# Llama Music Player v1.3.7

**Release status:** Unreleased

---

## Overview

This release introduces the adaptive surface-theme foundation and
theme-aware color helpers. The selected surface mode is persisted and
can follow the device setting or force a light or dark surface.

## Added

- **Adaptive Surface Modes** — Added SYSTEM, LIGHT, and DARK modes and
  semantic colors for application backgrounds, surfaces, panels,
  secondary text, and disabled controls.
- **Accent Contrast Helpers** — Added contrast-aware accent text styling
  for surfaces where the selected accent needs a glow.

## Changed

- **Activity Surface Painting** — Activities that use the surface helper
  apply the selected background color to the window and system bars.
- **Notification Placeholder** — The placeholder drawing path uses the
  active global surface background.

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)

## Download

The APK will be available from the Assets section when this release is
published.
