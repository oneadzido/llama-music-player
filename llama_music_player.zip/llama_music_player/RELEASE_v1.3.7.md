# Llama Music Player v1.3.7

**Release date:** Oct 23, 2026

### Overview

Three changes ship in this release: the incoming-file pathway plays
every request, the notification's play/pause icon never drifts from
the state machine's destination, and the theme list carries two new
colors.

An incoming audio file is an explicit play request. The activity
parks the file's path in the service, the service resolves the path
as the anchor of the playlist rebuild the insert triggers, and the
state machine transitions to it. The path was preserved through the
rebuild's cold-start branch, but not through the branch that runs
while a transition is already in flight. When the user opened a file
while a next or previous request was preparing, the pending path was
cleared before the in-flight branch could consult it, so the request
was consumed without being acted on: the rebuild had adopted the new
playlist, so the new song's art and title replaced the old ones, and
the old target kept playing. The pending path now overrides the
in-flight target; the transition to it begins once the current
prepare settles.

The notification's play/pause icon reads the destination of the
current transition. The destination is derived from `isPlaying()`,
which previously read `mAutoStartOnPrepared` alone during PREPARING
and did not account for a pending pause. A tap on the notification's
pause action during a prepare therefore left the icon showing
"pause" until the prepare completed. The controller was also not
poked when a transition began, so the icon reflected the previous
state for the duration of the prepare. `isPlaying()` now accounts
for both flags, every PREPARING state change pokes the controller
on the same main-thread turn, and the audio-focus gain path handles
PREPARING and READY.

The theme list gains two colors at its end: Cloudy Sky and Carbon
Fiber. `ThemeManager.COLOR_VALUES` carries the hex values and
`R.array.theme_names` carries the display names in each locale.

### Fixed

- **Incoming file plays when a transition is already in flight** —
  When a user opens an audio file from another app while a next or
  previous request is preparing, the file's path is parked in the
  service as a pending path, and the playlist rebuild that follows
  the insert resolves the path as the anchor of the next
  transition. The rebuild had two branches that preserve the
  target through an in-flight transition. The cold-start branch
  carried the pending path through unchanged and started the
  transition when the rebuild returned. The in-flight branch
  re-resolved the in-flight target's path against the new playlist
  and returned; it did not consult the pending path. The pending
  slot had already been cleared on the same turn, so the request
  was consumed by the rebuild without the state machine ever
  transitioning to it. The user saw the new song's art and title
  — the rebuild's re-resolved target adopted the newest path —
  while the old target kept playing.

  The in-flight branch now recognises the pending path and
  overrides the target with it. The reconcile that follows sees
  PREPARING and sets `mDeferredReconcile`, and the prepare
  completion callback re-enters reconciliation with the newest
  target. The new song plays through the same transition path a
  next or previous request uses.

- **Notification play/pause icon never drifts from the state
  machine** — The icon reads `isPlaying()`, which reported the
  destination of a PREPARING transition from
  `mAutoStartOnPrepared` alone. A pause scheduled during a
  prepare — a notification pause tap, a media-session pause, a
  hardware pause key, an audio-focus loss — sets
  `mPauseAfterPrepare` and leaves `mAutoStartOnPrepared`
  untouched, so the icon kept showing "pause" until the prepare
  settled. The same gap applied in reverse: a resume requested
  during a prepare did not clear the pending pause, so the icon
  stayed on "play" after the user had asked for playback. The
  controller was also not poked when a transition began, so the
  icon reflected the previous generation for the whole window
  between the request and the prepare's completion.

  `isPlaying()` now reads
  `mAutoStartOnPrepared && !mPauseAfterPrepare` during PREPARING,
  so the destination the icon reports and the destination the
  state machine will settle on are the same value. Every state
  change that shifts `isPlaying()` during PREPARING — a transition
  entry in `beginTransition`, a toggle, a pause, a resume, a
  media-session callback, a media-button press — pokes the
  notification controller on the same main-thread turn, so the
  icon flips at the moment the request is accepted rather than
  when the prepare completes. The toggle reflects the current
  destination: a transition heading toward playback gets a
  pending pause and a cleared transient-loss flag, and a
  transition already headed toward pause has the pending pause
  cleared and the auto-start re-armed.

- **Audio focus gain handles PREPARING and READY** —
  `AUDIOFOCUS_GAIN` previously resumed only from PAUSED. A
  transient loss that arrived during PREPARING set
  `mPauseAfterPrepare` and cleared `mAutoStartOnPrepared`; when
  gain arrived before the prepare completed, the pending pause
  was not cleared, so the song loaded in READY instead of
  playing. A transient loss that arrived during PREPARING and
  settled to READY before gain arrived left the song in READY;
  gain did not start playback. The gain branch now clears the
  pending pause and re-arms the auto-start when the state is
  PREPARING, and starts playback from READY when the prepare
  completed while the loss was active. Every branch of the focus
  handler pokes the controller, so a focus event that does not
  change the state — a duck, a gain without a remembered pause,
  a loss while already paused — does not leave the icon from the
  previous transition.

- **Theme names resolve in every locale** — The two colors added
  at the end of `ThemeManager.COLOR_VALUES` (indices 30 and 31)
  had no matching entries in the `theme_names` string-array of
  any locale file, so every array held 30 entries against a
  32-entry color list. `ThemeManager.getColorName(30)` and
  `getColorName(31)` returned null in all sixteen languages, and
  the theme list could not label either of the last two rows.
  Every locale's `theme_names` array now carries both entries, so
  the array's length matches `COLOR_VALUES` and
  `getColorName(int)` resolves a name for both new indices in
  every language.

### Added

- **Cloudy Sky theme color** — A pure white at index 30 of
  `ThemeManager.COLOR_VALUES`. The hex value is `#FFFFFF`. The
  theme's display name is carried in `R.array.theme_names` in
  each locale.

- **Carbon Fiber theme color** — A near-black charcoal at index
  31 of `ThemeManager.COLOR_VALUES`. The hex value is `#2E2E2E`.
  The theme's display name is carried in `R.array.theme_names` in
  each locale.

### Changed

- **Dark Moon is now Carbon Fiber** — The theme at index 31 was
  introduced as Dark Moon with the hex value `#5D5D80`. It ships
  in this release as Carbon Fiber, a near-black charcoal at
  `#2E2E2E`, to match the material the name describes. A device
  that already has index 31 selected picks up the new color on
  the next launch with no stored value to migrate: the index is
  what `SharedPreferences` holds, and the hex value is read from
  `COLOR_VALUES` through that index.

### Under the Hood

- `MusicService.isPlaying()` — the PREPARING arm returns
  `mAutoStartOnPrepared && !mPauseAfterPrepare`.

- `MusicService.pokeNotificationIfAttached()` — a new helper that
  pokes the controller's awareness poll when one is installed and
  is a no-op when it is not. Called from every state change that
  shifts `isPlaying()`.

- `MusicService.beginTransition(int, int)` — pokes the controller
  after setting the state to PREPARING, so the icon flips on the
  turn the transition begins.

- `MusicService.togglePlayPause()` — the PREPARING arm reads the
  current destination and toggles it. A transition heading toward
  playback gets a pending pause and a cleared transient-loss
  flag; a transition already headed toward pause has the pending
  pause cleared and the auto-start re-armed. Both branches poke
  the controller.

- `MusicService.pause()` — the PREPARING arm pokes the controller
  after setting `mPauseAfterPrepare`.

- `MusicService.resume()` — gained a PREPARING arm that clears
  `mPauseAfterPrepare` and re-arms `mAutoStartOnPrepared` when
  either was set, and pokes the controller.

- `MusicService.handleAudioFocusChange(int)` — the
  `AUDIOFOCUS_GAIN` branch now handles PAUSED, PREPARING, and
  READY. The PREPARING case clears the pending pause and
  re-arms the auto-start; the READY case runs the READY-to-PLAYING
  transition. Every branch pokes the controller.

- `MusicService.setupMediaSession()` — the `onPlay` and `onPause`
  callbacks gained PREPARING arms that reflect the request and
  poke the controller.

- `MusicService.handleMediaButton(int)` — the
  `KEYCODE_MEDIA_PLAY` and `KEYCODE_MEDIA_PAUSE` arms gained
  PREPARING handling and poke the controller.

- `MusicService.reconcile()` — the no-op branch clears
  `mDeferredReconcile` before returning, so a request that
  resolved to the current song cannot be re-entered by a later
  completion callback.

- `MusicService.setPlaylist(ArrayList<Song>, boolean)` — the
  PREPARING branch recognises the pending path and overrides the
  target with it before calling `reconcile()`. The pending slot
  is consumed only when the path it names was found in the
  rebuilt playlist.

- `ThemeManager.COLOR_VALUES` — two entries appended at indices
  30 and 31. Index 31 carries `#2E2E2E` under the name Carbon
  Fiber.

- `res/values/strings.xml` and every locale's `strings.xml` —
  the `theme_names` string-array gained two entries in each file,
  so the array's length matches `COLOR_VALUES` and
  `ThemeManager.getColorName(int)` resolves a name for both new
  indices in every locale.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana