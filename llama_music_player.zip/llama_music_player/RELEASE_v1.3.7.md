# Llama Music Player v1.3.7

**Release status:** Unreleased

---

## Overview

This release introduces adaptive surface themes and consistent theme-aware
color handling across the application. The selected mode is persisted and
can follow the device setting or force a light or dark surface.

## Added

- **Adaptive Surface Themes** — Added SYSTEM, LIGHT, and DARK modes with
  semantic colors for backgrounds, surfaces, panels, secondary text, and
  disabled controls.
- **Accent Contrast** — Added contrast-aware accent text styling and
  drawable glow support for theme-sensitive controls.
- **License Expansion Timing** — License sections use a 250 ms expansion
  delay, and tapping an already-expanded section does not rebuild it.

## Changed

- **Activity Surface Painting** — Activity windows and system bars use the
  selected surface color.
- **Notification Placeholder** — Placeholder artwork uses the current
  global surface background.

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)

## Download

The APK will be available from the Assets section when this release is
published.
