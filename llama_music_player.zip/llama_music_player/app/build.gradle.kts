// app/build.gradle.kts
//
// Llama Music Player — App-level Build Configuration
// ============================================================================
//
// Android application module configuration for v1.5.0.
//
// Every source file under app/src/main/kotlin is Kotlin. The
// EventBus is installed by LlamaEventBus.init() at runtime and
// discovers subscribers through the library's reflective lookup.
//
// Key Configuration Areas
// ------------------------
//   SDK:            compileSdk 36, minSdk 23, targetSdk 36
//   Signing:        Release signing reads local.properties
//                   (signing.storeFile, signing.storePassword,
//                   signing.keyAlias, signing.keyPassword)
//   Localization:   Sixteen locales bounded by resourceConfigurations
//   ProGuard:       Code shrinking and optimization for release builds;
//                   rules in proguard-rules.pro
//   EventBus:       Reflective subscriber lookup
//   Dependencies:   EventBus, jaudiotagger (from Maven Central), AndroidX,
//                   coroutines
//
// Toolchain compatibility
// -----------------------
//   AGP        8.7.2   ←→   Gradle 8.9 (declared in
//                            gradle/wrapper/gradle-wrapper.properties)
//   Kotlin     2.0.21  ←→   AGP 8.7.2
//   JDK        17       (declared under compileOptions and kotlinOptions)
//
// @author Richard Korbla Adzido
// @version 1.5.0
// @since 1.0.0
// ============================================================================

import java.io.FileInputStream
import java.util.Properties

// ============================================================================
// Plugins
// ============================================================================
//
// Three plugins, all versioned at the root build.gradle.kts:
//
//   com.android.application              — the Android application plugin
//                                          (AGP 8.7.2)
//   org.jetbrains.kotlin.android         — the Kotlin Android plugin
//                                          (Kotlin 2.0.21)
//   org.jetbrains.kotlin.plugin.parcelize — Parcelize, generating Parcelable
//                                          implementations at compile time
//                                          for event payloads crossing
//                                          process boundaries (Kotlin 2.0.21)
//
// The versions are declared at the root with `apply false`; the app module
// applies them here without re-declaring the versions.
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.parcelize")
}

// ============================================================================
// Keystore Properties Loading
// ============================================================================
//
// Signing credentials are read from local.properties when the file exists.
// The CI workflow writes the four keys below before invoking Gradle:
//
//   signing.storeFile      absolute path to the keystore
//   signing.storePassword  keystore password
//   signing.keyAlias       key alias inside the keystore
//   signing.keyPassword    key password
//
// When any key is missing, the release build is unsigned. That is the
// normal case for a local developer build: the debug build type is used,
// or the release build is signed with the Android debug keystore.
// ============================================================================

val keystorePropertiesFile = rootProject.file("local.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

val keystoreStoreFile: java.io.File? =
    keystoreProperties.getProperty("signing.storeFile")?.let { path ->
        try {
            rootProject.file(path)
        } catch (e: Exception) {
            null
        }
    }

// ============================================================================
// Android Configuration
// ============================================================================

android {

    /**
     * Namespace for generated R and BuildConfig classes.
     */
    namespace = "com.ark.llama"

    /**
     * Compile SDK Version. The app is compiled against API 36
     * (Android 16) and remains backward compatible with minSdk 23.
     */
    compileSdk = 36

    /**
     * Build Tools Version. Pinned to 36.0.0 for determinism across
     * developer machines and CI.
     */
    buildToolsVersion = "36.0.0"

    defaultConfig {

        /**
         * Unique identifier for the app on the device and in the
         * Google Play Store. Matches the Kotlin package name.
         */
        applicationId = "com.ark.llama"

        /**
         * Minimum SDK Version. API 23 (Android 6.0 Marshmallow) is
         * the floor for runtime permission support and for the
         * `checkSelfPermission(Context)` API used by
         * [com.ark.llama.PermissionChecker].
         */
        minSdk = 23

        /**
         * Target SDK Version. API 36 (Android 16) for latest
         * platform features.
         */
        targetSdk = 36

        /**
         * Version Code. Incremented for each release. v1.5.0 ships
         * as code 50.
         */
        versionCode = 50

        /**
         * Version Name. Follows semantic versioning.
         */
        versionName = "1.5.0"

        /**
         * MultiDex support for apps with more than 65,536 methods.
         */
        multiDexEnabled = true

        /**
         * Resource Configurations.
         *
         * Restricts the locale resources the release APK and AAB
         * carry. The application ships exactly the sixteen
         * languages the in-app picker offers, and the set is
         * declared here, in LanguageManager.LANGUAGE_TAGS, and in
         * res/xml/locales_config.xml. The three lists describe the
         * same set.
         *
         * Each entry is an Android resource-folder code, not a
         * BCP 47 tag. Indonesian is `in` here (folder code)
         * although the wider BCP 47 standard uses `id`.
         */
        resourceConfigurations.addAll(
            listOf(
                "en",  // 0  English
                "es",  // 1  Spanish
                "fr",  // 2  French
                "de",  // 3  German
                "it",  // 4  Italian
                "pt",  // 5  Portuguese
                "ru",  // 6  Russian
                "zh",  // 7  Chinese
                "ja",  // 8  Japanese
                "ko",  // 9  Korean
                "hi",  // 10 Hindi
                "ar",  // 11 Arabic
                "tr",  // 12 Turkish
                "in",  // 13 Indonesian (folder code; current BCP 47 tag is "id")
                "nl",  // 14 Dutch
                "pl",  // 15 Polish
            )
        )
    }

    /**
     * Signing Configurations.
     *
     * Credentials are loaded from local.properties to keep them
     * secure. When the keystore file is present, the release
     * configuration is created and attached to the release build
     * type below.
     */
    signingConfigs {
        if (keystoreStoreFile != null) {
            create("release") {
                storeFile = keystoreStoreFile
                storePassword = keystoreProperties.getProperty("signing.storePassword")
                keyAlias = keystoreProperties.getProperty("signing.keyAlias")
                keyPassword = keystoreProperties.getProperty("signing.keyPassword")
            }
        }
    }

    /**
     * Compile Options. Java 17 source/target with core library
     * desugaring for the java.time API surface used by jaudiotagger.
     */
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
        encoding = "UTF-8"
    }

    /**
     * Kotlin compiler options. jvmTarget 17 matches compileOptions
     * so the Kotlin and Java outputs are byte-compatible at the
     * 17 level.
     */
    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {

        /**
         * Release build type: R8 shrinking, resource shrinking,
         * zip-alignment, ProGuard rules.
         */
        release {
            if (keystoreStoreFile != null) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = true
            isShrinkResources = true
            isZipAlignEnabled = true
            isDebuggable = false
            isJniDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }

        /**
         * Debug build type: no shrinking, no obfuscation, zip-aligned,
         * debuggable, JNI-debuggable.
         */
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            isZipAlignEnabled = true
            isDebuggable = true
            isJniDebuggable = true
        }
    }

    /**
     * Source Sets.
     *
     * All Kotlin sources live under src/main/kotlin. The
     * src/main/java path is deliberately absent.
     */
    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("src/main/jniLibs")
            java.srcDirs("src/main/kotlin")
        }
    }

    /**
     * Packaging Options. Resolves duplicate .so files and excludes
     * library license files that would collide at merge time.
     */
    packaging {
        jniLibs {
            pickFirsts += "**/*.so"
        }
        resources {
            excludes += listOf(
                "META-INF/DEPENDENCIES",
                "META-INF/NOTICE",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE.txt",
                "META-INF/*.kotlin_module"
            )
        }
    }

    /**
     * Bundle Configuration.
     *
     * Language split disabled: the in-app picker must change the
     * display language on the installed instance without a Play
     * reconfiguration. Density and ABI splits remain enabled.
     */
    bundle {
        language { enableSplit = false }
        density  { enableSplit = true  }
        abi      { enableSplit = true  }
    }

    /**
     * Build Features.
     *
     * View binding is disabled — the activities use findViewById.
     * BuildConfig is enabled for the DEBUG flag that
     * LlamaEventBus.init() reads to decide the subscriber-exception
     * policy.
     */
    buildFeatures {
        viewBinding = false
        buildConfig = true
    }
}

// ============================================================================
// Dependencies
// ============================================================================

dependencies {

    /**
     * Core library desugaring. Supplies the java.time API surface
     * on devices below API 26, which jaudiotagger relies on.
     */
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.3")

    // ---- Kotlin & Coroutines ----

    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // ---- AndroidX ----

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("androidx.dynamicanimation:dynamicanimation:1.1.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media:media:1.7.0")

    // ---- EventBus ----

    /**
     * The event bus itself. Subscribers are discovered through the
     * library's reflective lookup at register time.
     */
    implementation("org.greenrobot:eventbus:3.3.1")

    // ---- Metadata ----

    /**
     * jaudiotagger for reading and writing ID3 tags and album art.
     */
    implementation("net.jthink:jaudiotagger:3.0.1")

    // ---- Testing ----

    testImplementation("junit:junit:4.13.2")
}

// ============================================================================
// APK Output Naming
// ============================================================================
//
// Release APK is named LlamaMusicPlayer-{versionName}.apk. The cast
// to the internal BaseVariantOutputImpl is guarded so a future AGP
// that renames the class does not break the build.
// ============================================================================

android.applicationVariants.all {
    if (buildType.name == "release") {
        outputs.all {
            try {
                (this as? com.android.build.gradle.internal.api.BaseVariantOutputImpl)
                    ?.outputFileName = "LlamaMusicPlayer-${versionName}.apk"
            } catch (ignored: ClassCastException) {
                // Leave default naming.
            }
        }
    }
}