// PlaybackScope.java
package com.ark.llama;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Immutable filter describing which subset of the library the player
 * considers its current playback scope. Combined with the loose-track path
 * set owned by {@link MusicService}, {@link #matches(Song, Set)} answers
 * whether a given song belongs to the active scope.
 *
 * <h3>The Seven Kinds</h3>
 * <p>{@link Kind} enumerates the seven scope modes: All, Favorites,
 * Loose Tracks, Folders, Genres, Artists, Albums. The first three are
 * exclusive and select nothing else; the last four carry a single
 * non-empty set of the corresponding filter values. The kind and the
 * set that kind uses travel together; the three other sets are empty
 * for any given instance.</p>
 *
 * <h3>Serialization</h3>
 * <p>{@link #serialize()} produces a JSON object string that
 * {@link #deserialize(String)} parses back into an equal instance. The
 * representation is stable across process restarts and is the format
 * {@link MusicService} persists under
 * {@code playback_scope_json} in {@code LlamaPrefs}. A malformed
 * string deserializes to {@link #ALL}, so a corrupted preference
 * cannot brick the player.</p>
 *
 * <h3>Folder Matching</h3>
 * <p>Folder scope matches a song when its path begins with the
 * stored folder path followed by a path separator. The separator
 * check is what stops {@code /storage/emulated/0/Music} from also
 * matching {@code /storage/emulated/0/Music2/song.mp3}. The match is
 * prefix-based rather than exact-equality because a folder scope
 * includes every subdirectory under that folder.</p>
 *
 * <h3>Placeholder Guard</h3>
 * <p>The genre, artist, and album matchers reject a field whose value
 * is the current locale's placeholder, so a song whose genre is
 * "Unknown Genre" is never matched against a stored genre of
 * "Unknown Genre" chosen by the user. The rejection uses
 * {@link CharacterMapper#isUnknownGenre(String)} and its siblings,
 * which recognise the placeholder in every supported locale.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.4.0
 * @since 1.4.0
 */
public final class PlaybackScope {

    // ============================================================================
    // Kind Enum
    // ============================================================================

    /**
     * The seven scope kinds.
     *
     * <p>The first three carry no filter set; the last four carry
     * exactly one. The mismatch is deliberate: a scope is either
     * "everything", "something the player derives from the song's
     * own state", or "something the user enumerated". Enumerations
     * are the only kinds that need their own set.</p>
     */
    public enum Kind {
        /** Every song in the library. */
        ALL,
        /** Only songs marked as favorites. */
        FAVORITES,
        /** Only songs that arrived as loose tracks. */
        LOOSE_TRACKS,
        /** Only songs under the enumerated folder paths. */
        FOLDERS,
        /** Only songs whose genre is in the enumerated set. */
        GENRES,
        /** Only songs whose artist is in the enumerated set. */
        ARTISTS,
        /** Only songs whose album is in the enumerated set. */
        ALBUMS
    }

    // ============================================================================
    // Shared Empty Instance
    // ============================================================================

    /** The "every song" scope. Immutable and shared. */
    @NonNull
    public static final PlaybackScope ALL = new PlaybackScope(
        Kind.ALL,
        Collections.emptySet(), Collections.emptySet(),
        Collections.emptySet(), Collections.emptySet());

    // ============================================================================
    // Fields
    // ============================================================================

    /** Kind of this scope. */
    @NonNull public final Kind kind;

    /** Folder paths used when {@link #kind} is {@link Kind#FOLDERS}. */
    @NonNull public final Set<String> paths;

    /** Genres used when {@link #kind} is {@link Kind#GENRES}. */
    @NonNull public final Set<String> genres;

    /** Artists used when {@link #kind} is {@link Kind#ARTISTS}. */
    @NonNull public final Set<String> artists;

    /** Albums used when {@link #kind} is {@link Kind#ALBUMS}. */
    @NonNull public final Set<String> albums;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a scope with the given kind and filter sets.
     *
     * <p>The sets are copied and made unmodifiable, so the instance
     * is deeply immutable from the caller's point of view. Pass
     * {@link Collections#emptySet()} for the four sets the kind does
     * not use; the {@link #matches(Song, Set)} implementation only
     * reads the set the kind names.</p>
     *
     * @param kind Kind of this scope
     * @param paths Folder paths, or empty
     * @param genres Genres, or empty
     * @param artists Artists, or empty
     * @param albums Albums, or empty
     */
    public PlaybackScope(@NonNull Kind kind,
                         @NonNull Set<String> paths,
                         @NonNull Set<String> genres,
                         @NonNull Set<String> artists,
                         @NonNull Set<String> albums) {
        this.kind = kind;
        this.paths = Collections.unmodifiableSet(new HashSet<>(paths));
        this.genres = Collections.unmodifiableSet(new HashSet<>(genres));
        this.artists = Collections.unmodifiableSet(new HashSet<>(artists));
        this.albums = Collections.unmodifiableSet(new HashSet<>(albums));
    }

    // ============================================================================
    // Factory Methods
    // ============================================================================

    /**
     * Returns a scope that selects only favorites.
     *
     * @return A favorites scope
     */
    @NonNull
    public static PlaybackScope favorites() {
        return new PlaybackScope(Kind.FAVORITES,
            Collections.emptySet(), Collections.emptySet(),
            Collections.emptySet(), Collections.emptySet());
    }

    /**
     * Returns a scope that selects only loose tracks.
     *
     * @return A loose-tracks scope
     */
    @NonNull
    public static PlaybackScope looseTracks() {
        return new PlaybackScope(Kind.LOOSE_TRACKS,
            Collections.emptySet(), Collections.emptySet(),
            Collections.emptySet(), Collections.emptySet());
    }

    /**
     * Returns a folder scope.
     *
     * @param folderPaths Filesystem paths of the folders to include
     * @return A folders scope
     */
    @NonNull
    public static PlaybackScope folders(@NonNull Set<String> folderPaths) {
        return new PlaybackScope(Kind.FOLDERS, folderPaths,
            Collections.emptySet(), Collections.emptySet(),
            Collections.emptySet());
    }

    /**
     * Returns a genre scope.
     *
     * @param genreNames Genres to include
     * @return A genres scope
     */
    @NonNull
    public static PlaybackScope genres(@NonNull Set<String> genreNames) {
        return new PlaybackScope(Kind.GENRES,
            Collections.emptySet(), genreNames,
            Collections.emptySet(), Collections.emptySet());
    }

    /**
     * Returns an artist scope.
     *
     * @param artistNames Artists to include
     * @return An artists scope
     */
    @NonNull
    public static PlaybackScope artists(@NonNull Set<String> artistNames) {
        return new PlaybackScope(Kind.ARTISTS,
            Collections.emptySet(), Collections.emptySet(),
            artistNames, Collections.emptySet());
    }

    /**
     * Returns an album scope.
     *
     * @param albumNames Albums to include
     * @return An albums scope
     */
    @NonNull
    public static PlaybackScope albums(@NonNull Set<String> albumNames) {
        return new PlaybackScope(Kind.ALBUMS,
            Collections.emptySet(), Collections.emptySet(),
            Collections.emptySet(), albumNames);
    }

    // ============================================================================
    // Matching
    // ============================================================================

    /**
     * Returns whether the given song belongs to this scope.
     *
     * <p>A null song, a song with a null path, or a song whose
     * fields carry the current locale's placeholder never match.
     * The placeholder guard is what stops a "genre" scope chosen by
     * the user from also matching a song whose genre was never
     * tagged.</p>
     *
     * @param song Song to test, or null
     * @param looseTrackPaths Paths of the loose tracks known to the
     *        service
     * @return True when the song belongs to the scope
     */
    public boolean matches(@Nullable Song song,
                           @NonNull Set<String> looseTrackPaths) {
        if (song == null || song.getPath() == null) {
            return false;
        }
        switch (kind) {
            case ALL:
                return true;
            case FAVORITES:
                return song.isFavorite();
            case LOOSE_TRACKS:
                return looseTrackPaths.contains(song.getPath());
            case FOLDERS: {
                final String songPath = song.getPath();
                for (String folderPath : paths) {
                    if (folderPath == null || folderPath.isEmpty()) {
                        continue;
                    }
                    final String prefix = folderPath.endsWith("/")
                        ? folderPath : folderPath + "/";
                    if (songPath.startsWith(prefix)) {
                        return true;
                    }
                }
                return false;
            }
            case GENRES: {
                final String genre = song.getGenre();
                return genre != null
                    && !CharacterMapper.isUnknownGenre(genre)
                    && genres.contains(genre);
            }
            case ARTISTS: {
                final String artist = song.getArtist();
                return artist != null
                    && !CharacterMapper.isUnknownArtist(artist)
                    && artists.contains(artist);
            }
            case ALBUMS: {
                final String album = song.getAlbum();
                return album != null
                    && !CharacterMapper.isUnknownAlbum(album)
                    && albums.contains(album);
            }
            default:
                return false;
        }
    }

    // ============================================================================
    // Serialization
    // ============================================================================

    /**
     * Serializes this scope to a JSON object string.
     *
     * <p>The representation names every field explicitly so a future
     * kind can be added without breaking older deserializers: an
     * unknown kind deserializes to {@link #ALL}.</p>
     *
     * @return A JSON string; never null
     */
    @NonNull
    public String serialize() {
        try {
            JSONObject object = new JSONObject();
            object.put("kind", kind.name());
            object.put("paths", new JSONArray(paths));
            object.put("genres", new JSONArray(genres));
            object.put("artists", new JSONArray(artists));
            object.put("albums", new JSONArray(albums));
            return object.toString();
        } catch (Exception exception) {
            return "{\"kind\":\"ALL\",\"paths\":[],\"genres\":[],\"artists\":[],\"albums\":[]}";
        }
    }

    /**
     * Deserializes a scope from a string previously produced by
     * {@link #serialize()}.
     *
     * <p>Returns {@link #ALL} for any input that does not parse, so
     * a corrupted preference cannot leave the player with a scope
     * that matches nothing.</p>
     *
     * @param serialized JSON string, or null
     * @return The deserialized scope; never null
     */
    @NonNull
    public static PlaybackScope deserialize(@Nullable String serialized) {
        if (serialized == null || serialized.isEmpty()) {
            return ALL;
        }
        try {
            JSONObject object = new JSONObject(serialized);
            Kind kind;
            try {
                kind = Kind.valueOf(object.optString("kind", "ALL"));
            } catch (IllegalArgumentException exception) {
                kind = Kind.ALL;
            }
            Set<String> paths = toStringSet(object.optJSONArray("paths"));
            Set<String> genres = toStringSet(object.optJSONArray("genres"));
            Set<String> artists = toStringSet(object.optJSONArray("artists"));
            Set<String> albums = toStringSet(object.optJSONArray("albums"));
            return new PlaybackScope(kind, paths, genres, artists, albums);
        } catch (Exception exception) {
            return ALL;
        }
    }

    /**
     * Converts a {@link JSONArray} of strings into a {@link Set}.
     *
     * @param array Array to convert, or null
     * @return A set containing each string in the array; empty when
     *         the array is null or empty
     */
    @NonNull
    private static Set<String> toStringSet(@Nullable JSONArray array) {
        Set<String> result = new HashSet<>();
        if (array == null) {
            return result;
        }
        for (int index = 0; index < array.length(); index++) {
            String value = array.optString(index, null);
            if (value != null) {
                result.add(value);
            }
        }
        return result;
    }

    // ============================================================================
    // Object Methods
    // ============================================================================

    /**
     * Returns whether this scope equals the given object.
     *
     * @param object Object to compare against, or null
     * @return True when the given object is a scope with the same
     *         kind and filter sets
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof PlaybackScope)) {
            return false;
        }
        PlaybackScope other = (PlaybackScope) object;
        return kind == other.kind
            && paths.equals(other.paths)
            && genres.equals(other.genres)
            && artists.equals(other.artists)
            && albums.equals(other.albums);
    }

    /**
     * Returns a hash code derived from the kind and the four filter
     * sets.
     *
     * @return The hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(kind, paths, genres, artists, albums);
    }

    /**
     * Returns a debug representation of this scope.
     *
     * @return A string naming the kind and the size of each set
     */
    @NonNull
    @Override
    public String toString() {
        return "PlaybackScope{kind=" + kind
            + ", paths=" + paths.size()
            + ", genres=" + genres.size()
            + ", artists=" + artists.size()
            + ", albums=" + albums.size() + '}';
    }
}