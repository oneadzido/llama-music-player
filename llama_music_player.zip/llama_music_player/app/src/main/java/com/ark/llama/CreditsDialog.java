package com.ark.llama;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Displays the application's credits, version, developer information,
 * third-party libraries, licenses, and theme selection controls.
 *
 * <p>The dialog shows the application icon, the application name, the
 * current version, the developer's name and email address, and a list of
 * the third-party libraries the application uses. A scrollable license
 * viewer sits below the libraries. The application's MIT license is
 * displayed by default. Tapping the application name or a library name
 * replaces the viewer content with that license, crossfading over a
 * 200-millisecond window.</p>
 *
 * <p>Tapping the application icon five times within five seconds reveals
 * the easter-egg message through {@link ToastManager}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. The theme receiver registered in
 * {@link #registerThemeReceiver()} delivers its callbacks on the main
 * thread through {@link #mMainHandler}. Delayed work is scheduled on that
 * same handler.</p>
 *
 * @see ThemeManager
 * @see ThemeHelper
 * @see ThemeDialog
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class CreditsDialog extends Dialog {

    // ========================================================================
    // Constants - Timing & Animation
    // ========================================================================

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Debounce delay for clickable text views in milliseconds. */
    private static final long TEXT_CLICK_DEBOUNCE_DELAY_MS = 250;

    /** Time window for easter egg taps in milliseconds. */
    private static final long TAP_TIMEOUT_MS = 5000;

    /** Number of taps required to trigger the easter egg. */
    private static final int REQUIRED_TAPS = 5;

    /** Intent action for theme color change broadcasts. */
    private static final String THEME_COLOR_CHANGED_ACTION = "THEME_COLOR_CHANGED";

    /** Message shown when the hidden easter egg is revealed. */
    private static final String EASTER_EGG_MESSAGE = "It all begins with a thought...";

    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Duration of license fade animation in milliseconds. */
    private static final int FADE_DURATION_MS = 200;

    // ========================================================================
    // Constants - Colors
    // ========================================================================

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Header background color. */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";

    /** Light gray text color for secondary text and headers. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Muted text color for license content and developer details. */
    private static final String TEXT_COLOR_MUTED = "#808080";

    // ========================================================================
    // Constants - Dimensions (dp)
    // ========================================================================

    /** Height of the top action bar in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of the version header bar in density-independent pixels. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;

    /** Height of action buttons in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Size of the app icon in density-independent pixels. */
    private static final int ICON_SIZE_DP = 64;

    /** Corner radius for the top of the dialog in density-independent pixels. */
    private static final int DIALOG_CORNER_RADIUS_DP = 20;

    /** Corner radius for license viewer container in density-independent pixels. */
    private static final int LICENSE_CORNER_RADIUS_DP = 10;

    /** Thickness of dividers in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;

    // ========================================================================
    // Constants - Padding (dp)
    // ========================================================================

    /** Standard padding for top bar and containers in density-independent pixels. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Base spacing unit in density-independent pixels. */
    private static final int SPACING_BASE_DP = 4;

    /** Header padding vertical in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;

    /** Header padding horizontal in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;

    /** Button padding horizontal in density-independent pixels. */
    private static final int BUTTON_PADDING_HORIZONTAL_DP = 8;

    /** Button padding vertical in density-independent pixels. */
    private static final int BUTTON_PADDING_VERTICAL_DP = 4;

    /** Bottom padding for dialog in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 4;

    // ========================================================================
    // License Texts for Dynamic Viewer
    // ========================================================================

    /** Llama Music Player's MIT License, displayed by default. */
    private static final String LLAMA_MIT_LICENSE =
        "Llama Music Player\n\n"
        + "Copyright (C) 2026 Richard Korbla Adzido\n\n"
        + "Licensed under the MIT License\n\n"
        + "Permission is hereby granted, free of charge, to any person obtaining a copy "
        + "of this software and associated documentation files (the \"Software\"), to deal "
        + "in the Software without restriction, including without limitation the rights "
        + "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell "
        + "copies of the Software, and to permit persons to whom the Software is "
        + "furnished to do so, subject to the following conditions:\n\n"
        + "The above copyright notice and this permission notice shall be included in all "
        + "copies or substantial portions of the Software.\n\n"
        + "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR "
        + "IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, "
        + "FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE "
        + "AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER "
        + "LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, "
        + "OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE "
        + "SOFTWARE.";

    /** jaudiotagger LGPL/MPL License text. */
    private static final String JAUDIOTAGGER_LICENSE =
        "jaudiotagger\n\n"
        + "Copyright (C) 2003-2018 jthink Ltd\n\n"
        + "Licensed under the GNU Lesser General Public License v2.1\n"
        + "or Mozilla Public License v1.1\n\n"
        + "This library is free software; you can redistribute it and/or "
        + "modify it under the terms of the GNU Lesser General Public "
        + "License as published by the Free Software Foundation; either "
        + "version 2.1 of the License, or (at your option) any later version.\n\n"
        + "Alternatively, this library may be distributed under the terms of "
        + "the Mozilla Public License Version 1.1.\n\n"
        + "jaudiotagger is used for reading and writing ID3 tags,\n"
        + "album art, and metadata in Llama Music Player.";

    /** FontAwesome SIL OFL 1.1 License text. */
    private static final String FONTAWESOME_LICENSE =
        "FontAwesome\n\n"
        + "Copyright (C) 2025 Fonticons, Inc.\n\n"
        + "This Font Software is licensed under the SIL Open Font License, Version 1.1.\n\n"
        + "This license is available with a FAQ at:\n http://scripts.sil.org/OFL\n\n"
        + "Permission is hereby granted, free of charge, to any person obtaining a copy "
        + "of the Font Software, to use, study, copy, merge, embed, modify, redistribute, "
        + "and sell modified and unmodified copies of the Font Software, subject to the "
        + "following conditions:\n\n"
        + "1. Neither the Font Software nor any of its individual components may be sold by itself.\n\n"
        + "2. The original copyright notice must be retained.\n\n"
        + "3. Modified versions must be clearly marked as such.\n\n"
        + "FontAwesome is used for folder icons, playback controls, and album art "
        + "placeholders in Llama Music Player.";

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Context used to access resources and services. */
    @NonNull
    private final Context mContext;

    /** Manager for reading the current theme color. */
    @NonNull
    private final ThemeManager mThemeManager;

    /** Helper for applying theme colors to UI components. */
    @NonNull
    private final ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    @Nullable
    private BroadcastReceiver mThemeReceiver;

    /** Timestamp of the last theme button click, for debouncing. */
    private long mLastThemeClickTime = 0;

    /** Timestamp of the last cancel button click, for debouncing. */
    private long mLastCancelClickTime = 0;

    /** True while the theme dialog is showing. */
    private boolean mIsThemeDialogShowing = false;

    /** License viewer whose content changes when the app name or a library is tapped. */
    @Nullable
    private TextView mDynamicLicenseText = null;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new CreditsDialog.
     *
     * @param context The context used to create the dialog; must not be null
     */
    public CreditsDialog(@NonNull Context context) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ========================================================================
    // Dialog Lifecycle Methods
    // ========================================================================

    /**
     * Initializes the dialog's window, content view, and theme receiver.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());
        configureWindow();
        applyThemeToContent();
        registerThemeReceiver();
    }

    /**
     * Dismisses the dialog, unregisters the theme receiver, and removes
     * all pending handler callbacks.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        if (mThemeReceiver != null) {
            try {
                mContext.unregisterReceiver(mThemeReceiver);
                mThemeReceiver = null;
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
        mMainHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Window Configuration Methods
    // ========================================================================

    /**
     * Configures the dialog window for full-screen display.
     */
    private void configureWindow() {
        Window window = getWindow();
        if (window == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }

        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.TOP;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.CreditsDialogAnimation);
    }

    // ========================================================================
    // Theme Management Methods
    // ========================================================================

    /**
     * Registers a broadcast receiver for theme color change events.
     *
     * <p>Does nothing when a receiver is already registered.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (THEME_COLOR_CHANGED_ACTION.equals(intent.getAction())) {
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            applyThemeToContent();
                            ToastManager.refreshThemeColor();
                        }
                    });
                }
            }
        };

        IntentFilter filter = new IntentFilter(THEME_COLOR_CHANGED_ACTION);
        mContext.registerReceiver(mThemeReceiver, filter);
    }

    /**
     * Applies the current theme color to every text view and button in
     * the dialog.
     */
    private void applyThemeToContent() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeManager.getCurrentColorInt();

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            applyThemeToTextViews((ViewGroup) rootView, themeColor);
            applyThemeToButtons((ViewGroup) rootView);

            if (mDynamicLicenseText != null) {
                mDynamicLicenseText.setTextColor(Color.parseColor(TEXT_COLOR_MUTED));
            }
        }
    }

    /**
     * Recursively applies theme colors to the TextViews in the given view
     * hierarchy, by the role each TextView plays.
     *
     * @param group The view group to traverse
     * @param themeColor The current theme color integer
     */
    private void applyThemeToTextViews(@NonNull ViewGroup group, int themeColor) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("ABOUT LLAMA")
                        || text.equals("VERSION")
                        || text.equals("Developer")
                        || text.equals("Libraries")
                        || text.equals("License")) {
                    textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                } else if (text.equals("Llama Music Player")) {
                    textView.setTextColor(themeColor);
                } else if (text.equals("jaudiotagger")
                        || text.equals("FontAwesome")) {
                    textView.setTextColor(themeColor);
                } else if (text.equals("Richard Korbla Adzido")
                        || text.equals("oneadzido@gmail.com")) {
                    textView.setTextColor(Color.parseColor(TEXT_COLOR_MUTED));
                }
            } else if (child instanceof ViewGroup) {
                applyThemeToTextViews((ViewGroup) child, themeColor);
            }
        }
    }

    /**
     * Recursively applies the current theme to every Button in the given
     * view hierarchy.
     *
     * @param group The view group to traverse
     */
    private void applyThemeToButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                applyThemeToButtons((ViewGroup) child);
            }
        }
    }

    // ========================================================================
    // Theme Dialog Methods
    // ========================================================================

    /**
     * Shows the theme selection dialog and applies the selected theme.
     */
    private void showThemeDialog() {
        String[] colorNames = mThemeManager.getColorNames();
        String[] colorValues = mThemeManager.getColorValues();
        int currentIndex = mThemeManager.getCurrentColorIndex();

        ThemeDialog dialog = new ThemeDialog(mContext, colorNames, colorValues, currentIndex,
            new ThemeDialog.OnThemeSelectedListener() {
                @Override
                public void onThemeSelected(int colorIndex, @NonNull String colorName,
                                            @NonNull String colorValue) {
                    if (colorIndex == mThemeManager.getCurrentColorIndex()) {
                        return;
                    }

                    mThemeManager.setThemeColor(colorIndex);
                    Intent intent = new Intent(THEME_COLOR_CHANGED_ACTION);
                    intent.putExtra("color", colorValue);
                    mContext.sendBroadcast(intent);
                }
            });

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dismissedDialog) {
                mIsThemeDialogShowing = false;
            }
        });

        dialog.show();
    }

    // ========================================================================
    // UI Construction Methods
    // ========================================================================

    /**
     * Creates the root content view of the dialog.
     *
     * @return The root view
     */
    @NonNull
    private View createContentView() {
        LinearLayout mainContainer = createMainContainer();

        mainContainer.addView(createTopBar());
        mainContainer.addView(createVersionHeader());
        mainContainer.addView(createScrollableContent());
        mainContainer.addView(createBottomPadding());

        return mainContainer;
    }

    /**
     * Creates the main container with rounded top corners.
     *
     * @return The main container layout
     */
    @NonNull
    private LinearLayout createMainContainer() {
        LinearLayout container = new LinearLayout(mContext);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[] {
            DIALOG_CORNER_RADIUS_DP, DIALOG_CORNER_RADIUS_DP,
            0, 0,
            0, 0,
            0, 0 });
        container.setBackground(background);

        return container;
    }

    /**
     * Creates the top action bar with a Cancel button, a title, and a
     * Themes button.
     *
     * @return The top bar layout
     */
    @NonNull
    private RelativeLayout createTopBar() {
        RelativeLayout topBar = new RelativeLayout(mContext);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createThemeButton());

        return topBar;
    }

    /**
     * Creates the Cancel button that closes the dialog.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText("CANCEL");
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(BUTTON_PADDING_HORIZONTAL_DP),
            dpToPx(BUTTON_PADDING_VERTICAL_DP),
            dpToPx(BUTTON_PADDING_HORIZONTAL_DP),
            dpToPx(BUTTON_PADDING_VERTICAL_DP));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.ALIGN_PARENT_START);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        button.setLayoutParams(params);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });

        addButtonAnimation(button);
        return button;
    }

    /**
     * Creates the "ABOUT LLAMA" title text for the top bar.
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(mContext);
        textView.setText("ABOUT LLAMA");
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(mThemeManager.getCurrentColorInt());
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        textView.setLayoutParams(params);

        return textView;
    }

    /**
     * Creates the Themes button that opens the theme selection dialog.
     *
     * @return The Themes button
     */
    @NonNull
    private Button createThemeButton() {
        Button button = new Button(mContext);
        button.setText("THEMES");
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(BUTTON_PADDING_HORIZONTAL_DP),
            dpToPx(BUTTON_PADDING_VERTICAL_DP),
            dpToPx(BUTTON_PADDING_HORIZONTAL_DP),
            dpToPx(BUTTON_PADDING_VERTICAL_DP));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.ALIGN_PARENT_END);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        button.setLayoutParams(params);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mIsThemeDialogShowing) {
                    return;
                }

                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastThemeClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastThemeClickTime = currentTime;
                    mIsThemeDialogShowing = true;
                    showThemeDialog();
                }
            }
        });

        addButtonAnimation(button);
        return button;
    }

    /**
     * Creates the version header showing the "VERSION" label and the
     * application version.
     *
     * @return The version header layout
     */
    @NonNull
    private LinearLayout createVersionHeader() {
        LinearLayout headerBar = new LinearLayout(mContext);
        headerBar.setOrientation(LinearLayout.HORIZONTAL);
        headerBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        headerBar.setGravity(Gravity.CENTER_VERTICAL);
        headerBar.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP),
            dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP));
        headerBar.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));

        TextView headerTitle = new TextView(mContext);
        headerTitle.setText("VERSION");
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView headerVersion = new TextView(mContext);
        headerVersion.setText(getAppVersion());
        headerVersion.setTextSize(12);
        headerVersion.setLetterSpacing(0.1f);
        headerVersion.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));

        headerBar.addView(headerTitle);
        headerBar.addView(headerVersion);

        return headerBar;
    }

    /**
     * Returns the application's version name.
     *
     * @return The version name, or {@code "1.1.8"} when the package
     *         manager does not return one
     */
    @NonNull
    private String getAppVersion() {
        try {
            PackageInfo packageInfo = mContext.getPackageManager().getPackageInfo(
                mContext.getPackageName(), 0);
            return packageInfo.versionName;
        } catch (Exception exception) {
            return "1.1.8";
        }
    }

    /**
     * Creates the scrollable content area containing the app icon,
     * developer details, libraries, and license viewer.
     *
     * @return The scroll view containing all content
     */
    @NonNull
    private ScrollView createScrollableContent() {
        ScrollView scrollView = new ScrollView(mContext);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        scrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        LinearLayout contentContainer = new LinearLayout(mContext);
        contentContainer.setOrientation(LinearLayout.VERTICAL);
        contentContainer.setPadding(0, dpToPx(SPACING_BASE_DP * 2),
            0, dpToPx(SPACING_BASE_DP * 2));
        contentContainer.setGravity(Gravity.CENTER);

        contentContainer.addView(createAppIcon());
        contentContainer.addView(createAppNameText());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));
        contentContainer.addView(createDivider());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));

        contentContainer.addView(createDeveloperSection());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));
        contentContainer.addView(createDivider());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));

        contentContainer.addView(createLibrariesSection());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));
        contentContainer.addView(createDivider());
        contentContainer.addView(createSpacer(dpToPx(SPACING_BASE_DP)));

        contentContainer.addView(createLicenseViewerSection());

        scrollView.addView(contentContainer);
        return scrollView;
    }

    /**
     * Creates a spacer view of the given height.
     *
     * @param heightPx The height of the spacer in pixels
     * @return The spacer view
     */
    @NonNull
    private View createSpacer(int heightPx) {
        View spacer = new View(mContext);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, heightPx));
        return spacer;
    }

    /**
     * Creates the application icon and attaches the easter-egg tap
     * listener.
     *
     * @return The application icon image view
     */
    @NonNull
    private ImageView createAppIcon() {
        ImageView imageView = new ImageView(mContext);

        try {
            Bitmap icon = BitmapFactory.decodeResource(
                mContext.getResources(), R.mipmap.ic_launcher);
            if (icon != null) {
                imageView.setImageBitmap(icon);
            } else {
                imageView.setImageResource(R.drawable.ic_notification);
            }
        } catch (Exception exception) {
            imageView.setImageResource(R.drawable.ic_notification);
        }

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            dpToPx(ICON_SIZE_DP), dpToPx(ICON_SIZE_DP));
        params.gravity = Gravity.CENTER;
        imageView.setLayoutParams(params);

        imageView.setClickable(true);
        imageView.setFocusable(true);

        imageView.setOnClickListener(new View.OnClickListener() {
            private int mTapCount = 0;
            private long mLastTapTime = 0;

            @Override
            public void onClick(View view) {
                final View tappedView = view;

                tappedView.animate()
                    .scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            tappedView.animate()
                                .scaleX(ANIMATION_SCALE_NORMAL)
                                .scaleY(ANIMATION_SCALE_NORMAL)
                                .setDuration(ANIMATION_DURATION_MS)
                                .start();
                        }
                    })
                    .start();

                long currentTime = SystemClock.elapsedRealtime();

                if (currentTime - mLastTapTime > TAP_TIMEOUT_MS) {
                    mTapCount = 0;
                }

                mLastTapTime = currentTime;
                mTapCount++;

                if (mTapCount >= REQUIRED_TAPS) {
                    mTapCount = 0;
                    showSecretMessage();
                }
            }
        });

        return imageView;
    }

    /**
     * Shows the easter-egg message.
     */
    private void showSecretMessage() {
        try {
            Window window = getWindow();
            if (window == null) {
                return;
            }

            ViewGroup rootView = (ViewGroup) window.getDecorView()
                .findViewById(android.R.id.content);
            if (rootView == null) {
                return;
            }

            ToastManager.showToastInView(
                rootView, EASTER_EGG_MESSAGE, ToastManager.LENGTH_LONG);
        } catch (Exception exception) {
            // The easter egg is non-essential; ignore failures so the
            // dialog continues to function normally.
        }
    }

    /**
     * Creates the clickable application-name TextView that shows the
     * application's MIT license when tapped.
     *
     * @return The clickable application-name text view
     */
    @NonNull
    private TextView createAppNameText() {
        final TextView textView = new TextView(mContext);
        textView.setText("Llama Music Player");
        textView.setTextSize(16);
        textView.setTextColor(mThemeManager.getCurrentColorInt());
        textView.setGravity(Gravity.CENTER);
        textView.setClickable(true);
        textView.setFocusable(true);

        textView.setOnClickListener(new View.OnClickListener() {
            private long mLastClickTime = 0;

            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastClickTime < TEXT_CLICK_DEBOUNCE_DELAY_MS) {
                    return;
                }
                mLastClickTime = currentTime;

                final View tappedView = view;

                tappedView.animate()
                    .scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            tappedView.animate()
                                .scaleX(ANIMATION_SCALE_NORMAL)
                                .scaleY(ANIMATION_SCALE_NORMAL)
                                .setDuration(ANIMATION_DURATION_MS)
                                .start();
                        }
                    })
                    .start();

                updateLicenseViewer(LLAMA_MIT_LICENSE);
            }
        });

        return textView;
    }

    /**
     * Creates a transparent divider for spacing between sections.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.TRANSPARENT);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates the developer section with name and email.
     *
     * @return The developer section layout
     */
    @NonNull
    private LinearLayout createDeveloperSection() {
        LinearLayout section = new LinearLayout(mContext);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setGravity(Gravity.CENTER);

        section.addView(createSectionTitle("Developer"));
        section.addView(createDeveloperText("Richard Korbla Adzido"));
        section.addView(createDeveloperText("oneadzido@gmail.com"));

        return section;
    }

    /**
     * Creates a developer detail text with muted styling.
     *
     * @param text The text to display
     * @return The styled text view
     */
    @NonNull
    private TextView createDeveloperText(String text) {
        TextView textView = new TextView(mContext);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_MUTED));
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(0, dpToPx(SPACING_BASE_DP / 2),
            0, dpToPx(SPACING_BASE_DP / 2));
        return textView;
    }

    /**
     * Creates the libraries section with clickable library names.
     *
     * @return The libraries section layout
     */
    @NonNull
    private LinearLayout createLibrariesSection() {
        LinearLayout section = new LinearLayout(mContext);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setGravity(Gravity.CENTER);

        section.addView(createSectionTitle("Libraries"));
        section.addView(createClickableLibraryText("jaudiotagger", JAUDIOTAGGER_LICENSE));
        section.addView(createClickableLibraryText("FontAwesome", FONTAWESOME_LICENSE));

        return section;
    }

    /**
     * Creates a clickable library name that animates on tap and shows the
     * given license in the viewer.
     *
     * @param text The library name to display
     * @param license The license text shown when the name is tapped
     * @return The styled clickable text view
     */
    @NonNull
    private TextView createClickableLibraryText(String text, final String license) {
        final TextView textView = new TextView(mContext);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(mThemeManager.getCurrentColorInt());
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(0, dpToPx(SPACING_BASE_DP / 2),
            0, dpToPx(SPACING_BASE_DP / 2));
        textView.setClickable(true);
        textView.setFocusable(true);

        textView.setOnClickListener(new View.OnClickListener() {
            private long mLastClickTime = 0;

            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastClickTime < TEXT_CLICK_DEBOUNCE_DELAY_MS) {
                    return;
                }
                mLastClickTime = currentTime;

                final View animatedView = view;

                animatedView.animate()
                    .scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            animatedView.animate()
                                .scaleX(ANIMATION_SCALE_NORMAL)
                                .scaleY(ANIMATION_SCALE_NORMAL)
                                .setDuration(ANIMATION_DURATION_MS)
                                .start();
                        }
                    })
                    .start();

                updateLicenseViewer(license);
            }
        });

        return textView;
    }

    /**
     * Creates the license viewer section with a bordered container and
     * side margins.
     *
     * @return The license viewer section layout
     */
    @NonNull
    private LinearLayout createLicenseViewerSection() {
        LinearLayout section = new LinearLayout(mContext);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setGravity(Gravity.CENTER);

        section.addView(createSectionTitle("License"));
        section.addView(createSpacer(dpToPx(SPACING_BASE_DP)));

        LinearLayout outerContainer = new LinearLayout(mContext);
        outerContainer.setOrientation(LinearLayout.VERTICAL);
        outerContainer.setPadding(dpToPx(PADDING_STANDARD_DP), 0,
            dpToPx(PADDING_STANDARD_DP), 0);

        GradientDrawable containerBackground = new GradientDrawable();
        containerBackground.setColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        containerBackground.setCornerRadius(dpToPx(LICENSE_CORNER_RADIUS_DP));

        LinearLayout innerContainer = new LinearLayout(mContext);
        innerContainer.setOrientation(LinearLayout.VERTICAL);
        innerContainer.setBackground(containerBackground);
        innerContainer.setPadding(dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP));
        innerContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        mDynamicLicenseText = new TextView(mContext);
        mDynamicLicenseText.setText(LLAMA_MIT_LICENSE);
        mDynamicLicenseText.setTextSize(12);
        mDynamicLicenseText.setTextColor(Color.parseColor(TEXT_COLOR_MUTED));
        mDynamicLicenseText.setGravity(Gravity.CENTER);
        mDynamicLicenseText.setLineSpacing(4f, 1.2f);

        innerContainer.addView(mDynamicLicenseText);
        outerContainer.addView(innerContainer);
        section.addView(outerContainer);

        return section;
    }

    /**
     * Replaces the license viewer content with the given text, fading the
     * old content out and the new content in.
     *
     * @param newLicenseText The new license text to display
     */
    private void updateLicenseViewer(@NonNull final String newLicenseText) {
        if (mDynamicLicenseText == null) {
            return;
        }

        mDynamicLicenseText.animate()
            .alpha(0f)
            .setDuration(FADE_DURATION_MS)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    mDynamicLicenseText.setText(newLicenseText);
                    mDynamicLicenseText.animate()
                        .alpha(1f)
                        .setDuration(FADE_DURATION_MS)
                        .start();
                }
            })
            .start();
    }

    /**
     * Creates a section title in the light text color.
     *
     * @param titleText The title text
     * @return The styled section title text view
     */
    @NonNull
    private TextView createSectionTitle(String titleText) {
        TextView textView = new TextView(mContext);
        textView.setText(titleText);
        textView.setTextSize(14);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(0, 0, 0, dpToPx(SPACING_BASE_DP));
        return textView;
    }

    /**
     * Creates the bottom padding view.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button The button to animate, or null
     */
    private void addButtonAnimation(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}