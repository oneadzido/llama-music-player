package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * LlamaPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides real-time pitch and tempo shifting using the SoundTouch native library.
 * It follows the same lifecycle pattern as Android's {@link android.media.MediaPlayer} for
 * consistency and predictability. The player is the primary audio engine for Llama Music Player,
 * with NativeMediaPlayer serving as a fallback when SoundTouch fails at runtime.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>AtomicBoolean/AtomicLong/AtomicInteger/AtomicReference</b> for all shared state</li>
 *   <li><b>Object.wait/notify</b> with proper synchronization for thread coordination</li>
 *   <li><b>Handler</b> for UI thread callbacks</li>
 *   <li><b>Sequence IDs</b> for stale callback detection</li>
 *   <li><b>Copy-on-write pattern</b> for immutable state where applicable</li>
 *   <li><b>mAudioTrackLock</b> for protecting AudioTrack operations from concurrent access</li>
 * </ul>
 * 
 * <h3>Audio Pipeline</h3>
 * <pre>
 * Audio File -> AudioDecoder -> PCM Buffer -> SoundTouch -> AudioTrack -> Speakers
 *                                ▼
 *                    DecoderManager (manages decode queue)
 * </pre>
 * 
 * <h3>Volume Control Thread Safety</h3>
 * <p>The volume control methods use AtomicReference to ensure that duck() and unduck()
 * operations are thread-safe even when called from different threads (e.g., audio focus
 * changes from system callbacks vs user-initiated volume changes).</p>
 * 
 * @see DecoderManager
 * @see AudioDecoder
 * @see SoundTouch
 * @see AudioTrack
 * @see NativeMediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class LlamaPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "LlamaPlayer";
    
    /** Broadcast action when a song is prepared (duration and session ID available). */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** 
     * Number of stereo frames per internal buffer (8192 = ~186ms at 44.1kHz stereo).
     * This buffer size provides smooth playback while maintaining responsiveness
     * for seek operations. Each chunk represents approximately 186ms of audio.
     */
    private static final int BUFFER_FRAMES = 8192;
    
    /** 
     * Minimum buffer duration in milliseconds for AudioTrack (500ms).
     * This buffer size provides an optimal balance between seek responsiveness
     * (under 0.5 second delay) and background playback reliability.
     */
    private static final int MIN_BUFFER_MS = 500;
    
    /** 
     * Number of chunks to write to AudioTrack before calling play().
     * With each chunk being ~186ms, 2 chunks provide 372ms of buffered audio
     * before playback begins. This creates a 128ms safety margin that
     * effectively prevents underruns during normal operation.
     */
    private static final int PRIME_CHUNK_COUNT = 2;
    
    /** Interval for position update callbacks to UI (milliseconds). */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Maximum time to wait for thread join during reset/stop (milliseconds). */
    private static final int THREAD_JOIN_TIMEOUT_MS = 500;
    
    /** Time to wait for decoder when not ready (milliseconds) - used with Object.wait. */
    private static final int DECODER_WAIT_MS = 100;
    
    /** Duration in milliseconds that the seek target is reported after a seek operation. */
    private static final int SEEK_WINDOW_MS = 200;
    
    /** Maximum number of retries for decoder read operations. */
    private static final int MAX_DECODER_RETRIES = 3;
    
    /** Delay between decoder retries in milliseconds. */
    private static final int DECODER_RETRY_DELAY_MS = 50;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Represents the current state of the player.
     * 
     * <p>This state machine follows the exact same pattern as
     * {@link android.media.MediaPlayer} to ensure predictable behavior.</p>
     */
    public enum State {
        /** Initial state after creation or reset(). No song loaded. */
        IDLE,
        
        /** Data source has been set via setDataSource(). Ready for prepareAsync(). */
        INITIALIZED,
        
        /** Loading song asynchronously (background thread active). */
        PREPARING,
        
        /** Song loaded and ready to play. Call start() to play. */
        PREPARED,
        
        /** Actively playing audio. Position advancing, call pause() to suspend. */
        STARTED,
        
        /** Playback paused. Call start() to resume from current position. */
        PAUSED,
        
        /** Playback stopped via stop(). Must call prepareAsync() again to play. */
        STOPPED,
        
        /** Song finished normally. Can call seekTo(0) then start() to replay. */
        COMPLETED,
        
        /** An error occurred. Must call reset() to recover. */
        ERROR,
        
        /** Player resources released. Cannot be used again. */
        RELEASED
    }
    
    /**
     * Listener interface for playback events.
     * 
     * <p>All callbacks are delivered on the main UI thread, making it safe
     * to update UI components directly from within callbacks.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         * 
         * @param newState The new state (never null)
         * @param oldState The previous state (may be null on first callback)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the song is prepared and ready for playback.
         * 
         * <p>After this callback, {@link #getDuration()} and
         * {@link #getAudioSessionId()} return valid values.</p>
         */
        void onPrepared();
        
        /**
         * Called when the song completes normally (end of file reached).
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * <p>Use this to update UI seek bars and time displays.
         * Frequency is approximately every 100ms.</p>
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback or preparation.
         * 
         * <p>The player enters ERROR state. Call {@link #reset()} to recover.</p>
         *
         * @param error Human-readable description of the error
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context (used for broadcasts). */
    @NonNull private final Context mContext;
    
    /** Playback event listener (null if not set). */
    @Nullable private volatile PlaybackListener mListener;
    
    /** Current player state (protected by mStateLock). */
    @NonNull private State mState = State.IDLE;
    
    /** Lock object for state transitions (prevents race conditions). */
    private final Object mStateLock = new Object();
    
    /** Decoder manager for audio decoding (main + prefill). */
    @Nullable private DecoderManager mDecoderManager;
    
    /** SoundTouch processor for pitch/tempo shifting. */
    @Nullable private SoundTouch mSoundTouchProcessor;
    
    /** AudioTrack for PCM output. */
    @Nullable private AudioTrack mAudioTrack;
    
    /** Lock for AudioTrack operations (prevents concurrent write/pause/stop). */
    private final Object mAudioTrackLock = new Object();
    
    /** Audio sample rate in Hz (from current audio file). */
    private volatile int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private volatile int mChannels = 2;
    
    /** Audio session ID (for equalizer attachment). */
    private volatile int mAudioSessionId = 0;
    
    /** Total duration of current song in milliseconds. */
    private volatile long mDuration = 0;
    
    /** File path of the currently loaded/loading song. */
    @Nullable private volatile String mCurrentFilePath = null;
    
    /** Flag indicating if audio format has been validated. */
    private volatile boolean mFormatValidated = false;
    
    /** Flag indicating if playback is currently active (atomic for thread safety). */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if playback is paused (atomic for thread safety). */
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    
    /** Flag indicating if end of stream has been reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Current playback position (cached, updated by playback loop). */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Pending seek target (-1 if no seek pending). */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Timestamp of last seek for position reporting. */
    private final AtomicLong mLastSeekTime = new AtomicLong(0);
    
    /** Last seek target for immediate position reporting. */
    private final AtomicInteger mLastSeekTarget = new AtomicInteger(-1);
    
    /** Last decoder seek position for accurate reporting after seek. */
    private final AtomicLong mDecoderSeekPos = new AtomicLong(-1);
    
    /** Current pitch value (preserved across song changes). */
    private volatile float mCurrentPitch = 0f;
    
    /** Current tempo value (preserved across song changes). */
    private volatile float mCurrentTempo = 1.0f;
    
    /** Background playback thread (persists across songs). */
    @Nullable private volatile Thread mPlaybackThread;
    
    /** Flag indicating if playback thread should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Lock object for playback thread synchronization. */
    private final Object mPlaybackLock = new Object();
    
    /** Lock object for decoder synchronization. */
    private final Object mDecoderLock = new Object();
    
    /** Flag indicating if AudioTrack has been primed (prefilled buffer). */
    private final AtomicBoolean mPrimed = new AtomicBoolean(false);
    
    /** Counter for number of chunks written (for priming). */
    private volatile int mPrimeCount = 0;
    
    /** Handler for UI thread operations (callbacks). */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if a state transition is in progress (prevents rapid transitions). */
    private final AtomicBoolean mTransitionInProgress = new AtomicBoolean(false);
    
    /** Flag indicating if a user-initiated seek operation is in progress. */
    private final AtomicBoolean mUserSeekInProgress = new AtomicBoolean(false);
    
    /** Flag indicating if prepare was called while previous prepare was ongoing. */
    private volatile int mPrepareSequence = 0;
    
    /** Flag indicating if seek is in progress (for position reporting). */
    private final AtomicBoolean mSeekInProgress = new AtomicBoolean(false);
    
    /** Number of consecutive decoder read errors. */
    private final AtomicInteger mDecoderErrorCount = new AtomicInteger(0);
    
    // ========================================================================
    // Volume Control for Audio Ducking (Thread-Safe with AtomicReference)
    // ========================================================================
    
    /** Current volume level (1.0 = normal, 0.0 = silent). */
    private final AtomicReference<Float> mCurrentVolume = new AtomicReference<>(1.0f);
    
    /** Normal volume before ducking (for restoration) - AtomicReference for thread safety. */
    private final AtomicReference<Float> mNormalVolume = new AtomicReference<>(1.0f);
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new LlamaPlayer.
     * 
     * <p>The player is initially in {@link State#IDLE}. The playback thread is not
     * started until the first call to {@link #start()}. The same thread is reused
     * for all subsequent songs, eliminating thread creation overhead.</p>
     *
     * @param context Application context (used for broadcasts and audio session)
     * @throws NullPointerException if context is null
     */
    public LlamaPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "LlamaPlayer created (IDLE state)");
    }
    
    // ========================================================================
    // Public API Methods (MediaPlayer-compatible)
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * <p>Listeners receive state change notifications, preparation completion,
     * position updates, and error events. All callbacks are delivered on the
     * main UI thread.</p>
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Sets the data source for the player.
     * 
     * <p>After calling this method, the player enters {@link State#INITIALIZED}.
     * Call {@link #prepareAsync()} to start loading the song.</p>
     * 
     * <p>This method is safe to call even if a previous song was playing -
     * the player will reset automatically.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @throws IllegalStateException if player is in RELEASED state
     * @throws NullPointerException if filePath is null
     * @throws IllegalArgumentException if filePath is empty or file doesn't exist
     */
    public void setDataSource(@NonNull String filePath) {
        if (filePath.isEmpty()) {
            throw new IllegalArgumentException("filePath cannot be empty");
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("setDataSource called on released player");
            }
            
            if (mState != State.IDLE && mState != State.INITIALIZED && 
                mState != State.ERROR && mState != State.STOPPED) {
                Log.w(TAG, "setDataSource called in state " + mState + " - auto-resetting");
                resetInternal(false);
            }
            
            mCurrentFilePath = filePath;
            mState = State.INITIALIZED;
            mIsEOS.set(false);
            mSeekTarget.set(-1);
            mDecoderErrorCount.set(0);
            
            Log.d(TAG, "setDataSource: " + filePath + " (INITIALIZED state)");
        }
    }
    
    /**
     * Prepares the player asynchronously (like MediaPlayer.prepareAsync()).
     * 
     * <p>After this method returns, the state becomes {@link State#PREPARING}.
     * When preparation completes successfully, {@link PlaybackListener#onPrepared()}
     * is called and the state becomes {@link State#PREPARED}.</p>
     * 
     * <p>If preparation fails, {@link PlaybackListener#onError(String)} is called
     * and the state becomes {@link State#ERROR}.</p>
     * 
     * <p>Multiple calls to prepareAsync() are safely ignored - only the first
     * preparation proceeds.</p>
     *
     * @throws IllegalStateException if player is not in INITIALIZED state
     */
    public void prepareAsync() {
        final int currentSequence;
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("prepareAsync called on released player");
            }
            if (mState != State.INITIALIZED && mState != State.STOPPED) {
                throw new IllegalStateException("prepareAsync called in invalid state: " + mState);
            }
            
            currentSequence = ++mPrepareSequence;
            mState = State.PREPARING;
        }
        
        Log.d(TAG, "prepareAsync() - starting background preparation (sequence=" + currentSequence + ")");
        
        new Thread(() -> prepareInternal(currentSequence), "LlamaPlayer-Prepare").start();
    }
    
    /**
     * Internal preparation logic (runs on background thread).
     * 
     * <p>This method initializes the DecoderManager, which opens the audio file
     * and creates the MediaCodec decoder. It then reads a small amount of PCM
     * to determine the actual sample rate and channel count, creates the
     * AudioTrack, and initializes SoundTouch.</p>
     *
     * @param sequence The preparation sequence ID (used to ignore stale callbacks)
     */
    private void prepareInternal(int sequence) {
        if (sequence != mPrepareSequence) {
            Log.d(TAG, "prepareInternal: stale preparation (seq=" + sequence + 
                  ", current=" + mPrepareSequence + ") - aborting");
            return;
        }
        
        try {
            // Clean up previous resources
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            // Release existing decoder manager
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            if (sequence != mPrepareSequence) return;
            
            // Create and initialize decoder manager
            mDecoderManager = new DecoderManager();
            if (!mDecoderManager.initialize(mCurrentFilePath, 0, 0)) {
                transitionToError("Failed to open audio file", sequence);
                return;
            }
            
            // Wait for decoder to actually provide sample rate and channels
            // We need to read a small buffer to get actual format from the decoder output
            int retryCount = 0;
            short[] tempBuffer = new short[BUFFER_FRAMES];
            while (mDecoderManager.getSampleRate() <= 0 && retryCount < 10) {
                int frames = mDecoderManager.read(tempBuffer, BUFFER_FRAMES / 2);
                if (frames > 0) {
                    // Successfully read data, decoder is providing format
                    break;
                }
                try { 
                    Thread.sleep(DECODER_RETRY_DELAY_MS); 
                } catch (InterruptedException e) { 
                    Thread.currentThread().interrupt();
                    break;
                }
                retryCount++;
            }
            
            if (mDecoderManager.getSampleRate() <= 0) {
                transitionToError("Failed to get audio format from decoder", sequence);
                return;
            }
            
            mSampleRate = mDecoderManager.getSampleRate();
            mChannels = mDecoderManager.getChannels();
            
            // Get duration from decoder
            mDuration = mDecoderManager.getDuration();
            
            Log.d(TAG, "prepareInternal: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
            
            // Validate audio format
            if (mSampleRate <= 0 || mSampleRate > 192000 || mChannels < 1 || mChannels > 2) {
                transitionToError("Invalid audio format: " + mSampleRate + "Hz, " + mChannels + "ch", sequence);
                return;
            }
            
            if (sequence != mPrepareSequence) return;
            
            // Initialize SoundTouch for pitch/tempo control
            if (SoundTouch.isLibraryAvailable()) {
                mSoundTouchProcessor = new SoundTouch(mSampleRate, mChannels);
                mSoundTouchProcessor.setPitch(mCurrentPitch);
                mSoundTouchProcessor.setTempo(mCurrentTempo);
                Log.d(TAG, "SoundTouch processor initialized");
            } else {
                Log.w(TAG, "SoundTouch library not available - pitch/tempo disabled");
            }
            
            // Create AudioTrack for PCM output
            createAudioTrack();
            
            synchronized (mAudioTrackLock) {
                if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    transitionToError("AudioTrack creation failed", sequence);
                    return;
                }
                
                // Get audio session ID for equalizer attachment
                mAudioSessionId = mAudioTrack.getAudioSessionId();
            }
            mFormatValidated = true;
            
            // Broadcast that song is prepared (for equalizer and UI)
            broadcastSongPrepared();
            
            if (sequence != mPrepareSequence) {
                Log.d(TAG, "prepareInternal: cancelled after preparation (seq=" + sequence + ")");
                return;
            }
            
            final State oldState;
            synchronized (mStateLock) {
                if (mState == State.RELEASED || mState == State.ERROR) {
                    return;
                }
                oldState = mState;
                mState = State.PREPARED;
            }
            
            Log.d(TAG, "prepareInternal completed (PREPARED state)");
            
            final PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> {
                    listener.onPrepared();
                    listener.onStateChanged(State.PREPARED, oldState);
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "prepareInternal exception", e);
            transitionToError(e.getMessage() != null ? e.getMessage() : "Unknown preparation error", sequence);
        }
    }
    
    /**
     * Starts or resumes playback (like MediaPlayer.start()).
     * 
     * <p>Valid states for calling start():</p>
     * <ul>
     *   <li>{@link State#PREPARED} - starts playback from beginning</li>
     *   <li>{@link State#PAUSED} - resumes playback from current position</li>
     *   <li>{@link State#COMPLETED} - seeks to 0 then starts playback</li>
     * </ul>
     * 
     * <p>Rapid multiple calls to start() are safe - the player ignores
     * calls when already in STARTED state.</p>
     *
     * @throws IllegalStateException if player is in an invalid state
     */
    public void start() {
        if (!mTransitionInProgress.compareAndSet(false, true)) {
            Log.d(TAG, "start() - transition already in progress, skipping");
            return;
        }
        
        try {
            synchronized (mStateLock) {
                if (mState == State.RELEASED) {
                    throw new IllegalStateException("start called on released player");
                }
                
                switch (mState) {
                    case PREPARED:
                        Log.d(TAG, "start() - from PREPARED, starting fresh");
                        startPlaybackThread();
                        transitionState(State.STARTED);
                        break;
                        
                    case PAUSED:
                        Log.d(TAG, "start() - from PAUSED, resuming");
                        resumePlayback();
                        transitionState(State.STARTED);
                        break;
                        
                    case COMPLETED:
                        Log.d(TAG, "start() - from COMPLETED, seeking to 0 then starting");
                        performSeek(0);
                        startPlaybackThread();
                        transitionState(State.STARTED);
                        break;
                        
                    case STARTED:
                        Log.d(TAG, "start() - already STARTED, ignoring");
                        break;
                        
                    default:
                        throw new IllegalStateException("start called in invalid state: " + mState);
                }
            }
        } finally {
            mTransitionInProgress.set(false);
        }
    }
    
    /**
     * Pauses playback (like MediaPlayer.pause()).
     * 
     * <p>This method only works when the player is in {@link State#STARTED}.
     * After pausing, call {@link #start()} to resume from the same position.</p>
     * 
     * <p>Multiple calls to pause() are safe - subsequent calls are ignored.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("pause called on released player");
            }
            
            if (mState != State.STARTED) {
                Log.w(TAG, "pause() called in state: " + mState + " (ignoring)");
                return;
            }
            
            Log.d(TAG, "pause() - pausing playback");
            
            mIsPaused.set(true);
            mIsPlaying.set(false);
            
            synchronized (mAudioTrackLock) {
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.pause();
                    } catch (Exception e) {
                        Log.e(TAG, "pause() - AudioTrack.pause error", e);
                    }
                }
            }
            
            transitionState(State.PAUSED);
            
            final PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.STARTED));
            }
        }
    }
    
    /**
     * Stops playback (like MediaPlayer.stop()).
     * 
     * <p>After calling stop(), the player enters {@link State#STOPPED}.
     * To play another song, you must call {@link #reset()} followed by
     * {@link #setDataSource(String)} and {@link #prepareAsync()}.</p>
     * 
     * <p>Valid states for stop(): PREPARED, STARTED, PAUSED, COMPLETED.</p>
     *
     * @throws IllegalStateException if player is in an invalid state
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("stop called on released player");
            }
            
            if (mState != State.PREPARED && mState != State.STARTED && 
                mState != State.PAUSED && mState != State.COMPLETED) {
                Log.w(TAG, "stop() called in state: " + mState + " (ignoring)");
                return;
            }
            
            Log.d(TAG, "stop() - stopping playback");
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    Log.w(TAG, "stop() - interrupted while waiting for thread");
                }
                mPlaybackThread = null;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            mIsEOS.set(false);
            mPrimed.set(false);
            mPrimeCount = 0;
            mCurrentPosition.set(0);
            mLastSeekTarget.set(-1);
            
            synchronized (mAudioTrackLock) {
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.pause();
                        mAudioTrack.flush();
                    } catch (Exception e) {
                        Log.e(TAG, "stop() - AudioTrack error", e);
                    }
                }
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.seekMainDecoder(0);
            }
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.clear();
            }
            
            transitionState(State.STOPPED);
        }
    }
    
    /**
     * Resets the player to IDLE state (like MediaPlayer.reset()).
     * 
     * <p>After reset(), you must call {@link #setDataSource(String)} and
     * {@link #prepareAsync()} again to play a song. This method is safe to call
     * from any state (except RELEASED) and will cleanly release all resources.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void reset() {
        resetInternal(true);
    }
    
    /**
     * Internal reset implementation.
     * 
     * @param notifyListener Whether to notify the listener of state change
     */
    private void resetInternal(boolean notifyListener) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("reset called on released player");
            }
            
            final State oldState = mState;
            Log.d(TAG, "reset() from state: " + oldState);
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            mIsEOS.set(false);
            mPrimed.set(false);
            mPrimeCount = 0;
            mCurrentPosition.set(0);
            mSeekTarget.set(-1);
            mLastSeekTarget.set(-1);
            mDecoderSeekPos.set(-1);
            mFormatValidated = false;
            mAudioSessionId = 0;
            mDuration = 0;
            mSampleRate = 44100;
            mChannels = 2;
            mCurrentFilePath = null;
            mDecoderErrorCount.set(0);
            
            mPrepareSequence++;
            
            transitionState(State.IDLE);
            
            if (notifyListener) {
                final PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.IDLE, oldState));
                }
            }
            
            Log.d(TAG, "reset() - IDLE state");
        }
    }
    
    /**
     * Seeks to the specified position with optional prefill buffer.
     * 
     * <p><b>IMPORTANT:</b> When prefillBuffer is provided (via DecoderManager),
     * it is written to AudioTrack IMMEDIATELY before flushing. This eliminates
     * the audio gap that would otherwise occur during the seek operation.</p>
     * 
     * <p>Additionally, AudioTrack is flushed to remove stale buffer data that
     * causes rubber-banding. The seek target is reported immediately for UI
     * feedback, and seek flags prevent position revert during stabilization.</p>
     *
     * @param positionMs Target position in milliseconds
     * @param prefillBuffer Pre-filled audio data from DecoderManager (null if not available)
     * @param prefillFrames Number of frames in prefill buffer
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void seekTo(int positionMs, @Nullable short[] prefillBuffer, int prefillFrames) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("seekTo called on released player");
            }
            
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            
            Log.d(TAG, "seekTo: " + positionMs + "ms -> clamped: " + clampedPosition + 
                  "ms, prefill=" + (prefillBuffer != null ? prefillFrames + " frames" : "none"));
            
            // ================================================================
            // STEP 1: Mark seek and update position IMMEDIATELY for UI
            // ================================================================
            mSeekInProgress.set(true);
            mSeekTarget.set((int) clampedPosition);
            
            // Update position immediately for instant UI feedback
            mCurrentPosition.set(clampedPosition);
            mLastSeekTime.set(SystemClock.elapsedRealtime());
            mLastSeekTarget.set((int) clampedPosition);
            
            // Notify listener of immediate position
            final PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onPositionUpdate(clampedPosition));
            }
            
            // ================================================================
            // STEP 2: Write prefill buffer IMMEDIATELY (if provided)
            // This prevents audio gap during seek
            // ================================================================
            if (prefillBuffer != null && prefillFrames > 0) {
                synchronized (mAudioTrackLock) {
                    if (mAudioTrack != null) {
                        try {
                            int sampleCount = prefillFrames * mChannels;
                            byte[] byteBuffer = new byte[sampleCount * 2];
                            for (int i = 0; i < sampleCount; i++) {
                                byteBuffer[i * 2] = (byte) (prefillBuffer[i] & 0xFF);
                                byteBuffer[i * 2 + 1] = (byte) ((prefillBuffer[i] >> 8) & 0xFF);
                            }
                            
                            // Write prefill buffer BEFORE flushing
                            int written = mAudioTrack.write(byteBuffer, 0, byteBuffer.length);
                            Log.d(TAG, "Prefill buffer written: " + written + " bytes (" + prefillFrames + " frames)");
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to write prefill buffer", e);
                        }
                    }
                }
            }
            
            // ================================================================
            // STEP 3: Seek the decoder
            // ================================================================
            if (mDecoderManager != null) {
                mDecoderManager.seekMainDecoder((int) clampedPosition);
                mDecoderSeekPos.set((int) clampedPosition);
                mIsEOS.set(false);
                mDecoderErrorCount.set(0); // Reset error count on successful seek
            }
            
            // ================================================================
            // STEP 4: Clear SoundTouch buffers
            // ================================================================
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.clear();
            }
            
            // ================================================================
            // STEP 5: FLUSH AUDIOTRACK IMMEDIATELY - IMPORTANT
            // This removes stale buffer data that causes rubber-banding
            // ================================================================
            synchronized (mAudioTrackLock) {
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    try {
                        int playState = mAudioTrack.getPlayState();
                        boolean wasPlaying = (playState == AudioTrack.PLAYSTATE_PLAYING);
                        
                        // Pause briefly to allow flush
                        if (wasPlaying) {
                            mAudioTrack.pause();
                        }
                        
                        // FLUSH removes all pending audio from the buffer
                        mAudioTrack.flush();
                        Log.d(TAG, "seekTo: AudioTrack flushed - stale buffer removed");
                        
                        // Resume if it was playing
                        if (wasPlaying) {
                            mAudioTrack.play();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "seekTo: Failed to flush AudioTrack", e);
                    }
                }
            }
            
            // ================================================================
            // STEP 6: Notify playback thread
            // ================================================================
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            // ================================================================
            // STEP 7: Reset seek flags after stabilization window
            // ================================================================
            mUiHandler.postDelayed(() -> {
                mSeekInProgress.set(false);
                mUserSeekInProgress.set(false);
                mSeekTarget.set(-1);
                Log.d(TAG, "seekTo: Seek flags reset");
            }, 250);
            
            // Clear the seek target reporting after UI feedback window expires
            mUiHandler.postDelayed(() -> {
                if (SystemClock.elapsedRealtime() - mLastSeekTime.get() >= SEEK_WINDOW_MS) {
                    mLastSeekTarget.set(-1);
                }
            }, SEEK_WINDOW_MS);
        }
    }
    
    /**
     * Seeks to the specified position (convenience method without prefill).
     *
     * @param positionMs Target position in milliseconds
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void seekTo(int positionMs) {
        seekTo(positionMs, null, 0);
    }
    
    /**
     * Returns the current playback position in milliseconds with seek-priority logic.
     * 
     * <p>During seek operations, returns the seek target for instant UI feedback.
     * After AudioTrack flush, returns correct playback head position.</p>
     *
     * @return Current position in milliseconds (0 if not available)
     */
    public long getCurrentPosition() {
        // Stage 1: Immediately after seek - return seek target for instant UI feedback
        int lastSeekTarget = mLastSeekTarget.get();
        if (lastSeekTarget >= 0) {
            long lastSeekTime = mLastSeekTime.get();
            if (lastSeekTime > 0 && SystemClock.elapsedRealtime() - lastSeekTime < SEEK_WINDOW_MS) {
                return lastSeekTarget;
            } else {
                mLastSeekTarget.set(-1);
            }
        }
        
        // Stage 2: During seek in progress - return the seek target
        if (mSeekInProgress.get()) {
            int seekTarget = mSeekTarget.get();
            if (seekTarget >= 0) {
                return seekTarget;
            }
        }
        
        // Stage 3: Normal operation - AudioTrack position after flush
        synchronized (mAudioTrackLock) {
            if (mAudioTrack != null && mState == State.STARTED && mPrimed.get() && !mIsPaused.get()) {
                try {
                    long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                    if (mSampleRate > 0 && frames > 0) {
                        long positionMs = (frames * 1000) / mSampleRate;
                        if (positionMs < mDuration) {
                            return positionMs;
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
        
        // Fallback to cached position
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds (0 if not available)
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Checks if the player is currently playing audio.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get() && mState == State.STARTED;
    }
    
    /**
     * Checks if the player is prepared (song loaded and ready to play).
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mState == State.PREPARED || mState == State.STARTED || 
               mState == State.PAUSED || mState == State.COMPLETED;
    }
    
    /**
     * Returns the audio session ID for the current AudioTrack.
     * This ID is used by EqualizerManager to attach audio effects.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return Current {@link State} (never null)
     */
    @NonNull
    public State getState() {
        return mState;
    }
    
    /**
     * Returns the current sample rate.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the current channel count.
     *
     * @return Number of channels (1 or 2)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * Recommended range: -6 to +6 semitones.</p>
     * 
     * <p><b>Parameter Change Implementation:</b> This method clears the SoundTouch
     * buffers and resets priming state without flushing the AudioTrack. The new
     * pitch setting takes effect as soon as the existing AudioTrack buffer drains
     * (within 500ms), providing a smooth transition without audio dropouts.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.setPitch(semitones);
            clearBuffersForParameterChange();
            Log.d(TAG, "setPitch: " + semitones + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down, greater than 1.0 speed up.
     * Recommended range: 0.5 to 1.5.</p>
     * 
     * <p><b>Parameter Change Implementation:</b> This method clears the SoundTouch
     * buffers and resets priming state without flushing the AudioTrack. The new
     * tempo setting takes effect as soon as the existing AudioTrack buffer drains
     * (within 500ms), providing a smooth transition without audio dropouts.</p>
     *
     * @param tempo The tempo multiplier (0.5 = half speed, 1.0 = normal, 1.5 = 1.5x speed)
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.setTempo(tempo);
            clearBuffersForParameterChange();
            Log.d(TAG, "setTempo: " + tempo + "x");
        }
    }
    
    // ========================================================================
    // Volume Control Methods for Audio Ducking (Thread-Safe)
    // ========================================================================
    
    /**
     * Sets the volume level for ducking.
     * Range: 0.0 (silent) to 1.0 (full volume).
     * 
     * <p>This method is used primarily for audio ducking when the system
     * requests transient focus loss with ducking (e.g., navigation apps speaking).</p>
     * 
     * <p><b>Thread Safety:</b> Uses AtomicReference for thread-safe volume updates.</p>
     *
     * @param volume Volume level (clamped to 0.0-1.0)
     */
    public void setVolume(float volume) {
        volume = Math.max(0.0f, Math.min(1.0f, volume));
        Float oldVolume = mCurrentVolume.getAndSet(volume);
        
        if (oldVolume != null && Math.abs(oldVolume - volume) < 0.01f) {
            return;
        }
        
        synchronized (mAudioTrackLock) {
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.setVolume(volume);
                    Log.d(TAG, "Volume set to: " + volume);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to set volume", e);
                }
            }
        }
    }
    
    /**
     * Gets the current volume level.
     * Thread-safe: uses AtomicReference.get().
     *
     * @return Current volume (0.0 to 1.0)
     */
    public float getVolume() {
        Float volume = mCurrentVolume.get();
        return volume != null ? volume : 1.0f;
    }
    
    /**
     * Ducks volume (reduces to 30%) for transient audio focus loss.
     * 
     * <p>Used when navigation apps speak, alarms sound, or other transient
     * audio events occur that should not pause music but should lower its
     * volume temporarily. Saves current volume for later restoration.</p>
     * 
     * <p><b>Thread Safety:</b> Uses AtomicReference to store the normal volume
     * before ducking, ensuring thread-safe access across different threads
     * (e.g., audio focus callbacks vs user-initiated operations).</p>
     */
    public void duck() {
        float currentVolume = getVolume();
        mNormalVolume.set(currentVolume);
        setVolume(0.3f);
        Log.d(TAG, "Volume ducked to 30% (was " + currentVolume + ")");
    }
    
    /**
     * Restores volume to normal level after ducking.
     * 
     * <p>Call this when the system regains audio focus after a transient
     * ducking event.</p>
     * 
     * <p><b>Thread Safety:</b> Retrieves the saved normal volume from the
     * AtomicReference and restores it.</p>
     */
    public void unduck() {
        Float normalVolume = mNormalVolume.get();
        float volumeToRestore = (normalVolume != null) ? normalVolume : 1.0f;
        setVolume(volumeToRestore);
        Log.d(TAG, "Volume unducked to " + volumeToRestore);
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Pre-loads a song without starting playback (convenience method).
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully
     */
    public boolean preLoad(@NonNull String filePath) {
        try {
            reset();
            setDataSource(filePath);
            prepareAsync();
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "preLoad failed", e);
            return false;
        }
    }
    
    /**
     * Loads and plays a song (convenience method).
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully
     */
    public boolean loadSong(@NonNull String filePath) {
        try {
            reset();
            setDataSource(filePath);
            prepareAsync();
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "loadSong failed", e);
            return false;
        }
    }
    
    /**
     * Plays the loaded song (convenience method).
     */
    public void play() {
        start();
    }
    
    /**
     * Releases all resources held by the player (like MediaPlayer.release()).
     * 
     * <p>After calling this method, the player enters {@link State#RELEASED}
     * and cannot be used again. Always call release() when the player is
     * no longer needed to prevent memory leaks.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release() - releasing all resources");
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            mState = State.RELEASED;
            
            Log.d(TAG, "release() - RELEASED state");
        }
    }
    
    /**
     * Transitions the player to a new state with thread-safe logging.
     */
    private void transitionState(State newState) {
        final State oldState = mState;
        mState = newState;
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
    }
    
    /**
     * Transitions the player to ERROR state and notifies listener.
     *
     * @param error Human-readable error description
     * @param sequence The preparation sequence ID (to ignore stale errors)
     */
    private void transitionToError(String error, int sequence) {
        if (sequence != mPrepareSequence) {
            Log.d(TAG, "transitionToError: stale error (seq=" + sequence + 
                  ", current=" + mPrepareSequence + ") - ignoring");
            return;
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            Log.e(TAG, "Error: " + error);
            mState = State.ERROR;
        }
        
        mRunning.set(false);
        mIsPlaying.set(false);
        
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        synchronized (mDecoderLock) {
            mDecoderLock.notifyAll();
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, null);
            });
        }
    }
    
    /**
     * Cleans up AudioTrack resources.
     */
    private void cleanupAudioTrack() {
        synchronized (mAudioTrackLock) {
            if (mAudioTrack != null) {
                try {
                    if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                        mAudioTrack.stop();
                    }
                    mAudioTrack.release();
                } catch (Exception e) {
                    Log.e(TAG, "cleanupAudioTrack error", e);
                }
                mAudioTrack = null;
            }
        }
    }
    
    /**
     * Creates and configures the AudioTrack instance.
     * 
     * <p>The buffer size is calculated to provide approximately 500ms of
     * audio, balancing seek responsiveness with background playback reliability.
     * The buffer is sized as max(4x minimum hardware buffer, target buffer size)
     * to ensure compatibility across different devices.</p>
     */
    private void createAudioTrack() {
        cleanupAudioTrack();
        
        int channelConfig = (mChannels == 2) ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize * 4, targetBufferSize);
        
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        synchronized (mAudioTrackLock) {
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        }
        
        int actualBufferMs = (bufferSize * 1000) / (mSampleRate * mChannels * 2);
        Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + "ch, " +
              "minBuffer=" + minBufferSize + ", finalBuffer=" + bufferSize + " bytes (" + actualBufferMs + "ms)");
    }
    
    /**
     * Starts the playback thread (creates new thread if not running).
     * 
     * <p>If the thread is already running, it just resumes playback.
     * The thread persists across multiple songs, eliminating thread
     * creation overhead.</p>
     */
    private void startPlaybackThread() {
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            Log.d(TAG, "startPlaybackThread: thread already running, resuming");
            mIsPlaying.set(true);
            mIsPaused.set(false);
            
            synchronized (mAudioTrackLock) {
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.play();
                    } catch (Exception e) {
                        Log.e(TAG, "startPlaybackThread - AudioTrack.play error", e);
                    }
                }
            }
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            return;
        }
        
        mPrimed.set(false);
        mPrimeCount = 0;
        
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        
        mPlaybackThread = new Thread(this::playbackLoop, "LlamaPlayer-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "startPlaybackThread: new thread created and started");
    }
    
    /**
     * Resumes playback from paused state.
     */
    private void resumePlayback() {
        mIsPaused.set(false);
        mIsPlaying.set(true);
        
        synchronized (mAudioTrackLock) {
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                } catch (Exception e) {
                    Log.e(TAG, "resumePlayback - AudioTrack.play error", e);
                }
            }
        }
        
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onStateChanged(State.STARTED, State.PAUSED));
        }
        
        Log.d(TAG, "resumePlayback() - playback resumed");
    }
    
    /**
     * Performs a seek operation from the playback loop (background thread).
     * 
     * <p>This method is called by the background playback thread when it detects
     * a pending seek request. The actual AudioTrack flush has already been performed
     * in seekTo() on the UI thread, so this method only updates the decoder and
     * SoundTouch state.</p>
     * 
     * <p><b>Note:</b> The AudioTrack flush is NOT repeated here because it would
     * cause a race condition. The flush is done immediately in seekTo() to ensure
     * the UI sees the correct position as soon as possible.</p>
     *
     * @param positionMs Target position in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs + "ms");
        
        // UI already updated in seekTo(), just update internal decoder state
        if (mDecoderManager != null) {
            mDecoderManager.seekMainDecoder(positionMs);
            mIsEOS.set(false);
            mDecoderErrorCount.set(0);
        }
        
        // Clear SoundTouch buffers to prevent audio artifacts
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.clear();
        }
        
        // Store the decoder seek position for any edge-case position queries
        mDecoderSeekPos.set(positionMs);
        
        // Clear the user seek flag - the seek is now fully processed
        mUserSeekInProgress.set(false);
    }
    
    /**
     * Updates the cached current position from AudioTrack's playback head.
     * 
     * <p>This method is called periodically from the playback loop to update
     * the UI with the current playback position.</p>
     */
    private void updateCurrentPosition() {
        if (mUserSeekInProgress.get()) {
            return;
        }
        
        int lastSeekTarget = mLastSeekTarget.get();
        if (lastSeekTarget >= 0) {
            long lastSeekTime = mLastSeekTime.get();
            if (lastSeekTime > 0 && SystemClock.elapsedRealtime() - lastSeekTime < SEEK_WINDOW_MS) {
                return;
            } else {
                mLastSeekTarget.set(-1);
            }
        }
        
        synchronized (mAudioTrackLock) {
            if (mAudioTrack != null && mState == State.STARTED && mPrimed.get()) {
                try {
                    long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                    if (mSampleRate > 0 && frames > 0) {
                        long positionMs = (frames * 1000) / mSampleRate;
                        if (positionMs < mDuration && positionMs > 0) {
                            mCurrentPosition.set(positionMs);
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
    }
    
    /**
     * Broadcasts an intent with song duration and audio session ID.
     * 
     * <p>This broadcast is received by MusicPlayer and EqualizerManager
     * to update the UI and attach the equalizer before playback starts.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "broadcastSongPrepared: dur=" + mDuration + "ms, session=" + mAudioSessionId);
    }
    
    /**
     * Clears audio buffers when pitch or tempo changes.
     * 
     * <p>This method ensures that new pitch/tempo settings take effect quickly
     * without causing audio dropouts. It clears the SoundTouch internal buffers
     * and resets the priming state, but does NOT flush the AudioTrack. The
     * existing AudioTrack buffer continues playing with the old settings, and
     * new audio processed with the new settings will begin playing as the buffer
     * naturally drains (within 500ms).</p>
     */
    private void clearBuffersForParameterChange() {
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.clear();
            Log.d(TAG, "SoundTouch buffers cleared for parameter change");
        }
        
        mPrimed.set(false);
        mPrimeCount = 0;
        
        Log.d(TAG, "Parameter change applied - AudioTrack buffer preserved");
    }
    
    /**
     * Handles decoder read errors with retry logic.
     * 
     * <p>If the decoder encounters consecutive errors, this method will
     * trigger an error state after MAX_DECODER_RETRIES attempts.</p>
     *
     * @return true if error is fatal and playback should stop
     */
    private boolean handleDecoderError() {
        int errors = mDecoderErrorCount.incrementAndGet();
        Log.w(TAG, "Decoder read error, count=" + errors);
        
        if (errors >= MAX_DECODER_RETRIES) {
            Log.e(TAG, "Decoder error threshold reached, stopping playback");
            transitionToError("Decoder read error after " + MAX_DECODER_RETRIES + " attempts", mPrepareSequence);
            return true;
        }
        
        // Small delay before retry
        try {
            Thread.sleep(DECODER_RETRY_DELAY_MS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return true;
        }
        
        return false;
    }
    
    // ========================================================================
    // Playback Loop (Runs on Background Thread)
    // ========================================================================
    
    /**
     * Main playback loop (runs on background thread).
     * 
     * <p>This loop runs continuously while mRunning is true. It handles:
     * <ul>
     *   <li>Reading PCM data from DecoderManager</li>
     *   <li>Processing through SoundTouch (if available)</li>
     *   <li>Writing to AudioTrack with optimal buffering</li>
     *   <li>Priming the AudioTrack before starting playback</li>
     *   <li>Seek requests</li>
     *   <li>Pause/resume handling</li>
     *   <li>End-of-stream detection and completion callbacks</li>
     * </ul>
     * 
     * The thread does NOT exit on song completion - it enters a waiting state
     * until the next play command, eliminating thread creation overhead.
     * 
     * <p>All waiting uses Object.wait() with timeout for proper thread
     * synchronization and immediate interrupt response.</p>
     */
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Playback loop started (thread persists across songs)");
        
        while (mRunning.get() && mState != State.RELEASED) {
            try {
                // Handle pause state
                if (mIsPaused.get() || mState != State.STARTED) {
                    synchronized (mPlaybackLock) {
                        if (mIsPaused.get() || mState != State.STARTED) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                
                // Handle pending seek
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0) {
                    performSeek(seekTarget);
                }
                
                // Check for end of stream
                if (mIsEOS.get() || (mDecoderManager != null && mDecoderManager.isEOS())) {
                    handleCompletion();
                    synchronized (mPlaybackLock) {
                        mPlaybackLock.wait();
                    }
                    continue;
                }
                
                // Wait for decoder to be ready
                if (mDecoderManager == null || !mFormatValidated) {
                    synchronized (mDecoderLock) {
                        if (mDecoderManager == null || !mFormatValidated) {
                            mDecoderLock.wait(DECODER_WAIT_MS);
                            continue;
                        }
                    }
                    continue;
                }
                
                // Read PCM data from decoder
                int framesRead = mDecoderManager.read(inputBuffer, BUFFER_FRAMES);
                if (framesRead < 0) {
                    if (handleDecoderError()) {
                        break;
                    }
                    continue;
                }
                if (framesRead == 0) {
                    Thread.yield();
                    continue;
                }
                
                // Reset decoder error count on successful read
                mDecoderErrorCount.set(0);
                
                // Process through SoundTouch if available
                short[] samplesToWrite = inputBuffer;
                int sampleCount = framesRead * mChannels;
                
                if (mSoundTouchProcessor != null && mSoundTouchProcessor.isInitialized()) {
                    mSoundTouchProcessor.putFrames(inputBuffer, framesRead);
                    int available = mSoundTouchProcessor.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mSoundTouchProcessor.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                
                // Convert short to byte for AudioTrack
                for (int i = 0; i < sampleCount; i++) {
                    byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                    byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                }
                
                // Write to AudioTrack (with synchronization)
                int written = -1;
                synchronized (mAudioTrackLock) {
                    try {
                        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                            written = mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                        } else {
                            Log.w(TAG, "AudioTrack not initialized, skipping write");
                            continue;
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "AudioTrack.write IllegalStateException", e);
                        try {
                            if (mAudioTrack != null) {
                                mAudioTrack.flush();
                            }
                        } catch (Exception ignored) {}
                        continue;
                    } catch (IllegalArgumentException e) {
                        Log.e(TAG, "AudioTrack.write IllegalArgumentException", e);
                        continue;
                    }
                }
                
                if (written < 0) {
                    Log.e(TAG, "AudioTrack.write error: " + written);
                    if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                        Log.w(TAG, "AudioTrack dead, attempting recovery");
                        try {
                            cleanupAudioTrack();
                            createAudioTrack();
                            mPrimed.set(false);
                            mPrimeCount = 0;
                        } catch (Exception ex) {
                            Log.e(TAG, "Failed to recreate AudioTrack", ex);
                        }
                    }
                    continue;
                }
                
                // Prime AudioTrack (write enough data before starting playback)
                if (!mPrimed.get()) {
                    mPrimeCount++;
                    if (mPrimeCount >= PRIME_CHUNK_COUNT) {
                        synchronized (mAudioTrackLock) {
                            if (mAudioTrack != null && mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                                try {
                                    mAudioTrack.play();
                                    mPrimed.set(true);
                                    Log.d(TAG, "AudioTrack primed and playing after " + mPrimeCount + " chunks");
                                } catch (Exception e) {
                                    Log.e(TAG, "Failed to start AudioTrack after priming", e);
                                }
                            }
                        }
                    }
                } else {
                    synchronized (mAudioTrackLock) {
                        if (mAudioTrack != null && mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && 
                            mState == State.STARTED) {
                            try {
                                mAudioTrack.play();
                            } catch (Exception e) {
                                Log.e(TAG, "Re-start AudioTrack failed", e);
                            }
                        }
                    }
                }
                
                // Update position for UI
                updateCurrentPosition();
                
                // Send position updates to listener
                long now = SystemClock.elapsedRealtime();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    final PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "Playback loop interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Playback loop exception", e);
                transitionToError(e.getMessage() != null ? e.getMessage() : "Playback loop error", mPrepareSequence);
                break;
            }
        }
        Log.d(TAG, "Playback loop exited");
    }
    
    /**
     * Handles normal song completion (end of file reached).
     * 
     * <p>When a song completes, the player enters COMPLETED state.
     * The playback thread does NOT exit - it enters a waiting state
     * to handle the next play command, eliminating thread creation overhead.</p>
     */
    private void handleCompletion() {
        Log.d(TAG, "Song completed - entering COMPLETED state (thread continues waiting)");
        
        mIsPlaying.set(false);
        mIsEOS.set(true);
        
        mCurrentPosition.set(0);
        mLastSeekTarget.set(-1);
        
        final State oldState;
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            oldState = mState;
            mState = State.COMPLETED;
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onCompletion();
                listener.onStateChanged(State.COMPLETED, oldState);
                listener.onPositionUpdate(0);
            });
        }
    }
}