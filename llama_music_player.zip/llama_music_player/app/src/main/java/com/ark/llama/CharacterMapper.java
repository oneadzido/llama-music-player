package com.ark.llama;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.File;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Utility class for cleaning and mapping music metadata.
 * 
 * <p>This class provides methods for:
 * <ul>
 *   <li>Extracting ID3 tags from audio files (title, artist, album, genre)</li>
 *   <li>Cleaning strings by removing control characters and HTML entities</li>
 *   <li>Handling placeholder values like "&lt;unknown&gt;"</li>
 *   <li>Caching song metadata in the database</li>
 * </ul>
 * </p>
 * 
 * <p>This is a final utility class with a private constructor following
 * Google's recommendations for utility class design.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All methods are static and thread-safe. Patterns are compiled once
 * and reused for performance.</p>
 * 
 * @see Song
 * @see SongDatabase
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.6
 * @since 1.0
 */
public final class CharacterMapper {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Pattern to match control characters (ASCII 0-31 except tab, newline, carriage return). */
    private static final Pattern CONTROL_CHARS = Pattern.compile("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]");
    
    /** Pattern to collapse multiple spaces into a single space. */
    private static final Pattern MULTIPLE_SPACES = Pattern.compile("\\s+");
    
    /** Array of placeholder values that indicate missing metadata. */
    private static final String[] PLACEHOLDER_VALUES = {"<unknown>", "unknown", "?", "null", ""};
    
    /** Application context reference for database access. */
    @Nullable
    private static Context appContext;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * 
     * <p>This class follows the utility class pattern and is never
     * instantiated. All methods are static.</p>
     */
    private CharacterMapper() {
    }

    // ========================================================================
    // Initialization
    // ========================================================================
    
    /**
     * Initializes the CharacterMapper with application context.
     * 
     * <p>This method is called before using other static methods
     * that require database access.</p>
     *
     * @param context Application context (used to obtain the application context)
     */
    public static void init(@NonNull Context context) {
        appContext = context.getApplicationContext();
    }

    // ========================================================================
    // Song Retrieval Methods
    // ========================================================================
    
    /**
     * Retrieves a Song object from a file path, using cache when available.
     * 
     * <p>This method first checks the database cache. If the song is not cached
     * or has no title, it parses the file directly and caches the result.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Song object with metadata, or null if file cannot be read
     */
    @Nullable
    public static Song getSongFromFile(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return null;
        }
        
        Song cached = SongDatabase.getInstance(appContext).getSong(filePath);
        if (cached != null && !TextUtils.isEmpty(cached.getTitle())) {
            return cached;
        }
        
        SongInfo info = parseSongInfo(filePath);
        if (info == null) {
            return null;
        }
        
        Song song = new Song(info.title, info.artist, info.album, info.genre, filePath, 0, null);
        
        if (!TextUtils.isEmpty(song.getTitle())) {
            SongDatabase.getInstance(appContext).insertSong(song);
        }
        
        return song;
    }

    /**
     * Gets the title of a song from the file.
     * 
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Song title, or empty string if not available
     */
    @NonNull
    public static String getTitle(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "";
        }
        
        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getTitle())) {
            return song.getTitle();
        }
        
        return parseTitleFromFile(filePath);
    }

    /**
     * Gets the artist name of a song from the file.
     * 
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Artist name, or "Unknown Artist" if not available
     */
    @NonNull
    public static String getArtist(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "Unknown Artist";
        }
        
        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getArtist())) {
            return song.getArtist();
        }
        
        String artist = parseArtistFromFile(filePath);
        return TextUtils.isEmpty(artist) ? "Unknown Artist" : artist;
    }

    /**
     * Gets the album name of a song from the file.
     * 
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Album name, or "Unknown Album" if not available
     */
    @NonNull
    public static String getAlbum(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "Unknown Album";
        }
        
        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getAlbum())) {
            return song.getAlbum();
        }
        
        String album = parseAlbumFromFile(filePath);
        return TextUtils.isEmpty(album) ? "Unknown Album" : album;
    }

    /**
     * Gets the genre of a song from the file.
     * 
     * <p>This method reads the genre directly from the file using jaudiotagger,
     * bypassing the database cache. The genre loading phase reads real genres
     * from ID3 tags. The database is updated when a real genre is found.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Genre string, or "Unknown Genre" if not available
     */
    @NonNull
    public static String getGenre(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "Unknown Genre";
        }
        
        String genre = parseGenreFromFile(filePath);
        
        if (genre != null && !"Unknown Genre".equals(genre) && !genre.isEmpty()) {
            SongDatabase db = SongDatabase.getInstance(appContext);
            
            Song existingSong = db.getSong(filePath);
            if (existingSong != null) {
                if (!genre.equals(existingSong.getGenre())) {
                    Song updatedSong = new Song(
                        existingSong.getTitle(),
                        existingSong.getArtist(),
                        existingSong.getAlbum(),
                        genre,
                        existingSong.getPath(),
                        existingSong.getDuration(),
                        existingSong.getUri()
                    );
                    db.insertSong(updatedSong);
                    Log.d("CharacterMapper", "Updated genre in database: " + 
                          existingSong.getTitle() + " -> " + genre);
                }
            }
            
            ArrayList<Song> looseSongs = db.getLooseSongs();
            for (Song loose : looseSongs) {
                if (loose != null && filePath.equals(loose.getPath())) {
                    Song updatedLoose = new Song(
                        loose.getTitle(),
                        loose.getArtist(),
                        loose.getAlbum(),
                        genre,
                        loose.getPath(),
                        loose.getDuration(),
                        null
                    );
                    db.insertLooseSong(updatedLoose);
                    break;
                }
            }
            
            return genre;
        }
        
        return "Unknown Genre";
    }

    // ========================================================================
    // File Parsing Methods
    // ========================================================================
    
    /**
     * Parses the title from a file (calls parseSongInfo).
     *
     * @param filePath Absolute path to the music file
     * @return The parsed title, or empty string if not available
     */
    @NonNull
    private static String parseTitleFromFile(@NonNull String filePath) {
        SongInfo info = parseSongInfo(filePath);
        return (info != null && info.title != null) ? info.title : "";
    }

    /**
     * Parses the artist from a file (calls parseSongInfo).
     *
     * @param filePath Absolute path to the music file
     * @return The parsed artist, or "Unknown Artist" if not available
     */
    @NonNull
    private static String parseArtistFromFile(@NonNull String filePath) {
        SongInfo info = parseSongInfo(filePath);
        return (info != null && info.artist != null) ? info.artist : "Unknown Artist";
    }

    /**
     * Parses the album from a file (calls parseSongInfo).
     *
     * @param filePath Absolute path to the music file
     * @return The parsed album, or "Unknown Album" if not available
     */
    @NonNull
    private static String parseAlbumFromFile(@NonNull String filePath) {
        SongInfo info = parseSongInfo(filePath);
        return (info != null && info.album != null) ? info.album : "Unknown Album";
    }

    /**
     * Parses the genre from a file (calls parseSongInfo).
     *
     * @param filePath Absolute path to the music file
     * @return The parsed genre, or null if not available
     */
    @Nullable
    private static String parseGenreFromFile(@NonNull String filePath) {
        SongInfo info = parseSongInfo(filePath);
        return (info != null && info.genre != null) ? info.genre : null;
    }

    /**
     * Parses song metadata from an audio file.
     * 
     * <p>This method attempts to read ID3 tags using jaudiotagger. If tags
     * are missing or unreadable, it falls back to using the filename
     * (without extension) as the title.</p>
     *
     * @param filePath Absolute path to the music file
     * @return SongInfo containing title, artist, album, and genre, or null if file is invalid
     */
    @Nullable
    static SongInfo parseSongInfo(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        
        SongInfo info = new SongInfo();
        info.title = "";
        info.artist = "Unknown Artist";
        info.album = "Unknown Album";
        info.genre = null;
        
        File file = new File(filePath);
        if (!file.exists() || !file.canRead()) {
            info.title = getFileNameWithoutExtension(file.getName());
            info.genre = "Unknown Genre";
            return info;
        }
        
        try {
            AudioFile audioFile = AudioFileIO.read(file);
            if (audioFile != null) {
                Tag tag = audioFile.getTag();
                if (tag != null) {
                    String title = tag.getFirst(FieldKey.TITLE);
                    if (!TextUtils.isEmpty(title)) info.title = title;
                    
                    String artist = tag.getFirst(FieldKey.ARTIST);
                    if (!TextUtils.isEmpty(artist)) info.artist = artist;
                    
                    String album = tag.getFirst(FieldKey.ALBUM);
                    if (!TextUtils.isEmpty(album)) info.album = album;
                    
                    String genre = tag.getFirst(FieldKey.GENRE);
                    if (!TextUtils.isEmpty(genre)) info.genre = genre;
                }
            }
            
            if (TextUtils.isEmpty(info.title)) {
                info.title = getFileNameWithoutExtension(file.getName());
            }
        } catch (Exception e) {
            info.title = getFileNameWithoutExtension(file.getName());
            Log.w("CharacterMapper", "Failed to parse metadata for: " + filePath, e);
        }
        
        info.title = clean(info.title != null ? info.title : "");
        info.artist = clean(info.artist != null ? info.artist : "Unknown Artist");
        info.album = clean(info.album != null ? info.album : "Unknown Album");
        if (info.genre != null) {
            info.genre = clean(info.genre);
        }
        
        if (isPlaceholder(info.title)) info.title = "";
        if (isPlaceholder(info.artist)) info.artist = null;
        if (isPlaceholder(info.album)) info.album = null;
        if (info.genre != null && isPlaceholder(info.genre)) info.genre = null;
        
        if (TextUtils.isEmpty(info.title)) info.title = "";
        if (TextUtils.isEmpty(info.artist)) info.artist = "Unknown Artist";
        if (TextUtils.isEmpty(info.album)) info.album = "Unknown Album";
        if (TextUtils.isEmpty(info.genre)) info.genre = "Unknown Genre";

        return info;
    }

    /**
     * Extracts the filename without extension.
     * 
     * @param fileName The full filename (may include extension)
     * @return The filename without the last extension
     */
    @NonNull
    private static String getFileNameWithoutExtension(@NonNull String fileName) {
        int dot = fileName.lastIndexOf(".");
        if (dot > 0) {
            return fileName.substring(0, dot);
        }
        return fileName;
    }

    // ========================================================================
    // String Cleaning Methods
    // ========================================================================
    
    /**
     * Checks if a string is a placeholder value (e.g., "unknown", "?").
     * 
     * @param input The string to check (can be null)
     * @return True if the string is a placeholder value
     */
    private static boolean isPlaceholder(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return false;
        String trimmed = input.trim();
        for (String placeholder : PLACEHOLDER_VALUES) {
            if (trimmed.equalsIgnoreCase(placeholder)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cleans a string by removing control characters, zero-width spaces, and normalizing spaces.
     * 
     * <p>This method performs the following operations:
     * <ul>
     *   <li>Decodes HTML entities</li>
     *   <li>Removes control characters (ASCII 0-31)</li>
     *   <li>Removes zero-width spaces (U+200B, U+FEFF)</li>
     *   <li>Replaces non-breaking spaces (U+00A0) with regular spaces</li>
     *   <li>Collapses multiple spaces into a single space</li>
     *   <li>Trims leading/trailing whitespace</li>
     * </ul>
     * </p>
     *
     * @param input The string to clean (can be null)
     * @return Cleaned string, or empty string if input is null
     */
    @NonNull
    private static String clean(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }
        
        try {
            String result = decodeHtmlEntities(input);
            result = CONTROL_CHARS.matcher(result).replaceAll("");
            result = result.replace("\u200B", "")
                          .replace("\uFEFF", "")
                          .replace("\u00A0", " ");
            result = MULTIPLE_SPACES.matcher(result).replaceAll(" ");
            return result.trim();
        } catch (Exception e) {
            Log.w("CharacterMapper", "Error cleaning string", e);
            return input;
        }
    }

    /**
     * Public wrapper for the clean method.
     * 
     * <p>Use this method when cleaning a string for display.</p>
     *
     * @param input The string to clean
     * @return The cleaned string
     */
    @NonNull
    public static String cleanString(@Nullable String input) {
        return clean(input);
    }
    
    /**
     * Minimal cleaning for strings that preserve more characters.
     * 
     * <p>Currently identical to cleanString(), kept as a separate method
     * for future customization.</p>
     *
     * @param input The string to clean
     * @return The cleaned string
     */
    @NonNull
    public static String cleanStringMinimal(@Nullable String input) {
        return clean(input);
    }
    
    /**
     * Cleans music metadata and returns null if it is a placeholder.
     * 
     * <p>This method is useful for ID3 tag fields that may contain
     * placeholder values like "&lt;unknown&gt;".</p>
     *
     * @param input The metadata string to clean
     * @return Cleaned metadata, or null if empty or placeholder
     */
    @Nullable
    public static String cleanMusicMetadata(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return null;
        
        String trimmed = input.trim();
        if (isPlaceholder(trimmed)) return null;
        
        String cleaned = clean(trimmed);
        if (TextUtils.isEmpty(cleaned)) return null;
        if (isPlaceholder(cleaned)) return null;
        
        return cleaned;
    }
    
    /**
     * Formats a string for display with a maximum length, adding ellipsis if truncated.
     * 
     * @param input The string to format
     * @param maxLength Maximum allowed length before truncation
     * @return Formatted string, possibly truncated with "..."
     */
    @NonNull
    public static String formatForDisplay(@Nullable String input, int maxLength) {
        if (TextUtils.isEmpty(input)) return "";
        if (input.length() <= maxLength) return input;
        if (maxLength < 4) return input.substring(0, maxLength);
        return input.substring(0, maxLength - 3) + "...";
    }
    
    /**
     * Formats a filename for display.
     *
     * @param originalName The original filename
     * @return A display-safe filename string
     */
    @NonNull
    public static String displayFileName(@Nullable String originalName) {
        String cleaned = cleanMusicMetadata(originalName);
        return TextUtils.isEmpty(cleaned) ? "Unknown" : cleaned;
    }
    
    /**
     * Cleans a string for use in file paths.
     *
     * @param input The input string
     * @return The cleaned string (or empty string if null)
     */
    @NonNull
    public static String cleanForPath(@Nullable String input) {
        return input != null ? input : "";
    }
    
    /**
     * Cleans and lowercases a string for search operations.
     *
     * @param input The input string
     * @return The cleaned and lowercased string
     */
    @NonNull
    public static String cleanForSearch(@Nullable String input) {
        if (input == null) return "";
        return clean(input).toLowerCase();
    }
    
    /**
     * Decodes common HTML entities in a string.
     * 
     * <p>Handles entities like &amp;amp;, &amp;lt;, &amp;gt;, &amp;quot;, &amp;apos;,
     * and various numeric entities.</p>
     *
     * @param input The string containing HTML entities
     * @return String with HTML entities decoded
     */
    @NonNull
    public static String decodeHtmlEntities(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }
        
        StringBuilder result = new StringBuilder(input);
        
        replaceAll(result, "&amp;", "&");
        replaceAll(result, "&lt;", "<");
        replaceAll(result, "&gt;", ">");
        replaceAll(result, "&quot;", "\"");
        replaceAll(result, "&apos;", "'");
        replaceAll(result, "&#39;", "'");
        replaceAll(result, "&#34;", "\"");
        replaceAll(result, "&#38;", "&");
        replaceAll(result, "&#60;", "<");
        replaceAll(result, "&#62;", ">");
        replaceAll(result, "&nbsp;", " ");
        replaceAll(result, "&#160;", " ");
        replaceAll(result, "&ndash;", "\u2013");
        replaceAll(result, "&mdash;", "\u2014");
        replaceAll(result, "&lsquo;", "'");
        replaceAll(result, "&rsquo;", "'");
        replaceAll(result, "&ldquo;", "\"");
        replaceAll(result, "&rdquo;", "\"");
        replaceAll(result, "&hellip;", "\u2026");
        replaceAll(result, "&#8230;", "\u2026");
        
        return result.toString();
    }
    
    /**
     * Helper method to replace all occurrences in a StringBuilder.
     * More efficient than String.replace() for multiple replacements.
     *
     * @param sb The StringBuilder to modify
     * @param target The target string to replace
     * @param replacement The replacement string
     */
    private static void replaceAll(StringBuilder sb, String target, String replacement) {
        int index = sb.indexOf(target);
        while (index != -1) {
            sb.replace(index, index + target.length(), replacement);
            index = sb.indexOf(target, index + replacement.length());
        }
    }
    
    /**
     * Checks if a string contains non-ASCII characters.
     * 
     * <p>Any character outside the ASCII range (0-127) is considered problematic.</p>
     *
     * @param input The string to check
     * @return True if non-ASCII characters are found
     */
    public static boolean hasProblematicCharacters(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return false;
        
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c > 127) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Checks if a song's metadata is already cached in the database.
     *
     * @param filePath The path of the song file
     * @return True if the song is in the database cache
     */
    public static boolean isCached(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) return false;
        return SongDatabase.getInstance(appContext).hasSong(filePath);
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Internal data class for parsed song information.
     * 
     * <p>This class is used internally to hold temporary parsing results
     * before creating a Song object.</p>
     */
    static class SongInfo {
        /** The song title (can be null). */
        @Nullable
        String title;
        
        /** The song artist (can be null). */
        @Nullable
        String artist;
        
        /** The song album (can be null). */
        @Nullable
        String album;
        
        /** The song genre (can be null). */
        @Nullable
        String genre;
        
        /**
         * Returns a string representation for debugging.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "SongInfo{" +
                    "title='" + title + '\'' +
                    ", artist='" + artist + '\'' +
                    ", album='" + album + '\'' +
                    ", genre='" + genre + '\'' +
                    '}';
        }
    }
}