package com.ark.llama;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.File;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Provides static utilities for extracting, cleaning, and canonicalizing
 * music metadata.
 *
 * <p>Reads ID3 tags from audio files, cleans strings by removing control
 * characters and decoding HTML entities, replaces placeholder values such
 * as {@code "<unknown>"} with canonical constants, and caches the parsed
 * result in the song database.</p>
 *
 * <h3>Result Contract</h3>
 * <p>Every parse produces a {@link ParseResult} whose {@link
 * ParseResult#status} is the exhaustive answer to "what happened".
 * Callers branch on the status, not on the presence or emptiness of any
 * field. The {@link #UNKNOWN_GENRE}, {@link #UNKNOWN_ARTIST}, and
 * {@link #UNKNOWN_ALBUM} constants are the canonical placeholder values;
 * a caller that needs to know whether a value came from an actual tag
 * compares against them.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. Compiled patterns are immutable
 * and reused across calls.</p>
 *
 * @see Song
 * @see SongDatabase
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class CharacterMapper {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "CharacterMapper";

    /** Canonical placeholder for a missing artist. */
    public static final String UNKNOWN_ARTIST = "Unknown Artist";

    /** Canonical placeholder for a missing album. */
    public static final String UNKNOWN_ALBUM = "Unknown Album";

    /** Canonical placeholder for a missing genre. */
    public static final String UNKNOWN_GENRE = "Unknown Genre";

    /** Pattern matching control characters (ASCII 0-31 except tab, newline, carriage return). */
    private static final Pattern CONTROL_CHARS = Pattern.compile("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]");

    /** Pattern collapsing runs of whitespace into a single space. */
    private static final Pattern MULTIPLE_SPACES = Pattern.compile("\\s+");

    /** Placeholder values that indicate missing metadata. */
    private static final String[] PLACEHOLDER_VALUES = {"<unknown>", "unknown", "?", "null", ""};

    /** Application context used for database access. */
    @Nullable
    private static Context appContext;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private CharacterMapper() {
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Stores the application context used by methods that access the
     * song database.
     *
     * <p>Call before using any method that requires database access.</p>
     *
     * @param context A context; the application context is retained
     */
    public static void init(@NonNull Context context) {
        appContext = context.getApplicationContext();
    }

    // ========================================================================
    // ParseResult - Typed Outcome of a File Parse
    // ========================================================================

    /**
     * Immutable result of parsing a file's metadata.
     *
     * <p>All string fields are non-null. A field whose tag was absent
     * carries the canonical placeholder for its kind — {@link
     * #UNKNOWN_ARTIST} for the artist, {@link #UNKNOWN_ALBUM} for the
     * album, {@link #UNKNOWN_GENRE} for the genre — except the title,
     * which always carries at least the filename-derived value.</p>
     *
     * <p>The {@link #status} field distinguishes the three outcomes the
     * parser produces. Callers that need to know whether a value came
     * from an actual tag compare against the constants; callers that
     * only display the value use the fields directly.</p>
     */
    public static final class ParseResult {

        /** Exhaustive outcomes of a file parse. */
        public enum Status {
            /** The file was read and jaudiotagger extracted whatever tags it found. */
            PARSED,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        /** The outcome of the parse. */
        @NonNull
        public final Status status;

        /** The song title; falls back to the filename without extension. */
        @NonNull
        public final String title;

        /** The artist; falls back to {@link #UNKNOWN_ARTIST}. */
        @NonNull
        public final String artist;

        /** The album; falls back to {@link #UNKNOWN_ALBUM}. */
        @NonNull
        public final String album;

        /** The genre; falls back to {@link #UNKNOWN_GENRE}. */
        @NonNull
        public final String genre;

        private ParseResult(@NonNull final Status status,
                            @NonNull final String title,
                            @NonNull final String artist,
                            @NonNull final String album,
                            @NonNull final String genre) {
            this.status = status;
            this.title = title;
            this.artist = artist;
            this.album = album;
            this.genre = genre;
        }

        /**
         * Returns whether the file was read successfully.
         *
         * @return True if {@link #status} is {@link Status#PARSED}
         */
        public boolean isParsed() {
            return status == Status.PARSED;
        }

        /**
         * Returns whether the genre came from an actual tag.
         *
         * @return True if the genre is not {@link #UNKNOWN_GENRE}
         */
        public boolean hasRealGenre() {
            return !UNKNOWN_GENRE.equals(genre);
        }

        /**
         * Returns whether the artist came from an actual tag.
         *
         * @return True if the artist is not {@link #UNKNOWN_ARTIST}
         */
        public boolean hasRealArtist() {
            return !UNKNOWN_ARTIST.equals(artist);
        }

        /**
         * Returns whether the album came from an actual tag.
         *
         * @return True if the album is not {@link #UNKNOWN_ALBUM}
         */
        public boolean hasRealAlbum() {
            return !UNKNOWN_ALBUM.equals(album);
        }
    }

    // ========================================================================
    // Song Retrieval Methods
    // ========================================================================

    /**
     * Returns the song for the given file path, using the database cache
     * when a cached entry with a usable title is present.
     *
     * <p>When no cached entry is usable, the file is parsed and the
     * result is inserted into the database if the parse succeeded.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The song, or null if the file cannot be read
     */
    @Nullable
    public static Song getSongFromFile(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return null;
        }

        Song cachedSong = SongDatabase.getInstance(appContext).getSong(filePath);
        if (cachedSong != null && !TextUtils.isEmpty(cachedSong.getTitle())
                && !"Unknown Title".equals(cachedSong.getTitle())) {
            return cachedSong;
        }

        ParseResult result = parseSongInfo(filePath);
        if (result.status != ParseResult.Status.PARSED) {
            return null;
        }

        Song song = new Song(result.title, result.artist, result.album, result.genre,
            filePath, 0, null);
        SongDatabase.getInstance(appContext).insertSong(song);
        return song;
    }

    /**
     * Returns the title of the song at the given file path.
     *
     * <p>Consults the database cache first and parses the file when the
     * cache does not hold a title.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The song title, or an empty string when unavailable
     */
    @NonNull
    public static String getTitle(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "";
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getTitle())) {
            return song.getTitle();
        }

        return parseSongInfo(filePath).title;
    }

    /**
     * Returns the artist of the song at the given file path.
     *
     * <p>Consults the database cache first and parses the file when the
     * cache does not hold an artist.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The artist name, or {@link #UNKNOWN_ARTIST} when unavailable
     */
    @NonNull
    public static String getArtist(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_ARTIST;
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getArtist())) {
            return song.getArtist();
        }

        return parseSongInfo(filePath).artist;
    }

    /**
     * Returns the album of the song at the given file path.
     *
     * <p>Consults the database cache first and parses the file when the
     * cache does not hold an album.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The album name, or {@link #UNKNOWN_ALBUM} when unavailable
     */
    @NonNull
    public static String getAlbum(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_ALBUM;
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getAlbum())) {
            return song.getAlbum();
        }

        return parseSongInfo(filePath).album;
    }

    /**
     * Returns the genre of the song at the given file path.
     *
     * <p>Reads the genre tag directly from the file, updates the database
     * entry for the song when the tag value differs from the cached
     * value, and returns the tag value. Returns {@link #UNKNOWN_GENRE}
     * when the tag is absent or carries a placeholder value.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The genre, or {@link #UNKNOWN_GENRE} when unavailable
     */
    @NonNull
    public static String getGenre(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_GENRE;
        }

        ParseResult result = parseSongInfo(filePath);
        if (!result.hasRealGenre()) {
            return UNKNOWN_GENRE;
        }

        String genre = result.genre;
        SongDatabase database = SongDatabase.getInstance(appContext);

        Song existingSong = database.getSong(filePath);
        if (existingSong != null && !genre.equals(existingSong.getGenre())) {
            Song updatedSong = new Song(
                existingSong.getTitle(),
                existingSong.getArtist(),
                existingSong.getAlbum(),
                genre,
                existingSong.getPath(),
                existingSong.getDuration(),
                existingSong.getUri());
            database.insertSong(updatedSong);
            Log.d(TAG, "Updated genre in database: "
                + existingSong.getTitle() + " -> " + genre);
        }

        ArrayList<Song> looseSongs = database.getLooseSongs();
        for (Song looseSong : looseSongs) {
            if (looseSong != null && filePath.equals(looseSong.getPath())) {
                Song updatedLooseSong = new Song(
                    looseSong.getTitle(),
                    looseSong.getArtist(),
                    looseSong.getAlbum(),
                    genre,
                    looseSong.getPath(),
                    looseSong.getDuration(),
                    null);
                database.insertLooseSong(updatedLooseSong);
                break;
            }
        }

        return genre;
    }

    // ========================================================================
    // File Parsing
    // ========================================================================

    /**
     * Parses the metadata of the audio file at the given path.
     *
     * <p>Reads ID3 tags with jaudiotagger. When a tag is missing,
     * unreadable, or the file cannot be opened, the title falls back to
     * the filename without extension and the other fields fall back to
     * their canonical placeholders. {@link ParseResult#status} records
     * which outcome occurred.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The parsed metadata and the outcome of the parse
     */
    @NonNull
    static ParseResult parseSongInfo(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return new ParseResult(
                ParseResult.Status.FILE_UNREADABLE,
                "", UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        File file = new File(filePath);
        if (!file.exists() || !file.canRead()) {
            String fallbackTitle = getFileNameWithoutExtension(file.getName());
            return new ParseResult(
                ParseResult.Status.FILE_UNREADABLE,
                clean(fallbackTitle), UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        String rawTitle = null;
        String rawArtist = null;
        String rawAlbum = null;
        String rawGenre = null;

        try {
            AudioFile audioFile = AudioFileIO.read(file);
            if (audioFile != null) {
                Tag tag = audioFile.getTag();
                if (tag != null) {
                    rawTitle = tag.getFirst(FieldKey.TITLE);
                    rawArtist = tag.getFirst(FieldKey.ARTIST);
                    rawAlbum = tag.getFirst(FieldKey.ALBUM);
                    rawGenre = tag.getFirst(FieldKey.GENRE);
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "Failed to parse metadata for: " + filePath, exception);
            String fallbackTitle = getFileNameWithoutExtension(file.getName());
            return new ParseResult(
                ParseResult.Status.PARSE_FAILED,
                clean(fallbackTitle), UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        String title = canonicalizeTitle(rawTitle, file);
        String artist = canonicalizeArtist(rawArtist);
        String album = canonicalizeAlbum(rawAlbum);
        String genre = canonicalizeGenre(rawGenre);

        return new ParseResult(
            ParseResult.Status.PARSED, title, artist, album, genre);
    }

    /**
     * Returns the canonical title derived from a raw tag value and file.
     *
     * <p>Falls back to the filename without extension when the tag is
     * absent or a placeholder, and to {@code "Unknown Title"} when the
     * filename yields an empty cleaned string.</p>
     *
     * @param rawTitle The raw title tag value, or null when absent
     * @param file The file the title was read from
     * @return The canonical title; never null and never empty
     */
    @NonNull
    private static String canonicalizeTitle(@Nullable String rawTitle, @NonNull File file) {
        String cleaned = cleanMusicMetadata(rawTitle);
        if (cleaned != null) {
            return cleaned;
        }
        String fallbackTitle = getFileNameWithoutExtension(file.getName());
        cleaned = clean(fallbackTitle);
        return TextUtils.isEmpty(cleaned) ? "Unknown Title" : cleaned;
    }

    /**
     * Returns the canonical artist derived from a raw tag value.
     *
     * <p>Falls back to {@link #UNKNOWN_ARTIST} when the tag is absent or
     * a placeholder.</p>
     *
     * @param rawArtist The raw artist tag value, or null when absent
     * @return The canonical artist; never null
     */
    @NonNull
    private static String canonicalizeArtist(@Nullable String rawArtist) {
        String cleaned = cleanMusicMetadata(rawArtist);
        return cleaned != null ? cleaned : UNKNOWN_ARTIST;
    }

    /**
     * Returns the canonical album derived from a raw tag value.
     *
     * <p>Falls back to {@link #UNKNOWN_ALBUM} when the tag is absent or a
     * placeholder.</p>
     *
     * @param rawAlbum The raw album tag value, or null when absent
     * @return The canonical album; never null
     */
    @NonNull
    private static String canonicalizeAlbum(@Nullable String rawAlbum) {
        String cleaned = cleanMusicMetadata(rawAlbum);
        return cleaned != null ? cleaned : UNKNOWN_ALBUM;
    }

    /**
     * Returns the canonical genre derived from a raw tag value.
     *
     * <p>Falls back to {@link #UNKNOWN_GENRE} when the tag is absent or a
     * placeholder.</p>
     *
     * @param rawGenre The raw genre tag value, or null when absent
     * @return The canonical genre; never null
     */
    @NonNull
    private static String canonicalizeGenre(@Nullable String rawGenre) {
        String cleaned = cleanMusicMetadata(rawGenre);
        return cleaned != null ? cleaned : UNKNOWN_GENRE;
    }

    /**
     * Returns the given filename with its last extension removed.
     *
     * @param fileName The full filename, with or without extension
     * @return The filename without the last extension
     */
    @NonNull
    private static String getFileNameWithoutExtension(@NonNull String fileName) {
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(0, dotIndex);
        }
        return fileName;
    }

    // ========================================================================
    // String Cleaning Methods
    // ========================================================================

    /**
     * Returns whether the given string is a placeholder value such as
     * {@code "unknown"} or {@code "?"}.
     *
     * @param input The string to check, or null
     * @return True if the string is a placeholder value
     */
    private static boolean isPlaceholder(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return false;
        }
        String trimmed = input.trim();
        for (String placeholder : PLACEHOLDER_VALUES) {
            if (trimmed.equalsIgnoreCase(placeholder)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the input with control characters, zero-width spaces, and
     * HTML entities removed and internal whitespace collapsed.
     *
     * @param input The string to clean, or null
     * @return The cleaned string, or an empty string when input is null
     */
    @NonNull
    private static String clean(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }

        try {
            String result = decodeHtmlEntities(input);
            result = CONTROL_CHARS.matcher(result).replaceAll("");
            result = result.replace("\u200B", "")
                          .replace("\uFEFF", "")
                          .replace("\u00A0", " ");
            result = MULTIPLE_SPACES.matcher(result).replaceAll(" ");
            return result.trim();
        } catch (Exception exception) {
            Log.w(TAG, "Error cleaning string", exception);
            return input;
        }
    }

    /**
     * Returns the input with control characters, zero-width spaces, and
     * HTML entities removed and internal whitespace collapsed.
     *
     * @param input The string to clean, or null
     * @return The cleaned string; never null
     */
    @NonNull
    public static String cleanString(@Nullable String input) {
        return clean(input);
    }

    /**
     * Returns the input cleaned, or null when the input is empty or a
     * placeholder value.
     *
     * @param input The metadata string to clean, or null
     * @return The cleaned value, or null when empty or a placeholder
     */
    @Nullable
    public static String cleanMusicMetadata(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return null;
        }

        String trimmed = input.trim();
        if (isPlaceholder(trimmed)) {
            return null;
        }

        String cleaned = clean(trimmed);
        if (TextUtils.isEmpty(cleaned)) {
            return null;
        }
        if (isPlaceholder(cleaned)) {
            return null;
        }

        return cleaned;
    }

    /**
     * Returns the input truncated to the given length with an ellipsis
     * appended when truncation occurs.
     *
     * @param input The string to format, or null
     * @param maxLength Maximum length before truncation
     * @return The formatted string; never null
     */
    @NonNull
    public static String formatForDisplay(@Nullable String input, int maxLength) {
        if (TextUtils.isEmpty(input)) {
            return "";
        }
        if (input.length() <= maxLength) {
            return input;
        }
        if (maxLength < 4) {
            return input.substring(0, maxLength);
        }
        return input.substring(0, maxLength - 3) + "...";
    }

    /**
     * Returns a display-safe filename derived from the given name.
     *
     * @param originalName The original filename, or null
     * @return The display-safe filename, or {@code "Unknown"} when the
     *         name cannot be cleaned
     */
    @NonNull
    public static String displayFileName(@Nullable String originalName) {
        String cleaned = cleanMusicMetadata(originalName);
        return TextUtils.isEmpty(cleaned) ? "Unknown" : cleaned;
    }

    /**
     * Returns the input suitable for use in file paths.
     *
     * @param input The input string, or null
     * @return The input, or an empty string when null
     */
    @NonNull
    public static String cleanForPath(@Nullable String input) {
        return input != null ? input : "";
    }

    /**
     * Returns the input cleaned and lowercased for search comparisons.
     *
     * @param input The input string, or null
     * @return The cleaned and lowercased string; never null
     */
    @NonNull
    public static String cleanForSearch(@Nullable String input) {
        if (input == null) {
            return "";
        }
        return clean(input).toLowerCase();
    }

    /**
     * Returns the input with common HTML entities decoded.
     *
     * @param input The string containing HTML entities, or null
     * @return The decoded string; never null
     */
    @NonNull
    public static String decodeHtmlEntities(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }

        StringBuilder result = new StringBuilder(input);

        replaceAll(result, "&amp;", "&");
        replaceAll(result, "&lt;", "<");
        replaceAll(result, "&gt;", ">");
        replaceAll(result, "&quot;", "\"");
        replaceAll(result, "&apos;", "'");
        replaceAll(result, "&#39;", "'");
        replaceAll(result, "&#34;", "\"");
        replaceAll(result, "&#38;", "&");
        replaceAll(result, "&#60;", "<");
        replaceAll(result, "&#62;", ">");
        replaceAll(result, "&nbsp;", " ");
        replaceAll(result, "&#160;", " ");
        replaceAll(result, "&ndash;", "\u2013");
        replaceAll(result, "&mdash;", "\u2014");
        replaceAll(result, "&lsquo;", "'");
        replaceAll(result, "&rsquo;", "'");
        replaceAll(result, "&ldquo;", "\"");
        replaceAll(result, "&rdquo;", "\"");
        replaceAll(result, "&hellip;", "\u2026");
        replaceAll(result, "&#8230;", "\u2026");

        return result.toString();
    }

    /**
     * Replaces every occurrence of {@code target} in {@code builder} with
     * {@code replacement}.
     *
     * @param builder The builder to modify
     * @param target The string to replace
     * @param replacement The replacement string
     */
    private static void replaceAll(@NonNull StringBuilder builder,
                                   @NonNull String target,
                                   @NonNull String replacement) {
        int index = builder.indexOf(target);
        while (index != -1) {
            builder.replace(index, index + target.length(), replacement);
            index = builder.indexOf(target, index + replacement.length());
        }
    }

    /**
     * Returns whether the input contains any non-ASCII character.
     *
     * @param input The string to check, or null
     * @return True if a non-ASCII character is present
     */
    public static boolean hasProblematicCharacters(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return false;
        }

        for (int index = 0; index < input.length(); index++) {
            char character = input.charAt(index);
            if (character > 127) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns whether the song at the given file path is present in the
     * database cache.
     *
     * @param filePath The path of the song file
     * @return True if the song is in the database cache
     */
    public static boolean isCached(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return false;
        }
        return SongDatabase.getInstance(appContext).hasSong(filePath);
    }
}