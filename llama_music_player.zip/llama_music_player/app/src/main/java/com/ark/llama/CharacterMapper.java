package com.ark.llama;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.File;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Utility class for cleaning and mapping music metadata.
 *
 * <p>This class provides methods for:
 * <ul>
 *   <li>Extracting ID3 tags from audio files (title, artist, album, genre)</li>
 *   <li>Cleaning strings by removing control characters and HTML entities</li>
 *   <li>Handling placeholder values like "&lt;unknown&gt;"</li>
 *   <li>Caching song metadata in the database</li>
 * </ul>
 * </p>
 *
 * <p>This is a final utility class with a private constructor following
 * Google's recommendations for utility class design.</p>
 *
 * <h3>Parse Result Contract</h3>
 * <p>Parsing a file produces a {@link ParseResult} whose fields are all
 * non-null and whose {@link ParseResult#status} distinguishes the three
 * outcomes the code can produce. Callers branch on the status, not on the
 * presence or emptiness of any field. The {@link ParseResult#UNKNOWN_GENRE},
 * {@link ParseResult#UNKNOWN_ARTIST}, and {@link ParseResult#UNKNOWN_ALBUM}
 * constants are the canonical placeholder values; a caller that wants to
 * know whether the value came from an actual tag compares against them.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods are static and thread-safe. Patterns are compiled once
 * and reused for performance.</p>
 *
 * @see Song
 * @see SongDatabase
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class CharacterMapper {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Canonical placeholder for a missing artist. */
    public static final String UNKNOWN_ARTIST = "Unknown Artist";

    /** Canonical placeholder for a missing album. */
    public static final String UNKNOWN_ALBUM = "Unknown Album";

    /** Canonical placeholder for a missing genre. */
    public static final String UNKNOWN_GENRE = "Unknown Genre";

    /** Pattern to match control characters (ASCII 0-31 except tab, newline, carriage return). */
    private static final Pattern CONTROL_CHARS = Pattern.compile("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]");

    /** Pattern to collapse multiple spaces into a single space. */
    private static final Pattern MULTIPLE_SPACES = Pattern.compile("\\s+");

    /** Array of placeholder values that indicate missing metadata. */
    private static final String[] PLACEHOLDER_VALUES = {"<unknown>", "unknown", "?", "null", ""};

    /** Application context reference for database access. */
    @Nullable
    private static Context appContext;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Private constructor to prevent instantiation.
     *
     * <p>This class follows the utility class pattern and is never
     * instantiated. All methods are static.</p>
     */
    private CharacterMapper() {
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initializes the CharacterMapper with application context.
     *
     * <p>This method is called before using other static methods
     * that require database access.</p>
     *
     * @param context Application context (used to obtain the application context)
     */
    public static void init(@NonNull Context context) {
        appContext = context.getApplicationContext();
    }

    // ========================================================================
    // ParseResult - Typed Outcome of a File Parse
    // ========================================================================

    /**
     * Immutable result of parsing a file's metadata.
     *
     * <p>All string fields are non-null. Fields for which no tag was
     * present carry the canonical placeholder for their kind — {@link
     * #UNKNOWN_ARTIST} for the artist, {@link #UNKNOWN_ALBUM} for the
     * album, {@link #UNKNOWN_GENRE} for the genre — or the filename-derived
     * title for the title, which is always populated.</p>
     *
     * <p>The {@link #status} field distinguishes the three outcomes the
     * parser produces. Callers that need to know whether a value came from
     * an actual tag compare against the constants; callers that just want
     * to display the value use the fields directly.</p>
     */
    public static final class ParseResult {

        /** Exhaustive outcomes of a file parse. */
        public enum Status {
            /** The file was read and jaudiotagger extracted whatever tags it found. */
            PARSED,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        /** The outcome of the parse. */
        @NonNull public final Status status;

        /** The song title. Never null; falls back to the filename without extension. */
        @NonNull public final String title;

        /** The artist. Never null; falls back to {@link #UNKNOWN_ARTIST}. */
        @NonNull public final String artist;

        /** The album. Never null; falls back to {@link #UNKNOWN_ALBUM}. */
        @NonNull public final String album;

        /** The genre. Never null; falls back to {@link #UNKNOWN_GENRE}. */
        @NonNull public final String genre;

        private ParseResult(@NonNull final Status status,
                            @NonNull final String title,
                            @NonNull final String artist,
                            @NonNull final String album,
                            @NonNull final String genre) {
            this.status = status;
            this.title = title;
            this.artist = artist;
            this.album = album;
            this.genre = genre;
        }

        /**
         * True when the file was read successfully.
         *
         * @return true if status is {@link Status#PARSED}
         */
        public boolean isParsed() {
            return status == Status.PARSED;
        }

        /**
         * True when the genre came from an actual tag.
         *
         * @return true if the genre is not {@link #UNKNOWN_GENRE}
         */
        public boolean hasRealGenre() {
            return !UNKNOWN_GENRE.equals(genre);
        }

        /**
         * True when the artist came from an actual tag.
         *
         * @return true if the artist is not {@link #UNKNOWN_ARTIST}
         */
        public boolean hasRealArtist() {
            return !UNKNOWN_ARTIST.equals(artist);
        }

        /**
         * True when the album came from an actual tag.
         *
         * @return true if the album is not {@link #UNKNOWN_ALBUM}
         */
        public boolean hasRealAlbum() {
            return !UNKNOWN_ALBUM.equals(album);
        }
    }

    // ========================================================================
    // Song Retrieval Methods
    // ========================================================================

    /**
     * Retrieves a Song object from a file path, using cache when available.
     *
     * <p>This method first checks the database cache. If the song is not
     * cached or has no title, it parses the file directly and caches the
     * result if the parse succeeded.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Song object with metadata, or null if file cannot be read
     */
    @Nullable
    public static Song getSongFromFile(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return null;
        }

        Song cachedSong = SongDatabase.getInstance(appContext).getSong(filePath);
        if (cachedSong != null && !TextUtils.isEmpty(cachedSong.getTitle())
                && !"Unknown Title".equals(cachedSong.getTitle())) {
            return cachedSong;
        }

        ParseResult result = parseSongInfo(filePath);
        if (result.status != ParseResult.Status.PARSED) {
            return null;
        }

        Song song = new Song(result.title, result.artist, result.album, result.genre, filePath, 0, null);
        SongDatabase.getInstance(appContext).insertSong(song);
        return song;
    }

    /**
     * Gets the title of a song from the file.
     *
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Song title, or empty string if not available
     */
    @NonNull
    public static String getTitle(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return "";
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getTitle())) {
            return song.getTitle();
        }

        return parseSongInfo(filePath).title;
    }

    /**
     * Gets the artist name of a song from the file.
     *
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Artist name, or {@link #UNKNOWN_ARTIST} if not available
     */
    @NonNull
    public static String getArtist(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_ARTIST;
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getArtist())) {
            return song.getArtist();
        }

        return parseSongInfo(filePath).artist;
    }

    /**
     * Gets the album name of a song from the file.
     *
     * <p>Checks the database cache first, then falls back to parsing the file.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Album name, or {@link #UNKNOWN_ALBUM} if not available
     */
    @NonNull
    public static String getAlbum(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_ALBUM;
        }

        Song song = SongDatabase.getInstance(appContext).getSong(filePath);
        if (song != null && !TextUtils.isEmpty(song.getAlbum())) {
            return song.getAlbum();
        }

        return parseSongInfo(filePath).album;
    }

    /**
     * Gets the genre of a song from the file.
     *
     * <p>This method reads the genre directly from the file using
     * jaudiotagger, bypassing the database cache. The genre loading phase
     * reads real genres from ID3 tags. The database is updated when a real
     * genre is found.</p>
     *
     * @param filePath Absolute path to the music file
     * @return Genre string, or {@link #UNKNOWN_GENRE} if not available
     */
    @NonNull
    public static String getGenre(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) {
            return UNKNOWN_GENRE;
        }

        ParseResult result = parseSongInfo(filePath);
        if (!result.hasRealGenre()) {
            return UNKNOWN_GENRE;
        }

        String genre = result.genre;
        SongDatabase database = SongDatabase.getInstance(appContext);

        Song existingSong = database.getSong(filePath);
        if (existingSong != null && !genre.equals(existingSong.getGenre())) {
            Song updatedSong = new Song(
                existingSong.getTitle(),
                existingSong.getArtist(),
                existingSong.getAlbum(),
                genre,
                existingSong.getPath(),
                existingSong.getDuration(),
                existingSong.getUri());
            database.insertSong(updatedSong);
            Log.d("CharacterMapper", "Updated genre in database: "
                + existingSong.getTitle() + " -> " + genre);
        }

        ArrayList<Song> looseSongs = database.getLooseSongs();
        for (Song looseSong : looseSongs) {
            if (looseSong != null && filePath.equals(looseSong.getPath())) {
                Song updatedLooseSong = new Song(
                    looseSong.getTitle(),
                    looseSong.getArtist(),
                    looseSong.getAlbum(),
                    genre,
                    looseSong.getPath(),
                    looseSong.getDuration(),
                    null);
                database.insertLooseSong(updatedLooseSong);
                break;
            }
        }

        return genre;
    }

    // ========================================================================
    // File Parsing
    // ========================================================================

    /**
     * Parses song metadata from an audio file.
     *
     * <p>This method attempts to read ID3 tags using jaudiotagger. If tags
     * are missing, unreadable, or the file itself cannot be opened, it
     * falls back to using the filename (without extension) as the title and
     * the canonical placeholders for the other fields. The {@link
     * ParseResult#status} field records which outcome occurred.</p>
     *
     * @param filePath Absolute path to the music file
     * @return ParseResult containing the parsed metadata and outcome
     */
    @NonNull
    static ParseResult parseSongInfo(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return new ParseResult(
                ParseResult.Status.FILE_UNREADABLE,
                "", UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        File file = new File(filePath);
        if (!file.exists() || !file.canRead()) {
            String fallbackTitle = getFileNameWithoutExtension(file.getName());
            return new ParseResult(
                ParseResult.Status.FILE_UNREADABLE,
                clean(fallbackTitle), UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        String rawTitle = null;
        String rawArtist = null;
        String rawAlbum = null;
        String rawGenre = null;

        try {
            AudioFile audioFile = AudioFileIO.read(file);
            if (audioFile != null) {
                Tag tag = audioFile.getTag();
                if (tag != null) {
                    rawTitle = tag.getFirst(FieldKey.TITLE);
                    rawArtist = tag.getFirst(FieldKey.ARTIST);
                    rawAlbum = tag.getFirst(FieldKey.ALBUM);
                    rawGenre = tag.getFirst(FieldKey.GENRE);
                }
            }
        } catch (Exception exception) {
            Log.w("CharacterMapper", "Failed to parse metadata for: " + filePath, exception);
            String fallbackTitle = getFileNameWithoutExtension(file.getName());
            return new ParseResult(
                ParseResult.Status.PARSE_FAILED,
                clean(fallbackTitle), UNKNOWN_ARTIST, UNKNOWN_ALBUM, UNKNOWN_GENRE);
        }

        String title = canonicalizeTitle(rawTitle, file);
        String artist = canonicalizeArtist(rawArtist);
        String album = canonicalizeAlbum(rawAlbum);
        String genre = canonicalizeGenre(rawGenre);

        return new ParseResult(
            ParseResult.Status.PARSED, title, artist, album, genre);
    }

    /**
     * Produces the canonical title value from a raw tag and file.
     * Falls back to the filename without extension if the tag is absent
     * or a placeholder.
     */
    @NonNull
    private static String canonicalizeTitle(@Nullable String rawTitle, @NonNull File file) {
        String cleaned = cleanMusicMetadata(rawTitle);
        if (cleaned != null) {
            return cleaned;
        }
        String fallbackTitle = getFileNameWithoutExtension(file.getName());
        cleaned = clean(fallbackTitle);
        return TextUtils.isEmpty(cleaned) ? "Unknown Title" : cleaned;
    }

    /**
     * Produces the canonical artist value from a raw tag.
     * Falls back to {@link #UNKNOWN_ARTIST} if the tag is absent or a placeholder.
     */
    @NonNull
    private static String canonicalizeArtist(@Nullable String rawArtist) {
        String cleaned = cleanMusicMetadata(rawArtist);
        return cleaned != null ? cleaned : UNKNOWN_ARTIST;
    }

    /**
     * Produces the canonical album value from a raw tag.
     * Falls back to {@link #UNKNOWN_ALBUM} if the tag is absent or a placeholder.
     */
    @NonNull
    private static String canonicalizeAlbum(@Nullable String rawAlbum) {
        String cleaned = cleanMusicMetadata(rawAlbum);
        return cleaned != null ? cleaned : UNKNOWN_ALBUM;
    }

    /**
     * Produces the canonical genre value from a raw tag.
     * Falls back to {@link #UNKNOWN_GENRE} if the tag is absent or a placeholder.
     */
    @NonNull
    private static String canonicalizeGenre(@Nullable String rawGenre) {
        String cleaned = cleanMusicMetadata(rawGenre);
        return cleaned != null ? cleaned : UNKNOWN_GENRE;
    }

    /**
     * Extracts the filename without extension.
     *
     * @param fileName The full filename (may include extension)
     * @return The filename without the last extension
     */
    @NonNull
    private static String getFileNameWithoutExtension(@NonNull String fileName) {
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(0, dotIndex);
        }
        return fileName;
    }

    // ========================================================================
    // String Cleaning Methods
    // ========================================================================

    /**
     * Checks if a string is a placeholder value (e.g., "unknown", "?").
     *
     * @param input The string to check (can be null)
     * @return True if the string is a placeholder value
     */
    private static boolean isPlaceholder(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return false;
        String trimmed = input.trim();
        for (String placeholder : PLACEHOLDER_VALUES) {
            if (trimmed.equalsIgnoreCase(placeholder)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cleans a string by removing control characters, zero-width spaces, and normalizing spaces.
     *
     * @param input The string to clean (can be null)
     * @return Cleaned string, or empty string if input is null
     */
    @NonNull
    private static String clean(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }

        try {
            String result = decodeHtmlEntities(input);
            result = CONTROL_CHARS.matcher(result).replaceAll("");
            result = result.replace("\u200B", "")
                          .replace("\uFEFF", "")
                          .replace("\u00A0", " ");
            result = MULTIPLE_SPACES.matcher(result).replaceAll(" ");
            return result.trim();
        } catch (Exception exception) {
            Log.w("CharacterMapper", "Error cleaning string", exception);
            return input;
        }
    }

    /**
     * Public wrapper for the clean method.
     *
     * @param input The string to clean
     * @return The cleaned string
     */
    @NonNull
    public static String cleanString(@Nullable String input) {
        return clean(input);
    }

    /**
     * Minimal cleaning for strings that preserve more characters.
     *
     * @param input The string to clean
     * @return The cleaned string
     */
    @NonNull
    public static String cleanStringMinimal(@Nullable String input) {
        return clean(input);
    }

    /**
     * Cleans music metadata and returns null if it is a placeholder.
     *
     * @param input The metadata string to clean
     * @return Cleaned metadata, or null if empty or placeholder
     */
    @Nullable
    public static String cleanMusicMetadata(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return null;

        String trimmed = input.trim();
        if (isPlaceholder(trimmed)) return null;

        String cleaned = clean(trimmed);
        if (TextUtils.isEmpty(cleaned)) return null;
        if (isPlaceholder(cleaned)) return null;

        return cleaned;
    }

    /**
     * Formats a string for display with a maximum length, adding ellipsis if truncated.
     *
     * @param input The string to format
     * @param maxLength Maximum allowed length before truncation
     * @return Formatted string, possibly truncated with "..."
     */
    @NonNull
    public static String formatForDisplay(@Nullable String input, int maxLength) {
        if (TextUtils.isEmpty(input)) return "";
        if (input.length() <= maxLength) return input;
        if (maxLength < 4) return input.substring(0, maxLength);
        return input.substring(0, maxLength - 3) + "...";
    }

    /**
     * Formats a filename for display.
     *
     * @param originalName The original filename
     * @return A display-safe filename string
     */
    @NonNull
    public static String displayFileName(@Nullable String originalName) {
        String cleaned = cleanMusicMetadata(originalName);
        return TextUtils.isEmpty(cleaned) ? "Unknown" : cleaned;
    }

    /**
     * Cleans a string for use in file paths.
     *
     * @param input The input string
     * @return The cleaned string (or empty string if null)
     */
    @NonNull
    public static String cleanForPath(@Nullable String input) {
        return input != null ? input : "";
    }

    /**
     * Cleans and lowercases a string for search operations.
     *
     * @param input The input string
     * @return The cleaned and lowercased string
     */
    @NonNull
    public static String cleanForSearch(@Nullable String input) {
        if (input == null) return "";
        return clean(input).toLowerCase();
    }

    /**
     * Decodes common HTML entities in a string.
     *
     * @param input The string containing HTML entities
     * @return String with HTML entities decoded
     */
    @NonNull
    public static String decodeHtmlEntities(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return input != null ? input : "";
        }

        StringBuilder result = new StringBuilder(input);

        replaceAll(result, "&amp;", "&");
        replaceAll(result, "&lt;", "<");
        replaceAll(result, "&gt;", ">");
        replaceAll(result, "&quot;", "\"");
        replaceAll(result, "&apos;", "'");
        replaceAll(result, "&#39;", "'");
        replaceAll(result, "&#34;", "\"");
        replaceAll(result, "&#38;", "&");
        replaceAll(result, "&#60;", "<");
        replaceAll(result, "&#62;", ">");
        replaceAll(result, "&nbsp;", " ");
        replaceAll(result, "&#160;", " ");
        replaceAll(result, "&ndash;", "\u2013");
        replaceAll(result, "&mdash;", "\u2014");
        replaceAll(result, "&lsquo;", "'");
        replaceAll(result, "&rsquo;", "'");
        replaceAll(result, "&ldquo;", "\"");
        replaceAll(result, "&rdquo;", "\"");
        replaceAll(result, "&hellip;", "\u2026");
        replaceAll(result, "&#8230;", "\u2026");

        return result.toString();
    }

    /**
     * Helper method to replace all occurrences in a StringBuilder.
     *
     * @param builder The StringBuilder to modify
     * @param target The target string to replace
     * @param replacement The replacement string
     */
    private static void replaceAll(StringBuilder builder, String target, String replacement) {
        int index = builder.indexOf(target);
        while (index != -1) {
            builder.replace(index, index + target.length(), replacement);
            index = builder.indexOf(target, index + replacement.length());
        }
    }

    /**
     * Checks if a string contains non-ASCII characters.
     *
     * @param input The string to check
     * @return True if non-ASCII characters are found
     */
    public static boolean hasProblematicCharacters(@Nullable String input) {
        if (TextUtils.isEmpty(input)) return false;

        for (int index = 0; index < input.length(); index++) {
            char character = input.charAt(index);
            if (character > 127) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if a song's metadata is already cached in the database.
     *
     * @param filePath The path of the song file
     * @return True if the song is in the database cache
     */
    public static boolean isCached(@NonNull String filePath) {
        if (TextUtils.isEmpty(filePath) || appContext == null) return false;
        return SongDatabase.getInstance(appContext).hasSong(filePath);
    }
}