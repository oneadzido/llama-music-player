package com.ark.llama;

import android.content.Context;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Provides the FontAwesome icon font as a shared {@link Typeface} and
 * exposes the Unicode characters that map to specific icon glyphs.
 *
 * <p>Icons are rendered by setting the typeface returned from
 * {@link #getTypeface()} on a {@code TextView} and assigning one of the
 * public character constants as its text. Because the glyphs are ordinary
 * characters, they respond to the standard {@code TextView} styling
 * properties such as color, size, and letter spacing.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The typeface is loaded once, on the first successful call to
 * {@link #init(Context)}, and is read on every subsequent call to
 * {@link #getTypeface()}. Call {@code init} before any other class in the
 * process reads the typeface.</p>
 *
 * <h3>Usage</h3>
 * <pre>
 * FontAwesome.init(context);
 *
 * TextView icon = findViewById(R.id.icon);
 * icon.setTypeface(FontAwesome.getTypeface());
 * icon.setText(FontAwesome.PLAY);
 * </pre>
 *
 * @see Typeface
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public final class FontAwesome {

    // ========================================================================
    // Constants - Icon Unicode Characters
    // ========================================================================

    /** Solid play triangle. */
    public static final String PLAY = "\uF04B";

    /** Solid pause bars. */
    public static final String PAUSE = "\uF04C";

    /** Solid double left chevrons. */
    public static final String BACKWARD = "\uF04A";

    /** Solid double right chevrons. */
    public static final String FORWARD = "\uF04E";

    /** Solid crossed arrows. */
    public static final String SHUFFLE = "\uF074";

    /** Solid circular arrows. */
    public static final String REPEAT = "\uF363";

    /** Solid converging circular arrows. */
    public static final String REPEAT_ONE = "\uF2F1";

    /** Solid folder shape. */
    public static final String FOLDER = "\uF07B";

    // ========================================================================
    // Static Variables
    // ========================================================================

    /** Typeface loaded from assets, or null when not yet loaded. */
    @Nullable
    private static Typeface sTypeface;

    // ========================================================================
    // Private Constructor
    // ========================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private FontAwesome() {
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Loads the FontAwesome typeface from assets on the first call, and
     * does nothing on every subsequent call.
     *
     * <p>Call this method before any code that needs
     * {@link #getTypeface()}. A failure to load the font file leaves
     * {@link #getTypeface()} returning null; this method does not throw
     * on failure.</p>
     *
     * @param context Context used to open the asset
     */
    public static void init(@NonNull Context context) {
        if (sTypeface == null) {
            try {
                sTypeface = Typeface.createFromAsset(
                    context.getAssets(), "fonts/fa-solid-900.ttf");
            } catch (Exception exception) {
                // A failed font load leaves the typeface null; icons then
                // render as blank glyphs at the default typeface.
            }
        }
    }

    /**
     * Returns the loaded FontAwesome typeface.
     *
     * <p>Returns null when {@link #init(Context)} has not yet been called
     * or when loading the font failed.</p>
     *
     * @return The FontAwesome typeface, or null when not loaded
     */
    @Nullable
    public static Typeface getTypeface() {
        return sTypeface;
    }
}