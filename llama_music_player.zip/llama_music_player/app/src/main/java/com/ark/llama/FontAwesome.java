package com.ark.llama;

import android.content.Context;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Utility class for managing FontAwesome icon font.
 * 
 * <p>This class provides access to the FontAwesome font for displaying
 * vector icons in TextViews and other text-based UI components. The font
 * is loaded once from assets and reused throughout the application.</p>
 * 
 * <p>FontAwesome icons are displayed as Unicode characters that map to
 * specific glyphs in the font file. This approach allows for scalable,
 * colorable icons that can be styled with standard TextView properties.</p>
 * 
 * <p>Usage example:
 * <pre>
 * // Initialize once at application start
 * FontAwesome.init(context);
 * 
 * // Use in a TextView
 * TextView icon = findViewById(R.id.icon);
 * icon.setTypeface(FontAwesome.getTypeface());
 * icon.setText(FontAwesome.PLAY);
 * </pre>
 * </p>
 * 
 * <p>Follows Google's recommendations for utility class design with
 * private constructor and static methods only.</p>
 * 
 * @see Typeface
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.0
 * @since 1.0
 */
public final class FontAwesome {
    
    // ========================================================================
    // Constants - Icon Unicode Characters
    // ========================================================================
    
    /** Play icon: "\uF04B" - Solid play triangle. */
    public static final String PLAY = "\uF04B";
    
    /** Pause icon: "\uF04C" - Solid pause bars. */
    public static final String PAUSE = "\uF04C";
    
    /** Backward/Skip Previous icon: "\uF04A" - Solid double left chevrons. */
    public static final String BACKWARD = "\uF04A";
    
    /** Forward/Skip Next icon: "\uF04E" - Solid double right chevrons. */
    public static final String FORWARD = "\uF04E";
    
    /** Shuffle icon: "\uF074" - Solid crossed arrows. */
    public static final String SHUFFLE = "\uF074";
    
    /** Repeat All icon: "\uF363" - Solid circular arrows. */
    public static final String REPEAT = "\uF363";
    
    /** Repeat One icon: "\uF2F1" - Solid converging circular arrows. */
    public static final String REPEAT_ONE = "\uF2F1";
    
    /** Folder icon: "\uF07B" - Solid folder shape. */
    public static final String FOLDER = "\uF07B";
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    /** Cached Typeface instance for the FontAwesome font. */
    @Nullable
    private static Typeface sTypeface;
    
    // ========================================================================
    // Private Constructor
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * 
     * <p>This class follows the utility class pattern and should never
     * be instantiated. All methods and fields are static.</p>
     */
    private FontAwesome() {
        // Private constructor to prevent instantiation
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Initializes the FontAwesome typeface by loading the font from assets.
     * 
     * <p>This method must be called before using FontAwesome icons.
     * It is typically called in the Application class onCreate() method.</p>
     *
     * @param context The application context used to access assets
     */
    public static void init(@NonNull Context context) {
        if (sTypeface == null) {
            try {
                sTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/fa-solid-900.ttf");
            } catch (Exception e) {
                // If font loading fails, typeface remains null - icons will show as blank
                // but the app will continue to function
            }
        }
    }
    
    /**
     * Returns the loaded FontAwesome typeface.
     * 
     * <p>Returns null if init() has not been called or if font loading failed.
     * Callers should handle null gracefully by falling back to default typeface.</p>
     *
     * @return The FontAwesome Typeface, or null if not loaded
     */
    @Nullable
    public static Typeface getTypeface() {
        return sTypeface;
    }
}