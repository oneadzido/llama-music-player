package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;
import org.jaudiotagger.tag.images.ArtworkFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

/**
 * Utility class for writing audio file metadata with safety guarantees.
 *
 * <p>This class provides write operations for ID3 tags and other metadata
 * with the following guarantees:</p>
 *
 * <ul>
 *   <li><b>Null means "no change"</b> - Fields set to null are left untouched</li>
 *   <li><b>Empty string means "delete field"</b> - Fields set to empty string are removed</li>
 *   <li><b>Automatic backup and restore</b> - On failure, original file is restored</li>
 *   <li><b>Verification after write</b> - Ensures file is still valid audio</li>
 * </ul>
 *
 * <h3>Result Contract</h3>
 * <p>Every write operation returns a {@link WriteResult} whose {@link
 * WriteResult#status} is the exhaustive, single-field answer to "what
 * happened." Callers branch on the status enum, not on the presence or
 * value of diagnostic strings. The {@link WriteResult#errorMessage} field
 * is retained for logging and display, but never for control flow.</p>
 *
 * <p>Two status values indicate that a backup was restored: {@link
 * WriteResult.Status#WRITE_FAILED_RESTORED} and {@link
 * WriteResult.Status#VERIFY_FAILED_RESTORED}. Two status values indicate
 * that the write never began and the original file was never touched:
 * {@link WriteResult.Status#PERMISSION_DENIED} and {@link
 * WriteResult.Status#COPY_FAILED}. The distinction is what lets a caller
 * answer "is the file on disk the same as it was before the call?" by
 * inspecting a single enum constant.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>This class uses a global write lock to prevent concurrent write operations.
 * All methods are static and use synchronized blocks for thread safety.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class MetadataWriter {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MetadataWriter";

    /** Buffer size for file copy operations (8KB). */
    private static final int COPY_BUFFER_SIZE = 8192;

    /** Max size for album art in bytes (1MB). */
    private static final int MAX_ALBUM_ART_BYTES = 1024 * 1024;

    /** Lock object for thread-safe write operations. */
    @NonNull
    private static final Object sWriteLock = new Object();

    // ========================================================================
    // Private Constructor
    // ========================================================================

    private MetadataWriter() {
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Result container for metadata write operations.
     *
     * <p>The {@link #status} field is the entire answer to "what happened."
     * Each status value describes a distinct outcome; no two statuses
     * require the same caller response, and every status a caller might
     * receive is enumerated.</p>
     *
     * <p>{@link #errorMessage} carries a human-readable diagnostic. It is
     * non-null for every non-{@link Status#WRITTEN} status and null for
     * {@code WRITTEN}. It is intended for logging and display; callers must
     * not parse it.</p>
     */
    public static final class WriteResult {

        /**
         * Exhaustive outcomes of a metadata write operation.
         */
        public enum Status {

            /**
             * The metadata was written to the file, verified, and written
             * back to the original URI. The file on disk reflects the new
             * metadata.
             */
            WRITTEN,

            /**
             * The URI no longer grants write permission. Nothing was
             * attempted; the file is untouched. Callers should invalidate
             * any cached URI for this song and ask the user to reselect
             * the file.
             */
            PERMISSION_DENIED,

            /**
             * The file could not be copied from the URI into the cache.
             * Nothing was attempted; the file is untouched.
             */
            COPY_FAILED,

            /**
             * The backup copy of the file could not be created. Nothing was
             * attempted; the file is untouched.
             */
            BACKUP_FAILED,

            /**
             * The metadata write to the cached copy failed. The original
             * file has been restored from backup; the file on disk is
             * unchanged.
             */
            WRITE_FAILED_RESTORED,

            /**
             * The metadata was written but the file failed verification as
             * valid audio. The original file has been restored from backup;
             * the file on disk is unchanged.
             */
            VERIFY_FAILED_RESTORED,

            /**
             * The metadata write and verification succeeded but the cached
             * file could not be copied back to the original URI. The
             * original file has been restored from backup; the file on disk
             * is unchanged.
             */
            COPY_BACK_FAILED_RESTORED,

            /**
             * An unexpected error occurred during the write. The original
             * file has been restored from backup if a backup existed. The
             * {@link #errorMessage} carries the exception's description.
             */
            FAILED
        }

        /** The outcome of the operation. */
        @NonNull
        public final Status status;

        /** Diagnostic message. Non-null for every status except {@link Status#WRITTEN}. */
        @Nullable
        public final String errorMessage;

        /**
         * Private constructor for WriteResult.
         *
         * @param status the outcome status
         * @param errorMessage diagnostic message, or null for successful writes
         */
        private WriteResult(@NonNull final Status status,
                            @Nullable final String errorMessage) {
            this.status = status;
            this.errorMessage = errorMessage;
        }

        /**
         * Creates a success result.
         *
         * @return A {@link Status#WRITTEN} result
         */
        @NonNull
        public static WriteResult written() {
            return new WriteResult(Status.WRITTEN, null);
        }

        /**
         * Creates a failure result for the given status.
         *
         * @param status the failure status; must not be {@link Status#WRITTEN}
         * @param errorMessage diagnostic message
         * @return A failure WriteResult
         */
        @NonNull
        public static WriteResult failed(@NonNull final Status status,
                                         @NonNull final String errorMessage) {
            if (status == Status.WRITTEN) {
                throw new IllegalArgumentException(
                    "Use written() to construct a WRITTEN result");
            }
            return new WriteResult(status, errorMessage);
        }

        /**
         * True when the write completed and the file on disk reflects the
         * new metadata.
         *
         * @return true if the status is {@link Status#WRITTEN}
         */
        public boolean isSuccess() {
            return status == Status.WRITTEN;
        }

        /**
         * True when the file on disk is the same as it was before the call.
         *
         * <p>For {@link Status#PERMISSION_DENIED}, {@link Status#COPY_FAILED},
         * and {@link Status#BACKUP_FAILED}, the write never began so the
         * file is trivially unchanged. For {@link Status#WRITE_FAILED_RESTORED},
         * {@link Status#VERIFY_FAILED_RESTORED}, and
         * {@link Status#COPY_BACK_FAILED_RESTORED}, a backup was explicitly
         * restored. All three classes of outcome return true here; callers
         * that care about the reason distinguish via {@link #status}.</p>
         *
         * @return true if the file on disk is unchanged
         */
        public boolean isFileUnchanged() {
            switch (status) {
                case PERMISSION_DENIED:
                case COPY_FAILED:
                case BACKUP_FAILED:
                case WRITE_FAILED_RESTORED:
                case VERIFY_FAILED_RESTORED:
                case COPY_BACK_FAILED_RESTORED:
                    return true;
                case WRITTEN:
                case FAILED:
                default:
                    return false;
            }
        }

        /**
         * Returns a string representation of the result.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "WriteResult{" +
                    "status=" + status +
                    ", errorMessage='" + errorMessage + '\'' +
                    '}';
        }
    }

    /**
     * Update bundle for metadata changes.
     *
     * <p>Fields set to null will be left unchanged.
     * Fields set to empty string will be deleted from the file.
     * Fields with non-empty values will be set to that value.</p>
     */
    public static final class UpdateBundle {

        /** New title (null = no change, empty = delete). */
        @Nullable
        public String title;

        /** New artist (null = no change, empty = delete). */
        @Nullable
        public String artist;

        /** New album (null = no change, empty = delete). */
        @Nullable
        public String album;

        /** New year (null = no change, empty = delete). */
        @Nullable
        public String year;

        /** New genre (null = no change, empty = delete). */
        @Nullable
        public String genre;

        /** New track number (null = no change, empty = delete). */
        @Nullable
        public String trackNumber;

        /** New lyrics (null = no change, empty = delete). */
        @Nullable
        public String lyrics;

        /**
         * New album art bytes.
         * null = no change to album art
         * empty array = delete album art
         * non-empty = set new album art
         */
        @Nullable
        public byte[] albumArt;

        /**
         * Creates an empty UpdateBundle.
         */
        public UpdateBundle() {
        }

        /**
         * Checks if any changes are requested.
         *
         * @return True if any field is non-null (including empty strings)
         */
        public boolean hasChanges() {
            return title != null || artist != null || album != null ||
                   year != null || genre != null || trackNumber != null ||
                   lyrics != null || albumArt != null;
        }

        /**
         * Returns a string representation of the update bundle for debugging.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "UpdateBundle{" +
                    "title=" + (title != null ? "'" + title + "'" : "null") +
                    ", artist=" + (artist != null ? "'" + artist + "'" : "null") +
                    ", album=" + (album != null ? "'" + album + "'" : "null") +
                    ", year=" + (year != null ? "'" + year + "'" : "null") +
                    ", genre=" + (genre != null ? "'" + genre + "'" : "null") +
                    ", trackNumber=" + (trackNumber != null ? "'" + trackNumber + "'" : "null") +
                    ", lyrics=" + (lyrics != null ? "[set]" : "null") +
                    ", albumArt=" + (albumArt != null ? (albumArt.length + " bytes") : "null") +
                    '}';
        }
    }

    // ========================================================================
    // Public Write Methods
    // ========================================================================

    /**
     * Writes metadata to an audio file accessed via a document URI (SAF).
     *
     * <p>This is the primary method for SAF-based write operations. It handles
     * backup, restore, and verification automatically.</p>
     *
     * <p>This method is thread-safe using a global write lock.</p>
     *
     * @param context Application context
     * @param documentUri Document URI for the audio file
     * @param update Metadata changes to apply (null fields = no change)
     * @return WriteResult indicating the outcome
     */
    @NonNull
    public static WriteResult writeMetadataToUri(@NonNull final Context context,
                                                 @NonNull final Uri documentUri,
                                                 @NonNull final UpdateBundle update) {
        synchronized (sWriteLock) {
            File tempFile = null;
            File backupFile = null;

            try {
                Log.d(TAG, "Starting metadata write to URI: " + documentUri);
                Log.d(TAG, "Update bundle: " + update);

                final DocumentFile document = DocumentFile.fromSingleUri(context, documentUri);
                if (document == null || !document.canWrite()) {
                    Log.e(TAG, "No write permission for URI: " + documentUri);
                    return WriteResult.failed(WriteResult.Status.PERMISSION_DENIED,
                        "No write permission for file");
                }

                tempFile = copyUriToCache(context, documentUri);
                if (tempFile == null) {
                    Log.e(TAG, "Failed to copy file from URI");
                    return WriteResult.failed(WriteResult.Status.COPY_FAILED,
                        "Failed to copy file from URI");
                }

                Log.d(TAG, "Copied to temp file: " + tempFile.getAbsolutePath() +
                      " (" + tempFile.length() + " bytes)");

                backupFile = new File(context.getCacheDir(),
                        "backup_" + SystemClock.elapsedRealtime() + "_" + tempFile.getName());
                if (!copyFile(tempFile, backupFile)) {
                    deleteFileSafely(tempFile);
                    return WriteResult.failed(WriteResult.Status.BACKUP_FAILED,
                        "Failed to create backup");
                }

                Log.d(TAG, "Backup created: " + backupFile.getAbsolutePath());

                if (!writeMetadataToFileInternal(tempFile, update)) {
                    Log.e(TAG, "Failed to write metadata, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.WRITE_FAILED_RESTORED,
                        "Failed to write metadata");
                }

                Log.d(TAG, "Metadata written, temp file size: " + tempFile.length() + " bytes");

                if (!verifyAudioFile(tempFile)) {
                    Log.e(TAG, "Verification failed, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.VERIFY_FAILED_RESTORED,
                        "Verification failed");
                }

                if (!copyCacheToUri(context, tempFile, documentUri)) {
                    Log.e(TAG, "Failed to write back to original URI, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.COPY_BACK_FAILED_RESTORED,
                        "Failed to write back to original");
                }

                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                Log.d(TAG, "Successfully wrote metadata to: " + documentUri);
                return WriteResult.written();

            } catch (Exception exception) {
                Log.e(TAG, "Unexpected error during metadata write", exception);
                if (backupFile != null && backupFile.exists() && tempFile != null) {
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                }
                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                final String errorMessage = exception.getMessage() != null
                    ? exception.getMessage() : "Unknown error";
                return WriteResult.failed(WriteResult.Status.FAILED, errorMessage);
            }
        }
    }

    // ========================================================================
    // Private Write Helper Methods
    // ========================================================================

    /**
     * Internal method that writes metadata to a file using jaudiotagger.
     *
     * <p>This method implements the null = no change, empty = delete logic.</p>
     *
     * @param file The file to write metadata to
     * @param update The metadata changes to apply
     * @return True if successful
     */
    private static boolean writeMetadataToFileInternal(@NonNull final File file,
                                                       @NonNull final UpdateBundle update) {
        AudioFile audioFile = null;

        try {
            Log.d(TAG, "=== Starting metadata write ===");
            Log.d(TAG, "File: " + file.getAbsolutePath());

            audioFile = AudioFileIO.read(file);
            if (audioFile == null) {
                Log.e(TAG, "AudioFileIO.read returned null");
                return false;
            }

            Tag tag = audioFile.getTag();
            if (tag == null) {
                Log.d(TAG, "No existing tag, creating default tag");
                tag = audioFile.createDefaultTag();
                audioFile.setTag(tag);
            }

            Log.d(TAG, "Tag class: " + tag.getClass().getName());

            setOrDeleteField(tag, FieldKey.TITLE, update.title);
            setOrDeleteField(tag, FieldKey.ARTIST, update.artist);
            setOrDeleteField(tag, FieldKey.ALBUM, update.album);
            setOrDeleteField(tag, FieldKey.YEAR, update.year);
            setOrDeleteField(tag, FieldKey.GENRE, update.genre);
            setOrDeleteField(tag, FieldKey.TRACK, update.trackNumber);
            setOrDeleteField(tag, FieldKey.LYRICS, update.lyrics);

            if (update.albumArt != null) {
                try {
                    tag.deleteArtworkField();
                    Log.d(TAG, "Deleted existing artwork");
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to delete existing artwork: " + exception.getMessage());
                }

                if (update.albumArt.length > 0) {
                    final Artwork artwork = createArtworkFromBytes(update.albumArt, file.getParentFile());
                    if (artwork != null) {
                        try {
                            tag.setField(artwork);
                            Log.d(TAG, "Album art set successfully");
                        } catch (Exception exception) {
                            Log.e(TAG, "Failed to set album art: " + exception.getMessage());
                            return false;
                        }
                    } else {
                        Log.e(TAG, "Could not create Artwork object");
                        return false;
                    }
                } else {
                    Log.d(TAG, "Album art deleted");
                }
            } else {
                Log.d(TAG, "Album art unchanged");
            }

            audioFile.commit();
            Log.d(TAG, "=== Metadata commit successful ===");
            return true;

        } catch (Exception exception) {
            Log.e(TAG, "writeMetadataToFileInternal failed: " + exception.getMessage(), exception);
            return false;
        }
    }

    /**
     * Sets or deletes a field in the tag.
     *
     * @param tag The tag to modify
     * @param key The field key
     * @param value The value to set
     */
    private static void setOrDeleteField(@NonNull final Tag tag,
                                         @NonNull final FieldKey key,
                                         @Nullable final String value) {
        try {
            if (value == null) {
                Log.d(TAG, "Field " + key + ": no change");
                return;
            }

            final String trimmed = value.trim();
            if (trimmed.isEmpty()) {
                tag.deleteField(key);
                Log.d(TAG, "Deleted field: " + key);
            } else {
                tag.setField(key, trimmed);
                Log.d(TAG, "Set field " + key + " = '" + trimmed + "'");
            }
        } catch (Exception exception) {
            Log.w(TAG, "Failed to set/delete field " + key + ": " + exception.getMessage());
        }
    }

    /**
     * Creates an Artwork object from byte data.
     *
     * @param albumArtBytes The album art bytes (JPEG format)
     * @param parentDir Parent directory for temporary files
     * @return Artwork object, or null if creation fails
     */
    @Nullable
    private static Artwork createArtworkFromBytes(@NonNull final byte[] albumArtBytes,
                                                   @Nullable final File parentDir) {
        if (albumArtBytes.length == 0 || albumArtBytes.length > MAX_ALBUM_ART_BYTES) {
            Log.e(TAG, "Invalid album art size: " + albumArtBytes.length);
            return null;
        }

        File tempFile = null;
        try {
            final File tempDir = (parentDir != null) ? parentDir :
                new File(System.getProperty("java.io.tmpdir"));
            tempFile = File.createTempFile("album_art_", ".jpg", tempDir);

            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(tempFile);
                fileOutputStream.write(albumArtBytes);
                fileOutputStream.flush();
                Log.d(TAG, "Wrote album art to temp file: " + tempFile.getAbsolutePath() +
                      " (" + tempFile.length() + " bytes)");
            } finally {
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException exception) {
                        // Ignore
                    }
                }
            }

            try {
                final Method method = ArtworkFactory.class.getMethod("createArtworkFromFile", File.class);
                final Artwork artwork = (Artwork) method.invoke(null, tempFile);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromFile()");
                    return artwork;
                }
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromFile not found");
            } catch (Exception exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromFile failed: " + exception.getMessage());
            }

            try {
                final Method method = ArtworkFactory.class.getMethod("createArtworkFromData", byte[].class);
                final Artwork artwork = (Artwork) method.invoke(null, (Object) albumArtBytes);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromData()");
                    return artwork;
                }
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromData not found");
            } catch (Exception exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromData failed: " + exception.getMessage());
            }

            return null;

        } catch (Exception exception) {
            Log.e(TAG, "Failed to create artwork: " + exception.getMessage(), exception);
            return null;
        } finally {
            if (tempFile != null && tempFile.exists()) {
                final boolean deleted = tempFile.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete temp art file");
                }
            }
        }
    }

    // ========================================================================
    // File Helper Methods
    // ========================================================================

    /**
     * Copies a file from a document URI to the cache directory.
     *
     * @param context Application context
     * @param uri The document URI to copy from
     * @return The cached file, or null if copy fails
     */
    @Nullable
    private static File copyUriToCache(@NonNull final Context context,
                                       @NonNull final Uri uri) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: " + uri);
                return null;
            }
            final File outFile = new File(context.getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            outputStream = new FileOutputStream(outFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Copied " + totalBytes + " bytes from URI to cache");
            return outFile;
        } catch (IOException exception) {
            Log.e(TAG, "copyUriToCache failed: " + exception.getMessage());
            return null;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Copies a cache file back to a document URI.
     *
     * @param context Application context
     * @param cacheFile The cached file to copy from
     * @param uri The destination document URI
     * @return True if copy succeeds
     */
    private static boolean copyCacheToUri(@NonNull final Context context,
                                          @NonNull final File cacheFile,
                                          @NonNull final Uri uri) {
        Log.d(TAG, "Writing cache file to URI: " + cacheFile.getAbsolutePath() +
              " (" + cacheFile.length() + " bytes)");

        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = new FileInputStream(cacheFile);
            final ContentResolver resolver = context.getContentResolver();
            outputStream = resolver.openOutputStream(uri, "wt");

            if (outputStream == null) {
                Log.e(TAG, "Failed to open output stream for URI: " + uri);
                return false;
            }

            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Successfully wrote " + totalBytes + " bytes to URI");
            return true;
        } catch (IOException exception) {
            Log.e(TAG, "copyCacheToUri failed: " + exception.getMessage(), exception);
            return false;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Copies a file from source to destination.
     *
     * @param sourceFile Source file
     * @param destinationFile Destination file
     * @return True if copy succeeds
     */
    private static boolean copyFile(@NonNull final File sourceFile, @NonNull final File destinationFile) {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        try {
            fileInputStream = new FileInputStream(sourceFile);
            fileOutputStream = new FileOutputStream(destinationFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            while ((length = fileInputStream.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, length);
            }
            fileOutputStream.getFD().sync();
            return true;
        } catch (IOException exception) {
            Log.e(TAG, "copyFile failed: " + exception.getMessage());
            return false;
        } finally {
            closeQuietly(fileInputStream);
            closeQuietly(fileOutputStream);
        }
    }

    /**
     * Restores a file from backup.
     *
     * @param original The original file to restore
     * @param backup The backup file
     * @return True if restore succeeds
     */
    private static boolean restoreFromBackup(@NonNull final File original,
                                             @NonNull final File backup) {
        if (!backup.exists()) {
            Log.e(TAG, "Backup file doesn't exist: " + backup.getAbsolutePath());
            return false;
        }
        deleteFileSafely(original);
        final boolean success = backup.renameTo(original);
        Log.d(TAG, "Restore from backup: " + (success ? "success" : "failed"));
        return success;
    }

    /**
     * Safely deletes a file, logging any errors.
     *
     * @param file The file to delete (can be null)
     */
    private static void deleteFileSafely(@Nullable final File file) {
        if (file != null && file.exists()) {
            try {
                final boolean deleted = file.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete: " + file.getName());
                }
            } catch (SecurityException exception) {
                Log.w(TAG, "delete failed for " + file.getName() + ": " + exception.getMessage());
            }
        }
    }

    /**
     * Verifies that a file is a valid audio file.
     *
     * @param file The file to verify
     * @return True if the file is a valid audio file
     */
    private static boolean verifyAudioFile(@NonNull final File file) {
        if (!file.exists() || file.length() == 0) {
            Log.e(TAG, "Verify failed: file doesn't exist or is empty");
            return false;
        }
        try {
            final AudioFile audioFile = AudioFileIO.read(file);
            final boolean valid = audioFile != null;
            Log.d(TAG, "Verify audio file: " + (valid ? "valid" : "failed"));
            return valid;
        } catch (Exception exception) {
            Log.e(TAG, "Verify failed with exception: " + exception.getMessage());
            return false;
        }
    }

    /**
     * Closes a Closeable quietly.
     *
     * @param closeable The Closeable to close (can be null)
     */
    private static void closeQuietly(@Nullable final java.io.Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException exception) {
                // Ignore
            }
        }
    }
}