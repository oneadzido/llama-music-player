package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;
import org.jaudiotagger.tag.images.ArtworkFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

/**
 * Writes ID3 tags and album art to audio files, with backup and restore
 * around every write.
 *
 * <p>A write copies the file to the cache, writes the requested changes
 * to the cached copy, verifies the result, and copies the cached copy
 * back to the original document URI. When any step fails after a backup
 * was taken, the original file is restored from that backup before the
 * method returns.</p>
 *
 * <h3>Result Contract</h3>
 * <p>Every write operation returns a {@link WriteResult} whose {@link
 * WriteResult#status} is the exhaustive, single-field answer to "what
 * happened". Callers branch on the status enum, not on the presence or
 * value of any diagnostic string. The {@link WriteResult#errorMessage}
 * field is used only for logging and display.</p>
 *
 * <p>Three status values indicate that the file on disk is the same as
 * it was before the call. {@link WriteResult.Status#PERMISSION_DENIED},
 * {@link WriteResult.Status#COPY_FAILED}, and
 * {@link WriteResult.Status#BACKUP_FAILED} describe outcomes in which
 * the write never began.
 * {@link WriteResult.Status#WRITE_FAILED_RESTORED},
 * {@link WriteResult.Status#VERIFY_FAILED_RESTORED}, and
 * {@link WriteResult.Status#COPY_BACK_FAILED_RESTORED} describe
 * outcomes in which a backup was restored.
 * {@link WriteResult#isFileUnchanged()} answers "is the file on disk the
 * same as it was before the call?" for every status.</p>
 *
 * <h3>Update Semantics</h3>
 * <p>Within an {@link UpdateBundle}, a field set to null means "leave the
 * current value unchanged". A field set to the empty string means "delete
 * the current value". A field set to any other string means "replace the
 * current value". The album art field follows the same rule: null means
 * no change, an empty array means delete, and a non-empty array means
 * replace.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every write acquires a single process-wide lock, so two concurrent
 * writes are serialised. Reads of the returned {@link WriteResult} are
 * safe from any thread.</p>
 *
 * @see MetadataReader
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class MetadataWriter {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "MetadataWriter";

    /** Buffer size for file copy operations, in bytes. */
    private static final int COPY_BUFFER_SIZE = 8192;

    /** Maximum size for album art in bytes. */
    private static final int MAX_ALBUM_ART_BYTES = 1024 * 1024;

    /** Fallback extension used when the source name cannot be resolved. */
    private static final String DEFAULT_EXTENSION = "mp3";

    /** Lock that serialises every write. */
    @NonNull
    private static final Object sWriteLock = new Object();

    // ========================================================================
    // Private Constructor
    // ========================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private MetadataWriter() {
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Describes the outcome of a metadata write.
     *
     * <p>The {@link #status} field is the entire answer to "what
     * happened". Each status value describes a distinct outcome.
     * {@link #errorMessage} carries a human-readable diagnostic; it is
     * non-null for every status except {@link Status#WRITTEN} and is
     * intended for logging and display only.</p>
     */
    public static final class WriteResult {

        /** Exhaustive outcomes of a metadata write. */
        public enum Status {

            /**
             * The metadata was written to the file, verified, and copied
             * back to the original URI. The file on disk reflects the new
             * metadata.
             */
            WRITTEN,

            /**
             * The URI no longer grants write permission, so the write was
             * not attempted. The file on disk is unchanged. Callers should
             * invalidate any cached URI for this song and ask the user to
             * reselect the file.
             */
            PERMISSION_DENIED,

            /**
             * The file could not be copied from the URI into the cache,
             * so the write was not attempted. The file on disk is
             * unchanged.
             */
            COPY_FAILED,

            /**
             * The backup copy of the file could not be created, so the
             * write was not attempted. The file on disk is unchanged.
             */
            BACKUP_FAILED,

            /**
             * The write to the cached copy failed. The original file has
             * been restored from backup, so the file on disk is
             * unchanged.
             */
            WRITE_FAILED_RESTORED,

            /**
             * The write completed but the cached copy failed verification
             * as valid audio. The original file has been restored from
             * backup, so the file on disk is unchanged.
             */
            VERIFY_FAILED_RESTORED,

            /**
             * The write and verification succeeded but the cached copy
             * could not be copied back to the original URI. The original
             * file has been restored from backup, so the file on disk is
             * unchanged.
             */
            COPY_BACK_FAILED_RESTORED,

            /**
             * An unexpected error occurred during the write. The original
             * file has been restored from backup if one existed.
             * {@link #errorMessage} carries the exception's description.
             */
            FAILED
        }

        /** The outcome of the operation. */
        @NonNull
        public final Status status;

        /** Diagnostic message; non-null for every status except {@link Status#WRITTEN}. */
        @Nullable
        public final String errorMessage;

        /**
         * Constructs a result with the given status and message.
         *
         * @param status Outcome of the write
         * @param errorMessage Diagnostic message, or null for a successful write
         */
        private WriteResult(@NonNull final Status status,
                            @Nullable final String errorMessage) {
            this.status = status;
            this.errorMessage = errorMessage;
        }

        /**
         * Returns a successful result.
         *
         * @return A result whose status is {@link Status#WRITTEN}
         */
        @NonNull
        public static WriteResult written() {
            return new WriteResult(Status.WRITTEN, null);
        }

        /**
         * Returns a failure result with the given status and message.
         *
         * @param status Outcome of the write; must not be {@link Status#WRITTEN}
         * @param errorMessage Diagnostic message describing the failure
         * @return A result whose status is the given value
         * @throws IllegalArgumentException If the given status is
         *         {@link Status#WRITTEN}
         */
        @NonNull
        public static WriteResult failed(@NonNull final Status status,
                                         @NonNull final String errorMessage) {
            if (status == Status.WRITTEN) {
                throw new IllegalArgumentException(
                    "Use written() to construct a WRITTEN result");
            }
            return new WriteResult(status, errorMessage);
        }

        /**
         * Returns whether the write completed and the file on disk
         * reflects the new metadata.
         *
         * @return True when the status is {@link Status#WRITTEN}
         */
        public boolean isSuccess() {
            return status == Status.WRITTEN;
        }

        /**
         * Returns whether the file on disk is the same as it was before
         * the call.
         *
         * <p>True for every status whose write did not begin or whose
         * backup was explicitly restored. Callers that need to distinguish
         * the reason inspect {@link #status}.</p>
         *
         * @return True when the file on disk is unchanged
         */
        public boolean isFileUnchanged() {
            switch (status) {
                case PERMISSION_DENIED:
                case COPY_FAILED:
                case BACKUP_FAILED:
                case WRITE_FAILED_RESTORED:
                case VERIFY_FAILED_RESTORED:
                case COPY_BACK_FAILED_RESTORED:
                    return true;
                case WRITTEN:
                case FAILED:
                default:
                    return false;
            }
        }

        /**
         * Returns a debug representation of this result.
         *
         * @return A string containing the status and error message
         */
        @NonNull
        @Override
        public String toString() {
            return "WriteResult{" +
                    "status=" + status +
                    ", errorMessage='" + errorMessage + '\'' +
                    '}';
        }
    }

    /**
     * Carries the metadata changes a caller wants to apply to a file.
     *
     * <p>A field set to null means "leave the current value unchanged". A
     * field set to the empty string means "delete the current value". A
     * field set to any other string means "replace the current value".
     * The album art field follows the same rule: null means no change, an
     * empty array means delete, and a non-empty array means replace.</p>
     */
    public static final class UpdateBundle {

        /** New title, or null for no change. */
        @Nullable
        public String title;

        /** New artist, or null for no change. */
        @Nullable
        public String artist;

        /** New album, or null for no change. */
        @Nullable
        public String album;

        /** New year, or null for no change. */
        @Nullable
        public String year;

        /** New genre, or null for no change. */
        @Nullable
        public String genre;

        /** New track number, or null for no change. */
        @Nullable
        public String trackNumber;

        /** New lyrics, or null for no change. */
        @Nullable
        public String lyrics;

        /** New album art, or null for no change. */
        @Nullable
        public byte[] albumArt;

        /**
         * Constructs an empty bundle.
         */
        public UpdateBundle() {
        }

        /**
         * Returns whether at least one field requests a change.
         *
         * <p>A field that is null does not count as a change; a field set
         * to the empty string does.</p>
         *
         * @return True when any field is non-null
         */
        public boolean hasChanges() {
            return title != null || artist != null || album != null
                || year != null || genre != null || trackNumber != null
                || lyrics != null || albumArt != null;
        }

        /**
         * Returns a debug representation of this bundle.
         *
         * @return A string describing each field's state
         */
        @NonNull
        @Override
        public String toString() {
            return "UpdateBundle{" +
                    "title=" + (title != null ? "'" + title + "'" : "null") +
                    ", artist=" + (artist != null ? "'" + artist + "'" : "null") +
                    ", album=" + (album != null ? "'" + album + "'" : "null") +
                    ", year=" + (year != null ? "'" + year + "'" : "null") +
                    ", genre=" + (genre != null ? "'" + genre + "'" : "null") +
                    ", trackNumber=" + (trackNumber != null ? "'" + trackNumber + "'" : "null") +
                    ", lyrics=" + (lyrics != null ? "[set]" : "null") +
                    ", albumArt=" + (albumArt != null ? (albumArt.length + " bytes") : "null") +
                    '}';
        }
    }

    // ========================================================================
    // Public Write Methods
    // ========================================================================

    /**
     * Applies the given metadata changes to the file referenced by the
     * given document URI.
     *
     * <p>The file is copied to the cache, a backup is created, the
     * changes are written to the cached copy, the cached copy is
     * verified as valid audio, and the cached copy is copied back to the
     * URI. Any failure after the backup is taken restores the original
     * file from that backup.</p>
     *
     * @param context Context used to open the URI and access the cache
     * @param documentUri Document URI of the audio file
     * @param update Metadata changes to apply
     * @return A result whose status is the outcome of the operation
     */
    @NonNull
    public static WriteResult writeMetadataToUri(@NonNull final Context context,
                                                 @NonNull final Uri documentUri,
                                                 @NonNull final UpdateBundle update) {
        synchronized (sWriteLock) {
            File tempFile = null;
            File backupFile = null;

            try {
                Log.d(TAG, "Starting metadata write to URI: " + documentUri);
                Log.d(TAG, "Update bundle: " + update);

                final DocumentFile document = DocumentFile.fromSingleUri(context, documentUri);
                if (document == null || !document.canWrite()) {
                    Log.e(TAG, "No write permission for URI: " + documentUri);
                    return WriteResult.failed(WriteResult.Status.PERMISSION_DENIED,
                        "No write permission for file");
                }

                tempFile = copyUriToCache(context, documentUri);
                if (tempFile == null) {
                    Log.e(TAG, "Failed to copy file from URI");
                    return WriteResult.failed(WriteResult.Status.COPY_FAILED,
                        "Failed to copy file from URI");
                }

                Log.d(TAG, "Copied to temp file: " + tempFile.getAbsolutePath()
                    + " (" + tempFile.length() + " bytes)");

                backupFile = new File(context.getCacheDir(),
                        "backup_" + SystemClock.elapsedRealtime() + "_" + tempFile.getName());
                if (!copyFile(tempFile, backupFile)) {
                    deleteFileSafely(tempFile);
                    return WriteResult.failed(WriteResult.Status.BACKUP_FAILED,
                        "Failed to create backup");
                }

                Log.d(TAG, "Backup created: " + backupFile.getAbsolutePath());

                if (!writeMetadataToFileInternal(tempFile, update)) {
                    Log.e(TAG, "Failed to write metadata, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.WRITE_FAILED_RESTORED,
                        "Failed to write metadata");
                }

                Log.d(TAG, "Metadata written, temp file size: " + tempFile.length() + " bytes");

                if (!verifyAudioFile(tempFile)) {
                    Log.e(TAG, "Verification failed, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.VERIFY_FAILED_RESTORED,
                        "Verification failed");
                }

                if (!copyCacheToUri(context, tempFile, documentUri)) {
                    Log.e(TAG, "Failed to write back to original URI, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failed(WriteResult.Status.COPY_BACK_FAILED_RESTORED,
                        "Failed to write back to original");
                }

                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                Log.d(TAG, "Successfully wrote metadata to: " + documentUri);
                return WriteResult.written();

            } catch (Exception exception) {
                Log.e(TAG, "Unexpected error during metadata write", exception);
                if (backupFile != null && backupFile.exists() && tempFile != null) {
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                }
                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                final String errorMessage = exception.getMessage() != null
                    ? exception.getMessage() : "Unknown error";
                return WriteResult.failed(WriteResult.Status.FAILED, errorMessage);
            }
        }
    }

    // ========================================================================
    // Private Write Helper Methods
    // ========================================================================

    /**
     * Writes the given changes to the given file with jaudiotagger.
     *
     * <p>Applies the null, empty, and non-empty rules of
     * {@link UpdateBundle} to every field, then commits the tag to the
     * file.</p>
     *
     * @param file The file to write to
     * @param update The changes to apply
     * @return True when the file was written without error
     */
    private static boolean writeMetadataToFileInternal(@NonNull final File file,
                                                       @NonNull final UpdateBundle update) {
        AudioFile audioFile = null;

        try {
            Log.d(TAG, "=== Starting metadata write ===");
            Log.d(TAG, "File: " + file.getAbsolutePath());

            audioFile = AudioFileIO.read(file);
            if (audioFile == null) {
                Log.e(TAG, "AudioFileIO.read returned null");
                return false;
            }

            Tag tag = audioFile.getTag();
            if (tag == null) {
                Log.d(TAG, "No existing tag, creating default tag");
                tag = audioFile.createDefaultTag();
                audioFile.setTag(tag);
            }

            Log.d(TAG, "Tag class: " + tag.getClass().getName());

            setOrDeleteField(tag, FieldKey.TITLE, update.title);
            setOrDeleteField(tag, FieldKey.ARTIST, update.artist);
            setOrDeleteField(tag, FieldKey.ALBUM, update.album);
            setOrDeleteField(tag, FieldKey.YEAR, update.year);
            setOrDeleteField(tag, FieldKey.GENRE, update.genre);
            setOrDeleteField(tag, FieldKey.TRACK, update.trackNumber);
            setOrDeleteField(tag, FieldKey.LYRICS, update.lyrics);

            if (update.albumArt != null) {
                try {
                    tag.deleteArtworkField();
                    Log.d(TAG, "Deleted existing artwork");
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to delete existing artwork: "
                        + exception.getMessage());
                }

                if (update.albumArt.length > 0) {
                    final Artwork artwork = createArtworkFromBytes(
                        update.albumArt, file.getParentFile());
                    if (artwork != null) {
                        try {
                            tag.setField(artwork);
                            Log.d(TAG, "Album art set successfully");
                        } catch (Exception exception) {
                            Log.e(TAG, "Failed to set album art: "
                                + exception.getMessage());
                            return false;
                        }
                    } else {
                        Log.e(TAG, "Could not create Artwork object");
                        return false;
                    }
                } else {
                    Log.d(TAG, "Album art deleted");
                }
            } else {
                Log.d(TAG, "Album art unchanged");
            }

            audioFile.commit();
            Log.d(TAG, "=== Metadata commit successful ===");
            return true;

        } catch (Exception exception) {
            Log.e(TAG, "writeMetadataToFileInternal failed: "
                + exception.getMessage(), exception);
            return false;
        }
    }

    /**
     * Applies the given value to the given field.
     *
     * @param tag The tag to modify
     * @param key The field to modify
     * @param value The new value; null for no change, empty to delete,
     *        non-empty to replace
     */
    private static void setOrDeleteField(@NonNull final Tag tag,
                                         @NonNull final FieldKey key,
                                         @Nullable final String value) {
        try {
            if (value == null) {
                Log.d(TAG, "Field " + key + ": no change");
                return;
            }

            final String trimmed = value.trim();
            if (trimmed.isEmpty()) {
                tag.deleteField(key);
                Log.d(TAG, "Deleted field: " + key);
            } else {
                tag.setField(key, trimmed);
                Log.d(TAG, "Set field " + key + " = '" + trimmed + "'");
            }
        } catch (Exception exception) {
            Log.w(TAG, "Failed to set/delete field " + key + ": "
                + exception.getMessage());
        }
    }

    /**
     * Creates an {@link Artwork} object from the given bytes.
     *
     * <p>Attempts {@code ArtworkFactory.createArtworkFromFile} first,
     * then falls back to {@code ArtworkFactory.createArtworkFromData}.
     * Returns null when both attempts fail or when the byte array is
     * empty or larger than {@link #MAX_ALBUM_ART_BYTES}.</p>
     *
     * @param albumArtBytes JPEG bytes to embed
     * @param parentDir Directory for the temporary file used by the file
     *        factory; null selects the JVM temporary directory
     * @return An artwork object, or null when none could be created
     */
    @Nullable
    private static Artwork createArtworkFromBytes(@NonNull final byte[] albumArtBytes,
                                                   @Nullable final File parentDir) {
        if (albumArtBytes.length == 0 || albumArtBytes.length > MAX_ALBUM_ART_BYTES) {
            Log.e(TAG, "Invalid album art size: " + albumArtBytes.length);
            return null;
        }

        File tempFile = null;
        try {
            final File tempDir = (parentDir != null) ? parentDir :
                new File(System.getProperty("java.io.tmpdir"));
            tempFile = File.createTempFile("album_art_", ".jpg", tempDir);

            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(tempFile);
                fileOutputStream.write(albumArtBytes);
                fileOutputStream.flush();
                Log.d(TAG, "Wrote album art to temp file: " + tempFile.getAbsolutePath()
                    + " (" + tempFile.length() + " bytes)");
            } finally {
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException exception) {
                        // The stream is already closed.
                    }
                }
            }

            try {
                final Method method = ArtworkFactory.class.getMethod(
                    "createArtworkFromFile", File.class);
                final Artwork artwork = (Artwork) method.invoke(null, tempFile);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromFile()");
                    return artwork;
                }
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromFile not found");
            } catch (Exception exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromFile failed: "
                    + exception.getMessage());
            }

            try {
                final Method method = ArtworkFactory.class.getMethod(
                    "createArtworkFromData", byte[].class);
                final Artwork artwork = (Artwork) method.invoke(null, (Object) albumArtBytes);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromData()");
                    return artwork;
                }
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromData not found");
            } catch (Exception exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromData failed: "
                    + exception.getMessage());
            }

            return null;

        } catch (Exception exception) {
            Log.e(TAG, "Failed to create artwork: " + exception.getMessage(), exception);
            return null;
        } finally {
            if (tempFile != null && tempFile.exists()) {
                final boolean deleted = tempFile.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete temp art file");
                }
            }
        }
    }

    // ========================================================================
    // File Helper Methods
    // ========================================================================

    /**
     * Copies the file referenced by the given URI into the application
     * cache directory, using the source file's extension for the cache
     * file's name.
     *
     * <p>The extension is derived from the source document's display
     * name so jaudiotagger invokes the reader that matches the actual
     * format. Naming every cached file {@code .mp3} would force the MP3
     * reader onto FLAC, OGG, M4A, and MP4 sources.</p>
     *
     * @param context Context used to open the URI and access the cache
     * @param uri URI of the file to copy
     * @return The cache file, or null when the copy fails
     */
    @Nullable
    private static File copyUriToCache(@NonNull final Context context,
                                       @NonNull final Uri uri) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: " + uri);
                return null;
            }
            final String extension = determineSourceExtension(context, uri);
            final File outFile = new File(context.getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + "." + extension);
            outputStream = new FileOutputStream(outFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Copied " + totalBytes + " bytes from URI to cache");
            return outFile;
        } catch (IOException exception) {
            Log.e(TAG, "copyUriToCache failed: " + exception.getMessage());
            return null;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Returns the extension to use for the cache file created from the
     * given document URI.
     *
     * <p>Prefers the {@link DocumentFile}'s name and falls back to
     * {@link #DEFAULT_EXTENSION} when the source name cannot be
     * resolved.</p>
     *
     * @param context Context used to build the document file
     * @param uri Document URI to inspect
     * @return The extension to use, without a leading dot
     */
    @NonNull
    private static String determineSourceExtension(@NonNull final Context context,
                                                   @NonNull final Uri uri) {
        try {
            final DocumentFile doc = DocumentFile.fromSingleUri(context, uri);
            if (doc != null && doc.getName() != null) {
                final String name = doc.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0 && dotIndex < name.length() - 1) {
                    return name.substring(dotIndex + 1);
                }
            }
        } catch (Exception ignored) {
            // Fall through to the default extension.
        }
        return DEFAULT_EXTENSION;
    }

    /**
     * Copies the given cache file back to the given document URI.
     *
     * @param context Context used to open the output stream
     * @param cacheFile File to read from
     * @param uri Destination document URI
     * @return True when the copy succeeded
     */
    private static boolean copyCacheToUri(@NonNull final Context context,
                                          @NonNull final File cacheFile,
                                          @NonNull final Uri uri) {
        Log.d(TAG, "Writing cache file to URI: " + cacheFile.getAbsolutePath()
            + " (" + cacheFile.length() + " bytes)");

        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = new FileInputStream(cacheFile);
            final ContentResolver resolver = context.getContentResolver();
            outputStream = resolver.openOutputStream(uri, "wt");

            if (outputStream == null) {
                Log.e(TAG, "Failed to open output stream for URI: " + uri);
                return false;
            }

            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Successfully wrote " + totalBytes + " bytes to URI");
            return true;
        } catch (IOException exception) {
            Log.e(TAG, "copyCacheToUri failed: " + exception.getMessage(), exception);
            return false;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Copies the source file to the destination file.
     *
     * @param sourceFile File to read from
     * @param destinationFile File to write to
     * @return True when the copy succeeded
     */
    private static boolean copyFile(@NonNull final File sourceFile,
                                    @NonNull final File destinationFile) {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        try {
            fileInputStream = new FileInputStream(sourceFile);
            fileOutputStream = new FileOutputStream(destinationFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            while ((length = fileInputStream.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, length);
            }
            fileOutputStream.getFD().sync();
            return true;
        } catch (IOException exception) {
            Log.e(TAG, "copyFile failed: " + exception.getMessage());
            return false;
        } finally {
            closeQuietly(fileInputStream);
            closeQuietly(fileOutputStream);
        }
    }

    /**
     * Restores the original file from the given backup.
     *
     * @param original File to restore
     * @param backup Backup file to restore from
     * @return True when the restore succeeded
     */
    private static boolean restoreFromBackup(@NonNull final File original,
                                             @NonNull final File backup) {
        if (!backup.exists()) {
            Log.e(TAG, "Backup file doesn't exist: " + backup.getAbsolutePath());
            return false;
        }
        deleteFileSafely(original);
        final boolean success = backup.renameTo(original);
        Log.d(TAG, "Restore from backup: " + (success ? "success" : "failed"));
        return success;
    }

    /**
     * Deletes the given file, logging any failure.
     *
     * @param file File to delete, or null
     */
    private static void deleteFileSafely(@Nullable final File file) {
        if (file != null && file.exists()) {
            try {
                final boolean deleted = file.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete: " + file.getName());
                }
            } catch (SecurityException exception) {
                Log.w(TAG, "delete failed for " + file.getName() + ": "
                    + exception.getMessage());
            }
        }
    }

    /**
     * Returns whether the given file is a valid audio file.
     *
     * @param file File to verify
     * @return True when the file exists, is non-empty, and can be read
     *         by jaudiotagger
     */
    private static boolean verifyAudioFile(@NonNull final File file) {
        if (!file.exists() || file.length() == 0) {
            Log.e(TAG, "Verify failed: file doesn't exist or is empty");
            return false;
        }
        try {
            final AudioFile audioFile = AudioFileIO.read(file);
            final boolean valid = audioFile != null;
            Log.d(TAG, "Verify audio file: " + (valid ? "valid" : "failed"));
            return valid;
        } catch (Exception exception) {
            Log.e(TAG, "Verify failed with exception: " + exception.getMessage());
            return false;
        }
    }

    /**
     * Closes the given {@link java.io.Closeable}, ignoring any exception.
     *
     * @param closeable The closeable to close, or null
     */
    private static void closeQuietly(@Nullable final java.io.Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException exception) {
                // The closeable is already closed.
            }
        }
    }
}