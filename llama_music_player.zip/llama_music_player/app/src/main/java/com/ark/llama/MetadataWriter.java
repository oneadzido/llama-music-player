package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;
import org.jaudiotagger.tag.images.ArtworkFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

/**
 * Utility class for writing audio file metadata with safety guarantees.
 * 
 * <p>This class provides write operations for ID3 tags and other metadata
 * with the following guarantees:</p>
 * 
 * <ul>
 *   <li><b>Null means "no change"</b> - Fields set to null are left untouched</li>
 *   <li><b>Empty string means "delete field"</b> - Fields set to empty string are removed</li>
 *   <li><b>Automatic backup and restore</b> - On failure, original file is restored</li>
 *   <li><b>Verification after write</b> - Ensures file is still valid audio</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses a global write lock to prevent concurrent write operations.
 * All methods are static and use synchronized blocks for thread safety.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.0
 * @since 1.0
 */
public final class MetadataWriter {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MetadataWriter";
    
    /** Buffer size for file copy operations (8KB). */
    private static final int COPY_BUFFER_SIZE = 8192;
    
    /** Max size for album art in bytes (1MB). */
    private static final int MAX_ALBUM_ART_BYTES = 1024 * 1024;
    
    /** Lock object for thread-safe write operations. */
    @NonNull
    private static final Object sWriteLock = new Object();
    
    // ========================================================================
    // Private Constructor
    // ========================================================================
    
    private MetadataWriter() {
        // Private constructor to prevent instantiation
    }
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Result container for metadata write operations.
     */
    public static final class WriteResult {
        
        /** True if the write operation succeeded. */
        public final boolean success;
        
        /** Error message if the operation failed (null on success). */
        @Nullable
        public final String errorMessage;
        
        /** True if a backup was restored after failure. */
        public final boolean backupRestored;
        
        /**
         * Private constructor for WriteResult.
         *
         * @param success True if successful
         * @param errorMessage Error message (null on success)
         * @param backupRestored True if backup was restored
         */
        private WriteResult(final boolean success, 
                           @Nullable final String errorMessage, 
                           final boolean backupRestored) {
            this.success = success;
            this.errorMessage = errorMessage;
            this.backupRestored = backupRestored;
        }
        
        /**
         * Creates a success result.
         *
         * @return Success WriteResult
         */
        @NonNull
        public static WriteResult success() {
            return new WriteResult(true, null, false);
        }
        
        /**
         * Creates a failure result.
         *
         * @param errorMessage The error message
         * @return Failure WriteResult
         */
        @NonNull
        public static WriteResult failure(@NonNull final String errorMessage) {
            return new WriteResult(false, errorMessage, false);
        }
        
        /**
         * Creates a failure result with backup restoration.
         *
         * @param errorMessage The error message
         * @param backupRestored True if backup was restored
         * @return Failure WriteResult
         */
        @NonNull
        public static WriteResult failureWithRestore(@NonNull final String errorMessage, 
                                                      final boolean backupRestored) {
            return new WriteResult(false, errorMessage, backupRestored);
        }
        
        /**
         * Returns a string representation of the result.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "WriteResult{" +
                    "success=" + success +
                    ", errorMessage='" + errorMessage + '\'' +
                    ", backupRestored=" + backupRestored +
                    '}';
        }
    }
    
    /**
     * Update bundle for metadata changes.
     * 
     * <p>Fields set to null will be left unchanged.
     * Fields set to empty string will be deleted from the file.
     * Fields with non-empty values will be set to that value.</p>
     */
    public static final class UpdateBundle {
        
        /** New title (null = no change, empty = delete). */
        @Nullable
        public String title;
        
        /** New artist (null = no change, empty = delete). */
        @Nullable
        public String artist;
        
        /** New album (null = no change, empty = delete). */
        @Nullable
        public String album;
        
        /** New year (null = no change, empty = delete). */
        @Nullable
        public String year;
        
        /** New genre (null = no change, empty = delete). */
        @Nullable
        public String genre;
        
        /** New track number (null = no change, empty = delete). */
        @Nullable
        public String trackNumber;
        
        /** New lyrics (null = no change, empty = delete). */
        @Nullable
        public String lyrics;
        
        /** 
         * New album art bytes.
         * null = no change to album art
         * empty array = delete album art
         * non-empty = set new album art
         */
        @Nullable
        public byte[] albumArt;
        
        /**
         * Creates an empty UpdateBundle.
         */
        public UpdateBundle() {
            // Default constructor
        }
        
        /**
         * Checks if any changes are requested.
         *
         * @return True if any field is non-null (including empty strings)
         */
        public boolean hasChanges() {
            return title != null || artist != null || album != null || 
                   year != null || genre != null || trackNumber != null || 
                   lyrics != null || albumArt != null;
        }
        
        /**
         * Returns a string representation of the update bundle for debugging.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "UpdateBundle{" +
                    "title=" + (title != null ? "'" + title + "'" : "null") +
                    ", artist=" + (artist != null ? "'" + artist + "'" : "null") +
                    ", album=" + (album != null ? "'" + album + "'" : "null") +
                    ", year=" + (year != null ? "'" + year + "'" : "null") +
                    ", genre=" + (genre != null ? "'" + genre + "'" : "null") +
                    ", trackNumber=" + (trackNumber != null ? "'" + trackNumber + "'" : "null") +
                    ", lyrics=" + (lyrics != null ? "[set]" : "null") +
                    ", albumArt=" + (albumArt != null ? (albumArt.length + " bytes") : "null") +
                    '}';
        }
    }
    
    // ========================================================================
    // Public Write Methods
    // ========================================================================
    
    /**
     * Writes metadata to an audio file accessed via a document URI (SAF).
     * 
     * <p>This is the primary method for SAF-based write operations. It handles
     * backup, restore, and verification automatically.</p>
     * 
     * <p>This method is thread-safe using a global write lock.</p>
     *
     * @param context Application context
     * @param documentUri Document URI for the audio file
     * @param update Metadata changes to apply (null fields = no change)
     * @return WriteResult indicating success or failure
     */
    @NonNull
    public static WriteResult writeMetadataToUri(@NonNull final Context context,
                                                 @NonNull final Uri documentUri,
                                                 @NonNull final UpdateBundle update) {
        synchronized (sWriteLock) {
            File tempFile = null;
            File backupFile = null;
            
            try {
                Log.d(TAG, "Starting metadata write to URI: " + documentUri);
                Log.d(TAG, "Update bundle: " + update);
                
                // First, check if we have write permission
                final DocumentFile doc = DocumentFile.fromSingleUri(context, documentUri);
                if (doc == null || !doc.canWrite()) {
                    Log.e(TAG, "No write permission for URI: " + documentUri);
                    return WriteResult.failure("No write permission for file");
                }
                
                // Copy file to temp location
                tempFile = copyUriToCache(context, documentUri);
                if (tempFile == null) {
                    Log.e(TAG, "Failed to copy file from URI");
                    return WriteResult.failure("Failed to copy file from URI");
                }
                
                Log.d(TAG, "Copied to temp file: " + tempFile.getAbsolutePath() + 
                      " (" + tempFile.length() + " bytes)");
                
                // Create backup
                backupFile = new File(context.getCacheDir(),
                        "backup_" + SystemClock.elapsedRealtime() + "_" + tempFile.getName());
                if (!copyFile(tempFile, backupFile)) {
                    deleteFileSafely(tempFile);
                    return WriteResult.failure("Failed to create backup");
                }
                
                Log.d(TAG, "Backup created: " + backupFile.getAbsolutePath());
                
                // Write metadata to temp file
                if (!writeMetadataToFileInternal(tempFile, update)) {
                    Log.e(TAG, "Failed to write metadata, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failureWithRestore("Failed to write metadata", true);
                }
                
                Log.d(TAG, "Metadata written, temp file size: " + tempFile.length() + " bytes");
                
                // Verify the written file is still valid audio
                if (!verifyAudioFile(tempFile)) {
                    Log.e(TAG, "Verification failed, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failureWithRestore("Verification failed", true);
                }
                
                // Write back to original URI
                if (!copyCacheToUri(context, tempFile, documentUri)) {
                    Log.e(TAG, "Failed to write back to original URI, restoring from backup");
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                    deleteFileSafely(tempFile);
                    deleteFileSafely(backupFile);
                    return WriteResult.failureWithRestore("Failed to write back to original", true);
                }
                
                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                Log.d(TAG, "Successfully wrote metadata to: " + documentUri);
                return WriteResult.success();
                
            } catch (Exception e) {
                Log.e(TAG, "Unexpected error during metadata write", e);
                if (backupFile != null && backupFile.exists() && tempFile != null) {
                    restoreFromBackup(tempFile, backupFile);
                    copyCacheToUri(context, tempFile, documentUri);
                }
                deleteFileSafely(tempFile);
                deleteFileSafely(backupFile);
                final String errorMessage = e.getMessage() != null ? e.getMessage() : "Unknown error";
                return WriteResult.failureWithRestore(errorMessage, true);
            }
        }
    }
    
    // ========================================================================
    // Private Write Helper Methods
    // ========================================================================
    
    /**
     * Internal method that writes metadata to a file using jaudiotagger.
     * 
     * <p>This method implements the null = no change, empty = delete logic.</p>
     *
     * @param file The file to write metadata to
     * @param update The metadata changes to apply
     * @return True if successful
     */
    private static boolean writeMetadataToFileInternal(@NonNull final File file, 
                                                       @NonNull final UpdateBundle update) {
        AudioFile audioFile = null;
        
        try {
            Log.d(TAG, "=== Starting metadata write ===");
            Log.d(TAG, "File: " + file.getAbsolutePath());
            
            audioFile = AudioFileIO.read(file);
            if (audioFile == null) {
                Log.e(TAG, "AudioFileIO.read returned null");
                return false;
            }
            
            Tag tag = audioFile.getTag();
            if (tag == null) {
                Log.d(TAG, "No existing tag, creating default tag");
                tag = audioFile.createDefaultTag();
                audioFile.setTag(tag);
            }
            
            Log.d(TAG, "Tag class: " + tag.getClass().getName());
            
            // Apply text field updates
            setOrDeleteField(tag, FieldKey.TITLE, update.title);
            setOrDeleteField(tag, FieldKey.ARTIST, update.artist);
            setOrDeleteField(tag, FieldKey.ALBUM, update.album);
            setOrDeleteField(tag, FieldKey.YEAR, update.year);
            setOrDeleteField(tag, FieldKey.GENRE, update.genre);
            setOrDeleteField(tag, FieldKey.TRACK, update.trackNumber);
            setOrDeleteField(tag, FieldKey.LYRICS, update.lyrics);
            
            // Handle album art
            if (update.albumArt != null) {
                // Delete existing artwork first
                try {
                    tag.deleteArtworkField();
                    Log.d(TAG, "Deleted existing artwork");
                } catch (Exception e) {
                    Log.w(TAG, "Failed to delete existing artwork: " + e.getMessage());
                }
                
                if (update.albumArt.length > 0) {
                    // New album art provided - write it
                    final Artwork artwork = createArtworkFromBytes(update.albumArt, file.getParentFile());
                    if (artwork != null) {
                        try {
                            tag.setField(artwork);
                            Log.d(TAG, "Album art set successfully");
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to set album art: " + e.getMessage());
                            return false;
                        }
                    } else {
                        Log.e(TAG, "Could not create Artwork object");
                        return false;
                    }
                } else {
                    // Empty array means delete album art (already handled by deleteArtworkField)
                    Log.d(TAG, "Album art deleted");
                }
            } else {
                // albumArt is null - no change to album art
                Log.d(TAG, "Album art unchanged");
            }
            
            // Commit changes
            audioFile.commit();
            Log.d(TAG, "=== Metadata commit successful ===");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "writeMetadataToFileInternal failed: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Sets or deletes a field in the tag.
     *
     * @param tag The tag to modify
     * @param key The field key
     * @param value The value to set:
     *        null = no change
     *        empty string = delete field
     *        non-empty = set field
     */
    private static void setOrDeleteField(@NonNull final Tag tag, 
                                         @NonNull final FieldKey key, 
                                         @Nullable final String value) {
        try {
            if (value == null) {
                // null = no change - skip entirely
                Log.d(TAG, "Field " + key + ": no change");
                return;
            }
            
            final String trimmed = value.trim();
            if (trimmed.isEmpty()) {
                // Empty = delete field
                tag.deleteField(key);
                Log.d(TAG, "Deleted field: " + key);
            } else {
                // Non-empty = set field
                tag.setField(key, trimmed);
                Log.d(TAG, "Set field " + key + " = '" + trimmed + "'");
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed to set/delete field " + key + ": " + e.getMessage());
        }
    }
    
    /**
     * Creates an Artwork object from byte data.
     *
     * @param albumArtBytes The album art bytes (JPEG format)
     * @param parentDir Parent directory for temporary files
     * @return Artwork object, or null if creation fails
     */
    @Nullable
    private static Artwork createArtworkFromBytes(@NonNull final byte[] albumArtBytes, 
                                                   @Nullable final File parentDir) {
        if (albumArtBytes.length == 0 || albumArtBytes.length > MAX_ALBUM_ART_BYTES) {
            Log.e(TAG, "Invalid album art size: " + albumArtBytes.length);
            return null;
        }
        
        File tempFile = null;
        try {
            final File tempDir = (parentDir != null) ? parentDir : 
                new File(System.getProperty("java.io.tmpdir"));
            tempFile = File.createTempFile("album_art_", ".jpg", tempDir);
            
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(tempFile);
                fos.write(albumArtBytes);
                fos.flush();
                Log.d(TAG, "Wrote album art to temp file: " + tempFile.getAbsolutePath() + 
                      " (" + tempFile.length() + " bytes)");
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        // Ignore
                    }
                }
            }
            
            // Try to create artwork from file
            try {
                final Method method = ArtworkFactory.class.getMethod("createArtworkFromFile", File.class);
                final Artwork artwork = (Artwork) method.invoke(null, tempFile);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromFile()");
                    return artwork;
                }
            } catch (NoSuchMethodException e) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromFile not found");
            } catch (Exception e) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromFile failed: " + e.getMessage());
            }
            
            // Fallback: create from data
            try {
                final Method method = ArtworkFactory.class.getMethod("createArtworkFromData", byte[].class);
                final Artwork artwork = (Artwork) method.invoke(null, (Object) albumArtBytes);
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromData()");
                    return artwork;
                }
            } catch (NoSuchMethodException e) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromData not found");
            } catch (Exception e) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromData failed: " + e.getMessage());
            }
            
            return null;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to create artwork: " + e.getMessage(), e);
            return null;
        } finally {
            if (tempFile != null && tempFile.exists()) {
                final boolean deleted = tempFile.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete temp art file");
                }
            }
        }
    }
    
    // ========================================================================
    // File Helper Methods
    // ========================================================================
    
    /**
     * Copies a file from a document URI to the cache directory.
     *
     * @param context Application context
     * @param uri The document URI to copy from
     * @return The cached file, or null if copy fails
     */
    @Nullable
    private static File copyUriToCache(@NonNull final Context context, 
                                       @NonNull final Uri uri) {
        InputStream in = null;
        OutputStream out = null;
        try {
            in = context.getContentResolver().openInputStream(uri);
            if (in == null) {
                Log.e(TAG, "openInputStream returned null for URI: " + uri);
                return null;
            }
            final File outFile = new File(context.getCacheDir(), 
                "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            out = new FileOutputStream(outFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int len;
            long totalBytes = 0;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
                totalBytes += len;
            }
            out.flush();
            Log.d(TAG, "Copied " + totalBytes + " bytes from URI to cache");
            return outFile;
        } catch (IOException e) {
            Log.e(TAG, "copyUriToCache failed: " + e.getMessage());
            return null;
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
    }
    
    /**
     * Copies a cache file back to a document URI.
     *
     * @param context Application context
     * @param cacheFile The cached file to copy from
     * @param uri The destination document URI
     * @return True if copy succeeds
     */
    private static boolean copyCacheToUri(@NonNull final Context context, 
                                          @NonNull final File cacheFile, 
                                          @NonNull final Uri uri) {
        Log.d(TAG, "Writing cache file to URI: " + cacheFile.getAbsolutePath() + 
              " (" + cacheFile.length() + " bytes)");
        
        InputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(cacheFile);
            final ContentResolver resolver = context.getContentResolver();
            out = resolver.openOutputStream(uri, "wt");
            
            if (out == null) {
                Log.e(TAG, "Failed to open output stream for URI: " + uri);
                return false;
            }
            
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int len;
            long totalBytes = 0;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
                totalBytes += len;
            }
            out.flush();
            Log.d(TAG, "Successfully wrote " + totalBytes + " bytes to URI");
            return true;
        } catch (IOException e) {
            Log.e(TAG, "copyCacheToUri failed: " + e.getMessage(), e);
            return false;
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
    }
    
    /**
     * Copies a file from source to destination.
     *
     * @param src Source file
     * @param dst Destination file
     * @return True if copy succeeds
     */
    private static boolean copyFile(@NonNull final File src, @NonNull final File dst) {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(src);
            out = new FileOutputStream(dst);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            out.getFD().sync();
            return true;
        } catch (IOException e) {
            Log.e(TAG, "copyFile failed: " + e.getMessage());
            return false;
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
    }
    
    /**
     * Restores a file from backup.
     *
     * @param original The original file to restore
     * @param backup The backup file
     * @return True if restore succeeds
     */
    private static boolean restoreFromBackup(@NonNull final File original, 
                                             @NonNull final File backup) {
        if (!backup.exists()) {
            Log.e(TAG, "Backup file doesn't exist: " + backup.getAbsolutePath());
            return false;
        }
        deleteFileSafely(original);
        final boolean success = backup.renameTo(original);
        Log.d(TAG, "Restore from backup: " + (success ? "success" : "failed"));
        return success;
    }
    
    /**
     * Safely deletes a file, logging any errors.
     *
     * @param file The file to delete (can be null)
     */
    private static void deleteFileSafely(@Nullable final File file) {
        if (file != null && file.exists()) {
            try {
                final boolean deleted = file.delete();
                if (!deleted) {
                    Log.w(TAG, "Failed to delete: " + file.getName());
                }
            } catch (SecurityException e) {
                Log.w(TAG, "delete failed for " + file.getName() + ": " + e.getMessage());
            }
        }
    }
    
    /**
     * Verifies that a file is a valid audio file.
     *
     * @param file The file to verify
     * @return True if the file is a valid audio file
     */
    private static boolean verifyAudioFile(@NonNull final File file) {
        if (!file.exists() || file.length() == 0) {
            Log.e(TAG, "Verify failed: file doesn't exist or is empty");
            return false;
        }
        try {
            final AudioFile audioFile = AudioFileIO.read(file);
            final boolean valid = audioFile != null;
            Log.d(TAG, "Verify audio file: " + (valid ? "valid" : "failed"));
            return valid;
        } catch (Exception e) {
            Log.e(TAG, "Verify failed with exception: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Closes a Closeable quietly.
     *
     * @param closeable The Closeable to close (can be null)
     */
    private static void closeQuietly(@Nullable final java.io.Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                // Ignore
            }
        }
    }
}