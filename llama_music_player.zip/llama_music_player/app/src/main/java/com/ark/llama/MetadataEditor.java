package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Edits the ID3 tags and album art of an audio file.
 *
 * <p>The editor has two modes. In VIEW MODE every field is read-only and
 * the primary action is MODIFY. In EDIT MODE every field is editable and
 * the primary action is UPDATE. Tapping MODIFY resolves a write-capable
 * URI for the file, either from the song database or by prompting the
 * user through the Storage Access Framework (SAF). Tapping UPDATE writes
 * the changed fields back to the file. The editor reads and writes tags
 * for MP3, FLAC, OGG, M4A, and WMA files.</p>
 *
 * <p>After a successful write, the activity publishes a single
 * {@code METADATA_UPDATED} broadcast carrying the new values. The
 * broadcast announces that a specific song's metadata changed; each
 * consumer ({@link MusicPlayer}, {@link PlaylistActivity}) reacts to the
 * broadcast according to its own concerns.</p>
 *
 * <h3>Result Contract</h3>
 * <p>A metadata read produces a {@link MetadataReader.MetadataBundle}
 * whose {@link MetadataReader.MetadataBundle#status} field distinguishes
 * {@code SUCCESS}, {@code FILE_UNREADABLE}, and {@code PARSE_FAILED}. A
 * write produces a {@link MetadataWriter.WriteResult} whose {@link
 * MetadataWriter.WriteResult#status} field enumerates every outcome the
 * writer can produce. This activity branches on those statuses for all
 * control flow; the error message field is used only for display and
 * logging.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>UI updates run on the main thread. Metadata reads and writes run on
 * the single-threaded executor created in {@link #onCreate(Bundle)} and
 * shut down in {@link #onDestroy()}. An {@link AtomicBoolean} guard
 * prevents concurrent save operations.</p>
 *
 * @see MetadataReader
 * @see MetadataWriter
 * @see StorageAccessHelper
 * @see NavigationController
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MetadataEditor extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "MetadataEditor";

    /** Request code for gallery image selection. */
    private static final int GALLERY_REQUEST_CODE = 400;

    /** Request code for the gallery permission request. */
    private static final int PERMISSION_GALLERY_REQUEST = 401;

    /** Request code for the SAF file picker. */
    private static final int REQUEST_SAF_FILE_PICKER = 402;

    /** UI mode: view-only. */
    private static final int MODE_VIEW = 0;

    /** UI mode: editable. */
    private static final int MODE_EDIT = 1;

    /** State: the song is not currently playing. */
    private static final int SONG_STATE_NOT_CURRENT = 0;

    /** State: the song was playing before the edit. */
    private static final int SONG_STATE_WAS_PLAYING = 1;

    /** State: the song was paused before the edit. */
    private static final int SONG_STATE_WAS_PAUSED = 2;

    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** JPEG compression quality for album art, 0 to 100. */
    private static final int ALBUM_ART_QUALITY = 95;

    /** Maximum length of the title field. */
    private static final int MAX_TITLE_LENGTH = 200;

    /** Maximum length of the artist field. */
    private static final int MAX_ARTIST_LENGTH = 200;

    /** Maximum length of the album field. */
    private static final int MAX_ALBUM_LENGTH = 200;

    /** Maximum length of the year field. */
    private static final int MAX_YEAR_LENGTH = 4;

    /** Maximum length of the genre field. */
    private static final int MAX_GENRE_LENGTH = 50;

    /** Maximum length of the track number field. */
    private static final int MAX_TRACK_LENGTH = 3;

    /** Maximum length of the lyrics field. */
    private static final int MAX_LYRICS_LENGTH = 5000;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before executing a button click action, in milliseconds. */
    private static final long CLICK_ACTION_DELAY_MS = 1000;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /** Size of the progress bar in density-independent pixels. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;

    /** Alpha value of the loading overlay dim, 0 to 255. */
    private static final int DIM_ALPHA = 180;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Delay before showing the keyboard on entering edit mode, in milliseconds. */
    private static final int KEYBOARD_SHOW_DELAY_MS = 1000;

    /** Delay before hiding the keyboard during an update, in milliseconds. */
    private static final int KEYBOARD_HIDE_DELAY_MS = 500;

    /** Delay before resuming playback after an edit, in milliseconds. */
    private static final int RESUME_PLAYBACK_DELAY_MS = 500;

    /** Intent extra flag indicating the editor is awaiting file selection. */
    private static final String EXTRA_AWAITING_FILE_SELECTION = "awaiting_file_selection";

    /** Shutdown timeout for the executor, in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;

    /** Broadcast action published after a successful write. */
    private static final String ACTION_METADATA_UPDATED = "METADATA_UPDATED";

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Button that cancels the edit and exits the activity. */
    @Nullable private Button mCancelButton;

    /** Primary action button; its label switches between SELECT, MODIFY, and UPDATE. */
    @Nullable private Button mActionButton;

    /** Header title showing the current mode. */
    @Nullable private TextView mHeaderTitle;

    /** Text view showing the file format. */
    @Nullable private TextView mFormatText;

    /** Image view displaying album art. */
    @Nullable private ImageView mAlbumArtView;

    /** Hint text shown below the album art in edit mode. */
    @Nullable private TextView mAlbumArtHint;

    /** EditText for the song title. */
    @Nullable private EditText mTitleEdit;

    /** EditText for the artist name. */
    @Nullable private EditText mArtistEdit;

    /** EditText for the album name. */
    @Nullable private EditText mAlbumEdit;

    /** EditText for the release year. */
    @Nullable private EditText mYearEdit;

    /** EditText for the genre. */
    @Nullable private EditText mGenreEdit;

    /** EditText for the track number. */
    @Nullable private EditText mTrackEdit;

    /** EditText for the lyrics. */
    @Nullable private EditText mLyricsEdit;

    /** EditText showing file size, bitrate, and duration. */
    @Nullable private EditText mFileInfoText;

    /** Scroll view containing the metadata form. */
    @Nullable private ScrollView mScrollView;

    /** Root layout used for touch handling. */
    @Nullable private LinearLayout mRootLayout;

    /** Container for album art, used for rounded-corner clipping. */
    @Nullable private FrameLayout mAlbumArtContainer;

    // ========================================================================
    // Data Components
    // ========================================================================

    /** Absolute path of the audio file. */
    @Nullable private String mFilePath;

    /** Cached song from the database, when one exists. */
    @Nullable private Song mOriginalSong;

    /** Metadata bundle as originally loaded. */
    @Nullable private MetadataReader.MetadataBundle mOriginalData;

    /** Current UI mode. */
    private int mCurrentMode = MODE_VIEW;

    /** True when any text field differs from the original value. */
    private boolean mHasTextChanges = false;

    /** True when album art was added or removed. */
    private boolean mAlbumArtChanged = false;

    /** New album art bytes, or null when unchanged. */
    @Nullable private byte[] mNewAlbumArt = null;

    /** True when album art was deleted. */
    private boolean mAlbumArtDeleted = false;

    /** SAF URI with write permission for the file. */
    @Nullable private Uri mGrantedFileUri = null;

    /** True while the activity is awaiting the file picker result. */
    private boolean mAwaitingFileSelection = false;

    /** Original title, used for change detection. */
    @Nullable private String mOriginalTitle;

    /** Original artist, used for change detection. */
    @Nullable private String mOriginalArtist;

    /** Original album, used for change detection. */
    @Nullable private String mOriginalAlbum;

    /** Original year, used for change detection. */
    @Nullable private String mOriginalYear;

    /** Original genre, used for change detection. */
    @Nullable private String mOriginalGenre;

    /** Original track number, used for change detection. */
    @Nullable private String mOriginalTrack;

    /** Original lyrics, used for change detection. */
    @Nullable private String mOriginalLyrics;

    /** Playback state of the song before editing. */
    private int mPreviousSongState = SONG_STATE_NOT_CURRENT;

    // ========================================================================
    // Managers and Helpers
    // ========================================================================

    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;

    /** Guard that prevents concurrent save operations. */
    @NonNull private final AtomicBoolean mIsSaving = new AtomicBoolean(false);

    /** Handler for UI operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for delayed actions. */
    @NonNull private final Handler mActionHandler = new Handler(Looper.getMainLooper());

    /** Executor for metadata reads and writes. */
    @Nullable private ExecutorService mExecutor;

    /** Manager for the current theme color. */
    @Nullable private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    @Nullable private ThemeHelper mThemeHelper;

    /** Timestamp of the last action button click. */
    private long mLastActionClickTime = 0;

    /** Timestamp of the last cancel button click. */
    private long mLastCancelClickTime = 0;

    /** Timestamp of the last modify click. */
    private long mLastModifyClickTime = 0;

    /** Timestamp of the last select click. */
    private long mLastSelectClickTime = 0;

    /** True while a file selection request is in progress. */
    private volatile boolean mRequestInProgress = false;

    /** Loading overlay shown during asynchronous work. */
    @Nullable private FrameLayout mLoadingOverlay;

    /** Currently running album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtTask = null;

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    /**
     * Initializes the activity, resolves the file from the intent, and
     * loads its metadata.
     *
     * <p>When the intent carries a file path or URI, the metadata is
     * loaded immediately. When the intent requests an awaiting-file state
     * and no file is available, a placeholder form is shown. When no
     * file is available and none is expected, the activity finishes with
     * a toast.</p>
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_metadata_editor);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        mExecutor = Executors.newSingleThreadExecutor();

        NavigationController.getInstance().registerListener(this);

        mFilePath = getIntent().getStringExtra("song_path");
        String songUri = getIntent().getStringExtra("song_uri");

        if (songUri != null) {
            mGrantedFileUri = Uri.parse(songUri);
        }

        if (mFilePath != null && mGrantedFileUri == null) {
            Song cachedSong = SongDatabase.getInstance(this).getSong(mFilePath);
            if (cachedSong != null && cachedSong.getUri() != null) {
                mGrantedFileUri = cachedSong.getContentUri();
                Log.d(TAG, "Retrieved URI from database cache: " + mGrantedFileUri);
            }
        }

        mAwaitingFileSelection = getIntent().getBooleanExtra(
            EXTRA_AWAITING_FILE_SELECTION, false);

        initializeViews();
        setupInputFilters();
        setupTextWatchers();

        if (mAwaitingFileSelection && mFilePath == null && mGrantedFileUri == null) {
            setPlaceholderUI();
        } else if (mFilePath == null && mGrantedFileUri == null) {
            ToastManager.showToast(this, "No file selected", ToastManager.LENGTH_NORMAL);
            finish();
            return;
        } else {
            if (mFilePath != null) {
                mOriginalSong = CharacterMapper.getSongFromFile(mFilePath);
            }
            loadMetadataAsync();
        }

        applyThemeToUI();
    }

    /**
     * Cancels in-flight album art and metadata loads, shuts down the
     * executor, and removes every handler callback.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        NavigationController.getInstance().unregisterListener(this);

        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
        }
        mMainHandler.removeCallbacksAndMessages(null);
        mActionHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Reapplies the current button-group state and refreshes the theme
     * colors of the activity's views.
     */
    @Override
    protected void onResume() {
        super.onResume();

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        applyThemeToUI();
    }

    /**
     * Hides the keyboard, applies the slide-down exit transition, and
     * finishes the activity.
     */
    @Override
    public void onBackPressed() {
        hideKeyboard();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
        super.onBackPressed();
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================

    /**
     * Enables or disables the action button according to the current
     * metadata-actions state.
     *
     * <p>While the button is labelled SELECT, it stays enabled so the
     * user can pick a file even when the metadata-actions group is
     * otherwise disabled.</p>
     *
     * @param group Button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.METADATA_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mActionButton == null) {
                        return;
                    }

                    String buttonText = mActionButton.getText().toString();

                    if ("SELECT".equals(buttonText)) {
                        mActionButton.setEnabled(true);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mActionButton, true);
                        }
                    } else {
                        mActionButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mActionButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    /**
     * Configures the activity window for full-screen immersive display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    /**
     * Resolves every view, attaches click listeners and touch handlers,
     * and initializes the placeholder state.
     */
    private void initializeViews() {
        mCancelButton = findViewById(R.id.cancelButton);
        mActionButton = findViewById(R.id.actionButton);
        mHeaderTitle = findViewById(R.id.headerTitle);
        mFormatText = findViewById(R.id.formatText);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtHint = findViewById(R.id.albumArtHint);
        mTitleEdit = findViewById(R.id.titleEdit);
        mArtistEdit = findViewById(R.id.artistEdit);
        mAlbumEdit = findViewById(R.id.albumEdit);
        mYearEdit = findViewById(R.id.yearEdit);
        mGenreEdit = findViewById(R.id.genreEdit);
        mTrackEdit = findViewById(R.id.trackEdit);
        mLyricsEdit = findViewById(R.id.lyricsEdit);
        mFileInfoText = findViewById(R.id.fileInfoText);
        mScrollView = findViewById(R.id.scrollView);
        mRootLayout = findViewById(R.id.rootLayout);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
        }

        if (mCancelButton != null) {
            mCancelButton.setText("CANCEL");
            mCancelButton.setBackgroundResource(R.drawable.button_border_selector);
        }

        if (mActionButton != null) {
            if (mFilePath != null || mGrantedFileUri != null) {
                mActionButton.setText("MODIFY");
            } else {
                mActionButton.setText("SELECT");
            }
            mActionButton.setBackgroundResource(R.drawable.button_border_selector);
        }

        if (mAlbumArtView != null) {
            mAlbumArtView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }

        animateButton(mCancelButton);
        animateButton(mActionButton);

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        handleCancelClick();
                    }
                }
            });
        }

        if (mActionButton != null) {
            mActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastActionClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastActionClickTime = currentTime;
                        handleModifyClick();
                    }
                }
            });
        }

        if (mAlbumArtView != null) {
            mAlbumArtView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) {
                        checkGalleryPermissionAndOpen();
                    }
                }
            });
        }

        if (mAlbumArtView != null) {
            mAlbumArtView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) {
                        removeAlbumArt();
                        return true;
                    }
                    return false;
                }
            });
        }

        if (mRootLayout != null) {
            mRootLayout.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        hideKeyboard();
                    }
                    return false;
                }
            });
        }

        setupLyricsScrolling();
        setFieldsEnabled(false);

        if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }
    }

    /**
     * Shows an empty form with SELECT as the primary action, for the case
     * in which no file has been chosen yet.
     */
    private void setPlaceholderUI() {
        setPlaceholderAlbumArt();
        if (mTitleEdit != null) mTitleEdit.setText("");
        if (mArtistEdit != null) mArtistEdit.setText("");
        if (mAlbumEdit != null) mAlbumEdit.setText("");
        if (mYearEdit != null) mYearEdit.setText("");
        if (mGenreEdit != null) mGenreEdit.setText("");
        if (mTrackEdit != null) mTrackEdit.setText("");
        if (mLyricsEdit != null) mLyricsEdit.setText("");
        if (mFormatText != null) mFormatText.setText("No file");
        if (mHeaderTitle != null) mHeaderTitle.setText("VIEW MODE");

        if (mFileInfoText != null) {
            mFileInfoText.setText(null);
            mFileInfoText.setTextColor(Color.parseColor("#5A5A5A"));
        }

        if (mActionButton != null) {
            mActionButton.setText("SELECT");
            setActionButtonEnabled(true);
        }
    }

    /**
     * Configures the lyrics EditText so its own scrolling does not
     * conflict with the parent ScrollView's scrolling.
     */
    private void setupLyricsScrolling() {
        if (mLyricsEdit == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            mLyricsEdit.setMovementMethod(
                new android.text.method.ScrollingMovementMethod());
        }

        mLyricsEdit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN && mScrollView != null) {
                    mScrollView.requestDisallowInterceptTouchEvent(true);
                }
                return false;
            }
        });

        mLyricsEdit.setTextIsSelectable(false);
        mLyricsEdit.setFocusable(false);
        mLyricsEdit.setFocusableInTouchMode(false);
        mLyricsEdit.setLongClickable(false);
        mLyricsEdit.setCustomSelectionActionModeCallback(null);
        mLyricsEdit.setCustomInsertionActionModeCallback(null);
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Action Button Handling
    // ========================================================================

    /**
     * Dispatches the action button click according to the current button
     * label and UI mode.
     */
    private void handleModifyClick() {
        String buttonText = mActionButton != null
            ? mActionButton.getText().toString() : "";

        if ("SELECT".equals(buttonText)) {
            long currentTime = SystemClock.elapsedRealtime();
            if (currentTime - mLastSelectClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                return;
            }
            mLastSelectClickTime = currentTime;

            ToastManager.showToast(this, "Please select an audio file",
                ToastManager.LENGTH_NORMAL);
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        openFilePicker();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }

        if (mCurrentMode == MODE_EDIT) {
            long currentTime = SystemClock.elapsedRealtime();
            if (currentTime - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                return;
            }
            mLastModifyClickTime = currentTime;

            if (NavigationController.getInstance().isGroupDisabled(
                    NavigationController.ButtonGroup.METADATA_ACTIONS)) {
                ToastManager.showToast(this,
                    "Please wait, playlist is syncing...",
                    ToastManager.LENGTH_NORMAL);
                return;
            }
            hideKeyboard();

            ToastManager.showToast(this, "Saving metadata...",
                ToastManager.LENGTH_NORMAL);
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        saveChanges();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }

        long currentTime = SystemClock.elapsedRealtime();
        if (currentTime - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) {
            return;
        }
        mLastModifyClickTime = currentTime;

        if (NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(this,
                "Please wait, playlist is syncing...",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        boolean hasValidUri = false;

        if (mFilePath != null) {
            hasValidUri = getStoredUri(mFilePath);
        }

        if (!hasValidUri && mGrantedFileUri != null && hasWritePermission(mGrantedFileUri)) {
            hasValidUri = true;
            saveUriToDatabase();
            Log.d(TAG, "MODIFY: Using existing mGrantedFileUri with write permission");
        }

        if (hasValidUri) {
            Log.d(TAG, "MODIFY: Successfully resolved URI, entering edit mode");
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        enterEditMode();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }

        Log.d(TAG, "MODIFY: No valid URI found, requesting SAF access");
        ToastManager.showToast(this,
            "Please reselect the file to enable editing",
            ToastManager.LENGTH_NORMAL);
        mActionHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    requestSafFileAccess();
                }
            }
        }, CLICK_ACTION_DELAY_MS);
    }

    /**
     * Opens the system file picker for audio file selection.
     */
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

        try {
            startActivityForResult(intent, REQUEST_SAF_FILE_PICKER);
        } catch (Exception exception) {
            ToastManager.showToast(this, "No file manager found",
                ToastManager.LENGTH_NORMAL);
            mRequestInProgress = false;
        }
    }

    /**
     * Requests SAF file access when write permission is needed.
     */
    private void requestSafFileAccess() {
        if (mIsSaving.get()) {
            ToastManager.showToast(this, "Please wait, saving in progress...",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        if (mRequestInProgress) {
            return;
        }
        mRequestInProgress = true;

        openFilePicker();

        mActionHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mRequestInProgress = false;
            }
        }, CLICK_ACTION_DELAY_MS);
    }

    // ========================================================================
    // Cancel Button Handling
    // ========================================================================

    /**
     * Handles the cancel button click according to the current mode.
     */
    private void handleCancelClick() {
        if (mCurrentMode == MODE_EDIT) {
            hideKeyboard();
            exitEditMode();
            ToastManager.showToast(this, "No changes saved",
                ToastManager.LENGTH_NORMAL);
        } else {
            onBackPressed();
        }
    }

    // ========================================================================
    // Input Setup Methods
    // ========================================================================

    /**
     * Attaches length and input-type filters to every edit field.
     */
    private void setupInputFilters() {
        if (mTitleEdit != null) {
            mTitleEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_TITLE_LENGTH)
            });
        }

        if (mArtistEdit != null) {
            mArtistEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_ARTIST_LENGTH)
            });
        }

        if (mAlbumEdit != null) {
            mAlbumEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_ALBUM_LENGTH)
            });
        }

        if (mYearEdit != null) {
            mYearEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_YEAR_LENGTH),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end,
                                               android.text.Spanned dest, int dstart, int dend) {
                        for (int index = start; index < end; index++) {
                            if (!Character.isDigit(source.charAt(index))) {
                                return "";
                            }
                        }
                        return null;
                    }
                }
            });
            mYearEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        }

        if (mGenreEdit != null) {
            mGenreEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_GENRE_LENGTH)
            });
        }

        if (mTrackEdit != null) {
            mTrackEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_TRACK_LENGTH),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end,
                                               android.text.Spanned dest, int dstart, int dend) {
                        for (int index = start; index < end; index++) {
                            if (!Character.isDigit(source.charAt(index))) {
                                return "";
                            }
                        }
                        return null;
                    }
                }
            });
            mTrackEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        }

        if (mLyricsEdit != null) {
            mLyricsEdit.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(MAX_LYRICS_LENGTH)
            });
            mLyricsEdit.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
    }

    /**
     * Attaches a text watcher to every edit field that recomputes the
     * change flag while in edit mode.
     */
    private void setupTextWatchers() {
        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (mCurrentMode == MODE_EDIT) {
                    detectTextChanges();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };

        if (mTitleEdit != null) mTitleEdit.addTextChangedListener(watcher);
        if (mArtistEdit != null) mArtistEdit.addTextChangedListener(watcher);
        if (mAlbumEdit != null) mAlbumEdit.addTextChangedListener(watcher);
        if (mYearEdit != null) mYearEdit.addTextChangedListener(watcher);
        if (mGenreEdit != null) mGenreEdit.addTextChangedListener(watcher);
        if (mTrackEdit != null) mTrackEdit.addTextChangedListener(watcher);
        if (mLyricsEdit != null) mLyricsEdit.addTextChangedListener(watcher);
    }

    /**
     * Compares the current edit field values against the originals and
     * updates {@link #mHasTextChanges}.
     */
    private void detectTextChanges() {
        String currentTitle = getEditTextDisplayValue(mTitleEdit);
        String currentArtist = getEditTextDisplayValue(mArtistEdit);
        String currentAlbum = getEditTextDisplayValue(mAlbumEdit);
        String currentYear = getEditTextDisplayValue(mYearEdit);
        String currentGenre = getEditTextDisplayValue(mGenreEdit);
        String currentTrack = getEditTextDisplayValue(mTrackEdit);
        String currentLyrics = getEditTextDisplayValue(mLyricsEdit);

        String titleToCompare = (currentTitle != null) ? currentTitle : "";
        String artistToCompare = (currentArtist != null) ? currentArtist : "";
        String albumToCompare = (currentAlbum != null) ? currentAlbum : "";
        String yearToCompare = (currentYear != null) ? currentYear : "";
        String genreToCompare = (currentGenre != null) ? currentGenre : "";
        String trackToCompare = (currentTrack != null) ? currentTrack : "";
        String lyricsToCompare = (currentLyrics != null) ? currentLyrics : "";

        String originalTitleToCompare = (mOriginalTitle != null) ? mOriginalTitle : "";
        String originalArtistToCompare = (mOriginalArtist != null) ? mOriginalArtist : "";
        String originalAlbumToCompare = (mOriginalAlbum != null) ? mOriginalAlbum : "";
        String originalYearToCompare = (mOriginalYear != null) ? mOriginalYear : "";
        String originalGenreToCompare = (mOriginalGenre != null) ? mOriginalGenre : "";
        String originalTrackToCompare = (mOriginalTrack != null) ? mOriginalTrack : "";
        String originalLyricsToCompare = (mOriginalLyrics != null) ? mOriginalLyrics : "";

        mHasTextChanges = !titleToCompare.equals(originalTitleToCompare)
            || !artistToCompare.equals(originalArtistToCompare)
            || !albumToCompare.equals(originalAlbumToCompare)
            || !yearToCompare.equals(originalYearToCompare)
            || !genreToCompare.equals(originalGenreToCompare)
            || !trackToCompare.equals(originalTrackToCompare)
            || !lyricsToCompare.equals(originalLyricsToCompare);
    }

    /**
     * Returns the trimmed text value of the given edit field.
     *
     * @param editText EditText to read, or null
     * @return The trimmed value, or null when the field is null or empty
     */
    @Nullable
    private String getEditTextDisplayValue(@Nullable EditText editText) {
        if (editText == null) {
            return null;
        }
        String value = editText.getText().toString().trim();
        return value.isEmpty() ? null : value;
    }

    /**
     * Returns the change to submit for the given edit field, or null when
     * the field is unchanged.
     *
     * @param editText EditText to read, or null
     * @param originalValue Original value for comparison, or null
     * @return The new value, an empty string when the original was cleared,
     *         or null when unchanged or the field is null
     */
    @Nullable
    private String getEditTextChangeValue(@Nullable EditText editText,
                                          @Nullable String originalValue) {
        if (editText == null) {
            return null;
        }
        String currentValue = editText.getText().toString().trim();
        String original = (originalValue != null) ? originalValue : "";

        if (currentValue.isEmpty() && !original.isEmpty()) {
            return "";
        }

        if (currentValue.equals(original)) {
            return null;
        }

        return currentValue.isEmpty() ? null : currentValue;
    }

    // ========================================================================
    // Song State Tracking
    // ========================================================================

    /**
     * Queries the service for the current playing state of the edited
     * song and pauses playback if it was playing.
     *
     * @return One of {@link #SONG_STATE_WAS_PLAYING},
     *         {@link #SONG_STATE_WAS_PAUSED}, or
     *         {@link #SONG_STATE_NOT_CURRENT}
     */
    private int checkCurrentSongState() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String lastPath = preferences.getString(KEY_LAST_SONG_PATH, null);

        if (mFilePath != null && mFilePath.equals(lastPath)) {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] wasPlaying = {false};

            BroadcastReceiver stateReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if ("PLAYING_STATE_RESPONSE".equals(intent.getAction())) {
                        wasPlaying[0] = intent.getBooleanExtra("is_playing", false);
                        latch.countDown();
                    }
                }
            };

            IntentFilter filter = new IntentFilter("PLAYING_STATE_RESPONSE");
            registerReceiver(stateReceiver, filter);

            Intent getStateIntent = new Intent("GET_PLAYING_STATE");
            sendBroadcast(getStateIntent);

            try {
                latch.await(150, TimeUnit.MILLISECONDS);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            } finally {
                try {
                    unregisterReceiver(stateReceiver);
                } catch (IllegalArgumentException exception) {
                    // The receiver was already unregistered.
                }
            }

            if (wasPlaying[0]) {
                sendBroadcast(new Intent("BLUETOOTH_PAUSE"));

                final CountDownLatch pauseLatch = new CountDownLatch(1);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        pauseLatch.countDown();
                    }
                }, 100);

                try {
                    pauseLatch.await(150, TimeUnit.MILLISECONDS);
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                }

                return SONG_STATE_WAS_PLAYING;
            } else {
                return SONG_STATE_WAS_PAUSED;
            }
        }

        return SONG_STATE_NOT_CURRENT;
    }

    // ========================================================================
    // Metadata Loading Methods
    // ========================================================================

    /**
     * Loads the metadata from the resolved URI or file path on the
     * executor, then reflects the result in the UI.
     */
    private void loadMetadataAsync() {
        showLoadingOverlay();
        if (mExecutor == null) {
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataReader.MetadataBundle metadataBundle;

                if (mGrantedFileUri != null) {
                    metadataBundle = MetadataReader.readMetadataFromUri(
                        MetadataEditor.this, mGrantedFileUri);
                    if (metadataBundle != null && mFilePath == null) {
                        String path = getFilePathFromUri(mGrantedFileUri);
                        if (path != null) {
                            mFilePath = path;
                        }
                    }
                } else if (mFilePath != null) {
                    metadataBundle = MetadataReader.readMetadata(mFilePath);
                } else {
                    metadataBundle = new MetadataReader.MetadataBundle();
                    metadataBundle.status =
                        MetadataReader.MetadataBundle.Status.FILE_UNREADABLE;
                    metadataBundle.format = "Unknown";
                }

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        hideLoadingOverlay();
                        mOriginalData = metadataBundle;
                        displayMetadata();
                        updateFileInfo();

                        switch (metadataBundle.status) {
                            case FILE_UNREADABLE:
                                setActionButtonEnabled(false);
                                ToastManager.showToast(MetadataEditor.this,
                                    "File not accessible", ToastManager.LENGTH_NORMAL);
                                break;
                            case PARSE_FAILED:
                                setActionButtonEnabled(false);
                                ToastManager.showToast(MetadataEditor.this,
                                    "Could not read metadata", ToastManager.LENGTH_NORMAL);
                                break;
                            case SUCCESS:
                            default:
                                if (!metadataBundle.isWriteSupported) {
                                    setActionButtonEnabled(false);
                                    ToastManager.showToast(MetadataEditor.this,
                                        "Cannot edit: " + metadataBundle.format + " format",
                                        ToastManager.LENGTH_NORMAL);
                                } else {
                                    setActionButtonEnabled(true);
                                    if (mActionButton != null && mCurrentMode == MODE_VIEW) {
                                        mActionButton.setText("MODIFY");
                                    }
                                }
                                break;
                        }
                    }
                });
            }
        });
    }

    /**
     * Returns the filesystem path for the given content URI.
     *
     * @param uri Content URI to inspect
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            path = uri.getPath();
            return path;
        }
        if ("content".equals(uri.getScheme())) {
            android.database.Cursor cursor = null;
            try {
                String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                Log.w(TAG, "Could not get file path from URI", exception);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    /**
     * Writes the loaded metadata into the edit fields and the album art
     * view, and caches the original values for change detection.
     */
    private void displayMetadata() {
        if (mOriginalData == null) {
            return;
        }

        mOriginalTitle = mOriginalData.title;
        mOriginalArtist = mOriginalData.artist;
        mOriginalAlbum = mOriginalData.album;
        mOriginalYear = mOriginalData.year;
        mOriginalGenre = mOriginalData.genre;
        mOriginalTrack = mOriginalData.trackNumber;
        mOriginalLyrics = mOriginalData.lyrics;

        if (mTitleEdit != null) {
            mTitleEdit.setText(mOriginalTitle != null ? mOriginalTitle : "");
        }
        if (mArtistEdit != null) {
            mArtistEdit.setText(mOriginalArtist != null ? mOriginalArtist : "");
        }
        if (mAlbumEdit != null) {
            mAlbumEdit.setText(mOriginalAlbum != null ? mOriginalAlbum : "");
        }
        if (mYearEdit != null) {
            mYearEdit.setText(mOriginalYear != null ? mOriginalYear : "");
        }
        if (mGenreEdit != null) {
            mGenreEdit.setText(mOriginalGenre != null ? mOriginalGenre : "");
        }
        if (mTrackEdit != null) {
            mTrackEdit.setText(mOriginalTrack != null ? mOriginalTrack : "");
        }
        if (mLyricsEdit != null) {
            mLyricsEdit.setText(mOriginalLyrics != null ? mOriginalLyrics : "");
        }

        if (mCurrentMode == MODE_VIEW) {
            refreshTextColors();
        }

        if (mOriginalData.hasAlbumArt()) {
            loadAlbumArtFromBytes(mOriginalData.albumArt);
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Long press to remove");
            } else if (mAlbumArtHint != null) {
                mAlbumArtHint.setVisibility(View.GONE);
            }
        } else {
            setPlaceholderAlbumArt();
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Tap to add album art");
            } else if (mAlbumArtHint != null) {
                mAlbumArtHint.setVisibility(View.GONE);
            }
        }
        applyAlbumArtClipping();
        updateHeaderForMode();
    }

    /**
     * Applies placeholder and real-value text colors to every edit field,
     * based on the current text.
     */
    private void refreshTextColors() {
        if (mCurrentMode != MODE_VIEW) {
            return;
        }

        EditText[] fields = {
            mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit,
            mGenreEdit, mTrackEdit, mLyricsEdit
        };

        for (EditText field : fields) {
            if (field == null) {
                continue;
            }

            String text = field.getText().toString();
            boolean isPlaceholder = (text == null || text.isEmpty()
                || "Unknown".equals(text) || "Unknown Title".equals(text)
                || "Unknown Artist".equals(text) || "Unknown Album".equals(text));

            if (isPlaceholder) {
                field.setTextColor(Color.parseColor("#808080"));
            } else {
                field.setTextColor(Color.parseColor("#C0C0C0"));
            }
        }
    }

    /**
     * Decodes the given album art bytes and displays them in the album
     * art view.
     *
     * @param albumArtBytes JPEG or PNG bytes to decode
     */
    private void loadAlbumArtFromBytes(@NonNull final byte[] albumArtBytes) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(
                        albumArtBytes, 0, albumArtBytes.length);
                    if (bitmap != null && mAlbumArtView != null) {
                        mAlbumArtView.setImageBitmap(bitmap);
                        mAlbumArtView.setColorFilter(null);
                        applyAlbumArtClipping();
                    } else {
                        setPlaceholderAlbumArt();
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to decode album art", exception);
                    setPlaceholderAlbumArt();
                }
            }
        });
    }

    /**
     * Sets the album art view to the themed placeholder image.
     */
    private void setPlaceholderAlbumArt() {
        if (mThemeHelper == null || mAlbumArtView == null) {
            return;
        }
        Drawable placeholder = mThemeHelper.createThemedAlbumArtPlaceholder();
        if (placeholder != null) {
            mAlbumArtView.setImageDrawable(placeholder);
        } else {
            mAlbumArtView.setImageResource(R.drawable.album_art_placeholder);
            mAlbumArtView.setColorFilter(
                mThemeHelper.getThemeColorInt(), PorterDuff.Mode.SRC_IN);
        }
        applyAlbumArtClipping();
    }

    /**
     * Updates the file info text with size, bitrate, and duration.
     */
    private void updateFileInfo() {
        if (mOriginalData == null || mFileInfoText == null) {
            return;
        }

        StringBuilder info = new StringBuilder();

        long bytes = mOriginalData.fileSize;
        if (bytes < 1024 * 1024) {
            float kilobytes = bytes / 1024.0f;
            info.append(String.format("%.0f KB", kilobytes));
        } else {
            float megabytes = bytes / (1024.0f * 1024.0f);
            info.append(String.format("%.1f MB", megabytes));
        }

        if (mGrantedFileUri != null || mFilePath != null) {
            MediaMetadataRetriever retriever = null;
            try {
                retriever = new MediaMetadataRetriever();
                if (mGrantedFileUri != null) {
                    retriever.setDataSource(this, mGrantedFileUri);
                } else if (mFilePath != null) {
                    retriever.setDataSource(mFilePath);
                }

                String bitrate = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_BITRATE);
                if (bitrate != null && !bitrate.isEmpty()) {
                    int kbps = Integer.parseInt(bitrate) / 1000;
                    info.append(" \u2022 ").append(kbps).append(" kbps");
                }

            } catch (Exception exception) {
                Log.w(TAG, "Could not read audio properties: " + exception.getMessage());
            } finally {
                if (retriever != null) {
                    try {
                        retriever.release();
                    } catch (Exception ignored) {
                        // The retriever is not in a state that permits release.
                    }
                }
            }
        }

        long durationMs = mOriginalData.duration;
        int totalSeconds = (int) (durationMs / 1000);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        String duration;
        if (hours > 0) {
            duration = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            duration = String.format("%02d:%02d", minutes, seconds);
        }
        info.append(" \u2022 ").append(duration);

        mFileInfoText.setText(info.toString());
        mFileInfoText.setSelected(false);
        mFileInfoText.setLongClickable(false);
        mFileInfoText.setTextIsSelectable(false);
        mFileInfoText.setTextColor(Color.parseColor("#C0C0C0"));

        if (mFormatText != null) {
            mFormatText.setText(mOriginalData.format.toUpperCase() + " file");
        }
    }

    /**
     * Applies rounded-corner clipping to the album art container.
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
        }
    }

    // ========================================================================
    // URI Resolution Methods
    // ========================================================================

    /**
     * Resolves a stored URI for the given file path from the song
     * database and verifies write permission.
     *
     * @param filePath Absolute file path
     * @return True when a write-capable URI was found
     */
    private boolean getStoredUri(@NonNull String filePath) {
        Song cachedSong = SongDatabase.getInstance(this).getSong(filePath);
        if (cachedSong != null && cachedSong.getUri() != null) {
            mGrantedFileUri = cachedSong.getContentUri();
            Log.d(TAG, "Found stored URI in database: " + mGrantedFileUri);

            if (mStorageHelper != null && mStorageHelper.reacquirePermission(mGrantedFileUri)) {
                Log.d(TAG, "Successfully reacquired permission for URI");
                return true;
            }

            if (hasWritePermission(mGrantedFileUri)) {
                Log.d(TAG, "URI has write permission");
                return true;
            }

            Log.w(TAG, "Cannot reacquire permission for URI, will need to reselect file");
            ToastManager.showToast(this, "Permission lost. Please select the file again",
                ToastManager.LENGTH_NORMAL);

            SongDatabase.getInstance(this).insertSong(new Song(
                cachedSong.getTitle(), cachedSong.getArtist(), cachedSong.getAlbum(),
                cachedSong.getGenre(),
                filePath, cachedSong.getDuration(), null));

            mGrantedFileUri = null;
            return false;
        }
        return false;
    }

    /**
     * Persists the currently granted URI for the current file path in the
     * song database.
     */
    private void saveUriToDatabase() {
        if (mFilePath == null || mGrantedFileUri == null) {
            return;
        }

        Song existingSong = SongDatabase.getInstance(this).getSong(mFilePath);
        if (existingSong != null) {
            Song updatedSong = new Song(
                existingSong.getTitle(),
                existingSong.getArtist(),
                existingSong.getAlbum(),
                existingSong.getGenre(),
                mFilePath,
                existingSong.getDuration(),
                mGrantedFileUri.toString()
            );
            SongDatabase.getInstance(this).insertSong(updatedSong);
            Log.d(TAG, "Updated existing song with URI: " + mFilePath);
        } else {
            Song newSong = new Song(
                mOriginalData != null && mOriginalData.title != null
                    ? mOriginalData.title : "Unknown Title",
                mOriginalData != null && mOriginalData.artist != null
                    ? mOriginalData.artist : "Unknown Artist",
                mOriginalData != null && mOriginalData.album != null
                    ? mOriginalData.album : "Unknown Album",
                mOriginalData != null && mOriginalData.genre != null
                    ? mOriginalData.genre : "Unknown Genre",
                mFilePath,
                mOriginalData != null ? mOriginalData.duration : 0,
                mGrantedFileUri.toString()
            );
            SongDatabase.getInstance(this).insertSong(newSong);
            Log.d(TAG, "Created new song with URI: " + mFilePath);
        }
    }

    /**
     * Returns whether write permission is available for the given URI.
     *
     * @param uri URI to check
     * @return True when the URI reports write access
     */
    private boolean hasWritePermission(@NonNull Uri uri) {
        try {
            DocumentFile document = DocumentFile.fromSingleUri(getApplicationContext(), uri);
            return document != null && document.canWrite();
        } catch (Exception exception) {
            Log.w(TAG, "hasWritePermission check failed", exception);
            return false;
        }
    }

    // ========================================================================
    // Edit Mode Management
    // ========================================================================

    /**
     * Switches to edit mode when the loaded metadata supports writing and
     * a write-capable URI is available, or requests SAF access when one
     * is needed.
     */
    private void enterEditMode() {
        if (mOriginalData == null) {
            ToastManager.showToast(this, "Cannot edit: metadata not loaded",
                ToastManager.LENGTH_NORMAL);
            return;
        }
        if (mOriginalData.status != MetadataReader.MetadataBundle.Status.SUCCESS) {
            ToastManager.showToast(this, "Cannot edit: file not readable",
                ToastManager.LENGTH_NORMAL);
            return;
        }
        if (!mOriginalData.isWriteSupported) {
            ToastManager.showToast(this,
                "Cannot edit: " + mOriginalData.format + " format",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        if (mGrantedFileUri == null && mFilePath != null) {
            getStoredUri(mFilePath);
        }

        if (mGrantedFileUri == null) {
            ToastManager.showToast(this, "File access needed. Please reselect the file",
                ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }

        if (!hasWritePermission(mGrantedFileUri)) {
            ToastManager.showToast(this,
                "Write permission needed. Please reselect the file",
                ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }

        mCurrentMode = MODE_EDIT;
        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;

        if (mActionButton != null) {
            mActionButton.setText("UPDATE");
        }
        setFieldsEnabled(true);

        if (mAlbumArtHint != null) {
            if (!mOriginalData.hasAlbumArt()) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Tap to add album art");
            } else {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Long press to remove");
            }
        }

        updateHeaderForMode();

        if (mTitleEdit != null) {
            mTitleEdit.requestFocus();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    InputMethodManager inputMethodManager =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (inputMethodManager != null) {
                        inputMethodManager.showSoftInput(
                            mTitleEdit, InputMethodManager.SHOW_IMPLICIT);
                    }
                }
            }, KEYBOARD_SHOW_DELAY_MS);
        }

        ToastManager.showToast(this, "Please tap UPDATE to save changes",
            ToastManager.LENGTH_NORMAL);
    }

    /**
     * Returns from edit mode to view mode, discarding any pending edits.
     */
    private void exitEditMode() {
        mCurrentMode = MODE_VIEW;
        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;

        if (mActionButton != null) {
            mActionButton.setText("MODIFY");
        }
        setFieldsEnabled(false);

        if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }

        updateHeaderForMode();

        hideKeyboard();
        if (mOriginalData != null) {
            displayMetadata();
        }
    }

    /**
     * Enables or disables every edit field.
     *
     * @param enabled True to make fields editable, false for read-only
     */
    private void setFieldsEnabled(boolean enabled) {
        EditText[] fields = {
            mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit, mGenreEdit, mTrackEdit
        };

        for (EditText field : fields) {
            if (field == null) {
                continue;
            }

            if (!enabled) {
                field.setEnabled(true);
                field.setFocusable(false);
                field.setFocusableInTouchMode(false);
                field.setClickable(false);
                field.setCursorVisible(false);
                field.setLongClickable(false);
                field.setTextIsSelectable(false);
                field.setOnFocusChangeListener(null);

                String text = field.getText().toString();
                if (text == null || text.isEmpty() || "Unknown".equals(text)
                    || "Unknown Title".equals(text) || "Unknown Artist".equals(text)
                    || "Unknown Album".equals(text)) {
                    field.setTextColor(Color.parseColor("#808080"));
                } else {
                    field.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mThemeHelper != null) {
                    field.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                } else {
                    field.setHintTextColor(Color.parseColor("#5A5A5A"));
                }

                if (mThemeHelper != null) {
                    mThemeHelper.updateEditText(field);
                }
            } else {
                field.setEnabled(true);
                field.setFocusable(true);
                field.setFocusableInTouchMode(true);
                field.setClickable(true);
                field.setCursorVisible(true);
                field.setLongClickable(true);
                field.setTextIsSelectable(true);

                if (mThemeHelper != null) {
                    mThemeHelper.updateEditTextCursor(field);
                }

                String currentText = field.getText().toString();
                boolean isPlaceholder = (currentText == null || currentText.isEmpty()
                    || "Unknown".equals(currentText) || "Unknown Title".equals(currentText)
                    || "Unknown Artist".equals(currentText)
                    || "Unknown Album".equals(currentText));

                if (isPlaceholder) {
                    field.setTextColor(Color.parseColor("#808080"));
                } else {
                    field.setTextColor(Color.parseColor("#C0C0C0"));
                }

                field.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View view, boolean hasFocus) {
                        EditText editText = (EditText) view;
                        if (hasFocus) {
                            if (mThemeManager != null) {
                                editText.setTextColor(mThemeManager.getCurrentColorInt());
                            } else if (mThemeHelper != null) {
                                editText.setTextColor(mThemeHelper.getThemeColorInt());
                            } else {
                                editText.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        } else {
                            String text = editText.getText().toString();
                            boolean isEmptyOrPlaceholder = (text == null || text.isEmpty()
                                || "Unknown".equals(text) || "Unknown Title".equals(text)
                                || "Unknown Artist".equals(text)
                                || "Unknown Album".equals(text));

                            if (isEmptyOrPlaceholder) {
                                editText.setTextColor(Color.parseColor("#808080"));
                            } else {
                                editText.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        }
                    }
                });
            }
        }

        if (mLyricsEdit != null) {
            if (!enabled) {
                mLyricsEdit.setEnabled(true);
                mLyricsEdit.setFocusable(false);
                mLyricsEdit.setFocusableInTouchMode(false);
                mLyricsEdit.setClickable(false);
                mLyricsEdit.setCursorVisible(false);
                mLyricsEdit.setLongClickable(false);
                mLyricsEdit.setTextIsSelectable(false);
                mLyricsEdit.setOnFocusChangeListener(null);
                mLyricsEdit.setCustomSelectionActionModeCallback(null);
                mLyricsEdit.setCustomInsertionActionModeCallback(null);

                String text = mLyricsEdit.getText().toString();
                if (text == null || text.isEmpty()) {
                    mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                } else {
                    mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mThemeHelper != null) {
                    mLyricsEdit.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                } else {
                    mLyricsEdit.setHintTextColor(Color.parseColor("#5A5A5A"));
                }

                if (mThemeHelper != null) {
                    mThemeHelper.updateEditText(mLyricsEdit);
                }
            } else {
                mLyricsEdit.setEnabled(true);
                mLyricsEdit.setFocusable(true);
                mLyricsEdit.setFocusableInTouchMode(true);
                mLyricsEdit.setClickable(true);
                mLyricsEdit.setCursorVisible(true);
                mLyricsEdit.setLongClickable(true);
                mLyricsEdit.setTextIsSelectable(true);

                if (mThemeHelper != null) {
                    mThemeHelper.updateEditTextCursor(mLyricsEdit);
                }

                String currentLyrics = mLyricsEdit.getText().toString();
                if (currentLyrics == null || currentLyrics.isEmpty()) {
                    mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                } else {
                    mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                }

                mLyricsEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View view, boolean hasFocus) {
                        if (hasFocus) {
                            if (mThemeManager != null) {
                                mLyricsEdit.setTextColor(mThemeManager.getCurrentColorInt());
                            } else if (mThemeHelper != null) {
                                mLyricsEdit.setTextColor(mThemeHelper.getThemeColorInt());
                            }
                        } else {
                            String text = mLyricsEdit.getText().toString();
                            if (text == null || text.isEmpty()) {
                                mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                            } else {
                                mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        }
                    }
                });

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mLyricsEdit.setCustomSelectionActionModeCallback(
                        new android.view.ActionMode.Callback() {
                            @Override
                            public boolean onCreateActionMode(
                                    android.view.ActionMode mode, android.view.Menu menu) {
                                return true;
                            }

                            @Override
                            public boolean onPrepareActionMode(
                                    android.view.ActionMode mode, android.view.Menu menu) {
                                return false;
                            }

                            @Override
                            public boolean onActionItemClicked(
                                    android.view.ActionMode mode, android.view.MenuItem item) {
                                return false;
                            }

                            @Override
                            public void onDestroyActionMode(android.view.ActionMode mode) {
                            }
                        });
                }
            }
        }

        if (mFileInfoText != null) {
            mFileInfoText.setEnabled(true);
            mFileInfoText.setFocusable(false);
            mFileInfoText.setFocusableInTouchMode(false);
            mFileInfoText.setClickable(false);
            mFileInfoText.setCursorVisible(false);
            mFileInfoText.setLongClickable(false);
            mFileInfoText.setTextIsSelectable(false);
        }
    }

    /**
     * Updates the header text to reflect the current mode.
     */
    private void updateHeaderForMode() {
        if (mHeaderTitle != null) {
            mHeaderTitle.setText(mCurrentMode == MODE_VIEW ? "VIEW MODE" : "EDIT MODE");
            mHeaderTitle.setTextColor(Color.parseColor("#C0C0C0"));
            mHeaderTitle.setLetterSpacing(0.1f);
        }

        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
            mFormatText.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }

    /**
     * Applies the enabled state to the action button and reapplies its
     * theme.
     *
     * @param enabled True to enable, false to disable
     */
    private void setActionButtonEnabled(boolean enabled) {
        if (mActionButton != null && mThemeHelper != null) {
            mActionButton.setEnabled(enabled);
            mThemeHelper.updateButton(mActionButton, enabled);
        }
    }

    /**
     * Removes the current album art and marks it for deletion on the next
     * save.
     */
    private void removeAlbumArt() {
        ToastManager.showToast(this, "Album art removed", ToastManager.LENGTH_NORMAL);
        mNewAlbumArt = null;
        mAlbumArtChanged = true;
        mAlbumArtDeleted = true;
        setPlaceholderAlbumArt();

        if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
            mAlbumArtHint.setVisibility(View.VISIBLE);
            mAlbumArtHint.setText("Tap to add album art");
        } else if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }
    }

    // ========================================================================
    // Album Art Selection
    // ========================================================================

    /**
     * Checks for gallery read permission and opens the gallery if it is
     * granted, or requests the permission otherwise.
     */
    private void checkGalleryPermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                    new String[] {"android.permission.READ_MEDIA_IMAGES"},
                    PERMISSION_GALLERY_REQUEST);
                return;
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                    new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_GALLERY_REQUEST);
                return;
            }
        }
        openGalleryForAlbumArt();
    }

    /**
     * Opens the system image picker for album art selection.
     */
    private void openGalleryForAlbumArt() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, GALLERY_REQUEST_CODE);
    }

    /**
     * Loads the given image URI on the executor and installs it as the
     * pending album art.
     *
     * @param uri URI of the selected image, or null
     */
    private void processSelectedAlbumArt(@Nullable final Uri uri) {
        if (mIsSaving.get()) {
            ToastManager.showToast(this, "Please wait... Saving changes",
                ToastManager.LENGTH_NORMAL);
            return;
        }
        if (uri == null) {
            return;
        }

        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }

        setPlaceholderAlbumArt();

        if (mExecutor == null) {
            return;
        }
        mCurrentAlbumArtTask = mExecutor.submit(new Runnable() {
            @Override
            public void run() {
                byte[] imageData = loadAlbumArtBytes(uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mCurrentAlbumArtTask = null;
                        if (imageData == null || imageData.length == 0) {
                            ToastManager.showToast(MetadataEditor.this,
                                "Failed to load image", ToastManager.LENGTH_NORMAL);
                            if (mOriginalData != null && mOriginalData.hasAlbumArt()) {
                                loadAlbumArtFromBytes(mOriginalData.albumArt);
                            } else {
                                setPlaceholderAlbumArt();
                            }
                            return;
                        }

                        mNewAlbumArt = imageData;
                        mAlbumArtChanged = true;
                        mAlbumArtDeleted = false;

                        Bitmap displayBitmap = BitmapFactory.decodeByteArray(
                            mNewAlbumArt, 0, mNewAlbumArt.length);
                        if (displayBitmap != null && mAlbumArtView != null) {
                            mAlbumArtView.setImageBitmap(displayBitmap);
                            mAlbumArtView.setColorFilter(null);
                            applyAlbumArtClipping();
                            if (mAlbumArtHint != null) {
                                mAlbumArtHint.setVisibility(View.VISIBLE);
                                mAlbumArtHint.setText("Long press to remove");
                            }
                            ToastManager.showToast(MetadataEditor.this,
                                "Album art changed", ToastManager.LENGTH_NORMAL);
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the given image URI, downsamples it to the album art size,
     * and returns the encoded JPEG bytes.
     *
     * @param uri URI of the image to read
     * @return JPEG byte array, or null when the image cannot be read
     */
    @Nullable
    private byte[] loadAlbumArtBytes(@NonNull Uri uri) {
        InputStream inputStream = null;
        try {
            inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(inputStream, null, options);
            inputStream.close();

            options.inSampleSize = calculateInSampleSize(
                options, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;

            inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, options);
            if (bitmap == null) {
                return null;
            }

            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            if (width > MAX_ALBUM_ART_SIZE_PX || height > MAX_ALBUM_ART_SIZE_PX) {
                float ratio = Math.min((float) MAX_ALBUM_ART_SIZE_PX / width,
                                       (float) MAX_ALBUM_ART_SIZE_PX / height);
                int newWidth = Math.round(width * ratio);
                int newHeight = Math.round(height * ratio);
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(
                    bitmap, newWidth, newHeight, true);
                bitmap.recycle();
                bitmap = scaledBitmap;
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, ALBUM_ART_QUALITY, outputStream);
            bitmap.recycle();
            return outputStream.toByteArray();

        } catch (Exception exception) {
            Log.e(TAG, "Error loading album art", exception);
            return null;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException ignored) {
                    // The stream is already closed.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above the
     * requested size.
     *
     * @param options Options whose bounds have been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options,
                                      int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    // ========================================================================
    // Save Changes Methods
    // ========================================================================

    /**
     * Hides the keyboard and then performs the save.
     */
    private void saveChanges() {
        hideKeyboard();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                performSaveChanges();
            }
        }, KEYBOARD_HIDE_DELAY_MS);
    }

    /**
     * Collects the pending changes, pauses playback if the song is
     * playing, and submits the write to the executor.
     */
    private void performSaveChanges() {
        boolean hasAnyChanges = mHasTextChanges || mAlbumArtChanged;

        if (!hasAnyChanges) {
            ToastManager.showToast(this, "No changes to save",
                ToastManager.LENGTH_NORMAL);
            return;
        }
        if (mIsSaving.get()) {
            return;
        }
        if (mGrantedFileUri == null) {
            ToastManager.showToast(this, "No write permission",
                ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }

        if (NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(this,
                "Please wait, playlist is syncing...",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        final MetadataWriter.UpdateBundle update = new MetadataWriter.UpdateBundle();

        if (mHasTextChanges) {
            update.title = getEditTextChangeValue(mTitleEdit, mOriginalTitle);
            update.artist = getEditTextChangeValue(mArtistEdit, mOriginalArtist);
            update.album = getEditTextChangeValue(mAlbumEdit, mOriginalAlbum);
            update.year = getEditTextChangeValue(mYearEdit, mOriginalYear);
            update.genre = getEditTextChangeValue(mGenreEdit, mOriginalGenre);
            update.trackNumber = getEditTextChangeValue(mTrackEdit, mOriginalTrack);
            update.lyrics = getEditTextChangeValue(mLyricsEdit, mOriginalLyrics);
        }

        if (mAlbumArtChanged) {
            if (mAlbumArtDeleted) {
                update.albumArt = new byte[0];
            } else if (mNewAlbumArt != null) {
                update.albumArt = mNewAlbumArt;
            }
        } else {
            update.albumArt = null;
        }

        mPreviousSongState = checkCurrentSongState();

        mIsSaving.set(true);
        setActionButtonEnabled(false);

        if (mExecutor == null) {
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataWriter.WriteResult result =
                    MetadataWriter.writeMetadataToUri(
                        MetadataEditor.this, mGrantedFileUri, update);
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay();
                        mIsSaving.set(false);
                        setActionButtonEnabled(true);
                        if (result.isSuccess()) {
                            onSaveSuccess();
                        } else {
                            onSaveFailure(result);
                        }
                    }
                });
            }
        });
    }

    /**
     * Handles a successful write: reloads metadata, updates the database,
     * broadcasts the change, and resumes playback when applicable.
     */
    private void onSaveSuccess() {
        if (mGrantedFileUri != null) {
            mOriginalData = MetadataReader.readMetadataFromUri(this, mGrantedFileUri);
        } else if (mFilePath != null) {
            mOriginalData = MetadataReader.readMetadata(mFilePath);
        }

        if (mOriginalData != null && (mFilePath != null || mGrantedFileUri != null)) {
            String path = mFilePath;
            if (path == null && mGrantedFileUri != null) {
                path = getFilePathFromUri(mGrantedFileUri);
            }
            if (path != null) {
                Song updatedSong = new Song(
                    mOriginalData.title != null
                        ? mOriginalData.title : "Unknown Title",
                    mOriginalData.artist != null
                        ? mOriginalData.artist : "Unknown Artist",
                    mOriginalData.album != null
                        ? mOriginalData.album : "Unknown Album",
                    mOriginalData.genre != null
                        ? mOriginalData.genre : "Unknown Genre",
                    path,
                    mOriginalData.duration,
                    mGrantedFileUri != null ? mGrantedFileUri.toString() : null
                );
                SongDatabase.getInstance(this).insertSong(updatedSong);
                Log.d(TAG, "Saved updated song to database: " + path);
            }
        }

        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;

        exitEditMode();

        if (mFilePath != null) {
            Intent updateIntent = new Intent(ACTION_METADATA_UPDATED);
            updateIntent.putExtra("song_path", mFilePath);
            updateIntent.putExtra("title", mOriginalData.title);
            updateIntent.putExtra("artist", mOriginalData.artist);
            updateIntent.putExtra("album", mOriginalData.album);
            updateIntent.putExtra("genre", mOriginalData.genre);
            boolean hasAlbumArt = mOriginalData.hasAlbumArt();
            updateIntent.putExtra("has_album_art", hasAlbumArt);
            updateIntent.putExtra("album_art_removed", mAlbumArtDeleted);
            if (hasAlbumArt) {
                updateIntent.putExtra("album_art_bytes", mOriginalData.albumArt);
            }
            sendBroadcast(updateIntent);
        }

        if (mPreviousSongState == SONG_STATE_WAS_PLAYING) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    sendBroadcast(new Intent("BLUETOOTH_PLAY"));
                }
            }, RESUME_PLAYBACK_DELAY_MS);
        }

        applyThemeToUI();

        ToastManager.showToast(this, "Metadata updated", ToastManager.LENGTH_NORMAL);
    }

    /**
     * Handles a failed write by mapping its status to a user-facing
     * message and clearing the cached URI when permission was denied.
     *
     * @param result Outcome of the write
     */
    private void onSaveFailure(@NonNull MetadataWriter.WriteResult result) {
        String message;
        switch (result.status) {
            case WRITE_FAILED_RESTORED:
            case VERIFY_FAILED_RESTORED:
            case COPY_BACK_FAILED_RESTORED:
                message = "Update failed - restored original";
                break;
            case PERMISSION_DENIED:
                message = "Permission lost";
                break;
            case COPY_FAILED:
            case BACKUP_FAILED:
            case FAILED:
            default:
                message = "Update failed";
                break;
        }
        ToastManager.showToast(this, message, ToastManager.LENGTH_NORMAL);
        Log.e(TAG, "Save failed [" + result.status + "]: " + result.errorMessage);

        if (result.status == MetadataWriter.WriteResult.Status.PERMISSION_DENIED) {
            if (mFilePath != null) {
                SongDatabase.getInstance(this).insertSong(new Song(
                    mOriginalTitle != null ? mOriginalTitle : "Unknown Title",
                    mOriginalArtist != null ? mOriginalArtist : "Unknown Artist",
                    mOriginalAlbum != null ? mOriginalAlbum : "Unknown Album",
                    mOriginalGenre != null ? mOriginalGenre : "Unknown Genre",
                    mFilePath, 0, null));
            }
            mGrantedFileUri = null;
            ToastManager.showToast(this, "Permission lost. Please reselect the file",
                ToastManager.LENGTH_NORMAL);
        }
    }

    // ========================================================================
    // Theme and UI Helper Methods
    // ========================================================================

    /**
     * Applies the current theme color to every control in the activity.
     */
    private void applyThemeToUI() {
        if (mThemeHelper == null || mThemeManager == null) {
            return;
        }
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, true);
        }
        setActionButtonEnabled(mActionButton != null && mActionButton.isEnabled());

        EditText[] editTexts = {
            mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit,
            mGenreEdit, mTrackEdit, mLyricsEdit
        };
        for (EditText editText : editTexts) {
            if (editText != null) {
                mThemeHelper.updateEditText(editText);

                if (mCurrentMode == MODE_EDIT) {
                    mThemeHelper.updateEditTextCursor(editText);

                    if (editText.hasFocus()) {
                        editText.setTextColor(mThemeManager.getCurrentColorInt());
                        editText.setHintTextColor(mThemeManager.getCurrentColorInt());
                    } else {
                        String text = editText.getText().toString();
                        boolean isPlaceholder = (text == null || text.isEmpty()
                            || "Unknown".equals(text) || "Unknown Title".equals(text)
                            || "Unknown Artist".equals(text)
                            || "Unknown Album".equals(text));
                        editText.setTextColor(isPlaceholder
                            ? Color.parseColor("#808080") : Color.parseColor("#C0C0C0"));
                        editText.setHintTextColor(Color.parseColor("#5A5A5A"));
                    }
                } else {
                    String text = editText.getText().toString();
                    boolean isPlaceholder = (text == null || text.isEmpty()
                        || "Unknown".equals(text) || "Unknown Title".equals(text)
                        || "Unknown Artist".equals(text)
                        || "Unknown Album".equals(text));
                    editText.setTextColor(isPlaceholder
                        ? Color.parseColor("#808080") : Color.parseColor("#C0C0C0"));
                    if (mThemeHelper != null) {
                        editText.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                    } else {
                        editText.setHintTextColor(Color.parseColor("#5A5A5A"));
                    }
                }
            }
        }

        if (mFileInfoText != null) {
            mThemeHelper.updateEditText(mFileInfoText);
            String text = mFileInfoText.getText().toString();
            if (text == null || text.isEmpty()) {
                mFileInfoText.setTextColor(Color.parseColor("#5A5A5A"));
            } else {
                mFileInfoText.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mCurrentMode == MODE_VIEW) {
                mFileInfoText.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
            } else {
                mFileInfoText.setHintTextColor(Color.parseColor("#5A5A5A"));
            }
        }

        if (mAlbumArtHint != null) {
            mAlbumArtHint.setTextColor(Color.parseColor("#808080"));
        }
        if (mHeaderTitle != null) {
            mHeaderTitle.setTextColor(Color.parseColor("#C0C0C0"));
            mHeaderTitle.setLetterSpacing(0.1f);
        }

        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
            mFormatText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mOriginalData == null || mOriginalData.albumArt == null) {
            setPlaceholderAlbumArt();
        }
    }

    /**
     * Shows the loading overlay with an indeterminate spinner.
     */
    private void showLoadingOverlay() {
        if (mLoadingOverlay != null) {
            return;
        }
        ViewGroup rootView = (ViewGroup) getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (rootView == null) {
            return;
        }
        mLoadingOverlay = new FrameLayout(this);
        mLoadingOverlay.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mLoadingOverlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
        ProgressBar spinner = new ProgressBar(this);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            dpToPx(PROGRESS_BAR_SIZE_DP), dpToPx(PROGRESS_BAR_SIZE_DP));
        params.gravity = Gravity.CENTER;
        spinner.setLayoutParams(params);
        mLoadingOverlay.addView(spinner);
        rootView.addView(mLoadingOverlay);

        if (mThemeHelper != null && spinner != null) {
            mThemeHelper.updateProgressBar(spinner);
        }
    }

    /**
     * Removes the loading overlay.
     */
    private void hideLoadingOverlay() {
        if (mLoadingOverlay != null && mLoadingOverlay.getParent() != null) {
            ((ViewGroup) mLoadingOverlay.getParent()).removeView(mLoadingOverlay);
        }
        mLoadingOverlay = null;
    }

    /**
     * Hides the soft keyboard when one is shown.
     */
    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    // ========================================================================
    // Activity Results and Permissions
    // ========================================================================

    /**
     * Handles the SAF file picker result and the gallery image result.
     *
     * @param requestCode The request code passed to
     *        {@link #startActivityForResult(Intent, int)}
     * @param resultCode The result code returned by the picker
     * @param data The intent carrying the picked item, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SAF_FILE_PICKER) {
            mRequestInProgress = false;

            if (resultCode == RESULT_OK && data != null) {
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    mAwaitingFileSelection = false;

                    if (mStorageHelper != null) {
                        mStorageHelper.takeFilePermission(selectedUri);
                    } else {
                        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                        try {
                            getContentResolver().takePersistableUriPermission(
                                selectedUri, takeFlags);
                        } catch (SecurityException exception) {
                            Log.e(TAG, "Failed to take URI permission", exception);
                        }
                    }

                    mGrantedFileUri = selectedUri;

                    String path = getFilePathFromUri(selectedUri);
                    if (path != null) {
                        mFilePath = path;
                    }

                    if (mHeaderTitle != null) {
                        mHeaderTitle.setText("LOADING");
                    }

                    showLoadingOverlay();

                    if (mExecutor != null) {
                        mExecutor.execute(new Runnable() {
                            @Override
                            public void run() {
                                final MetadataReader.MetadataBundle metadataBundle =
                                    MetadataReader.readMetadataFromUri(
                                        MetadataEditor.this, selectedUri);

                                mMainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        hideLoadingOverlay();
                                        mOriginalData = metadataBundle;

                                        displayMetadata();
                                        updateFileInfo();

                                        if (mHeaderTitle != null) {
                                            mHeaderTitle.setText("VIEW MODE");
                                        }

                                        switch (metadataBundle.status) {
                                            case FILE_UNREADABLE:
                                                setActionButtonEnabled(false);
                                                ToastManager.showToast(
                                                    MetadataEditor.this,
                                                    "File not accessible",
                                                    ToastManager.LENGTH_NORMAL);
                                                break;
                                            case PARSE_FAILED:
                                                setActionButtonEnabled(false);
                                                ToastManager.showToast(
                                                    MetadataEditor.this,
                                                    "Could not read metadata",
                                                    ToastManager.LENGTH_NORMAL);
                                                break;
                                            case SUCCESS:
                                            default:
                                                if (!metadataBundle.isWriteSupported) {
                                                    setActionButtonEnabled(false);
                                                    ToastManager.showToast(
                                                        MetadataEditor.this,
                                                        "Cannot edit: "
                                                            + metadataBundle.format
                                                            + " format",
                                                        ToastManager.LENGTH_NORMAL);
                                                } else {
                                                    setActionButtonEnabled(true);
                                                    if (mActionButton != null) {
                                                        mActionButton.setText("MODIFY");
                                                    }
                                                }
                                                break;
                                        }

                                        saveUriToDatabase();
                                        enterEditMode();
                                    }
                                });
                            }
                        });
                    }
                }
                return;
            } else if (resultCode == RESULT_CANCELED && mAwaitingFileSelection) {
                finish();
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
                return;
            }
            return;
        }

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            processSelectedAlbumArt(data.getData());
        }
    }

    /**
     * Handles the gallery permission result, opening the gallery when the
     * permission was granted.
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_GALLERY_REQUEST) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGalleryForAlbumArt();
            } else {
                ToastManager.showToast(this,
                    "Permission needed to load album art",
                    ToastManager.LENGTH_NORMAL);
            }
        }
    }
}