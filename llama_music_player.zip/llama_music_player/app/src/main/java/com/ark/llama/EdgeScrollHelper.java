// EdgeScrollHelper.java
package com.ark.llama;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Attaches proportional edge fast-scroll to a {@link RecyclerView}.
 *
 * <p>A vertical drag that starts inside the leftmost or rightmost
 * {@link #EDGE_ZONE_DP} of the list scrolls it proportionally: a full
 * viewport-height of finger travel maps to
 * {@link #FAST_SCROLL_FRACTION_PER_VIEWPORT} of the total scrollable
 * range, anchored at the position the drag began. A drag that starts
 * anywhere else is left to the RecyclerView's own scroll handling.</p>
 *
 * <p>Fast scroll only engages when the content is at least
 * {@link #FAST_SCROLL_MIN_CONTENT_RATIO} times taller than the
 * viewport. On a shorter list the proportional mapping would be too
 * coarse for a user who is reading rows, and the edge zones defer to
 * ordinary scrolling.</p>
 *
 * <p>A tap is never consumed. The interceptor only takes over once
 * the finger has moved beyond the touch slop, so tapping a row that
 * happens to sit near an edge still fires the row's click.</p>
 *
 * <p>Shared by the playlist and the playback scope dialog so both
 * surfaces use the same edge width, the same engagement threshold,
 * and the same scroll rate.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.4.0
 * @since 1.4.0
 */
public final class EdgeScrollHelper {

    // ============================================================================
    // Constants
    // ============================================================================

    /**
     * Width of the fast-scroll touch zone from each side of the
     * list, in density-independent pixels.
     */
    private static final int EDGE_ZONE_DP = 32;

    /**
     * Fraction of the total scrollable range traversed by one
     * viewport-height of finger travel in an edge fast-scroll
     * zone.
     */
    private static final float FAST_SCROLL_FRACTION_PER_VIEWPORT = 0.05f;

    /**
     * Minimum content-to-viewport ratio at which fast scroll
     * engages.
     */
    private static final float FAST_SCROLL_MIN_CONTENT_RATIO = 3.0f;

    // ============================================================================
    // Private Constructor
    // ============================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private EdgeScrollHelper() {
    }

    // ============================================================================
    // Public Methods
    // ============================================================================

    /**
     * Installs the edge fast-scroll interceptor on the given
     * RecyclerView.
     *
     * <p>Attach once per RecyclerView. A second call on the same
     * RecyclerView installs a second listener and doubles the
     * scroll rate; the caller is responsible for calling this
     * exactly once.</p>
     *
     * @param recyclerView RecyclerView to attach the interceptor to
     */
    public static void attach(@NonNull final RecyclerView recyclerView) {
        final Context context = recyclerView.getContext();
        final int edgeZonePx = dpToPx(context, EDGE_ZONE_DP);
        final int touchSlop = ViewConfiguration.get(context)
            .getScaledTouchSlop();

        recyclerView.addOnItemTouchListener(
            new RecyclerView.OnItemTouchListener() {

                /** Y coordinate of the current gesture's starting
                 *  touch, in view-local pixels. */
                private float anchorTouchY = 0f;

                /** Scroll offset in pixels at the moment the
                 *  gesture started. */
                private int anchorScrollY = 0;

                /** Total scrollable range in pixels, sampled at
                 *  gesture start. */
                private int scrollableRange = 1;

                /** Viewport height in pixels, sampled at gesture
                 *  start. */
                private int viewportHeight = 1;

                /** True when the current gesture started inside an
                 *  edge zone. */
                private boolean startedInEdgeZone = false;

                /** True once the interceptor has taken over the
                 *  gesture. */
                private boolean consuming = false;

                @Override
                public boolean onInterceptTouchEvent(
                        @NonNull RecyclerView recyclerView,
                        @NonNull MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN: {
                            final float x = event.getX();
                            final int width = recyclerView.getWidth();
                            startedInEdgeZone = (x <= edgeZonePx
                                || x >= width - edgeZonePx);
                            consuming = false;
                            if (startedInEdgeZone) {
                                anchorTouchY = event.getY();
                                anchorScrollY = recyclerView
                                    .computeVerticalScrollOffset();
                                final int contentHeight = recyclerView
                                    .computeVerticalScrollRange();
                                viewportHeight = Math.max(
                                    1, recyclerView.getHeight());
                                scrollableRange = Math.max(
                                    1,
                                    contentHeight - viewportHeight);
                            }
                            return false;
                        }
                        case MotionEvent.ACTION_MOVE: {
                            if (!startedInEdgeZone) {
                                return false;
                            }
                            if (!consuming) {
                                if (Math.abs(
                                        event.getY() - anchorTouchY)
                                        <= touchSlop) {
                                    return false;
                                }
                                if (!fastScrollEngages(recyclerView)) {
                                    startedInEdgeZone = false;
                                    return false;
                                }
                                recyclerView.stopScroll();
                                consuming = true;
                                return true;
                            }
                            applyProportionalScroll(
                                recyclerView, event.getY());
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            final boolean wasConsuming = consuming;
                            consuming = false;
                            startedInEdgeZone = false;
                            return wasConsuming;
                        }
                        default:
                            return false;
                    }
                }

                @Override
                public void onTouchEvent(
                        @NonNull RecyclerView recyclerView,
                        @NonNull MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_MOVE: {
                            applyProportionalScroll(
                                recyclerView, event.getY());
                            break;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            consuming = false;
                            startedInEdgeZone = false;
                            break;
                        }
                        default:
                            break;
                    }
                }

                @Override
                public void onRequestDisallowInterceptTouchEvent(
                        boolean disallowIntercept) {
                    // The RecyclerView is asking whether the
                    // listener wants to veto an interception.
                    // The listener accepts the request
                    // unconditionally.
                }

                /**
                 * Returns whether the list is long enough for
                 * proportional fast scroll to be useful.
                 *
                 * @param recyclerView The RecyclerView being
                 *        scrolled
                 * @return True when content exceeds
                 *         {@link #FAST_SCROLL_MIN_CONTENT_RATIO}
                 *         times the viewport
                 */
                private boolean fastScrollEngages(
                        @NonNull RecyclerView recyclerView) {
                    final int contentHeight = recyclerView
                        .computeVerticalScrollRange();
                    final int viewport = Math.max(
                        1, recyclerView.getHeight());
                    return contentHeight
                        > viewport * FAST_SCROLL_MIN_CONTENT_RATIO;
                }

                /**
                 * Moves the RecyclerView so its scroll offset is a
                 * fixed function of the finger's vertical
                 * position, measured from the position the
                 * gesture began.
                 *
                 * @param recyclerView The RecyclerView being
                 *        scrolled
                 * @param currentTouchY Current finger Y in
                 *        view-local pixels
                 */
                private void applyProportionalScroll(
                        @NonNull RecyclerView recyclerView,
                        float currentTouchY) {
                    final float viewportFraction =
                        (currentTouchY - anchorTouchY) / viewportHeight;
                    final float libraryFraction = viewportFraction
                        * FAST_SCROLL_FRACTION_PER_VIEWPORT;
                    final int targetOffset = anchorScrollY
                        + Math.round(
                            libraryFraction * scrollableRange);
                    final int currentOffset = recyclerView
                        .computeVerticalScrollOffset();
                    final int delta = targetOffset - currentOffset;
                    if (delta != 0) {
                        recyclerView.scrollBy(0, delta);
                    }
                }
            });
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dpValue Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private static int dpToPx(@NonNull Context context, int dpValue) {
        return Math.round(dpValue * context.getResources()
            .getDisplayMetrics().density);
    }
}