package com.ark.llama;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * The dim-and-spinner overlay, process-wide and reason-keyed.
 *
 * <p>The overlay is a dim {@link FrameLayout} covering the current
 * activity's content view, with a rotating ring spinner centred in it.
 * It answers one question for the user: <em>is the app working?</em> It
 * is not a progress bar and it does not report progress; it reports
 * activity.</p>
 *
 * <h3>Process-Wide, Not Per-Activity</h3>
 * <p>The overlay is a singleton. The spinner and the dim background
 * belong to the process, not to any single activity. When the activity
 * in front changes, the overlay is reattached to the new activity's
 * content view without the reason set being touched. This is what lets
 * the overlay follow the user across navigation — for example, when a
 * folder-scan operation continues while the user back-swipes out of
 * {@link FolderManager} and lands in {@link MusicPlayer}.</p>
 *
 * <h3>Ownership by Reason</h3>
 * <p>Visibility is by <b>reason token</b>. Each caller that wants the
 * overlay visible holds a reason; the overlay is visible while at least
 * one reason is held. Independent callers — the cold-start library load
 * in {@link MusicPlayer}, the metadata read in {@link MetadataEditor},
 * and the folder-update cycle initiated by {@link FolderManager} — use
 * distinct reasons, so one can be released without tearing down the
 * others.</p>
 *
 * <h3>Reason Tokens</h3>
 * <p>Three reasons are in use in this app and are declared as public
 * constants on this class:</p>
 * <ul>
 *   <li>{@link #REASON_COLD_START} — the cold-start library load.</li>
 *   <li>{@link #REASON_METADATA_LOAD} — a metadata read in the editor.</li>
 *   <li>{@link #REASON_FOLDER_UPDATE_CYCLE} — the folder-scan, playlist
 *       rebuild, and genre-load sequence that follows an UPDATE tap in
 *       the folder manager. Held from the tap until genre loading
 *       begins, so the overlay is continuous from the user's first
 *       press to the moment the genre overlay takes over.</li>
 * </ul>
 *
 * <h3>Stuck Timeout</h3>
 * <p>A reason held longer than {@link #STUCK_TIMEOUT_MS} is released
 * automatically by a periodic health check. This is a safety net, not
 * a design feature: every reason has an owner that hides it on every
 * exit path, and the timeout exists only to recover from the
 * unexpected — for example, an activity destroyed while still holding a
 * reason it cannot hand off. The release is logged at warn level so an
 * orphaned reason is visible in logcat.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>{@link #init(Context)} registers the manager as an
 * {@link Application.ActivityLifecycleCallbacks} listener and starts
 * the health check. Every activity that uses the overlay calls
 * {@code init} from its own {@link Activity#onCreate(Bundle)}; the call
 * is idempotent. The overlay is built lazily on the first
 * {@link #show(String)} and torn down when the last reason is
 * released.</p>
 *
 * <p>The spinner's rotation animator is bound to the spinner view's
 * attach state. {@link View#onAttachedToWindow()} starts the rotation
 * and {@link View#onDetachedFromWindow()} cancels it, so the animation
 * runs exactly while the view is on screen.</p>
 *
 * <h3>Theme</h3>
 * <p>The theme color is supplied by the caller through
 * {@link #setColor(int)} and remembered across detach and reattach. The
 * spinner uses the color twice: at full alpha for the bright arc, and at
 * {@link #TRACK_ALPHA} for the dim track.</p>
 *
 * <h3>Touch</h3>
 * <p>The dim container consumes touches. While the overlay is showing,
 * the UI behind it is not in a state to be acted on. System gesture
 * navigation — back, home, recents — is handled by the system process
 * before touches reach the app, and is not affected by the overlay.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. The reason set is a
 * plain {@link HashSet} and is not synchronized. Public methods post to
 * the main handler when called from a background thread; in practice
 * every caller in this app is already on the main thread.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — The overlay is attached if and only if {@link #mReasons} is
 *       non-empty.</li>
 *   <li>I2 — {@link #attach(Activity)} and {@link #detach()} are
 *       idempotent.</li>
 *   <li>I3 — The spinner's animator is running if and only if the
 *       spinner view is attached to a window.</li>
 *   <li>I4 — Every view the manager adds to an activity's content view
 *       is removed by {@link #detach()} or when that activity is
 *       destroyed. The manager does not accumulate orphan views.</li>
 *   <li>I5 — {@link #onActivityResumed(Activity)} reattaches the overlay
 *       to the resumed activity if any reasons are held, regardless of
 *       which activity was attached before.</li>
 *   <li>I6 — {@link #onActivityDestroyed(Activity)} releases the view
 *       references for the destroyed activity but never touches the
 *       reason set. A reason survives the destruction of its author's
 *       activity; the health check is what eventually releases it if no
 *       other path does.</li>
 * </ul>
 *
 * @see MusicPlayer
 * @see MetadataEditor
 * @see FolderManager
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class OverlayManager implements Application.ActivityLifecycleCallbacks {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "OverlayManager";

    /**
     * Reason held by {@link MusicPlayer} for the cold-start library
     * load.
     */
    public static final String REASON_COLD_START = "MusicPlayer.COLD_START";

    /**
     * Reason held by {@link MetadataEditor} for a metadata read.
     */
    public static final String REASON_METADATA_LOAD = "MetadataEditor.METADATA_LOAD";

    /**
     * Reason held during the folder-update cycle.
     *
     * <p>Shown by {@link FolderManager} on the UPDATE tap. Held through
     * the folder scan, through the playlist rebuild driven by
     * {@link MusicPlayer}, and released by
     * {@link PlaylistManager#triggerGenreLoading(String)} at the moment
     * genre loading begins. The overlay is therefore continuous from the
     * user's first press to the moment the genre overlay takes over.</p>
     */
    public static final String REASON_FOLDER_UPDATE_CYCLE = "FolderUpdateCycle";

    /** Alpha of the dim background, 0-255. */
    private static final int DIM_ALPHA = 180;

    /** Base color of the dim background, as 0xRRGGBB. */
    private static final int DIM_RGB = 0x121212;

    /** Spinner diameter in density-independent pixels. */
    private static final int SPINNER_DIAMETER_DP = 32;

    /** Spinner stroke width in density-independent pixels. */
    private static final int SPINNER_STROKE_DP = 2;

    /** Sweep of the bright arc, in degrees. */
    private static final int BRIGHT_ARC_SWEEP_DEGREES = 90;

    /** Rotation period, in milliseconds. */
    private static final long ROTATION_PERIOD_MS = 1000L;

    /** Alpha applied to the dim track, 0-255. */
    private static final int TRACK_ALPHA = 0x4D;

    /** Default theme color used before any caller sets one. */
    private static final int DEFAULT_COLOR = 0xFFB8A86E;

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000L;

    /**
     * Maximum time a reason may be held before it is released
     * automatically.
     *
     * <p>A safety net for orphaned reasons. Every reason has an owner
     * that hides it on every exit path; this timeout recovers from the
     * unexpected. Set generously so a slow operation on a large library
     * is never mistaken for an orphan.</p>
     */
    private static final long STUCK_TIMEOUT_MS = 60000L;

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance, or null before {@link #init(Context)}. */
    @Nullable
    private static volatile OverlayManager sInstance;

    /** Application instance used for lifecycle callbacks. */
    @Nullable
    private static Application sApplication;

    /**
     * Initializes the singleton.
     *
     * <p>Calling this method more than once with the same process has no
     * effect.</p>
     *
     * @param context A context; the application context is retained
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new OverlayManager(context);
        }
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance
     * @throws IllegalStateException When {@link #init(Context)} has not
     *         yet been called
     */
    @NonNull
    private static OverlayManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException(
                "OverlayManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ============================================================================
    // Fields
    // ============================================================================

    /** Main-thread handler for overlay operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for the periodic health check. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    /** Reasons currently holding the overlay visible. */
    @NonNull
    private final Set<String> mReasons = new HashSet<>();

    /** Wall-clock time at which each reason was first shown. */
    @NonNull
    private final Map<String, Long> mReasonShowTimes = new HashMap<>();

    /** Weak reference to the currently resumed activity. */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef;

    /** Weak reference to the activity the overlay is currently attached to. */
    @Nullable
    private WeakReference<Activity> mAttachedActivityRef;

    /** Attached container, or null when the overlay is not showing. */
    @Nullable
    private FrameLayout mContainer;

    /** Attached spinner, or null when the overlay is not showing. */
    @Nullable
    private SpinnerView mSpinner;

    /** Current theme color. */
    private int mColor = DEFAULT_COLOR;

    /** Runnable for the periodic health check. */
    @Nullable
    private Runnable mHealthCheckRunnable;

    /** True once the lifecycle callbacks have been registered. */
    private boolean mCallbacksRegistered = false;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the singleton, registers lifecycle callbacks, and
     * starts the health check.
     *
     * @param context A context; the application context is retained
     */
    private OverlayManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        startHealthCheck();
        Log.d(TAG, "OverlayManager initialized");
    }

    // ============================================================================
    // Public API
    // ============================================================================

    /**
     * Adds a reason to the visible set and attaches the overlay when the
     * set becomes non-empty.
     *
     * <p>A call with a reason that is already held is a no-op. Every
     * call must be paired with a matching {@link #hide(String)} on every
     * exit path from the operation that holds the reason.</p>
     *
     * @param reason Caller-supplied token, unique to the operation that
     *               wants the overlay visible
     */
    public static void show(@NonNull String reason) {
        OverlayManager manager = getInstance();
        manager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                manager.showInternal(reason);
            }
        });
    }

    /**
     * Removes a reason from the visible set and detaches the overlay
     * when the set becomes empty.
     *
     * <p>A call whose reason is not held is a no-op, so paired
     * show/hide calls are safe regardless of ordering or duplication.</p>
     *
     * @param reason Token passed to a previous {@link #show(String)}
     *               call
     */
    public static void hide(@NonNull String reason) {
        OverlayManager manager = getInstance();
        manager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                manager.hideInternal(reason);
            }
        });
    }

    /**
     * Applies a theme color to the spinner.
     *
     * <p>The color is remembered and reapplied on the next attach. The
     * spinner derives both its bright arc and its dim track from this
     * color.</p>
     *
     * @param color Theme color as an ARGB integer
     */
    public static void setColor(final int color) {
        OverlayManager manager = getInstance();
        manager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                manager.mColor = color;
                if (manager.mSpinner != null) {
                    manager.mSpinner.setColor(color);
                }
            }
        });
    }

    /**
     * Returns whether the overlay is currently showing.
     *
     * @return True when at least one reason is held
     */
    public static boolean isShowing() {
        return !getInstance().mReasons.isEmpty();
    }

    /**
     * Returns whether the given reason is currently held.
     *
     * @param reason Reason token to test, or null
     * @return True when the reason is held
     */
    public static boolean isShowing(@Nullable String reason) {
        if (reason == null) {
            return false;
        }
        return getInstance().mReasons.contains(reason);
    }

    // ============================================================================
    // Show / Hide Internals
    // ============================================================================

    /**
     * Internal implementation of {@link #show(String)}.
     *
     * <p>Runs on the main thread. Adds the reason and, when it is the
     * first, attaches the overlay to the current activity.</p>
     *
     * @param reason Reason to add
     */
    private void showInternal(@NonNull String reason) {
        final boolean wasEmpty = mReasons.isEmpty();
        final boolean added = mReasons.add(reason);
        if (!added) {
            return;
        }
        mReasonShowTimes.put(reason, SystemClock.elapsedRealtime());
        if (!wasEmpty) {
            return;
        }
        Activity activity = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            attach(activity);
        }
    }

    /**
     * Internal implementation of {@link #hide(String)}.
     *
     * <p>Runs on the main thread. Removes the reason and, when the set
     * becomes empty, detaches the overlay.</p>
     *
     * @param reason Reason to remove
     */
    private void hideInternal(@NonNull String reason) {
        final boolean removed = mReasons.remove(reason);
        if (!removed) {
            return;
        }
        mReasonShowTimes.remove(reason);
        if (!mReasons.isEmpty()) {
            return;
        }
        detach();
    }

    // ============================================================================
    // Attachment
    // ============================================================================

    /**
     * Builds and attaches the container and spinner to the given
     * activity's content view.
     *
     * <p>Idempotent while attached to the same activity. If the manager
     * is already attached to a different activity, the old container is
     * detached first.</p>
     *
     * @param activity Activity whose content view will host the overlay
     */
    private void attach(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        Activity attached = mAttachedActivityRef != null
            ? mAttachedActivityRef.get() : null;
        if (attached == activity && mContainer != null) {
            return;
        }
        detach();

        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) {
            return;
        }

        FrameLayout container = new FrameLayout(activity);
        container.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        container.setBackgroundColor(Color.argb(DIM_ALPHA,
            Color.red(DIM_RGB), Color.green(DIM_RGB), Color.blue(DIM_RGB)));
        container.setClickable(true);
        container.setFocusable(true);

        SpinnerView spinner = new SpinnerView(activity);
        spinner.setColor(mColor);
        int size = dpToPx(activity, SPINNER_DIAMETER_DP);
        FrameLayout.LayoutParams spinnerParams = new FrameLayout.LayoutParams(
            size, size);
        spinnerParams.gravity = Gravity.CENTER;
        spinner.setLayoutParams(spinnerParams);

        container.addView(spinner);
        root.addView(container);

        mContainer = container;
        mSpinner = spinner;
        mAttachedActivityRef = new WeakReference<>(activity);
    }

    /**
     * Detaches the container from its parent and clears the view
     * fields.
     *
     * <p>The reason set is not touched. A detach that empties the view
     * layer does not end any operation.</p>
     */
    private void detach() {
        if (mContainer != null && mContainer.getParent() != null) {
            ((ViewGroup) mContainer.getParent()).removeView(mContainer);
        }
        mContainer = null;
        mSpinner = null;
        mAttachedActivityRef = null;
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    // ============================================================================
    // Activity Lifecycle
    // ============================================================================

    /**
     * Registers the manager's lifecycle callbacks with the application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) {
            return;
        }
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    /**
     * Updates the current activity and reattaches the overlay when any
     * reasons are held.
     *
     * @param activity Activity that resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        if (mReasons.isEmpty()) {
            return;
        }
        Activity attached = mAttachedActivityRef != null
            ? mAttachedActivityRef.get() : null;
        if (attached != activity) {
            detach();
            attach(activity);
        }
    }

    /**
     * Ignores activity creation events. The overlay reattaches on
     * resume, not on creation.
     *
     * @param activity Activity that was created
     * @param savedInstanceState Saved state, or null
     */
    @Override
    public void onActivityCreated(@NonNull Activity activity,
                                  @Nullable Bundle savedInstanceState) {
    }

    /**
     * Ignores activity start events. The overlay reattaches on resume,
     * not on start.
     *
     * @param activity Activity that was started
     */
    @Override
    public void onActivityStarted(@NonNull Activity activity) {
    }

    /**
     * Ignores activity pause events. The overlay is left attached to a
     * paused activity so it is already present when the activity
     * resumes.
     *
     * @param activity Activity that paused
     */
    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    /**
     * Ignores activity stop events. The overlay is left attached to a
     * stopped activity until the activity is destroyed.
     *
     * @param activity Activity that stopped
     */
    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    /**
     * Ignores save-instance-state events.
     *
     * @param activity Activity that is saving state
     * @param outState Bundle to write state into
     */
    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity,
                                            @NonNull Bundle outState) {
    }

    /**
     * Drops the view references when the destroyed activity was the one
     * the overlay was attached to.
     *
     * <p>The reason set is deliberately not touched. A reason survives
     * the destruction of its author's activity, so an operation that is
     * still running in the background can keep the overlay up when the
     * user navigates. The next {@link #onActivityResumed(Activity)}
     * reattaches the overlay to the resumed activity.</p>
     *
     * @param activity Activity that was destroyed
     */
    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        Activity attached = mAttachedActivityRef != null
            ? mAttachedActivityRef.get() : null;
        if (attached == activity) {
            mContainer = null;
            mSpinner = null;
            mAttachedActivityRef = null;
        }
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
    }

    // ============================================================================
    // Health Check
    // ============================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        if (mHealthCheckRunnable != null) {
            return;
        }
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
    }

    /**
     * Releases any reason held longer than {@link #STUCK_TIMEOUT_MS}.
     *
     * <p>Logs a warning for each release so an orphaned reason is
     * visible in logcat.</p>
     */
    private void performHealthCheck() {
        if (mReasons.isEmpty()) {
            return;
        }
        final long now = SystemClock.elapsedRealtime();
        final Iterator<Map.Entry<String, Long>> iterator =
            mReasonShowTimes.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Long> entry = iterator.next();
            long age = now - entry.getValue();
            if (age > STUCK_TIMEOUT_MS) {
                Log.w(TAG, "Releasing stuck reason '" + entry.getKey()
                    + "' after " + age + "ms");
                mReasons.remove(entry.getKey());
                iterator.remove();
            }
        }
        if (mReasons.isEmpty()) {
            detach();
        }
    }

    // ============================================================================
    // Shutdown
    // ============================================================================

    /**
     * Releases every resource held by the manager.
     *
     * <p>Called only at process teardown. Unregisters the lifecycle
     * callbacks, stops the health check, detaches the overlay, clears
     * the reason set, and clears the singleton reference.</p>
     */
    public static void shutdown() {
        OverlayManager manager = sInstance;
        if (manager == null) {
            return;
        }
        Log.d(TAG, "Shutting down OverlayManager");
        if (manager.mHealthCheckRunnable != null) {
            manager.mHealthHandler.removeCallbacks(manager.mHealthCheckRunnable);
            manager.mHealthCheckRunnable = null;
        }
        if (manager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(manager);
                manager.mCallbacksRegistered = false;
            } catch (Exception exception) {
                // The callbacks were already unregistered.
            }
        }
        manager.detach();
        manager.mReasons.clear();
        manager.mReasonShowTimes.clear();
        sInstance = null;
        sApplication = null;
    }

    // ============================================================================
    // Spinner View
    // ============================================================================

    /**
     * A ring spinner with one bright arc travelling around a dim track.
     *
     * <p>A full circle stroked in a low-alpha theme color, with one
     * quarter of the ring stroked at full theme alpha, rotated
     * continuously. The rotation is what makes the arc's position
     * change over time; the two alphas are what make the arc legible
     * as a distinct object rather than as part of the ring.</p>
     *
     * <p>The rotation animator is started in
     * {@link #onAttachedToWindow()} and cancelled in
     * {@link #onDetachedFromWindow()}. The animator's lifecycle is the
     * view's attach lifecycle, with no coordination from the manager.
     * This is what keeps the spinner animating for exactly the interval
     * the overlay is attached, without the manager having to know about
     * the animator at all.</p>
     */
    private static final class SpinnerView extends View {

        /** Paint for the dim track. */
        @NonNull
        private final Paint mTrackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        /** Paint for the bright arc. */
        @NonNull
        private final Paint mArcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        /**
         * Reusable bounds rect for {@link Canvas#drawArc}.
         *
         * <p>Allocated once and mutated on every draw, so the onDraw
         * path does not allocate.</p>
         */
        @NonNull
        private final RectF mArcBounds = new RectF();

        /** Animator rotating the view, or null when not attached. */
        @Nullable
        private ObjectAnimator mRotation;

        /**
         * Constructs the spinner.
         *
         * @param context Context used for resource and density lookup
         */
        SpinnerView(@NonNull Context context) {
            super(context);

            mTrackPaint.setStyle(Paint.Style.STROKE);
            mTrackPaint.setStrokeCap(Paint.Cap.ROUND);
            mArcPaint.setStyle(Paint.Style.STROKE);
            mArcPaint.setStrokeCap(Paint.Cap.ROUND);

            setClickable(false);
            setFocusable(false);
        }

        /**
         * Sets the theme color.
         *
         * <p>The bright arc uses the color at full alpha; the track uses
         * the same color at {@link #TRACK_ALPHA}. Both are set in one
         * call, so the two are never out of step.</p>
         *
         * @param color Theme color as an ARGB integer
         */
        void setColor(int color) {
            mArcPaint.setColor(color);
            mTrackPaint.setColor((color & 0x00FFFFFF) | (TRACK_ALPHA << 24));
            invalidate();
        }

        /**
         * Starts the rotation animator when the view is attached to a
         * window.
         */
        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            startRotation();
        }

        /**
         * Cancels the rotation animator when the view is detached from
         * its window.
         */
        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            stopRotation();
        }

        /**
         * Starts the rotation animator when none is running.
         *
         * <p>Guarded against a second start so a detach followed by an
         * attach does not leave two animators running on the same
         * property.</p>
         */
        private void startRotation() {
            if (mRotation != null && mRotation.isRunning()) {
                return;
            }
            mRotation = ObjectAnimator.ofFloat(this, "rotation", 0f, 360f);
            mRotation.setDuration(ROTATION_PERIOD_MS);
            mRotation.setRepeatCount(ObjectAnimator.INFINITE);
            mRotation.setInterpolator(new LinearInterpolator());
            mRotation.start();
        }

        /**
         * Cancels the rotation animator and clears the field.
         *
         * <p>Idempotent. Called from
         * {@link #onDetachedFromWindow()} on every detach, including the
         * one the framework performs as part of the activity's
         * teardown.</p>
         */
        private void stopRotation() {
            if (mRotation != null) {
                mRotation.cancel();
                mRotation = null;
            }
        }

        /**
         * Draws the ring and the bright arc.
         *
         * @param canvas Canvas to draw into
         */
        @Override
        protected void onDraw(@NonNull Canvas canvas) {
            float centerX = getWidth() / 2f;
            float centerY = getHeight() / 2f;
            float stroke = getResources().getDisplayMetrics().density
                * SPINNER_STROKE_DP;
            float radius = Math.min(centerX, centerY) - stroke / 2f;

            mTrackPaint.setStrokeWidth(stroke);
            mArcPaint.setStrokeWidth(stroke);

            canvas.drawCircle(centerX, centerY, radius, mTrackPaint);

            mArcBounds.set(
                centerX - radius, centerY - radius,
                centerX + radius, centerY + radius);
            // -90f puts the arc's start at twelve o'clock. Sweep is
            // +90f clockwise.
            canvas.drawArc(mArcBounds, -90f,
                BRIGHT_ARC_SWEEP_DEGREES, false, mArcPaint);
        }
    }
}