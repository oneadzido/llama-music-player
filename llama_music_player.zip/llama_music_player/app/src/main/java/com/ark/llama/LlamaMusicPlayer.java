// LlamaMusicPlayer.java
package com.ark.llama;

import android.app.Application;

/**
 * Application subclass. Owns the process-lifetime
 * {@link BroadcastTranslator}.
 *
 * <p>The translator's receivers are registered here once at process
 * creation and unregistered at process termination. This is the
 * only place the translator's lifecycle is driven. Every class in
 * the app that used to register its own in-process broadcast
 * receivers now subscribes to {@link BroadcastTranslator}'s typed
 * events through the greenrobot EventBus; the translator is the
 * single registrar of those stems.</p>
 *
 * <h3>Scope</h3>
 * <p>This class does <b>not</b> hoist any initialization from other
 * classes. It does not create the notification controller, the
 * playlists, the media session, the audio focus listener, the
 * equalizer, the theme, or the language manager. Those objects are
 * created lazily by the first consumer that needs them, exactly as
 * they were before the migration. The only thing this class does
 * that the rest of the app depends on is start the translator, and
 * — on the rare devices where {@code onTerminate()} is called —
 * stop it.</p>
 *
 * <h3>Ordering</h3>
 * <p>The translator is started in {@code onCreate()} after
 * {@code super.onCreate()}. By the time any other component of the
 * app is created (activities, services, singletons' lazy
 * constructors), the translator's receivers are already
 * registered. There is therefore no window in which a broadcast
 * can fire before the translator is ready to translate it.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>On a real device {@code onTerminate()} is essentially never
 * called — Android kills the process instead. The stop is wired up
 * for two reasons: to keep the class symmetrical (register on
 * create, unregister on terminate), and to support instrumentation
 * tests that drive the Application lifecycle explicitly.</p>
 *
 * @see BroadcastTranslator
 * @see MusicService
 * @see MusicPlayer
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
public final class LlamaMusicPlayer extends Application {

    /**
     * Starts the {@link BroadcastTranslator}.
     *
     * <p>Called by the framework once, before any activity or
     * service is created. Idempotent: the translator refuses a
     * second start call from any class.</p>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        BroadcastTranslator.getInstance(this).start();
    }

    /**
     * Stops the {@link BroadcastTranslator}.
     *
     * <p>Called by the framework on emulated process termination.
     * Idempotent: the translator refuses a second stop call.</p>
     */
    @Override
    public void onTerminate() {
        BroadcastTranslator.getInstance(this).stop();
        super.onTerminate();
    }
}