// LanguageDialog.java
package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Presents the supported languages in a scrollable list and reports
 * the user's selection through {@link OnLanguageSelectedListener}.
 *
 * <p>Each row shows a language's endonym — the language's name in its
 * own script — and a "CURRENT" indicator on the row of the language
 * currently applied. When the dialog opens, the current language is
 * scrolled into the vertical center of the list. Tapping a row
 * animates the row and then notifies the listener before dismissing
 * the dialog.</p>
 *
 * <h3>Endonyms</h3>
 * <p>The names are not translated: a speaker browsing for their
 * language should recognise it in its own script, not in the current
 * locale's approximation of it. The array is supplied by
 * {@link LanguageManager#getLanguageNames()}, which owns it.</p>
 *
 * <h3>Top Bar Geometry</h3>
 * <p>The top bar is a horizontal {@link LinearLayout}. The Cancel
 * button sits at the start with its natural width, the title takes the
 * leftover width with a weight of 1, and a trailing placeholder
 * reserves no width. The title is the only element that can yield, so
 * a long Cancel label and a long title truncate rather than overlap.
 * The geometry matches every other dialog's top bar.</p>
 *
 * <h3>Selection</h3>
 * <p>On a tap, the row is highlighted, plays a bounce, and is held on
 * screen for {@link #DISMISS_DELAY_MS} milliseconds. When that delay
 * elapses, the listener is notified and the dialog dismisses itself.
 * The delay is the picker's own — it gives the animation and the
 * {@code CURRENT} indicator their beat — and is unrelated to what any
 * consumer of the selection does with it.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. Delayed work is scheduled on
 * {@link #mMainHandler}.</p>
 *
 * @see LanguageManager
 * @see ThemeHelper
 *
 * @author Richard Korbla Adzido
 * @version 1.3.5
 * @since 1.3.0
 */
public class LanguageDialog extends Dialog {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "LanguageDialog";

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Header background color, slightly lighter than the main background. */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";

    /** Background color of the currently selected language row. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";

    /** Touch highlight color applied to a pressed list row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for headers and secondary text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before dismissing the dialog after a selection, in milliseconds. */
    private static final long DISMISS_DELAY_MS = 500;

    /** Duration of button press and selection animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Height of the top action bar, in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of the header bar, in density-independent pixels. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;

    /** Height of action buttons, in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Standard padding for the top bar, in density-independent pixels. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Horizontal padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;

    /** Horizontal padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_VERTICAL_DP = 12;

    /** Padding around the "CURRENT" indicator text, in density-independent pixels. */
    private static final int INDICATOR_PADDING_DP = 8;

    /** Bottom padding of the dialog, in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 8;

    /** Thickness of dividers between rows, in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;

    /** Separator between the list header and the language count. */
    private static final String LANGUAGE_COUNT_SEPARATOR = " ";

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Context used to resolve resources and construct views. */
    private final Context mContext;

    /** Endonyms of the languages displayed in the list. */
    private final String[] mLanguageNames;

    /** BCP 47 tags of the languages, index-aligned with {@link #mLanguageNames}. */
    private final String[] mLanguageTags;

    /** Index of the language currently applied. */
    private final int mCurrentLanguageIndex;

    /** Listener notified when a language is selected, or null. */
    @Nullable
    private final OnLanguageSelectedListener mListener;

    /** Scroll view that contains the language list. */
    private ScrollView mScrollView;

    /** Container that holds every language row. */
    private LinearLayout mLanguageList;

    /** Manager that supplies the current theme color. */
    private final ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    private final ThemeHelper mThemeHelper;

    /** Timestamp of the last selection, used for debouncing. */
    private long mLastSelectionTime = 0;

    /** Timestamp of the last cancel click, used for debouncing. */
    private long mLastCancelClickTime = 0;

    /** Handler for delayed tasks on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ============================================================================
    // Listener Interface
    // ============================================================================

    /**
     * Receives language selection events.
     */
    public interface OnLanguageSelectedListener {

        /**
         * Called when the user selects a language.
         *
         * @param languageIndex Index of the selected language in the
         *        language arrays
         * @param languageName Endonym of the selected language
         * @param languageTag BCP 47 tag of the selected language
         */
        void onLanguageSelected(int languageIndex,
                                @NonNull String languageName,
                                @NonNull String languageTag);
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the dialog.
     *
     * @param context Context used to resolve resources and construct
     *        views
     * @param languageNames Endonyms shown in the list
     * @param languageTags BCP 47 tags, index-aligned with
     *        {@code languageNames}
     * @param currentLanguageIndex Index of the language currently
     *        applied
     * @param listener Listener notified when a language is selected, or
     *        null
     */
    public LanguageDialog(@NonNull Context context,
                          @NonNull String[] languageNames,
                          @NonNull String[] languageTags,
                          int currentLanguageIndex,
                          @Nullable OnLanguageSelectedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mLanguageNames = languageNames;
        mLanguageTags = languageTags;
        mCurrentLanguageIndex = currentLanguageIndex;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ============================================================================
    // Dialog Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the dialog's window, content view, and language list.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());

        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }

        scrollToCurrentLanguage();
        applyThemeToButtons();
    }

    /**
     * Dismisses the dialog and removes every pending handler callback.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    /** Returns a context that resolves resources using the currently selected app language. */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext).getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context", exception);
            return mContext;
        }
    }

    // ============================================================================
    // Window Configuration Methods
    // ============================================================================

    /**
     * Configures the dialog window for full-screen display.
     *
     * @param window Window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }

        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.LanguageDialogAnimation);
    }

    // ============================================================================
    // Theme Management Methods
    // ============================================================================

    /**
     * Applies the current theme color to every button in the dialog.
     */
    private void applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            findAndThemeButtons((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the current theme to every button in the given
     * view hierarchy.
     *
     * @param group View group to traverse
     */
    private void findAndThemeButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                findAndThemeButtons((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the selection styling to the given language row and clears
     * the styling from every other row.
     *
     * @param newSelectedIndex Index of the newly selected language
     */
    private void updateSelectedLanguage(int newSelectedIndex) {
        int themeColorInt = mThemeManager.getCurrentColorInt();

        for (int index = 0; index < mLanguageList.getChildCount(); index++) {
            View child = mLanguageList.getChildAt(index);

            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                LinearLayout item = (LinearLayout) child;
                int languageIndex = (Integer) item.getTag();
                boolean isSelected = (languageIndex == newSelectedIndex);

                item.setBackgroundColor(isSelected
                    ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                    : Color.TRANSPARENT);

                if (item.getChildCount() > 0) {
                    TextView name = (TextView) item.getChildAt(0);
                    if (name != null) {
                        name.setTextColor(isSelected
                            ? themeColorInt
                            : Color.parseColor(TEXT_COLOR_LIGHT));
                    }
                }

                if (item.getChildCount() > 1) {
                    TextView indicator = (TextView) item.getChildAt(1);
                    if (indicator != null) {
                        if (isSelected) {
                            indicator.setText(
                                getLocaleContext().getString(R.string.language_dialog_current));
                            indicator.setTextSize(12);
                            indicator.setLetterSpacing(0.1f);
                            indicator.setTextColor(themeColorInt);
                            indicator.setVisibility(View.VISIBLE);
                        } else {
                            indicator.setVisibility(View.GONE);
                        }
                    }
                }
            }
        }
    }

    // ============================================================================
    // Animation Methods
    // ============================================================================

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Applies the selection styling, plays a bounce animation on the
     * given row, then notifies the listener and dismisses the dialog.
     *
     * @param view Selected language row
     * @param languageIndex Index of the selected language
     * @param languageName Endonym of the selected language
     * @param languageTag BCP 47 tag of the selected language
     */
    private void animateLanguageSelection(@NonNull final View view,
                                          final int languageIndex,
                                          @NonNull final String languageName,
                                          @NonNull final String languageTag) {
        updateSelectedLanguage(languageIndex);

        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                      .scaleY(ANIMATION_SCALE_DOWN)
                      .setDuration(ANIMATION_DURATION_MS)
                      .withEndAction(new Runnable() {
                          @Override
                          public void run() {
                              view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                            .scaleY(ANIMATION_SCALE_NORMAL)
                                            .setDuration(ANIMATION_DURATION_MS)
                                            .start();
                          }
                      })
                      .start();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    mListener.onLanguageSelected(languageIndex,
                        languageName, languageTag);
                }
                dismiss();
            }
        }, DISMISS_DELAY_MS);
    }

    // ============================================================================
    // Scrolling Methods
    // ============================================================================

    /**
     * Scrolls the list so the current language appears in the vertical
     * center of the scroll view.
     */
    private void scrollToCurrentLanguage() {
        if (mScrollView == null || mLanguageList == null
                || mCurrentLanguageIndex < 0) {
            return;
        }

        mScrollView.post(new Runnable() {
            @Override
            public void run() {
                int targetIndex = findLanguageIndex();
                if (targetIndex >= 0) {
                    final View target = mLanguageList.getChildAt(targetIndex);
                    if (target != null) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int scrollViewHeight = mScrollView.getHeight();
                                int targetTop = target.getTop();
                                int targetHeight = target.getHeight();
                                int scrollY = targetTop
                                    - (scrollViewHeight / 2) + (targetHeight / 2);
                                mScrollView.smoothScrollTo(0, Math.max(0, scrollY));
                            }
                        }, 0);
                    }
                }
            }
        });
    }

    /**
     * Returns the index of the current language within the list view.
     *
     * @return Index of the current language in the list, or -1 when it
     *         is not present
     */
    private int findLanguageIndex() {
        for (int index = 0; index < mLanguageList.getChildCount(); index++) {
            View child = mLanguageList.getChildAt(index);
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                if ((Integer) child.getTag() == mCurrentLanguageIndex) {
                    return index;
                }
            }
        }
        return -1;
    }

    // ============================================================================
    // UI Construction Methods
    // ============================================================================

    /**
     * Creates the root content view of the dialog.
     *
     * @return The root view
     */
    @NonNull
    private View createContentView() {
        LinearLayout main = new LinearLayout(mContext);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[] {20, 20, 20, 20, 0, 0, 0, 0});
        main.setBackground(background);

        main.addView(createTopBar());
        main.addView(createHeader());
        main.addView(createScrollableList());
        main.addView(createBottomPadding());

        return main;
    }

    /**
     * Creates the top action bar.
     *
     * <p>A horizontal {@link LinearLayout}: the Cancel button at the
     * start with its natural width, the title in the middle with a
     * weight of 1, and an invisible trailing Themes-width spacer.
     * The title is the only element that can yield, so a long Cancel
     * label and a long title truncate rather than overlap.</p>
     *
     * @return The top bar layout
     */
    @NonNull
    private LinearLayout createTopBar() {
        LinearLayout topBar = new LinearLayout(mContext);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createPlaceholder());

        return topBar;
    }

    /**
     * Creates the Cancel button.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText(getLocaleContext().getString(R.string.action_cancel));
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3),
            dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);
        button.setSingleLine(true);
        button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        button.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });

        animateButton(button);
        return button;
    }

    /**
     * Creates the title text.
     *
     * <p>Takes the leftover width between the two edge slots with a
     * weight of 1, so a long translation truncates rather than
     * overlaps. Centred within the space it occupies.</p>
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(getLocaleContext());
        textView.setText(getLocaleContext().getString(R.string.language_dialog_title));
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);
        textView.setSingleLine(true);
        textView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textView.setPadding(dpToPx(INDICATOR_PADDING_DP), 0,
            dpToPx(INDICATOR_PADDING_DP), 0);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
            0, dpToPx(BUTTON_HEIGHT_DP), 1f));

        return textView;
    }

    /**
     * Creates an invisible trailing spacer matching the localized Themes button width.
     *
     * @return The width-reserving spacer
     */
    @NonNull
    private View createPlaceholder() {
        // Match the localized Themes action's measured width so the title
        // stays centered exactly like CreditsDialog, without adding an action.
        Button placeholder = new Button(mContext);
        placeholder.setText(getLocaleContext().getString(R.string.action_themes));
        placeholder.setTextSize(14);
        placeholder.setLetterSpacing(0.1f);
        placeholder.setBackgroundResource(R.drawable.button_border_selector);
        placeholder.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        placeholder.setMinHeight(0);
        placeholder.setMinWidth(0);
        placeholder.setIncludeFontPadding(false);
        placeholder.setSingleLine(true);
        placeholder.setEllipsize(android.text.TextUtils.TruncateAt.END);
        placeholder.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));
        placeholder.setVisibility(View.INVISIBLE);
        placeholder.setEnabled(false);
        placeholder.setFocusable(false);
        return placeholder;
    }

    /**
     * Creates the header bar showing the list label and language count.
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP),
            dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));

        TextView headerTitle = new TextView(mContext);
        headerTitle.setText(getLocaleContext().getString(R.string.language_dialog_list_header));
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView headerCount = new TextView(mContext);
        headerCount.setText(LANGUAGE_COUNT_SEPARATOR + getLocaleContext().getResources().getQuantityString(
            R.plurals.language_dialog_count,
            mLanguageNames.length,
            mLanguageNames.length));
        headerCount.setTextSize(12);
        headerCount.setLetterSpacing(0.1f);
        headerCount.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));

        header.addView(headerTitle);
        header.addView(headerCount);

        return header;
    }

    /**
     * Creates the scrollable list that contains every language row.
     *
     * @return The scroll view containing the language list
     */
    @NonNull
    private ScrollView createScrollableList() {
        mScrollView = new ScrollView(mContext);
        mScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        mScrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        mLanguageList = new LinearLayout(mContext);
        mLanguageList.setOrientation(LinearLayout.VERTICAL);
        mLanguageList.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        for (int languageIndex = 0; languageIndex < mLanguageNames.length;
                languageIndex++) {
            final int index = languageIndex;
            final String name = mLanguageNames[languageIndex];
            final String tag = mLanguageTags[languageIndex];
            final boolean selected = (languageIndex == mCurrentLanguageIndex);

            final LinearLayout item = createLanguageItem(index, name, tag, selected);
            mLanguageList.addView(item);

            if (languageIndex < mLanguageNames.length - 1) {
                mLanguageList.addView(createDivider());
            }
        }

        mScrollView.addView(mLanguageList);
        return mScrollView;
    }

    /**
     * Creates a single language row with a name and a current indicator.
     *
     * @param languageIndex Index of the language in the language arrays
     * @param name Endonym of the language
     * @param tag BCP 47 tag of the language
     * @param selected True when this language is the current one
     * @return The language row layout
     */
    @NonNull
    private LinearLayout createLanguageItem(final int languageIndex,
                                             @NonNull final String name,
                                             @NonNull final String tag,
                                             final boolean selected) {
        final LinearLayout item = new LinearLayout(mContext);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setPaddingRelative(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP),
            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        item.setTag(languageIndex);
        item.setBackgroundColor(selected
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
            : Color.TRANSPARENT);

        item.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(
                            Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setBackgroundColor(selected
                            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                            : Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        TextView nameView = new TextView(mContext);
        nameView.setText(name);
        nameView.setTextSize(14);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setTextColor(selected
            ? mThemeManager.getCurrentColorInt()
            : Color.parseColor(TEXT_COLOR_LIGHT));
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView indicator = new TextView(mContext);
        if (selected) {
            indicator.setText(getLocaleContext().getString(R.string.language_dialog_current));
            indicator.setTextSize(12);
            indicator.setLetterSpacing(0.1f);
            indicator.setTextColor(mThemeManager.getCurrentColorInt());
            indicator.setVisibility(View.VISIBLE);
        } else {
            indicator.setVisibility(View.GONE);
        }

        // A single logical start margin. The gap between the language
        // name and the CURRENT indicator is inter-sibling spacing
        // inside a horizontal LinearLayout, which is a margin rather
        // than the TextView's own padding. The trailing inset is
        // supplied by the row's own end padding.
        LinearLayout.LayoutParams indicatorParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        indicatorParams.setMarginStart(dpToPx(INDICATOR_PADDING_DP));
        indicator.setLayoutParams(indicatorParams);

        item.addView(nameView);
        item.addView(indicator);

        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSelectionTime = currentTime;
                    animateLanguageSelection(item, languageIndex, name, tag);
                }
            }
        });

        return item;
    }

    /**
     * Creates a divider view that separates two language rows.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates the bottom padding view.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}