package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.media.session.MediaButtonReceiver;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Service for managing media playback notifications.
 * 
 * <p>This class provides a comprehensive notification system for music playback
 * that follows industry standards. The notification is shown when media is loaded
 * or actively playing. It integrates with the NavigationController to display
 * sync status during playlist updates.</p>
 * 
 * <p>Transport actions (play/pause, next, previous) are dispatched through
 * {@link MediaButtonReceiver#buildMediaButtonPendingIntent} so that each tap
 * flows through the active {@link MediaSessionCompat} held by
 * {@link MusicService}. This routes notification taps through the same
 * callback path as hardware and headset buttons, with no service start and
 * no foreground-promotion race on the tap path. The notification's
 * {@code MediaStyle} is bound to the session token so Wear OS, Android Auto,
 * and the system media controls surface resolve the correct transport.</p>
 * 
 * <p>Playback state (Playing / Paused / Syncing) is rendered on the
 * notification itself via {@code setSubText}. The channel name is a stable
 * string that is never rewritten at runtime.</p>
 * 
 * <h3>Transport PendingIntents</h3>
 * <p>The three transport PendingIntents are constructed once, in the
 * constructor, and stored as instance fields. This placement avoids a
 * {@code PackageManager.queryIntentServices} IPC on every notification
 * rebuild, which for a rebuilding cadence of several per second during
 * playback would mean a sustained stream of package-manager queries from
 * the main thread. The PendingIntents themselves are immutable for the life
 * of the process, so rebuilding them per notification is unnecessary in
 * addition to being expensive.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Media playback controls (play/pause, next, previous, close)</li>
 *   <li>Album art display with caching and memory management</li>
 *   <li>Theme color integration for visual consistency</li>
 *   <li>Sync state indication during playlist updates</li>
 *   <li>Watchdog timer that resets stuck sync state</li>
 *   <li>Forced notification refresh when sync ends</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class NotificationService implements NavigationController.ButtonStateListener {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "NotificationService";
    
    /** Notification channel ID for music playback. */
    private static final String CHANNEL_ID = "music_playback_channel";
    
    /** Group key for grouping notifications. */
    private static final String GROUP_KEY = "llama_music_group";
    
    /** Notification ID for the main playback notification. */
    public static final int NOTIFICATION_ID = 1;
    
    /** Notification ID for the group summary notification. */
    private static final int GROUP_SUMMARY_ID = 2;
    
    /** Maximum size for album art in pixels. */
    private static final int MAX_ART_SIZE = 300;
    
    /** Maximum cache size for album art in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 25;
    
    /** Neutral color for secondary action buttons (silver/gray). */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;
    
    /** Red color for close action button. */
    private static final int RED_COLOR = 0xFFE53935;
    
    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;
    
    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Default icon size in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;
    
    /** Timeout for stuck sync state (30 seconds). */
    private static final long SYNC_TIMEOUT_MS = 30000;
    
    /** Stable channel name shown in Settings. Never rewritten at runtime. */
    private static final String CHANNEL_NAME = "Playback";
    
    /** Stable channel description shown in Settings. */
    private static final String CHANNEL_DESCRIPTION = "Media playback controls";
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Immutable state object representing the current notification state.
     * 
     * <p>This class encapsulates all the information needed to build the
     * notification, including playback state, metadata, and album art.
     * Immutability ensures thread-safe state transitions.</p>
     */
    private static class NotificationState {
        
        /** The current channel state (e.g., "Playing", "Paused", "Syncing", "Resting"). */
        final String channelState;
        
        /** Whether music is currently playing. */
        final boolean isPlaying;
        
        /** The song title (empty string if none). */
        final String title;
        
        /** The artist name (empty string if none). */
        final String artist;
        
        /** The album art bitmap (null if none). */
        final Bitmap albumArt;
        
        /** The placeholder bitmap for when album art is missing (null if none). */
        final Bitmap placeholder;
        
        /** Cache key for the album art bitmap. */
        final String artKey;

        /**
         * Constructs a new NotificationState.
         *
         * @param channelState The current channel state
         * @param isPlaying True if music is playing
         * @param title The song title
         * @param artist The artist name
         * @param albumArt The album art bitmap
         * @param placeholder The placeholder bitmap
         * @param artKey The cache key for album art
         */
        NotificationState(String channelState, boolean isPlaying, 
                         String title, String artist, 
                         Bitmap albumArt, Bitmap placeholder, String artKey) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.placeholder = placeholder;
            this.artKey = artKey;
        }
    }
    
    /**
     * Functional interface for updating the notification state.
     */
    private interface StateUpdater {
        
        /**
         * Updates the notification state.
         *
         * @param current The current state
         * @return The new state
         */
        NotificationState update(NotificationState current);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** The service this notification service is attached to. */
    private final Service mService;
    
    /** Notification manager for displaying notifications. */
    private NotificationManager mNotificationManager;
    
    /** Main thread handler for UI operations. */
    private final Handler mMainHandler;
    
    /** Handler for sync timeout watchdog. */
    private final Handler mTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for sync timeout watchdog. */
    private final Runnable mSyncTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsSyncActive) {
                Log.w(TAG, "Sync state stuck for " + SYNC_TIMEOUT_MS + "ms, forcing reset");
                mIsSyncActive = false;
                updateSyncState();
                forceUpdate();
            }
        }
    };
    
    /** Current notification state (atomic reference for thread safety). */
    private final AtomicReference<NotificationState> mCurrentState = 
        new AtomicReference<NotificationState>(new NotificationState("Resting", false, 
                                                    "", "", null, null, null));
    
    /** Flag indicating whether the service is in foreground mode. */
    private final AtomicBoolean mForegroundStarted = new AtomicBoolean(false);
    
    /** Flag indicating whether a notification update is scheduled. */
    private final AtomicBoolean mUpdateScheduled = new AtomicBoolean(false);
    
    /** LRU cache for album art bitmaps. */
    private final LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Lock object for notification operations. */
    private final Object mNotificationLock = new Object();
    
    /** Flag indicating whether a playlist sync is active. */
    private boolean mIsSyncActive = false;
    
    /**
     * Supplier for the active MediaSessionCompat token, populated by
     * {@link MusicService} after session setup. The notification's
     * MediaStyle binds to the session so Wear OS, Android Auto, and the
     * system media controls surface resolve the correct transport.
     */
    @Nullable
    private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;
    
    /**
     * Transport PendingIntent for PLAY_PAUSE. Built once, in the constructor,
     * because {@link MediaButtonReceiver#buildMediaButtonPendingIntent}
     * performs a {@code PackageManager.queryIntentServices} IPC on every
     * call. The PendingIntent is immutable and safe to reuse across
     * notification rebuilds.
     */
    @Nullable
    private PendingIntent mPlayPauseIntent;
    
    /**
     * Transport PendingIntent for SKIP_TO_NEXT. See {@link #mPlayPauseIntent}
     * for the rationale on constructor-time construction.
     */
    @Nullable
    private PendingIntent mNextIntent;
    
    /**
     * Transport PendingIntent for SKIP_TO_PREVIOUS. See {@link #mPlayPauseIntent}
     * for the rationale on constructor-time construction.
     */
    @Nullable
    private PendingIntent mPrevIntent;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new NotificationService.
     *
     * <p>The constructor also builds the three transport PendingIntents and
     * stores them as instance fields. Construction is the only point at
     * which the class touches the package manager for media button
     * resolution; the fields are reused for every subsequent notification
     * rebuild.</p>
     *
     * @param service The service this notification service is attached to
     */
    public NotificationService(@NonNull Service service) {
        mService = service;
        mContext = service.getApplicationContext();
        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
            
            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled()) {
                    NotificationState state = mCurrentState.get();
                    if (oldValue != state.albumArt && oldValue != state.placeholder) {
                        safeRecycleBitmap(oldValue);
                    }
                }
            }
        };
        
        createNotificationChannel();
        
        mPlayPauseIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mNextIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_NEXT);
        mPrevIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
        
        NavigationController.getInstance().registerListener(this);
    }
    
    // ========================================================================
    // Session Token Plumbing
    // ========================================================================
    
    /**
     * Sets the supplier used to obtain the active {@link MediaSessionCompat}
     * token. Called by {@link MusicService} after session setup so the
     * notification's MediaStyle can bind to the session without a hard
     * reference.
     *
     * @param provider The token supplier, or null to clear
     */
    public void setSessionTokenProvider(@Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }
    
    // ========================================================================
    // NavigationController.ButtonStateListener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes in NavigationController.
     * Updates the sync state when folder actions are disabled.
     * 
     * <p>A timeout watchdog resets stuck sync state and forces notification
     * refresh when sync ends to overcome channel name caching.</p>
     *
     * @param group The button group that changed
     * @param disabled True if buttons in this group are disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            mIsSyncActive = disabled;
            updateSyncState();
            
            if (disabled) {
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                mTimeoutHandler.postDelayed(mSyncTimeoutRunnable, SYNC_TIMEOUT_MS);
                Log.d(TAG, "Sync started, watchdog timer started");
            } else {
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                forceUpdate();
                Log.d(TAG, "Sync ended, forced notification refresh");
            }
        }
    }
    
    /**
     * Updates the notification state based on current sync activity.
     */
    public void updateSyncState() {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                String newState;
                
                if (mIsSyncActive) {
                    newState = "Syncing";
                } else {
                    if (current.title != null && !current.title.isEmpty()) {
                        newState = current.isPlaying ? "Playing" : "Paused";
                    } else {
                        newState = "Resting";
                    }
                }
                
                return new NotificationState(
                    newState,
                    current.isPlaying,
                    current.title,
                    current.artist,
                    current.albumArt,
                    current.placeholder,
                    current.artKey
                );
            }
        });
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Stops the foreground notification and releases resources.
     * This method is called when the service is being destroyed.
     */
    public void stopForeground() {
        release();
    }
    
    /**
     * Releases all resources and unregisters from NavigationController.
     * After this method is called, the notification service is not used.
     */
    public void release() {
        mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
        
        NavigationController.getInstance().unregisterListener(this);
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return new NotificationState(
                    "Resting",
                    false,
                    "",
                    "",
                    null,
                    null,
                    null
                );
            }
        });
    }
    
    /**
     * Synchronously promotes the service to foreground with the current
     * notification state. Called from {@code MusicService.onStartCommand}
     * before any state-machine work, so the framework's foreground contract
     * is satisfied even when the main looper is backed up by a burst of
     * incoming commands.
     * 
     * <p>No-op if the service is already foreground, or if no valid
     * notification content exists yet.</p>
     */
    public void startForegroundSync() {
        if (mForegroundStarted.get()) {
            return;
        }
        
        final NotificationState state = mCurrentState.get();
        if (state == null) {
            return;
        }
        
        final boolean hasContent = state.title != null && !state.title.isEmpty();
        final boolean isValidState = !"Resting".equals(state.channelState) && hasContent;
        if (!isValidState) {
            return;
        }
        
        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager)
                        mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                final Notification notification = buildNotification(state);
                mNotificationManager.notify(NOTIFICATION_ID, notification);
                mService.startForeground(NOTIFICATION_ID, notification);
                mForegroundStarted.set(true);
                Log.d(TAG, "Foreground promoted synchronously");
            } catch (Exception exception) {
                Log.e(TAG, "startForegroundSync failed", exception);
            }
        }
    }
    
    /**
     * Forces a notification update regardless of state changes. Gated by
     * the same {@code mUpdateScheduled} flag used by
     * {@link #scheduleNotificationUpdate()}, so a burst of calls collapses
     * into a single rebuild rather than queuing one rebuild per call.
     */
    public void forceUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }
        if (mMainHandler != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    mUpdateScheduled.set(false);
                    performUpdateNotification();
                }
            });
        }
    }
    
    // ========================================================================
    // Core API Methods
    // ========================================================================
    
    /**
     * Updates the song information in the notification.
     *
     * @param title The song title (can be null)
     * @param artist The artist name (can be null)
     * @param artPath The file path of the album art (can be null)
     */
    public void updateSongInfo(@Nullable final String title, @Nullable final String artist, @Nullable final String artPath) {
        final String newTitle = (title != null && !title.isEmpty()) ? title : "";
        final String newArtist = (artist != null && !artist.isEmpty()) ? artist : "";
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                String newState = current.channelState;
                
                if (!newTitle.isEmpty()) {
                    newState = current.isPlaying ? "Playing" : "Paused";
                } else {
                    newState = "Resting";
                }
                
                if (mIsSyncActive) {
                    newState = "Syncing";
                }
                
                return new NotificationState(
                    newState,
                    current.isPlaying,
                    newTitle,
                    newArtist,
                    current.albumArt,
                    current.placeholder,
                    current.artKey
                );
            }
        });
    }
    
    /**
     * Sets the album art for the notification.
     * 
     * <p>The album art and placeholder bitmap fields are always kept
     * distinct. The render path ({@link #getSafeLargeIcon}) falls back to
     * the placeholder when no album art is present, so the placeholder is
     * never duplicated into the album art field.</p>
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap for when art is missing (can be null)
     * @param artPath The file path of the album art (used for caching)
     */
    public void setAlbumArt(@Nullable final Bitmap art, @Nullable final Bitmap placeholder, @Nullable final String artPath) {
        final Bitmap finalArt = art;
        final Bitmap finalPlaceholder = placeholder;
        final String finalArtPath = artPath;
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                Bitmap newPlaceholder = current.placeholder;
                if (finalPlaceholder != null && !finalPlaceholder.isRecycled()) {
                    if (newPlaceholder == null || newPlaceholder.isRecycled() || 
                        finalPlaceholder != newPlaceholder) {
                        safeRecycleBitmap(newPlaceholder);
                        newPlaceholder = createSafeCopy(finalPlaceholder, MAX_ART_SIZE);
                    }
                }
                
                Bitmap newAlbumArt = null;
                String newArtKey = null;
                
                if (finalArt != null && !finalArt.isRecycled()) {
                    String cacheKey = (finalArtPath != null) ? finalArtPath : 
                                     Integer.toHexString(finalArt.hashCode());
                    Bitmap cachedBitmap = mAlbumArtCache.get(cacheKey);
                    
                    if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
                        newAlbumArt = cachedBitmap;
                        newArtKey = cacheKey;
                    } else {
                        Bitmap safeCopy = createSafeCopy(finalArt, MAX_ART_SIZE);
                        if (safeCopy != null) {
                            mAlbumArtCache.put(cacheKey, safeCopy);
                            newAlbumArt = safeCopy;
                            newArtKey = cacheKey;
                        }
                    }
                }
                
                if (current.albumArt != newAlbumArt) {
                    safeRecycleBitmap(current.albumArt);
                }
                
                return new NotificationState(
                    current.channelState,
                    current.isPlaying,
                    current.title,
                    current.artist,
                    newAlbumArt,
                    newPlaceholder,
                    newArtKey
                );
            }
        });
    }
    
    /**
     * Sets the playing state in the notification.
     *
     * @param playing True if music is playing, false if paused
     */
    public void setPlayingState(final boolean playing) {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                String newState = current.channelState;
                
                if (!mIsSyncActive && current.title != null && !current.title.isEmpty()) {
                    newState = playing ? "Playing" : "Paused";
                }
                
                return new NotificationState(
                    newState,
                    playing,
                    current.title,
                    current.artist,
                    current.albumArt,
                    current.placeholder,
                    current.artKey
                );
            }
        });
    }
    
    // ========================================================================
    // State Management Methods
    // ========================================================================
    
    /**
     * Updates the notification state atomically.
     * 
     * <p>The channel name is never rewritten; the state is rendered through
     * {@code subText} on the notification itself.</p>
     *
     * @param updater The state updater function
     */
    private void updateState(StateUpdater updater) {
        NotificationState oldState, newState;
        do {
            oldState = mCurrentState.get();
            newState = updater.update(oldState);
        } while (!mCurrentState.compareAndSet(oldState, newState));
        
        scheduleNotificationUpdate();
    }
    
    /**
     * Schedules a notification update on the main thread.
     * Uses a flag to prevent multiple pending updates.
     */
    private void scheduleNotificationUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mUpdateScheduled.set(false);
                performUpdateNotification();
            }
        });
    }
    
    /**
     * Performs the actual notification update.
     * Builds and displays the notification based on current state.
     */
    private void performUpdateNotification() {
        NotificationState state = mCurrentState.get();
        
        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                boolean hasContent = state.title != null && !state.title.isEmpty();
                boolean isValidState = !"Resting".equals(state.channelState) && hasContent;
                
                if (isValidState) {
                    Notification notification = buildNotification(state);
                    mNotificationManager.notify(NOTIFICATION_ID, notification);
                    updateGroupSummary(state);
                    
                    if (!mForegroundStarted.getAndSet(true)) {
                        mService.startForeground(NOTIFICATION_ID, notification);
                        Log.d(TAG, "Foreground service started");
                    }
                } else {
                    mNotificationManager.cancel(NOTIFICATION_ID);
                    mNotificationManager.cancel(GROUP_SUMMARY_ID);
                    
                    if (mForegroundStarted.getAndSet(false)) {
                        mService.stopForeground(true);
                        Log.d(TAG, "Foreground service stopped - no content");
                    }
                }
            } catch (SecurityException exception) {
                Log.e(TAG, "Missing notification permission", exception);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to update notification", exception);
            }
        }
    }
    
    // ========================================================================
    // Notification Building Methods
    // ========================================================================
    
    /**
     * Builds the notification based on the current state.
     * 
     * <p>Transport actions are dispatched through
     * {@link MediaButtonReceiver#buildMediaButtonPendingIntent}, routing each
     * tap through the active {@link MediaSessionCompat} instead of starting
     * the service. The close action sends an explicit stop to the service,
     * which pauses playback cleanly without an activity start.</p>
     * 
     * <p>The three transport PendingIntents are read from instance fields
     * that were initialized in the constructor. The close action's
     * PendingIntent is constructed per rebuild because it targets the
     * service directly and does not go through the package-manager
     * resolution that would justify caching.</p>
     *
     * @param state The current notification state
     * @return The built notification
     */
    @NonNull
    private Notification buildNotification(NotificationState state) {
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            themeColor = ThemeHelper.getDefaultColor();
        }
        
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);
        
        PendingIntent playPauseIntent = mPlayPauseIntent;
        PendingIntent nextIntent      = mNextIntent;
        PendingIntent prevIntent      = mPrevIntent;
        PendingIntent closeIntent     = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            flags);
        
        String title = state.title.isEmpty() ? "Unknown Title" : state.title;
        String artist = state.artist.isEmpty() ? "Unknown Artist" : state.artist;
        String subText = "";
        
        if ("Playing".equals(state.channelState)) {
            subText = "Playing";
        } else if ("Paused".equals(state.channelState)) {
            subText = "Paused";
        } else if ("Syncing".equals(state.channelState)) {
            subText = "Syncing";
        }
        
        if (title.length() > MAX_TITLE_LENGTH) {
            title = title.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (artist.length() > MAX_ARTIST_LENGTH) {
            artist = artist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }
        
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_ID);
        } else {
            @SuppressWarnings("deprecation")
            Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
            builder = deprecatedBuilder;
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(artist)
            .setSubText(subText)
            .setColor(themeColor)
            .setColorized(true)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)
            .setGroup(GROUP_KEY);
        
        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }
        
        if (prevIntent != null) {
            addActionButton(builder, R.drawable.ic_notification_prev, "Prev", prevIntent, NEUTRAL_COLOR);
        }
        if (playPauseIntent != null) {
            int playPauseRes = state.isPlaying ? R.drawable.ic_notification_pause : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying ? "Pause" : "Play";
            addActionButton(builder, playPauseRes, playPauseLabel, playPauseIntent, themeColor);
        }
        if (nextIntent != null) {
            addActionButton(builder, R.drawable.ic_notification_next, "Next", nextIntent, NEUTRAL_COLOR);
        }
        addActionButton(builder, R.drawable.ic_notification_close, "Close", closeIntent, RED_COLOR);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.app.Notification.MediaStyle style = new android.app.Notification.MediaStyle();
            style.setShowActionsInCompactView(0, 1, 2);
            
            final MediaSessionCompat.Token compatToken =
                mSessionTokenProvider != null ? mSessionTokenProvider.get() : null;
            if (compatToken != null) {
                final Object rawToken = compatToken.getToken();
                if (rawToken instanceof android.media.session.MediaSession.Token) {
                    style.setMediaSession((android.media.session.MediaSession.Token) rawToken);
                }
            }
            
            builder.setStyle(style);
        }
        
        return builder.build();
    }
    
    /**
     * Adds an action button to the notification.
     *
     * @param builder The notification builder
     * @param iconRes The icon resource ID
     * @param label The button label
     * @param intent The pending intent for the button
     * @param color The icon color
     */
    private void addActionButton(Notification.Builder builder, int iconRes, 
                                  String label, PendingIntent intent, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon icon = createThemedIcon(iconRes, color);
            if (icon != null) {
                Notification.Action action = new Notification.Action.Builder(icon, label, intent).build();
                builder.addAction(action);
                return;
            }
        }
        
        @SuppressWarnings("deprecation")
        Notification.Action action = new Notification.Action.Builder(iconRes, label, intent).build();
        builder.addAction(action);
    }
    
    /**
     * Gets a safe large icon for the notification.
     *
     * @param state The current notification state
     * @return The large icon bitmap, or null if none available
     */
    @Nullable
    private Bitmap getSafeLargeIcon(NotificationState state) {
        if (state.artKey != null) {
            Bitmap cachedBitmap = mAlbumArtCache.get(state.artKey);
            if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
                return cachedBitmap;
            }
        }
        
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        
        if (state.placeholder != null && !state.placeholder.isRecycled()) {
            return state.placeholder;
        }
        
        return null;
    }
    
    /**
     * Creates a safe copy of a bitmap scaled to the specified maximum size.
     *
     * @param source The source bitmap
     * @param maxSize The maximum dimension in pixels
     * @return The scaled bitmap copy, or null if copy fails
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            
            if (width <= 0 || height <= 0) {
                return null;
            }
            
            Bitmap scaledBitmap;
            if (width <= maxSize && height <= maxSize) {
                scaledBitmap = source.copy(source.getConfig() != null ? source.getConfig() : Bitmap.Config.ARGB_8888, false);
            } else {
                float scale = Math.min((float) maxSize / width, (float) maxSize / height);
                scaledBitmap = Bitmap.createScaledBitmap(source, Math.round(width * scale), Math.round(height * scale), true);
            }
            
            return scaledBitmap;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to create safe bitmap copy", exception);
            return null;
        }
    }
    
    /**
     * Safely recycles a bitmap.
     *
     * @param bitmap The bitmap to recycle (can be null)
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception ignored) {
            }
        }
    }
    
    /**
     * Creates a themed icon with the specified color.
     *
     * @param drawableRes The drawable resource ID
     * @param color The icon color
     * @return The themed icon, or null if creation fails
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);
            
            if (drawable == null) {
                Log.w(TAG, "Failed to load drawable: " + drawableRes);
                return null;
            }
            
            drawable.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            
            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }
            
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            } else {
                return null;
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to create themed icon", exception);
            return null;
        }
    }
    
    // ========================================================================
    // Notification Channel Methods
    // ========================================================================
    
    /**
     * Creates the notification channel for Android O and above.
     * 
     * <p>The channel name is a stable string that is never rewritten at
     * runtime. Playback state is rendered on the notification itself via
     * {@code setSubText}.</p>
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                NotificationChannel existingChannel = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (existingChannel == null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        CHANNEL_NAME,
                        NotificationManager.IMPORTANCE_LOW
                    );
                    channel.setDescription(CHANNEL_DESCRIPTION);
                    channel.setShowBadge(false);
                    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    channel.setSound(null, null);
                    channel.enableVibration(false);
                    mNotificationManager.createNotificationChannel(channel);
                    Log.d(TAG, "Created notification channel: " + CHANNEL_NAME);
                }
            } catch (Exception exception) {
                Log.e(TAG, "Failed to create notification channel", exception);
            }
        }
    }
    
    /**
     * Updates the group summary notification.
     *
     * @param state The current notification state
     */
    private void updateGroupSummary(NotificationState state) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && mNotificationManager != null) {
            try {
                int themeColor;
                try {
                    ThemeManager themeManager = ThemeManager.getInstance(mContext);
                    themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
                } catch (Exception exception) {
                    themeColor = ThemeHelper.getDefaultColor();
                }
                
                String displayText = "Llama • " + state.channelState;
                
                Notification.Builder summaryBuilder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    summaryBuilder = new Notification.Builder(mContext, CHANNEL_ID);
                } else {
                    @SuppressWarnings("deprecation")
                    Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
                    summaryBuilder = deprecatedBuilder;
                }
                
                summaryBuilder.setSmallIcon(R.drawable.ic_notification)
                    .setGroup(GROUP_KEY)
                    .setGroupSummary(true)
                    .setContentTitle(displayText)
                    .setContentText(getChannelDescription(state.channelState))
                    .setColor(themeColor)
                    .setOngoing(true)
                    .setShowWhen(false);
                    
                mNotificationManager.notify(GROUP_SUMMARY_ID, summaryBuilder.build());
            } catch (Exception exception) {
                Log.e(TAG, "Failed to update group summary", exception);
            }
        }
    }
    
    /**
     * Gets the channel description based on current state.
     *
     * @param state The current channel state
     * @return The channel description string
     */
    private String getChannelDescription(String state) {
        if ("Playing".equals(state)) {
            return "Currently playing";
        } else if ("Paused".equals(state)) {
            return "Currently paused";
        } else if ("Syncing".equals(state)) {
            return "Syncing playlist...";
        } else {
            return "Playback controls";
        }
    }
}