package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.media.session.MediaButtonReceiver;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Service for managing media playback notifications.
 *
 * <p>This class provides the notification system for music playback. The
 * notification carries the song title, artist, transport controls, and
 * album art, and its {@code MediaStyle} is bound to the active
 * {@link MediaSessionCompat} held by {@link MusicService} so Wear OS,
 * Android Auto, and the system media controls surface resolve the correct
 * transport.</p>
 *
 * <p>Transport actions (play/pause, next, previous) are dispatched through
 * {@link MediaButtonReceiver#buildMediaButtonPendingIntent} so that each
 * tap flows through the active session. Notification taps therefore follow
 * the same callback path as hardware and headset buttons.</p>
 *
 * <h3>Foreground Contract</h3>
 * <p>{@link #startForegroundSync()} posts the notification and calls
 * {@link Service#startForeground(int, Notification)} on every invocation.
 * {@link MediaButtonReceiver} starts the service via
 * {@code startForegroundService} on every notification transport button
 * tap. Each such call opens a window within which {@code startForeground}
 * must be called; the system terminates the process when the window
 * elapses without the call. {@code startForeground} is idempotent — the
 * framework treats a repeat call with the same ID as an update — so the
 * unconditional call is well-defined.</p>
 *
 * <h3>Foreground while Playing</h3>
 * <p>The service holds the foreground promotion while
 * {@link #STATE_PLAYING} is the rendered state. SystemUI disables the
 * Dismiss action on a notification backed by a foreground service, so the
 * promotion is present while playing and absent while paused, and the
 * paused notification is dismissible through the swiped-away path wired to
 * {@code ACTION_STOP} via {@link Notification.Builder#setDeleteIntent}.</p>
 *
 * <h3>Single Rebuild per State Change</h3>
 * <p>Every state-mutating call — {@link #updateSongInfo},
 * {@link #setAlbumArt}, {@link #setPlayingState} — routes through
 * {@link #updateState}, which ends in {@link #scheduleNotificationUpdate}.
 * That method is guarded by {@link #mUpdateScheduled} so a burst of
 * changes coalesces into one rebuild. {@link MusicService} exploits the
 * coalescing: on every commit it hands the notification the song's title,
 * artist, play/pause mode, and (when already cached) album art in the same
 * main-thread iteration, so the notification rebuilds once with all fields
 * already committed.</p>
 *
 * <h3>Album Art Lifecycle</h3>
 * <p>The album art bitmap is retained across song changes. When
 * {@link #updateSongInfo} receives a new song path, it clears only the
 * cache key, so the previous song's art stays visible until
 * {@link #setAlbumArt} pushes the new song's art. This matches how the
 * activity's album art {@code ImageView} holds its previous bitmap until
 * the new art loads and fades in.</p>
 *
 * <p>The cache key is cleared on a song change because
 * {@link #getSafeLargeIcon} resolves it to a bitmap; leaving the old key
 * would display the previous song's art under the new song's metadata.
 * The entry under the old path is also removed from the cache in the
 * same transition, so the cache's byte accounting stays accurate and
 * nothing later evicts a bitmap that {@link #setAlbumArt} has already
 * recycled.</p>
 *
 * <p>The album art and placeholder bitmap fields are kept distinct. The
 * render path ({@link #getSafeLargeIcon}) falls back to the placeholder
 * when no album art is present, so the placeholder is never duplicated
 * into the album art field.</p>
 *
 * <h3>Resting State</h3>
 * <p>When the queue is empty and no song is bound to the player, the
 * notification renders the placeholder strings {@code "Title"} and
 * {@code "Artist"}, matching the player UI's no-song placeholders. A
 * loaded song's title and artist are rendered as received from the
 * service; the mapper that produces those strings has already substituted
 * the "Unknown ..." markers for missing metadata.</p>
 *
 * <h3>Channel Importance</h3>
 * <p>The notification channel is created at
 * {@link NotificationManager#IMPORTANCE_DEFAULT} so the small icon is
 * permitted to appear wherever the platform chooses to render the
 * notification. Sound and vibration are disabled on the channel; the
 * importance setting affects only where the icon is permitted to
 * appear.</p>
 *
 * <h3>Small Icon</h3>
 * <p>The theme colour reaches the notification through {@code setColor}
 * and through the per-action themed icons produced by
 * {@link #createThemedIcon(int, int)}. On API 31 and above,
 * {@link Notification.Builder#setForegroundServiceBehavior(int)} is set to
 * {@link Notification#FOREGROUND_SERVICE_IMMEDIATE} so the status-bar icon
 * of the media playback foreground service is drawn as soon as the
 * promotion is committed.</p>
 *
 * <h3>Transport PendingIntents</h3>
 * <p>The three transport PendingIntents are constructed once, in the
 * constructor, and stored as instance fields. Construction is the only
 * point at which the class touches the package manager for media button
 * resolution, and the fields are reused for every subsequent notification
 * rebuild. The PendingIntents are immutable for the life of the process.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class NotificationService {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "NotificationService";

    /** Notification channel ID for music playback. */
    private static final String CHANNEL_ID = "music_playback_channel";

    /** Notification ID for the playback notification. */
    public static final int NOTIFICATION_ID = 1;

    /** Maximum size for album art in pixels. */
    private static final int MAX_ART_SIZE = 300;

    /** Maximum cache size for album art in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 25;

    /** Neutral color for secondary action buttons (silver/gray). */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;

    /** Red color for close action button. */
    private static final int RED_COLOR = 0xFFE53935;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;

    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";

    /** Default icon size in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;

    /** Stable channel name shown in Settings. */
    private static final String CHANNEL_NAME = "Playback";

    /** Stable channel description shown in Settings. */
    private static final String CHANNEL_DESCRIPTION = "Media playback controls";

    /**
     * Placeholder title shown when the queue is empty. Matches the player
     * UI's no-song placeholder in {@code MusicPlayer.applyNoSongState()}.
     */
    private static final String PLACEHOLDER_TITLE = "Title";

    /**
     * Placeholder artist shown when the queue is empty. Matches the player
     * UI's no-song placeholder in {@code MusicPlayer.applyNoSongState()}.
     */
    private static final String PLACEHOLDER_ARTIST = "Artist";

    /** The channel state string used when no song is loaded. */
    private static final String STATE_RESTING = "Resting";

    /** The channel state string used while playing. */
    private static final String STATE_PLAYING = "Playing";

    /** The channel state string used while paused. */
    private static final String STATE_PAUSED = "Paused";

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Immutable state object representing the current notification state.
     *
     * <p>This class encapsulates all the information needed to build the
     * notification, including playback state, metadata, and album art.
     * Immutability ensures thread-safe state transitions.</p>
     */
    private static class NotificationState {

        /** The current channel state ("Playing", "Paused", or "Resting"). */
        final String channelState;

        /** Whether music is currently playing. */
        final boolean isPlaying;

        /** The song title (empty string if none). */
        final String title;

        /** The artist name (empty string if none). */
        final String artist;

        /** The album art bitmap (null if none). */
        final Bitmap albumArt;

        /** The placeholder bitmap for when album art is missing (null if none). */
        final Bitmap placeholder;

        /** Cache key for the album art bitmap. */
        final String artKey;

        /**
         * The path of the song the album art belongs to. Empty when no
         * song is loaded. Used by the state updaters to correlate art with
         * the song currently being described.
         */
        final String songPath;

        /**
         * Constructs a new NotificationState.
         *
         * @param channelState The current channel state
         * @param isPlaying True if music is playing
         * @param title The song title
         * @param artist The artist name
         * @param albumArt The album art bitmap
         * @param placeholder The placeholder bitmap
         * @param artKey The cache key for album art
         * @param songPath The path of the song the album art belongs to
         */
        NotificationState(String channelState, boolean isPlaying,
                         String title, String artist,
                         Bitmap albumArt, Bitmap placeholder, String artKey,
                         String songPath) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.placeholder = placeholder;
            this.artKey = artKey;
            this.songPath = songPath;
        }

        /**
         * Returns true when no song is bound to the player.
         *
         * @return True if the state is {@link #STATE_RESTING}
         */
        boolean isResting() {
            return STATE_RESTING.equals(channelState);
        }
    }

    /**
     * Functional interface for updating the notification state.
     */
    private interface StateUpdater {

        /**
         * Updates the notification state.
         *
         * @param current The current state
         * @return The new state
         */
        NotificationState update(NotificationState current);
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** The service this notification service is attached to. */
    private final Service mService;

    /** Notification manager for displaying notifications. */
    private NotificationManager mNotificationManager;

    /** Main thread handler for UI operations. */
    private final Handler mMainHandler;

    /** Current notification state (atomic reference for thread safety). */
    private final AtomicReference<NotificationState> mCurrentState =
        new AtomicReference<NotificationState>(new NotificationState(STATE_RESTING, false,
                                                    "", "", null, null, null, ""));

    /** Flag indicating whether the service is in foreground mode. */
    private final AtomicBoolean mForegroundStarted = new AtomicBoolean(false);

    /** Flag indicating whether a notification update is scheduled. */
    private final AtomicBoolean mUpdateScheduled = new AtomicBoolean(false);

    /** LRU cache for album art bitmaps. */
    private final LruCache<String, Bitmap> mAlbumArtCache;

    /** Lock object for notification operations. */
    private final Object mNotificationLock = new Object();

    /**
     * Supplier for the active MediaSessionCompat token, populated by
     * {@link MusicService} after session setup. Used only for the
     * notification's {@code MediaStyle} binding, so external surfaces
     * (Wear OS, Android Auto, system media controls) render against the
     * active session.
     */
    @Nullable
    private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;

    /**
     * Transport PendingIntent for PLAY_PAUSE. Built once, in the constructor,
     * because {@link MediaButtonReceiver#buildMediaButtonPendingIntent}
     * performs a {@code PackageManager.queryIntentServices} IPC on every
     * call. The PendingIntent is immutable and safe to reuse across
     * notification rebuilds.
     */
    @Nullable
    private PendingIntent mPlayPauseIntent;

    /**
     * Transport PendingIntent for SKIP_TO_NEXT. See {@link #mPlayPauseIntent}
     * for the rationale on constructor-time construction.
     */
    @Nullable
    private PendingIntent mNextIntent;

    /**
     * Transport PendingIntent for SKIP_TO_PREVIOUS. See {@link #mPlayPauseIntent}
     * for the rationale on constructor-time construction.
     */
    @Nullable
    private PendingIntent mPrevIntent;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new NotificationService.
     *
     * <p>The constructor also builds the three transport PendingIntents and
     * stores them as instance fields. Construction is the only point at
     * which the class touches the package manager for media button
     * resolution; the fields are reused for every subsequent notification
     * rebuild.</p>
     *
     * @param service The service this notification service is attached to
     */
    public NotificationService(@NonNull Service service) {
        mService = service;
        mContext = service.getApplicationContext();
        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());

        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }

            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled()) {
                    NotificationState state = mCurrentState.get();
                    if (oldValue != state.albumArt && oldValue != state.placeholder) {
                        safeRecycleBitmap(oldValue);
                    }
                }
            }
        };

        createNotificationChannel();

        mPlayPauseIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mNextIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_NEXT);
        mPrevIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
    }

    // ========================================================================
    // Session Token Plumbing
    // ========================================================================

    /**
     * Sets the supplier used to obtain the active {@link MediaSessionCompat}
     * token. Called by {@link MusicService} after session setup so the
     * notification's MediaStyle can bind to the session without a hard
     * reference.
     *
     * @param provider The token supplier, or null to clear
     */
    public void setSessionTokenProvider(@Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }

    // ========================================================================
    // Public API Methods
    // ========================================================================

    /**
     * Stops the foreground notification and releases resources.
     * This method is called when the service is being destroyed.
     */
    public void stopForeground() {
        release();
    }

    /**
     * Releases all resources. After this method is called, the notification
     * service is not used.
     */
    public void release() {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return new NotificationState(
                    STATE_RESTING,
                    false,
                    "",
                    "",
                    null,
                    null,
                    null,
                    ""
                );
            }
        });
    }

    /**
     * Synchronously posts a notification and promotes the service to the
     * foreground. Called from {@code MusicService.onStartCommand} before
     * any state-machine work.
     *
     * <p>The notification is posted and {@code Service.startForeground} is
     * called on every invocation. {@link MediaButtonReceiver} starts the
     * service via {@code startForegroundService} on every notification
     * transport button tap, and each such call opens a window within which
     * {@code startForeground} must be called. {@code startForeground} is
     * idempotent, so the call is well-defined on every tap.</p>
     */
    public void startForegroundSync() {
        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager)
                        mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }

                NotificationState state = mCurrentState.get();
                if (state == null) {
                    state = new NotificationState(STATE_RESTING, false, "", "", null, null, null, "");
                }

                final Notification notification = buildNotification(state);
                mNotificationManager.notify(NOTIFICATION_ID, notification);
                mService.startForeground(NOTIFICATION_ID, notification);
                mForegroundStarted.set(true);
                Log.d(TAG, "Foreground promoted synchronously");
            } catch (Exception exception) {
                Log.e(TAG, "startForegroundSync failed", exception);
            }
        }
    }

    /**
     * Drops the foreground promotion while keeping the notification posted.
     * Called from {@code MusicService.doPause()} so the paused notification
     * is dismissible. SystemUI disables the Dismiss action on a
     * notification backed by a foreground service.
     *
     * <p>The notification is retained; only the foreground promotion is
     * dropped. A subsequent resume re-promotes the service through
     * {@link #startForegroundSync()}, which posts and promotes in one
     * call. No-op when the service is not currently foreground.</p>
     */
    public void demoteFromForeground() {
        synchronized (mNotificationLock) {
            if (!mForegroundStarted.getAndSet(false)) {
                return;
            }
            try {
                mService.stopForeground(false);
                Log.d(TAG, "Foreground demoted");
            } catch (Exception exception) {
                Log.e(TAG, "demoteFromForeground failed", exception);
            }
        }
    }

    /**
     * Forces a notification update regardless of state changes. Gated by
     * the same {@code mUpdateScheduled} flag used by
     * {@link #scheduleNotificationUpdate()}, so a burst of calls collapses
     * into a single rebuild rather than queuing one rebuild per call.
     */
    public void forceUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }
        if (mMainHandler != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    mUpdateScheduled.set(false);
                    performUpdateNotification();
                }
            });
        }
    }

    // ========================================================================
    // Core API Methods
    // ========================================================================

    /**
     * Updates the song information in the notification.
     *
     * <p>The {@code artPath} argument is the path of the song the metadata
     * belongs to. When it differs from the notification's current song
     * path, the album art bitmap is retained (so the previous song's art
     * stays visible until {@link #setAlbumArt} pushes the new song's art)
     * while the cache key and the old cache entry are both dropped. The
     * bitmap itself is recycled only when a new art push replaces it.</p>
     *
     * @param title The song title (can be null)
     * @param artist The artist name (can be null)
     * @param artPath The file path of the song (can be null)
     */
    public void updateSongInfo(@Nullable final String title, @Nullable final String artist, @Nullable final String artPath) {
        final String newTitle = (title != null && !title.isEmpty()) ? title : "";
        final String newArtist = (artist != null && !artist.isEmpty()) ? artist : "";
        final String newSongPath = (artPath != null) ? artPath : "";

        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                String newState;

                if (!newTitle.isEmpty()) {
                    newState = current.isPlaying ? STATE_PLAYING : STATE_PAUSED;
                } else {
                    newState = STATE_RESTING;
                }

                boolean songChanged = !newSongPath.equals(current.songPath);

                // Drop the previous song's entry from the notification's
                // cache. The bitmap itself is still referenced by
                // current.albumArt and is recycled only when a new art
                // push replaces it. Removing the entry here keeps the
                // cache's byte accounting accurate and prevents a later
                // eviction from meeting a bitmap that setAlbumArt has
                // already recycled.
                if (songChanged && !current.songPath.isEmpty()) {
                    mAlbumArtCache.remove(current.songPath);
                }

                String newArtKey = songChanged ? null : current.artKey;

                return new NotificationState(
                    newState,
                    current.isPlaying,
                    newTitle,
                    newArtist,
                    current.albumArt,
                    current.placeholder,
                    newArtKey,
                    newSongPath
                );
            }
        });
    }

    /**
     * Sets the album art for the notification.
     *
     * <p>The album art and placeholder bitmap fields are kept distinct.
     * The render path ({@link #getSafeLargeIcon}) falls back to the
     * placeholder when no album art is present, so the placeholder is
     * never duplicated into the album art field.</p>
     *
     * <p>Art is accepted only when the path it carries matches the
     * notification's current song path. A null art bitmap with a matching
     * path is a placeholder-only update: the committed art and its cache
     * key are left untouched. The placeholder is updated whenever a new
     * one arrives, since it belongs to no specific song.</p>
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap for when art is missing (can be null)
     * @param artPath The file path of the song the art belongs to (can be null)
     */
    public void setAlbumArt(@Nullable final Bitmap art, @Nullable final Bitmap placeholder, @Nullable final String artPath) {
        final Bitmap finalArt = art;
        final Bitmap finalPlaceholder = placeholder;
        final String finalArtPath = (artPath != null) ? artPath : "";

        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                Bitmap newPlaceholder = current.placeholder;
                if (finalPlaceholder != null && !finalPlaceholder.isRecycled()) {
                    if (newPlaceholder == null || newPlaceholder.isRecycled() ||
                        finalPlaceholder != newPlaceholder) {
                        safeRecycleBitmap(newPlaceholder);
                        newPlaceholder = createSafeCopy(finalPlaceholder, MAX_ART_SIZE);
                    }
                }

                boolean artMatchesCurrentSong = finalArtPath.isEmpty()
                    || finalArtPath.equals(current.songPath);

                Bitmap newAlbumArt = current.albumArt;
                String newArtKey = current.artKey;

                if (artMatchesCurrentSong && finalArt != null && !finalArt.isRecycled()) {
                    newAlbumArt = null;
                    newArtKey = null;

                    Bitmap cachedBitmap = mAlbumArtCache.get(finalArtPath);
                    if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
                        newAlbumArt = cachedBitmap;
                        newArtKey = finalArtPath;
                    } else {
                        Bitmap safeCopy = createSafeCopy(finalArt, MAX_ART_SIZE);
                        if (safeCopy != null) {
                            mAlbumArtCache.put(finalArtPath, safeCopy);
                            newAlbumArt = safeCopy;
                            newArtKey = finalArtPath;
                        }
                    }

                    if (current.albumArt != newAlbumArt && current.albumArt != current.placeholder) {
                        safeRecycleBitmap(current.albumArt);
                    }
                }

                return new NotificationState(
                    current.channelState,
                    current.isPlaying,
                    current.title,
                    current.artist,
                    newAlbumArt,
                    newPlaceholder,
                    newArtKey,
                    current.songPath
                );
            }
        });
    }

    /**
     * Sets the playing state in the notification.
     *
     * @param playing True if music is playing, false if paused
     */
    public void setPlayingState(final boolean playing) {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                String newState = current.channelState;

                if (current.title != null && !current.title.isEmpty()) {
                    newState = playing ? STATE_PLAYING : STATE_PAUSED;
                }

                return new NotificationState(
                    newState,
                    playing,
                    current.title,
                    current.artist,
                    current.albumArt,
                    current.placeholder,
                    current.artKey,
                    current.songPath
                );
            }
        });
    }

    // ========================================================================
    // State Management Methods
    // ========================================================================

    /**
     * Updates the notification state atomically.
     *
     * @param updater The state updater function
     */
    private void updateState(StateUpdater updater) {
        NotificationState oldState, newState;
        do {
            oldState = mCurrentState.get();
            newState = updater.update(oldState);
        } while (!mCurrentState.compareAndSet(oldState, newState));

        scheduleNotificationUpdate();
    }

    /**
     * Schedules a notification update on the main thread.
     * Uses a flag to prevent multiple pending updates.
     */
    private void scheduleNotificationUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }

        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mUpdateScheduled.set(false);
                performUpdateNotification();
            }
        });
    }

    /**
     * Performs the actual notification update.
     *
     * <p>Foreground promotion follows the rendered state. The service holds
     * the promotion while the state is {@link #STATE_PLAYING} and releases
     * it in every other state.</p>
     */
    private void performUpdateNotification() {
        NotificationState state = mCurrentState.get();

        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }

                boolean hasContent = state.title != null && !state.title.isEmpty();
                boolean isValidState = !STATE_RESTING.equals(state.channelState) && hasContent;

                if (isValidState) {
                    Notification notification = buildNotification(state);
                    mNotificationManager.notify(NOTIFICATION_ID, notification);

                    boolean shouldBeForeground = STATE_PLAYING.equals(state.channelState);
                    if (shouldBeForeground && !mForegroundStarted.getAndSet(true)) {
                        mService.startForeground(NOTIFICATION_ID, notification);
                        Log.d(TAG, "Foreground service started");
                    } else if (!shouldBeForeground) {
                        demoteFromForeground();
                    }
                } else {
                    // When the queue is empty, cancel the notification and
                    // drop the foreground promotion. The service itself
                    // stays alive so subsequent requests can repopulate the
                    // queue without a cold start.
                    mNotificationManager.cancel(NOTIFICATION_ID);
                    demoteFromForeground();
                }
            } catch (SecurityException exception) {
                Log.e(TAG, "Missing notification permission", exception);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to update notification", exception);
            }
        }
    }

    // ========================================================================
    // Notification Building Methods
    // ========================================================================

    /**
     * Builds the notification based on the current state.
     *
     * <p>Transport actions are dispatched through
     * {@link MediaButtonReceiver#buildMediaButtonPendingIntent}, routing each
     * tap through the active {@link MediaSessionCompat} instead of starting
     * the service. The close action and the swipe-away delete intent both
     * send {@code ACTION_STOP} to the service, which pauses playback
     * cleanly without an activity start.</p>
     *
     * <p>The three transport PendingIntents are read from instance fields
     * that were initialized in the constructor. The close and delete
     * PendingIntents are constructed per rebuild because they target the
     * service directly and do not go through the package-manager resolution
     * that would justify caching.</p>
     *
     * <p>{@code setOngoing(state.isPlaying)} protects the notification from
     * dismissal while playing. In the paused and resting states the ongoing
     * flag is cleared and the service is not foreground, so the Dismiss
     * action is enabled.</p>
     *
     * <p>The title and artist strings are rendered as received from the
     * service. When the state is Resting, the player UI's no-song
     * placeholders are drawn in their place so the two surfaces agree.
     * When a song is loaded, the strings it carries are drawn as-is; the
     * mapper that produced them has already substituted the "Unknown ..."
     * markers for missing metadata, so no second substitution is
     * performed here.</p>
     *
     * <p>The theme colour reaches the notification through {@code setColor}
     * and through the per-action themed icons produced by
     * {@link #createThemedIcon(int, int)}. On API 31 and above,
     * {@link Notification.Builder#setForegroundServiceBehavior(int)} is set
     * to {@link Notification#FOREGROUND_SERVICE_IMMEDIATE} so the status-bar
     * icon of the media playback foreground service is drawn as soon as
     * the promotion is committed.</p>
     *
     * @param state The current notification state
     * @return The built notification
     */
    @NonNull
    private Notification buildNotification(NotificationState state) {
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            themeColor = ThemeHelper.getDefaultColor();
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent contentIntent = PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);

        PendingIntent playPauseIntent = mPlayPauseIntent;
        PendingIntent nextIntent      = mNextIntent;
        PendingIntent prevIntent      = mPrevIntent;
        PendingIntent closeIntent     = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            flags);
        PendingIntent deleteIntent    = PendingIntent.getService(mContext, 5,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            flags);

        final boolean isResting = state.isResting();

        // The service supplies the song's title and artist as plain
        // strings. When the queue is empty, the state is Resting and the
        // player UI's no-song placeholders are used so the two surfaces
        // agree. When a song is loaded, the strings it carries are rendered
        // as received — the mapper that produced them has already
        // substituted the "Unknown ..." markers for missing metadata.
        String title = isResting ? PLACEHOLDER_TITLE : state.title;
        String artist = isResting ? PLACEHOLDER_ARTIST : state.artist;

        if (title.length() > MAX_TITLE_LENGTH) {
            title = title.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (artist.length() > MAX_ARTIST_LENGTH) {
            artist = artist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_ID);
        } else {
            @SuppressWarnings("deprecation")
            Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
            builder = deprecatedBuilder;
        }

        builder.setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(artist)
            .setColor(themeColor)
            .setContentIntent(contentIntent)
            .setDeleteIntent(deleteIntent)
            .setOngoing(state.isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }

        if (prevIntent != null) {
            addActionButton(builder, R.drawable.ic_notification_prev, "Prev", prevIntent, NEUTRAL_COLOR);
        }
        if (playPauseIntent != null) {
            int playPauseRes = state.isPlaying ? R.drawable.ic_notification_pause : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying ? "Pause" : "Play";
            addActionButton(builder, playPauseRes, playPauseLabel, playPauseIntent, themeColor);
        }
        if (nextIntent != null) {
            addActionButton(builder, R.drawable.ic_notification_next, "Next", nextIntent, NEUTRAL_COLOR);
        }
        addActionButton(builder, R.drawable.ic_notification_close, "Close", closeIntent, RED_COLOR);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.app.Notification.MediaStyle style = new android.app.Notification.MediaStyle();
            style.setShowActionsInCompactView(0, 1, 2);

            final MediaSessionCompat.Token compatToken =
                mSessionTokenProvider != null ? mSessionTokenProvider.get() : null;
            if (compatToken != null) {
                final Object rawToken = compatToken.getToken();
                if (rawToken instanceof android.media.session.MediaSession.Token) {
                    style.setMediaSession((android.media.session.MediaSession.Token) rawToken);
                }
            }

            builder.setStyle(style);
        }

        return builder.build();
    }

    /**
     * Adds an action button to the notification.
     *
     * @param builder The notification builder
     * @param iconRes The icon resource ID
     * @param label The button label
     * @param intent The pending intent for the button
     * @param color The icon color
     */
    private void addActionButton(Notification.Builder builder, int iconRes,
                                  String label, PendingIntent intent, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon icon = createThemedIcon(iconRes, color);
            if (icon != null) {
                Notification.Action action = new Notification.Action.Builder(icon, label, intent).build();
                builder.addAction(action);
                return;
            }
        }

        @SuppressWarnings("deprecation")
        Notification.Action action = new Notification.Action.Builder(iconRes, label, intent).build();
        builder.addAction(action);
    }

    /**
     * Gets a safe large icon for the notification.
     *
     * @param state The current notification state
     * @return The large icon bitmap, or null if none available
     */
    @Nullable
    private Bitmap getSafeLargeIcon(NotificationState state) {
        if (state.artKey != null) {
            Bitmap cachedBitmap = mAlbumArtCache.get(state.artKey);
            if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
                return cachedBitmap;
            }
        }

        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }

        if (state.placeholder != null && !state.placeholder.isRecycled()) {
            return state.placeholder;
        }

        return null;
    }

    /**
     * Creates a safe copy of a bitmap scaled to the specified maximum size.
     *
     * @param source The source bitmap
     * @param maxSize The maximum dimension in pixels
     * @return The scaled bitmap copy, or null if copy fails
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }

        try {
            int width = source.getWidth();
            int height = source.getHeight();

            if (width <= 0 || height <= 0) {
                return null;
            }

            Bitmap scaledBitmap;
            if (width <= maxSize && height <= maxSize) {
                scaledBitmap = source.copy(source.getConfig() != null ? source.getConfig() : Bitmap.Config.ARGB_8888, false);
            } else {
                float scale = Math.min((float) maxSize / width, (float) maxSize / height);
                scaledBitmap = Bitmap.createScaledBitmap(source, Math.round(width * scale), Math.round(height * scale), true);
            }

            return scaledBitmap;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to create safe bitmap copy", exception);
            return null;
        }
    }

    /**
     * Safely recycles a bitmap.
     *
     * @param bitmap The bitmap to recycle (can be null)
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * Creates a themed icon with the specified color.
     *
     * @param drawableRes The drawable resource ID
     * @param color The icon color
     * @return The themed icon, or null if creation fails
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);

            if (drawable == null) {
                Log.w(TAG, "Failed to load drawable: " + drawableRes);
                return null;
            }

            drawable.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            } else {
                return null;
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to create themed icon", exception);
            return null;
        }
    }

    // ========================================================================
    // Notification Channel Methods
    // ========================================================================

    /**
     * Creates the notification channel for Android O and above.
     *
     * <p>The channel is created at {@link NotificationManager#IMPORTANCE_DEFAULT}
     * so the small icon is permitted to appear wherever the platform
     * chooses to render the notification. Sound and vibration are disabled
     * on the channel; the importance setting affects only where the icon
     * is permitted to appear.</p>
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }

                NotificationChannel existingChannel = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (existingChannel == null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        CHANNEL_NAME,
                        NotificationManager.IMPORTANCE_DEFAULT
                    );
                    channel.setDescription(CHANNEL_DESCRIPTION);
                    channel.setShowBadge(false);
                    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    channel.setSound(null, null);
                    channel.enableVibration(false);
                    mNotificationManager.createNotificationChannel(channel);
                    Log.d(TAG, "Created notification channel: " + CHANNEL_NAME);
                }
            } catch (Exception exception) {
                Log.e(TAG, "Failed to create notification channel", exception);
            }
        }
    }
}