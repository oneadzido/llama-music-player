package com.ark.llama;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashSet;
import java.util.Set;

/**
 * The dim-and-spinner loading overlay, owned by the activity that shows
 * it.
 *
 * <p>The overlay is a dim {@link FrameLayout} covering the activity's
 * content view, with a rotating ring spinner centred in it. It exists to
 * answer one question for the user: <em>is the app working?</em> It is
 * not a progress bar and it does not report progress; it reports
 * activity. That distinction is why the spinner is a rotating ring with
 * a travelling bright arc rather than an animated fill — the arc's
 * position is legible on every frame, so the eye reads motion even when
 * the underlying work takes an unknown amount of time.</p>
 *
 * <h3>Ownership</h3>
 * <p>The overlay is owned by the activity that constructs it. One
 * instance per activity. The overlay does not know what work is in
 * flight; it knows only how many callers currently want it visible.</p>
 *
 * <p>Visibility is by <b>reason token</b>. Each caller that wants the
 * overlay visible holds a token; the overlay is visible while at least
 * one token is held. This makes independent callers — the cold-start
 * library load and the post-scan playlist rebuild are the two in this
 * app — able to show and hide the overlay without interfering with each
 * other. A caller that finishes its own work removes its own token; the
 * overlay stays visible only if another caller's token is still held.</p>
 *
 * <h3>LifecanvasYcle</h3>
 * <p>The overlay is built lazily. The constructor records the activity
 * and the initial theme color and does nothing else. The dim container
 * and the spinner are built on the first {@link #show(String)} call and
 * torn down when the last token is removed. An activity that never
 * triggers a load never pays for an overlay it does not use.</p>
 *
 * <p>The spinner's rotation animator is bound to the spinner view's
 * attach state. {@link View#onAttachedToWindow()} starts the rotation
 * and {@link View#onDetachedFromWindow()} cancels it, so the animation
 * runs exactly while the view is on screen and is never left running
 * after the overlay is detached. This is the same discipline the
 * codebase applies to every other animator: no animator outlives the
 * view that owns it.</p>
 *
 * <h3>Ordering</h3>
 * <p>The token set is the sole source of truth for visibility. A
 * {@link #show(String)} call that is not the first is a no-op with
 * respect to the view hierarchy: the overlay is already attached, and
 * the new token is added to the set. A {@link #hide(String)} call whose
 * token is not held is a no-op with respect to both the set and the view
 * hierarchy. This makes show/hide pairs safe to call in any order and
 * safe to call more than once, which is what every caller needs from a
 * pair of lifecanvasYcle methods it does not fully control the timing of.</p>
 *
 * <h3>Theme</h3>
 * <p>The theme color is supplied by the caller through
 * {@link #setColor(int)} and remembered across detach and reattach. The
 * spinner uses the color twice: at full alpha for the bright arc, and at
 * {@link #TRACK_ALPHA} for the dim track. Both are derived from the same
 * value, so the spinner reads as a single object in the current theme
 * rather than as a themed element sitting on an unthemed ring.</p>
 *
 * <h3>Touch</h3>
 * <p>The dim container consumes touches. This is deliberate: while the
 * overlay is showing, the UI behind it is not in a state to be acted on,
 * and any touch that reaches the controls underneath — an album-art
 * swipe, a transport tap — is acting on stale state. Making the
 * container clickable is what prevents that.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every method runs on the main thread. The token set is a plain
 * {@link HashSet} and is not synchronized; callers that would call
 * {@code show} or {@code hide} from a background thread must marshal to
 * the main thread first, as every caller in this app does.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — The overlay is attached if and only if {@link #mReasons}
 *       is non-empty. No other field participates in that decision.</li>
 *   <li>I2 — {@link #attach()} and {@link #detach()} are idempotent.
 *       Neither inspects the token set; the caller decides whether the
 *       set's size has crossed the zero boundary.</li>
 *   <li>I3 — The spinner's animator is running if and only if the
 *       spinner view is attached to a window. No code path starts or
 *       stops the animator directly.</li>
 *   <li>I4 — Every view the overlay adds to the activity's content view
 *       is removed by {@link #detach()}. An activity that shows and
 *       hides the overlay repeatedly does not accumulate orphan
 *       views.</li>
 *   <li>I5 — The overlay never outlives the activity. The activity owns
 *       the instance; when the activity is destroyed, the instance is
 *       garbage-collected with it, and the container is removed from
 *       the destroyed activity's view hierarchy by the framework.</li>
 * </ul>
 *
 * @see MetadataEditor
 * @see MusicPlayer
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class LoadingOverlay {

    // ============================================================================
    // Constants
    // ============================================================================

    /**
     * Alpha of the dim background, 0-255.
     *
     * <p>High enough to obscure the UI behind the overlay — the point is
     * that the user's attention is not drawn to controls that cannot be
     * acted on — and low enough that the outline of the activity remains
     * visible, so the user knows the app has not been replaced by a
     * blank screen.</p>
     */
    private static final int DIM_ALPHA = 180;

    /**
     * Base color of the dim background, as 0xRRGGBB.
     *
     * <p>Matches the app's primary background so the overlay reads as a
     * deepening of the existing surface rather than as an opaque new
     * screen.</p>
     */
    private static final int DIM_RGB = 0x121212;

    /**
     * Spinner diameter in density-independent pixels.
     *
     * <p>Small by design. A large spinner reads as a static shape; a
     * small one reads as a moving arc, which is the point of the
     * spinner. This size matches the compact size the design reference
     * uses for windows with tight vertical space, which includes
     * split-screen windows on phones.</p>
     */
    private static final int SPINNER_DIAMETER_DP = 26;

    /**
     * Spinner stroke width in density-independent pixels.
     *
     * <p>Thicker relative to the diameter than a large spinner would
     * use. The reference uses a heavier stroke on its smallest spinners
     * because the arc has less room to make an impression; the same
     * reasoning applies here.</p>
     */
    private static final int SPINNER_STROKE_DP = 2;

    /**
     * Sweep of the bright arc, in degrees.
     *
     * <p>One quarter of the ring. Chosen to match the design reference,
     * which colors exactly one side of the CSS border. A quarter is
     * enough for the arc to read as a distinct object, and small enough
     * that the arc's angular position is unambiguous on every frame.</p>
     */
    private static final int BRIGHT_ARC_SWEEP_DEGREES = 90;

    /**
     * Rotation period in milliseconds.
     *
     * <p>One full rotation per second, driven by a linear interpolator.
     * Linear is deliberate: any easing makes the arc appear to
     * accelerate and decelerate within a single rotation, which reads as
     * a stutter. Constant angular velocity is what makes the arc read as
     * a continuously moving object.</p>
     */
    private static final long ROTATION_PERIOD_MS = 1000L;

    /**
     * Alpha applied to the dim track, 0-255.
     *
     * <p>The track is the same theme color as the bright arc, at roughly
     * twenty-five percent opacity. Deriving it from the arc color rather
     * than specifying it separately means the spinner always reads as a
     * single object in the current theme: the track is the theme's
     * fingerprint and the arc is the theme in motion.</p>
     */
    private static final int TRACK_ALPHA = 0x4D;

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Activity whose content view hosts the overlay. */
    @NonNull
    private final Activity mActivity;

    /**
     * Reasons currently holding the overlay visible.
     *
     * <p>The sole source of truth for visibility. Each element is a
     * caller-supplied token; the overlay is visible while this set is
     * non-empty. See the class documentation for the ownership
     * contract.</p>
     */
    @NonNull
    private final Set<String> mReasons = new HashSet<>();

    /** Attached container, or null when the overlay is not showing. */
    @Nullable
    private FrameLayout mContainer;

    /** Attached spinner, or null when the overlay is not showing. */
    @Nullable
    private SpinnerView mSpinner;

    /**
     * Theme color to apply to the spinner.
     *
     * <p>Remembered across detach and reattach, so a caller can set the
     * color at any time — including while the overlay is hidden — and
     * the next attach uses the current value.</p>
     */
    private int mColor;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs an overlay for the given activity.
     *
     * <p>Does not attach any view. The view hierarchy is built lazily
     * on the first {@link #show(String)} call, so an activity that never
     * triggers a load never pays for an overlay it does not use.</p>
     *
     * @param activity Activity whose content view will host the overlay
     * @param initialColor Initial theme color for the spinner
     */
    public LoadingOverlay(@NonNull Activity activity, int initialColor) {
        mActivity = activity;
        mColor = initialColor;
    }

    // ============================================================================
    // Public API
    // ============================================================================

    /**
     * Adds a reason to the visible set and attaches the overlay when the
     * set becomes non-empty.
     *
     * <p>A call while the overlay is already attached adds the reason
     * but performs no view work. A call with a reason that is already
     * held is a no-op: the set does not grow, and the overlay's
     * visibility is unchanged.</p>
     *
     * <p>Every call must be paired with a matching
     * {@link #hide(String)} on every exit path from the operation that
     * holds the reason. A reason that is never removed keeps the overlay
     * visible for the lifetime of the activity.</p>
     *
     * @param reason Caller-supplied token, unique to the operation that
     *               wants the overlay visible
     */
    public void show(@NonNull String reason) {
        mReasons.add(reason);
        if (mReasons.size() != 1) {
            return;
        }
        attach();
    }

    /**
     * Removes a reason from the visible set and detaches the overlay
     * when the set becomes empty.
     *
     * <p>A call whose reason is not held is a no-op: the set does not
     * change, and the overlay's visibility is unchanged. This is
     * deliberate. Callers use paired show/hide calls on operations whose
     * completion order is not fully predictable, and a hide whose show
     * never ran — or that already ran and finished — must not tear down
     * another caller's overlay.</p>
     *
     * @param reason Token passed to a previous {@link #show(String)}
     *               call
     */
    public void hide(@NonNull String reason) {
        mReasons.remove(reason);
        if (!mReasons.isEmpty()) {
            return;
        }
        detach();
    }

    /**
     * Returns whether the overlay is currently showing.
     *
     * @return True when at least one reason is held
     */
    public boolean isShowing() {
        return !mReasons.isEmpty();
    }

    /**
     * Applies a theme color to the spinner.
     *
     * <p>The color is remembered and reapplied on the next attach, so a
     * caller can set the color at any time and does not need to check
     * whether the overlay is currently showing.</p>
     *
     * <p>The spinner derives both its bright arc and its dim track from
     * this color. A theme change while the overlay is showing updates
     * both at once.</p>
     *
     * @param color Theme color as an ARGB integer
     */
    public void setColor(int color) {
        mColor = color;
        if (mSpinner != null) {
            mSpinner.setColor(color);
        }
    }

    // ============================================================================
    // Attachment
    // ============================================================================

    /**
     * Builds and attaches the container and spinner to the activity's
     * content view.
     *
     * <p>Idempotent while attached. Refused silently when the activity
     * has no content view, which happens if the call lands after the
     * activity has begun tearing down. In that case the overlay's state
     * remains consistent — the reason is held, and the next
     * {@code show} after a fresh attach will build the view.</p>
     */
    private void attach() {
        if (mContainer != null) {
            return;
        }

        ViewGroup root = mActivity.findViewById(android.R.id.content);
        if (root == null) {
            return;
        }

        FrameLayout container = new FrameLayout(mActivity);
        container.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        container.setBackgroundColor(Color.argb(DIM_ALPHA,
            Color.red(DIM_RGB), Color.green(DIM_RGB), Color.blue(DIM_RGB)));
        container.setClickable(true);
        container.setFocusable(true);

        SpinnerView spinner = new SpinnerView(mActivity);
        spinner.setColor(mColor);
        int size = dpToPx(SPINNER_DIAMETER_DP);
        FrameLayout.LayoutParams spinnerParams = new FrameLayout.LayoutParams(
            size, size);
        spinnerParams.gravity = Gravity.CENTER;
        spinner.setLayoutParams(spinnerParams);

        container.addView(spinner);
        root.addView(container);

        mContainer = container;
        mSpinner = spinner;
    }

    /**
     * Detaches the container from its parent and clears the view
     * fields.
     *
     * <p>The spinner's animator stops itself when its view is detached;
     * this method does not need to stop it. See invariant I3.</p>
     */
    private void detach() {
        if (mContainer != null && mContainer.getParent() != null) {
            ((ViewGroup) mContainer.getParent()).removeView(mContainer);
        }
        mContainer = null;
        mSpinner = null;
    }

    // ============================================================================
    // Spinner View
    // ============================================================================

    /**
     * A ring spinner with one bright arc travelling around a dim track.
     *
     * <p>A full circle stroked in a low-alpha theme color, with one
     * quarter of the ring stroked at full theme alpha, rotated
     * continuously. The rotation is what makes the arc's position
     * change over time; the two alphas are what make the arc legible
     * as a distinct object rather than as part of the ring.</p>
     *
     * <p>The rotation animator is started in
     * {@link #onAttachedToWindow()} and cancelled in
     * {@link #onDetachedFromWindow()}. The animator's lifecanvasYcle is the
     * view's attach lifecanvasYcle, with no coordination from the overlay.
     * This is what keeps the spinner animating for exactly the interval
     * the overlay is attached, without the overlay having to know about
     * the animator at all.</p>
     */
    private static final class SpinnerView extends View {

        /** Paint for the dim track. */
        @NonNull
        private final Paint mTrackPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

        /** Paint for the bright arc. */
        @NonNull
        private final Paint mArcPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

        /**
         * Reusable bounds rect for {@link Canvas#drawArc}.
         *
         * <p>Allocated once and mutated on every draw, so the onDraw
         * path does not allocate.</p>
         */
        @NonNull
        private final RectF mArcBounds = new RectF();

        /** Animator rotating the view, or null when not attached. */
        @Nullable
        private ObjectAnimator mRotation;

        /**
         * Constructs the spinner.
         *
         * @param context Context used for resource and density lookup
         */
        SpinnerView(@NonNull Context context) {
            super(context);

            mTrackPaint.setStyle(Paint.Style.STROKE);
            mTrackPaint.setStrokeCap(Paint.Cap.ROUND);
            mArcPaint.setStyle(Paint.Style.STROKE);
            mArcPaint.setStrokeCap(Paint.Cap.ROUND);

            setClickable(false);
            setFocusable(false);
        }

        /**
         * Sets the theme color.
         *
         * <p>The bright arc uses the color at full alpha; the track uses
         * the same color at {@link #TRACK_ALPHA}. Both are set in one
         * call, so the two are never out of step.</p>
         *
         * @param color Theme color as an ARGB integer
         */
        void setColor(int color) {
            mArcPaint.setColor(color);
            mTrackPaint.setColor(
                (color & 0x00FFFFFF) | (TRACK_ALPHA << 24));
            invalidate();
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            startRotation();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            stopRotation();
        }

        /**
         * Starts the rotation animator when none is running.
         *
         * <p>Guarded against a second start so a detach followed by an
         * attach does not leave two animators running on the same
         * property.</p>
         */
        private void startRotation() {
            if (mRotation != null && mRotation.isRunning()) {
                return;
            }
            mRotation = ObjectAnimator.ofFloat(
                this, "rotation", 0f, 360f);
            mRotation.setDuration(ROTATION_PERIOD_MS);
            mRotation.setRepeatCount(ObjectAnimator.INFINITE);
            mRotation.setInterpolator(new LinearInterpolator());
            mRotation.start();
        }

        /**
         * Cancels the rotation animator and clears the field.
         *
         * <p>Idempotent. Called from
         * {@link #onDetachedFromWindow()} on every detach, including the
         * one the framework performs as part of the activity's
         * teardown.</p>
         */
        private void stopRotation() {
            if (mRotation != null) {
                mRotation.cancel();
                mRotation = null;
            }
        }

        @Override
        protected void onDraw(@NonNull Canvas canvas) {
            float canvasX = getWidth() / 2f;
            float canvasY = getHeight() / 2f;
            float stroke = getResources().getDisplayMetrics().density
                * SPINNER_STROKE_DP;
            float radius = Math.min(canvasX, canvasY) - stroke / 2f;

            mTrackPaint.setStrokeWidth(stroke);
            mArcPaint.setStrokeWidth(stroke);

            canvas.drawCircle(canvasX, canvasY, radius, mTrackPaint);

            mArcBounds.set(
                canvasX - radius, canvasY - radius, canvasX + radius, canvasY + radius);
            // -90f puts the arc's start at twelve o'clock. Sweep is
            // +90f clockwise.
            canvas.drawArc(mArcBounds, -90f,
                BRIGHT_ARC_SWEEP_DEGREES, false, mArcPaint);
        }
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Converts density-independent pixels to pixels using the activity's
     * current display metrics.
     *
     * <p>Reads the metrics at call time rather than caching them, so a
     * density change between attaches produces the correct size on the
     * next attach.</p>
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp
            * mActivity.getResources().getDisplayMetrics().density);
    }
}