package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Virtualizer;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Manager for controlling audio effects including equalizer, bass boost, surround,
 * pitch, and speed.
 * 
 * <p>This class provides a comprehensive API for managing audio effects on the
 * Android platform. It encapsulates the complexity of the Android audio effect
 * framework and works seamlessly with both LlamaPlayer and NativeMediaPlayer.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> for band level array access</li>
 *   <li><b>AtomicBoolean</b> for state flags</li>
 *   <li><b>AtomicReference</b> for audio effect objects</li>
 *   <li><b>Volatile</b> for simple flags where atomic operations aren't needed</li>
 *   <li><b>Synchronized</b> for singleton and listener management</li>
 * </ul>
 * 
 * @see Equalizer
 * @see BassBoost
 * @see Virtualizer
 * @see LlamaPlayer
 * @see NativeMediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class EqualizerManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "EqualizerManager";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for equalizer enabled state. */
    private static final String KEY_EQUALIZER_ENABLED = "equalizer_enabled";
    
    /** Key for bass boost level. */
    private static final String KEY_BASS_BOOST = "bass_boost_level";
    
    /** Key for surround effect level. */
    private static final String KEY_SURROUND = "surround_level";
    
    /** Key for pitch level. */
    private static final String KEY_PITCH = "pitch_level";
    
    /** Key for speed level. */
    private static final String KEY_SPEED = "speed_level";
    
    /** Key for selected preset. */
    private static final String KEY_SELECTED_PRESET = "selected_preset";
    
    /** Prefix for equalizer band level keys. */
    private static final String KEY_BAND_PREFIX = "eq_band_";
    
    /** Prefix for custom equalizer band level keys. */
    private static final String KEY_CUSTOM_BAND_PREFIX = "eq_custom_band_";
    
    /** Key indicating whether custom bands exist. */
    private static final String KEY_HAS_CUSTOM_BAND = "has_custom_band";
    
    /** Key for custom bass boost value. */
    private static final String KEY_CUSTOM_BASS_BOOST = "eq_custom_bass_boost";
    
    /** Key for custom surround value. */
    private static final String KEY_CUSTOM_SURROUND = "eq_custom_surround";
    
    /** Key for custom pitch value. */
    private static final String KEY_CUSTOM_PITCH = "eq_custom_pitch";
    
    /** Key for custom speed value. */
    private static final String KEY_CUSTOM_SPEED = "eq_custom_speed";
    
    /** Key indicating whether custom boosters exist. */
    private static final String KEY_HAS_CUSTOM_BOOSTERS = "has_custom_boosters";
    
    /** Key indicating whether custom pitch exists. */
    private static final String KEY_HAS_CUSTOM_PITCH = "has_custom_pitch";
    
    /** Key indicating whether custom speed exists. */
    private static final String KEY_HAS_CUSTOM_SPEED = "has_custom_speed";
    
    /** Default value for pitch and speed (neutral). */
    private static final int DEFAULT_PITCH_SPEED = 1000;
    
    /** Maximum value for bass boost and surround. */
    private static final int MAX_BOOST_STRENGTH = 1000;
    
    /** Minimum valid audio session ID. */
    private static final int MIN_VALID_SESSION_ID = 1;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Singleton instance. */
    private static volatile EqualizerManager sInstance;
    
    // ========================================================================
    // Audio Effect Objects (Thread-Safe with AtomicReference)
    // ========================================================================
    
    /** Equalizer effect instance. */
    @Nullable
    private final AtomicReference<Equalizer> mEqualizer = new AtomicReference<>();
    
    /** Bass boost effect instance. */
    @Nullable
    private final AtomicReference<BassBoost> mBassBoost = new AtomicReference<>();
    
    /** Surround/virtualizer effect instance. */
    @Nullable
    private final AtomicReference<Virtualizer> mSurround = new AtomicReference<>();
    
    /** Current audio session ID. */
    private final AtomicInteger mCurrentAudioSessionId = new AtomicInteger(-1);
    
    /** Whether the equalizer is enabled. */
    private final AtomicBoolean mIsEnabled = new AtomicBoolean(false);
    
    /** Currently selected preset index. */
    private final AtomicInteger mCurrentPreset = new AtomicInteger(0);
    
    // ========================================================================
    // Pitch and Speed Values
    // ========================================================================
    
    /** Current pitch level (0-2000, 1000 = normal). */
    private final AtomicInteger mPitchLevel = new AtomicInteger(DEFAULT_PITCH_SPEED);
    
    /** Current speed level (0-2000, 1000 = normal). */
    private final AtomicInteger mSpeedLevel = new AtomicInteger(DEFAULT_PITCH_SPEED);
    
    // ========================================================================
    // Equalizer Band Data (Thread-Safe with ReadWriteLock)
    // ========================================================================
    
    /** Number of equalizer bands. */
    private volatile short mNumberOfBands = 0;
    
    /** Minimum and maximum band level range. */
    @Nullable
    private volatile short[] mBandLevelRange;
    
    /** Current band levels (protected by mBandLevelLock). */
    @Nullable
    private int[] mCurrentBandLevels;
    
    /** Center frequencies for each band (immutable after attach). */
    @Nullable
    private volatile int[] mCenterFrequencies;
    
    /** Custom band levels (saved when switching from custom preset). */
    @Nullable
    private volatile int[] mCustomBandLevels;
    
    /** Custom bass boost value. */
    private final AtomicInteger mCustomBassBoost = new AtomicInteger(0);
    
    /** Custom surround value. */
    private final AtomicInteger mCustomSurround = new AtomicInteger(0);
    
    /** Custom pitch value. */
    private final AtomicInteger mCustomPitch = new AtomicInteger(DEFAULT_PITCH_SPEED);
    
    /** Custom speed value. */
    private final AtomicInteger mCustomSpeed = new AtomicInteger(DEFAULT_PITCH_SPEED);
    
    /** Read/write lock for band level array access. */
    private final ReentrantReadWriteLock mBandLevelLock = new ReentrantReadWriteLock();
    
    // ========================================================================
    // Context and Listener
    // ========================================================================
    
    /** Application context. */
    @NonNull
    private final Context mContext;
    
    /** Equalizer event listener. */
    @Nullable
    private volatile EqualizerListener mListener;
    
    // ========================================================================
    // Preset Data (Immutable, Thread-Safe)
    // ========================================================================
    
    /**
     * Array of preset names available in the equalizer.
     * Total of 60 presets covering various music genres and effects.
     */
    private static final String[] PRESET_NAMES = {
        "Custom", "Acoustic", "Afrobeat", "Afropop", "Alternative", "Ambient",
        "Bass & Treble", "Bass Boost", "Bass Reducer", "Blues", "Car", "Chill",
        "Classical", "Club", "Country", "Dance", "Deep", "Disco", "Drum & Bass",
        "Dubstep", "Electronic", "Folk", "Gospel", "Grunge", "Hard Rock", "Headphones",
        "Hip Hop", "House", "Indie", "Jazz", "Live", "Loudness", "Lounge", "Metal",
        "Midnight", "Opera", "Orchestral", "Outdoor", "Party", "Podcast", "Pop",
        "Psychedelic", "Reference", "Reggae", "Rock", "Ska", "Small Speakers",
        "Soft Rock", "Soul", "Studio", "Symphony", "Techno", "Trance", "Treble Boost",
        "Treble Reducer", "Vocal Boost", "Voice", "Warm", "World", "Zero"
    };
    
    /**
     * Gain values for each preset (in millibels, where 100 = 1 dB).
     * Each inner array contains 10 band gain values.
     */
    private static final int[][] PRESET_GAINS = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                                         // Custom (0)
        {300, 250, 200, 150, 100, 50, 0, -50, -100, -150},                     // Acoustic (1)
        {450, 500, 500, 400, 300, 150, 100, 150, 250, 350},                    // Afrobeat (2)
        {500, 550, 500, 450, 350, 250, 200, 250, 350, 400},                    // Afropop (3)
        {300, 350, 400, 350, 300, 250, 200, 150, 200, 300},                    // Alternative (4)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},                    // Ambient (5)
        {600, 500, 300, 100, 0, 0, 0, 100, 300, 600},                          // Bass & Treble (6)
        {700, 650, 500, 300, 150, 0, -100, -150, -200, -250},                  // Bass Boost (7)
        {-250, -200, -150, -100, -50, 50, 150, 250, 350, 450},                 // Bass Reducer (8)
        {300, 350, 350, 250, 200, 150, 100, 50, 100, 150},                     // Blues (9)
        {500, 450, 350, 250, 150, 100, 100, 150, 200, 250},                    // Car (10)
        {200, 250, 300, 350, 300, 250, 200, 150, 100, 50},                     // Chill (11)
        {400, 350, 300, 250, 200, 150, 100, 50, 0, -50},                       // Classical (12)
        {600, 650, 650, 450, 250, 0, -50, -50, 100, 200},                      // Club (13)
        {250, 300, 350, 400, 350, 300, 200, 150, 100, 50},                     // Country (14)
        {500, 550, 550, 400, 200, 0, 100, 250, 400, 500},                      // Dance (15)
        {800, 850, 700, 400, 150, -50, -150, -200, -300, -350},                // Deep (16)
        {500, 550, 600, 500, 350, 200, 150, 100, 50, 0},                       // Disco (17)
        {650, 650, 500, 250, 100, -50, -100, -50, 150, 200},                   // Drum & Bass (18)
        {700, 750, 550, 200, -100, -250, -150, 50, 200, 300},                  // Dubstep (19)
        {650, 700, 650, 450, 200, 0, 50, 150, 350, 450},                       // Electronic (20)
        {150, 200, 300, 400, 450, 400, 300, 200, 150, 100},                    // Folk (21)
        {200, 250, 350, 450, 550, 500, 400, 300, 200, 150},                    // Gospel (22)
        {450, 500, 400, 200, -75, -100, 0, 150, 300, 400},                     // Grunge (23)
        {400, 450, 500, 450, 300, 200, 200, 250, 350, 400},                    // Hard Rock (24)
        {200, 150, 100, 0, -100, -100, -50, 0, 150, 250},                      // Headphones (25)
        {600, 650, 550, 300, 100, -50, -100, 0, 150, 250},                     // Hip Hop (26)
        {600, 650, 600, 450, 250, 50, 0, 50, 150, 300},                        // House (27)
        {200, 250, 300, 400, 400, 350, 300, 250, 200, 150},                    // Indie (28)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},                    // Jazz (29)
        {100, 150, 250, 400, 500, 450, 350, 250, 150, 100},                    // Live (30)
        {500, 450, 300, 100, -100, -150, -100, 100, 350, 450},                 // Loudness (31)
        {150, 200, 250, 300, 350, 300, 250, 200, 150, 100},                    // Lounge (32)
        {400, 450, 300, 100, -150, -200, -100, 150, 400, 500},                 // Metal (33)
        {200, 250, 300, 250, 150, 50, -50, -100, -150, -200},                  // Midnight (34)
        {250, 300, 350, 350, 300, 250, 200, 150, 100, 50},                     // Opera (35)
        {300, 350, 400, 400, 350, 300, 250, 200, 150, 100},                    // Orchestral (36)
        {300, 350, 400, 350, 300, 300, 350, 400, 450, 500},                    // Outdoor (37)
        {550, 600, 550, 350, 100, -100, -50, 150, 400, 550},                   // Party (38)
        {-200, -100, 100, 400, 600, 700, 600, 400, 200, 0},                    // Podcast (39)
        {250, 300, 350, 400, 450, 450, 400, 350, 300, 250},                    // Pop (40)
        {300, 350, 400, 350, 300, 200, 150, 200, 300, 400},                    // Psychedelic (41)
        {50, 75, 100, 125, 150, 175, 200, 225, 250, 275},                      // Reference (42)
        {450, 500, 450, 350, 250, 150, 100, 50, 0, -50},                       // Reggae (43)
        {350, 400, 450, 500, 450, 350, 250, 200, 250, 300},                    // Rock (44)
        {350, 400, 450, 400, 350, 300, 250, 200, 150, 150},                    // Ska (45)
        {400, 350, 300, 200, 100, 100, 150, 200, 300, 400},                    // Small Speakers (46)
        {200, 250, 300, 400, 350, 250, 150, 100, 50, 25},                      // Soft Rock (47)
        {400, 450, 400, 300, 200, 150, 100, 50, 100, 150},                     // Soul (48)
        {50, 100, 150, 200, 250, 300, 350, 400, 450, 500},                     // Studio (49)
        {400, 450, 500, 450, 400, 350, 300, 250, 200, 150},                    // Symphony (50)
        {650, 600, 500, 350, 150, -50, -100, 0, 200, 400},                     // Techno (51)
        {550, 600, 550, 400, 200, 50, 100, 250, 400, 500},                     // Trance (52)
        {-300, -250, -200, -150, 0, 150, 300, 500, 700, 800},                  // Treble Boost (53)
        {50, 100, 150, 200, 150, 100, 50, 0, -100, -200},                      // Treble Reducer (54)
        {-200, -150, 200, 400, 500, 600, 500, 400, 200, -100},                 // Vocal Boost (55)
        {-400, -300, 0, 400, 600, 700, 600, 400, 0, -300},                     // Voice (56)
        {400, 350, 250, 150, 100, 50, 25, 0, -25, -50},                        // Warm (57)
        {200, 300, 350, 400, 400, 350, 300, 200, 150, 100},                    // World (58)
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}                                         // Zero (59)
    };
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for equalizer events.
     * All callbacks are delivered on the main UI thread.
     */
    public interface EqualizerListener {
        
        /**
         * Called when band levels change.
         *
         * @param levels Array of current band levels in millibels
         */
        void onBandLevelsChanged(@NonNull int[] levels);
        
        /**
         * Called when the preset changes.
         *
         * @param preset The new preset index
         * @param presetName The name of the new preset
         */
        void onPresetChanged(int preset, @NonNull String presetName);
        
        /**
         * Called when the equalizer becomes ready or is detached.
         *
         * @param ready True if the equalizer is ready, false otherwise
         */
        void onEqualizerReady(boolean ready);
    }
    
    // ========================================================================
    // Constructor and Singleton
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private EqualizerManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadSettings();
        Log.d(TAG, "EqualizerManager created");
    }
    
    /**
     * Returns the singleton instance of EqualizerManager.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized EqualizerManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new EqualizerManager(context);
        }
        return sInstance;
    }
    
    // ========================================================================
    // Listener Management (Thread-Safe via synchronized)
    // ========================================================================
    
    /**
     * Sets the equalizer event listener.
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public synchronized void setListener(@Nullable EqualizerListener listener) {
        mListener = listener;
        Log.d(TAG, "Equalizer listener " + (listener != null ? "set" : "cleared"));
    }
    
    // ========================================================================
    // Settings Loading/Saving (Thread-Safe via SharedPreferences)
    // ========================================================================
    
    /**
     * Loads saved settings from SharedPreferences.
     */
    private void loadSettings() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mIsEnabled.set(prefs.getBoolean(KEY_EQUALIZER_ENABLED, false));
        mCurrentPreset.set(prefs.getInt(KEY_SELECTED_PRESET, 0));
        Log.d(TAG, "Settings loaded: enabled=" + mIsEnabled.get() + ", preset=" + mCurrentPreset.get());
    }
    
    /**
     * Saves current band levels to SharedPreferences.
     * Must be called with appropriate locks held.
     */
    private void saveCurrentBandLevels() {
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels == null) {
                return;
            }
            SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                editor.putInt(KEY_BAND_PREFIX + i, mCurrentBandLevels[i]);
            }
            editor.apply();
            Log.d(TAG, "Saved " + mCurrentBandLevels.length + " band levels");
        } finally {
            mBandLevelLock.readLock().unlock();
        }
    }
    
    /**
     * Saves the current preset to SharedPreferences.
     *
     * @param preset The preset index to save
     */
    private void savePreset(int preset) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SELECTED_PRESET, preset)
            .apply();
        mCurrentPreset.set(preset);
        Log.d(TAG, "Saved preset: " + getPresetName(preset));
    }
    
    // ========================================================================
    // State Query Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Checks if the equalizer is attached to an audio session.
     *
     * @return True if attached
     */
    public boolean isAttached() {
        return mEqualizer.get() != null && mCurrentAudioSessionId.get() > 0;
    }
    
    /**
     * Checks if the equalizer is operational (attached and enabled).
     *
     * @return True if operational
     */
    public boolean isOperational() {
        return isAttached() && mIsEnabled.get();
    }
    
    /**
     * Checks if the equalizer is enabled.
     *
     * @return True if enabled
     */
    public boolean isEnabled() {
        return mIsEnabled.get();
    }
    
    /**
     * Enables or disables the equalizer.
     *
     * @param enabled True to enable, false to disable
     */
    public void setEnabled(boolean enabled) {
        mIsEnabled.set(enabled);
        
        Equalizer equalizer = mEqualizer.get();
        if (equalizer != null && isAttached()) {
            try {
                equalizer.setEnabled(enabled);
                Log.d(TAG, "Equalizer " + (enabled ? "enabled" : "disabled"));
            } catch (Exception e) {
                Log.e(TAG, "Failed to set enabled", e);
            }
        }
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, enabled)
            .apply();
    }
    
    // ========================================================================
    // Audio Session Management (Thread-Safe)
    // ========================================================================
    
    /**
     * Attaches the equalizer to an audio session.
     *
     * @param audioSessionId The audio session ID to attach to
     */
    public void attachToAudioSession(int audioSessionId) {
        if (audioSessionId < MIN_VALID_SESSION_ID) {
            Log.w(TAG, "attachToAudioSession: invalid session ID " + audioSessionId);
            notifyListenerReady(false);
            return;
        }
        
        // If already attached to the same session, just refresh
        if (mCurrentAudioSessionId.get() == audioSessionId && mEqualizer.get() != null) {
            Log.d(TAG, "Already attached to session " + audioSessionId + ", refreshing");
            if (mIsEnabled.get()) {
                try {
                    Equalizer eq = mEqualizer.get();
                    if (eq != null) eq.setEnabled(true);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to re-enable equalizer", e);
                }
            }
            applyPreset(mCurrentPreset.get());
            notifyListenerReady(true);
            return;
        }
        
        Log.d(TAG, "Attaching equalizer to audio session: " + audioSessionId);
        
        try {
            // Release existing resources before attaching to new session
            release();
            mCurrentAudioSessionId.set(audioSessionId);
            
            // Create equalizer with try-catch to handle invalid sessions
            Equalizer newEqualizer = null;
            try {
                newEqualizer = new Equalizer(0, audioSessionId);
                newEqualizer.setEnabled(mIsEnabled.get());
                Log.d(TAG, "Equalizer created for session " + audioSessionId);
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Equalizer for session " + audioSessionId, e);
                release();
                notifyListenerReady(false);
                return;
            }
            mEqualizer.set(newEqualizer);
            
            // Get band information
            mNumberOfBands = newEqualizer.getNumberOfBands();
            mBandLevelRange = newEqualizer.getBandLevelRange();
            int[] newCenterFrequencies = new int[mNumberOfBands];
            mCenterFrequencies = newCenterFrequencies;
            
            mBandLevelLock.writeLock().lock();
            try {
                mCurrentBandLevels = new int[mNumberOfBands];
            } finally {
                mBandLevelLock.writeLock().unlock();
            }
            
            for (short i = 0; i < mNumberOfBands; i++) {
                newCenterFrequencies[i] = newEqualizer.getCenterFreq(i);
                if (newCenterFrequencies[i] == 0) {
                    newCenterFrequencies[i] = (int) (20 * Math.pow(2, i * 0.5));
                }
            }
            Log.d(TAG, "Equalizer has " + mNumberOfBands + " bands, range [" + 
                  (mBandLevelRange != null ? mBandLevelRange[0] : "?") + ", " +
                  (mBandLevelRange != null ? mBandLevelRange[1] : "?") + "]");
            
            // Load saved band levels
            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            mBandLevelLock.writeLock().lock();
            try {
                for (short i = 0; i < mNumberOfBands; i++) {
                    int savedLevel = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                    if (mBandLevelRange != null) {
                        savedLevel = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], savedLevel));
                    }
                    mCurrentBandLevels[i] = savedLevel;
                    newEqualizer.setBandLevel(i, (short) savedLevel);
                }
            } finally {
                mBandLevelLock.writeLock().unlock();
            }
            
            // Restore custom settings
            restoreCustomBandLevels();
            restoreCustomBoosters();
            restoreCustomPitch();
            restoreCustomSpeed();
            
            // Create bass boost
            try {
                BassBoost newBassBoost = new BassBoost(0, audioSessionId);
                newBassBoost.setEnabled(true);
                int bassLevel = prefs.getInt(KEY_BASS_BOOST, 0);
                short max = newBassBoost.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                newBassBoost.setStrength((short) Math.min(bassLevel, max));
                mBassBoost.set(newBassBoost);
                Log.d(TAG, "Bass boost created, supported=" + newBassBoost.getStrengthSupported());
            } catch (Exception e) {
                Log.e(TAG, "Failed to create BassBoost", e);
                mBassBoost.set(null);
            }
            
            // Create surround effect
            try {
                Virtualizer newSurround = new Virtualizer(0, audioSessionId);
                newSurround.setEnabled(true);
                int surroundLevel = prefs.getInt(KEY_SURROUND, 0);
                short max = newSurround.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                newSurround.setStrength((short) Math.min(surroundLevel, max));
                mSurround.set(newSurround);
                Log.d(TAG, "Surround created");
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Surround", e);
                mSurround.set(null);
            }
            
            // Load pitch and speed
            mPitchLevel.set(prefs.getInt(KEY_PITCH, DEFAULT_PITCH_SPEED));
            mSpeedLevel.set(prefs.getInt(KEY_SPEED, DEFAULT_PITCH_SPEED));
            
            // Apply current preset
            applyPreset(mCurrentPreset.get());
            
            // Notify listeners
            notifyListenerReady(true);
            mBandLevelLock.readLock().lock();
            try {
                if (mCurrentBandLevels != null) {
                    notifyBandLevelsChanged(mCurrentBandLevels.clone());
                }
            } finally {
                mBandLevelLock.readLock().unlock();
            }
            notifyPresetChanged(mCurrentPreset.get(), getPresetName(mCurrentPreset.get()));
            
            Log.d(TAG, "Equalizer successfully attached to session " + audioSessionId);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to attach equalizer", e);
            release();
            notifyListenerReady(false);
        }
    }
    
    /**
     * Detaches the equalizer from the current audio session.
     */
    public void detach() {
        Log.d(TAG, "Detaching equalizer from session " + mCurrentAudioSessionId.get());
        mCurrentAudioSessionId.set(-1);
    }
    
    /**
     * Releases all equalizer resources.
     */
    public void release() {
        Log.d(TAG, "Releasing equalizer resources");
        
        // Save custom settings before releasing
        if (mCurrentPreset.get() == 0) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }
        
        // Release equalizer with safety checks
        Equalizer eq = mEqualizer.getAndSet(null);
        if (eq != null) {
            try {
                saveCurrentBandLevels();
                eq.release();
                Log.d(TAG, "Equalizer released");
            } catch (Exception e) {
                Log.e(TAG, "Error releasing equalizer", e);
            }
        }
        
        // Release bass boost
        BassBoost bb = mBassBoost.getAndSet(null);
        if (bb != null) {
            try {
                bb.release();
                Log.d(TAG, "Bass boost released");
            } catch (Exception e) {
                Log.e(TAG, "Error releasing bass boost", e);
            }
        }
        
        // Release surround
        Virtualizer vs = mSurround.getAndSet(null);
        if (vs != null) {
            try {
                vs.release();
                Log.d(TAG, "Surround released");
            } catch (Exception e) {
                Log.e(TAG, "Error releasing surround", e);
            }
        }
        
        // Reset band data
        mNumberOfBands = 0;
        mBandLevelRange = null;
        mBandLevelLock.writeLock().lock();
        try {
            mCurrentBandLevels = null;
        } finally {
            mBandLevelLock.writeLock().unlock();
        }
        mCenterFrequencies = null;
        mCustomBandLevels = null;
        mCurrentAudioSessionId.set(-1);
    }
    
    // ========================================================================
    // Listener Notification Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Notifies the listener of equalizer ready state.
     *
     * @param ready True if ready
     */
    private void notifyListenerReady(boolean ready) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onEqualizerReady(ready);
                Log.d(TAG, "Notified listener: ready=" + ready);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying listener ready", e);
            }
        }
    }
    
    /**
     * Notifies the listener of band level changes.
     *
     * @param levels The new band levels
     */
    private void notifyBandLevelsChanged(@Nullable int[] levels) {
        EqualizerListener listener = mListener;
        if (listener != null && levels != null) {
            try {
                listener.onBandLevelsChanged(levels);
                Log.d(TAG, "Notified listener: band levels changed");
            } catch (Exception e) {
                Log.e(TAG, "Error notifying band levels changed", e);
            }
        }
    }
    
    /**
     * Notifies the listener of preset changes.
     *
     * @param preset The new preset index
     * @param presetName The name of the new preset
     */
    private void notifyPresetChanged(int preset, @NonNull String presetName) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPresetChanged(preset, presetName);
                Log.d(TAG, "Notified listener: preset=" + presetName);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying preset changed", e);
            }
        }
    }
    
    // ========================================================================
    // Equalizer Band Methods (Thread-Safe with ReadWriteLock)
    // ========================================================================
    
    /**
     * Returns the number of equalizer bands.
     *
     * @return Number of bands
     */
    public short getNumberOfBands() {
        return mNumberOfBands;
    }
    
    /**
     * Returns the minimum allowed band level in millibels.
     *
     * @return Minimum band level
     */
    public short getMinBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[0] : -1500;
    }
    
    /**
     * Returns the maximum allowed band level in millibels.
     *
     * @return Maximum band level
     */
    public short getMaxBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[1] : 1500;
    }
    
    /**
     * Returns the center frequency for a band in millihertz.
     *
     * @param band The band index
     * @return Center frequency in millihertz, or 0 if invalid
     */
    public int getCenterFrequency(int band) {
        if (!isAttached() || band < 0 || mCenterFrequencies == null || band >= mCenterFrequencies.length) {
            return 0;
        }
        return mCenterFrequencies[band];
    }
    
    /**
     * Returns a human-readable frequency label for display.
     *
     * @param frequency The frequency in millihertz
     * @return Formatted frequency string (e.g., "1.2 kHz")
     */
    @NonNull
    public String getFrequencyLabel(int frequency) {
        int freqHz = frequency / 1000;
        if (freqHz < 1000) {
            return freqHz + " Hz";
        }
        int kHz = freqHz / 1000;
        int rem = (freqHz % 1000) / 100;
        if (rem == 0) {
            return kHz + " kHz";
        } else {
            return kHz + "." + rem + " kHz";
        }
    }
    
    /**
     * Sets the level for a specific equalizer band.
     *
     * @param band The band index
     * @param level The level in millibels (clamped to min/max)
     */
    public void setBandLevel(int band, int level) {
        Equalizer equalizer = mEqualizer.get();
        if (!isAttached() || equalizer == null || band < 0 || band >= mNumberOfBands || mBandLevelRange == null) {
            Log.w(TAG, "setBandLevel: invalid band " + band);
            return;
        }
        
        short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], level));
        
        try {
            equalizer.setBandLevel((short) band, clamped);
            
            mBandLevelLock.writeLock().lock();
            try {
                if (mCurrentBandLevels != null) {
                    mCurrentBandLevels[band] = clamped;
                }
            } finally {
                mBandLevelLock.writeLock().unlock();
            }
            
            // Save custom band level if using custom preset
            if (mCurrentPreset.get() == 0 && mCustomBandLevels != null && band < mCustomBandLevels.length) {
                mCustomBandLevels[band] = clamped;
                mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(KEY_CUSTOM_BAND_PREFIX + band, clamped)
                    .apply();
            }
            
            // Save to persistent storage
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BAND_PREFIX + band, clamped)
                .apply();
            
            // Switch to custom preset if a preset was active
            if (mCurrentPreset.get() != 0) {
                mCurrentPreset.set(0);
                savePreset(0);
                backupCustomBandLevels();
                backupCustomBoosters();
                backupCustomPitch();
                backupCustomSpeed();
                notifyPresetChanged(0, "Custom");
            }
            
            mBandLevelLock.readLock().lock();
            try {
                if (mCurrentBandLevels != null) {
                    notifyBandLevelsChanged(mCurrentBandLevels.clone());
                }
            } finally {
                mBandLevelLock.readLock().unlock();
            }
            
            Log.d(TAG, "Band " + band + " set to " + level + " mB");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to set band level", e);
        }
    }
    
    /**
     * Returns the level for a specific equalizer band.
     *
     * @param band The band index
     * @return The level in millibels
     */
    public int getBandLevel(int band) {
        if (!isAttached() || band < 0 || band >= mNumberOfBands) {
            return 0;
        }
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels == null) {
                return 0;
            }
            return mCurrentBandLevels[band];
        } finally {
            mBandLevelLock.readLock().unlock();
        }
    }
    
    /**
     * Returns a copy of all current band levels.
     *
     * @return Array of band levels in millibels
     */
    @NonNull
    public int[] getAllBandLevels() {
        mBandLevelLock.readLock().lock();
        try {
            return mCurrentBandLevels != null ? mCurrentBandLevels.clone() : new int[0];
        } finally {
            mBandLevelLock.readLock().unlock();
        }
    }
    
    // ========================================================================
    // Preset Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Returns the name of a preset by index.
     *
     * @param preset The preset index
     * @return The preset name
     */
    @NonNull
    public String getPresetName(int preset) {
        return (preset >= 0 && preset < PRESET_NAMES.length) ? PRESET_NAMES[preset] : "Custom";
    }
    
    /**
     * Returns all preset names.
     *
     * @return Array of preset names
     */
    @NonNull
    public String[] getPresetNames() {
        return PRESET_NAMES.clone();
    }
    
    /**
     * Returns the currently selected preset index.
     *
     * @return The current preset index
     */
    public int getCurrentPreset() {
        return mCurrentPreset.get();
    }
    
    /**
     * Applies a preset by index.
     *
     * @param presetIndex The preset index to apply
     */
    public void applyPreset(int presetIndex) {
        Equalizer equalizer = mEqualizer.get();
        if (equalizer == null) {
            Log.w(TAG, "applyPreset called but equalizer is null");
            mCurrentPreset.set(presetIndex);
            savePreset(presetIndex);
            return;
        }
        
        if (!isAttached()) {
            Log.w(TAG, "applyPreset called but equalizer not attached");
            mCurrentPreset.set(presetIndex);
            savePreset(presetIndex);
            return;
        }
        
        try {
            if (presetIndex == 0) {
                applyCustomPreset();
            } else if (presetIndex < PRESET_GAINS.length) {
                applyStandardPreset(presetIndex);
            }
            Log.d(TAG, "Applied preset: " + getPresetName(presetIndex));
        } catch (Exception e) {
            Log.e(TAG, "Failed to apply preset", e);
        }
    }
    
    /**
     * Applies the custom preset (user-modified equalizer settings).
     * 
     * <p>This method restores custom band levels, bass boost, surround, pitch, and speed
     * from memory or SharedPreferences. It handles the case where no custom settings exist
     * by falling back to saved band levels or default values.</p>
     * 
     * <p><b>Thread Safety:</b> This method uses the band level write lock and is called
     * from applyPreset() which is already synchronized by the caller's context.</p>
     */
    private void applyCustomPreset() {
        Equalizer equalizer = mEqualizer.get();
        if (equalizer == null || mBandLevelRange == null) {
            Log.w(TAG, "applyCustomPreset: band data not available");
            return;
        }
        
        boolean restored = false;
        
        mBandLevelLock.writeLock().lock();
        try {
            // Restore custom band levels
            if (mCustomBandLevels != null && mCustomBandLevels.length == mNumberOfBands && mCurrentBandLevels != null) {
                for (short i = 0; i < mNumberOfBands; i++) {
                    int level = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], mCustomBandLevels[i]));
                    equalizer.setBandLevel(i, (short) level);
                    mCurrentBandLevels[i] = level;
                }
                restored = true;
                Log.d(TAG, "Restored custom band levels from memory");
            } else if (restoreCustomBandLevels() && mCurrentBandLevels != null) {
                for (short i = 0; i < mNumberOfBands; i++) {
                    int level = mCurrentBandLevels[i];
                    equalizer.setBandLevel(i, (short) level);
                }
                restored = true;
                Log.d(TAG, "Restored custom band levels from preferences");
            }
            
            // Fall back to saved band levels if custom restoration failed
            if (!restored && mCurrentBandLevels != null) {
                SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                for (short i = 0; i < mNumberOfBands; i++) {
                    int saved = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                    saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                    equalizer.setBandLevel(i, (short) saved);
                    mCurrentBandLevels[i] = saved;
                }
                Log.d(TAG, "Fell back to saved band levels");
            } else if (!restored) {
                // mCurrentBandLevels is null - initialize it with zero levels
                Log.w(TAG, "No band levels available for custom preset - using zero levels");
                if (mCurrentBandLevels == null && mNumberOfBands > 0) {
                    mCurrentBandLevels = new int[mNumberOfBands];
                }
                // Set all bands to 0
                if (mCurrentBandLevels != null) {
                    for (short i = 0; i < mNumberOfBands; i++) {
                        equalizer.setBandLevel(i, (short) 0);
                        mCurrentBandLevels[i] = 0;
                    }
                }
            }
        } finally {
            mBandLevelLock.writeLock().unlock();
        }
        
        // Restore boosters and pitch/speed
        restoreCustomBoosters();
        restoreCustomPitch();
        restoreCustomSpeed();
        
        BassBoost bb = mBassBoost.get();
        if (bb != null) {
            bb.setStrength((short) Math.min(mCustomBassBoost.get(), MAX_BOOST_STRENGTH));
        }
        Virtualizer vs = mSurround.get();
        if (vs != null) {
            vs.setStrength((short) Math.min(mCustomSurround.get(), MAX_BOOST_STRENGTH));
        }
        
        // Update state
        mCurrentPreset.set(0);
        saveCurrentBandLevels();
        savePreset(0);
        
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels != null) {
                notifyBandLevelsChanged(mCurrentBandLevels.clone());
            }
        } finally {
            mBandLevelLock.readLock().unlock();
        }
        notifyPresetChanged(0, "Custom");
    }
    
    /**
     * Applies a standard preset by index.
     *
     * @param presetIndex The preset index to apply
     */
    private void applyStandardPreset(int presetIndex) {
        Equalizer equalizer = mEqualizer.get();
        if (equalizer == null || mBandLevelRange == null) {
            Log.w(TAG, "applyStandardPreset: band data not available");
            return;
        }
        
        // Backup current custom settings if switching from custom
        if (mCurrentPreset.get() == 0) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }
        
        int[] gains = PRESET_GAINS[presetIndex];
        mBandLevelLock.writeLock().lock();
        try {
            if (mCurrentBandLevels != null) {
                for (short i = 0; i < Math.min(mNumberOfBands, gains.length); i++) {
                    short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], gains[i]));
                    equalizer.setBandLevel(i, clamped);
                    mCurrentBandLevels[i] = clamped;
                }
            }
        } finally {
            mBandLevelLock.writeLock().unlock();
        }
        
        mCurrentPreset.set(presetIndex);
        saveCurrentBandLevels();
        savePreset(mCurrentPreset.get());
        
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels != null) {
                notifyBandLevelsChanged(mCurrentBandLevels.clone());
            }
        } finally {
            mBandLevelLock.readLock().unlock();
        }
        notifyPresetChanged(mCurrentPreset.get(), getPresetName(mCurrentPreset.get()));
    }
    
    // ========================================================================
    // Custom Settings Backup/Restore Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Backs up current band levels as custom settings.
     */
    private void backupCustomBandLevels() {
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels == null) {
                return;
            }
            SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                editor.putInt(KEY_CUSTOM_BAND_PREFIX + i, mCurrentBandLevels[i]);
            }
            editor.putBoolean(KEY_HAS_CUSTOM_BAND, true);
            editor.apply();
            mCustomBandLevels = mCurrentBandLevels.clone();
            Log.d(TAG, "Backed up " + mCurrentBandLevels.length + " custom band levels");
        } finally {
            mBandLevelLock.readLock().unlock();
        }
    }
    
    /**
     * Backs up current bass boost, surround, pitch, and speed as custom settings.
     */
    private void backupCustomBoosters() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        int customBass = getBassBoost();
        int customSurround = getSurround();
        mCustomBassBoost.set(customBass);
        mCustomSurround.set(customSurround);
        editor.putInt(KEY_CUSTOM_BASS_BOOST, customBass);
        editor.putInt(KEY_CUSTOM_SURROUND, customSurround);
        editor.putBoolean(KEY_HAS_CUSTOM_BOOSTERS, true);
        editor.apply();
        
        backupCustomPitch();
        backupCustomSpeed();
        Log.d(TAG, "Backed up custom boosters: bass=" + customBass + ", surround=" + customSurround);
    }
    
    /**
     * Backs up current pitch as custom setting.
     */
    private void backupCustomPitch() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        int customPitch = getPitch();
        mCustomPitch.set(customPitch);
        editor.putInt(KEY_CUSTOM_PITCH, customPitch);
        editor.putBoolean(KEY_HAS_CUSTOM_PITCH, true);
        editor.apply();
        Log.d(TAG, "Backed up custom pitch: " + customPitch);
    }
    
    /**
     * Backs up current speed as custom setting.
     */
    private void backupCustomSpeed() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        int customSpeed = getSpeed();
        mCustomSpeed.set(customSpeed);
        editor.putInt(KEY_CUSTOM_SPEED, customSpeed);
        editor.putBoolean(KEY_HAS_CUSTOM_SPEED, true);
        editor.apply();
        Log.d(TAG, "Backed up custom speed: " + customSpeed);
    }
    
    /**
     * Restores custom pitch from SharedPreferences.
     */
    private void restoreCustomPitch() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_PITCH, false)) {
            mCustomPitch.set(prefs.getInt(KEY_CUSTOM_PITCH, DEFAULT_PITCH_SPEED));
            Log.d(TAG, "Restored custom pitch: " + mCustomPitch.get());
        }
    }
    
    /**
     * Restores custom speed from SharedPreferences.
     */
    private void restoreCustomSpeed() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_SPEED, false)) {
            mCustomSpeed.set(prefs.getInt(KEY_CUSTOM_SPEED, DEFAULT_PITCH_SPEED));
            Log.d(TAG, "Restored custom speed: " + mCustomSpeed.get());
        }
    }
    
    /**
     * Restores custom band levels from SharedPreferences.
     *
     * @return True if custom band levels were restored
     */
    private boolean restoreCustomBandLevels() {
        if (mBandLevelRange == null) {
            return false;
        }
        
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_HAS_CUSTOM_BAND, false)) {
            return false;
        }
        
        mBandLevelLock.writeLock().lock();
        try {
            if (mCurrentBandLevels == null) {
                return false;
            }
            boolean valid = true;
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                if (prefs.contains(KEY_CUSTOM_BAND_PREFIX + i)) {
                    int saved = prefs.getInt(KEY_CUSTOM_BAND_PREFIX + i, 0);
                    saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                    mCurrentBandLevels[i] = saved;
                } else {
                    valid = false;
                    break;
                }
            }
            
            if (valid) {
                mCustomBandLevels = mCurrentBandLevels.clone();
                Log.d(TAG, "Restored " + mCurrentBandLevels.length + " custom band levels");
                return true;
            }
        } finally {
            mBandLevelLock.writeLock().unlock();
        }
        
        Log.w(TAG, "Failed to restore custom band levels - missing entries");
        return false;
    }
    
    /**
     * Restores custom bass boost and surround from SharedPreferences.
     */
    private void restoreCustomBoosters() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_BOOSTERS, false)) {
            mCustomBassBoost.set(prefs.getInt(KEY_CUSTOM_BASS_BOOST, 0));
            mCustomSurround.set(prefs.getInt(KEY_CUSTOM_SURROUND, 0));
            Log.d(TAG, "Restored custom boosters: bass=" + mCustomBassBoost.get() + 
                  ", surround=" + mCustomSurround.get());
        } else {
            mCustomBassBoost.set(0);
            mCustomSurround.set(0);
        }
    }
    
    /**
     * Clears all custom band levels and resets to zero.
     */
    public void clearCustomBandLevels() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        
        mBandLevelLock.readLock().lock();
        try {
            if (mCurrentBandLevels != null) {
                for (short i = 0; i < mCurrentBandLevels.length; i++) {
                    editor.remove(KEY_CUSTOM_BAND_PREFIX + i);
                }
            }
        } finally {
            mBandLevelLock.readLock().unlock();
        }
        
        editor.remove(KEY_HAS_CUSTOM_BAND);
        editor.remove(KEY_CUSTOM_BASS_BOOST);
        editor.remove(KEY_CUSTOM_SURROUND);
        editor.remove(KEY_HAS_CUSTOM_BOOSTERS);
        editor.remove(KEY_CUSTOM_PITCH);
        editor.remove(KEY_CUSTOM_SPEED);
        editor.remove(KEY_HAS_CUSTOM_PITCH);
        editor.remove(KEY_HAS_CUSTOM_SPEED);
        editor.apply();
        
        // Reset custom values
        mCustomBandLevels = null;
        mCustomBassBoost.set(0);
        mCustomSurround.set(0);
        mCustomPitch.set(DEFAULT_PITCH_SPEED);
        mCustomSpeed.set(DEFAULT_PITCH_SPEED);
        
        // Reset current band levels to zero
        Equalizer equalizer = mEqualizer.get();
        if (mCurrentBandLevels != null && isAttached() && equalizer != null) {
            mBandLevelLock.writeLock().lock();
            try {
                for (short i = 0; i < mCurrentBandLevels.length; i++) {
                    mCurrentBandLevels[i] = 0;
                    equalizer.setBandLevel(i, (short) 0);
                }
            } finally {
                mBandLevelLock.writeLock().unlock();
            }
            saveCurrentBandLevels();
        }
        
        Log.d(TAG, "Cleared all custom settings");
    }
    
    // ========================================================================
    // Bass Boost Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Sets the bass boost level.
     *
     * @param level The bass boost level (0-1000)
     */
    public void setBassBoost(int level) {
        BassBoost bb = mBassBoost.get();
        if (bb == null || !isAttached()) {
            Log.w(TAG, "setBassBoost: bass boost not available");
            return;
        }
        
        try {
            short max = bb.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            short currentStrength = bb.getRoundedStrength();
            
            if (clamped != currentStrength) {
                boolean wasEnabled = bb.getEnabled();
                if (wasEnabled) {
                    bb.setEnabled(false);
                }
                bb.setStrength(clamped);
                if (wasEnabled) {
                    bb.setEnabled(true);
                }
                Log.d(TAG, "Bass boost set to " + clamped);
            }
            
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BASS_BOOST, clamped)
                .apply();
            
            if (mCurrentPreset.get() == 0) {
                mCustomBassBoost.set(clamped);
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setBassBoost error", e);
        }
    }
    
    /**
     * Returns the current bass boost level.
     *
     * @return Bass boost level (0-1000)
     */
    public int getBassBoost() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BASS_BOOST, 0);
    }
    
    /**
     * Checks if bass boost is supported on this device.
     *
     * @return True if supported
     */
    public boolean isBassBoostSupported() {
        BassBoost bb = mBassBoost.get();
        return bb != null && bb.getStrengthSupported() && isAttached();
    }
    
    /**
     * Sets the bass boost strength (low-level method).
     *
     * @param strength The strength value (0-1000)
     */
    public void setBassBoostStrength(short strength) {
        BassBoost bb = mBassBoost.get();
        if (bb != null) {
            try {
                bb.setStrength(strength);
                bb.setEnabled(strength > 0);
                Log.d(TAG, "Bass boost strength set to " + strength);
            } catch (Exception e) {
                Log.e(TAG, "setBassBoostStrength error", e);
            }
        }
    }
    
    /**
     * Returns the current bass boost strength.
     *
     * @return The current strength
     */
    public short getBassBoostStrength() {
        BassBoost bb = mBassBoost.get();
        if (bb == null) {
            return 0;
        }
        return bb.getRoundedStrength();
    }
    
    // ========================================================================
    // Surround/Virtualizer Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Sets the surround effect level.
     *
     * @param level The surround level (0-1000)
     */
    public void setSurround(int level) {
        Virtualizer vs = mSurround.get();
        if (vs == null || !isAttached()) {
            Log.w(TAG, "setSurround: surround not available");
            return;
        }
        
        try {
            short max = vs.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            short currentStrength = vs.getRoundedStrength();
            
            if (clamped != currentStrength) {
                boolean wasEnabled = vs.getEnabled();
                if (wasEnabled) {
                    vs.setEnabled(false);
                }
                vs.setStrength(clamped);
                if (wasEnabled) {
                    vs.setEnabled(true);
                }
                Log.d(TAG, "Surround set to " + clamped);
            }
            
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_SURROUND, clamped)
                .apply();
            
            if (mCurrentPreset.get() == 0) {
                mCustomSurround.set(clamped);
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setSurround error", e);
        }
    }
    
    /**
     * Returns the current surround effect level.
     *
     * @return Surround level (0-1000)
     */
    public int getSurround() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SURROUND, 0);
    }
    
    /**
     * Checks if surround effect is supported on this device.
     *
     * @return True if supported
     */
    public boolean isSurroundSupported() {
        Virtualizer vs = mSurround.get();
        return vs != null && vs.getStrengthSupported() && isAttached();
    }
    
    /**
     * Sets the surround strength (low-level method).
     *
     * @param strength The strength value (0-1000)
     */
    public void setSurroundStrength(short strength) {
        Virtualizer vs = mSurround.get();
        if (vs != null) {
            try {
                vs.setStrength(strength);
                vs.setEnabled(strength > 0);
                Log.d(TAG, "Surround strength set to " + strength);
            } catch (Exception e) {
                Log.e(TAG, "setSurroundStrength error", e);
            }
        }
    }
    
    /**
     * Returns the current surround strength.
     *
     * @return The current strength
     */
    public short getSurroundStrength() {
        Virtualizer vs = mSurround.get();
        if (vs == null) {
            return 0;
        }
        return vs.getRoundedStrength();
    }
    
    // ========================================================================
    // Pitch Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Sets the pitch level.
     *
     * @param level The pitch level (0-2000, 1000 = normal)
     */
    public void setPitch(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }
        
        mPitchLevel.set(smoothedLevel);
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PITCH, smoothedLevel)
            .apply();
        
        if (mCurrentPreset.get() == 0) {
            mCustomPitch.set(smoothedLevel);
            backupCustomPitch();
        }
        
        Log.d(TAG, "Pitch set to " + smoothedLevel + " (" + getPitchSemitones() + " semitones)");
    }
    
    /**
     * Returns the current pitch level.
     *
     * @return Pitch level (0-2000, 1000 = normal)
     */
    public int getPitch() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
    }
    
    /**
     * Returns the current pitch level (direct access).
     *
     * @return Pitch level
     */
    public int getPitchLevel() {
        return mPitchLevel.get();
    }
    
    /**
     * Checks if pitch control is supported.
     *
     * @return Always true (SoundTouch provides this)
     */
    public boolean isPitchSupported() {
        return true;
    }
    
    /**
     * Returns the pitch in semitones.
     *
     * @return Pitch in semitones (-6 to +6)
     */
    public float getPitchSemitones() {
        int level = getPitch();
        if (level == DEFAULT_PITCH_SPEED) {
            return 0f;
        }
        float normalized = (level - DEFAULT_PITCH_SPEED) / 1000.0f;
        return normalized * 6.0f;
    }
    
    // ========================================================================
    // Speed Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Sets the playback speed level.
     *
     * @param level The speed level (0-2000, 1000 = normal)
     */
    public void setSpeed(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }
        
        mSpeedLevel.set(smoothedLevel);
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SPEED, mSpeedLevel.get())
            .apply();
        
        if (mCurrentPreset.get() == 0) {
            mCustomSpeed.set(mSpeedLevel.get());
            backupCustomSpeed();
        }
        
        float speedMultiplier = 0.5f + (smoothedLevel / 2000.0f);
        Log.d(TAG, "Speed set to " + smoothedLevel + " (" + speedMultiplier + "x)");
    }
    
    /**
     * Returns the current speed level.
     *
     * @return Speed level (0-2000, 1000 = normal)
     */
    public int getSpeed() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
    }
    
    /**
     * Returns the current speed as a multiplier.
     *
     * @return Speed multiplier (0.5 to 1.5)
     */
    public float getSpeedMultiplier() {
        int level = getSpeed();
        return 0.5f + (level / 2000.0f);
    }
}