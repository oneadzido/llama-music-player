package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Virtualizer;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Manager for controlling audio effects including equalizer, bass boost, surround,
 * pitch, and speed.
 * 
 * <p>This class provides a comprehensive API for managing audio effects on the
 * Android platform. It encapsulates the complexity of the Android audio effect
 * framework and provides:</p>
 * 
 * <ul>
 *   <li>A 10-band equalizer with 60 preset configurations</li>
 *   <li>Bass boost effect with strength control (0-1000)</li>
 *   <li>Surround effect with strength control (0-1000)</li>
 *   <li>Independent pitch shifting (-6 to +6 semitones)</li>
 *   <li>Independent speed control (0.5x to 1.5x)</li>
 *   <li>Persistent storage of custom settings</li>
 *   <li>Preset management with custom preset saving</li>
 * </ul>
 * 
 * <p>This class follows the singleton pattern and all effect operations should
 * be performed after attaching to an audio session.</p>
 * 
 * <p>Follows Google's recommendations for audio effect management with proper
 * resource cleanup and thread-safe listener notification.</p>
 * 
 * @see Equalizer
 * @see BassBoost
 * @see Virtualizer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class EqualizerManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "EqualizerManager";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for equalizer enabled state. */
    private static final String KEY_EQUALIZER_ENABLED = "equalizer_enabled";
    
    /** Key for bass boost level. */
    private static final String KEY_BASS_BOOST = "bass_boost_level";
    
    /** Key for surround effect level. */
    private static final String KEY_SURROUND = "surround_level";
    
    /** Key for pitch level. */
    private static final String KEY_PITCH = "pitch_level";
    
    /** Key for speed level. */
    private static final String KEY_SPEED = "speed_level";
    
    /** Key for selected preset. */
    private static final String KEY_SELECTED_PRESET = "selected_preset";
    
    /** Prefix for equalizer band level keys. */
    private static final String KEY_BAND_PREFIX = "eq_band_";
    
    /** Prefix for custom equalizer band level keys. */
    private static final String KEY_CUSTOM_BAND_PREFIX = "eq_custom_band_";
    
    /** Key indicating whether custom bands exist. */
    private static final String KEY_HAS_CUSTOM_BAND = "has_custom_band";
    
    /** Key for custom bass boost value. */
    private static final String KEY_CUSTOM_BASS_BOOST = "eq_custom_bass_boost";
    
    /** Key for custom surround value. */
    private static final String KEY_CUSTOM_SURROUND = "eq_custom_surround";
    
    /** Key for custom pitch value. */
    private static final String KEY_CUSTOM_PITCH = "eq_custom_pitch";
    
    /** Key for custom speed value. */
    private static final String KEY_CUSTOM_SPEED = "eq_custom_speed";
    
    /** Key indicating whether custom boosters exist. */
    private static final String KEY_HAS_CUSTOM_BOOSTERS = "has_custom_boosters";
    
    /** Key indicating whether custom pitch exists. */
    private static final String KEY_HAS_CUSTOM_PITCH = "has_custom_pitch";
    
    /** Key indicating whether custom speed exists. */
    private static final String KEY_HAS_CUSTOM_SPEED = "has_custom_speed";
    
    /** Default value for pitch and speed (neutral). */
    private static final int DEFAULT_PITCH_SPEED = 1000;
    
    /** Maximum value for bass boost and surround. */
    private static final int MAX_BOOST_STRENGTH = 1000;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Singleton instance. */
    private static EqualizerManager sInstance;
    
    // ========================================================================
    // Audio Effect Objects
    // ========================================================================
    
    /** Equalizer effect instance. */
    private Equalizer mEqualizer;
    
    /** Bass boost effect instance. */
    private BassBoost mBassBoost;
    
    /** Surround effect instance. */
    private Virtualizer mSurround;
    
    /** Current audio session ID. */
    private int mCurrentAudioSessionId = -1;
    
    /** Whether the equalizer is enabled. */
    private boolean mIsEnabled = false;
    
    /** Currently selected preset index. */
    private int mCurrentPreset = 0;
    
    // ========================================================================
    // Pitch and Speed Values
    // ========================================================================
    
    /** Current pitch level (0-2000, 1000 = normal). */
    private int mPitchLevel = DEFAULT_PITCH_SPEED;
    
    /** Current speed level (0-2000, 1000 = normal). */
    private int mSpeedLevel = DEFAULT_PITCH_SPEED;
    
    // ========================================================================
    // Equalizer Band Data
    // ========================================================================
    
    /** Number of equalizer bands. */
    private short mNumberOfBands = 0;
    
    /** Minimum and maximum band level range. */
    private short[] mBandLevelRange;
    
    /** Current band levels. */
    private int[] mCurrentBandLevels;
    
    /** Center frequencies for each band. */
    private int[] mCenterFrequencies;
    
    /** Custom band levels (saved when switching from custom preset). */
    private int[] mCustomBandLevels;
    
    /** Custom bass boost value. */
    private int mCustomBassBoost = 0;
    
    /** Custom surround value. */
    private int mCustomSurround = 0;
    
    /** Custom pitch value. */
    private int mCustomPitch = DEFAULT_PITCH_SPEED;
    
    /** Custom speed value. */
    private int mCustomSpeed = DEFAULT_PITCH_SPEED;
    
    // ========================================================================
    // Context and Listener
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** Equalizer event listener. */
    @Nullable
    private volatile EqualizerListener mListener;
    
    // ========================================================================
    // Preset Data
    // ========================================================================
    
    /**
     * Array of preset names available in the equalizer.
     * Total of 60 presets covering various music genres and effects.
     */
    private static final String[] PRESET_NAMES = {
        "Custom",       // 0
        "Acoustic",     // 1
        "Afrobeat",     // 2
        "Afropop",      // 3
        "Alternative",  // 4
        "Ambient",      // 5
        "Bass & Treble",// 6
        "Bass Boost",   // 7
        "Bass Reducer", // 8
        "Blues",        // 9
        "Car",          // 10
        "Chill",        // 11
        "Classical",    // 12
        "Club",         // 13
        "Country",      // 14
        "Dance",        // 15
        "Deep",         // 16
        "Disco",        // 17
        "Drum & Bass",  // 18
        "Dubstep",      // 19
        "Electronic",   // 20
        "Folk",         // 21
        "Gospel",       // 22
        "Grunge",       // 23
        "Hard Rock",    // 24
        "Headphones",   // 25
        "Hip Hop",      // 26
        "House",        // 27
        "Indie",        // 28
        "Jazz",         // 29
        "Live",         // 30
        "Loudness",     // 31
        "Lounge",       // 32
        "Metal",        // 33
        "Midnight",     // 34
        "Opera",        // 35
        "Orchestral",   // 36
        "Outdoor",      // 37
        "Party",        // 38
        "Podcast",      // 39
        "Pop",          // 40
        "Psychedelic",  // 41
        "Reference",    // 42
        "Reggae",       // 43
        "Rock",         // 44
        "Ska",          // 45
        "Small Speakers",// 46
        "Soft Rock",    // 47
        "Soul",         // 48
        "Studio",       // 49
        "Symphony",     // 50
        "Techno",       // 51
        "Trance",       // 52
        "Treble Boost", // 53
        "Treble Reducer",// 54
        "Vocal Boost",  // 55
        "Voice",        // 56
        "Warm",         // 57
        "World",        // 58
        "Zero"          // 59
    };
    
    /**
     * Gain values for each preset (in millibels, where 100 = 1 dB).
     * Each inner array contains 10 band gain values.
     */
    private static final int[][] PRESET_GAINS = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                                         // Custom (0)
        {300, 250, 200, 150, 100, 50, 0, -50, -100, -150},                     // Acoustic (1)
        {450, 500, 500, 400, 300, 150, 100, 150, 250, 350},                    // Afrobeat (2)
        {500, 550, 500, 450, 350, 250, 200, 250, 350, 400},                    // Afropop (3)
        {300, 350, 400, 350, 300, 250, 200, 150, 200, 300},                    // Alternative (4)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},                    // Ambient (5)
        {600, 500, 300, 100, 0, 0, 0, 100, 300, 600},                          // Bass & Treble (6)
        {700, 650, 500, 300, 150, 0, -100, -150, -200, -250},                  // Bass Boost (7)
        {-250, -200, -150, -100, -50, 50, 150, 250, 350, 450},                 // Bass Reducer (8)
        {300, 350, 350, 250, 200, 150, 100, 50, 100, 150},                     // Blues (9)
        {500, 450, 350, 250, 150, 100, 100, 150, 200, 250},                    // Car (10)
        {200, 250, 300, 350, 300, 250, 200, 150, 100, 50},                     // Chill (11)
        {400, 350, 300, 250, 200, 150, 100, 50, 0, -50},                       // Classical (12)
        {600, 650, 650, 450, 250, 0, -50, -50, 100, 200},                      // Club (13)
        {250, 300, 350, 400, 350, 300, 200, 150, 100, 50},                     // Country (14)
        {500, 550, 550, 400, 200, 0, 100, 250, 400, 500},                      // Dance (15)
        {800, 850, 700, 400, 150, -50, -150, -200, -300, -350},                // Deep (16)
        {500, 550, 600, 500, 350, 200, 150, 100, 50, 0},                       // Disco (17)
        {650, 650, 500, 250, 100, -50, -100, -50, 150, 200},                   // Drum & Bass (18)
        {700, 750, 550, 200, -100, -250, -150, 50, 200, 300},                  // Dubstep (19)
        {650, 700, 650, 450, 200, 0, 50, 150, 350, 450},                       // Electronic (20)
        {150, 200, 300, 400, 450, 400, 300, 200, 150, 100},                    // Folk (21)
        {200, 250, 350, 450, 550, 500, 400, 300, 200, 150},                    // Gospel (22)
        {450, 500, 400, 200, -75, -100, 0, 150, 300, 400},                     // Grunge (23)
        {400, 450, 500, 450, 300, 200, 200, 250, 350, 400},                    // Hard Rock (24)
        {200, 150, 100, 0, -100, -100, -50, 0, 150, 250},                      // Headphones (25)
        {600, 650, 550, 300, 100, -50, -100, 0, 150, 250},                     // Hip Hop (26)
        {600, 650, 600, 450, 250, 50, 0, 50, 150, 300},                        // House (27)
        {200, 250, 300, 400, 400, 350, 300, 250, 200, 150},                    // Indie (28)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},                    // Jazz (29)
        {100, 150, 250, 400, 500, 450, 350, 250, 150, 100},                    // Live (30)
        {500, 450, 300, 100, -100, -150, -100, 100, 350, 450},                 // Loudness (31)
        {150, 200, 250, 300, 350, 300, 250, 200, 150, 100},                    // Lounge (32)
        {400, 450, 300, 100, -150, -200, -100, 150, 400, 500},                 // Metal (33)
        {200, 250, 300, 250, 150, 50, -50, -100, -150, -200},                  // Midnight (34)
        {250, 300, 350, 350, 300, 250, 200, 150, 100, 50},                     // Opera (35)
        {300, 350, 400, 400, 350, 300, 250, 200, 150, 100},                    // Orchestral (36)
        {300, 350, 400, 350, 300, 300, 350, 400, 450, 500},                    // Outdoor (37)
        {550, 600, 550, 350, 100, -100, -50, 150, 400, 550},                   // Party (38)
        {-200, -100, 100, 400, 600, 700, 600, 400, 200, 0},                    // Podcast (39)
        {250, 300, 350, 400, 450, 450, 400, 350, 300, 250},                    // Pop (40)
        {300, 350, 400, 350, 300, 200, 150, 200, 300, 400},                    // Psychedelic (41)
        {50, 75, 100, 125, 150, 175, 200, 225, 250, 275},                      // Reference (42)
        {450, 500, 450, 350, 250, 150, 100, 50, 0, -50},                       // Reggae (43)
        {350, 400, 450, 500, 450, 350, 250, 200, 250, 300},                    // Rock (44)
        {350, 400, 450, 400, 350, 300, 250, 200, 150, 150},                    // Ska (45)
        {400, 350, 300, 200, 100, 100, 150, 200, 300, 400},                    // Small Speakers (46)
        {200, 250, 300, 400, 350, 250, 150, 100, 50, 25},                      // Soft Rock (47)
        {400, 450, 400, 300, 200, 150, 100, 50, 100, 150},                     // Soul (48)
        {50, 100, 150, 200, 250, 300, 350, 400, 450, 500},                     // Studio (49)
        {400, 450, 500, 450, 400, 350, 300, 250, 200, 150},                    // Symphony (50)
        {650, 600, 500, 350, 150, -50, -100, 0, 200, 400},                     // Techno (51)
        {550, 600, 550, 400, 200, 50, 100, 250, 400, 500},                     // Trance (52)
        {-300, -250, -200, -150, 0, 150, 300, 500, 700, 800},                  // Treble Boost (53)
        {50, 100, 150, 200, 150, 100, 50, 0, -100, -200},                      // Treble Reducer (54)
        {-200, -150, 200, 400, 500, 600, 500, 400, 200, -100},                 // Vocal Boost (55)
        {-400, -300, 0, 400, 600, 700, 600, 400, 0, -300},                     // Voice (56)
        {400, 350, 250, 150, 100, 50, 25, 0, -25, -50},                        // Warm (57)
        {200, 300, 350, 400, 400, 350, 300, 200, 150, 100},                    // World (58)
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}                                         // Zero (59)
    };
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for equalizer events.
     * 
     * <p>Implement this interface to receive callbacks when the equalizer
     * state changes, such as band levels, preset changes, or ready state.</p>
     */
    public interface EqualizerListener {
        
        /**
         * Called when equalizer band levels change.
         *
         * @param levels Array of new band level values
         */
        void onBandLevelsChanged(@NonNull int[] levels);
        
        /**
         * Called when the preset changes.
         *
         * @param preset The new preset index
         * @param presetName The name of the new preset
         */
        void onPresetChanged(int preset, @NonNull String presetName);
        
        /**
         * Called when the equalizer becomes ready or unready.
         *
         * @param ready True if the equalizer is ready for use
         */
        void onEqualizerReady(boolean ready);
    }
    
    // ========================================================================
    // Constructor and Singleton
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private EqualizerManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadSettings();
    }
    
    /**
     * Returns the singleton instance of EqualizerManager.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized EqualizerManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new EqualizerManager(context);
        }
        return sInstance;
    }
    
    // ========================================================================
    // Listener Management
    // ========================================================================
    
    /**
     * Sets the equalizer event listener.
     * 
     * <p>This method is thread-safe for listener management.</p>
     *
     * @param listener The listener to receive events (can be null)
     */
    public synchronized void setListener(@Nullable EqualizerListener listener) {
        mListener = listener;
    }
    
    // ========================================================================
    // Settings Loading/Saving
    // ========================================================================
    
    /**
     * Loads saved settings from SharedPreferences.
     */
    private void loadSettings() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mIsEnabled = prefs.getBoolean(KEY_EQUALIZER_ENABLED, false);
        mCurrentPreset = prefs.getInt(KEY_SELECTED_PRESET, 0);
    }
    
    /**
     * Saves the current band levels to SharedPreferences.
     */
    private void saveCurrentBandLevels() {
        if (mCurrentBandLevels == null) {
            return;
        }
        
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            editor.putInt(KEY_BAND_PREFIX + i, mCurrentBandLevels[i]);
        }
        editor.apply();
    }
    
    /**
     * Saves the selected preset to SharedPreferences.
     *
     * @param preset The preset index to save
     */
    private void savePreset(int preset) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SELECTED_PRESET, preset)
            .apply();
        mCurrentPreset = preset;
    }
    
    // ========================================================================
    // State Query Methods
    // ========================================================================
    
    /**
     * Checks if the equalizer is attached to an audio session.
     *
     * @return True if attached to an active audio session
     */
    public boolean isAttached() {
        return mEqualizer != null && mCurrentAudioSessionId > 0;
    }
    
    /**
     * Checks if the equalizer is operational (attached and enabled).
     *
     * @return True if the equalizer can be used
     */
    public boolean isOperational() {
        return isAttached() && mIsEnabled;
    }
    
    /**
     * Checks if the equalizer is enabled.
     *
     * @return True if enabled
     */
    public boolean isEnabled() {
        return mIsEnabled;
    }
    
    /**
     * Enables or disables the equalizer.
     *
     * @param enabled True to enable, false to disable
     */
    public void setEnabled(boolean enabled) {
        mIsEnabled = enabled;
        
        if (mEqualizer != null && isAttached()) {
            try {
                mEqualizer.setEnabled(enabled);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set enabled", e);
            }
        }
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, enabled)
            .apply();
    }
    
    // ========================================================================
    // Audio Session Management
    // ========================================================================
    
    /**
     * Attaches the equalizer to an audio session.
     * 
     * <p>This method must be called before any equalizer operations.
     * The audio session ID is obtained from the MediaPlayer.</p>
     *
     * @param audioSessionId The audio session ID to attach to
     */
    public void attachToAudioSession(int audioSessionId) {
        try {
            if (audioSessionId <= 0) {
                Log.w(TAG, "attachToAudioSession: invalid session ID " + audioSessionId);
                notifyListenerReady(false);
                return;
            }
            
            if (mCurrentAudioSessionId == audioSessionId && mEqualizer != null) {
                Log.d(TAG, "Already attached to session " + audioSessionId);
                notifyListenerReady(true);
                applyPreset(mCurrentPreset);
                return;
            }
            
            release();
            mCurrentAudioSessionId = audioSessionId;
            
            // Create equalizer with try-catch to handle invalid sessions
            try {
                mEqualizer = new Equalizer(0, audioSessionId);
                mEqualizer.setEnabled(mIsEnabled);
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Equalizer for session " + audioSessionId, e);
                release();
                notifyListenerReady(false);
                return;
            }
            
            // Get band information
            mNumberOfBands = mEqualizer.getNumberOfBands();
            mBandLevelRange = mEqualizer.getBandLevelRange();
            mCenterFrequencies = new int[mNumberOfBands];
            mCurrentBandLevels = new int[mNumberOfBands];
            
            for (short i = 0; i < mNumberOfBands; i++) {
                mCenterFrequencies[i] = mEqualizer.getCenterFreq(i);
                if (mCenterFrequencies[i] == 0) {
                    mCenterFrequencies[i] = (int) (20 * Math.pow(2, i * 0.5));
                }
            }
            
            // Load saved band levels
            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            for (short i = 0; i < mNumberOfBands; i++) {
                int savedLevel = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                savedLevel = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], savedLevel));
                mCurrentBandLevels[i] = savedLevel;
                mEqualizer.setBandLevel(i, (short) savedLevel);
            }
            
            // Restore custom settings
            restoreCustomBandLevels();
            restoreCustomBoosters();
            restoreCustomPitch();
            restoreCustomSpeed();
            
            // Create bass boost
            try {
                mBassBoost = new BassBoost(0, audioSessionId);
                mBassBoost.setEnabled(true);
                int bassLevel = prefs.getInt(KEY_BASS_BOOST, 0);
                short max = mBassBoost.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                mBassBoost.setStrength((short) Math.min(bassLevel, max));
            } catch (Exception e) {
                Log.e(TAG, "Failed to create BassBoost", e);
                mBassBoost = null;
            }
            
            // Create surround effect
            try {
                mSurround = new Virtualizer(0, audioSessionId);
                mSurround.setEnabled(true);
                int surroundLevel = prefs.getInt(KEY_SURROUND, 0);
                short max = mSurround.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                mSurround.setStrength((short) Math.min(surroundLevel, max));
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Surround", e);
                mSurround = null;
            }
            
            // Load pitch and speed
            mPitchLevel = prefs.getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
            mSpeedLevel = prefs.getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
            
            // Apply current preset
            applyPreset(mCurrentPreset);
            
            // Notify listeners
            notifyListenerReady(true);
            notifyBandLevelsChanged(mCurrentBandLevels);
            notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to attach equalizer", e);
            release();
            notifyListenerReady(false);
        }
    }
    
    /**
     * Detaches the equalizer from the current audio session.
     */
    public void detach() {
        mCurrentAudioSessionId = -1;
    }
    
    /**
     * Releases all audio effect resources.
     * 
     * <p>This method should be called when the equalizer is no longer needed,
     * typically when the audio session is destroyed.</p>
     */
    public void release() {
        // Save custom settings before releasing
        if (mCurrentPreset == 0 && mCurrentBandLevels != null) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }
        
        // Release equalizer with safety checks
        if (mEqualizer != null) {
            try {
                saveCurrentBandLevels();
                mEqualizer.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing equalizer", e);
            }
            mEqualizer = null;
        }
        
        // Release bass boost with safety checks
        if (mBassBoost != null) {
            try {
                mBassBoost.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing bass boost", e);
            }
            mBassBoost = null;
        }
        
        // Release surround with safety checks
        if (mSurround != null) {
            try {
                mSurround.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing surround", e);
            }
            mSurround = null;
        }
        
        // Reset band data
        mNumberOfBands = 0;
        mBandLevelRange = null;
        mCurrentBandLevels = null;
        mCenterFrequencies = null;
        mCustomBandLevels = null;
        mCurrentAudioSessionId = -1;
    }
    
    // ========================================================================
    // Listener Notification Methods
    // ========================================================================
    
    /**
     * Notifies the listener about equalizer readiness.
     *
     * @param ready True if the equalizer is ready
     */
    private void notifyListenerReady(boolean ready) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onEqualizerReady(ready);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying listener ready", e);
            }
        }
    }
    
    /**
     * Notifies the listener about band level changes.
     *
     * @param levels The new band level array
     */
    private void notifyBandLevelsChanged(@Nullable int[] levels) {
        EqualizerListener listener = mListener;
        if (listener != null && levels != null) {
            try {
                listener.onBandLevelsChanged(levels);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying band levels changed", e);
            }
        }
    }
    
    /**
     * Notifies the listener about preset changes.
     *
     * @param preset The new preset index
     * @param presetName The name of the new preset
     */
    private void notifyPresetChanged(int preset, @NonNull String presetName) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPresetChanged(preset, presetName);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying preset changed", e);
            }
        }
    }
    
    // ========================================================================
    // Equalizer Band Methods
    // ========================================================================
    
    /**
     * Returns the number of equalizer bands.
     *
     * @return Number of bands (typically 5 or 10)
     */
    public short getNumberOfBands() {
        return mNumberOfBands;
    }
    
    /**
     * Returns the minimum band level in millibels.
     *
     * @return Minimum band level (typically -1500 = -15 dB)
     */
    public short getMinBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[0] : -1500;
    }
    
    /**
     * Returns the maximum band level in millibels.
     *
     * @return Maximum band level (typically 1500 = 15 dB)
     */
    public short getMaxBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[1] : 1500;
    }
    
    /**
     * Returns the center frequency for a band in Hz.
     *
     * @param band The band index
     * @return Center frequency in Hz
     */
    public int getCenterFrequency(int band) {
        if (!isAttached() || band < 0 || band >= mCenterFrequencies.length) {
            return 0;
        }
        return mCenterFrequencies[band];
    }
    
    /**
     * Returns a human-readable frequency label for a band.
     *
     * @param frequency The frequency in Hz
     * @return Formatted frequency string (e.g., "60 Hz" or "3.6 kHz")
     */
    @NonNull
    public String getFrequencyLabel(int frequency) {
        int freqHz = frequency / 1000;
        if (freqHz < 1000) {
            return freqHz + " Hz";
        }
        
        int kHz = freqHz / 1000;
        int rem = (freqHz % 1000) / 100;
        
        if (rem == 0) {
            return kHz + " kHz";
        } else {
            return kHz + "." + rem + " kHz";
        }
    }
    
    /**
     * Sets the level for a specific equalizer band.
     *
     * @param band The band index
     * @param level The level in millibels (within min/max range)
     */
    public void setBandLevel(int band, int level) {
        if (!isAttached() || band < 0 || band >= mNumberOfBands) {
            return;
        }
        
        short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], level));
        
        try {
            mEqualizer.setBandLevel((short) band, clamped);
            mCurrentBandLevels[band] = clamped;
            
            // Save custom band level if using custom preset
            if (mCurrentPreset == 0) {
                if (mCustomBandLevels != null && band < mCustomBandLevels.length) {
                    mCustomBandLevels[band] = clamped;
                }
                mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(KEY_CUSTOM_BAND_PREFIX + band, clamped)
                    .apply();
            }
            
            // Save to persistent storage
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BAND_PREFIX + band, clamped)
                .apply();
            
            // Switch to custom preset if a preset was active
            if (mCurrentPreset != 0) {
                mCurrentPreset = 0;
                savePreset(0);
                backupCustomBandLevels();
                backupCustomBoosters();
                backupCustomPitch();
                backupCustomSpeed();
                notifyPresetChanged(0, "Custom");
            }
            
            notifyBandLevelsChanged(mCurrentBandLevels);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to set band level", e);
        }
    }
    
    /**
     * Returns the level for a specific equalizer band.
     *
     * @param band The band index
     * @return The level in millibels
     */
    public int getBandLevel(int band) {
        if (!isAttached() || band < 0 || band >= mNumberOfBands || mCurrentBandLevels == null) {
            return 0;
        }
        return mCurrentBandLevels[band];
    }
    
    /**
     * Returns all current band levels as an array.
     *
     * @return A copy of the current band levels
     */
    @NonNull
    public int[] getAllBandLevels() {
        return mCurrentBandLevels != null ? mCurrentBandLevels.clone() : new int[0];
    }
    
    // ========================================================================
    // Preset Methods
    // ========================================================================
    
    /**
     * Returns the name of a preset by index.
     *
     * @param preset The preset index
     * @return The preset name
     */
    @NonNull
    public String getPresetName(int preset) {
        return (preset >= 0 && preset < PRESET_NAMES.length) ? PRESET_NAMES[preset] : "Custom";
    }
    
    /**
     * Returns all preset names as an array.
     *
     * @return Array of preset names
     */
    @NonNull
    public String[] getPresetNames() {
        return PRESET_NAMES.clone();
    }
    
    /**
     * Returns the currently selected preset index.
     *
     * @return The current preset index
     */
    public int getCurrentPreset() {
        return mCurrentPreset;
    }
    
    /**
     * Applies a preset by index.
     * 
     * <p>For preset 0 (Custom), it restores the saved custom settings.
     * For other presets, it applies predefined gain values.</p>
     *
     * @param presetIndex The preset index to apply
     */
    public void applyPreset(int presetIndex) {
        if (mEqualizer == null) {
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }
        
        if (!isAttached()) {
            Log.w(TAG, "applyPreset called but equalizer not attached");
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }
        
        try {
            if (presetIndex == 0) {
                applyCustomPreset();
            } else if (presetIndex < PRESET_GAINS.length) {
                applyStandardPreset(presetIndex);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to apply preset", e);
        }
    }
    
    /**
     * Applies the custom preset (restores saved custom settings).
     */
    private void applyCustomPreset() {
        boolean restored = false;
        
        // Restore custom band levels
        if (mCustomBandLevels != null && mCustomBandLevels.length == mNumberOfBands) {
            for (short i = 0; i < mNumberOfBands; i++) {
                int level = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], mCustomBandLevels[i]));
                mEqualizer.setBandLevel(i, (short) level);
                mCurrentBandLevels[i] = level;
            }
            restored = true;
        } else if (restoreCustomBandLevels()) {
            for (short i = 0; i < mNumberOfBands; i++) {
                int level = mCurrentBandLevels[i];
                mEqualizer.setBandLevel(i, (short) level);
            }
            restored = true;
        }
        
        // Fall back to saved band levels
        if (!restored) {
            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            for (short i = 0; i < mNumberOfBands; i++) {
                int saved = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                mEqualizer.setBandLevel(i, (short) saved);
                mCurrentBandLevels[i] = saved;
            }
        }
        
        // Restore boosters and pitch/speed
        restoreCustomBoosters();
        restoreCustomPitch();
        restoreCustomSpeed();
        
        if (mBassBoost != null) {
            mBassBoost.setStrength((short) Math.min(mCustomBassBoost, MAX_BOOST_STRENGTH));
        }
        if (mSurround != null) {
            mSurround.setStrength((short) Math.min(mCustomSurround, MAX_BOOST_STRENGTH));
        }
        
        // Update state
        mCurrentPreset = 0;
        saveCurrentBandLevels();
        savePreset(0);
        
        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(0, "Custom");
    }
    
    /**
     * Applies a standard preset from the preset gains array.
     *
     * @param presetIndex The preset index to apply
     */
    private void applyStandardPreset(int presetIndex) {
        // Backup current custom settings if switching from custom
        if (mCurrentPreset == 0) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }
        
        int[] gains = PRESET_GAINS[presetIndex];
        for (short i = 0; i < Math.min(mNumberOfBands, gains.length); i++) {
            short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], gains[i]));
            mEqualizer.setBandLevel(i, clamped);
            mCurrentBandLevels[i] = clamped;
        }
        
        mCurrentPreset = presetIndex;
        saveCurrentBandLevels();
        savePreset(mCurrentPreset);
        
        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));
    }
    
    // ========================================================================
    // Custom Settings Backup/Restore Methods
    // ========================================================================
    
    /**
     * Backs up current band levels as custom settings.
     */
    private void backupCustomBandLevels() {
        if (mCurrentBandLevels == null) {
            return;
        }
        
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            editor.putInt(KEY_CUSTOM_BAND_PREFIX + i, mCurrentBandLevels[i]);
        }
        editor.putBoolean(KEY_HAS_CUSTOM_BAND, true);
        editor.apply();
        
        mCustomBandLevels = mCurrentBandLevels.clone();
    }
    
    /**
     * Backs up current bass boost and surround values as custom settings.
     */
    private void backupCustomBoosters() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomBassBoost = getBassBoost();
        mCustomSurround = getSurround();
        editor.putInt(KEY_CUSTOM_BASS_BOOST, mCustomBassBoost);
        editor.putInt(KEY_CUSTOM_SURROUND, mCustomSurround);
        editor.putBoolean(KEY_HAS_CUSTOM_BOOSTERS, true);
        editor.apply();
        
        backupCustomPitch();
        backupCustomSpeed();
    }
    
    /**
     * Backs up current pitch value as custom setting.
     */
    private void backupCustomPitch() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomPitch = getPitch();
        editor.putInt(KEY_CUSTOM_PITCH, mCustomPitch);
        editor.putBoolean(KEY_HAS_CUSTOM_PITCH, true);
        editor.apply();
    }
    
    /**
     * Backs up current speed value as custom setting.
     */
    private void backupCustomSpeed() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomSpeed = getSpeed();
        editor.putInt(KEY_CUSTOM_SPEED, mCustomSpeed);
        editor.putBoolean(KEY_HAS_CUSTOM_SPEED, true);
        editor.apply();
    }
    
    /**
     * Restores custom pitch value from SharedPreferences.
     */
    private void restoreCustomPitch() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_PITCH, false)) {
            mCustomPitch = prefs.getInt(KEY_CUSTOM_PITCH, DEFAULT_PITCH_SPEED);
        }
    }
    
    /**
     * Restores custom speed value from SharedPreferences.
     */
    private void restoreCustomSpeed() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_SPEED, false)) {
            mCustomSpeed = prefs.getInt(KEY_CUSTOM_SPEED, DEFAULT_PITCH_SPEED);
        }
    }
    
    /**
     * Restores custom band levels from SharedPreferences.
     *
     * @return True if restoration was successful
     */
    private boolean restoreCustomBandLevels() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_HAS_CUSTOM_BAND, false) || mCurrentBandLevels == null) {
            return false;
        }
        
        boolean valid = true;
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            if (prefs.contains(KEY_CUSTOM_BAND_PREFIX + i)) {
                int saved = prefs.getInt(KEY_CUSTOM_BAND_PREFIX + i, 0);
                saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                mCurrentBandLevels[i] = saved;
            } else {
                valid = false;
                break;
            }
        }
        
        if (valid) {
            mCustomBandLevels = mCurrentBandLevels.clone();
            return true;
        }
        
        return false;
    }
    
    /**
     * Restores custom bass boost and surround values from SharedPreferences.
     */
    private void restoreCustomBoosters() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_BOOSTERS, false)) {
            mCustomBassBoost = prefs.getInt(KEY_CUSTOM_BASS_BOOST, 0);
            mCustomSurround = prefs.getInt(KEY_CUSTOM_SURROUND, 0);
        } else {
            mCustomBassBoost = 0;
            mCustomSurround = 0;
        }
    }
    
    /**
     * Clears all custom band levels (resets to zero).
     */
    public void clearCustomBandLevels() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        
        // Remove custom band entries
        if (mCurrentBandLevels != null) {
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                editor.remove(KEY_CUSTOM_BAND_PREFIX + i);
            }
        }
        
        editor.remove(KEY_HAS_CUSTOM_BAND);
        editor.remove(KEY_CUSTOM_BASS_BOOST);
        editor.remove(KEY_CUSTOM_SURROUND);
        editor.remove(KEY_HAS_CUSTOM_BOOSTERS);
        editor.remove(KEY_CUSTOM_PITCH);
        editor.remove(KEY_CUSTOM_SPEED);
        editor.remove(KEY_HAS_CUSTOM_PITCH);
        editor.remove(KEY_HAS_CUSTOM_SPEED);
        editor.apply();
        
        // Reset custom values
        if (mCustomBandLevels != null) {
            for (int i = 0; i < mCustomBandLevels.length; i++) {
                mCustomBandLevels[i] = 0;
            }
        }
        
        mCustomBassBoost = 0;
        mCustomSurround = 0;
        mCustomPitch = DEFAULT_PITCH_SPEED;
        mCustomSpeed = DEFAULT_PITCH_SPEED;
        
        // Reset current band levels to zero
        if (mCurrentBandLevels != null && isAttached()) {
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                mCurrentBandLevels[i] = 0;
                try {
                    mEqualizer.setBandLevel(i, (short) 0);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to reset band level", e);
                }
            }
            saveCurrentBandLevels();
        }
    }
    
    // ========================================================================
    // Bass Boost Methods
    // ========================================================================
    
    /**
     * Sets the bass boost strength.
     *
     * @param level The strength level (0-1000)
     */
    public void setBassBoost(int level) {
        if (mBassBoost == null || !isAttached()) {
            return;
        }
        
        try {
            short max = mBassBoost.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            short currentStrength = mBassBoost.getRoundedStrength();
            
            if (clamped != currentStrength) {
                boolean wasEnabled = mBassBoost.getEnabled();
                if (wasEnabled) {
                    mBassBoost.setEnabled(false);
                }
                mBassBoost.setStrength(clamped);
                if (wasEnabled) {
                    mBassBoost.setEnabled(true);
                }
            }
            
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BASS_BOOST, clamped)
                .apply();
            
            if (mCurrentPreset == 0) {
                mCustomBassBoost = clamped;
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setBassBoost error", e);
        }
    }
    
    /**
     * Returns the current bass boost strength.
     *
     * @return The bass boost strength (0-1000)
     */
    public int getBassBoost() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BASS_BOOST, 0);
    }
    
    /**
     * Checks if bass boost is supported on this device.
     *
     * @return True if supported
     */
    public boolean isBassBoostSupported() {
        return mBassBoost != null && mBassBoost.getStrengthSupported() && isAttached();
    }
    
    /**
     * Sets bass boost strength directly (short version).
     *
     * @param strength The strength value
     */
    public void setBassBoostStrength(short strength) {
        if (mBassBoost != null) {
            try {
                mBassBoost.setStrength(strength);
                mBassBoost.setEnabled(strength > 0);
            } catch (Exception e) {
                Log.e(TAG, "setBassBoostStrength error", e);
            }
        }
    }
    
    /**
     * Returns the rounded bass boost strength.
     *
     * @return The rounded strength
     */
    public short getBassBoostStrength() {
        if (mBassBoost == null) {
            return 0;
        }
        return mBassBoost.getRoundedStrength();
    }
    
    // ========================================================================
    // Surround/Virtualizer Methods
    // ========================================================================
    
    /**
     * Sets the surround effect strength.
     *
     * @param level The strength level (0-1000)
     */
    public void setSurround(int level) {
        if (mSurround == null || !isAttached()) {
            return;
        }
        
        try {
            short max = mSurround.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            short currentStrength = mSurround.getRoundedStrength();
            
            if (clamped != currentStrength) {
                boolean wasEnabled = mSurround.getEnabled();
                if (wasEnabled) {
                    mSurround.setEnabled(false);
                }
                mSurround.setStrength(clamped);
                if (wasEnabled) {
                    mSurround.setEnabled(true);
                }
            }
            
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_SURROUND, clamped)
                .apply();
            
            if (mCurrentPreset == 0) {
                mCustomSurround = clamped;
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setSurround error", e);
        }
    }
    
    /**
     * Returns the current surround effect strength.
     *
     * @return The surround strength (0-1000)
     */
    public int getSurround() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SURROUND, 0);
    }
    
    /**
     * Checks if surround effect is supported on this device.
     *
     * @return True if supported
     */
    public boolean isSurroundSupported() {
        return mSurround != null && mSurround.getStrengthSupported() && isAttached();
    }
    
    /**
     * Sets surround strength directly (short version).
     *
     * @param strength The strength value
     */
    public void setSurroundStrength(short strength) {
        if (mSurround != null) {
            try {
                mSurround.setStrength(strength);
                mSurround.setEnabled(strength > 0);
            } catch (Exception e) {
                Log.e(TAG, "setSurroundStrength error", e);
            }
        }
    }
    
    /**
     * Returns the rounded surround strength.
     *
     * @return The rounded strength
     */
    public short getSurroundStrength() {
        if (mSurround == null) {
            return 0;
        }
        return mSurround.getRoundedStrength();
    }
    
    // ========================================================================
    // Pitch Methods
    // ========================================================================
    
    /**
     * Sets the pitch shift level.
     * 
     * <p>The value range is 0-2000, where:
     * <ul>
     *   <li>0 = -6 semitones (lowest)</li>
     *   <li>1000 = normal pitch</li>
     *   <li>2000 = +6 semitones (highest)</li>
     * </ul>
     * </p>
     *
     * @param level The pitch level (0-2000)
     */
    public void setPitch(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }
        
        mPitchLevel = smoothedLevel;
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PITCH, smoothedLevel)
            .apply();
        
        if (mCurrentPreset == 0) {
            mCustomPitch = smoothedLevel;
            backupCustomPitch();
        }
    }
    
    /**
     * Returns the current pitch level.
     *
     * @return The pitch level (0-2000)
     */
    public int getPitch() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
    }
    
    /**
     * Returns the raw pitch level value.
     *
     * @return The pitch level
     */
    public int getPitchLevel() {
        return mPitchLevel;
    }
    
    /**
     * Checks if pitch shifting is supported (always true).
     *
     * @return True
     */
    public boolean isPitchSupported() {
        return true;
    }
    
    /**
     * Returns the pitch shift in semitones.
     *
     * @return Semitones (range approximately -6 to +6)
     */
    public float getPitchSemitones() {
        int level = getPitch();
        if (level == DEFAULT_PITCH_SPEED) {
            return 0f;
        }
        float normalized = (level - DEFAULT_PITCH_SPEED) / 1000.0f;
        return normalized * 6.0f;
    }
    
    // ========================================================================
    // Speed Methods
    // ========================================================================
    
    /**
     * Sets the playback speed level.
     * 
     * <p>Speed is calculated as: <strong>0.5 + (level / 2000)</strong></p>
     * 
     * <p>This produces the following mapping:</p>
     * <ul>
     *   <li>level = 0 -> 0.5x (50% slower)</li>
     *   <li>level = 500 -> 0.75x (25% slower)</li>
     *   <li>level = 1000 -> 1.0x (normal speed)</li>
     *   <li>level = 1500 -> 1.25x (25% faster)</li>
     *   <li>level = 2000 -> 1.5x (50% faster)</li>
     * </ul>
     *
     * @param level The speed level, where 0 = slowest (0.5x) and 2000 = fastest (1.5x)
     */
    public void setSpeed(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }
        
        mSpeedLevel = smoothedLevel;
        
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SPEED, mSpeedLevel)
            .apply();
        
        if (mCurrentPreset == 0) {
            mCustomSpeed = mSpeedLevel;
            backupCustomSpeed();
        }
    }
    
    /**
     * Returns the current speed level.
     *
     * @return The speed level (0-2000)
     */
    public int getSpeed() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
    }
}