package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Virtualizer;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Manages audio effects: a multi-band equalizer, bass boost, surround,
 * pitch, and speed, with persistent storage of every user-facing setting.
 *
 * <p>Effect parameters are stored in {@link SharedPreferences}. Setters
 * write to both {@link SharedPreferences} and the corresponding Android
 * audio-effect object; getters read the persisted value. A caller that
 * sets a value and reads it back receives the value it set, regardless of
 * any rounding the underlying effect applies.</p>
 *
 * <h3>State Ownership</h3>
 * <p>SharedPreferences are the authoritative store for every user-facing
 * setting this manager exposes: equalizer enabled state, band levels,
 * bass boost, surround, pitch, speed, the selected preset, and the
 * custom-settings snapshots. The manager reads through getters and writes
 * through setters, both of which go to SharedPreferences.</p>
 *
 * <p>The Android audio effect objects ({@link Equalizer}, {@link BassBoost},
 * {@link Virtualizer}) drive playback-time behaviour. Their internal
 * state is written by this manager when a setter is called. Getters
 * return the SharedPreferences value, not the effect object's rounded
 * value.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Listener registration and unregistration are synchronized on this
 * instance. Other methods are not internally synchronized; callers that
 * invoke them from multiple threads must provide their own
 * coordination.</p>
 *
 * @see Equalizer
 * @see BassBoost
 * @see Virtualizer
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class EqualizerManager {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "EqualizerManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the equalizer enabled state. */
    private static final String KEY_EQUALIZER_ENABLED = "equalizer_enabled";

    /** Key for the bass boost level. */
    private static final String KEY_BASS_BOOST = "bass_boost_level";

    /** Key for the surround effect level. */
    private static final String KEY_SURROUND = "surround_level";

    /** Key for the pitch level. */
    private static final String KEY_PITCH = "pitch_level";

    /** Key for the speed level. */
    private static final String KEY_SPEED = "speed_level";

    /** Key for the selected preset. */
    private static final String KEY_SELECTED_PRESET = "selected_preset";

    /** Prefix for equalizer band level keys. */
    private static final String KEY_BAND_PREFIX = "eq_band_";

    /** Prefix for custom equalizer band level keys. */
    private static final String KEY_CUSTOM_BAND_PREFIX = "eq_custom_band_";

    /** Key indicating whether custom bands exist. */
    private static final String KEY_HAS_CUSTOM_BAND = "has_custom_band";

    /** Key for the custom bass boost value. */
    private static final String KEY_CUSTOM_BASS_BOOST = "eq_custom_bass_boost";

    /** Key for the custom surround value. */
    private static final String KEY_CUSTOM_SURROUND = "eq_custom_surround";

    /** Key for the custom pitch value. */
    private static final String KEY_CUSTOM_PITCH = "eq_custom_pitch";

    /** Key for the custom speed value. */
    private static final String KEY_CUSTOM_SPEED = "eq_custom_speed";

    /** Key indicating whether custom boosters exist. */
    private static final String KEY_HAS_CUSTOM_BOOSTERS = "has_custom_boosters";

    /** Key indicating whether a custom pitch exists. */
    private static final String KEY_HAS_CUSTOM_PITCH = "has_custom_pitch";

    /** Key indicating whether a custom speed exists. */
    private static final String KEY_HAS_CUSTOM_SPEED = "has_custom_speed";

    /** Default value for pitch and speed, meaning neutral. */
    private static final int DEFAULT_PITCH_SPEED = 1000;

    /** Maximum value for bass boost and surround. */
    private static final int MAX_BOOST_STRENGTH = 1000;

    // ========================================================================
    // Preset Data
    // ========================================================================

    /** Names of the sixty presets, indexed by preset index. */
    private static final String[] PRESET_NAMES = {
        "Custom",          // 0
        "Acoustic",        // 1
        "Afrobeat",        // 2
        "Afropop",         // 3
        "Alternative",     // 4
        "Ambient",         // 5
        "Bass & Treble",   // 6
        "Bass Boost",      // 7
        "Bass Reducer",    // 8
        "Blues",           // 9
        "Car",             // 10
        "Chill",           // 11
        "Classical",       // 12
        "Club",            // 13
        "Country",         // 14
        "Dance",           // 15
        "Deep",            // 16
        "Disco",           // 17
        "Drum & Bass",     // 18
        "Dubstep",         // 19
        "Electronic",      // 20
        "Folk",            // 21
        "Gospel",          // 22
        "Grunge",          // 23
        "Hard Rock",       // 24
        "Headphones",      // 25
        "Hip Hop",         // 26
        "House",           // 27
        "Indie",           // 28
        "Jazz",            // 29
        "Live",            // 30
        "Loudness",        // 31
        "Lounge",          // 32
        "Metal",           // 33
        "Midnight",        // 34
        "Opera",           // 35
        "Orchestral",      // 36
        "Outdoor",         // 37
        "Party",           // 38
        "Podcast",         // 39
        "Pop",             // 40
        "Psychedelic",     // 41
        "Reference",       // 42
        "Reggae",          // 43
        "Rock",            // 44
        "Ska",             // 45
        "Small Speakers",  // 46
        "Soft Rock",       // 47
        "Soul",            // 48
        "Studio",          // 49
        "Symphony",        // 50
        "Techno",          // 51
        "Trance",          // 52
        "Treble Boost",    // 53
        "Treble Reducer",  // 54
        "Vocal Boost",     // 55
        "Voice",           // 56
        "Warm",            // 57
        "World",           // 58
        "Zero"             // 59
    };

    /**
     * Gain values for each preset, in millibels where 100 equals 1 dB.
     * Each inner array holds ten band gain values, indexed by band.
     */
    private static final int[][] PRESET_GAINS = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                                 // Custom (0)
        {300, 250, 200, 150, 100, 50, 0, -50, -100, -150},              // Acoustic (1)
        {450, 500, 500, 400, 300, 150, 100, 150, 250, 350},             // Afrobeat (2)
        {500, 550, 500, 450, 350, 250, 200, 250, 350, 400},             // Afropop (3)
        {300, 350, 400, 350, 300, 250, 200, 150, 200, 300},             // Alternative (4)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},             // Ambient (5)
        {600, 500, 300, 100, 0, 0, 0, 100, 300, 600},                   // Bass & Treble (6)
        {700, 650, 500, 300, 150, 0, -100, -150, -200, -250},           // Bass Boost (7)
        {-250, -200, -150, -100, -50, 50, 150, 250, 350, 450},          // Bass Reducer (8)
        {300, 350, 350, 250, 200, 150, 100, 50, 100, 150},              // Blues (9)
        {500, 450, 350, 250, 150, 100, 100, 150, 200, 250},             // Car (10)
        {200, 250, 300, 350, 300, 250, 200, 150, 100, 50},              // Chill (11)
        {400, 350, 300, 250, 200, 150, 100, 50, 0, -50},                // Classical (12)
        {600, 650, 650, 450, 250, 0, -50, -50, 100, 200},               // Club (13)
        {250, 300, 350, 400, 350, 300, 200, 150, 100, 50},              // Country (14)
        {500, 550, 550, 400, 200, 0, 100, 250, 400, 500},               // Dance (15)
        {800, 850, 700, 400, 150, -50, -150, -200, -300, -350},         // Deep (16)
        {500, 550, 600, 500, 350, 200, 150, 100, 50, 0},                // Disco (17)
        {650, 650, 500, 250, 100, -50, -100, -50, 150, 200},            // Drum & Bass (18)
        {700, 750, 550, 200, -100, -250, -150, 50, 200, 300},           // Dubstep (19)
        {650, 700, 650, 450, 200, 0, 50, 150, 350, 450},                // Electronic (20)
        {150, 200, 300, 400, 450, 400, 300, 200, 150, 100},             // Folk (21)
        {200, 250, 350, 450, 550, 500, 400, 300, 200, 150},             // Gospel (22)
        {450, 500, 400, 200, -75, -100, 0, 150, 300, 400},              // Grunge (23)
        {400, 450, 500, 450, 300, 200, 200, 250, 350, 400},             // Hard Rock (24)
        {200, 150, 100, 0, -100, -100, -50, 0, 150, 250},               // Headphones (25)
        {600, 650, 550, 300, 100, -50, -100, 0, 150, 250},              // Hip Hop (26)
        {600, 650, 600, 450, 250, 50, 0, 50, 150, 300},                 // House (27)
        {200, 250, 300, 400, 400, 350, 300, 250, 200, 150},             // Indie (28)
        {200, 250, 300, 350, 400, 350, 300, 250, 200, 150},             // Jazz (29)
        {100, 150, 250, 400, 500, 450, 350, 250, 150, 100},             // Live (30)
        {500, 450, 300, 100, -100, -150, -100, 100, 350, 450},          // Loudness (31)
        {150, 200, 250, 300, 350, 300, 250, 200, 150, 100},             // Lounge (32)
        {400, 450, 300, 100, -150, -200, -100, 150, 400, 500},          // Metal (33)
        {200, 250, 300, 250, 150, 50, -50, -100, -150, -200},           // Midnight (34)
        {250, 300, 350, 350, 300, 250, 200, 150, 100, 50},              // Opera (35)
        {300, 350, 400, 400, 350, 300, 250, 200, 150, 100},             // Orchestral (36)
        {300, 350, 400, 350, 300, 300, 350, 400, 450, 500},             // Outdoor (37)
        {550, 600, 550, 350, 100, -100, -50, 150, 400, 550},            // Party (38)
        {-200, -100, 100, 400, 600, 700, 600, 400, 200, 0},             // Podcast (39)
        {250, 300, 350, 400, 450, 450, 400, 350, 300, 250},             // Pop (40)
        {300, 350, 400, 350, 300, 200, 150, 200, 300, 400},             // Psychedelic (41)
        {50, 75, 100, 125, 150, 175, 200, 225, 250, 275},               // Reference (42)
        {450, 500, 450, 350, 250, 150, 100, 50, 0, -50},                // Reggae (43)
        {350, 400, 450, 500, 450, 350, 250, 200, 250, 300},             // Rock (44)
        {350, 400, 450, 400, 350, 300, 250, 200, 150, 150},             // Ska (45)
        {400, 350, 300, 200, 100, 100, 150, 200, 300, 400},             // Small Speakers (46)
        {200, 250, 300, 400, 350, 250, 150, 100, 50, 25},               // Soft Rock (47)
        {400, 450, 400, 300, 200, 150, 100, 50, 100, 150},              // Soul (48)
        {50, 100, 150, 200, 250, 300, 350, 400, 450, 500},              // Studio (49)
        {400, 450, 500, 450, 400, 350, 300, 250, 200, 150},             // Symphony (50)
        {650, 600, 500, 350, 150, -50, -100, 0, 200, 400},              // Techno (51)
        {550, 600, 550, 400, 200, 50, 100, 250, 400, 500},              // Trance (52)
        {-300, -250, -200, -150, 0, 150, 300, 500, 700, 800},           // Treble Boost (53)
        {50, 100, 150, 200, 150, 100, 50, 0, -100, -200},               // Treble Reducer (54)
        {-200, -150, 200, 400, 500, 600, 500, 400, 200, -100},          // Vocal Boost (55)
        {-400, -300, 0, 400, 600, 700, 600, 400, 0, -300},              // Voice (56)
        {400, 350, 250, 150, 100, 50, 25, 0, -25, -50},                 // Warm (57)
        {200, 300, 350, 400, 400, 350, 300, 200, 150, 100},             // World (58)
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}                                  // Zero (59)
    };

    // ========================================================================
    // Static Members
    // ========================================================================

    /** Singleton instance. */
    private static EqualizerManager sInstance;

    // ========================================================================
    // Audio Effect Objects
    // ========================================================================

    /** Equalizer effect instance, or null before attach. */
    private Equalizer mEqualizer;

    /** Bass boost effect instance, or null before attach or when unsupported. */
    private BassBoost mBassBoost;

    /** Surround effect instance, or null before attach or when unsupported. */
    private Virtualizer mSurround;

    /** Current audio session identifier, or -1 when not attached. */
    private int mCurrentAudioSessionId = -1;

    /** Currently selected preset index. */
    private int mCurrentPreset = 0;

    // ========================================================================
    // Equalizer Band Data
    // ========================================================================

    /** Number of equalizer bands reported by the device. */
    private short mNumberOfBands = 0;

    /** Minimum and maximum band level range, or null before attach. */
    @Nullable
    private short[] mBandLevelRange;

    /** Current band levels, or null before attach. */
    @Nullable
    private int[] mCurrentBandLevels;

    /** Center frequencies for each band, or null before attach. */
    @Nullable
    private int[] mCenterFrequencies;

    /** Custom band levels saved while the custom preset is selected. */
    @Nullable
    private int[] mCustomBandLevels;

    /** Custom bass boost value. */
    private int mCustomBassBoost = 0;

    /** Custom surround value. */
    private int mCustomSurround = 0;

    /** Custom pitch value. */
    private int mCustomPitch = DEFAULT_PITCH_SPEED;

    /** Custom speed value. */
    private int mCustomSpeed = DEFAULT_PITCH_SPEED;

    // ========================================================================
    // Context and Listener
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** Registered equalizer event listener, or null. */
    @Nullable
    private volatile EqualizerListener mListener;

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Receives equalizer state changes.
     *
     * <p>Implement this interface to be notified when band levels, the
     * preset, or the ready state change. Every method is called on the
     * thread that performed the change.</p>
     */
    public interface EqualizerListener {

        /**
         * Called when the equalizer band levels change.
         *
         * @param levels Array of the new band level values
         */
        void onBandLevelsChanged(@NonNull int[] levels);

        /**
         * Called when the preset changes.
         *
         * @param preset The new preset index
         * @param presetName The name of the new preset
         */
        void onPresetChanged(int preset, @NonNull String presetName);

        /**
         * Called when the equalizer becomes ready or stops being ready.
         *
         * @param ready True when the equalizer is ready for use
         */
        void onEqualizerReady(boolean ready);
    }

    // ========================================================================
    // Constructor and Singleton
    // ========================================================================

    /**
     * Constructs the manager and reads the persisted preset index.
     *
     * @param context A context; the application context is retained
     */
    private EqualizerManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadSettings();
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static synchronized EqualizerManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new EqualizerManager(context);
        }
        return sInstance;
    }

    // ========================================================================
    // Listener Management
    // ========================================================================

    /**
     * Sets the listener that receives equalizer events.
     *
     * @param listener The listener, or null to remove the current listener
     */
    public synchronized void setListener(@Nullable EqualizerListener listener) {
        mListener = listener;
    }

    // ========================================================================
    // Settings Loading and Saving
    // ========================================================================

    /**
     * Reads the persisted preset index into memory.
     */
    private void loadSettings() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentPreset = preferences.getInt(KEY_SELECTED_PRESET, 0);
    }

    /**
     * Writes the current band levels to SharedPreferences.
     */
    private void saveCurrentBandLevels() {
        if (mCurrentBandLevels == null) {
            return;
        }

        SharedPreferences.Editor editor = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short bandIndex = 0; bandIndex < mCurrentBandLevels.length; bandIndex++) {
            editor.putInt(KEY_BAND_PREFIX + bandIndex, mCurrentBandLevels[bandIndex]);
        }
        editor.apply();
    }

    /**
     * Persists the given preset index and updates the in-memory value.
     *
     * @param preset The preset index to persist
     */
    private void savePreset(int preset) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SELECTED_PRESET, preset)
            .apply();
        mCurrentPreset = preset;
    }

    // ========================================================================
    // State Query Methods
    // ========================================================================

    /**
     * Returns whether the equalizer is attached to an audio session.
     *
     * @return True when an equalizer is bound to a live audio session
     */
    public boolean isAttached() {
        return mEqualizer != null && mCurrentAudioSessionId > 0;
    }

    /**
     * Returns whether the equalizer is attached and enabled.
     *
     * @return True when the equalizer can be used
     */
    public boolean isOperational() {
        return isAttached() && isEnabled();
    }

    /**
     * Returns whether the equalizer is enabled.
     *
     * @return True when the equalizer is enabled
     */
    public boolean isEnabled() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_EQUALIZER_ENABLED, false);
    }

    /**
     * Enables or disables the equalizer.
     *
     * <p>The new state is persisted and applied to the underlying effect
     * object when one is attached.</p>
     *
     * @param enabled True to enable, false to disable
     */
    public void setEnabled(boolean enabled) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, enabled)
            .apply();

        if (mEqualizer != null && isAttached()) {
            try {
                mEqualizer.setEnabled(enabled);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set enabled", exception);
            }
        }
    }

    // ========================================================================
    // Audio Session Management
    // ========================================================================

    /**
     * Attaches the equalizer, bass boost, and surround effects to the
     * given audio session and restores the persisted settings.
     *
     * <p>When a different session was already attached, the previous
     * effects are released before the new ones are created. When the same
     * session is already attached, only the preset is reapplied.</p>
     *
     * <p>On failure to create any effect object, the method releases
     * every resource it acquired and reports the not-ready state through
     * the listener.</p>
     *
     * @param audioSessionId The audio session identifier to attach to
     */
    public void attachToAudioSession(int audioSessionId) {
        try {
            if (audioSessionId <= 0) {
                Log.w(TAG, "attachToAudioSession: invalid session ID " + audioSessionId);
                notifyListenerReady(false);
                return;
            }

            if (mCurrentAudioSessionId == audioSessionId && mEqualizer != null) {
                Log.d(TAG, "Already attached to session " + audioSessionId);
                notifyListenerReady(true);
                applyPreset(mCurrentPreset);
                return;
            }

            release();
            mCurrentAudioSessionId = audioSessionId;

            try {
                mEqualizer = new Equalizer(0, audioSessionId);
                mEqualizer.setEnabled(isEnabled());
            } catch (Exception exception) {
                Log.e(TAG, "Failed to create Equalizer for session " + audioSessionId,
                    exception);
                release();
                notifyListenerReady(false);
                return;
            }

            mNumberOfBands = mEqualizer.getNumberOfBands();
            mBandLevelRange = mEqualizer.getBandLevelRange();
            mCenterFrequencies = new int[mNumberOfBands];
            mCurrentBandLevels = new int[mNumberOfBands];

            for (short bandIndex = 0; bandIndex < mNumberOfBands; bandIndex++) {
                mCenterFrequencies[bandIndex] = mEqualizer.getCenterFreq(bandIndex);
                if (mCenterFrequencies[bandIndex] == 0) {
                    mCenterFrequencies[bandIndex] =
                        (int) (20 * Math.pow(2, bandIndex * 0.5));
                }
            }

            SharedPreferences preferences = mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);
            for (short bandIndex = 0; bandIndex < mNumberOfBands; bandIndex++) {
                int savedLevel = preferences.getInt(KEY_BAND_PREFIX + bandIndex, 0);
                savedLevel = Math.max(mBandLevelRange[0],
                    Math.min(mBandLevelRange[1], savedLevel));
                mCurrentBandLevels[bandIndex] = savedLevel;
                mEqualizer.setBandLevel(bandIndex, (short) savedLevel);
            }

            restoreCustomBandLevels();
            restoreCustomBoosters();

            try {
                mBassBoost = new BassBoost(0, audioSessionId);
                mBassBoost.setEnabled(true);
                int bassLevel = preferences.getInt(KEY_BASS_BOOST, 0);
                short maxStrength = mBassBoost.getStrengthSupported()
                    ? (short) MAX_BOOST_STRENGTH : 0;
                mBassBoost.setStrength((short) Math.min(bassLevel, maxStrength));
            } catch (Exception exception) {
                Log.e(TAG, "Failed to create BassBoost", exception);
                mBassBoost = null;
            }

            try {
                mSurround = new Virtualizer(0, audioSessionId);
                mSurround.setEnabled(true);
                int surroundLevel = preferences.getInt(KEY_SURROUND, 0);
                short maxStrength = mSurround.getStrengthSupported()
                    ? (short) MAX_BOOST_STRENGTH : 0;
                mSurround.setStrength((short) Math.min(surroundLevel, maxStrength));
            } catch (Exception exception) {
                Log.e(TAG, "Failed to create Surround", exception);
                mSurround = null;
            }

            applyPreset(mCurrentPreset);

            notifyListenerReady(true);
            notifyBandLevelsChanged(mCurrentBandLevels);
            notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));

        } catch (Exception exception) {
            Log.e(TAG, "Failed to attach equalizer", exception);
            release();
            notifyListenerReady(false);
        }
    }

    /**
     * Detaches the equalizer from the current audio session.
     */
    public void detach() {
        mCurrentAudioSessionId = -1;
    }

    /**
     * Releases every audio effect resource held by this manager.
     *
     * <p>When the current preset is Custom, the current values are saved
     * as the custom snapshot before the effects are torn down. Band level
     * arrays are preserved so the UI can display the last known values
     * when no session is available.</p>
     */
    public void release() {
        if (mCurrentPreset == 0 && mCurrentBandLevels != null) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }

        if (mEqualizer != null) {
            try {
                saveCurrentBandLevels();
                mEqualizer.release();
            } catch (Exception exception) {
                Log.e(TAG, "Error releasing equalizer", exception);
            }
            mEqualizer = null;
        }

        if (mBassBoost != null) {
            try {
                mBassBoost.release();
            } catch (Exception exception) {
                Log.e(TAG, "Error releasing bass boost", exception);
            }
            mBassBoost = null;
        }

        if (mSurround != null) {
            try {
                mSurround.release();
            } catch (Exception exception) {
                Log.e(TAG, "Error releasing surround", exception);
            }
            mSurround = null;
        }

        mNumberOfBands = 0;
        mBandLevelRange = null;
        mCenterFrequencies = null;
        mCurrentAudioSessionId = -1;
    }

    // ========================================================================
    // Listener Notification Methods
    // ========================================================================

    /**
     * Notifies the listener of the current ready state.
     *
     * @param ready True when the equalizer is ready for use
     */
    private void notifyListenerReady(boolean ready) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onEqualizerReady(ready);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying listener ready", exception);
            }
        }
    }

    /**
     * Notifies the listener of the current band level values.
     *
     * @param levels The band level array, or null
     */
    private void notifyBandLevelsChanged(@Nullable int[] levels) {
        EqualizerListener listener = mListener;
        if (listener != null && levels != null) {
            try {
                listener.onBandLevelsChanged(levels);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying band levels changed", exception);
            }
        }
    }

    /**
     * Notifies the listener of a preset change.
     *
     * @param preset The new preset index
     * @param presetName The name of the new preset
     */
    private void notifyPresetChanged(int preset, @NonNull String presetName) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPresetChanged(preset, presetName);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying preset changed", exception);
            }
        }
    }

    // ========================================================================
    // Equalizer Band Methods
    // ========================================================================

    /**
     * Returns the number of equalizer bands reported by the device.
     *
     * @return The number of bands
     */
    public short getNumberOfBands() {
        return mNumberOfBands;
    }

    /**
     * Returns the minimum band level in millibels.
     *
     * @return The minimum level, or -1500 when not attached
     */
    public short getMinBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[0] : -1500;
    }

    /**
     * Returns the maximum band level in millibels.
     *
     * @return The maximum level, or 1500 when not attached
     */
    public short getMaxBandLevel() {
        return mBandLevelRange != null ? mBandLevelRange[1] : 1500;
    }

    /**
     * Returns the center frequency of the given band in Hz.
     *
     * @param band The band index
     * @return The center frequency in Hz, or 0 when not attached or the
     *         index is out of range
     */
    public int getCenterFrequency(int band) {
        if (!isAttached() || mCenterFrequencies == null
                || band < 0 || band >= mCenterFrequencies.length) {
            return 0;
        }
        return mCenterFrequencies[band];
    }

    /**
     * Returns a human-readable label for the given frequency.
     *
     * @param frequency The frequency in Hz
     * @return The formatted label, such as {@code "1.2 kHz"} or
     *         {@code "200 Hz"}
     */
    @NonNull
    public String getFrequencyLabel(int frequency) {
        int frequencyHz = frequency / 1000;
        if (frequencyHz < 1000) {
            return frequencyHz + " Hz";
        }

        int kilohertz = frequencyHz / 1000;
        int remainder = (frequencyHz % 1000) / 100;

        if (remainder == 0) {
            return kilohertz + " kHz";
        } else {
            return kilohertz + "." + remainder + " kHz";
        }
    }

    /**
     * Sets the level of the given band.
     *
     * <p>The level is clamped to the device's band level range. When a
     * standard preset is selected, the first band-level change switches
     * the current preset back to Custom and notifies the listener.</p>
     *
     * @param band The band index
     * @param level The desired level in millibels
     */
    public void setBandLevel(int band, int level) {
        if (!isAttached() || mBandLevelRange == null || mCurrentBandLevels == null
                || band < 0 || band >= mNumberOfBands) {
            return;
        }

        short clamped = (short) Math.max(mBandLevelRange[0],
            Math.min(mBandLevelRange[1], level));

        try {
            mEqualizer.setBandLevel((short) band, clamped);
            mCurrentBandLevels[band] = clamped;

            if (mCurrentPreset == 0) {
                if (mCustomBandLevels != null && band < mCustomBandLevels.length) {
                    mCustomBandLevels[band] = clamped;
                }
                mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(KEY_CUSTOM_BAND_PREFIX + band, clamped)
                    .apply();
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BAND_PREFIX + band, clamped)
                .apply();

            if (mCurrentPreset != 0) {
                mCurrentPreset = 0;
                savePreset(0);
                backupCustomBandLevels();
                backupCustomBoosters();
                backupCustomPitch();
                backupCustomSpeed();
                notifyPresetChanged(0, "Custom");
            }

            notifyBandLevelsChanged(mCurrentBandLevels);

        } catch (Exception exception) {
            Log.e(TAG, "Failed to set band level", exception);
        }
    }

    /**
     * Returns the level of the given band in millibels.
     *
     * @param band The band index
     * @return The level in millibels, or 0 when not attached or the
     *         index is out of range
     */
    public int getBandLevel(int band) {
        if (!isAttached() || mCurrentBandLevels == null
                || band < 0 || band >= mNumberOfBands) {
            return 0;
        }
        return mCurrentBandLevels[band];
    }

    /**
     * Returns a copy of the current band levels.
     *
     * @return A copy of the band level array, or an empty array when not
     *         attached
     */
    @NonNull
    public int[] getAllBandLevels() {
        return mCurrentBandLevels != null ? mCurrentBandLevels.clone() : new int[0];
    }

    // ========================================================================
    // Preset Methods
    // ========================================================================

    /**
     * Returns the name of the given preset index.
     *
     * @param preset The preset index
     * @return The preset name, or {@code "Custom"} when the index is out
     *         of range
     */
    @NonNull
    public String getPresetName(int preset) {
        return (preset >= 0 && preset < PRESET_NAMES.length)
            ? PRESET_NAMES[preset] : "Custom";
    }

    /**
     * Returns a copy of all preset names.
     *
     * @return A copy of the preset name array
     */
    @NonNull
    public String[] getPresetNames() {
        return PRESET_NAMES.clone();
    }

    /**
     * Returns the currently selected preset index.
     *
     * @return The current preset index
     */
    public int getCurrentPreset() {
        return mCurrentPreset;
    }

    /**
     * Applies the preset at the given index.
     *
     * <p>The Custom preset restores the previously saved custom values.
     * All other presets apply the gain values defined for that preset.</p>
     *
     * @param presetIndex The preset index to apply
     */
    public void applyPreset(int presetIndex) {
        if (mEqualizer == null) {
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }

        if (!isAttached()) {
            Log.w(TAG, "applyPreset called but equalizer not attached");
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }

        try {
            if (presetIndex == 0) {
                applyCustomPreset();
            } else if (presetIndex < PRESET_GAINS.length) {
                applyStandardPreset(presetIndex);
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to apply preset", exception);
        }
    }

    /**
     * Restores the saved custom settings as the active equalizer state.
     */
    private void applyCustomPreset() {
        boolean restored = false;

        if (mCustomBandLevels != null && mCustomBandLevels.length == mNumberOfBands) {
            for (short bandIndex = 0; bandIndex < mNumberOfBands; bandIndex++) {
                int level = Math.max(mBandLevelRange[0],
                    Math.min(mBandLevelRange[1], mCustomBandLevels[bandIndex]));
                mEqualizer.setBandLevel(bandIndex, (short) level);
                mCurrentBandLevels[bandIndex] = level;
            }
            restored = true;
        } else if (restoreCustomBandLevels()) {
            for (short bandIndex = 0; bandIndex < mNumberOfBands; bandIndex++) {
                int level = mCurrentBandLevels[bandIndex];
                mEqualizer.setBandLevel(bandIndex, (short) level);
            }
            restored = true;
        }

        if (!restored) {
            SharedPreferences preferences = mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);
            for (short bandIndex = 0; bandIndex < mNumberOfBands; bandIndex++) {
                int savedLevel = preferences.getInt(KEY_BAND_PREFIX + bandIndex, 0);
                savedLevel = Math.max(mBandLevelRange[0],
                    Math.min(mBandLevelRange[1], savedLevel));
                mEqualizer.setBandLevel(bandIndex, (short) savedLevel);
                mCurrentBandLevels[bandIndex] = savedLevel;
            }
        }

        restoreCustomBoosters();

        if (mBassBoost != null) {
            mBassBoost.setStrength((short) Math.min(mCustomBassBoost, MAX_BOOST_STRENGTH));
        }
        if (mSurround != null) {
            mSurround.setStrength((short) Math.min(mCustomSurround, MAX_BOOST_STRENGTH));
        }

        mCurrentPreset = 0;
        saveCurrentBandLevels();
        savePreset(0);

        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(0, "Custom");
    }

    /**
     * Applies the gain values of the given standard preset.
     *
     * <p>When the current preset is Custom, the current values are saved
     * as the custom snapshot before the standard preset is applied.</p>
     *
     * @param presetIndex The preset index to apply
     */
    private void applyStandardPreset(int presetIndex) {
        if (mCurrentPreset == 0) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }

        int[] gains = PRESET_GAINS[presetIndex];
        for (short bandIndex = 0;
                bandIndex < Math.min(mNumberOfBands, gains.length);
                bandIndex++) {
            short clamped = (short) Math.max(mBandLevelRange[0],
                Math.min(mBandLevelRange[1], gains[bandIndex]));
            mEqualizer.setBandLevel(bandIndex, clamped);
            mCurrentBandLevels[bandIndex] = clamped;
        }

        mCurrentPreset = presetIndex;
        saveCurrentBandLevels();
        savePreset(mCurrentPreset);

        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));
    }

    // ========================================================================
    // Custom Settings Backup and Restore
    // ========================================================================

    /**
     * Saves the current band levels as the custom snapshot.
     */
    private void backupCustomBandLevels() {
        if (mCurrentBandLevels == null) {
            return;
        }

        SharedPreferences.Editor editor = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short bandIndex = 0; bandIndex < mCurrentBandLevels.length; bandIndex++) {
            editor.putInt(KEY_CUSTOM_BAND_PREFIX + bandIndex, mCurrentBandLevels[bandIndex]);
        }
        editor.putBoolean(KEY_HAS_CUSTOM_BAND, true);
        editor.apply();

        mCustomBandLevels = mCurrentBandLevels.clone();
    }

    /**
     * Saves the current bass boost, surround, pitch, and speed values as
     * the custom snapshot.
     */
    private void backupCustomBoosters() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomBassBoost = getBassBoost();
        mCustomSurround = getSurround();
        editor.putInt(KEY_CUSTOM_BASS_BOOST, mCustomBassBoost);
        editor.putInt(KEY_CUSTOM_SURROUND, mCustomSurround);
        editor.putBoolean(KEY_HAS_CUSTOM_BOOSTERS, true);
        editor.apply();

        backupCustomPitch();
        backupCustomSpeed();
    }

    /**
     * Saves the current pitch value as the custom snapshot.
     */
    private void backupCustomPitch() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomPitch = getPitch();
        editor.putInt(KEY_CUSTOM_PITCH, mCustomPitch);
        editor.putBoolean(KEY_HAS_CUSTOM_PITCH, true);
        editor.apply();
    }

    /**
     * Saves the current speed value as the custom snapshot.
     */
    private void backupCustomSpeed() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomSpeed = getSpeed();
        editor.putInt(KEY_CUSTOM_SPEED, mCustomSpeed);
        editor.putBoolean(KEY_HAS_CUSTOM_SPEED, true);
        editor.apply();
    }

    /**
     * Reads the custom pitch value from SharedPreferences when one has
     * been saved.
     */
    private void restoreCustomPitch() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        if (preferences.getBoolean(KEY_HAS_CUSTOM_PITCH, false)) {
            mCustomPitch = preferences.getInt(KEY_CUSTOM_PITCH, DEFAULT_PITCH_SPEED);
        }
    }

    /**
     * Reads the custom speed value from SharedPreferences when one has
     * been saved.
     */
    private void restoreCustomSpeed() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        if (preferences.getBoolean(KEY_HAS_CUSTOM_SPEED, false)) {
            mCustomSpeed = preferences.getInt(KEY_CUSTOM_SPEED, DEFAULT_PITCH_SPEED);
        }
    }

    /**
     * Reads the custom band levels from SharedPreferences into the
     * current band level array.
     *
     * @return True when every band's custom value was restored
     */
    private boolean restoreCustomBandLevels() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        if (!preferences.getBoolean(KEY_HAS_CUSTOM_BAND, false)
                || mCurrentBandLevels == null) {
            return false;
        }

        boolean valid = true;
        for (short bandIndex = 0; bandIndex < mCurrentBandLevels.length; bandIndex++) {
            if (preferences.contains(KEY_CUSTOM_BAND_PREFIX + bandIndex)) {
                int savedLevel = preferences.getInt(
                    KEY_CUSTOM_BAND_PREFIX + bandIndex, 0);
                savedLevel = Math.max(mBandLevelRange[0],
                    Math.min(mBandLevelRange[1], savedLevel));
                mCurrentBandLevels[bandIndex] = savedLevel;
            } else {
                valid = false;
                break;
            }
        }

        if (valid) {
            mCustomBandLevels = mCurrentBandLevels.clone();
            return true;
        }

        return false;
    }

    /**
     * Reads the custom bass boost and surround values from
     * SharedPreferences.
     */
    private void restoreCustomBoosters() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        if (preferences.getBoolean(KEY_HAS_CUSTOM_BOOSTERS, false)) {
            mCustomBassBoost = preferences.getInt(KEY_CUSTOM_BASS_BOOST, 0);
            mCustomSurround = preferences.getInt(KEY_CUSTOM_SURROUND, 0);
        } else {
            mCustomBassBoost = 0;
            mCustomSurround = 0;
        }
    }

    /**
     * Clears every custom snapshot and resets the active band levels to
     * zero.
     */
    public void clearCustomBandLevels() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        if (mCurrentBandLevels != null) {
            for (short bandIndex = 0; bandIndex < mCurrentBandLevels.length; bandIndex++) {
                editor.remove(KEY_CUSTOM_BAND_PREFIX + bandIndex);
            }
        }

        editor.remove(KEY_HAS_CUSTOM_BAND);
        editor.remove(KEY_CUSTOM_BASS_BOOST);
        editor.remove(KEY_CUSTOM_SURROUND);
        editor.remove(KEY_HAS_CUSTOM_BOOSTERS);
        editor.remove(KEY_CUSTOM_PITCH);
        editor.remove(KEY_CUSTOM_SPEED);
        editor.remove(KEY_HAS_CUSTOM_PITCH);
        editor.remove(KEY_HAS_CUSTOM_SPEED);
        editor.apply();

        if (mCustomBandLevels != null) {
            for (int bandIndex = 0; bandIndex < mCustomBandLevels.length; bandIndex++) {
                mCustomBandLevels[bandIndex] = 0;
            }
        }

        mCustomBassBoost = 0;
        mCustomSurround = 0;
        mCustomPitch = DEFAULT_PITCH_SPEED;
        mCustomSpeed = DEFAULT_PITCH_SPEED;

        if (mCurrentBandLevels != null && isAttached()) {
            for (short bandIndex = 0; bandIndex < mCurrentBandLevels.length; bandIndex++) {
                mCurrentBandLevels[bandIndex] = 0;
                try {
                    mEqualizer.setBandLevel(bandIndex, (short) 0);
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to reset band level", exception);
                }
            }
            saveCurrentBandLevels();
        }
    }

    // ========================================================================
    // Bass Boost Methods
    // ========================================================================

    /**
     * Sets the bass boost strength.
     *
     * <p>The strength is clamped to the maximum the device supports. When
     * the Custom preset is selected, the value is also written to the
     * custom snapshot.</p>
     *
     * @param level The strength level
     */
    public void setBassBoost(int level) {
        if (mBassBoost == null || !isAttached()) {
            return;
        }

        try {
            short maxStrength = mBassBoost.getStrengthSupported()
                ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, maxStrength);
            short currentStrength = mBassBoost.getRoundedStrength();

            if (clamped != currentStrength) {
                boolean wasEnabled = mBassBoost.getEnabled();
                if (wasEnabled) {
                    mBassBoost.setEnabled(false);
                }
                mBassBoost.setStrength(clamped);
                if (wasEnabled) {
                    mBassBoost.setEnabled(true);
                }
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BASS_BOOST, clamped)
                .apply();

            if (mCurrentPreset == 0) {
                mCustomBassBoost = clamped;
                backupCustomBoosters();
            }
        } catch (Exception exception) {
            Log.e(TAG, "setBassBoost error", exception);
        }
    }

    /**
     * Returns the current bass boost strength.
     *
     * @return The bass boost strength
     */
    public int getBassBoost() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BASS_BOOST, 0);
    }

    /**
     * Returns whether the device supports bass boost.
     *
     * @return True when bass boost is supported and attached
     */
    public boolean isBassBoostSupported() {
        return mBassBoost != null && mBassBoost.getStrengthSupported() && isAttached();
    }

    /**
     * Sets the bass boost strength on the underlying effect object
     * without persisting the value.
     *
     * @param strength The strength value
     */
    public void setBassBoostStrength(short strength) {
        if (mBassBoost != null) {
            try {
                mBassBoost.setStrength(strength);
                mBassBoost.setEnabled(strength > 0);
            } catch (Exception exception) {
                Log.e(TAG, "setBassBoostStrength error", exception);
            }
        }
    }

    /**
     * Returns the bass boost strength the effect object is currently
     * applying.
     *
     * @return The rounded strength, or 0 when no bass boost is attached
     */
    public short getBassBoostStrength() {
        if (mBassBoost == null) {
            return 0;
        }
        return mBassBoost.getRoundedStrength();
    }

    // ========================================================================
    // Surround Methods
    // ========================================================================

    /**
     * Sets the surround effect strength.
     *
     * <p>The strength is clamped to the maximum the device supports. When
     * the Custom preset is selected, the value is also written to the
     * custom snapshot.</p>
     *
     * @param level The strength level
     */
    public void setSurround(int level) {
        if (mSurround == null || !isAttached()) {
            return;
        }

        try {
            short maxStrength = mSurround.getStrengthSupported()
                ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, maxStrength);
            short currentStrength = mSurround.getRoundedStrength();

            if (clamped != currentStrength) {
                boolean wasEnabled = mSurround.getEnabled();
                if (wasEnabled) {
                    mSurround.setEnabled(false);
                }
                mSurround.setStrength(clamped);
                if (wasEnabled) {
                    mSurround.setEnabled(true);
                }
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_SURROUND, clamped)
                .apply();

            if (mCurrentPreset == 0) {
                mCustomSurround = clamped;
                backupCustomBoosters();
            }
        } catch (Exception exception) {
            Log.e(TAG, "setSurround error", exception);
        }
    }

    /**
     * Returns the current surround effect strength.
     *
     * @return The surround strength
     */
    public int getSurround() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SURROUND, 0);
    }

    /**
     * Returns whether the device supports the surround effect.
     *
     * @return True when the surround effect is supported and attached
     */
    public boolean isSurroundSupported() {
        return mSurround != null && mSurround.getStrengthSupported() && isAttached();
    }

    /**
     * Sets the surround strength on the underlying effect object without
     * persisting the value.
     *
     * @param strength The strength value
     */
    public void setSurroundStrength(short strength) {
        if (mSurround != null) {
            try {
                mSurround.setStrength(strength);
                mSurround.setEnabled(strength > 0);
            } catch (Exception exception) {
                Log.e(TAG, "setSurroundStrength error", exception);
            }
        }
    }

    /**
     * Returns the surround strength the effect object is currently
     * applying.
     *
     * @return The rounded strength, or 0 when no surround effect is
     *         attached
     */
    public short getSurroundStrength() {
        if (mSurround == null) {
            return 0;
        }
        return mSurround.getRoundedStrength();
    }

    // ========================================================================
    // Pitch Methods
    // ========================================================================

    /**
     * Sets the pitch shift level.
     *
     * <p>Values near the neutral position collapse to the neutral
     * position. The value range is 0 to 2000, where 0 is the lowest
     * pitch, 1000 is normal pitch, and 2000 is the highest pitch.</p>
     *
     * @param level The pitch level
     */
    public void setPitch(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PITCH, smoothedLevel)
            .apply();

        if (mCurrentPreset == 0) {
            mCustomPitch = smoothedLevel;
            backupCustomPitch();
        }
    }

    /**
     * Returns the current pitch level.
     *
     * @return The pitch level
     */
    public int getPitch() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
    }

    /**
     * Returns the current pitch level.
     *
     * <p>Equivalent to {@link #getPitch()}.</p>
     *
     * @return The pitch level
     */
    public int getPitchLevel() {
        return getPitch();
    }

    /**
     * Returns whether pitch shifting is available on this device.
     *
     * @return True when pitch shifting is available
     */
    public boolean isPitchSupported() {
        return true;
    }

    /**
     * Returns the pitch shift in semitones.
     *
     * @return The pitch shift in semitones, in the range of
     *         approximately -6 to +6
     */
    public float getPitchSemitones() {
        int level = getPitch();
        if (level == DEFAULT_PITCH_SPEED) {
            return 0f;
        }
        float normalized = (level - DEFAULT_PITCH_SPEED) / 1000.0f;
        return normalized * 6.0f;
    }

    // ========================================================================
    // Speed Methods
    // ========================================================================

    /**
     * Sets the playback speed level.
     *
     * <p>Values near the neutral position collapse to the neutral
     * position. The value range is 0 to 2000, where the resulting speed
     * is {@code 0.5 + (level / 2000)}: 0 maps to 0.5x, 1000 maps to
     * 1.0x, and 2000 maps to 1.5x.</p>
     *
     * @param level The speed level
     */
    public void setSpeed(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        if (Math.abs(smoothedLevel - DEFAULT_PITCH_SPEED) <= 6) {
            smoothedLevel = DEFAULT_PITCH_SPEED;
        }

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SPEED, smoothedLevel)
            .apply();

        if (mCurrentPreset == 0) {
            mCustomSpeed = smoothedLevel;
            backupCustomSpeed();
        }
    }

    /**
     * Returns the current speed level.
     *
     * @return The speed level
     */
    public int getSpeed() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
    }
}