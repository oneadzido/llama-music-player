package com.ark.llama;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothHeadset;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.File;

/**
 * Handles Bluetooth headset and A2DP connection state changes.
 *
 * <p>Listens for headset and A2DP profile connection and disconnection
 * events. When either profile connects and there is prior playback state
 * to resume, starts {@link MusicService} with an explicit
 * {@code ACTION_BLUETOOTH_RESUME} action. When either profile
 * disconnects, pauses playback to save battery.</p>
 *
 * <p>The manifest declares both {@code
 * android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED} and
 * {@code android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED}.
 * The two broadcasts carry the same {@code EXTRA_STATE} extra with the
 * same {@code STATE_CONNECTED} and {@code STATE_DISCONNECTED} values, so
 * a single dispatch handles both. The A2DP profile matters because a
 * headset that loses only A2DP while remaining paired has moved the
 * user's audio elsewhere.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All operations run on the main thread and are thread-safe.</p>
 *
 * @see MusicService
 * @see BroadcastReceiver
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class BluetoothReceiver extends BroadcastReceiver {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "BluetoothReceiver";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action for broadcasting Bluetooth connection state. */
    private static final String ACTION_BLUETOOTH_CONNECTED = "BLUETOOTH_CONNECTED";

    /** Intent action for requesting playback to start. */
    private static final String ACTION_BLUETOOTH_PLAY = "BLUETOOTH_PLAY";

    /** Intent action for requesting playback to pause. */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";

    /** Intent action for getting the current playing state. */
    private static final String ACTION_GET_PLAYING_STATE = "GET_PLAYING_STATE";

    /** Service action for resuming playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME";

    // ========================================================================
    // BroadcastReceiver Methods
    // ========================================================================

    /**
     * Handles Bluetooth headset and A2DP connection state change
     * broadcasts.
     *
     * <p>Dispatches on {@link BluetoothHeadset#ACTION_CONNECTION_STATE_CHANGED}
     * and {@link BluetoothA2dp#ACTION_CONNECTION_STATE_CHANGED}. Broadcasts
     * carrying a null action are logged and discarded.</p>
     *
     * @param context The Context in which the receiver is running
     * @param intent The Intent being received
     */
    @Override
    public void onReceive(@NonNull Context context, @NonNull Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            Log.w(TAG, "Received intent with null action");
            return;
        }

        if (BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)
                || BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
            handleConnectionStateChanged(context, intent);
        }
    }

    // ========================================================================
    // Connection State Handling
    // ========================================================================

    /**
     * Dispatches a connection state change to the connect or disconnect
     * handler.
     *
     * @param context The application context
     * @param intent The intent containing connection state extras
     */
    private void handleConnectionStateChanged(@NonNull Context context, @NonNull Intent intent) {
        int state = intent.getIntExtra(BluetoothHeadset.EXTRA_STATE,
            BluetoothHeadset.STATE_DISCONNECTED);

        switch (state) {
            case BluetoothHeadset.STATE_CONNECTED:
                Log.d(TAG, "Bluetooth profile connected");
                handleBluetoothConnect(context);
                break;

            case BluetoothHeadset.STATE_DISCONNECTED:
                Log.d(TAG, "Bluetooth profile disconnected");
                handleBluetoothDisconnect(context);
                break;

            default:
                Log.v(TAG, "Bluetooth state change ignored: " + state);
                break;
        }
    }

    /**
     * Handles a Bluetooth profile connection event.
     *
     * <p>Starts {@link MusicService} with {@code ACTION_BLUETOOTH_RESUME}
     * when there is a prior playback state and a valid last song path. A
     * connect with no prior playback state does not start the
     * service.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothConnect(@NonNull Context context) {
        broadcastBluetoothState(context, true);

        SharedPreferences preferences = context.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        boolean wasPlaying = preferences.getBoolean(KEY_LAST_PLAYING, false);
        String lastPath = preferences.getString(KEY_LAST_SONG_PATH, null);

        boolean hasSomethingToResume = wasPlaying
            && lastPath != null
            && new File(lastPath).exists();

        if (!hasSomethingToResume) {
            Log.d(TAG, "Connected, no prior playback to resume");
            return;
        }

        Log.d(TAG, "Resuming playback after Bluetooth connect");
        Intent resumeIntent = new Intent(context, MusicService.class);
        resumeIntent.setAction(ACTION_BLUETOOTH_RESUME);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(resumeIntent);
        } else {
            context.startService(resumeIntent);
        }
    }

    /**
     * Handles a Bluetooth profile disconnection event.
     *
     * <p>Pauses playback and broadcasts the connection state change. The
     * currently playing state is persisted by {@link MusicService} on
     * pause, so a subsequent connect can decide whether to resume.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothDisconnect(@NonNull Context context) {
        Intent getStateIntent = new Intent(ACTION_GET_PLAYING_STATE);
        context.sendBroadcast(getStateIntent);

        Intent pauseIntent = new Intent(ACTION_BLUETOOTH_PAUSE);
        context.sendBroadcast(pauseIntent);

        broadcastBluetoothState(context, false);
    }

    /**
     * Broadcasts the current Bluetooth connection state to other
     * components.
     *
     * @param context The application context
     * @param isConnected True if Bluetooth is connected, false otherwise
     */
    private void broadcastBluetoothState(@NonNull Context context, boolean isConnected) {
        Intent bluetoothIntent = new Intent(ACTION_BLUETOOTH_CONNECTED);
        bluetoothIntent.putExtra("connected", isConnected);
        context.sendBroadcast(bluetoothIntent);
    }
}