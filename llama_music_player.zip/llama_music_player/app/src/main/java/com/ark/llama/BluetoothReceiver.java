package com.ark.llama;

import android.bluetooth.BluetoothHeadset;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;

/**
 * BroadcastReceiver for handling Bluetooth headset connection state changes.
 * 
 * <p>This receiver listens exclusively for Bluetooth headset connection and
 * disconnection events. Media button events are not handled here; they are
 * routed by the system through {@code androidx.media.session.MediaButtonReceiver}
 * to the active {@code MediaSessionCompat} held by {@link MusicService}.</p>
 * 
 * <p>When a headset connects and there is prior playback state to resume,
 * the receiver starts {@link MusicService} with an explicit
 * {@code ACTION_BLUETOOTH_RESUME} action. When a headset disconnects, it
 * pauses playback to save battery.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>BroadcastReceiver callbacks run on the main thread. This class does not
 * create any background threads. All operations are
 * immediate and thread-safe.</p>
 * 
 * @see MusicService
 * @see BroadcastReceiver
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class BluetoothReceiver extends BroadcastReceiver {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "BluetoothReceiver";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Intent action for broadcasting Bluetooth connection state. */
    private static final String ACTION_BLUETOOTH_CONNECTED = "BLUETOOTH_CONNECTED";
    
    /** Intent action for requesting playback to start. */
    private static final String ACTION_BLUETOOTH_PLAY = "BLUETOOTH_PLAY";
    
    /** Intent action for requesting playback to pause. */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";
    
    /** Intent action for getting the current playing state. */
    private static final String ACTION_GET_PLAYING_STATE = "GET_PLAYING_STATE";
    
    /** Service action for resuming playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME";

    // ========================================================================
    // BroadcastReceiver Methods
    // ========================================================================
    
    /**
     * Called when a broadcast is received.
     * 
     * <p>Handles only {@link BluetoothHeadset#ACTION_CONNECTION_STATE_CHANGED}.
     * Media button events are routed by the system through
     * {@code androidx.media.session.MediaButtonReceiver} and do not reach
     * this receiver.</p>
     *
     * @param context The Context in which the receiver is running
     * @param intent The Intent being received
     */
    @Override
    public void onReceive(@NonNull Context context, @NonNull Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            Log.w(TAG, "Received intent with null action");
            return;
        }

        if (BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
            handleConnectionStateChanged(context, intent);
        }
    }

    // ========================================================================
    // Connection State Handling
    // ========================================================================
    
    /**
     * Handles Bluetooth headset connection state changes.
     * 
     * @param context The application context
     * @param intent The intent containing connection state extras
     */
    private void handleConnectionStateChanged(@NonNull Context context, @NonNull Intent intent) {
        int state = intent.getIntExtra(BluetoothHeadset.EXTRA_STATE, BluetoothHeadset.STATE_DISCONNECTED);
        
        switch (state) {
            case BluetoothHeadset.STATE_CONNECTED:
                Log.d(TAG, "Bluetooth headset connected");
                handleBluetoothConnect(context);
                break;
                
            case BluetoothHeadset.STATE_DISCONNECTED:
                Log.d(TAG, "Bluetooth headset disconnected");
                handleBluetoothDisconnect(context);
                break;
                
            default:
                Log.v(TAG, "Bluetooth state change ignored: " + state);
                break;
        }
    }

    /**
     * Handles Bluetooth headset connection event.
     * 
     * <p>Starts {@link MusicService} with {@code ACTION_BLUETOOTH_RESUME} only
     * when there is a prior playback state and a valid last song path. A
     * headset connect with no prior playback state does not start the
     * service and does not promote anything to foreground.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothConnect(@NonNull Context context) {
        broadcastBluetoothState(context, true);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean wasPlaying = prefs.getBoolean(KEY_LAST_PLAYING, false);
        String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        boolean hasSomethingToResume = wasPlaying
            && lastPath != null
            && new java.io.File(lastPath).exists();

        if (!hasSomethingToResume) {
            Log.d(TAG, "Headset connected, no prior playback to resume");
            return;
        }

        Log.d(TAG, "Resuming playback after Bluetooth connect");
        Intent resumeIntent = new Intent(context, MusicService.class);
        resumeIntent.setAction(ACTION_BLUETOOTH_RESUME);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(resumeIntent);
        } else {
            context.startService(resumeIntent);
        }
    }

    /**
     * Handles Bluetooth headset disconnection event.
     * 
     * <p>Pauses playback and broadcasts the connection state change. The
     * currently playing state is persisted by {@link MusicService} on pause,
     * so a subsequent connect can decide whether to resume.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothDisconnect(@NonNull Context context) {
        Intent getStateIntent = new Intent(ACTION_GET_PLAYING_STATE);
        context.sendBroadcast(getStateIntent);
        
        Intent pauseIntent = new Intent(ACTION_BLUETOOTH_PAUSE);
        context.sendBroadcast(pauseIntent);
        
        broadcastBluetoothState(context, false);
    }

    /**
     * Broadcasts the current Bluetooth connection state to other components.
     * 
     * @param context The application context
     * @param isConnected True if Bluetooth is connected, false otherwise
     */
    private void broadcastBluetoothState(@NonNull Context context, boolean isConnected) {
        Intent btIntent = new Intent(ACTION_BLUETOOTH_CONNECTED);
        btIntent.putExtra("connected", isConnected);
        context.sendBroadcast(btIntent);
    }
}