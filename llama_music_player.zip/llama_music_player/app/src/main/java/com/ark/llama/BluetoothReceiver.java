package com.ark.llama;

import android.bluetooth.BluetoothHeadset;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.view.KeyEvent;

/**
 * BroadcastReceiver for handling Bluetooth headset connections and media button events.
 * 
 * <p>This receiver listens for:
 * <ul>
 *   <li>Bluetooth headset connection/disconnection events</li>
 *   <li>Media button events (play/pause/next/previous) from Bluetooth devices</li>
 * </ul>
 * </p>
 * 
 * <p>When a Bluetooth headset connects, the receiver starts the MusicService and
 * optionally resumes playback if it was playing before disconnect. When disconnected,
 * it pauses playback to save battery.</p>
 * 
 * <p>Follows Google's recommendations for efficient broadcast receiver implementation
 * and proper lifecycle management.</p>
 * 
 * @see MusicService
 * @see BroadcastReceiver
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class BluetoothReceiver extends BroadcastReceiver {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "BluetoothReceiver";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Intent action for broadcasting Bluetooth connection state. */
    private static final String ACTION_BLUETOOTH_CONNECTED = "BLUETOOTH_CONNECTED";
    
    /** Intent action for requesting playback to start. */
    private static final String ACTION_BLUETOOTH_PLAY = "BLUETOOTH_PLAY";
    
    /** Intent action for requesting playback to pause. */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";
    
    /** Intent action for getting the current playing state. */
    private static final String ACTION_GET_PLAYING_STATE = "GET_PLAYING_STATE";
    
    /** Intent action for processing media button events. */
    private static final String ACTION_MEDIA_BUTTON_ACTION = "MEDIA_BUTTON_ACTION";

    // ========================================================================
    // BroadcastReceiver Methods
    // ========================================================================
    
    /**
     * Called when a broadcast is received.
     * 
     * <p>This method handles two types of intents:
     * <ul>
     *   <li>{@link BluetoothHeadset#ACTION_CONNECTION_STATE_CHANGED} - Bluetooth connection changes</li>
     *   <li>{@link Intent#ACTION_MEDIA_BUTTON} - Media button presses from Bluetooth devices</li>
     * </ul>
     * </p>
     *
     * @param context The Context in which the receiver is running
     * @param intent The Intent being received
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            Log.w(TAG, "Received intent with null action");
            return;
        }

        if (BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
            handleConnectionStateChanged(context, intent);
        } else if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
            handleMediaButtonIntent(context, intent);
        }
    }

    // ========================================================================
    // Connection State Handling
    // ========================================================================
    
    /**
     * Handles Bluetooth headset connection state changes.
     * 
     * @param context The application context
     * @param intent The intent containing connection state extras
     */
    private void handleConnectionStateChanged(Context context, Intent intent) {
        int state = intent.getIntExtra(BluetoothHeadset.EXTRA_STATE, BluetoothHeadset.STATE_DISCONNECTED);
        
        switch (state) {
            case BluetoothHeadset.STATE_CONNECTED:
                Log.d(TAG, "Bluetooth headset connected");
                handleBluetoothConnect(context);
                break;
                
            case BluetoothHeadset.STATE_DISCONNECTED:
                Log.d(TAG, "Bluetooth headset disconnected");
                handleBluetoothDisconnect(context);
                break;
                
            default:
                // Intermediate states (connecting, disconnecting) - no action needed
                break;
        }
    }

    /**
     * Handles Bluetooth headset connection event.
     * 
     * <p>Starts the music service and resumes playback if it was playing
     * before the disconnect.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothConnect(Context context) {
        startMusicService(context);
        broadcastBluetoothState(context, true);
        
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean wasPlaying = prefs.getBoolean(KEY_LAST_PLAYING, false);
        
        if (wasPlaying) {
            Log.d(TAG, "Resuming playback after Bluetooth connect");
            Intent playIntent = new Intent(ACTION_BLUETOOTH_PLAY);
            context.sendBroadcast(playIntent);
        }
    }

    /**
     * Handles Bluetooth headset disconnection event.
     * 
     * <p>Pauses playback and saves the current playing state for potential
     * resume on reconnection.</p>
     *
     * @param context The application context
     */
    private void handleBluetoothDisconnect(Context context) {
        // Save current playing state before pausing
        Intent getStateIntent = new Intent(ACTION_GET_PLAYING_STATE);
        context.sendBroadcast(getStateIntent);
        
        // Pause playback
        Intent pauseIntent = new Intent(ACTION_BLUETOOTH_PAUSE);
        context.sendBroadcast(pauseIntent);
        
        broadcastBluetoothState(context, false);
    }

    /**
     * Starts the MusicService, handling foreground service requirements for Android O and above.
     * 
     * <p>On Android 8.0 (API level 26) and higher, startForegroundService() must be used
     * to start a foreground service. The service must call startForeground() within 5 seconds.</p>
     *
     * @param context The application context
     */
    private void startMusicService(Context context) {
        Intent serviceIntent = new Intent(context, MusicService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }

    /**
     * Broadcasts the current Bluetooth connection state to other components.
     * 
     * @param context The application context
     * @param isConnected True if Bluetooth is connected, false otherwise
     */
    private void broadcastBluetoothState(Context context, boolean isConnected) {
        Intent btIntent = new Intent(ACTION_BLUETOOTH_CONNECTED);
        btIntent.putExtra("connected", isConnected);
        context.sendBroadcast(btIntent);
    }

    // ========================================================================
    // Media Button Handling
    // ========================================================================
    
    /**
     * Handles media button events from Bluetooth devices.
     * 
     * <p>Extracts the KeyEvent from the intent and processes it.</p>
     *
     * @param context The application context
     * @param intent The intent containing the KeyEvent
     */
    private void handleMediaButtonIntent(Context context, Intent intent) {
        KeyEvent event = null;
        
        // Use the appropriate method based on API level
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent.class);
        } else {
            event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
        }
        
        if (event != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            Log.d(TAG, "Media button received: keyCode=" + event.getKeyCode());
            processMediaButton(context, event.getKeyCode());
        }
    }

    /**
     * Processes a media button press by broadcasting it to the MusicService.
     * 
     * @param context The application context
     * @param keyCode The key code of the pressed button
     */
    private void processMediaButton(Context context, int keyCode) {
        Intent intent = new Intent(ACTION_MEDIA_BUTTON_ACTION);
        intent.putExtra("key_code", keyCode);
        context.sendBroadcast(intent);
    }
}