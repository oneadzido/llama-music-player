package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Manages music library operations including folder scanning, song caching, and playlist management.
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> for song list access</li>
 *   <li><b>AtomicBoolean</b> for loading state flags</li>
 *   <li><b>AtomicReference</b> for pending listener</li>
 *   <li><b>Copy-on-write</b> pattern for returning song lists</li>
 *   <li><b>ExecutorService</b> for background operations</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicLibrary {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicLibrary";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_FOLDERS = "selected_folders_uris";
    public static final String ACTION_PLAYLIST_LOAD_PROGRESS = "com.ark.llama.PLAYLIST_LOAD_PROGRESS";
    
    private static final int UI_UPDATE_THRESHOLD = 10;
    private static final long UI_UPDATE_TIME_MS = 500;
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    private final Context mContext;
    private final Set<String> mSelectedFolderUris;
    private final SongDatabase mSongDatabase;
    private final ExecutorService mExecutor;
    
    /** Read/write lock for song list access. */
    private final ReentrantReadWriteLock mSongsLock = new ReentrantReadWriteLock();
    
    /** List of all songs in the library (protected by mSongsLock). */
    private final ArrayList<Song> mAllSongs = new ArrayList<>();
    
    /** List of songs from previous load (for comparison). */
    private final ArrayList<Song> mOldSongs = new ArrayList<>();
    
    /** List of loose tracks (songs opened from other apps). */
    private final ArrayList<Song> mLooseSongs = new ArrayList<>();
    
    /** Flag indicating if a load operation is in progress. */
    private final AtomicBoolean mIsLoading = new AtomicBoolean(false);
    
    /** Pending listener waiting for async load to complete. */
    private final AtomicReference<OnSongsLoadedListener> mPendingListener = new AtomicReference<>();
    
    /** Flag indicating if the library is loaded. */
    private volatile boolean mIsLoaded = false;
    
    // ========================================================================
    // Listener Interfaces
    // ========================================================================
    
    public interface OnSongsLoadedListener {
        void onSongsLoaded(@NonNull ArrayList<Song> songs);
        void onLoadingError(@NonNull String error);
    }
    
    public interface UpdateProgressListener {
        void onProgress(int current, int total, @NonNull String message);
        void onComplete();
        void onError(@NonNull String error);
    }
    
    public interface LoadProgressListener {
        void onLoadProgress(int currentCount);
        void onLoadComplete(@NonNull ArrayList<Song> songs);
        void onLoadError(@NonNull String error);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    public MusicLibrary(@NonNull Context context) {
        mContext = context;
        CharacterMapper.init(context);
        mSelectedFolderUris = new HashSet<>();
        mSongDatabase = SongDatabase.getInstance(context);
        mExecutor = Executors.newSingleThreadExecutor();
        
        loadSavedFolders();
        loadSongsFromDatabaseSync();
        loadLooseSongs();
        mergeLooseSongs();
        
        if (!mAllSongs.isEmpty()) {
            mIsLoaded = true;
        }
        
        deleteOldCacheFile();
    }
    
    // ========================================================================
    // Initialization Helpers
    // ========================================================================
    
    private void deleteOldCacheFile() {
        try {
            File cacheFile = new File(mContext.getFilesDir(), "playlist_cache.ser");
            if (cacheFile.exists()) {
                cacheFile.delete();
            }
        } catch (SecurityException e) {
            Log.w(TAG, "Permission denied deleting cache file");
        }
    }
    
    private void loadSavedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> saved = prefs.getStringSet(KEY_FOLDERS, null);
        if (saved != null) {
            mSelectedFolderUris.addAll(saved);
        }
    }
    
    private void saveFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putStringSet(KEY_FOLDERS, mSelectedFolderUris).apply();
    }
    
    @WorkerThread
    private void loadSongsFromDatabaseSync() {
        ArrayList<Song> cached = mSongDatabase.getAllSongs();
        if (cached != null && !cached.isEmpty()) {
            mSongsLock.writeLock().lock();
            try {
                mAllSongs.clear();
                mAllSongs.addAll(cached);
            } finally {
                mSongsLock.writeLock().unlock();
            }
        }
    }
    
    private void loadLooseSongs() {
        ArrayList<Song> allLoose = mSongDatabase.getLooseSongs();
        ArrayList<Song> validLooseSongs = new ArrayList<>();
        
        for (Song song : allLoose) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validLooseSongs.add(song);
                } else {
                    mSongDatabase.removeLooseSong(song.getPath());
                }
            }
        }
        
        synchronized (mLooseSongs) {
            mLooseSongs.clear();
            mLooseSongs.addAll(validLooseSongs);
        }
    }
    
    private void mergeLooseSongs() {
        synchronized (mLooseSongs) {
            mSongsLock.writeLock().lock();
            try {
                for (Song loose : mLooseSongs) {
                    if (loose == null || loose.getPath() == null) continue;
                    
                    boolean alreadyExists = false;
                    for (Song existing : mAllSongs) {
                        if (existing != null && loose.getPath().equals(existing.getPath())) {
                            alreadyExists = true;
                            break;
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(loose);
                    }
                }
            } finally {
                mSongsLock.writeLock().unlock();
            }
        }
    }
    
    // ========================================================================
    // Public API - Folder Management (Thread-Safe)
    // ========================================================================
    
    @NonNull
    public Set<String> getSelectedFolders() {
        synchronized (mSelectedFolderUris) {
            return new HashSet<>(mSelectedFolderUris);
        }
    }
    
    public void addFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.add(uri);
        }
        saveFolders();
    }
    
    public void removeFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.remove(uri);
        }
        saveFolders();
    }
    
    public int getFolderCount() {
        synchronized (mSelectedFolderUris) {
            return mSelectedFolderUris.size();
        }
    }
    
    // ========================================================================
    // Public API - Song Management (Thread-Safe)
    // ========================================================================
    
    public void refreshSongs(@Nullable ArrayList<Song> newSongs) {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            if (newSongs != null) {
                mAllSongs.addAll(newSongs);
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        loadLooseSongs();
        mergeLooseSongs();
        mIsLoaded = true;
    }
    
    public void refreshCache() {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            ArrayList<Song> freshSongs = mSongDatabase.getAllSongs();
            if (freshSongs != null) {
                mAllSongs.addAll(freshSongs);
            }
            mergeLooseSongs();
            mIsLoaded = true;
        } finally {
            mSongsLock.writeLock().unlock();
        }
        Log.d(TAG, "Cache refreshed, now has " + getSongCount() + " songs");
    }
    
    public void removeMissingFiles(@Nullable ArrayList<Song> currentSongs) {
        if (currentSongs == null || currentSongs.isEmpty()) return;
        
        ArrayList<Song> validSongs = new ArrayList<>();
        for (Song song : currentSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validSongs.add(song);
                }
            }
        }
        
        if (validSongs.size() != currentSongs.size()) {
            mSongsLock.writeLock().lock();
            try {
                mAllSongs.clear();
                mAllSongs.addAll(validSongs);
            } finally {
                mSongsLock.writeLock().unlock();
            }
            mSongDatabase.clearCache();
            if (!validSongs.isEmpty()) {
                mSongDatabase.insertSongsBatch(validSongs);
            }
        }
    }
    
    @WorkerThread
    public void clearPlaylistCache() {
        mSongDatabase.clearCache();
    }
    
    @NonNull
    public ArrayList<Song> getAllSongs() {
        mSongsLock.readLock().lock();
        try {
            return new ArrayList<>(mAllSongs);
        } finally {
            mSongsLock.readLock().unlock();
        }
    }
    
    public int getSongCount() {
        mSongsLock.readLock().lock();
        try {
            return mAllSongs.size();
        } finally {
            mSongsLock.readLock().unlock();
        }
    }
    
    @NonNull
    public ArrayList<Song> searchSongs(@NonNull String query) {
        if (TextUtils.isEmpty(query)) {
            return getAllSongs();
        }
        
        ArrayList<Song> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase().trim();
        
        mSongsLock.readLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        results.add(song);
                    }
                }
            }
        } finally {
            mSongsLock.readLock().unlock();
        }
        
        return results;
    }
    
    public boolean updateSongGenre(@NonNull String songPath, @NonNull String genre) {
        mSongsLock.writeLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated in-memory genre for: " + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        synchronized (mLooseSongs) {
            for (Song song : mLooseSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    return true;
                }
            }
        }
        
        return false;
    }
    
    // ========================================================================
    // Public API - Old Song Management (for comparison)
    // ========================================================================
    
    public int getOldSongCount() {
        return mOldSongs.size();
    }
    
    @Nullable
    public Song getOldSongAt(int index) {
        return (index >= 0 && index < mOldSongs.size()) ? mOldSongs.get(index) : null;
    }
    
    // ========================================================================
    // Public API - Asynchronous Loading (Thread-Safe)
    // ========================================================================
    
    public void loadAllSongsAsync(@Nullable final OnSongsLoadedListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    listener.onSongsLoaded(getAllSongs());
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            mPendingListener.set(listener);
            return;
        }
        
        mIsLoading.set(true);
        mPendingListener.set(listener);
        
        final OnSongsLoadedListener capturedListener = listener;
        mExecutor.execute(() -> {
            try {
                loadAllSongsInternal();
                mIsLoaded = true;
                
                if (capturedListener != null) {
                    final ArrayList<Song> finalSongs = getAllSongs();
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                        capturedListener.onSongsLoaded(finalSongs);
                    });
                }
            } catch (final Exception e) {
                if (capturedListener != null) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                        capturedListener.onLoadingError(
                            e.getMessage() != null ? e.getMessage() : "Unknown error");
                    });
                }
            } finally {
                mIsLoading.set(false);
                if (mPendingListener.get() == capturedListener) {
                    mPendingListener.set(null);
                }
            }
        });
    }
    
    public void loadAllSongsWithProgress(@Nullable final LoadProgressListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    listener.onLoadComplete(getAllSongs());
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                loadAllSongsWithProgress(listener);
            }, 200);
            return;
        }
        
        mIsLoading.set(true);
        
        mExecutor.execute(() -> {
            try {
                final ArrayList<Song> newSongList = new ArrayList<>();
                
                if (mSelectedFolderUris.isEmpty()) {
                    loadLooseSongs();
                    synchronized (mLooseSongs) {
                        newSongList.addAll(mLooseSongs);
                    }
                    
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                        mSongsLock.writeLock().lock();
                        try {
                            mAllSongs.clear();
                            mAllSongs.addAll(newSongList);
                            mergeLooseSongs();
                        } finally {
                            mSongsLock.writeLock().unlock();
                        }
                        mIsLoaded = true;
                        if (listener != null) {
                            listener.onLoadComplete(newSongList);
                        }
                        mIsLoading.set(false);
                    });
                    return;
                }
                
                final AtomicInteger count = new AtomicInteger(0);
                for (String uriString : mSelectedFolderUris) {
                    scanFolderWithUriProgress(Uri.parse(uriString), newSongList, count, listener);
                }
                
                if (!newSongList.isEmpty()) {
                    Collections.sort(newSongList, (a, b) -> {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null && titleB == null) return 0;
                        if (titleA == null) return -1;
                        if (titleB == null) return 1;
                        return titleA.compareToIgnoreCase(titleB);
                    });
                }
                
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    mSongsLock.writeLock().lock();
                    try {
                        mAllSongs.clear();
                        mAllSongs.addAll(newSongList);
                        mergeLooseSongs();
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                    mIsLoaded = true;
                    if (listener != null) {
                        listener.onLoadComplete(newSongList);
                    }
                    mIsLoading.set(false);
                });
            } catch (final Exception e) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (listener != null) {
                        listener.onLoadError(e.getMessage() != null ? e.getMessage() : "Unknown error");
                    }
                    mIsLoading.set(false);
                });
            }
        });
    }
    
    // ========================================================================
    // Internal Methods (Thread-Safe)
    // ========================================================================
    
    private void loadAllSongsInternal() {
        mOldSongs.clear();
        mSongsLock.readLock().lock();
        try {
            mOldSongs.addAll(mAllSongs);
        } finally {
            mSongsLock.readLock().unlock();
        }
        
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        if (mSelectedFolderUris.isEmpty()) {
            loadLooseSongs();
            synchronized (mLooseSongs) {
                mSongsLock.writeLock().lock();
                try {
                    mAllSongs.addAll(mLooseSongs);
                } finally {
                    mSongsLock.writeLock().unlock();
                }
            }
            return;
        }
        
        for (String uriString : mSelectedFolderUris) {
            scanFolderWithUriOptimized(Uri.parse(uriString));
        }
        
        mSongsLock.writeLock().lock();
        try {
            if (!mAllSongs.isEmpty()) {
                Collections.sort(mAllSongs, (a, b) -> {
                    String titleA = a.getTitle();
                    String titleB = b.getTitle();
                    if (titleA == null && titleB == null) return 0;
                    if (titleA == null) return -1;
                    if (titleB == null) return 1;
                    return titleA.compareToIgnoreCase(titleB);
                });
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        mergeLooseSongs();
    }
    
    private void scanFolderWithUriOptimized(@NonNull Uri folderUri) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithCache(folderPath);
            } else {
                String name = getFolderNameFromUri(folderUri);
                if (name != null) {
                    queryMediaStoreByNameWithCache(name);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan optimized error", e);
        }
    }
    
    private void queryMediaStoreWithCache(@NonNull String folderPath) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    
                    mSongsLock.writeLock().lock();
                    try {
                        if (cached != null) {
                            mAllSongs.add(cached);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryWithCache error", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    private void queryMediaStoreByNameWithCache(@NonNull String folderName) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    
                    mSongsLock.writeLock().lock();
                    try {
                        if (cached != null) {
                            mAllSongs.add(cached);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryByNameWithCache error", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    private void scanFolderWithUriProgress(@NonNull Uri folderUri, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithProgress(folderPath, targetList, count, listener);
            } else {
                String name = getFolderNameFromUri(folderUri);
                if (name != null) {
                    queryMediaStoreByNameWithProgress(name, targetList, count, listener);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan progress error", e);
        }
    }
    
    private void queryMediaStoreWithProgress(@NonNull String folderPath, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReported = {0};
        final long[] lastTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int current = count.incrementAndGet();
                    
                    long now = SystemClock.elapsedRealtime();
                    if (listener != null && (current - lastReported[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReported[0] = current;
                        lastTime[0] = now;
                        mainHandler.post(() -> listener.onLoadProgress(current));
                        sendSongAddedBroadcast(finalSong, current);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = count.get();
                if (listener != null && finalCount > lastReported[0]) {
                    mainHandler.post(() -> listener.onLoadProgress(finalCount));
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryWithProgress error", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    private void queryMediaStoreByNameWithProgress(@NonNull String folderName, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReported = {0};
        final long[] lastTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int current = count.incrementAndGet();
                    
                    long now = SystemClock.elapsedRealtime();
                    if (listener != null && (current - lastReported[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReported[0] = current;
                        lastTime[0] = now;
                        mainHandler.post(() -> listener.onLoadProgress(current));
                        sendSongAddedBroadcast(finalSong, current);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = count.get();
                if (listener != null && finalCount > lastReported[0]) {
                    mainHandler.post(() -> listener.onLoadProgress(finalCount));
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryByNameWithProgress error", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    private void sendSongAddedBroadcast(@Nullable Song song, int currentCount) {
        Intent intent = new Intent(ACTION_PLAYLIST_LOAD_PROGRESS);
        
        if (song != null) {
            intent.putExtra("song_title", song.getTitle());
            intent.putExtra("song_artist", song.getArtist());
            intent.putExtra("song_album", song.getAlbum());
            intent.putExtra("song_genre", song.getGenre());
            intent.putExtra("song_path", song.getPath());
            intent.putExtra("song_duration", song.getDuration());
        }
        
        intent.putExtra("current_count", currentCount);
        mContext.sendBroadcast(intent);
    }
    
    public void shutdown() {
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int start = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(start);
                if (subPath.contains("%2F")) subPath = subPath.replace("%2F", "/");
                if (subPath.contains("/tree/")) subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                if (subPath.contains("/document/")) subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
                return path;
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
    
    @Nullable
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx != -1) name = cursor.getString(idx);
            }
        } catch (Exception e) {
            Log.e(TAG, "getFolderName error", e);
        } finally {
            if (cursor != null) cursor.close();
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) name = name.substring(name.indexOf(":") + 1);
        }
        
        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
}