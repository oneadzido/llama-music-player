package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Manages music library operations including folder scanning, song caching, and playlist management.
 * 
 * <p>This class is the core data management layer for Llama Music Player. It handles:</p>
 * <ul>
 *   <li>Loading and caching songs from selected folders</li>
 *   <li>Managing selected folder URIs with persistence</li>
 *   <li>Searching songs by title, artist, album, or genre</li>
 *   <li>Removing missing files and cleaning up stale data</li>
 *   <li>Supporting loose tracks (songs opened from other apps)</li>
 *   <li>Broadcasting progress during playlist loading</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> for song list access</li>
 *   <li><b>AtomicBoolean</b> for loading state flags</li>
 *   <li><b>AtomicReference</b> for pending listener</li>
 *   <li><b>Copy-on-write</b> pattern for returning song lists</li>
 *   <li><b>ExecutorService</b> for background operations</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The MusicLibrary acts as a bridge between the database (SongDatabase) and the UI.
 * It caches songs in memory for fast access, uses read-write locks for thread safety,
 * and provides both synchronous and asynchronous loading methods.</p>
 * 
 * @see SongDatabase
 * @see CharacterMapper
 * @see ReentrantReadWriteLock
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class MusicLibrary {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicLibrary";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing selected folder URIs in SharedPreferences. */
    private static final String KEY_FOLDERS = "selected_folders_uris";
    
    /** Broadcast action for playlist load progress updates. */
    public static final String ACTION_PLAYLIST_LOAD_PROGRESS = "com.ark.llama.PLAYLIST_LOAD_PROGRESS";
    
    /** Number of songs between progress updates for UI throttling. */
    private static final int UI_UPDATE_THRESHOLD = 10;
    
    /** Minimum time between progress updates in milliseconds (500ms). */
    private static final long UI_UPDATE_TIME_MS = 500;
    
    /** Timeout for executor service shutdown in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** Set of selected folder URIs (protected by synchronized on the set itself). */
    private final Set<String> mSelectedFolderUris;
    
    /** Database helper for persistent song cache. */
    private final SongDatabase mSongDatabase;
    
    /** Single-thread executor for background operations. */
    private final ExecutorService mExecutor;
    
    /** Read/write lock for song list access. */
    private final ReentrantReadWriteLock mSongsLock = new ReentrantReadWriteLock();
    
    /** List of all songs in the library (protected by mSongsLock). */
    private final ArrayList<Song> mAllSongs = new ArrayList<>();
    
    /** List of songs from previous load (for comparison during updates). */
    private final ArrayList<Song> mOldSongs = new ArrayList<>();
    
    /** List of loose tracks (songs opened from other apps). */
    private final ArrayList<Song> mLooseSongs = new ArrayList<>();
    
    /** Flag indicating if a load operation is in progress. */
    private final AtomicBoolean mIsLoading = new AtomicBoolean(false);
    
    /** Pending listener waiting for async load to complete. */
    private final AtomicReference<OnSongsLoadedListener> mPendingListener = new AtomicReference<>();
    
    /** Flag indicating if the library has been loaded at least once. */
    private volatile boolean mIsLoaded = false;
    
    // ========================================================================
    // Listener Interfaces
    // ========================================================================
    
    /**
     * Listener for asynchronous song loading operations.
     */
    public interface OnSongsLoadedListener {
        
        /**
         * Called when songs are successfully loaded.
         *
         * @param songs The loaded list of songs
         */
        void onSongsLoaded(@NonNull ArrayList<Song> songs);
        
        /**
         * Called when an error occurs during loading.
         *
         * @param error The error message
         */
        void onLoadingError(@NonNull String error);
    }
    
    /**
     * Listener for update operations with progress reporting.
     */
    public interface UpdateProgressListener {
        
        /**
         * Called periodically during update to report progress.
         *
         * @param current Current number of songs processed
         * @param total Total number of songs to process
         * @param message Progress message
         */
        void onProgress(int current, int total, @NonNull String message);
        
        /**
         * Called when the update completes successfully.
         */
        void onComplete();
        
        /**
         * Called when an error occurs during update.
         *
         * @param error The error message
         */
        void onError(@NonNull String error);
    }
    
    /**
     * Listener for load operations with progress reporting.
     */
    public interface LoadProgressListener {
        
        /**
         * Called periodically during loading to report progress.
         *
         * @param currentCount Current number of songs loaded
         */
        void onLoadProgress(int currentCount);
        
        /**
         * Called when loading completes successfully.
         *
         * @param songs The loaded list of songs
         */
        void onLoadComplete(@NonNull ArrayList<Song> songs);
        
        /**
         * Called when an error occurs during loading.
         *
         * @param error The error message
         */
        void onLoadError(@NonNull String error);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new MusicLibrary instance.
     * 
     * <p>Initializes the library by loading saved folder URIs, loading cached
     * songs from the database, loading loose tracks, and merging them into
     * the master song list. This constructor is lightweight and non-blocking.</p>
     *
     * @param context Application context
     */
    public MusicLibrary(@NonNull Context context) {
        mContext = context;
        CharacterMapper.init(context);
        mSelectedFolderUris = new HashSet<>();
        mSongDatabase = SongDatabase.getInstance(context);
        mExecutor = Executors.newSingleThreadExecutor();
        
        loadSavedFolders();
        loadSongsFromDatabaseSync();
        loadLooseSongs();
        mergeLooseSongs();
        
        if (!mAllSongs.isEmpty()) {
            mIsLoaded = true;
        }
        
        deleteLegacyCacheFile();
    }
    
    // ========================================================================
    // Initialization Helpers
    // ========================================================================
    
    /**
     * Deletes the legacy serialized cache file if it exists.
     * 
     * <p>This is a migration method. The file is no longer used and can be
     * safely removed.</p>
     */
    private void deleteLegacyCacheFile() {
        try {
            File cacheFile = new File(mContext.getFilesDir(), "playlist_cache.ser");
            if (cacheFile.exists()) {
                cacheFile.delete();
                Log.d(TAG, "Deleted legacy cache file");
            }
        } catch (SecurityException exception) {
            Log.w(TAG, "Permission denied deleting cache file");
        }
    }
    
    /**
     * Loads saved folder URIs from SharedPreferences.
     */
    private void loadSavedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = prefs.getStringSet(KEY_FOLDERS, null);
        if (savedFolders != null) {
            mSelectedFolderUris.addAll(savedFolders);
            Log.d(TAG, "Loaded " + savedFolders.size() + " saved folders");
        }
    }
    
    /**
     * Saves the current folder URIs to SharedPreferences.
     */
    private void saveFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putStringSet(KEY_FOLDERS, mSelectedFolderUris).apply();
        Log.d(TAG, "Saved " + mSelectedFolderUris.size() + " folders");
    }
    
    /**
     * Loads songs from the database synchronously.
     */
    @WorkerThread
    private void loadSongsFromDatabaseSync() {
        ArrayList<Song> cachedSongs = mSongDatabase.getAllSongs();
        if (cachedSongs != null && !cachedSongs.isEmpty()) {
            mSongsLock.writeLock().lock();
            try {
                mAllSongs.clear();
                mAllSongs.addAll(cachedSongs);
                Log.d(TAG, "Loaded " + cachedSongs.size() + " songs from database");
            } finally {
                mSongsLock.writeLock().unlock();
            }
        }
    }
    
    /**
     * Loads loose tracks from the database.
     */
    private void loadLooseSongs() {
        ArrayList<Song> allLooseSongs = mSongDatabase.getLooseSongs();
        ArrayList<Song> validLooseSongs = new ArrayList<>();
        
        for (Song song : allLooseSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validLooseSongs.add(song);
                } else {
                    mSongDatabase.removeLooseSong(song.getPath());
                    Log.d(TAG, "Removed missing loose song: " + song.getPath());
                }
            }
        }
        
        synchronized (mLooseSongs) {
            mLooseSongs.clear();
            mLooseSongs.addAll(validLooseSongs);
            Log.d(TAG, "Loaded " + validLooseSongs.size() + " valid loose songs");
        }
    }
    
    /**
     * Merges loose tracks into the main song list, avoiding duplicates.
     */
    private void mergeLooseSongs() {
        synchronized (mLooseSongs) {
            mSongsLock.writeLock().lock();
            try {
                int addedCount = 0;
                for (Song looseSong : mLooseSongs) {
                    if (looseSong == null || looseSong.getPath() == null) continue;
                    
                    boolean alreadyExists = false;
                    for (Song existingSong : mAllSongs) {
                        if (existingSong != null && looseSong.getPath().equals(existingSong.getPath())) {
                            alreadyExists = true;
                            break;
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(looseSong);
                        addedCount++;
                    }
                }
                if (addedCount > 0) {
                    Log.d(TAG, "Merged " + addedCount + " loose songs into main list");
                }
            } finally {
                mSongsLock.writeLock().unlock();
            }
        }
    }
    
    // ========================================================================
    // Public API - Folder Management (Thread-Safe)
    // ========================================================================
    
    /**
     * Returns a copy of the selected folder URIs set.
     *
     * @return A new HashSet containing all selected folder URIs
     */
    @NonNull
    public Set<String> getSelectedFolders() {
        synchronized (mSelectedFolderUris) {
            return new HashSet<>(mSelectedFolderUris);
        }
    }
    
    /**
     * Adds a folder URI to the selected folders set.
     *
     * @param uri The folder URI to add
     */
    public void addFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.add(uri);
            Log.d(TAG, "Added folder: " + uri);
        }
        saveFolders();
    }
    
    /**
     * Removes a folder URI from the selected folders set.
     *
     * @param uri The folder URI to remove
     */
    public void removeFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.remove(uri);
            Log.d(TAG, "Removed folder: " + uri);
        }
        saveFolders();
    }
    
    /**
     * Returns the number of selected folders.
     *
     * @return The folder count
     */
    public int getFolderCount() {
        synchronized (mSelectedFolderUris) {
            return mSelectedFolderUris.size();
        }
    }
    
    // ========================================================================
    // Public API - Song Management (Thread-Safe)
    // ========================================================================
    
    /**
     * Refreshes the in-memory song list with a new list.
     *
     * @param newSongs The new song list (can be null, treated as empty)
     */
    public void refreshSongs(@Nullable ArrayList<Song> newSongs) {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            if (newSongs != null) {
                mAllSongs.addAll(newSongs);
                Log.d(TAG, "Refreshed songs with " + newSongs.size() + " songs");
            } else {
                Log.d(TAG, "Refreshed songs with empty list");
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        loadLooseSongs();
        mergeLooseSongs();
        mIsLoaded = true;
    }
    
    /**
     * Refreshes the in-memory cache by reloading from the database.
     */
    public void refreshCache() {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            ArrayList<Song> freshSongs = mSongDatabase.getAllSongs();
            if (freshSongs != null) {
                mAllSongs.addAll(freshSongs);
                Log.d(TAG, "Cache refreshed, now has " + mAllSongs.size() + " songs");
            }
            mergeLooseSongs();
            mIsLoaded = true;
        } finally {
            mSongsLock.writeLock().unlock();
        }
        Log.d(TAG, "Cache refreshed, now has " + getSongCount() + " songs");
    }
    
    /**
     * Removes songs whose files no longer exist on disk.
     *
     * @param currentSongs The current song list to validate (can be null)
     */
    public void removeMissingFiles(@Nullable ArrayList<Song> currentSongs) {
        if (currentSongs == null || currentSongs.isEmpty()) {
            return;
        }
        
        ArrayList<Song> validSongs = new ArrayList<>();
        for (Song song : currentSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validSongs.add(song);
                } else {
                    Log.d(TAG, "Removing missing file: " + song.getPath());
                }
            }
        }
        
        if (validSongs.size() != currentSongs.size()) {
            mSongsLock.writeLock().lock();
            try {
                mAllSongs.clear();
                mAllSongs.addAll(validSongs);
                Log.d(TAG, "Removed " + (currentSongs.size() - validSongs.size()) + " missing files");
            } finally {
                mSongsLock.writeLock().unlock();
            }
            mSongDatabase.clearCache();
            if (!validSongs.isEmpty()) {
                mSongDatabase.insertSongsBatch(validSongs);
            }
        }
    }
    
    /**
     * Clears the entire playlist cache from the database.
     */
    @WorkerThread
    public void clearPlaylistCache() {
        mSongDatabase.clearCache();
        Log.d(TAG, "Cleared playlist cache");
    }
    
    /**
     * Returns a copy of all songs in the library.
     *
     * @return A new ArrayList containing all songs
     */
    @NonNull
    public ArrayList<Song> getAllSongs() {
        mSongsLock.readLock().lock();
        try {
            return new ArrayList<>(mAllSongs);
        } finally {
            mSongsLock.readLock().unlock();
        }
    }
    
    /**
     * Returns the total number of songs in the library.
     *
     * @return The song count
     */
    public int getSongCount() {
        mSongsLock.readLock().lock();
        try {
            return mAllSongs.size();
        } finally {
            mSongsLock.readLock().unlock();
        }
    }
    
    /**
     * Searches for songs matching the query string.
     *
     * @param query The search query (case-insensitive)
     * @return A list of songs matching the query
     */
    @NonNull
    public ArrayList<Song> searchSongs(@NonNull String query) {
        if (TextUtils.isEmpty(query)) {
            return getAllSongs();
        }
        
        ArrayList<Song> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase().trim();
        
        mSongsLock.readLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        results.add(song);
                    }
                }
            }
        } finally {
            mSongsLock.readLock().unlock();
        }
        
        Log.d(TAG, "Search for '" + query + "' returned " + results.size() + " results");
        return results;
    }
    
    /**
     * Updates the genre of a specific song in the in-memory cache.
     *
     * @param songPath The path of the song to update
     * @param genre The new genre value
     * @return True if the song was found and updated, false otherwise
     */
    public boolean updateSongGenre(@NonNull String songPath, @NonNull String genre) {
        mSongsLock.writeLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated in-memory genre for: " + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        synchronized (mLooseSongs) {
            for (Song song : mLooseSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated loose song genre for: " + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        }
        
        Log.w(TAG, "Song not found for genre update: " + songPath);
        return false;
    }
    
    // ========================================================================
    // Public API - Asynchronous Loading (Thread-Safe)
    // ========================================================================
    
    /**
     * Loads all songs asynchronously with a callback.
     *
     * @param listener The listener to receive the results (can be null)
     */
    public void loadAllSongsAsync(@Nullable final OnSongsLoadedListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onSongsLoaded(getAllSongs());
                    }
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            mPendingListener.set(listener);
            return;
        }
        
        mIsLoading.set(true);
        mPendingListener.set(listener);
        
        final OnSongsLoadedListener capturedListener = listener;
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    loadAllSongsInternal();
                    mIsLoaded = true;
                    
                    if (capturedListener != null) {
                        final ArrayList<Song> finalSongs = getAllSongs();
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onSongsLoaded(finalSongs);
                            }
                        });
                    }
                } catch (final Exception exception) {
                    Log.e(TAG, "Error loading songs", exception);
                    if (capturedListener != null) {
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onLoadingError(
                                    exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                            }
                        });
                    }
                } finally {
                    mIsLoading.set(false);
                    if (mPendingListener.get() == capturedListener) {
                        mPendingListener.set(null);
                    }
                }
            }
        });
    }
    
    /**
     * Loads all songs asynchronously with progress reporting.
     *
     * @param listener The listener to receive progress and results (can be null)
     */
    public void loadAllSongsWithProgress(@Nullable final LoadProgressListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onLoadComplete(getAllSongs());
                    }
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    loadAllSongsWithProgress(listener);
                }
            }, 200);
            return;
        }
        
        mIsLoading.set(true);
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final ArrayList<Song> newSongList = new ArrayList<>();
                    
                    if (mSelectedFolderUris.isEmpty()) {
                        loadLooseSongs();
                        synchronized (mLooseSongs) {
                            newSongList.addAll(mLooseSongs);
                        }
                        
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                mSongsLock.writeLock().lock();
                                try {
                                    mAllSongs.clear();
                                    mAllSongs.addAll(newSongList);
                                    mergeLooseSongs();
                                } finally {
                                    mSongsLock.writeLock().unlock();
                                }
                                mIsLoaded = true;
                                if (listener != null) {
                                    listener.onLoadComplete(newSongList);
                                }
                                mIsLoading.set(false);
                            }
                        });
                        return;
                    }
                    
                    final AtomicInteger currentCount = new AtomicInteger(0);
                    for (String folderUriString : mSelectedFolderUris) {
                        scanFolderWithUriProgress(Uri.parse(folderUriString), newSongList, currentCount, listener);
                    }
                    
                    if (!newSongList.isEmpty()) {
                        Collections.sort(newSongList, new Comparator<Song>() {
                            @Override
                            public int compare(Song firstSong, Song secondSong) {
                                String firstTitle = firstSong.getTitle();
                                String secondTitle = secondSong.getTitle();
                                if (firstTitle == null && secondTitle == null) return 0;
                                if (firstTitle == null) return -1;
                                if (secondTitle == null) return 1;
                                return firstTitle.compareToIgnoreCase(secondTitle);
                            }
                        });
                    }
                    
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            mSongsLock.writeLock().lock();
                            try {
                                mAllSongs.clear();
                                mAllSongs.addAll(newSongList);
                                mergeLooseSongs();
                            } finally {
                                mSongsLock.writeLock().unlock();
                            }
                            mIsLoaded = true;
                            if (listener != null) {
                                listener.onLoadComplete(newSongList);
                            }
                            mIsLoading.set(false);
                        }
                    });
                } catch (final Exception exception) {
                    Log.e(TAG, "Error loading songs with progress", exception);
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (listener != null) {
                                listener.onLoadError(exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                            }
                            mIsLoading.set(false);
                        }
                    });
                }
            }
        });
    }
    
    // ========================================================================
    // Internal Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Loads all songs from selected folders (internal method, runs on background thread).
     */
    private void loadAllSongsInternal() {
        mOldSongs.clear();
        mSongsLock.readLock().lock();
        try {
            mOldSongs.addAll(mAllSongs);
        } finally {
            mSongsLock.readLock().unlock();
        }
        
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        if (mSelectedFolderUris.isEmpty()) {
            loadLooseSongs();
            synchronized (mLooseSongs) {
                mSongsLock.writeLock().lock();
                try {
                    mAllSongs.addAll(mLooseSongs);
                } finally {
                    mSongsLock.writeLock().unlock();
                }
            }
            return;
        }
        
        for (String folderUriString : mSelectedFolderUris) {
            scanFolderWithUriOptimized(Uri.parse(folderUriString));
        }
        
        mSongsLock.writeLock().lock();
        try {
            if (!mAllSongs.isEmpty()) {
                Collections.sort(mAllSongs, new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null && secondTitle == null) return 0;
                        if (firstTitle == null) return -1;
                        if (secondTitle == null) return 1;
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                });
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
        
        mergeLooseSongs();
        Log.d(TAG, "Internal load complete: " + getSongCount() + " songs");
    }
    
    /**
     * Scans a folder for music files using optimized path (no progress callbacks).
     *
     * @param folderUri The folder URI to scan
     */
    private void scanFolderWithUriOptimized(@NonNull Uri folderUri) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithCache(folderPath);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    queryMediaStoreByNameWithCache(folderName);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan optimized error", exception);
        }
    }
    
    /**
     * Queries MediaStore for music files in a folder path using cached metadata.
     *
     * @param folderPath The folder path to scan
     */
    private void queryMediaStoreWithCache(@NonNull String folderPath) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) return;
                
                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }
                    
                    long duration = durationColumn != -1 ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    
                    mSongsLock.writeLock().lock();
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                    Log.d(TAG, "Cached " + newSongs.size() + " new songs from " + folderPath);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryWithCache error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    /**
     * Queries MediaStore for music files by folder name using cached metadata.
     *
     * @param folderName The folder name to scan
     */
    private void queryMediaStoreByNameWithCache(@NonNull String folderName) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) return;
                
                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }
                    
                    long duration = durationColumn != -1 ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    
                    mSongsLock.writeLock().lock();
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                    Log.d(TAG, "Cached " + newSongs.size() + " new songs from folder " + folderName);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryByNameWithCache error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    /**
     * Scans a folder for music files with progress reporting.
     *
     * @param folderUri The folder URI to scan
     * @param targetList The list to add songs to
     * @param currentCount The current count of processed songs
     * @param listener The progress listener (can be null)
     */
    private void scanFolderWithUriProgress(@NonNull Uri folderUri, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount, 
            @Nullable LoadProgressListener listener) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithProgress(folderPath, targetList, currentCount, listener);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    queryMediaStoreByNameWithProgress(folderName, targetList, currentCount, listener);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan progress error", exception);
        }
    }
    
    /**
     * Queries MediaStore with progress reporting.
     *
     * @param folderPath The folder path to scan
     * @param targetList The list to add songs to
     * @param currentCount The current count of processed songs
     * @param listener The progress listener (can be null)
     */
    private void queryMediaStoreWithProgress(@NonNull String folderPath, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReportedCount = {0};
        final long[] lastReportedTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) return;
                
                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }
                    
                    long duration = durationColumn != -1 ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cachedSong != null) {
                        finalSong = cachedSong;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int currentValue = currentCount.incrementAndGet();
                    
                    long currentTime = SystemClock.elapsedRealtime();
                    if (listener != null && (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD || 
                        currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReportedCount[0] = currentValue;
                        lastReportedTime[0] = currentTime;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onLoadProgress(currentValue);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, currentValue);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = currentCount.get();
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryWithProgress error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    /**
     * Queries MediaStore by folder name with progress reporting.
     *
     * @param folderName The folder name to scan
     * @param targetList The list to add songs to
     * @param currentCount The current count of processed songs
     * @param listener The progress listener (can be null)
     */
    private void queryMediaStoreByNameWithProgress(@NonNull String folderName, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReportedCount = {0};
        final long[] lastReportedTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) return;
                
                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }
                    
                    long duration = durationColumn != -1 ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cachedSong != null) {
                        finalSong = cachedSong;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int currentValue = currentCount.incrementAndGet();
                    
                    long currentTime = SystemClock.elapsedRealtime();
                    if (listener != null && (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD || 
                        currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReportedCount[0] = currentValue;
                        lastReportedTime[0] = currentTime;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onLoadProgress(currentValue);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, currentValue);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = currentCount.get();
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryByNameWithProgress error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    /**
     * Sends a broadcast with song information when a new song is discovered.
     *
     * @param song The song that was discovered (can be null)
     * @param currentCount The current total count of discovered songs
     */
    private void sendSongAddedBroadcast(@Nullable Song song, int currentCount) {
        Intent intent = new Intent(ACTION_PLAYLIST_LOAD_PROGRESS);
        
        if (song != null) {
            intent.putExtra("song_title", song.getTitle());
            intent.putExtra("song_artist", song.getArtist());
            intent.putExtra("song_album", song.getAlbum());
            intent.putExtra("song_genre", song.getGenre());
            intent.putExtra("song_path", song.getPath());
            intent.putExtra("song_duration", song.getDuration());
        }
        
        intent.putExtra("current_count", currentCount);
        mContext.sendBroadcast(intent);
    }
    
    /**
     * Shuts down the executor service gracefully.
     */
    public void shutdown() {
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
            Log.d(TAG, "Executor shut down");
        }
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Extracts the file system path from a folder URI.
     *
     * @param uri The folder URI
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) subPath = subPath.replace("%2F", "/");
                if (subPath.contains("/tree/")) subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                if (subPath.contains("/document/")) subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to get folder path from URI", exception);
                return null;
            }
        }
        return null;
    }
    
    /**
     * Gets the display name of a folder from its URI.
     *
     * @param uri The folder URI
     * @return The folder name, cleaned and sanitized, or null if extraction fails
     */
    @Nullable
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String folderName = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameColumn != -1) folderName = cursor.getString(nameColumn);
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) cursor.close();
        }
        
        if (folderName == null && uri.getLastPathSegment() != null) {
            folderName = uri.getLastPathSegment();
            if (folderName.contains(":")) folderName = folderName.substring(folderName.indexOf(":") + 1);
        }
        
        return folderName != null ? CharacterMapper.cleanStringMinimal(folderName) : null;
    }
}