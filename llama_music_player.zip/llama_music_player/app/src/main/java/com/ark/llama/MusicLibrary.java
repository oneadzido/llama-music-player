package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Owns the in-memory song list and the set of selected folder URIs, and
 * scans folders through {@link MediaStore} to populate the list.
 *
 * <p>The library exposes the current song list to the UI, loads the list
 * from the database, scans folder URIs for music files, searches the
 * list, and coordinates removal of missing files. It also supports
 * loose tracks opened from other apps and broadcasts per-song progress
 * while a scan is running.</p>
 *
 * <h3>State Ownership</h3>
 * <p>{@link #refreshCache()} is the sole writer of the in-memory song
 * list. It reads the songs table and the loose-songs table from
 * {@link SongDatabase} — the authoritative store — and rebuilds the list
 * under the write lock. Every other public API reads from that list.
 * Components that change the library change the database, then call
 * {@link #refreshCache()} on their own {@code MusicLibrary} instance, or
 * send a broadcast that causes every instance to do so.</p>
 *
 * <p>Multiple {@code MusicLibrary} instances may coexist, one per
 * component that reads song data. Each instance holds its own in-memory
 * state, so each must refresh independently when notified. The database
 * keeps them in agreement: a broadcast that reaches every instance, such
 * as {@code SOFT_UPDATE_PLAYLIST}, causes all instances to converge on
 * the same database state.</p>
 *
 * <p>{@link #updateSongGenre(String, String)} is a targeted cache-
 * coherence optimization that runs after the caller has already updated
 * the database. It brings an existing entry in the in-memory list in
 * sync with a value the database holds; it does not add or remove
 * entries.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Construction is synchronous and cheap: folder URIs are read from
 * SharedPreferences on the calling thread, and the initial database read
 * plus loose-track merge is scheduled on the single-thread executor. The
 * constructor returns immediately, so callers on the main thread are not
 * blocked by a full-table scan of the songs table.</p>
 *
 * <p>Consumers that need the loaded list use
 * {@link #loadAllSongsAsync(OnSongsLoadedListener)}, which either
 * dispatches the cached list immediately when the initial load has
 * completed or scans the folders from {@link MediaStore}. Consumers that
 * read {@link #getAllSongs()} or {@link #getSongCount()} immediately
 * after construction observe the list as it exists at that moment, which
 * may be empty until the background load finishes.</p>
 *
 * <p>{@link #invalidate()} is the reset-path counterpart to
 * {@link #refreshCache()}. Where {@code refreshCache()} re-reads the
 * song and loose tables while keeping the current folder set,
 * {@code invalidate()} additionally clears the in-memory lists, drops the
 * loaded flag, and re-reads the folder URI set from
 * {@code SharedPreferences}. Every {@code MusicLibrary} instance in the
 * process converges on the cleared selection, so a subsequent scan of
 * the removed folders cannot repopulate the database.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Song list access is guarded by a {@link ReentrantReadWriteLock}.
 * Loading state is tracked with an {@link AtomicBoolean}, pending
 * listeners with an {@link AtomicReference}, and folder URIs with a
 * synchronized set. Public list-returning methods return copies.</p>
 *
 * @see SongDatabase
 * @see CharacterMapper
 * @see ReentrantReadWriteLock
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MusicLibrary {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicLibrary";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the selected folder URIs in SharedPreferences. */
    private static final String KEY_FOLDERS = "selected_folders_uris";

    /** Broadcast action for playlist load progress updates. */
    public static final String ACTION_PLAYLIST_LOAD_PROGRESS =
        "com.ark.llama.PLAYLIST_LOAD_PROGRESS";

    /** Number of songs between progress updates, for UI throttling. */
    private static final int UI_UPDATE_THRESHOLD = 10;

    /** Minimum time between progress updates in milliseconds. */
    private static final long UI_UPDATE_TIME_MS = 500;

    /** Timeout for executor shutdown in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** Selected folder URIs; guarded by synchronized on the set itself. */
    private final Set<String> mSelectedFolderUris;

    /** Persistent store of the song metadata. */
    private final SongDatabase mSongDatabase;

    /** Single-thread executor for background operations. */
    private final ExecutorService mExecutor;

    /** Lock that guards the in-memory song list. */
    private final ReentrantReadWriteLock mSongsLock = new ReentrantReadWriteLock();

    /** In-memory song list; guarded by {@link #mSongsLock}. */
    private final ArrayList<Song> mAllSongs = new ArrayList<>();

    /** In-memory loose track list; guarded by synchronized on itself. */
    private final ArrayList<Song> mLooseSongs = new ArrayList<>();

    /** True while a load operation is in progress. */
    private final AtomicBoolean mIsLoading = new AtomicBoolean(false);

    /** Listener waiting for the current asynchronous load to complete. */
    private final AtomicReference<OnSongsLoadedListener> mPendingListener =
        new AtomicReference<>();

    /** True once the library has been loaded at least once. */
    private volatile boolean mIsLoaded = false;

    // ========================================================================
    // Listener Interfaces
    // ========================================================================

    /**
     * Receives the result of an asynchronous song load.
     */
    public interface OnSongsLoadedListener {

        /**
         * Called when the songs have been loaded.
         *
         * @param songs The loaded list of songs
         */
        void onSongsLoaded(@NonNull ArrayList<Song> songs);

        /**
         * Called when the load fails.
         *
         * @param error Description of the failure
         */
        void onLoadingError(@NonNull String error);
    }

    /**
     * Receives progress and completion callbacks for an update operation.
     */
    public interface UpdateProgressListener {

        /**
         * Called periodically while the update runs.
         *
         * @param current Number of songs processed so far
         * @param total Total number of songs to process
         * @param message Progress message
         */
        void onProgress(int current, int total, @NonNull String message);

        /**
         * Called when the update completes successfully.
         */
        void onComplete();

        /**
         * Called when the update fails.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    /**
     * Receives progress, completion, and error callbacks for a load
     * operation.
     */
    public interface LoadProgressListener {

        /**
         * Called periodically while the load runs.
         *
         * @param currentCount Number of songs loaded so far
         */
        void onLoadProgress(int currentCount);

        /**
         * Called when the load completes successfully.
         *
         * @param songs The loaded list of songs
         */
        void onLoadComplete(@NonNull ArrayList<Song> songs);

        /**
         * Called when the load fails.
         *
         * @param error Description of the failure
         */
        void onLoadError(@NonNull String error);
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a library that reads its folder set from
     * SharedPreferences and schedules the initial load on a background
     * thread.
     *
     * @param context Application context
     */
    public MusicLibrary(@NonNull Context context) {
        mContext = context;
        CharacterMapper.init(context);
        mSelectedFolderUris = new HashSet<>();
        mSongDatabase = SongDatabase.getInstance(context);
        mExecutor = Executors.newSingleThreadExecutor();

        loadSavedFolders();
        deleteLegacyCacheFile();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    loadSongsFromDatabaseSync();
                    loadLooseSongs();
                    mergeLooseSongs();
                    if (!mAllSongs.isEmpty()) {
                        mIsLoaded = true;
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Initial library load failed", exception);
                }
            }
        });
    }

    // ========================================================================
    // Initialization Helpers
    // ========================================================================

    /**
     * Deletes the legacy serialized cache file when one is present.
     */
    private void deleteLegacyCacheFile() {
        try {
            File cacheFile = new File(mContext.getFilesDir(), "playlist_cache.ser");
            if (cacheFile.exists()) {
                cacheFile.delete();
                Log.d(TAG, "Deleted legacy cache file");
            }
        } catch (SecurityException exception) {
            Log.w(TAG, "Permission denied deleting cache file");
        }
    }

    /**
     * Reads the persisted folder URI set into the in-memory set.
     */
    private void loadSavedFolders() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = preferences.getStringSet(KEY_FOLDERS, null);
        if (savedFolders != null) {
            mSelectedFolderUris.addAll(savedFolders);
            Log.d(TAG, "Loaded " + savedFolders.size() + " saved folders");
        }
    }

    /**
     * Persists the current folder URI set to SharedPreferences.
     */
    private void saveFolders() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        preferences.edit().putStringSet(KEY_FOLDERS, mSelectedFolderUris).apply();
        Log.d(TAG, "Saved " + mSelectedFolderUris.size() + " folders");
    }

    /**
     * Rebuilds the in-memory song list from the database under the write
     * lock.
     *
     * <p>The database read happens inside the write lock. Reading outside
     * the lock and writing inside it would create a window in which a
     * concurrent {@link #invalidate()} could clear the database between
     * the read and the lock acquisition, and the stale read would then be
     * written back on top of the freshly cleared list. Clearing and
     * reading under the same lock eliminates that window.</p>
     */
    @WorkerThread
    private void loadSongsFromDatabaseSync() {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            ArrayList<Song> cachedSongs = mSongDatabase.getAllSongs();
            if (cachedSongs != null && !cachedSongs.isEmpty()) {
                mAllSongs.addAll(cachedSongs);
                Log.d(TAG, "Loaded " + cachedSongs.size() + " songs from database");
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }
    }

    /**
     * Rebuilds the loose track list from the database, removing entries
     * whose files no longer exist.
     *
     * <p>The clear and the read both happen inside the monitor on
     * {@link #mLooseSongs}. Reading outside and writing inside would
     * allow a concurrent {@link #invalidate()} to clear the table between
     * the read and the write, and the stale read would then be written
     * back on top of the freshly cleared list.</p>
     */
    private void loadLooseSongs() {
        synchronized (mLooseSongs) {
            mLooseSongs.clear();
            ArrayList<Song> allLooseSongs = mSongDatabase.getLooseSongs();
            for (Song song : allLooseSongs) {
                if (song != null && song.getPath() != null) {
                    File file = new File(song.getPath());
                    if (file.exists() && file.canRead()) {
                        mLooseSongs.add(song);
                    } else {
                        mSongDatabase.removeLooseSong(song.getPath());
                        Log.d(TAG, "Removed missing loose song: " + song.getPath());
                    }
                }
            }
            Log.d(TAG, "Loaded " + mLooseSongs.size() + " valid loose songs");
        }
    }

    /**
     * Adds each loose track to the main song list when its path is not
     * already present.
     */
    private void mergeLooseSongs() {
        synchronized (mLooseSongs) {
            mSongsLock.writeLock().lock();
            try {
                int addedCount = 0;
                for (Song looseSong : mLooseSongs) {
                    if (looseSong == null || looseSong.getPath() == null) {
                        continue;
                    }

                    boolean alreadyExists = false;
                    for (Song existingSong : mAllSongs) {
                        if (existingSong != null
                                && looseSong.getPath().equals(existingSong.getPath())) {
                            alreadyExists = true;
                            break;
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(looseSong);
                        addedCount++;
                    }
                }
                if (addedCount > 0) {
                    Log.d(TAG, "Merged " + addedCount + " loose songs into main list");
                }
            } finally {
                mSongsLock.writeLock().unlock();
            }
        }
    }

    // ========================================================================
    // Public API - Folder Management
    // ========================================================================

    /**
     * Returns a copy of the selected folder URI set.
     *
     * @return A new set containing every selected folder URI
     */
    @NonNull
    public Set<String> getSelectedFolders() {
        synchronized (mSelectedFolderUris) {
            return new HashSet<>(mSelectedFolderUris);
        }
    }

    /**
     * Adds the given folder URI to the selected set and persists the set.
     *
     * @param uri Folder URI to add
     */
    public void addFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.add(uri);
            Log.d(TAG, "Added folder: " + uri);
        }
        saveFolders();
    }

    /**
     * Removes the given folder URI from the selected set and persists the
     * set.
     *
     * @param uri Folder URI to remove
     */
    public void removeFolder(@NonNull String uri) {
        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.remove(uri);
            Log.d(TAG, "Removed folder: " + uri);
        }
        saveFolders();
    }

    /**
     * Returns the number of selected folders.
     *
     * @return The folder count
     */
    public int getFolderCount() {
        synchronized (mSelectedFolderUris) {
            return mSelectedFolderUris.size();
        }
    }

    // ========================================================================
    // Public API - Song Management
    // ========================================================================

    /**
     * Rebuilds the in-memory song list from the database.
     *
     * <p>This is the sole writer of {@link #mAllSongs} and
     * {@link #mLooseSongs}. It reads the songs table and the
     * loose-songs table from {@link SongDatabase}, the authoritative
     * store, and rebuilds the list under the write lock. Callers that
     * change the library change the database first through
     * {@link SongDatabase}'s insert, delete, or clear methods, and then
     * call this method on their own {@code MusicLibrary} instance.</p>
     */
    public void refreshCache() {
        mSongsLock.writeLock().lock();
        try {
            // Reload loose songs from the database first so the merge below
            // sees the current set rather than a stale one.
            ArrayList<Song> allLooseSongs = mSongDatabase.getLooseSongs();
            ArrayList<Song> validLooseSongs = new ArrayList<>();
            for (Song song : allLooseSongs) {
                if (song != null && song.getPath() != null) {
                    File file = new File(song.getPath());
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(song);
                    } else {
                        mSongDatabase.removeLooseSong(song.getPath());
                    }
                }
            }
            synchronized (mLooseSongs) {
                mLooseSongs.clear();
                mLooseSongs.addAll(validLooseSongs);
            }

            // Rebuild the main list from the database.
            mAllSongs.clear();
            ArrayList<Song> freshSongs = mSongDatabase.getAllSongs();
            if (freshSongs != null) {
                mAllSongs.addAll(freshSongs);
            }

            // Merge loose songs that are not already present in the main list.
            int addedCount = 0;
            synchronized (mLooseSongs) {
                for (Song looseSong : mLooseSongs) {
                    if (looseSong == null || looseSong.getPath() == null) {
                        continue;
                    }

                    boolean alreadyExists = false;
                    for (Song existingSong : mAllSongs) {
                        if (existingSong != null
                                && looseSong.getPath().equals(existingSong.getPath())) {
                            alreadyExists = true;
                            break;
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(looseSong);
                        addedCount++;
                    }
                }
            }

            mIsLoaded = true;

            Log.d(TAG, "Cache refreshed: " + mAllSongs.size() + " songs, "
                + validLooseSongs.size() + " loose (" + addedCount + " merged)");
        } finally {
            mSongsLock.writeLock().unlock();
        }
    }

    /**
     * Resets this instance to its post-construction, pre-load state.
     *
     * <p>Unlike {@link #refreshCache()}, which re-reads the song and
     * loose-song tables from the database while keeping the current
     * folder set, this method additionally clears the in-memory song
     * lists, drops the loaded flag, and re-reads the folder URI set from
     * {@code SharedPreferences}. It exists for the full-library-reset
     * path: when the user removes every folder and every loose track,
     * every {@code MusicLibrary} instance in the process converges on the
     * new empty folder set, not just the instance owned by the component
     * that performed the removal.</p>
     *
     * <p>The write lock is held across the song-list and loose-list
     * clears so an in-flight initial load, which also writes under the
     * write lock, cannot interleave with it. The folder set is guarded by
     * its own monitor, as everywhere else in this class.</p>
     */
    public void invalidate() {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
            synchronized (mLooseSongs) {
                mLooseSongs.clear();
            }
            mIsLoaded = false;
        } finally {
            mSongsLock.writeLock().unlock();
        }

        synchronized (mSelectedFolderUris) {
            mSelectedFolderUris.clear();
            loadSavedFolders();
        }

        Log.d(TAG, "Library invalidated: " + mSelectedFolderUris.size()
            + " folders remain in selection");
    }

    /**
     * Removes from the database any song in the given list whose file no
     * longer exists, and refreshes the in-memory list when at least one
     * song was removed.
     *
     * @param currentSongs The song list to validate, or null
     */
    public void removeMissingFiles(@Nullable ArrayList<Song> currentSongs) {
        if (currentSongs == null || currentSongs.isEmpty()) {
            return;
        }

        ArrayList<Song> validSongs = new ArrayList<>();
        for (Song song : currentSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validSongs.add(song);
                } else {
                    Log.d(TAG, "Removing missing file: " + song.getPath());
                }
            }
        }

        if (validSongs.size() != currentSongs.size()) {
            mSongDatabase.clearCache();
            if (!validSongs.isEmpty()) {
                mSongDatabase.insertSongsBatch(validSongs);
            }
            refreshCache();
        }
    }

    /**
     * Removes every cached song from the database.
     */
    @WorkerThread
    public void clearPlaylistCache() {
        mSongDatabase.clearCache();
        Log.d(TAG, "Cleared playlist cache");
    }

    /**
     * Returns a copy of the in-memory song list.
     *
     * @return A new list containing every song in the library
     */
    @NonNull
    public ArrayList<Song> getAllSongs() {
        mSongsLock.readLock().lock();
        try {
            return new ArrayList<>(mAllSongs);
        } finally {
            mSongsLock.readLock().unlock();
        }
    }

    /**
     * Returns the number of songs currently in the in-memory list.
     *
     * @return The song count
     */
    public int getSongCount() {
        mSongsLock.readLock().lock();
        try {
            return mAllSongs.size();
        } finally {
            mSongsLock.readLock().unlock();
        }
    }

    /**
     * Returns every song whose title, artist, album, or genre contains
     * the given query, ignoring case.
     *
     * @param query The search text
     * @return A list of matching songs
     */
    @NonNull
    public ArrayList<Song> searchSongs(@NonNull String query) {
        if (TextUtils.isEmpty(query)) {
            return getAllSongs();
        }

        ArrayList<Song> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase().trim();

        mSongsLock.readLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase().contains(lowerQuery))
                            || (artist != null && artist.toLowerCase().contains(lowerQuery))
                            || (album != null && album.toLowerCase().contains(lowerQuery))
                            || (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        results.add(song);
                    }
                }
            }
        } finally {
            mSongsLock.readLock().unlock();
        }

        Log.d(TAG, "Search for '" + query + "' returned " + results.size() + " results");
        return results;
    }

    /**
     * Brings the in-memory genre of the given song in sync with a value
     * the database already holds.
     *
     * <p>The caller updates the database first; this method brings the
     * in-memory entry in sync with the value the database now holds. It
     * updates an existing entry only.</p>
     *
     * @param songPath Path of the song to update
     * @param genre New genre value
     * @return True when the song was found and updated
     */
    public boolean updateSongGenre(@NonNull String songPath, @NonNull String genre) {
        mSongsLock.writeLock().lock();
        try {
            for (Song song : mAllSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated in-memory genre for: "
                        + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }

        synchronized (mLooseSongs) {
            for (Song song : mLooseSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated loose song genre for: "
                        + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        }

        Log.w(TAG, "Song not found for genre update: " + songPath);
        return false;
    }

    // ========================================================================
    // Public API - Asynchronous Loading
    // ========================================================================

    /**
     * Loads all songs asynchronously and dispatches the result to the
     * given listener on the main thread.
     *
     * <p>When the in-memory list is already populated, the listener is
     * dispatched with a copy of that list immediately. When a load is
     * already in progress, the listener replaces any previous one.</p>
     *
     * @param listener Listener that receives the loaded list, or null
     */
    public void loadAllSongsAsync(@Nullable final OnSongsLoadedListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onSongsLoaded(getAllSongs());
                    }
                });
            }
            return;
        }

        if (mIsLoading.get()) {
            mPendingListener.set(listener);
            return;
        }

        mIsLoading.set(true);
        mPendingListener.set(listener);

        final OnSongsLoadedListener capturedListener = listener;
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    loadAllSongsInternal();
                    mIsLoaded = true;

                    if (capturedListener != null) {
                        final ArrayList<Song> finalSongs = getAllSongs();
                        new android.os.Handler(android.os.Looper.getMainLooper())
                            .post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onSongsLoaded(finalSongs);
                            }
                        });
                    }
                } catch (final Exception exception) {
                    Log.e(TAG, "Error loading songs", exception);
                    if (capturedListener != null) {
                        new android.os.Handler(android.os.Looper.getMainLooper())
                            .post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onLoadingError(
                                    exception.getMessage() != null
                                        ? exception.getMessage() : "Unknown error");
                            }
                        });
                    }
                } finally {
                    mIsLoading.set(false);
                    if (mPendingListener.get() == capturedListener) {
                        mPendingListener.set(null);
                    }
                }
            }
        });
    }

    /**
     * Loads all songs asynchronously with progress reporting.
     *
     * @param listener Listener that receives progress and the loaded
     *        list, or null
     */
    public void loadAllSongsWithProgress(@Nullable final LoadProgressListener listener) {
        if (mIsLoaded && getSongCount() > 0) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onLoadComplete(getAllSongs());
                    }
                });
            }
            return;
        }

        if (mIsLoading.get()) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(new Runnable() {
                @Override
                public void run() {
                    loadAllSongsWithProgress(listener);
                }
            }, 200);
            return;
        }

        mIsLoading.set(true);

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final ArrayList<Song> newSongList = new ArrayList<>();

                    if (mSelectedFolderUris.isEmpty()) {
                        loadLooseSongs();
                        synchronized (mLooseSongs) {
                            newSongList.addAll(mLooseSongs);
                        }

                        new android.os.Handler(android.os.Looper.getMainLooper())
                            .post(new Runnable() {
                            @Override
                            public void run() {
                                mSongsLock.writeLock().lock();
                                try {
                                    mAllSongs.clear();
                                    mAllSongs.addAll(newSongList);
                                    mergeLooseSongs();
                                } finally {
                                    mSongsLock.writeLock().unlock();
                                }
                                mIsLoaded = true;
                                if (listener != null) {
                                    listener.onLoadComplete(newSongList);
                                }
                                mIsLoading.set(false);
                            }
                        });
                        return;
                    }

                    final AtomicInteger currentCount = new AtomicInteger(0);
                    for (String folderUriString : mSelectedFolderUris) {
                        scanFolderWithUriProgress(Uri.parse(folderUriString),
                            newSongList, currentCount, listener);
                    }

                    if (!newSongList.isEmpty()) {
                        Collections.sort(newSongList, new Comparator<Song>() {
                            @Override
                            public int compare(Song firstSong, Song secondSong) {
                                String firstTitle = firstSong.getTitle();
                                String secondTitle = secondSong.getTitle();
                                if (firstTitle == null && secondTitle == null) {
                                    return 0;
                                }
                                if (firstTitle == null) {
                                    return -1;
                                }
                                if (secondTitle == null) {
                                    return 1;
                                }
                                return firstTitle.compareToIgnoreCase(secondTitle);
                            }
                        });
                    }

                    new android.os.Handler(android.os.Looper.getMainLooper())
                        .post(new Runnable() {
                        @Override
                        public void run() {
                            mSongsLock.writeLock().lock();
                            try {
                                mAllSongs.clear();
                                mAllSongs.addAll(newSongList);
                                mergeLooseSongs();
                            } finally {
                                mSongsLock.writeLock().unlock();
                            }
                            mIsLoaded = true;
                            if (listener != null) {
                                listener.onLoadComplete(newSongList);
                            }
                            mIsLoading.set(false);
                        }
                    });
                } catch (final Exception exception) {
                    Log.e(TAG, "Error loading songs with progress", exception);
                    new android.os.Handler(android.os.Looper.getMainLooper())
                        .post(new Runnable() {
                        @Override
                        public void run() {
                            if (listener != null) {
                                listener.onLoadError(
                                    exception.getMessage() != null
                                        ? exception.getMessage() : "Unknown error");
                            }
                            mIsLoading.set(false);
                        }
                    });
                }
            }
        });
    }

    // ========================================================================
    // Internal Load Methods
    // ========================================================================

    /**
     * Loads every song from the selected folders into the in-memory
     * list.
     */
    private void loadAllSongsInternal() {
        mSongsLock.writeLock().lock();
        try {
            mAllSongs.clear();
        } finally {
            mSongsLock.writeLock().unlock();
        }

        if (mSelectedFolderUris.isEmpty()) {
            loadLooseSongs();
            synchronized (mLooseSongs) {
                mSongsLock.writeLock().lock();
                try {
                    mAllSongs.addAll(mLooseSongs);
                } finally {
                    mSongsLock.writeLock().unlock();
                }
            }
            return;
        }

        for (String folderUriString : mSelectedFolderUris) {
            scanFolderWithUriOptimized(Uri.parse(folderUriString));
        }

        mSongsLock.writeLock().lock();
        try {
            if (!mAllSongs.isEmpty()) {
                Collections.sort(mAllSongs, new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null && secondTitle == null) {
                            return 0;
                        }
                        if (firstTitle == null) {
                            return -1;
                        }
                        if (secondTitle == null) {
                            return 1;
                        }
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                });
            }
        } finally {
            mSongsLock.writeLock().unlock();
        }

        mergeLooseSongs();
        Log.d(TAG, "Internal load complete: " + getSongCount() + " songs");
    }

    /**
     * Scans the given folder URI without emitting progress callbacks.
     *
     * @param folderUri The folder URI to scan
     */
    private void scanFolderWithUriOptimized(@NonNull Uri folderUri) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithCache(folderPath);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    queryMediaStoreByNameWithCache(folderName);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan optimized error", exception);
        }
    }

    /**
     * Queries {@link MediaStore} for music files under the given path,
     * adding each result to the in-memory list and to the database.
     *
     * @param folderPath The folder path to scan
     */
    private void queryMediaStoreWithCache(@NonNull String folderPath) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[] {normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) {
                    return;
                }

                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    try {
                        android.media.MediaMetadataRetriever retriever =
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }

                    long duration = durationColumn != -1
                        ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);

                    mSongsLock.writeLock().lock();
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());

                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                    Log.d(TAG, "Cached " + newSongs.size() + " new songs from "
                        + folderPath);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryWithCache error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Queries {@link MediaStore} for music files whose path contains the
     * given folder name, adding each result to the in-memory list and to
     * the database.
     *
     * @param folderName The folder name to scan
     */
    private void queryMediaStoreByNameWithCache(@NonNull String folderName) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<>();

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[] {"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) {
                    return;
                }

                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    try {
                        android.media.MediaMetadataRetriever retriever =
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }

                    long duration = durationColumn != -1
                        ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);

                    mSongsLock.writeLock().lock();
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong);
                        } else {
                            Song newSong = new Song(
                                    CharacterMapper.getTitle(filePath),
                                    CharacterMapper.getArtist(filePath),
                                    CharacterMapper.getAlbum(filePath),
                                    CharacterMapper.getGenre(filePath),
                                    filePath, duration, null);
                            mAllSongs.add(newSong);
                            newSongs.add(newSong);
                        }
                    } finally {
                        mSongsLock.writeLock().unlock();
                    }
                } while (cursor.moveToNext());

                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                    Log.d(TAG, "Cached " + newSongs.size() + " new songs from folder "
                        + folderName);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryByNameWithCache error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Scans the given folder URI with progress reporting.
     *
     * @param folderUri The folder URI to scan
     * @param targetList The list that receives the found songs
     * @param currentCount Counter of songs processed so far
     * @param listener Progress listener, or null
     */
    private void scanFolderWithUriProgress(@NonNull Uri folderUri,
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount,
            @Nullable LoadProgressListener listener) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithProgress(folderPath, targetList, currentCount, listener);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    queryMediaStoreByNameWithProgress(folderName, targetList,
                        currentCount, listener);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan progress error", exception);
        }
    }

    /**
     * Queries {@link MediaStore} for music files under the given path,
     * with progress reporting.
     *
     * @param folderPath The folder path to scan
     * @param targetList The list that receives the found songs
     * @param currentCount Counter of songs processed so far
     * @param listener Progress listener, or null
     */
    private void queryMediaStoreWithProgress(@NonNull String folderPath,
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount,
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReportedCount = {0};
        final long[] lastReportedTime = {0};

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[] {normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) {
                    return;
                }

                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    try {
                        android.media.MediaMetadataRetriever retriever =
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }

                    long duration = durationColumn != -1
                        ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    Song finalSong;

                    if (cachedSong != null) {
                        finalSong = cachedSong;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }

                    targetList.add(finalSong);
                    final int currentValue = currentCount.incrementAndGet();

                    long currentTime = SystemClock.elapsedRealtime();
                    if (listener != null
                            && (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD
                                || currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReportedCount[0] = currentValue;
                        lastReportedTime[0] = currentTime;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onLoadProgress(currentValue);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, currentValue);
                    }
                } while (cursor.moveToNext());

                final int finalCount = currentCount.get();
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryWithProgress error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Queries {@link MediaStore} for music files whose path contains the
     * given folder name, with progress reporting.
     *
     * @param folderName The folder name to scan
     * @param targetList The list that receives the found songs
     * @param currentCount Counter of songs processed so far
     * @param listener Progress listener, or null
     */
    private void queryMediaStoreByNameWithProgress(@NonNull String folderName,
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger currentCount,
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final android.os.Handler mainHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReportedCount = {0};
        final long[] lastReportedTime = {0};

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[] {"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathColumn == -1) {
                    return;
                }

                do {
                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    try {
                        android.media.MediaMetadataRetriever retriever =
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception exception) {
                        continue;
                    }

                    long duration = durationColumn != -1
                        ? cursor.getLong(durationColumn) : 0;
                    Song cachedSong = mSongDatabase.getSong(filePath);
                    Song finalSong;

                    if (cachedSong != null) {
                        finalSong = cachedSong;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }

                    targetList.add(finalSong);
                    final int currentValue = currentCount.incrementAndGet();

                    long currentTime = SystemClock.elapsedRealtime();
                    if (listener != null
                            && (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD
                                || currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReportedCount[0] = currentValue;
                        lastReportedTime[0] = currentTime;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onLoadProgress(currentValue);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, currentValue);
                    }
                } while (cursor.moveToNext());

                final int finalCount = currentCount.get();
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "queryByNameWithProgress error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Broadcasts a single-song progress update.
     *
     * @param song The song that was just added, or null to broadcast only
     *        the running count
     * @param currentCount Running count of discovered songs
     */
    private void sendSongAddedBroadcast(@Nullable Song song, int currentCount) {
        Intent intent = new Intent(ACTION_PLAYLIST_LOAD_PROGRESS);

        if (song != null) {
            intent.putExtra("song_title", song.getTitle());
            intent.putExtra("song_artist", song.getArtist());
            intent.putExtra("song_album", song.getAlbum());
            intent.putExtra("song_genre", song.getGenre());
            intent.putExtra("song_path", song.getPath());
            intent.putExtra("song_duration", song.getDuration());
        }

        intent.putExtra("current_count", currentCount);
        mContext.sendBroadcast(intent);
    }

    /**
     * Shuts down the executor, waiting up to
     * {@link #SHUTDOWN_TIMEOUT_MS} milliseconds for tasks to finish.
     */
    public void shutdown() {
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
            Log.d(TAG, "Executor shut down");
        }
    }

    // ========================================================================
    // URI Helper Methods
    // ========================================================================

    /**
     * Returns the filesystem path encoded in the given primary-storage
     * tree URI, or null when the URI does not refer to primary storage.
     *
     * @param uri Folder URI to inspect
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/");
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                }
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to get folder path from URI", exception);
                return null;
            }
        }
        return null;
    }

    /**
     * Returns the cleaned display name of the given folder URI.
     *
     * @param uri Folder URI to inspect
     * @return The cleaned folder name, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String folderName = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(
                    android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameColumn != -1) {
                    folderName = cursor.getString(nameColumn);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        if (folderName == null && uri.getLastPathSegment() != null) {
            folderName = uri.getLastPathSegment();
            if (folderName.contains(":")) {
                folderName = folderName.substring(folderName.indexOf(":") + 1);
            }
        }

        return folderName != null ? CharacterMapper.cleanString(folderName) : null;
    }
}