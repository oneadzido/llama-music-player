package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe manager for audio decoding operations including main decoder and prefill for seeks.
 * 
 * <p>This class provides two types of decoders:</p>
 * <ul>
 *   <li><b>Main Decoder:</b> Persistent decoder for continuous playback</li>
 *   <li><b>Prefill Decoder:</b> Temporary decoder for seek prefill (eliminates stall)</li>
 * </ul>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All public methods are thread-safe</li>
 *   <li>Main decoder operations are protected by a ReentrantLock</li>
 *   <li>Prefill operations use AtomicBoolean for state tracking</li>
 *   <li>Callback is delivered on main thread via Handler</li>
 *   <li>No two decoders access the same file simultaneously</li>
 *   <li>Sequence IDs prevent stale callback delivery</li>
 *   <li>Error counter uses AtomicInteger for thread safety</li>
 * </ul>
 * 
 * @see AudioDecoder
 * @see LlamaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class DecoderManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "DecoderManager";
    
    /** 
     * Number of frames to prefill (~93ms at 44.1kHz stereo).
     * This is enough to cover the seek operation gap without causing
     * excessive memory usage or delay.
     */
    private static final int PREFILL_FRAMES = 4096;
    
    /** Maximum number of frames to read per decoder call. */
    private static final int MAX_FRAMES_PER_READ = 8192;
    
    /** Timeout for decoder operations in milliseconds. */
    private static final long DECODER_TIMEOUT_MS = 100;
    
    /** Maximum number of retry attempts for decoder operations. */
    private static final int MAX_RETRY_ATTEMPTS = 3;
    
    // ========================================================================
    // Thread-Safe State Variables
    // ========================================================================
    
    /** Lock for main decoder operations (protects from concurrent access). */
    private final ReentrantLock mMainDecoderLock = new ReentrantLock();
    
    /** Main decoder for continuous playback (persistent across seeks). */
    @Nullable
    private volatile AudioDecoder mMainDecoder;
    
    /** Current file path (immutable after initialize). */
    @Nullable
    private volatile String mCurrentFilePath;
    
    /** Current sample rate (immutable after initialize, from decoder output). */
    private volatile int mSampleRate = 44100;
    
    /** Current channel count (immutable after initialize, from decoder output). */
    private volatile int mChannels = 2;
    
    /** Main thread handler for callbacks (ensures UI thread delivery). */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Prefill State (Thread-Safe)
    // ========================================================================
    
    /** Flag indicating if prefill is in progress (atomic for CAS operations). */
    private final AtomicBoolean mIsPrefilling = new AtomicBoolean(false);
    
    /** Flag indicating if current prefill was cancelled (atomic). */
    private final AtomicBoolean mIsPrefillCancelled = new AtomicBoolean(false);
    
    /** 
     * Current prefill sequence ID (increments on each prefill start).
     * Used to detect and ignore stale callbacks from cancelled prefills.
     */
    private final AtomicInteger mPrefillSequence = new AtomicInteger(0);
    
    /** Callback for prefill completion (volatile for cross-thread visibility). */
    @Nullable
    private volatile PrefillCallback mPendingCallback = null;
    
    /** Thread reference for current prefill operation (for interruption). */
    @Nullable
    private volatile Thread mCurrentPrefillThread = null;
    
    // ========================================================================
    // Error Tracking (Thread-Safe)
    // ========================================================================
    
    /** Number of consecutive read errors from main decoder (atomic). */
    private final AtomicInteger mConsecutiveErrors = new AtomicInteger(0);
    
    /** Flag indicating if decoder is in error state (atomic). */
    private final AtomicBoolean mIsInErrorState = new AtomicBoolean(false);
    
    // ========================================================================
    // Callback Interface
    // ========================================================================
    
    /**
     * Callback for prefill completion.
     * Called on the main thread for safe UI updates.
     */
    public interface PrefillCallback {
        
        /**
         * Called when prefill buffer is ready.
         * 
         * <p>The sequence ID should be checked against the current sequence
         * to ensure this callback isn't from a cancelled/stale prefill.</p>
         * 
         * @param buffer Prefilled audio data (16-bit PCM, interleaved)
         * @param frames Number of frames in buffer (each frame = channels samples)
         * @param sequence The sequence ID of this prefill (for stale detection)
         */
        void onPrefillReady(@NonNull short[] buffer, int frames, int sequence);
    }
    
    // ========================================================================
    // Constructors and Initialization
    // ========================================================================
    
    /**
     * Constructs a new DecoderManager instance.
     * 
     * <p>The manager is not usable until {@link #initialize(String, int, int)} is called.</p>
     */
    public DecoderManager() {
        Log.d(TAG, "DecoderManager instance created");
    }
    
    /**
     * Initializes the decoder manager with a file.
     * Thread-safe: uses ReentrantLock to protect main decoder creation.
     * 
     * <p>This method creates and opens the main AudioDecoder, which will
     * be used for all subsequent read operations. The sample rate and
     * channel count parameters are ignored - they will be read from the
     * decoder output after the first frame is decoded.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @param sampleRate Ignored - will be detected from decoder output
     * @param channels Ignored - will be detected from decoder output
     * @return true if initialization successful, false otherwise
     */
    public boolean initialize(@NonNull String filePath, int sampleRate, int channels) {
        // Cancel any ongoing prefill before reinitializing
        cancelPrefill();
        
        mMainDecoderLock.lock();
        try {
            releaseMainDecoderLocked();
            
            Log.d(TAG, "initialize: opening audio file: " + filePath);
            
            AudioDecoder newDecoder = new AudioDecoder();
            if (!newDecoder.open(filePath)) {
                Log.e(TAG, "Failed to open main decoder: " + filePath);
                return false;
            }
            
            mMainDecoder = newDecoder;
            mCurrentFilePath = filePath;
            
            // Get actual sample rate and channels from decoder (after first frame)
            // We need to read a small amount to get the actual format
            short[] tempBuffer = new short[MAX_FRAMES_PER_READ];
            int retryCount = 0;
            while (mMainDecoder.getSampleRate() <= 0 && retryCount < 10) {
                int frames = mMainDecoder.read(tempBuffer, MAX_FRAMES_PER_READ / 2);
                if (frames > 0) {
                    break;
                }
                try { 
                    Thread.sleep(DECODER_TIMEOUT_MS); 
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                retryCount++;
            }
            
            mSampleRate = mMainDecoder.getSampleRate();
            mChannels = mMainDecoder.getChannels();
            
            Log.d(TAG, "DecoderManager initialized: " + filePath + ", " + mSampleRate + "Hz, " + mChannels + "ch");
            
            // Reset error state on successful initialization
            mConsecutiveErrors.set(0);
            mIsInErrorState.set(false);
            
            return true;
            
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    // ========================================================================
    // Main Decoder Operations (Thread-Safe)
    // ========================================================================
    
    /**
     * Reads PCM data from the main decoder.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * <p>This method reads up to the specified number of frames from the
     * decoder. If the decoder is at end of stream, returns 0.
     * On error, returns -1.</p>
     * 
     * <p><b>Buffer Management:</b> The internal PCM buffer uses compaction
     * to maintain a sliding window. When more than half the buffer is consumed,
     * remaining data is moved to the front to maximize available space.</p>
     *
     * @param buffer Destination buffer for PCM samples (16-bit signed, interleaved)
     * @param frames Number of frames to read (each frame = channels samples)
     * @return Number of frames actually read, or -1 on error
     */
    public int read(@NonNull short[] buffer, int frames) {
        if (frames <= 0) return 0;
        
        mMainDecoderLock.lock();
        try {
            if (mMainDecoder == null) {
                Log.e(TAG, "read: decoder not initialized");
                return -1;
            }
            
            if (mIsInErrorState.get()) {
                Log.w(TAG, "read: decoder in error state");
                return -1;
            }
            
            int framesRead = mMainDecoder.read(buffer, frames);
            
            if (framesRead < 0) {
                int errors = mConsecutiveErrors.incrementAndGet();
                Log.w(TAG, "read: decoder error, consecutive errors=" + errors);
                
                if (errors >= MAX_RETRY_ATTEMPTS) {
                    Log.e(TAG, "read: too many consecutive errors, entering error state");
                    mIsInErrorState.set(true);
                }
                return -1;
            }
            
            // Reset error count on successful read
            if (framesRead > 0) {
                mConsecutiveErrors.set(0);
            }
            
            return framesRead;
            
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Seeks the main decoder to the specified position.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * <p>After seek, the decoder will start reading from the new position.
     * Any buffered PCM data is discarded, and the decoder flushes its internal state.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekMainDecoder(int positionMs) {
        mMainDecoderLock.lock();
        try {
            if (mMainDecoder != null) {
                mMainDecoder.seekTo(positionMs);
                // Reset error state on explicit seek
                mConsecutiveErrors.set(0);
                mIsInErrorState.set(false);
                Log.d(TAG, "Main decoder seeked to: " + positionMs + "ms");
            }
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Checks if the main decoder has reached end of stream.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * @return true if EOS reached, false otherwise
     */
    public boolean isEOS() {
        mMainDecoderLock.lock();
        try {
            return mMainDecoder != null && mMainDecoder.isEOS();
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Gets the current sample rate from the decoder output.
     * Thread-safe: volatile read.
     * 
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Gets the current channel count from the decoder output.
     * Thread-safe: volatile read.
     * 
     * @return Number of channels (1 for mono, 2 for stereo)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Gets the total duration of the audio file in milliseconds.
     * Thread-safe: calls through to main decoder with lock.
     * 
     * @return Duration in milliseconds, or 0 if not available
     */
    public int getDuration() {
        mMainDecoderLock.lock();
        try {
            if (mMainDecoder != null) {
                return mMainDecoder.getDuration();
            }
            return 0;
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Gets the current file path.
     * Thread-safe: volatile read.
     * 
     * @return File path, or null if not initialized
     */
    @Nullable
    public String getCurrentFilePath() {
        return mCurrentFilePath;
    }
    
    /**
     * Checks if the decoder manager is initialized and ready.
     * Thread-safe: checks main decoder with lock for safety.
     * 
     * @return true if main decoder is available and not in error state
     */
    public boolean isReady() {
        mMainDecoderLock.lock();
        try {
            return mMainDecoder != null && !mIsInErrorState.get();
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Checks if the decoder is in error state.
     * Thread-safe: atomic read.
     * 
     * @return true if in error state
     */
    public boolean isInErrorState() {
        return mIsInErrorState.get();
    }
    
    /**
     * Resets the error state of the decoder.
     * Thread-safe: atomic set.
     */
    public void resetErrorState() {
        mConsecutiveErrors.set(0);
        mIsInErrorState.set(false);
        Log.d(TAG, "Decoder error state reset");
    }
    
    // ========================================================================
    // Prefill Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Starts asynchronous prefill at the specified position.
     * Thread-safe: uses AtomicBoolean for state, sequence ID for stale detection.
     * 
     * <p>This method creates a temporary decoder that seeks to the target position
     * and reads a small buffer of PCM data. When complete, the callback is invoked
     * on the main thread with the prefill buffer. The caller can then write this
     * buffer to AudioTrack before flushing, eliminating the audio gap during seek.</p>
     * 
     * <p>If a prefill is already in progress, it is cancelled and replaced.
     * This ensures that only the most recent seek request is processed.</p>
     * 
     * @param targetPositionMs Target seek position in milliseconds
     * @param callback Callback when prefill is ready (on UI thread)
     */
    public void startPrefill(int targetPositionMs, @NonNull PrefillCallback callback) {
        // Cancel any existing prefill
        cancelPrefill();
        
        if (mCurrentFilePath == null) {
            Log.e(TAG, "Cannot prefill: no file loaded");
            mMainHandler.post(() -> callback.onPrefillReady(new short[0], 0, -1));
            return;
        }
        
        // Atomically set prefill state using CAS
        if (!mIsPrefilling.compareAndSet(false, true)) {
            Log.w(TAG, "Prefill already in progress (CAS failed)");
            return;
        }
        
        mIsPrefillCancelled.set(false);
        
        final int currentSequence = mPrefillSequence.incrementAndGet();
        mPendingCallback = callback;
        
        final String filePath = mCurrentFilePath;
        final int channels = mChannels;
        final int targetPos = targetPositionMs;
        
        Log.d(TAG, "startPrefill: position=" + targetPos + "ms, sequence=" + currentSequence);
        
        // Start background thread for prefill operation
        final Thread prefillThread = new Thread(() -> {
            mCurrentPrefillThread = Thread.currentThread();
            
            try {
                // Check cancellation before starting
                if (mIsPrefillCancelled.get()) {
                    finishPrefill(new short[0], 0, currentSequence);
                    return;
                }
                
                AudioDecoder prefillDecoder = null;
                try {
                    // Create temporary decoder for prefill only
                    prefillDecoder = new AudioDecoder();
                    
                    if (!prefillDecoder.open(filePath)) {
                        Log.e(TAG, "Failed to open prefill decoder");
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Check cancellation after open
                    if (mIsPrefillCancelled.get()) {
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Seek to target position
                    prefillDecoder.seekTo(targetPos);
                    
                    // Check cancellation after seek
                    if (mIsPrefillCancelled.get()) {
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Read prefill buffer
                    short[] buffer = new short[PREFILL_FRAMES * channels];
                    int framesRead = prefillDecoder.read(buffer, PREFILL_FRAMES);
                    
                    if (framesRead > 0 && !mIsPrefillCancelled.get()) {
                        Log.d(TAG, "Prefill complete: " + framesRead + " frames at " + targetPos + "ms (seq=" + currentSequence + ")");
                        
                        // Trim buffer to actual frames read
                        short[] trimmedBuffer = new short[framesRead * channels];
                        System.arraycopy(buffer, 0, trimmedBuffer, 0, trimmedBuffer.length);
                        
                        finishPrefill(trimmedBuffer, framesRead, currentSequence);
                    } else {
                        Log.w(TAG, "Prefill read " + framesRead + " frames");
                        finishPrefill(new short[0], 0, currentSequence);
                    }
                    
                } catch (Exception e) {
                    Log.e(TAG, "Prefill failed", e);
                    finishPrefill(new short[0], 0, currentSequence);
                } finally {
                    if (prefillDecoder != null) {
                        try {
                            prefillDecoder.release();
                        } catch (Exception e) {
                            Log.w(TAG, "Error releasing prefill decoder", e);
                        }
                    }
                }
            } finally {
                mCurrentPrefillThread = null;
            }
        }, "DecoderManager-Prefill");
        
        prefillThread.start();
    }
    
    /**
     * Cancels any ongoing prefill operation.
     * Thread-safe: uses AtomicBoolean flags and thread interruption.
     * 
     * <p>This method sets the cancellation flag and interrupts the prefill
     * thread if it's running. The callback will not be invoked for the
     * cancelled operation.</p>
     */
    public void cancelPrefill() {
        // Set cancellation flag first (prevents new operations from completing)
        mIsPrefillCancelled.set(true);
        
        // Interrupt the prefill thread if it's running
        Thread prefillThread = mCurrentPrefillThread;
        if (prefillThread != null && prefillThread.isAlive()) {
            prefillThread.interrupt();
            Log.d(TAG, "Prefill thread interrupted");
        }
        
        // Clear the prefill state
        mIsPrefilling.set(false);
        mPendingCallback = null;
        
        Log.d(TAG, "Prefill cancelled");
    }
    
    /**
     * Checks if prefill is currently in progress.
     * Thread-safe: AtomicBoolean get.
     * 
     * @return true if prefill is active
     */
    public boolean isPrefilling() {
        return mIsPrefilling.get();
    }
    
    /**
     * Completes prefill and delivers callback on main thread.
     * Thread-safe: checks sequence ID to prevent stale callbacks.
     * 
     * <p>Only delivers the callback if the sequence ID matches the current
     * sequence, ensuring that callbacks from cancelled prefills are ignored.</p>
     * 
     * @param buffer The prefill buffer (may be empty on failure)
     * @param frames Number of frames in buffer
     * @param sequence The sequence ID of this prefill
     */
    private void finishPrefill(@NonNull short[] buffer, int frames, int sequence) {
        // Reset prefill state
        mIsPrefilling.set(false);
        
        // Get the callback (volatile read)
        final PrefillCallback callback = mPendingCallback;
        
        // Only deliver if this callback is still valid (not cancelled by a newer prefill)
        if (callback != null && sequence == mPrefillSequence.get()) {
            mMainHandler.post(() -> {
                // Double-check we're not delivering a stale callback
                if (sequence == mPrefillSequence.get()) {
                    callback.onPrefillReady(buffer, frames, sequence);
                } else {
                    Log.d(TAG, "finishPrefill: stale callback ignored (seq=" + sequence + 
                          ", current=" + mPrefillSequence.get() + ")");
                }
            });
        } else {
            Log.d(TAG, "finishPrefill: callback null or stale, seq=" + sequence);
        }
        
        // Clear callback reference to allow GC
        if (sequence == mPrefillSequence.get()) {
            mPendingCallback = null;
        }
        
        Log.d(TAG, "Prefill finished: " + frames + " frames, seq=" + sequence);
    }
    
    // ========================================================================
    // Lifecycle Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Releases main decoder resources (must be called with lock held).
     */
    private void releaseMainDecoderLocked() {
        if (mMainDecoder != null) {
            try {
                mMainDecoder.release();
                Log.d(TAG, "Main decoder released");
            } catch (Exception e) {
                Log.w(TAG, "Error releasing main decoder", e);
            }
            mMainDecoder = null;
        }
    }
    
    /**
     * Releases all decoder resources.
     * Thread-safe: acquires lock and cancels prefill.
     * 
     * <p>After release, the decoder manager cannot be used again unless
     * {@link #initialize(String, int, int)} is called again.</p>
     */
    public void release() {
        // Cancel any ongoing prefill first
        cancelPrefill();
        
        mMainDecoderLock.lock();
        try {
            releaseMainDecoderLocked();
            mCurrentFilePath = null;
            mConsecutiveErrors.set(0);
            mIsInErrorState.set(false);
            Log.d(TAG, "DecoderManager released");
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    // ========================================================================
    // Debug Methods
    // ========================================================================
    
    /**
     * Returns debug information about the decoder state.
     * 
     * @return Debug string with current state
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("DecoderManager Debug Info:\n");
        sb.append("  File: ").append(mCurrentFilePath != null ? mCurrentFilePath : "null").append("\n");
        sb.append("  Format: ").append(mSampleRate).append("Hz, ").append(mChannels).append("ch\n");
        sb.append("  Main decoder: ").append(mMainDecoder != null ? "initialized" : "null").append("\n");
        sb.append("  Error state: ").append(mIsInErrorState.get()).append("\n");
        sb.append("  Consecutive errors: ").append(mConsecutiveErrors.get()).append("\n");
        sb.append("  Prefilling: ").append(mIsPrefilling.get()).append("\n");
        sb.append("  Prefill sequence: ").append(mPrefillSequence.get()).append("\n");
        return sb.toString();
    }
}