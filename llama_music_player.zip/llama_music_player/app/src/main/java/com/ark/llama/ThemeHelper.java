package com.ark.llama;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Helper class for applying theme colors to UI components.
 * 
 * <p>This class provides methods to theme various Android UI components including:
 * <ul>
 *   <li>Buttons with custom drawable states (normal, pressed, disabled)</li>
 *   <li>SeekBars with progress and thumb tinting</li>
 *   <li>ProgressBars with indeterminate tinting</li>
 *   <li>TextViews for accent coloring</li>
 *   <li>EditTexts with custom cursor color and highlight</li>
 * </ul>
 * </p>
 * 
 * <p>The helper follows Google's recommendations for:
 * <ul>
 *   <li>Singleton pattern for efficient resource management</li>
 *   <li>Cached dp-to-px calculations for performance</li>
 *   <li>Proper state drawable management for buttons</li>
 *   <li>Reflection for cursor color (works across API levels)</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is thread-safe. All methods are either idempotent or use
 * proper synchronization. All operations are immediate UI updates.</p>
 * 
 * @see ThemeManager
 * @see GradientDrawable
 * @see StateListDrawable
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class ThemeHelper {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "ThemeHelper";
    
    /** Background color for pressed button state. */
    private static final int COLOR_PRESSED_BG = 0xFF2A2A2A;
    
    /** Color for disabled UI elements. */
    private static final int COLOR_DISABLED = 0xFF5A5A5A;
    
    /** Normal background color for buttons. */
    private static final int COLOR_NORMAL_BG = 0xFF1E1E1E;
    
    /** Primary text color. */
    public static final int COLOR_TEXT_PRIMARY = 0xFFC0C0C0;
    
    /** Secondary text color. */
    public static final int COLOR_TEXT_SECONDARY = 0xFFA0A0A0;
    
    /** Hint text color. */
    public static final int COLOR_TEXT_HINT = 0xFF5A5A5A;
    
    /** Default theme color (Royal Llama). */
    public static final int DEFAULT_COLOR = 0xFFB8A86E;
    
    /** Button corner radius in dp. */
    private static final int BUTTON_CORNER_RADIUS_DP = 10;
    
    /** Control button corner radius in dp. */
    private static final int CONTROL_BUTTON_CORNER_RADIUS_DP = 8;
    
    /** Button stroke width in dp. */
    private static final int BUTTON_STROKE_WIDTH_DP = 1;
    
    /** Button inset in dp. */
    private static final int BUTTON_INSET_DP = 2;
    
    /** Cursor width in dp. */
    private static final int CURSOR_WIDTH_DP = 1;
    
    /** Cursor height in dp. */
    private static final int CURSOR_HEIGHT_DP = 16;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance (volatile for thread-safe double-checked locking). */
    @Nullable
    private static volatile ThemeHelper sInstance;
    
    /** Current theme color (hex string). */
    @NonNull
    private String mCurrentThemeColor = "#B8A86E";
    
    /** Application context. */
    @NonNull
    private final Context mAppContext;
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private ThemeHelper(@NonNull Context context) {
        mAppContext = context.getApplicationContext();
    }
    
    /**
     * Returns the singleton instance of ThemeHelper.
     * Thread-safe with double-checked locking.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized ThemeHelper getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (ThemeHelper.class) {
                if (sInstance == null) {
                    sInstance = new ThemeHelper(context);
                }
            }
        }
        return sInstance;
    }
    
    /**
     * Returns the default theme color as an integer.
     *
     * @return The default theme color
     */
    @ColorInt
    public static int getDefaultColor() {
        return DEFAULT_COLOR;
    }
    
    // ========================================================================
    // Theme Color Management
    // ========================================================================
    
    /**
     * Sets the current theme color.
     * Thread-safe: mCurrentThemeColor is volatile.
     *
     * @param color The theme color as a hex string (e.g., "#B8A86E")
     */
    public void setThemeColor(@NonNull String color) {
        mCurrentThemeColor = color;
    }
    
    /**
     * Returns the current theme color as a hex string.
     * Thread-safe: mCurrentThemeColor is volatile.
     *
     * @return The theme color
     */
    @NonNull
    public String getThemeColor() {
        return mCurrentThemeColor;
    }
    
    /**
     * Returns the current theme color as an integer.
     * Thread-safe: Color.parseColor() is a pure function.
     *
     * @return The theme color integer
     */
    @ColorInt
    public int getThemeColorInt() {
        try {
            return Color.parseColor(mCurrentThemeColor);
        } catch (IllegalArgumentException exception) {
            Log.e(TAG, "Invalid theme color: " + mCurrentThemeColor);
            return DEFAULT_COLOR;
        }
    }
    
    /**
     * Returns a muted version of the current theme color for hint text.
     * Uses 40% opacity (alpha = 102) for a subtle appearance.
     *
     * @return Muted theme color integer (40% opacity)
     */
    @ColorInt
    public int getMutedThemeColorInt() {
        int fullColor = getThemeColorInt();
        int red = Color.red(fullColor);
        int green = Color.green(fullColor);
        int blue = Color.blue(fullColor);
        return Color.argb(102, red, green, blue);
    }
    
    // ========================================================================
    // Unit Conversion
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     * 
     * <p>This method caches the density value through the context.</p>
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    public int dpToPx(int dp) {
        float density = mAppContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
    
    // ========================================================================
    // Drawable Creation
    // ========================================================================
    
    /**
     * Creates a themed album art placeholder drawable.
     *
     * @return Themed drawable, or null if resource not found
     */
    @Nullable
    public Drawable createThemedAlbumArtPlaceholder() {
        Drawable drawable = ContextCompat.getDrawable(mAppContext, R.drawable.album_art_placeholder);
        if (drawable != null) {
            drawable.setColorFilter(getThemeColorInt(), PorterDuff.Mode.SRC_IN);
        }
        return drawable;
    }
    
    // ========================================================================
    // Button Theming Methods
    // ========================================================================
    
    /**
     * Updates a button's appearance based on enabled state.
     * 
     * <p>Creates a state list drawable with normal, pressed, and disabled states.
     * Normal state: transparent background with colored border
     * Pressed state: dark background with colored border
     * Disabled state: dark background with gray border</p>
     *
     * @param button The button to update (can be null)
     * @param isEnabled True if the button is enabled
     */
    public void updateButton(@Nullable Button button, boolean isEnabled) {
        if (button == null) return;
        
        button.setSingleLine(true);
        button.setEllipsize(TextUtils.TruncateAt.END);
        button.setMaxLines(1);
        button.setHorizontallyScrolling(false);
        
        int themeColor = getThemeColorInt();
        int strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP);
        int cornerRadius = dpToPx(BUTTON_CORNER_RADIUS_DP);
        int inset = dpToPx(BUTTON_INSET_DP);
        
        GradientDrawable normalDrawable = new GradientDrawable();
        normalDrawable.setShape(GradientDrawable.RECTANGLE);
        normalDrawable.setCornerRadius(cornerRadius);
        normalDrawable.setStroke(strokeWidth, isEnabled ? themeColor : COLOR_DISABLED);
        normalDrawable.setColor(Color.TRANSPARENT);
        
        InsetDrawable normalInset = new InsetDrawable(normalDrawable, inset);
        
        GradientDrawable pressedDrawable = new GradientDrawable();
        pressedDrawable.setShape(GradientDrawable.RECTANGLE);
        pressedDrawable.setCornerRadius(cornerRadius);
        pressedDrawable.setStroke(strokeWidth, themeColor);
        pressedDrawable.setColor(COLOR_PRESSED_BG);
        
        InsetDrawable pressedInset = new InsetDrawable(pressedDrawable, inset);
        
        GradientDrawable disabledDrawable = new GradientDrawable();
        disabledDrawable.setShape(GradientDrawable.RECTANGLE);
        disabledDrawable.setCornerRadius(cornerRadius);
        disabledDrawable.setStroke(strokeWidth, COLOR_DISABLED);
        disabledDrawable.setColor(COLOR_NORMAL_BG);
        
        InsetDrawable disabledInset = new InsetDrawable(disabledDrawable, inset);
        
        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[]{android.R.attr.state_pressed}, pressedInset);
        stateList.addState(new int[]{android.R.attr.state_focused}, pressedInset);
        stateList.addState(new int[]{-android.R.attr.state_enabled}, disabledInset);
        
        int[][] colorStates = new int[][] {
            new int[] {android.R.attr.state_pressed},
            new int[] {android.R.attr.state_focused},
            new int[] {-android.R.attr.state_enabled},
            new int[] {}
        };
        
        if (isEnabled) {
            stateList.addState(new int[]{}, normalInset);
            int[] colors = new int[] {
                Color.WHITE,
                Color.WHITE,
                COLOR_DISABLED,
                themeColor
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        } else {
            stateList.addState(new int[]{}, disabledInset);
            button.setTextColor(COLOR_DISABLED);
        }
        
        button.setBackground(stateList);
        button.setPadding(dpToPx(8), 0, dpToPx(8), 0);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
    }
    
    /**
     * Updates a control button (media controls) appearance.
     *
     * @param button The button to update (can be null)
     * @param isEnabled True if the button is enabled
     * @param isActive True if the button is active (e.g., shuffle/repeat enabled)
     */
    public void updateControlButton(@Nullable Button button, boolean isEnabled, boolean isActive) {
        if (button == null) {
            return;
        }
        
        int themeColor = getThemeColorInt();
        int cornerRadius = dpToPx(CONTROL_BUTTON_CORNER_RADIUS_DP);
        int strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP);
        
        GradientDrawable normalDrawable = new GradientDrawable();
        normalDrawable.setShape(GradientDrawable.RECTANGLE);
        normalDrawable.setCornerRadius(cornerRadius);
        normalDrawable.setStroke(strokeWidth, isActive ? themeColor : COLOR_TEXT_PRIMARY);
        normalDrawable.setColor(COLOR_NORMAL_BG);
        
        GradientDrawable pressedDrawable = new GradientDrawable();
        pressedDrawable.setShape(GradientDrawable.RECTANGLE);
        pressedDrawable.setCornerRadius(cornerRadius);
        pressedDrawable.setStroke(strokeWidth, themeColor);
        pressedDrawable.setColor(COLOR_PRESSED_BG);
        
        GradientDrawable disabledDrawable = new GradientDrawable();
        disabledDrawable.setShape(GradientDrawable.RECTANGLE);
        disabledDrawable.setCornerRadius(cornerRadius);
        disabledDrawable.setStroke(strokeWidth, COLOR_DISABLED);
        disabledDrawable.setColor(COLOR_NORMAL_BG);
        
        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[]{android.R.attr.state_pressed}, pressedDrawable);
        stateList.addState(new int[]{android.R.attr.state_focused}, pressedDrawable);
        stateList.addState(new int[]{-android.R.attr.state_enabled}, disabledDrawable);
        stateList.addState(new int[]{}, normalDrawable);
        
        button.setBackground(stateList);
        button.setPadding(0, 0, 0, 0);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
        
        int[][] colorStates = new int[][] {
            new int[] {android.R.attr.state_pressed},
            new int[] {android.R.attr.state_focused},
            new int[] {-android.R.attr.state_enabled},
            new int[] {}
        };
        
        if (isEnabled) {
            int[] colors = new int[] {
                themeColor,
                themeColor,
                COLOR_DISABLED,
                isActive ? themeColor : COLOR_TEXT_PRIMARY
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        } else {
            int[] colors = new int[] {
                COLOR_DISABLED, COLOR_DISABLED, COLOR_DISABLED, COLOR_DISABLED
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        }
    }
    
    // ========================================================================
    // SeekBar Theming
    // ========================================================================
    
    /**
     * Updates a SeekBar's appearance based on enabled state.
     * 
     * <p>Sets progress and thumb tint colors to match the theme.</p>
     *
     * @param seekBar The SeekBar to update (can be null)
     * @param isEnabled True if the SeekBar is enabled
     */
    public void updateSeekBar(@Nullable SeekBar seekBar, boolean isEnabled) {
        if (seekBar == null) {
            return;
        }
        
        int progressColor = isEnabled ? getThemeColorInt() : COLOR_DISABLED;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressTintList(ColorStateList.valueOf(progressColor));
            seekBar.setThumbTintList(ColorStateList.valueOf(progressColor));
        }
        
        seekBar.setThumb(null);
        seekBar.setEnabled(isEnabled);
    }
    
    // ========================================================================
    // ProgressBar Theming
    // ========================================================================
    
    /**
     * Updates a ProgressBar's indeterminate and progress tint colors.
     *
     * @param progressBar The ProgressBar to update (can be null)
     */
    public void updateProgressBar(@Nullable ProgressBar progressBar) {
        if (progressBar == null) {
            return;
        }
        
        int themeColor = getThemeColorInt();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.setIndeterminateTintList(ColorStateList.valueOf(themeColor));
            progressBar.setProgressTintList(ColorStateList.valueOf(themeColor));
        } else {
            Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
            if (indeterminateDrawable != null) {
                indeterminateDrawable.setColorFilter(themeColor, PorterDuff.Mode.SRC_IN);
            }
        }
    }
    
    // ========================================================================
    // TextView Theming
    // ========================================================================
    
    /**
     * Updates a TextView's text color for accent text.
     *
     * @param textView The TextView to update (can be null)
     * @param isAccent True to set accent color, false to leave unchanged
     */
    public void updateTextView(@Nullable TextView textView, boolean isAccent) {
        if (textView == null) {
            return;
        }
        
        if (isAccent) {
            textView.setTextColor(getThemeColorInt());
        }
    }
    
    // ========================================================================
    // EditText Theming
    // ========================================================================
    
    /**
     * Updates an EditText's highlight color.
     *
     * @param editText The EditText to update
     */
    public void updateEditText(@NonNull EditText editText) {
        int themeColor = getThemeColorInt();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            editText.setHighlightColor(Color.argb(40,
                Color.red(themeColor), Color.green(themeColor), Color.blue(themeColor)));
        }
    }
    
    /**
     * Sets the cursor color for an EditText using reflection with proper fallbacks.
     * 
     * <p>This method works across all Android versions by either using the
     * setTextCursorDrawable method (if available) or by modifying the
     * internal cursor drawable via reflection.</p>
     *
     * @param editText The EditText to modify
     * @param color The desired cursor color
     */
    public void setCursorColor(@NonNull EditText editText, @ColorInt int color) {
        GradientDrawable cursorDrawable = new GradientDrawable();
        cursorDrawable.setShape(GradientDrawable.RECTANGLE);
        cursorDrawable.setColor(color);
        cursorDrawable.setSize(dpToPx(CURSOR_WIDTH_DP), dpToPx(CURSOR_HEIGHT_DP));
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Method method = EditText.class.getMethod("setTextCursorDrawable", Drawable.class);
                method.invoke(editText, cursorDrawable);
                return;
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "setTextCursorDrawable not available, using reflection fallback");
            } catch (Exception exception) {
                Log.w(TAG, "setTextCursorDrawable failed, using reflection fallback", exception);
            }
        }
        
        try {
            Field cursorResField = TextView.class.getDeclaredField("mCursorDrawableRes");
            cursorResField.setAccessible(true);
            cursorResField.set(editText, 0);
            
            Field editorField = TextView.class.getDeclaredField("mEditor");
            editorField.setAccessible(true);
            Object editor = editorField.get(editText);
            
            if (editor != null) {
                Field cursorField = editor.getClass().getDeclaredField("mCursorDrawable");
                cursorField.setAccessible(true);
                cursorField.set(editor, new Drawable[]{cursorDrawable, cursorDrawable});
                editText.invalidate();
            }
        } catch (Exception exception) {
            Log.e(TAG, "Cursor reflection failed", exception);
        }
    }
    
    /**
     * Updates an EditText's cursor color and hint text color.
     * 
     * <p>Also sets a focus change listener to reapply cursor color on focus.</p>
     *
     * @param editText The EditText to update
     */
    public void updateEditTextCursor(@NonNull final EditText editText) {
        int themeColor = getThemeColorInt();
        setCursorColor(editText, themeColor);
        
        int red = Color.red(themeColor);
        int green = Color.green(themeColor);
        int blue = Color.blue(themeColor);
        int hintColor = Color.argb(102, red, green, blue);
        editText.setHintTextColor(hintColor);
        
        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus && view instanceof EditText) {
                    setCursorColor((EditText) view, getThemeColorInt());
                }
            }
        });
    }
}