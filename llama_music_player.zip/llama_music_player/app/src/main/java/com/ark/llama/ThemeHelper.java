package com.ark.llama;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Applies the current theme color to UI components.
 *
 * <p>The helper themes buttons with three states (normal, pressed,
 * disabled), tints the progress and thumb of SeekBars, tints the
 * indeterminate and determinate state of ProgressBars, and applies an
 * accent color to TextViews and EditTexts. It also provides the
 * themed album art placeholder used by both the player and the
 * notification.</p>
 *
 * <p>Distance conversions use the density reported by the application
 * context. Cursor coloring on EditTexts uses the public
 * {@code setTextCursorDrawable} method on API 29 and later and falls
 * back to reflection against the framework's private cursor drawable
 * fields on earlier releases; when reflection fails, the cursor keeps
 * the system default color.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every method touches Android view or drawable state and runs on
 * the main thread. The current theme color is held in a plain field
 * written by {@link #setThemeColor(String)} and read by
 * {@link #getThemeColor()} and {@link #getThemeColorInt()}; callers
 * that write the color from a non-main thread must coordinate with the
 * main thread themselves.</p>
 *
 * @see ThemeManager
 * @see GradientDrawable
 * @see StateListDrawable
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class ThemeHelper {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "ThemeHelper";

    /** Background color applied to a pressed button. */
    private static final int COLOR_PRESSED_BG = 0xFF2A2A2A;

    /** Color applied to disabled UI elements. */
    private static final int COLOR_DISABLED = 0xFF5A5A5A;

    /** Background color applied to a normal button. */
    private static final int COLOR_NORMAL_BG = 0xFF1E1E1E;

    /** Primary text color. */
    public static final int COLOR_TEXT_PRIMARY = 0xFFC0C0C0;

    /** Secondary text color. */
    public static final int COLOR_TEXT_SECONDARY = 0xFFA0A0A0;

    /** Hint text color. */
    public static final int COLOR_TEXT_HINT = 0xFF5A5A5A;

    /** Default theme color. */
    public static final int DEFAULT_COLOR = 0xFFB8A86E;

    /** Corner radius of themed buttons, in density-independent pixels. */
    private static final int BUTTON_CORNER_RADIUS_DP = 10;

    /** Corner radius of themed control buttons, in density-independent pixels. */
    private static final int CONTROL_BUTTON_CORNER_RADIUS_DP = 8;

    /** Stroke width of themed buttons, in density-independent pixels. */
    private static final int BUTTON_STROKE_WIDTH_DP = 1;

    /** Inset applied to themed buttons, in density-independent pixels. */
    private static final int BUTTON_INSET_DP = 2;

    /** Cursor width, in density-independent pixels. */
    private static final int CURSOR_WIDTH_DP = 1;

    /** Cursor height, in density-independent pixels. */
    private static final int CURSOR_HEIGHT_DP = 16;

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile ThemeHelper sInstance;

    /** Current theme color, as a hex string. */
    @NonNull
    private String mCurrentThemeColor = "#B8A86E";

    /** Application context used for resource and density lookups. */
    @NonNull
    private final Context mAppContext;

    /**
     * Constructs the singleton.
     *
     * @param context A context; the application context is retained
     */
    private ThemeHelper(@NonNull Context context) {
        mAppContext = context.getApplicationContext();
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static synchronized ThemeHelper getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (ThemeHelper.class) {
                if (sInstance == null) {
                    sInstance = new ThemeHelper(context);
                }
            }
        }
        return sInstance;
    }

    /**
     * Returns the default theme color.
     *
     * @return The default theme color as an integer
     */
    @ColorInt
    public static int getDefaultColor() {
        return DEFAULT_COLOR;
    }

    // ========================================================================
    // Theme Color Management
    // ========================================================================

    /**
     * Sets the current theme color.
     *
     * @param color Theme color as a hex string, such as
     *        {@code "#B8A86E"}
     */
    public void setThemeColor(@NonNull String color) {
        mCurrentThemeColor = color;
    }

    /**
     * Returns the current theme color as a hex string.
     *
     * @return The current theme color
     */
    @NonNull
    public String getThemeColor() {
        return mCurrentThemeColor;
    }

    /**
     * Returns the current theme color as an integer.
     *
     * <p>When the stored hex string cannot be parsed, the default color
     * is returned.</p>
     *
     * @return The current theme color as an integer
     */
    @ColorInt
    public int getThemeColorInt() {
        try {
            return Color.parseColor(mCurrentThemeColor);
        } catch (IllegalArgumentException exception) {
            Log.e(TAG, "Invalid theme color: " + mCurrentThemeColor);
            return DEFAULT_COLOR;
        }
    }

    /**
     * Returns a muted version of the current theme color, at 40 percent
     * opacity, for hint text.
     *
     * @return The muted theme color as an integer
     */
    @ColorInt
    public int getMutedThemeColorInt() {
        int fullColor = getThemeColorInt();
        int red = Color.red(fullColor);
        int green = Color.green(fullColor);
        int blue = Color.blue(fullColor);
        return Color.argb(102, red, green, blue);
    }

    // ========================================================================
    // Unit Conversion
    // ========================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    public int dpToPx(int dp) {
        float density = mAppContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    // ========================================================================
    // Drawable Creation
    // ========================================================================

    /**
     * Returns the album art placeholder drawable tinted with the current
     * theme color.
     *
     * @return The themed placeholder drawable, or null when the resource
     *         cannot be resolved
     */
    @Nullable
    public Drawable createThemedAlbumArtPlaceholder() {
        Drawable drawable = ContextCompat.getDrawable(
            mAppContext, R.drawable.album_art_placeholder);
        if (drawable != null) {
            drawable.setColorFilter(getThemeColorInt(), PorterDuff.Mode.SRC_IN);
        }
        return drawable;
    }

    // ========================================================================
    // Button Theming Methods
    // ========================================================================

    /**
     * Applies the current theme to the given button.
     *
     * <p>Builds a state-list drawable with a transparent normal state,
     * a pressed state with the theme color as its stroke and a dark
     * background, and a disabled state with the disabled color as its
     * stroke and a dark background. The button's text color matches the
     * theme in the normal and pressed states and the disabled color when
     * the button is disabled. The button is configured for single-line
     * text, centered gravity, and no font padding.</p>
     *
     * @param button Button to update, or null
     * @param isEnabled True when the button is enabled
     */
    public void updateButton(@Nullable Button button, boolean isEnabled) {
        if (button == null) {
            return;
        }

        button.setSingleLine(true);
        button.setEllipsize(TextUtils.TruncateAt.END);
        button.setMaxLines(1);
        button.setHorizontallyScrolling(false);

        int themeColor = getThemeColorInt();
        int strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP);
        int cornerRadius = dpToPx(BUTTON_CORNER_RADIUS_DP);
        int inset = dpToPx(BUTTON_INSET_DP);

        GradientDrawable normalDrawable = new GradientDrawable();
        normalDrawable.setShape(GradientDrawable.RECTANGLE);
        normalDrawable.setCornerRadius(cornerRadius);
        normalDrawable.setStroke(strokeWidth, isEnabled ? themeColor : COLOR_DISABLED);
        normalDrawable.setColor(Color.TRANSPARENT);

        InsetDrawable normalInset = new InsetDrawable(normalDrawable, inset);

        GradientDrawable pressedDrawable = new GradientDrawable();
        pressedDrawable.setShape(GradientDrawable.RECTANGLE);
        pressedDrawable.setCornerRadius(cornerRadius);
        pressedDrawable.setStroke(strokeWidth, themeColor);
        pressedDrawable.setColor(COLOR_PRESSED_BG);

        InsetDrawable pressedInset = new InsetDrawable(pressedDrawable, inset);

        GradientDrawable disabledDrawable = new GradientDrawable();
        disabledDrawable.setShape(GradientDrawable.RECTANGLE);
        disabledDrawable.setCornerRadius(cornerRadius);
        disabledDrawable.setStroke(strokeWidth, COLOR_DISABLED);
        disabledDrawable.setColor(COLOR_NORMAL_BG);

        InsetDrawable disabledInset = new InsetDrawable(disabledDrawable, inset);

        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[] {android.R.attr.state_pressed}, pressedInset);
        stateList.addState(new int[] {android.R.attr.state_focused}, pressedInset);
        stateList.addState(new int[] {-android.R.attr.state_enabled}, disabledInset);

        int[][] colorStates = new int[][] {
            new int[] {android.R.attr.state_pressed},
            new int[] {android.R.attr.state_focused},
            new int[] {-android.R.attr.state_enabled},
            new int[] {}
        };

        if (isEnabled) {
            stateList.addState(new int[] {}, normalInset);
            int[] colors = new int[] {
                Color.WHITE,
                Color.WHITE,
                COLOR_DISABLED,
                themeColor
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        } else {
            stateList.addState(new int[] {}, disabledInset);
            button.setTextColor(COLOR_DISABLED);
        }

        button.setBackground(stateList);
        button.setPadding(dpToPx(8), 0, dpToPx(8), 0);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
    }

    /**
     * Applies the current theme to the given control button.
     *
     * <p>Every state uses a solid dark background. The stroke is the
     * theme color when the button is active, the primary text color when
     * the button is inactive, and the disabled color when the button is
     * disabled. The text color follows the same scheme.</p>
     *
     * @param button Button to update, or null
     * @param isEnabled True when the button is enabled
     * @param isActive True when the button represents an active mode,
     *        such as an enabled shuffle or repeat
     */
    public void updateControlButton(@Nullable Button button, boolean isEnabled,
                                    boolean isActive) {
        if (button == null) {
            return;
        }

        int themeColor = getThemeColorInt();
        int cornerRadius = dpToPx(CONTROL_BUTTON_CORNER_RADIUS_DP);
        int strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP);

        GradientDrawable normalDrawable = new GradientDrawable();
        normalDrawable.setShape(GradientDrawable.RECTANGLE);
        normalDrawable.setCornerRadius(cornerRadius);
        normalDrawable.setStroke(strokeWidth,
            isActive ? themeColor : COLOR_TEXT_PRIMARY);
        normalDrawable.setColor(COLOR_NORMAL_BG);

        GradientDrawable pressedDrawable = new GradientDrawable();
        pressedDrawable.setShape(GradientDrawable.RECTANGLE);
        pressedDrawable.setCornerRadius(cornerRadius);
        pressedDrawable.setStroke(strokeWidth, themeColor);
        pressedDrawable.setColor(COLOR_PRESSED_BG);

        GradientDrawable disabledDrawable = new GradientDrawable();
        disabledDrawable.setShape(GradientDrawable.RECTANGLE);
        disabledDrawable.setCornerRadius(cornerRadius);
        disabledDrawable.setStroke(strokeWidth, COLOR_DISABLED);
        disabledDrawable.setColor(COLOR_NORMAL_BG);

        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[] {android.R.attr.state_pressed}, pressedDrawable);
        stateList.addState(new int[] {android.R.attr.state_focused}, pressedDrawable);
        stateList.addState(new int[] {-android.R.attr.state_enabled}, disabledDrawable);
        stateList.addState(new int[] {}, normalDrawable);

        button.setBackground(stateList);
        button.setPadding(0, 0, 0, 0);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);

        int[][] colorStates = new int[][] {
            new int[] {android.R.attr.state_pressed},
            new int[] {android.R.attr.state_focused},
            new int[] {-android.R.attr.state_enabled},
            new int[] {}
        };

        if (isEnabled) {
            int[] colors = new int[] {
                themeColor,
                themeColor,
                COLOR_DISABLED,
                isActive ? themeColor : COLOR_TEXT_PRIMARY
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        } else {
            int[] colors = new int[] {
                COLOR_DISABLED, COLOR_DISABLED, COLOR_DISABLED, COLOR_DISABLED
            };
            button.setTextColor(new ColorStateList(colorStates, colors));
        }
    }

    // ========================================================================
    // SeekBar Theming
    // ========================================================================

    /**
     * Applies the current theme to the given SeekBar's progress and
     * thumb.
     *
     * <p>The thumb drawable is cleared and the SeekBar's enabled state is
     * set to the given value. The progress and thumb tint are applied on
     * API 21 and later; on earlier releases, the default tint is
     * kept.</p>
     *
     * @param seekBar SeekBar to update, or null
     * @param isEnabled True when the SeekBar is enabled
     */
    public void updateSeekBar(@Nullable SeekBar seekBar, boolean isEnabled) {
        if (seekBar == null) {
            return;
        }

        int progressColor = isEnabled ? getThemeColorInt() : COLOR_DISABLED;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressTintList(ColorStateList.valueOf(progressColor));
            seekBar.setThumbTintList(ColorStateList.valueOf(progressColor));
        }

        seekBar.setThumb(null);
        seekBar.setEnabled(isEnabled);
    }

    // ========================================================================
    // ProgressBar Theming
    // ========================================================================

    /**
     * Applies the current theme to the given ProgressBar's indeterminate
     * and determinate tint.
     *
     * @param progressBar ProgressBar to update, or null
     */
    public void updateProgressBar(@Nullable ProgressBar progressBar) {
        if (progressBar == null) {
            return;
        }

        int themeColor = getThemeColorInt();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.setIndeterminateTintList(ColorStateList.valueOf(themeColor));
            progressBar.setProgressTintList(ColorStateList.valueOf(themeColor));
        } else {
            Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
            if (indeterminateDrawable != null) {
                indeterminateDrawable.setColorFilter(themeColor, PorterDuff.Mode.SRC_IN);
            }
        }
    }

    // ========================================================================
    // TextView Theming
    // ========================================================================

    /**
     * Applies the current theme to the given TextView when it is marked
     * as accent text.
     *
     * @param textView TextView to update, or null
     * @param isAccent True to apply the theme color
     */
    public void updateTextView(@Nullable TextView textView, boolean isAccent) {
        if (textView == null) {
            return;
        }

        if (isAccent) {
            textView.setTextColor(getThemeColorInt());
        }
    }

    // ========================================================================
    // EditText Theming
    // ========================================================================

    /**
     * Applies the current theme to the given EditText's selection
     * highlight.
     *
     * @param editText EditText to update
     */
    public void updateEditText(@NonNull EditText editText) {
        int themeColor = getThemeColorInt();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            editText.setHighlightColor(Color.argb(40,
                Color.red(themeColor), Color.green(themeColor), Color.blue(themeColor)));
        }
    }

    /**
     * Sets the cursor color of the given EditText.
     *
     * <p>On API 29 and later, the public
     * {@code setTextCursorDrawable} method is used. On earlier releases,
     * the framework's private cursor drawable fields are set through
     * reflection. When reflection fails, the cursor keeps the system
     * default color and the failure is logged.</p>
     *
     * @param editText EditText to update
     * @param color Color to apply to the cursor
     */
    public void setCursorColor(@NonNull EditText editText, @ColorInt int color) {
        GradientDrawable cursorDrawable = new GradientDrawable();
        cursorDrawable.setShape(GradientDrawable.RECTANGLE);
        cursorDrawable.setColor(color);
        cursorDrawable.setSize(dpToPx(CURSOR_WIDTH_DP), dpToPx(CURSOR_HEIGHT_DP));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Method method = EditText.class.getMethod(
                    "setTextCursorDrawable", Drawable.class);
                method.invoke(editText, cursorDrawable);
                return;
            } catch (NoSuchMethodException exception) {
                Log.d(TAG, "setTextCursorDrawable not available, "
                    + "using reflection fallback");
            } catch (Exception exception) {
                Log.w(TAG, "setTextCursorDrawable failed, "
                    + "using reflection fallback", exception);
            }
        }

        try {
            Field cursorResField = TextView.class.getDeclaredField("mCursorDrawableRes");
            cursorResField.setAccessible(true);
            cursorResField.set(editText, 0);

            Field editorField = TextView.class.getDeclaredField("mEditor");
            editorField.setAccessible(true);
            Object editor = editorField.get(editText);

            if (editor != null) {
                Field cursorField = editor.getClass().getDeclaredField("mCursorDrawable");
                cursorField.setAccessible(true);
                cursorField.set(editor, new Drawable[] {cursorDrawable, cursorDrawable});
                editText.invalidate();
            }
        } catch (Exception exception) {
            Log.e(TAG, "Cursor reflection failed", exception);
        }
    }

    /**
     * Applies the current theme to the given EditText's cursor and hint
     * text color, and installs a focus-change listener that reapplies
     * the cursor color when the EditText gains focus.
     *
     * @param editText EditText to update
     */
    public void updateEditTextCursor(@NonNull final EditText editText) {
        int themeColor = getThemeColorInt();
        setCursorColor(editText, themeColor);

        int red = Color.red(themeColor);
        int green = Color.green(themeColor);
        int blue = Color.blue(themeColor);
        int hintColor = Color.argb(102, red, green, blue);
        editText.setHintTextColor(hintColor);

        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus && view instanceof EditText) {
                    setCursorColor((EditText) view, getThemeColorInt());
                }
            }
        });
    }
}