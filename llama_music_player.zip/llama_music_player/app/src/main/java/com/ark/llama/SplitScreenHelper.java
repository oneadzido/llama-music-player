package com.ark.llama;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Scales the vertical margins and paddings of a view hierarchy for
 * short windows.
 *
 * <p>Each activity that uses this helper constructs one instance in
 * {@code onCreate}, calls {@link #capture(View)} once on the root view
 * to record every view's original vertical spacing, and then calls
 * {@link #applyForHeight(int)} on every configuration change and once
 * after {@code capture}. The helper walks its recorded list of views
 * and writes {@code original * factor} into each view's
 * {@link ViewGroup.MarginLayoutParams} and padding slots.</p>
 *
 * <h3>Factor Bands</h3>
 * <p>The factor is a pure function of the window height in
 * density-independent pixels:</p>
 * <table>
 *   <tr><th>Window height</th><th>Factor</th><th>Effect</th></tr>
 *   <tr><td>&ge; {@link #FULL_HEIGHT_DP}</td><td>1.0</td>
 *       <td>XML values applied as-is.</td></tr>
 *   <tr><td>&ge; {@link #TIGHT_HEIGHT_DP}</td><td>0.75</td>
 *       <td>Mild tightening for windows between full and split
 *           heights.</td></tr>
 *   <tr><td>&ge; {@link #COMPACT_HEIGHT_DP}</td><td>0.5</td>
 *       <td>Half spacing for split-screen windows on a phone.</td></tr>
 *   <tr><td>below</td><td>0.25</td>
 *       <td>Barely any spacing for very short windows.</td></tr>
 * </table>
 *
 * <h3>Restoring Originals</h3>
 * <p>The helper always writes {@code original * factor} from its
 * recorded originals, so leaving a short window is simply calling
 * {@link #applyForHeight(int)} with a height in the full-height band.
 * The helper does not accumulate compounded factors across calls.</p>
 *
 * <h3>Horizontal Spacing</h3>
 * <p>Only vertical spacing is scaled. Horizontal margins and paddings
 * are left alone: the concern this helper addresses is vertical
 * crowding when the window shrinks, and shrinking horizontal spacing
 * risks text crowding on otherwise-wide split-screen layouts.</p>
 *
 * <h3>Weak References</h3>
 * <p>Records hold views by weak reference, so a helper that outlives a
 * view — the case during activity teardown, when the helper is still
 * in the field while the view hierarchy is being released — does not
 * keep the view alive. Pruning of dead records happens on the next
 * {@link #applyForHeight(int)}.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. The helper mutates
 * layout parameters and view padding, both of which must be written on
 * the main thread.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — {@link #mRecords} is populated only by {@link #capture(View)}.
 *       Every other method reads but never adds records.</li>
 *   <li>I2 — Each view appears at most once in {@link #mRecords}. A
 *       second {@code capture} on the same root clears the previous
 *       list before walking the tree, so stale records cannot survive.</li>
 *   <li>I3 — A record's stored original values are the values observed
 *       at capture time. They are never updated after capture.</li>
 *   <li>I4 — {@link #applyForHeight(int)} writes every recorded view on
 *       every call, even when the factor has not changed since the
 *       previous call. Layout parameters are cheap to write and the
 *       write always recomputes from the original, so a missed call
 *       cannot drift.</li>
 * </ul>
 *
 * @see MusicPlayer
 * @see FolderManager
 * @see PlaylistActivity
 * @see EqualizerActivity
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class SplitScreenHelper {

    // ============================================================================
    // Constants
    // ============================================================================

    /**
     * Window height at or above which the factor is 1.0.
     */
    private static final int FULL_HEIGHT_DP = 600;

    /**
     * Window height at or above which the factor is 0.75.
     */
    private static final int TIGHT_HEIGHT_DP = 480;

    /**
     * Window height at or above which the factor is 0.5.
     */
    private static final int COMPACT_HEIGHT_DP = 400;

    /** Factor applied at and above {@link #FULL_HEIGHT_DP}. */
    private static final float FACTOR_FULL = 1.0f;

    /** Factor applied at and above {@link #TIGHT_HEIGHT_DP}. */
    private static final float FACTOR_TIGHT = 0.75f;

    /** Factor applied at and above {@link #COMPACT_HEIGHT_DP}. */
    private static final float FACTOR_COMPACT = 0.5f;

    /** Factor applied below {@link #COMPACT_HEIGHT_DP}. */
    private static final float FACTOR_MINIMAL = 0.25f;

    // ============================================================================
    // Records
    // ============================================================================

    /**
     * Holds the original vertical spacing of a single view.
     *
     * <p>Captured once by {@link #capture(View)} and never updated. The
     * {@link #viewRef} is weak so a record that outlives its view does
     * not keep the view alive.</p>
     */
    private static final class MarginRecord {

        /** Weak reference to the recorded view. */
        @NonNull
        final WeakReference<View> viewRef;

        /** Original top margin in pixels, or 0 when the view has no margin params. */
        final int topMargin;

        /** Original bottom margin in pixels, or 0 when the view has no margin params. */
        final int bottomMargin;

        /** Original top padding in pixels. */
        final int paddingTop;

        /** Original bottom padding in pixels. */
        final int paddingBottom;

        /** True when the view's layout params are margin params. */
        final boolean hasMarginParams;

        /**
         * Constructs a record for the given view with the given
         * original values.
         *
         * @param view View the record belongs to
         * @param topMargin Original top margin
         * @param bottomMargin Original bottom margin
         * @param paddingTop Original top padding
         * @param paddingBottom Original bottom padding
         * @param hasMarginParams True when the view has margin params
         */
        MarginRecord(@NonNull View view,
                     int topMargin, int bottomMargin,
                     int paddingTop, int paddingBottom,
                     boolean hasMarginParams) {
            this.viewRef = new WeakReference<>(view);
            this.topMargin = topMargin;
            this.bottomMargin = bottomMargin;
            this.paddingTop = paddingTop;
            this.paddingBottom = paddingBottom;
            this.hasMarginParams = hasMarginParams;
        }

        /**
         * Returns whether the view is still reachable.
         *
         * @return True when the view reference is still live
         */
        boolean isValid() {
            return viewRef.get() != null;
        }
    }

    // ============================================================================
    // Fields
    // ============================================================================

    /** Records of every view captured from the last {@link #capture(View)}. */
    @NonNull
    private final List<MarginRecord> mRecords = new ArrayList<>();

    /** Factor applied by the last {@link #applyForHeight(int)} call, or -1. */
    private float mLastFactor = -1f;

    // ============================================================================
    // Public API
    // ============================================================================

    /**
     * Records the original vertical spacing of every view in the given
     * hierarchy.
     *
     * <p>Clears any previous records first so a second capture on a
     * different root starts from a clean state. The walk is recursive:
     * every {@link ViewGroup} descended into, every non-group view
     * recorded. Root {@code ViewGroup}s are recorded as well, so a
     * padding on the root participates in the scaling.</p>
     *
     * <p>Call this once per activity in {@code onCreate}, after
     * {@code setContentView} has inflated the view hierarchy but before
     * the first {@link #applyForHeight(int)}.</p>
     *
     * @param root Root of the view hierarchy to capture
     */
    public void capture(@NonNull View root) {
        mRecords.clear();
        walk(root);
    }

    /**
     * Scales every recorded view's vertical margins and paddings by the
     * factor for the given window height.
     *
     * <p>Each view is written with {@code original * factor} from its
     * record, so the helper never compounds two calls. A record whose
     * view has been garbage-collected is pruned on the first pass; the
     * remaining records are written in the same pass.</p>
     *
     * <p>Call this from {@code onConfigurationChanged} and once
     * immediately after {@link #capture(View)} so the initial layout
     * reflects the current window.</p>
     *
     * @param screenHeightDp The current window height in dp
     */
    public void applyForHeight(int screenHeightDp) {
        final float factor = factorFor(screenHeightDp);
        if (factor == mLastFactor && mRecords.stream().allMatch(MarginRecord::isValid)) {
            return;
        }
        mLastFactor = factor;

        final Iterator<MarginRecord> iterator = mRecords.iterator();
        while (iterator.hasNext()) {
            final MarginRecord record = iterator.next();
            final View view = record.viewRef.get();
            if (view == null) {
                iterator.remove();
                continue;
            }
            applyRecord(view, record, factor);
        }
    }

    /**
     * Returns the factor currently applied by the last
     * {@link #applyForHeight(int)} call.
     *
     * @return The current factor, or -1 when no call has been made
     */
    public float getCurrentFactor() {
        return mLastFactor;
    }

    // ============================================================================
    // Private Methods
    // ============================================================================

    /**
     * Recursively records the given view and, when it is a
     * {@link ViewGroup}, its children.
     *
     * @param view View to record
     */
    private void walk(@NonNull View view) {
        record(view);

        if (view instanceof ViewGroup) {
            final ViewGroup group = (ViewGroup) view;
            final int childCount = group.getChildCount();
            for (int index = 0; index < childCount; index++) {
                walk(group.getChildAt(index));
            }
        }
    }

    /**
     * Records the original vertical spacing of the given view.
     *
     * @param view View to record
     */
    private void record(@NonNull View view) {
        final ViewGroup.LayoutParams rawParams = view.getLayoutParams();
        final boolean hasMarginParams = rawParams instanceof ViewGroup.MarginLayoutParams;

        final int topMargin;
        final int bottomMargin;
        if (hasMarginParams) {
            final ViewGroup.MarginLayoutParams params =
                (ViewGroup.MarginLayoutParams) rawParams;
            topMargin = params.topMargin;
            bottomMargin = params.bottomMargin;
        } else {
            topMargin = 0;
            bottomMargin = 0;
        }

        mRecords.add(new MarginRecord(
            view,
            topMargin, bottomMargin,
            view.getPaddingTop(), view.getPaddingBottom(),
            hasMarginParams));
    }

    /**
     * Writes the scaled values into the given view's layout parameters
     * and padding.
     *
     * @param view View to update
     * @param record Record holding the view's original values
     * @param factor Factor to apply
     */
    private void applyRecord(@NonNull View view,
                             @NonNull MarginRecord record,
                             float factor) {
        if (record.hasMarginParams) {
            final ViewGroup.LayoutParams rawParams = view.getLayoutParams();
            if (rawParams instanceof ViewGroup.MarginLayoutParams) {
                final ViewGroup.MarginLayoutParams params =
                    (ViewGroup.MarginLayoutParams) rawParams;
                final int scaledTop = Math.round(record.topMargin * factor);
                final int scaledBottom = Math.round(record.bottomMargin * factor);
                if (params.topMargin != scaledTop
                        || params.bottomMargin != scaledBottom) {
                    params.topMargin = scaledTop;
                    params.bottomMargin = scaledBottom;
                    view.setLayoutParams(params);
                }
            }
        }

        final int scaledPaddingTop = Math.round(record.paddingTop * factor);
        final int scaledPaddingBottom = Math.round(record.paddingBottom * factor);
        if (view.getPaddingTop() != scaledPaddingTop
                || view.getPaddingBottom() != scaledPaddingBottom) {
            view.setPadding(
                view.getPaddingLeft(),
                scaledPaddingTop,
                view.getPaddingRight(),
                scaledPaddingBottom);
        }
    }

    /**
     * Returns the factor for the given window height.
     *
     * @param screenHeightDp The current window height in dp
     * @return The factor to apply
     */
    private float factorFor(int screenHeightDp) {
        if (screenHeightDp >= FULL_HEIGHT_DP) {
            return FACTOR_FULL;
        }
        if (screenHeightDp >= TIGHT_HEIGHT_DP) {
            return FACTOR_TIGHT;
        }
        if (screenHeightDp >= COMPACT_HEIGHT_DP) {
            return FACTOR_COMPACT;
        }
        return FACTOR_MINIMAL;
    }
}