package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Service for updating the playlist by scanning selected music folders.
 * 
 * <p>This service provides:
 * <ul>
 *   <li>Background scanning of music folders using MediaStore</li>
 *   <li>Progress reporting during scanning operations</li>
 *   <li>Database caching for performance</li>
 *   <li>Support for both internal and external storage paths</li>
 *   <li>Cancellation support for long-running operations</li>
 *   <li>Integration with NavigationController for global button state management</li>
 *   <li>Targeted loose track addition without full folder scans</li>
 *   <li>Genre loading (Phase 2) for songs with "Unknown Genre"</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All delays use Handler.postDelayed().
 * ExecutorService is properly managed with graceful shutdown.</p>
 * 
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.5
 * @since 1.0
 */
public class PlaylistService {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistService";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for selected folder URIs. */
    private static final String KEY_SELECTED_FOLDERS = "selected_folders_uris";
    
    /** Threshold for progress updates (number of songs between updates). */
    private static final int PROGRESS_THRESHOLD = 10;
    
    /** Minimum time between progress updates (milliseconds). */
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500;
    
    /** Sync complete broadcast action. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";
    
    /** Broadcast action for genre update events during genre loading phase. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";
    
    /** Broadcast action for forcing playlist refresh after genre loading. */
    public static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    
    /** Broadcast action for triggering genre loading from any component. */
    public static final String ACTION_TRIGGER_GENRE_LOADING = "com.ark.llama.TRIGGER_GENRE_LOADING";
    
    /** Shutdown timeout for executor service in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    
    /** Delay before broadcasting playlist updates after loose track addition. */
    private static final int UPDATE_BROADCAST_DELAY_MS = 200;
    
    /** Delay before sending SYNC_COMPLETE after SOFT_UPDATE_PLAYLIST. */
    private static final int SYNC_COMPLETE_DELAY_MS = 400;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    private static PlaylistService sInstance;
    
    /**
     * Returns the singleton instance of PlaylistService.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized PlaylistService getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new PlaylistService(context);
        }
        return sInstance;
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** Single-thread executor for background operations. */
    private final ExecutorService mExecutor;
    
    /** Flag indicating if an update is in progress. */
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);
    
    /** Main thread handler for UI operations and delayed callbacks. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Genre Loading Members (Phase 2)
    // ========================================================================
    
    /** Flag indicating if genre loading is in progress. */
    private final AtomicBoolean mIsGenreLoading = new AtomicBoolean(false);
    
    /** Handler for genre loading UI operations. */
    private final Handler mGenreHandler = new Handler(Looper.getMainLooper());
    
    /** Broadcast receiver for trigger genre loading intents. */
    private BroadcastReceiver mTriggerGenreReceiver;
    
    // ========================================================================
    // Callback Interface
    // ========================================================================
    
    /**
     * Callback interface for playlist update progress and completion.
     */
    public interface UpdateCallback {
        
        /**
         * Called periodically during the update to report progress.
         *
         * @param current Current number of songs processed
         * @param total Total number of songs to process
         */
        void onProgress(int current, int total);
        
        /**
         * Called when the update completes successfully.
         *
         * @param songCount Total number of songs found
         */
        void onComplete(int songCount);
        
        /**
         * Called when an error occurs during the update.
         *
         * @param error The error message
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private PlaylistService(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Updates the playlist by scanning all selected folders.
     *
     * @param callback Callback for progress and completion (can be null)
     */
    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }
    
    /**
     * Updates the playlist silently (without progress callbacks).
     */
    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }
    
    /**
     * Adds a single song as a loose track and triggers a targeted playlist update.
     * 
     * <p>This method maintains the same user experience as folder updates but only
     * processes the single new song (no full folder scan). The song is added to
     * the database as a loose track and the playlist is refreshed with minimal
     * overhead.</p>
     * 
     * <p>The update flow matches the folder update pattern with:
     * <ul>
     *   <li>NavigationController lock acquisition/release</li>
     *   <li>Persistent overlay progress reporting</li>
     *   <li>SOFT_UPDATE_PLAYLIST broadcast for MusicService</li>
     *   <li>DISPLAY_PLAYLIST broadcast for PlaylistActivity</li>
     *   <li>SYNC_COMPLETE broadcast for other components</li>
     * </ul>
     * </p>
     *
     * @param song The song to add as a loose track (must not be null)
     * @param callback Callback for progress and completion (can be null)
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song, @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }
        
        NavigationController.getInstance().beginPlaylistSync();
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Step 1: Add the loose track to database
                    SongDatabase db = SongDatabase.getInstance(mContext);
                    db.insertLooseSong(song);
                    Log.d(TAG, "Loose track added: " + song.getPath());
                    
                    // Step 2: Get all songs (existing + new loose track) - NO FULL SCAN
                    final ArrayList<Song> allSongs = db.getAllSongs();
                    final int totalSongCount = allSongs.size();
                    
                    // Step 3: Single progress update (matches folder update pattern)
                    if (callback != null && !Thread.currentThread().isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }
                    
                    Log.d(TAG, "Playlist updated with loose track. Total songs: " + totalSongCount);
                    
                    // Step 4: Update MusicLibrary and broadcast the same updates as folder update
                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // Refresh MusicLibrary cache
                            refreshMusicLibrary(allSongs);
                            
                            // Send SOFT_UPDATE_PLAYLIST to update MusicService's playlist
                            // This preserves the current song and adds the new one
                            Intent softUpdateIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                            mContext.sendBroadcast(softUpdateIntent);
                            
                            // Update any open PlaylistActivity (matches folder update)
                            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(refreshDisplayIntent);
                            
                            // Send sync complete (matches folder update pattern)
                            Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(syncCompleteIntent);
                            
                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);
                    
                } catch (final Exception e) {
                    Log.e(TAG, "Failed to add loose track", e);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);
                    
                    // Send sync complete even on error (matches folder update pattern)
                    Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }
    
    /**
     * Cancels an ongoing update operation.
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
    }
    
    /**
     * Checks if an update is currently in progress.
     *
     * @return True if updating
     */
    public boolean isUpdating() {
        return mIsUpdating.get();
    }
    
    // ========================================================================
    // Genre Loading Methods (Phase 2)
    // ========================================================================
    
    /**
     * Triggers genre loading for songs with "Unknown Genre".
     * 
     * <p>This method identifies all songs that still have "Unknown Genre" and
     * processes them in a background thread, reading the real genre from ID3
     * tags using CharacterMapper. Each successful genre update triggers a
     * broadcast to refresh the UI for that specific song.</p>
     * 
     * <p>This is Phase 2 of the two-phase loading architecture, providing
     * progressive UI updates as genres become available without blocking the
     * user interface.</p>
     * 
     * <p>Thread-safe: uses AtomicBoolean to prevent concurrent runs.</p>
     * 
     * <p>Can be called directly or via ACTION_TRIGGER_GENRE_LOADING broadcast.</p>
     */
    public void triggerGenreLoading() {
        if (mIsGenreLoading.getAndSet(true)) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }
        
        Log.d(TAG, "Starting genre loading...");
        
        // Refresh MusicLibrary to get latest songs
        MusicLibrary musicLibrary = new MusicLibrary(mContext);
        musicLibrary.refreshCache();
        ArrayList<Song> allSongs = musicLibrary.getAllSongs();
        
        // Find songs needing genres
        final ArrayList<Song> songsNeedingGenres = new ArrayList<>();
        for (Song song : allSongs) {
            if (song != null && ("Unknown Genre".equals(song.getGenre()) || 
                                 song.getGenre() == null || 
                                 song.getGenre().isEmpty())) {
                songsNeedingGenres.add(song);
            }
        }
        
        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            mIsGenreLoading.set(false);
            return;
        }
        
        Log.d(TAG, "Loading genres for " + songsNeedingGenres.size() + " songs");
        
        // Show persistent overlay - get current activity from ToastManager
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null && !currentActivity.isFinishing() && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity, 
                        "Loading metadata... 0/" + songsNeedingGenres.size(),
                        "GENRE_UPDATE");
                } else {
                    Log.w(TAG, "No activity available for persistent overlay");
                }
            }
        });
        
        // Send START broadcast
        sendGenreUpdateBroadcast("START", null, null, 0, songsNeedingGenres.size());
        
        // Process in background
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final SongDatabase db = SongDatabase.getInstance(mContext);
                final MusicLibrary library = new MusicLibrary(mContext);
                int updated = 0;
                final int total = songsNeedingGenres.size();
                
                for (Song song : songsNeedingGenres) {
                    if (song == null || TextUtils.isEmpty(song.getPath())) {
                        continue;
                    }
                    
                    // Read genre from file using CharacterMapper (bypasses database cache)
                    String realGenre = CharacterMapper.getGenre(song.getPath());
                    
                    boolean hasRealGenre = (realGenre != null && 
                                           !realGenre.isEmpty() && 
                                           !"Unknown Genre".equals(realGenre));
                    
                    if (hasRealGenre) {
                        Song updatedSong = new Song(
                            song.getTitle(),
                            song.getArtist(),
                            song.getAlbum(),
                            realGenre,
                            song.getPath(),
                            song.getDuration(),
                            song.getUri()
                        );
                        
                        // Update database
                        db.insertSong(updatedSong);
                        
                        // Update in-memory cache
                        library.updateSongGenre(song.getPath(), realGenre);
                        
                        // Update local song object
                        song.setGenre(realGenre);
                        updated++;
                        
                        // Send broadcast to update UI for this song
                        sendGenreUpdateBroadcast("UPDATE", song.getPath(), realGenre, updated, total);
                        
                        Log.d(TAG, "Genre updated: " + song.getTitle() + " -> " + realGenre);
                    }
                    
                    // Update progress every 10 songs or at the end
                    if (updated % 10 == 0 || updated == total || updated == 1) {
                        final int finalUpdated = updated;
                        final int finalTotal = total;
                        mGenreHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.updatePersistentOverlay(
                                    "Loading metadata... " + finalUpdated + "/" + finalTotal
                                );
                                ToastManager.heartbeat("GENRE_UPDATE");
                            }
                        });
                    }
                }
                
                Log.d(TAG, "Genre loading completed: " + updated + "/" + total + " songs updated");
                
                // Send COMPLETE broadcast
                sendGenreUpdateBroadcast("COMPLETE", null, null, updated, total);
                
                // Force playlist refresh
                Intent forceRefreshIntent = new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                mContext.sendBroadcast(forceRefreshIntent);
                
                // Hide overlay
                mGenreHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay("GENRE_UPDATE");
                        mIsGenreLoading.set(false);
                    }
                });
            }
        });
    }
    
    /**
     * Checks if genre loading is currently in progress.
     *
     * @return True if genre loading is in progress
     */
    public boolean isGenreLoading() {
        return mIsGenreLoading.get();
    }
    
    /**
     * Sends a genre update broadcast to update UI components.
     * 
     * <p>This method centralizes all genre-related broadcasts using a single
     * intent action "GENRE_UPDATE". The status field distinguishes between
     * different event types.</p>
     *
     * @param status Event status: "START", "UPDATE", or "COMPLETE"
     * @param songPath Path of the song being updated (null for START/COMPLETE)
     * @param genre The genre value (null for START/COMPLETE)
     * @param current Current number of songs updated
     * @param total Total number of songs to update
     */
    private void sendGenreUpdateBroadcast(String status, String songPath, String genre, int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }
    
    /**
     * Registers the broadcast receiver for trigger genre loading intents.
     * This allows any component (StorageObserver, FolderManager, etc.) to
     * trigger genre loading via broadcast.
     */
    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(intent.getAction())) {
                    triggerGenreLoading();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        mContext.registerReceiver(mTriggerGenreReceiver, filter);
        Log.d(TAG, "Trigger genre receiver registered");
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    /**
     * Shuts down the executor service gracefully.
     */
    public void shutdown() {
        cancelUpdate();
        
        // Unregister receivers
        unregisterReceiverSafely(mTriggerGenreReceiver);
        
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException e) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", e);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        Log.d(TAG, "PlaylistService shut down");
    }
    
    // ========================================================================
    // Internal Methods
    // ========================================================================
    
    /**
     * Internal method for playlist update.
     * 
     * <p>This method performs the fast scan from MediaStore (no ID3 reading).
     * Genre loading is handled separately by triggerGenreLoading() after
     * the scan completes.</p>
     * 
     * <p><b>Error Handling:</b> The entire scanning process is wrapped in a
     * try-catch block to ensure that the error callback is always invoked
     * even if an uncaught exception occurs. This prevents the UI from waiting
     * indefinitely for a callback that never arrives, which would leave buttons
     * disabled permanently.</p>
     * 
     * <p>Wrapped in try-finally to guarantee NavigationController.endPlaylistSync()
     * is called even on exceptions, preventing notification from staying stuck on "Syncing".</p>
     *
     * @param callback Callback for progress and completion
     * @param silent True to skip progress callbacks
     */
    private void updatePlaylistInternal(@Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }
        
        NavigationController.getInstance().beginPlaylistSync();
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                // Wrap entire scan in try-catch to ensure error callback fires
                try {
                    performScan(callback, silent);
                } catch (final Exception e) {
                    Log.e(TAG, "Uncaught exception during playlist update", e);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(e.getMessage() != null ? e.getMessage() : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);
                    
                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }
    
    /**
     * Performs the actual scanning of folders (called from background thread).
     * 
     * <p>This method now preserves loose tracks when deleting songs
     * not found in the scanned folders.</p>
     *
     * @param callback Progress callback
     * @param silent True to skip progress updates
     */
    private void performScan(@Nullable final UpdateCallback callback, final boolean silent) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();
            
            // Track if we actually found any songs during the scan
            boolean foundAnySongs = false;
            
            // Preserve loose tracks when no folders are selected
            if (selectedFolders.isEmpty()) {
                SongDatabase db = SongDatabase.getInstance(mContext);
                
                // Get all loose tracks first
                ArrayList<Song> looseSongs = db.getLooseSongs();
                
                // Clear the main songs table
                db.clearCache();
                
                // Re-insert loose tracks into the main table
                if (!looseSongs.isEmpty()) {
                    db.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }
                
                final ArrayList<Song> songsAfterUpdate = db.getAllSongs();
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshMusicLibrary(songsAfterUpdate);
                        
                        Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);
                        
                        Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(refreshDisplayIntent);
                        
                        if (callback != null) {
                            callback.onComplete(songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }
            
            final int totalFiles = countMusicFiles(selectedFolders);
            final AtomicInteger currentCount = new AtomicInteger(0);
            
            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }
            
            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get()) {
                    Log.d(TAG, "Update cancelled during scanning");
                    return;
                }
                int foundInFolder = scanFolderFast(Uri.parse(folderUriString), newSongs, allFoundPaths, 
                         currentCount, totalFiles, callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }
            
            if (!mIsUpdating.get()) {
                Log.d(TAG, "Update cancelled after scanning");
                return;
            }
            
            SongDatabase db = SongDatabase.getInstance(mContext);
            
            if (!newSongs.isEmpty()) {
                db.insertSongsBatch(newSongs);
                Log.d(TAG, "Inserted " + newSongs.size() + " new songs");
            }
            
            // Safety check: If we have selected folders but found no songs,
            // something is wrong (permission issue, empty folders, etc.)
            // Don't delete existing songs - preserve the current playlist
            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                Log.w(TAG, "No songs found in selected folders - preserving existing playlist");
                // Don't delete anything, just update with what we have
                final ArrayList<Song> currentSongs = db.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshMusicLibrary(currentSongs);
                        if (callback != null) {
                            callback.onComplete(currentSongs.size());
                        }
                    }
                });
                return;
            }
            
            // Preserve loose tracks during auto-sync (always true for PlaylistService)
            db.deleteSongsNotInSet(allFoundPaths, true);
            
            final ArrayList<Song> allSongsAfterUpdate = db.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();
            
            Log.d(TAG, "Phase 1 completed. Total songs: " + totalSongCount);
            
            // First, refresh the MusicLibrary with the new songs
            refreshMusicLibrary(allSongsAfterUpdate);
            
            // Send SOFT_UPDATE_PLAYLIST to update MusicService
            Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);
            
            // Update any open PlaylistActivity
            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);
            
            // Delay SYNC_COMPLETE to ensure MusicService has processed the update
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }
                    
                    // Send sync complete after MusicService has had time to process
                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);
            
        } catch (final Exception e) {
            Log.e(TAG, "Update failed: " + e.getMessage(), e);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(e);
        }
    }
    
    // ========================================================================
    // Folder and File Scanning Methods (Phase 1 - Fast Scan)
    // ========================================================================
    
    /**
     * Scans a folder for music files using fast path (no ID3 tag reading).
     * 
     * <p>Each file is processed with individual try-catch to prevent a single
     * corrupt file from aborting the entire scan.</p>
     *
     * @param folderUri The folder URI to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int scanFolderFast(@NonNull Uri folderUri, @NonNull ArrayList<Song> newSongs, 
                           @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount, 
                           int totalFiles, @Nullable UpdateCallback callback, boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }
        
        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(folderName, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan error for folder: " + folderUri, e);
        }
        return songsFound;
    }
    
    /**
     * Queries MediaStore for music files in a specific folder path (fast path).
     * 
     * <p>This method does NOT read ID3 tags - it only uses MediaStore data.
     * Genre is set to null (will become "Unknown Genre" in constructor) for
     * fast display.</p>
     * 
     * <p>Each file is processed individually with its own try-catch block.
     * This prevents a single corrupt file from aborting the entire scan.</p>
     *
     * @param folderPath The folder path to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int queryMediaStoreFast(@NonNull String folderPath, @NonNull ArrayList<Song> newSongs, 
                                @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount, 
                                int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }
        
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        
        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                
                if (pathCol == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }
                
                int processedCount = 0;
                SongDatabase db = SongDatabase.getInstance(mContext);
                
                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }
                    
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }
                    
                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }
                    
                    allFoundPaths.add(filePath);
                    
                    // Process each file with individual try-catch
                    try {
                        Song cached = db.getSong(filePath);
                        
                        if (cached == null) {
                            String rawTitle = cursor.getString(titleCol);
                            String rawArtist = cursor.getString(artistCol);
                            String rawAlbum = cursor.getString(albumCol);
                            long duration = (durCol != -1) ? cursor.getLong(durCol) : 0;
                            
                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dot = fileName.lastIndexOf(".");
                                if (dot > 0) {
                                    fileName = fileName.substring(0, dot);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }
                            
                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }
                            
                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }
                            
                            String genre = null;
                            
                            if (CharacterMapper.hasProblematicCharacters(title) || 
                                CharacterMapper.hasProblematicCharacters(artist) || 
                                CharacterMapper.hasProblematicCharacters(album)) {
                                
                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }
                            
                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to process file: " + filePath, e);
                        // Continue with next file
                    }
                    
                    final int current = currentCount.incrementAndGet();
                    processedCount++;
                    
                    long now = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null && 
                        (current - lastProgress[0] >= PROGRESS_THRESHOLD || 
                         now - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         current == totalFiles);
                    
                    if (shouldUpdateProgress) {
                        lastProgress[0] = current;
                        lastProgressTime[0] = now;
                        final int finalCurrent = current;
                        final int finalTotal = totalFiles;
                        
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }
                    
                } while (cursor.moveToNext() && mIsUpdating.get());
                
                Log.d(TAG, "Scanned folder: " + folderPath + ", found " + processedCount + " songs");
            }
        } catch (SecurityException e) {
            Log.e(TAG, "Permission denied scanning folder: " + folderPath, e);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get()) {
                            callback.onError("Permission denied accessing storage");
                        }
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "query error for folder: " + folderPath, e);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
        return songsFound;
    }
    
    /**
     * Queries MediaStore for music files by folder name (fast path).
     * 
     * <p>Each file is processed individually with its own try-catch block.
     * This prevents a single corrupt file from aborting the entire scan.</p>
     *
     * @param folderName The folder name to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int queryMediaStoreByNameFast(@NonNull String folderName, @NonNull ArrayList<Song> newSongs, 
                                      @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount, 
                                      int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }
        
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        
        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                
                if (pathCol == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }
                
                int processedCount = 0;
                SongDatabase db = SongDatabase.getInstance(mContext);
                
                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }
                    
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }
                    
                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }
                    
                    allFoundPaths.add(filePath);
                    
                    // Process each file with individual try-catch
                    try {
                        Song cached = db.getSong(filePath);
                        
                        if (cached == null) {
                            String rawTitle = cursor.getString(titleCol);
                            String rawArtist = cursor.getString(artistCol);
                            String rawAlbum = cursor.getString(albumCol);
                            long duration = (durCol != -1) ? cursor.getLong(durCol) : 0;
                            
                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dot = fileName.lastIndexOf(".");
                                if (dot > 0) {
                                    fileName = fileName.substring(0, dot);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }
                            
                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }
                            
                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }
                            
                            String genre = null;
                            
                            if (CharacterMapper.hasProblematicCharacters(title) || 
                                CharacterMapper.hasProblematicCharacters(artist) || 
                                CharacterMapper.hasProblematicCharacters(album)) {
                                
                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }
                            
                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to process file: " + filePath, e);
                        // Continue with next file
                    }
                    
                    final int current = currentCount.incrementAndGet();
                    processedCount++;
                    
                    long now = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null && 
                        (current - lastProgress[0] >= PROGRESS_THRESHOLD || 
                         now - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         current == totalFiles);
                    
                    if (shouldUpdateProgress) {
                        lastProgress[0] = current;
                        lastProgressTime[0] = now;
                        final int finalCurrent = current;
                        final int finalTotal = totalFiles;
                        
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }
                    
                } while (cursor.moveToNext() && mIsUpdating.get());
                
                Log.d(TAG, "Scanned folder by name: " + folderName + ", found " + processedCount + " songs");
            }
        } catch (Exception e) {
            Log.e(TAG, "query by name error for: " + folderName, e);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
        return songsFound;
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Returns the set of selected folder URIs from SharedPreferences.
     *
     * @return Set of folder URI strings
     */
    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> saved = prefs.getStringSet(KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (saved != null) {
            result.addAll(saved);
        }
        return result;
    }
    
    /**
     * Refreshes the MusicLibrary with the updated song list.
     *
     * @param songs The updated song list
     */
    private void refreshMusicLibrary(@NonNull ArrayList<Song> songs) {
        MusicLibrary musicLibrary = new MusicLibrary(mContext);
        musicLibrary.refreshSongs(songs);
    }
    
    /**
     * Counts the total number of music files in selected folders.
     *
     * @param selectedFolders Set of selected folder URIs
     * @return Total number of music files
     */
    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }
        
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        
        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);
                
                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                folderSelection, new String[]{normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception e) {
                                Log.w(TAG, "Failed to close count cursor", e);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                    folderSelection, new String[]{"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception e) {
                                    Log.w(TAG, "Failed to close count cursor", e);
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "count error for folder: " + folderUriString, e);
            }
        }
        
        Log.d(TAG, "Total music files counted: " + total);
        return total;
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Extracts the file system path from a folder URI.
     *
     * @param uri The folder URI (can be null)
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }
        
        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            int start = uriString.indexOf("primary:") + 8;
            String subPath = uriString.substring(start);
            if (subPath.contains("%2F")) {
                subPath = subPath.replace("%2F", "/");
            }
            if (subPath.contains("/tree/")) {
                subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
            }
            if (subPath.contains("/document/")) {
                subPath = subPath.substring(subPath.indexOf("/document/") + 10);
            }
            String path = "/storage/emulated/0/" + subPath;
            path = Uri.decode(path);
            while (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            return path;
        }
        return null;
    }
    
    /**
     * Gets the display name of a folder from its URI.
     *
     * @param uri The folder URI (can be null)
     * @return The folder name, or null if extraction fails
     */
    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }
        
        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx != -1) {
                    name = cursor.getString(idx);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getFolderName error", e);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.w(TAG, "Failed to close folder name cursor", e);
                }
            }
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }
        
        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
}