package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * PlaylistService - Background scanning and playlist update orchestration.
 *
 * <p>This service scans selected music folders using MediaStore, caches
 * results in the song database, reports progress through callbacks and
 * broadcasts, and runs a separate genre-loading phase that reads ID3 tags
 * for songs whose genre is not yet known. It also provides a targeted
 * "add one loose track" path used when the user opens a file from an
 * external app, without triggering a full folder rescan.</p>
 *
 * <h3>Two-Phase Loading</h3>
 * <ul>
 *   <li><b>Phase 1 (fast scan):</b> queries MediaStore for each selected
 *       folder and persists title, artist, album, and duration. Genre is
 *       left as {@code null} so the song row constructs with the default
 *       placeholder and the UI can render immediately.</li>
 *   <li><b>Phase 2 (genre loading):</b> triggered by
 *       {@link #triggerGenreLoading()} or by the
 *       {@code com.ark.llama.TRIGGER_GENRE_LOADING} broadcast. Reads ID3
 *       tags for songs whose genre is still unknown. Each successful read
 *       emits a {@code GENRE_UPDATE} broadcast so listeners can refresh the
 *       specific row without a full reload.</li>
 * </ul>
 *
 * <h3>Broadcasts Emitted</h3>
 * <ul>
 *   <li>{@code SOFT_UPDATE_PLAYLIST} — consumed by {@link MusicService} to
 *       reload the playlist with the current song preserved.</li>
 *   <li>{@code DISPLAY_PLAYLIST} — consumed by {@link PlaylistActivity} to
 *       refresh the visible list.</li>
 *   <li>{@code SYNC_COMPLETE} — consumed by any component that wants to
 *       know a scan or loose-track addition has finished.</li>
 *   <li>{@code GENRE_UPDATE} — START/UPDATE/COMPLETE lifecycle for
 *       Phase 2, consumed by {@link PlaylistActivity} and
 *       {@link MusicService}.</li>
 *   <li>{@code FORCE_PLAYLIST_REFRESH} — sent on genre loading completion
 *       so any listener can rebuild its display.</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>All scanning runs on a single-thread executor. {@code mIsUpdating}
 * and {@code mIsGenreLoading} guard against concurrent runs. Main-thread
 * callbacks are dispatched through {@code mMainHandler} or
 * {@code mGenreHandler}.</p>
 *
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class PlaylistService {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for selected folder URIs. */
    private static final String KEY_SELECTED_FOLDERS = "selected_folders_uris";

    /** Threshold for progress updates (number of songs between updates). */
    private static final int PROGRESS_THRESHOLD = 10;

    /** Minimum time between progress updates in milliseconds. */
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500;

    /** Sync complete broadcast action. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action for genre update events during genre loading phase. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action for forcing playlist refresh after genre loading. */
    public static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Broadcast action for triggering genre loading from any component. */
    public static final String ACTION_TRIGGER_GENRE_LOADING = "com.ark.llama.TRIGGER_GENRE_LOADING";

    /** Shutdown timeout for executor service in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;

    /** Delay before broadcasting playlist updates after loose track addition. */
    private static final int UPDATE_BROADCAST_DELAY_MS = 200;

    /** Delay before sending SYNC_COMPLETE after a full scan. */
    private static final int SYNC_COMPLETE_DELAY_MS = 400;

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    private static PlaylistService sInstance;

    /**
     * Returns the singleton instance of PlaylistService.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized PlaylistService getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new PlaylistService(context);
        }
        return sInstance;
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** Single-thread executor for background operations. */
    private final ExecutorService mExecutor;

    /** Flag indicating if an update is in progress. */
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);

    /** Main thread handler for UI operations and delayed callbacks. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Genre Loading Members (Phase 2)
    // ========================================================================

    /** Flag indicating if genre loading is in progress. */
    private final AtomicBoolean mIsGenreLoading = new AtomicBoolean(false);

    /** Handler for genre loading UI operations. */
    private final Handler mGenreHandler = new Handler(Looper.getMainLooper());

    /** Broadcast receiver for trigger genre loading intents. */
    private BroadcastReceiver mTriggerGenreReceiver;

    // ========================================================================
    // Callback Interface
    // ========================================================================

    /**
     * Callback interface for playlist update progress and completion.
     */
    public interface UpdateCallback {

        /**
         * Called periodically during the update to report progress.
         *
         * @param current Current number of songs processed
         * @param total Total number of songs to process
         */
        void onProgress(int current, int total);

        /**
         * Called when the update completes successfully.
         *
         * @param songCount Total number of songs found
         */
        void onComplete(int songCount);

        /**
         * Called when an error occurs during the update.
         *
         * @param error The error message
         */
        void onError(@NonNull String error);
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private PlaylistService(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
    }

    // ========================================================================
    // Public API
    // ========================================================================

    /**
     * Updates the playlist by scanning all selected folders.
     *
     * @param callback Callback for progress and completion (can be null)
     */
    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }

    /**
     * Updates the playlist silently (without progress callbacks).
     */
    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }

    /**
     * Adds a single song as a loose track and triggers a targeted playlist
     * update. No folder scan runs — the song is written to the database
     * directly, the library cache is refreshed, and the standard broadcast
     * sequence (SOFT_UPDATE_PLAYLIST, DISPLAY_PLAYLIST, SYNC_COMPLETE) is
     * emitted so the UI and the service pick up the new content.
     *
     * <p>The same NavigationController lock and persistent overlay
     * lifecycle are used as for a folder scan, keeping the user-facing
     * experience uniform.</p>
     *
     * @param song The song to add as a loose track (must not be null)
     * @param callback Callback for progress and completion (can be null)
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song, @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    SongDatabase database = SongDatabase.getInstance(mContext);
                    database.insertLooseSong(song);
                    Log.d(TAG, "Loose track added: " + song.getPath());

                    final ArrayList<Song> allSongs = database.getAllSongs();
                    final int totalSongCount = allSongs.size();

                    if (callback != null && !Thread.currentThread().isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }

                    Log.d(TAG, "Playlist updated with loose track. Total songs: " + totalSongCount);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refreshMusicLibrary(allSongs);

                            Intent softUpdateIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                            mContext.sendBroadcast(softUpdateIntent);

                            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(refreshDisplayIntent);

                            Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(syncCompleteIntent);

                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);

                } catch (final Exception exception) {
                    Log.e(TAG, "Failed to add loose track", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    /**
     * Cancels an ongoing update operation.
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
    }

    /**
     * Checks if an update is currently in progress.
     *
     * @return True if updating
     */
    public boolean isUpdating() {
        return mIsUpdating.get();
    }

    // ========================================================================
    // Genre Loading Methods (Phase 2)
    // ========================================================================

    /**
     * Triggers genre loading for songs with "Unknown Genre".
     *
     * <p>Identifies all songs that still have an unknown genre and processes
     * them in a background thread, reading the real genre from ID3 tags via
     * {@link CharacterMapper}. Each successful update emits a
     * {@code GENRE_UPDATE} broadcast with the status {@code UPDATE} so the
     * UI can refresh the specific row without a full reload.</p>
     *
     * <p>Guard is atomic to prevent concurrent runs. Can be invoked
     * directly or via {@link #ACTION_TRIGGER_GENRE_LOADING}.</p>
     */
    public void triggerGenreLoading() {
        if (mIsGenreLoading.getAndSet(true)) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        Log.d(TAG, "Starting genre loading...");

        MusicLibrary musicLibrary = new MusicLibrary(mContext);
        musicLibrary.refreshCache();
        ArrayList<Song> allSongs = musicLibrary.getAllSongs();

        final ArrayList<Song> songsNeedingGenres = new ArrayList<>();
        for (Song song : allSongs) {
            if (song != null && ("Unknown Genre".equals(song.getGenre()) ||
                                 song.getGenre() == null ||
                                 song.getGenre().isEmpty())) {
                songsNeedingGenres.add(song);
            }
        }

        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            mIsGenreLoading.set(false);
            return;
        }

        Log.d(TAG, "Loading genres for " + songsNeedingGenres.size() + " songs");

        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null && !currentActivity.isFinishing() && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity,
                        "Loading metadata... 0/" + songsNeedingGenres.size(),
                        "GENRE_UPDATE");
                } else {
                    Log.w(TAG, "No activity available for persistent overlay");
                }
            }
        });

        sendGenreUpdateBroadcast("START", null, null, 0, songsNeedingGenres.size());

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final SongDatabase database = SongDatabase.getInstance(mContext);
                final MusicLibrary musicLibrary = new MusicLibrary(mContext);
                int updatedCount = 0;
                final int total = songsNeedingGenres.size();

                for (Song song : songsNeedingGenres) {
                    if (song == null || TextUtils.isEmpty(song.getPath())) {
                        continue;
                    }

                    String realGenre = CharacterMapper.getGenre(song.getPath());

                    boolean hasRealGenre = (realGenre != null &&
                                           !realGenre.isEmpty() &&
                                           !"Unknown Genre".equals(realGenre));

                    if (hasRealGenre) {
                        Song updatedSong = new Song(
                            song.getTitle(),
                            song.getArtist(),
                            song.getAlbum(),
                            realGenre,
                            song.getPath(),
                            song.getDuration(),
                            song.getUri()
                        );

                        database.insertSong(updatedSong);
                        musicLibrary.updateSongGenre(song.getPath(), realGenre);
                        song.setGenre(realGenre);
                        updatedCount++;

                        sendGenreUpdateBroadcast("UPDATE", song.getPath(), realGenre, updatedCount, total);

                        Log.d(TAG, "Genre updated: " + song.getTitle() + " -> " + realGenre);
                    }

                    if (updatedCount % 10 == 0 || updatedCount == total || updatedCount == 1) {
                        final int finalUpdatedCount = updatedCount;
                        final int finalTotal = total;
                        mGenreHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.updatePersistentOverlay(
                                    "Loading metadata... " + finalUpdatedCount + "/" + finalTotal
                                );
                                ToastManager.heartbeat("GENRE_UPDATE");
                            }
                        });
                    }
                }

                Log.d(TAG, "Genre loading completed: " + updatedCount + "/" + total + " songs updated");

                sendGenreUpdateBroadcast("COMPLETE", null, null, updatedCount, total);

                Intent forceRefreshIntent = new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                mContext.sendBroadcast(forceRefreshIntent);

                mGenreHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay("GENRE_UPDATE");
                        mIsGenreLoading.set(false);
                    }
                });
            }
        });
    }

    /**
     * Checks if genre loading is currently in progress.
     *
     * @return True if genre loading is in progress
     */
    public boolean isGenreLoading() {
        return mIsGenreLoading.get();
    }

    /**
     * Sends a genre update broadcast to update UI components.
     *
     * @param status Event status: "START", "UPDATE", or "COMPLETE"
     * @param songPath Path of the song being updated (null for START/COMPLETE)
     * @param genre The genre value (null for START/COMPLETE)
     * @param current Current number of songs updated
     * @param total Total number of songs to update
     */
    private void sendGenreUpdateBroadcast(String status, String songPath, String genre, int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }

    /**
     * Registers the broadcast receiver for trigger genre loading intents.
     */
    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(intent.getAction())) {
                    triggerGenreLoading();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        mContext.registerReceiver(mTriggerGenreReceiver, filter);
        Log.d(TAG, "Trigger genre receiver registered");
    }

    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    /**
     * Shuts down the executor service gracefully.
     */
    public void shutdown() {
        cancelUpdate();

        unregisterReceiverSafely(mTriggerGenreReceiver);

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        Log.d(TAG, "PlaylistService shut down");
    }

    // ========================================================================
    // Internal Methods
    // ========================================================================

    /**
     * Internal entry point for a full folder scan.
     *
     * <p>Runs the fast MediaStore scan without reading ID3 tags; genre
     * loading is handled separately by {@link #triggerGenreLoading()} after
     * the scan completes.</p>
     *
     * <p>The scan body is wrapped so that the error callback is always
     * invoked even on an uncaught exception, and
     * {@code NavigationController.endPlaylistSync()} is always called so
     * the notification does not stay in the "Syncing" state.</p>
     *
     * @param callback Callback for progress and completion
     * @param silent True to skip progress callbacks
     */
    private void updatePlaylistInternal(@Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performScan(callback, silent);
                } catch (final Exception exception) {
                    Log.e(TAG, "Uncaught exception during playlist update", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    /**
     * Performs the actual scanning of folders (called from background thread).
     *
     * <p>Preserves loose tracks when deleting songs not found in the scanned
     * folders.</p>
     *
     * @param callback Progress callback
     * @param silent True to skip progress updates
     */
    private void performScan(@Nullable final UpdateCallback callback, final boolean silent) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();

            boolean foundAnySongs = false;

            if (selectedFolders.isEmpty()) {
                // No folders configured: preserve whatever loose tracks
                // exist in the database.
                SongDatabase database = SongDatabase.getInstance(mContext);

                ArrayList<Song> looseSongs = database.getLooseSongs();

                database.clearCache();

                if (!looseSongs.isEmpty()) {
                    database.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }

                final ArrayList<Song> songsAfterUpdate = database.getAllSongs();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshMusicLibrary(songsAfterUpdate);

                        Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);

                        Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(refreshDisplayIntent);

                        if (callback != null) {
                            callback.onComplete(songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }

            final int totalFiles = countMusicFiles(selectedFolders);
            final AtomicInteger currentCount = new AtomicInteger(0);

            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }

            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get()) {
                    Log.d(TAG, "Update cancelled during scanning");
                    return;
                }
                int foundInFolder = scanFolderFast(Uri.parse(folderUriString), newSongs, allFoundPaths,
                         currentCount, totalFiles, callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }

            if (!mIsUpdating.get()) {
                Log.d(TAG, "Update cancelled after scanning");
                return;
            }

            SongDatabase database = SongDatabase.getInstance(mContext);

            if (!newSongs.isEmpty()) {
                database.insertSongsBatch(newSongs);
                Log.d(TAG, "Inserted " + newSongs.size() + " new songs");
            }

            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                // Folders exist but yielded nothing: treat as a transient
                // failure and leave the existing playlist intact.
                Log.w(TAG, "No songs found in selected folders - preserving existing playlist");
                final ArrayList<Song> currentSongs = database.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshMusicLibrary(currentSongs);
                        if (callback != null) {
                            callback.onComplete(currentSongs.size());
                        }
                    }
                });
                return;
            }

            database.deleteSongsNotInSet(allFoundPaths, true);

            final ArrayList<Song> allSongsAfterUpdate = database.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();

            Log.d(TAG, "Phase 1 completed. Total songs: " + totalSongCount);

            refreshMusicLibrary(allSongsAfterUpdate);

            Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);

            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);

            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);

        } catch (final Exception exception) {
            Log.e(TAG, "Update failed: " + exception.getMessage(), exception);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(exception);
        }
    }

    // ========================================================================
    // Folder and File Scanning (Phase 1 - Fast Scan)
    // ========================================================================

    /**
     * Scans a folder for music files using the fast path (no ID3 tag
     * reading).
     *
     * @param folderUri The folder URI to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int scanFolderFast(@NonNull Uri folderUri, @NonNull ArrayList<Song> newSongs,
                           @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                           int totalFiles, @Nullable UpdateCallback callback, boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(folderName, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan error for folder: " + folderUri, exception);
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files in a specific folder path (fast
     * path).
     *
     * <p>Does not normally read ID3 tags — only MediaStore data. Genre is
     * left null in the common path, which the {@link Song} constructor
     * converts to the placeholder; the real value is populated later by
     * {@link #triggerGenreLoading()}. As a fallback, if title, artist, or
     * album contains problematic characters, the file is parsed directly
     * via {@link CharacterMapper#getSongFromFile(String)} and its genre (if
     * present) is used.</p>
     *
     * <p>Each file is processed individually with its own try-catch block,
     * so a single corrupt file cannot abort the entire scan.</p>
     *
     * @param folderPath The folder path to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int queryMediaStoreFast(@NonNull String folderPath, @NonNull ArrayList<Song> newSongs,
                                @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                                int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " +
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1) ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            // For filenames or metadata with non-standard
                            // characters, fall back to reading the file
                            // directly. This covers legacy encodings that
                            // MediaStore does not decode.
                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                         currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder: " + folderPath + ", found " + processedCount + " songs");
            }
        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied scanning folder: " + folderPath, exception);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get()) {
                            callback.onError("Permission denied accessing storage");
                        }
                    }
                });
            }
        } catch (Exception exception) {
            Log.e(TAG, "query error for folder: " + folderPath, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files by folder name (fast path).
     *
     * <p>Fallback for folder URIs whose filesystem path cannot be extracted.
     * Same fast-scan semantics as
     * {@link #queryMediaStoreFast(String, ArrayList, Set, AtomicInteger, int, UpdateCallback, boolean)}.</p>
     *
     * @param folderName The folder name to scan
     * @param newSongs List to add new songs to
     * @param allFoundPaths Set of all found file paths
     * @param currentCount Current count of processed files
     * @param totalFiles Total number of files to process
     * @param callback Progress callback
     * @param silent True to skip progress updates
     * @return Number of songs found in this folder
     */
    private int queryMediaStoreByNameFast(@NonNull String folderName, @NonNull ArrayList<Song> newSongs,
                                      @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                                      int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " +
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1) ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                         currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder by name: " + folderName + ", found " + processedCount + " songs");
            }
        } catch (Exception exception) {
            Log.e(TAG, "query by name error for: " + folderName, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns the set of selected folder URIs from SharedPreferences.
     *
     * @return Set of folder URI strings
     */
    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = prefs.getStringSet(KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (savedFolders != null) {
            result.addAll(savedFolders);
        }
        return result;
    }

    /**
     * Refreshes the MusicLibrary with the updated song list.
     *
     * @param songs The updated song list
     */
    private void refreshMusicLibrary(@NonNull ArrayList<Song> songs) {
        MusicLibrary musicLibrary = new MusicLibrary(mContext);
        musicLibrary.refreshSongs(songs);
    }

    /**
     * Counts the total number of music files in selected folders.
     *
     * @param selectedFolders Set of selected folder URIs
     * @return Total number of music files
     */
    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);

                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                folderSelection, new String[]{normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception exception) {
                                Log.w(TAG, "Failed to close count cursor", exception);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                    folderSelection, new String[]{"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception exception) {
                                    Log.w(TAG, "Failed to close count cursor", exception);
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "count error for folder: " + folderUriString, exception);
            }
        }

        Log.d(TAG, "Total music files counted: " + total);
        return total;
    }

    // ========================================================================
    // URI Helper Methods
    // ========================================================================

    /**
     * Extracts the file system path from a folder URI.
     *
     * @param uri The folder URI (can be null)
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            int startIndex = uriString.indexOf("primary:") + 8;
            String subPath = uriString.substring(startIndex);
            if (subPath.contains("%2F")) {
                subPath = subPath.replace("%2F", "/");
            }
            if (subPath.contains("/tree/")) {
                subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
            }
            if (subPath.contains("/document/")) {
                subPath = subPath.substring(subPath.indexOf("/document/") + 10);
            }
            String path = "/storage/emulated/0/" + subPath;
            path = Uri.decode(path);
            while (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            return path;
        }
        return null;
    }

    /**
     * Gets the display name of a folder from its URI.
     *
     * @param uri The folder URI (can be null)
     * @return The folder name, or null if extraction fails
     */
    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
}