package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaylistService - Background scanning and playlist update orchestration.
 *
 * <p>This service scans selected music folders using MediaStore, caches
 * results in the song database, reports progress through callbacks and
 * broadcasts, and runs a separate genre-loading phase that reads ID3 tags
 * for songs whose genre is not yet known. It also provides a targeted
 * "add one loose track" path used when the user opens a file from an
 * external app, without triggering a full folder rescan.</p>
 *
 * <h3>Two-Phase Loading</h3>
 * <ul>
 *   <li><b>Phase 1 (fast scan):</b> queries MediaStore for each selected
 *       folder and persists title, artist, album, and duration. Genre is
 *       left as {@code null} so the song row constructs with the default
 *       placeholder and the UI can render immediately.</li>
 *   <li><b>Phase 2 (genre loading):</b> triggered by
 *       {@link #triggerGenreLoading()} or by the
 *       {@code com.ark.llama.TRIGGER_GENRE_LOADING} broadcast. Reads ID3
 *       tags for songs whose genre is still unknown. Each successful read
 *       emits a {@code GENRE_UPDATE} broadcast so listeners can refresh the
 *       specific row without a full reload.</li>
 * </ul>
 *
 * <h3>Scan Cancellation</h3>
 * <p>{@link #cancelUpdate()} increments a generation counter and clears
 * the busy flag. Every scan captures the counter at start and re-checks it
 * immediately before each database write. A cancel that arrives between
 * the loop's flag check and the write still aborts the write, so a scan
 * can never reinsert songs into a database that a concurrent full-library
 * reset has just cleared.</p>
 *
 * <h3>Persistent Overlay Ownership</h3>
 * <p>Genre loading owns the persistent "Loading metadata..." overlay for
 * its entire lifetime. The overlay is shown with the {@code "GENRE_UPDATE"}
 * operation ID and is kept alive by a self-scheduling heartbeat ticker
 * that runs independently of the ID3 read loop, so a slow read cannot
 * starve the heartbeat and trip {@link ToastManager}'s stuck detector.
 * The ticker is invalidated on completion. No other component should show
 * or update this overlay — {@link PlaylistActivity} observes genre progress
 * for its own list state only.</p>
 *
 * <h3>Broadcasts Emitted</h3>
 * <ul>
 *   <li>{@code SOFT_UPDATE_PLAYLIST} — consumed by {@link MusicService} to
 *       reload the playlist with the current song preserved.</li>
 *   <li>{@code DISPLAY_PLAYLIST} — consumed by {@link PlaylistActivity} to
 *       refresh the visible list.</li>
 *   <li>{@code SYNC_COMPLETE} — consumed by any component that wants to
 *       know a scan or loose-track addition has finished.</li>
 *   <li>{@code GENRE_UPDATE} — START/UPDATE/COMPLETE lifecycle for
 *       Phase 2, consumed by {@link PlaylistActivity} and
 *       {@link MusicService}.</li>
 *   <li>{@code FORCE_PLAYLIST_REFRESH} — sent on genre loading completion
 *       so any listener can rebuild its display.</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>All scanning runs on a single-thread executor. {@code mIsUpdating}
 * and {@code mIsGenreLoading} guard against concurrent runs. Main-thread
 * callbacks are dispatched through {@code mMainHandler} or
 * {@code mGenreHandler}.</p>
 *
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistService {

    // ========================================================================
    // Constants
    // ========================================================================

    private static final String TAG = "PlaylistService";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_SELECTED_FOLDERS = "selected_folders_uris";

    private static final int PROGRESS_THRESHOLD = 10;
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500;

    /**
     * Minimum interval between genre-loading heartbeats, safely below the
     * {@link ToastManager}'s {@code STUCK_TIMEOUT_MS} (1000 ms) so a slow
     * ID3 read cannot starve the heartbeat and trip the stuck detector.
     */
    private static final long GENRE_HEARTBEAT_INTERVAL_MS = 500;

    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";
    public static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    public static final String ACTION_TRIGGER_GENRE_LOADING = "com.ark.llama.TRIGGER_GENRE_LOADING";

    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    private static final int UPDATE_BROADCAST_DELAY_MS = 200;
    private static final int SYNC_COMPLETE_DELAY_MS = 400;

    // ========================================================================
    // Singleton
    // ========================================================================

    private static PlaylistService sInstance;

    @NonNull
    public static synchronized PlaylistService getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new PlaylistService(context);
        }
        return sInstance;
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    private final Context mContext;
    private final ExecutorService mExecutor;
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /**
     * Generation counter for scan cancellation. Incremented by
     * {@link #cancelUpdate()}. A scan captures the value at start and
     * re-checks it immediately before every database write, so a cancel
     * that arrives between the loop's flag check and the write still
     * aborts the write.
     */
    @NonNull
    private final AtomicLong mScanGeneration = new AtomicLong(0L);

    // ========================================================================
    // Genre Loading Members (Phase 2)
    // ========================================================================

    private final AtomicBoolean mIsGenreLoading = new AtomicBoolean(false);
    private final Handler mGenreHandler = new Handler(Looper.getMainLooper());

    /**
     * Token for the current genre-loading heartbeat ticker. Incremented to
     * invalidate any in-flight ticker when a run completes or is
     * superseded.
     */
    @NonNull
    private final AtomicLong mGenreHeartbeatToken = new AtomicLong(0L);

    private BroadcastReceiver mTriggerGenreReceiver;

    // ========================================================================
    // Callback Interface
    // ========================================================================

    public interface UpdateCallback {

        void onProgress(int current, int total);

        void onComplete(int songCount);

        void onError(@NonNull String error);
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    private PlaylistService(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
    }

    // ========================================================================
    // Public API
    // ========================================================================

    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }

    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }

    /**
     * Adds a single song as a loose track and triggers a targeted playlist
     * update. No folder scan runs — the song is written to the database
     * directly, the library cache is refreshed, and the standard broadcast
     * sequence (SOFT_UPDATE_PLAYLIST, DISPLAY_PLAYLIST, SYNC_COMPLETE) is
     * emitted so the UI and the service pick up the new content.
     *
     * <p>The same NavigationController lock and persistent overlay
     * lifecycle are used as for a folder scan, keeping the user-facing
     * experience uniform.</p>
     *
     * <p>The scan generation is captured before submission and re-checked
     * immediately before the database write, so a concurrent
     * {@link #cancelUpdate()} aborts the write.</p>
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song, @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mScanGeneration.get() != scanGeneration) {
                        Log.d(TAG, "Loose-track addition cancelled before insert");
                        return;
                    }

                    SongDatabase database = SongDatabase.getInstance(mContext);
                    database.insertLooseSong(song);
                    Log.d(TAG, "Loose track added: " + song.getPath());

                    final ArrayList<Song> allSongs = database.getAllSongs();
                    final int totalSongCount = allSongs.size();

                    if (callback != null && !Thread.currentThread().isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }

                    Log.d(TAG, "Playlist updated with loose track. Total songs: " + totalSongCount);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent softUpdateIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                            mContext.sendBroadcast(softUpdateIntent);

                            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(refreshDisplayIntent);

                            Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(syncCompleteIntent);

                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);

                } catch (final Exception exception) {
                    Log.e(TAG, "Failed to add loose track", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    /**
     * Requests cancellation of any in-flight scan.
     *
     * <p>Clears the busy flag and increments the scan generation. The
     * generation is captured by every scan at start and re-checked
     * immediately before each database write, so a scan that has passed
     * its last flag check but not yet reached its write will still abort.
     * This is the mechanism by which a full-library reset can guarantee
     * that no scan reinserts songs after the reset clears them.</p>
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
        mScanGeneration.incrementAndGet();
        Log.d(TAG, "Scan cancel requested (generation "
            + mScanGeneration.get() + ")");
    }

    public boolean isUpdating() {
        return mIsUpdating.get();
    }

    // ========================================================================
    // Genre Loading Methods (Phase 2)
    // ========================================================================

    /**
     * Triggers genre loading for songs with "Unknown Genre".
     *
     * <p>Identifies all songs that still have an unknown genre and processes
     * them in a background thread, reading the real genre from ID3 tags via
     * {@link CharacterMapper}. Each successful update emits a
     * {@code GENRE_UPDATE} broadcast with the status {@code UPDATE} so the
     * UI can refresh the specific row without a full reload.</p>
     *
     * <p>The persistent overlay is owned by this method for the entire
     * loading lifetime. It is shown with the {@code "GENRE_UPDATE"}
     * operation ID, and a self-scheduling heartbeat ticker (started in the
     * same post as the overlay show) resets {@link ToastManager}'s stuck
     * timer every {@link #GENRE_HEARTBEAT_INTERVAL_MS} milliseconds
     * independently of the ID3 read loop. The ticker is invalidated on
     * completion.</p>
     */
    public void triggerGenreLoading() {
        if (mIsGenreLoading.getAndSet(true)) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        Log.d(TAG, "Starting genre loading...");

        final ArrayList<Song> allSongs = SongDatabase.getInstance(mContext).getAllSongs();

        final ArrayList<Song> songsNeedingGenres = new ArrayList<>();
        for (Song song : allSongs) {
            if (song != null && ("Unknown Genre".equals(song.getGenre()) ||
                                 song.getGenre() == null ||
                                 song.getGenre().isEmpty())) {
                songsNeedingGenres.add(song);
            }
        }

        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            mIsGenreLoading.set(false);
            return;
        }

        Log.d(TAG, "Loading genres for " + songsNeedingGenres.size() + " songs");

        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null && !currentActivity.isFinishing() && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity,
                        "Loading metadata... 0/" + songsNeedingGenres.size(),
                        "GENRE_UPDATE");
                } else {
                    Log.w(TAG, "No activity available for persistent overlay");
                }
                startGenreHeartbeatTicker();
            }
        });

        sendGenreUpdateBroadcast("START", null, null, 0, songsNeedingGenres.size());

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final SongDatabase database = SongDatabase.getInstance(mContext);
                int updatedCount = 0;
                final int total = songsNeedingGenres.size();
                long lastProgressTime = 0;

                try {
                    for (Song song : songsNeedingGenres) {
                        if (song == null || TextUtils.isEmpty(song.getPath())) {
                            continue;
                        }

                        String realGenre = CharacterMapper.getGenre(song.getPath());

                        boolean hasRealGenre = (realGenre != null &&
                                               !realGenre.isEmpty() &&
                                               !"Unknown Genre".equals(realGenre));

                        if (hasRealGenre) {
                            Song updatedSong = new Song(
                                song.getTitle(),
                                song.getArtist(),
                                song.getAlbum(),
                                realGenre,
                                song.getPath(),
                                song.getDuration(),
                                song.getUri()
                            );

                            database.insertSong(updatedSong);
                            song.setGenre(realGenre);
                            updatedCount++;

                            sendGenreUpdateBroadcast("UPDATE", song.getPath(), realGenre, updatedCount, total);

                            Log.d(TAG, "Genre updated: " + song.getTitle() + " -> " + realGenre);
                        }

                        long now = SystemClock.elapsedRealtime();
                        if (now - lastProgressTime >= PROGRESS_TIME_THRESHOLD_MS
                                || updatedCount == total
                                || updatedCount == 1) {
                            lastProgressTime = now;
                            final int currentUpdated = updatedCount;
                            final int currentTotal = total;
                            mGenreHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    ToastManager.updatePersistentOverlay(
                                        "Loading metadata... " + currentUpdated + "/" + currentTotal);
                                }
                            });
                        }
                    }
                } finally {
                    stopGenreHeartbeatTicker();
                }

                Log.d(TAG, "Genre loading completed: " + updatedCount + "/" + total + " songs updated");

                sendGenreUpdateBroadcast("COMPLETE", null, null, updatedCount, total);

                Intent forceRefreshIntent = new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                mContext.sendBroadcast(forceRefreshIntent);

                mGenreHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay("GENRE_UPDATE");
                        mIsGenreLoading.set(false);
                    }
                });
            }
        });
    }

    public boolean isGenreLoading() {
        return mIsGenreLoading.get();
    }

    /**
     * Starts the genre-loading heartbeat ticker. The ticker resets
     * {@link ToastManager}'s stuck timer every
     * {@link #GENRE_HEARTBEAT_INTERVAL_MS} milliseconds independently of
     * the ID3 read loop, so a slow read cannot starve the heartbeat and
     * trip the stuck detector.
     */
    private void startGenreHeartbeatTicker() {
        final long token = mGenreHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mGenreHeartbeatToken.get() != token) {
                    return;
                }
                ToastManager.heartbeat("GENRE_UPDATE");
                mGenreHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current genre-loading heartbeat ticker by invalidating its
     * token. Idempotent.
     */
    private void stopGenreHeartbeatTicker() {
        mGenreHeartbeatToken.incrementAndGet();
    }

    private void sendGenreUpdateBroadcast(String status, String songPath, String genre, int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }

    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(intent.getAction())) {
                    triggerGenreLoading();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        mContext.registerReceiver(mTriggerGenreReceiver, filter);
        Log.d(TAG, "Trigger genre receiver registered");
    }

    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    public void shutdown() {
        cancelUpdate();

        stopGenreHeartbeatTicker();

        unregisterReceiverSafely(mTriggerGenreReceiver);

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        Log.d(TAG, "PlaylistService shut down");
    }

    // ========================================================================
    // Internal Methods
    // ========================================================================

    private void updatePlaylistInternal(@Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performScan(callback, silent, scanGeneration);
                } catch (final Exception exception) {
                    Log.e(TAG, "Uncaught exception during playlist update", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    private void performScan(@Nullable final UpdateCallback callback,
                             final boolean silent,
                             final long scanGeneration) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();

            boolean foundAnySongs = false;

            if (selectedFolders.isEmpty()) {
                SongDatabase database = SongDatabase.getInstance(mContext);

                ArrayList<Song> looseSongs = database.getLooseSongs();

                database.clearCache();

                if (!looseSongs.isEmpty()) {
                    database.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }

                final ArrayList<Song> songsAfterUpdate = database.getAllSongs();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);

                        Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(refreshDisplayIntent);

                        if (callback != null) {
                            callback.onComplete(songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }

            final int totalFiles = countMusicFiles(selectedFolders);
            final AtomicInteger currentCount = new AtomicInteger(0);

            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }

            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get()) {
                    Log.d(TAG, "Update cancelled during scanning");
                    return;
                }
                int foundInFolder = scanFolderFast(Uri.parse(folderUriString), newSongs, allFoundPaths,
                         currentCount, totalFiles, callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }

            if (!mIsUpdating.get()) {
                Log.d(TAG, "Update cancelled after scanning");
                return;
            }

            // Re-check the generation before the batch insert. A cancel that
            // arrived between the flag check above and this point would
            // otherwise be missed, and the scan would reinsert songs into a
            // database that a concurrent full-library reset has just
            // cleared.
            if (mScanGeneration.get() != scanGeneration) {
                Log.d(TAG, "Scan cancelled before batch insert, aborting");
                return;
            }

            SongDatabase database = SongDatabase.getInstance(mContext);

            if (!newSongs.isEmpty()) {
                database.insertSongsBatch(newSongs);
                Log.d(TAG, "Inserted " + newSongs.size() + " new songs");
            }

            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                Log.w(TAG, "No songs found in selected folders - preserving existing playlist");
                final ArrayList<Song> currentSongs = database.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onComplete(currentSongs.size());
                        }
                    }
                });
                return;
            }

            // Re-check again before the delete pass. The delete is a
            // database write and must respect the same cancellation
            // contract as the insert above.
            if (mScanGeneration.get() != scanGeneration) {
                Log.d(TAG, "Scan cancelled before delete pass, aborting");
                return;
            }

            database.deleteSongsNotInSet(allFoundPaths, true);

            final ArrayList<Song> allSongsAfterUpdate = database.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();

            Log.d(TAG, "Phase 1 completed. Total songs: " + totalSongCount);

            Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);

            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);

            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);

        } catch (final Exception exception) {
            Log.e(TAG, "Update failed: " + exception.getMessage(), exception);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(exception.getMessage() != null ? exception.getMessage() : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(exception);
        }
    }

    // ========================================================================
    // Folder and File Scanning (Phase 1 - Fast Scan)
    // ========================================================================

    private int scanFolderFast(@NonNull Uri folderUri, @NonNull ArrayList<Song> newSongs,
                           @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                           int totalFiles, @Nullable UpdateCallback callback, boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(folderName, newSongs, allFoundPaths, currentCount, totalFiles, callback, silent);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan error for folder: " + folderUri, exception);
        }
        return songsFound;
    }

    private int queryMediaStoreFast(@NonNull String folderPath, @NonNull ArrayList<Song> newSongs,
                                @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                                int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " +
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1) ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                         currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder: " + folderPath + ", found " + processedCount + " songs");
            }
        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied scanning folder: " + folderPath, exception);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get()) {
                            callback.onError("Permission denied accessing storage");
                        }
                    }
                });
            }
        } catch (Exception exception) {
            Log.e(TAG, "query error for folder: " + folderPath, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    private int queryMediaStoreByNameFast(@NonNull String folderName, @NonNull ArrayList<Song> newSongs,
                                      @NonNull Set<String> allFoundPaths, @NonNull AtomicInteger currentCount,
                                      int totalFiles, @Nullable final UpdateCallback callback, final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " +
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[]{
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[]{"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1) ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre, filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                         currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                         currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder by name: " + folderName + ", found " + processedCount + " songs");
            }
        } catch (Exception exception) {
            Log.e(TAG, "query by name error for: " + folderName, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = prefs.getStringSet(KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (savedFolders != null) {
            result.addAll(savedFolders);
        }
        return result;
    }

    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);

                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                folderSelection, new String[]{normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception exception) {
                                Log.w(TAG, "Failed to close count cursor", exception);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                    folderSelection, new String[]{"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception exception) {
                                    Log.w(TAG, "Failed to close count cursor", exception);
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "count error for folder: " + folderUriString, exception);
            }
        }

        Log.d(TAG, "Total music files counted: " + total);
        return total;
    }

    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            int startIndex = uriString.indexOf("primary:") + 8;
            String subPath = uriString.substring(startIndex);
            if (subPath.contains("%2F")) {
                subPath = subPath.replace("%2F", "/");
            }
            if (subPath.contains("/tree/")) {
                subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
            }
            if (subPath.contains("/document/")) {
                subPath = subPath.substring(subPath.indexOf("/document/") + 10);
            }
            String path = "/storage/emulated/0/" + subPath;
            path = Uri.decode(path);
            while (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            return path;
        }
        return null;
    }

    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
}