package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Adapter for displaying folders in the FolderManager RecyclerView.
 * 
 * <p>This adapter handles both regular folder items and the special "Loose Tracks"
 * entry. It provides touch feedback, theme support, and debounced click handling
 * for remove buttons.</p>
 * 
 * <p>Follows Google's recommendations for ViewHolder pattern and efficient list updates.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>Click debouncing uses timestamp comparison.
 * All UI operations are on the main thread.</p>
 * 
 * @see FolderManager
 * @see RecyclerView.Adapter
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long DEBOUNCE_DELAY_MS = 250;
    
    /** Animation duration for button press effects (milliseconds). */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Touch highlight color (dark gray). */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for accessing resources and services. */
    private final Context context;
    
    /** List of folder items to display. */
    private final List<FolderItem> folders;
    
    /** Listener for folder removal events. */
    @NonNull
    private final OnFolderRemoveListener removeListener;
    
    /** Helper for applying theme colors to UI elements. */
    private final ThemeHelper themeHelper;
    
    /** Theme manager for getting current color. */
    private final ThemeManager themeManager;
    
    /** Flag indicating whether remove buttons are enabled. */
    private final AtomicBoolean shouldEnableRemoveButtons = new AtomicBoolean(true);

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Listener interface for folder removal events.
     * 
     * <p>Activities that use this adapter implement this interface
     * to handle folder removal operations.</p>
     */
    public interface OnFolderRemoveListener {
        
        /**
         * Called when a regular folder is removed.
         * 
         * @param folderUriString The URI string of the folder to remove
         * @param position The position of the folder in the list
         */
        void onFolderRemove(@NonNull String folderUriString, int position);
        
        /**
         * Called when the Loose Tracks entry is removed.
         */
        void onLooseTracksRemove();
    }

    // ========================================================================
    // FolderItem Class
    // ========================================================================

    /**
     * Represents a folder item in the list.
     * 
     * <p>Can be either a real folder (with a URI) or the special
     * "Loose Tracks" entry that displays uncategorized songs.</p>
     */
    public static class FolderItem {
        
        /** The URI string of the folder, or "LOOSE_TRACKS" for the special entry. */
        @NonNull
        public final String uriString;
        
        /** The display name shown to the user. */
        @NonNull
        public final String displayName;
        
        /** True if this is the special Loose Tracks entry. */
        public final boolean isLooseTracks;
        
        /** Number of loose tracks (only valid if isLooseTracks is true). */
        public final int looseTracksCount;

        /**
         * Constructor for real folder items.
         * 
         * @param uriString The URI string of the folder
         * @param displayName The display name of the folder
         */
        public FolderItem(@NonNull String uriString, @NonNull String displayName) {
            this.uriString = uriString;
            this.displayName = displayName;
            this.isLooseTracks = false;
            this.looseTracksCount = 0;
        }

        /**
         * Constructor for the special "Loose Tracks" item.
         * 
         * @param looseTracksCount The number of loose tracks to display
         */
        public FolderItem(int looseTracksCount) {
            this.uriString = "LOOSE_TRACKS";
            this.displayName = "Loose Tracks [" + looseTracksCount + " song" 
                + (looseTracksCount != 1 ? "s" : "") + "]";
            this.isLooseTracks = true;
            this.looseTracksCount = looseTracksCount;
        }
        
        /**
         * Returns a string representation for debugging.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "FolderItem{" +
                    "uriString='" + uriString + '\'' +
                    ", displayName='" + displayName + '\'' +
                    ", isLooseTracks=" + isLooseTracks +
                    ", looseTracksCount=" + looseTracksCount +
                    '}';
        }
    }

    // ========================================================================
    // ViewHolder Class
    // ========================================================================

    /**
     * ViewHolder for folder items following Google's ViewHolder pattern.
     * 
     * <p>This class caches references to the views within each item layout
     * to improve performance during scrolling.</p>
     */
    static class FolderViewHolder extends RecyclerView.ViewHolder {
        
        /** TextView displaying the folder icon. */
        @Nullable
        final TextView folderIcon;
        
        /** TextView displaying the folder name. */
        @Nullable
        final TextView folderName;
        
        /** Button for removing the folder. */
        @Nullable
        final Button removeButton;

        /**
         * Constructs a new FolderViewHolder.
         * 
         * @param itemView The item view for this ViewHolder
         */
        FolderViewHolder(@NonNull View itemView) {
            super(itemView);
            folderIcon = (TextView) itemView.findViewById(R.id.folderIcon);
            folderName = (TextView) itemView.findViewById(R.id.folderName);
            removeButton = (Button) itemView.findViewById(R.id.removeButton);
        }
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new FolderAdapter.
     * 
     * @param context The application context
     * @param folders The list of folder items to display
     * @param listener The listener for folder removal events
     */
    public FolderAdapter(@NonNull Context context, @NonNull List<FolderItem> folders, 
                         @NonNull OnFolderRemoveListener listener) {
        this.context = context;
        this.folders = folders;
        this.removeListener = listener;
        this.themeHelper = ThemeHelper.getInstance(context);
        this.themeManager = ThemeManager.getInstance(context);
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Enables all remove buttons in the list.
     */
    public void enableRemoveButtons() {
        shouldEnableRemoveButtons.set(true);
        notifyDataSetChanged();
    }

    /**
     * Disables all remove buttons in the list.
     */
    public void disableRemoveButtons() {
        shouldEnableRemoveButtons.set(false);
        notifyDataSetChanged();
    }

    /**
     * Updates the folder list with new data.
     *
     * @param newFolders The new list of folder items
     */
    public void updateFolders(@NonNull List<FolderItem> newFolders) {
        folders.clear();
        folders.addAll(newFolders);
        notifyDataSetChanged();
    }

    /**
     * Removes an item at the specified position with proper animation.
     * 
     * @param position The position of the item to remove
     */
    public void removeItem(int position) {
        if (position >= 0 && position < folders.size()) {
            folders.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, folders.size() - position);
        }
    }

    // ========================================================================
    // RecyclerView.Adapter Methods
    // ========================================================================

    /**
     * Creates a new ViewHolder for a folder item.
     * 
     * @param parent The parent ViewGroup
     * @param viewType The view type (not used)
     * @return A new FolderViewHolder
     */
    @NonNull
    @Override
    public FolderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_folder, parent, false);
        return new FolderViewHolder(view);
    }

    /**
     * Binds data to a ViewHolder at the specified position.
     * 
     * <p>This method configures the folder icon, folder name, remove button state,
     * and touch feedback for the list item.</p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final FolderViewHolder holder, int position) {
        if (position < 0 || position >= folders.size()) {
            return;
        }
        
        final FolderItem folderItem = folders.get(position);
        if (folderItem == null) {
            return;
        }
        
        final View itemView = holder.itemView;
        final Button removeButton = holder.removeButton;

        if (holder.folderIcon != null) {
            holder.folderIcon.setTypeface(FontAwesome.getTypeface());
            holder.folderIcon.setText(FontAwesome.FOLDER);
            if (themeManager != null && themeHelper != null) {
                themeHelper.setThemeColor(themeManager.getCurrentColor());
                holder.folderIcon.setTextColor(themeHelper.getThemeColorInt());
            }
        }

        if (holder.folderName != null) {
            holder.folderName.setText(folderItem.displayName);
        }

        if (removeButton != null) {
            configureRemoveButton(removeButton, folderItem, holder);
        }

        itemView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setBackgroundColor(Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Returns the total number of items in the list.
     * 
     * @return The number of folder items
     */
    @Override
    public int getItemCount() {
        return folders.size();
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Configures the remove button based on current enabled state.
     * 
     * @param removeButton The button to configure
     * @param folderItem The folder item associated with this button
     * @param holder The ViewHolder containing the button
     */
    private void configureRemoveButton(@NonNull Button removeButton, 
                                        @NonNull FolderItem folderItem, 
                                        @NonNull FolderViewHolder holder) {
        
        boolean enabled = shouldEnableRemoveButtons.get();
        
        removeButton.setEnabled(enabled);
        
        if (themeManager != null && themeHelper != null) {
            themeHelper.setThemeColor(themeManager.getCurrentColor());
            themeHelper.updateButton(removeButton, enabled);
        }
        
        animateButton(removeButton);
        
        if (enabled) {
            removeButton.setOnClickListener(createRemoveClickListener(folderItem, holder));
        } else {
            removeButton.setOnClickListener(null);
        }
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * 
     * @param button The button to animate
     */
    private void animateButton(@NonNull final Button button) {
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Creates a click listener for the remove button with debouncing protection.
     * 
     * @param folderItem The folder item associated with this button
     * @param holder The ViewHolder containing the button
     * @return A new View.OnClickListener
     */
    @NonNull
    private View.OnClickListener createRemoveClickListener(@NonNull final FolderItem folderItem, 
                                                             @NonNull final FolderViewHolder holder) {
        return new View.OnClickListener() {
            private long lastClickTime = 0;

            @Override
            public void onClick(@NonNull View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - lastClickTime < DEBOUNCE_DELAY_MS) {
                    return;
                }
                lastClickTime = currentTime;

                int position = holder.getAdapterPosition();
                if (position == RecyclerView.NO_POSITION) {
                    return;
                }

                if (folderItem.isLooseTracks) {
                    removeListener.onLooseTracksRemove();
                } else {
                    removeListener.onFolderRemove(folderItem.uriString, position);
                }
            }
        };
    }
}