package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Renders the list of folders and the Loose Tracks entry in the
 * {@link FolderManager} {@link RecyclerView}.
 *
 * <p>Each row shows a themed folder icon, the folder's display name, and
 * a remove button. The Loose Tracks row is rendered the same way, with
 * the number of loose tracks appended to its name. Tapping a remove
 * button notifies the owning activity through
 * {@link OnFolderRemoveListener}.</p>
 *
 * <h3>State Ownership</h3>
 * <p>Whether the remove button for a row is enabled is a function of
 * {@link NavigationController}'s
 * {@link NavigationController.ButtonGroup#FOLDER_ACTIONS} disabled state,
 * not of any flag cached in this adapter. The button's enabled state is
 * queried from the controller during bind. When the controller's state
 * changes, the activity calls
 * {@link RecyclerView.Adapter#notifyDataSetChanged()} so rows rebind and
 * the new state is reflected.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every method runs on the main thread, including bind, click
 * handling, and the rebind requested by
 * {@link #refreshRemoveButtonStates()}. The adapter does not start
 * background work of its own.</p>
 *
 * @see FolderManager
 * @see NavigationController
 * @see RecyclerView.Adapter
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Debounce delay for button clicks in milliseconds. */
    private static final long DEBOUNCE_DELAY_MS = 250;

    /** Animation duration for button press effects, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Touch highlight color applied to a pressed row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Context used to inflate rows and resolve resources. */
    private final Context context;

    /** Folder items displayed by this adapter. */
    private final List<FolderItem> folders;

    /** Listener notified when a folder or the Loose Tracks entry is removed. */
    @NonNull
    private final OnFolderRemoveListener removeListener;

    /** Helper that applies theme colors to buttons and text. */
    private final ThemeHelper themeHelper;

    /** Manager that supplies the current theme color. */
    private final ThemeManager themeManager;

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Receives notifications when the user removes a folder or the Loose
     * Tracks entry.
     */
    public interface OnFolderRemoveListener {

        /**
         * Called when a regular folder is removed.
         *
         * @param folderUriString URI string of the folder to remove
         * @param position Position of the folder in the list
         */
        void onFolderRemove(@NonNull String folderUriString, int position);

        /**
         * Called when the Loose Tracks entry is removed.
         */
        void onLooseTracksRemove();
    }

    // ========================================================================
    // FolderItem Class
    // ========================================================================

    /**
     * Represents a single row in the folder list.
     *
     * <p>Every row is either a real folder with a URI, or the special
     * Loose Tracks row that stands for the songs opened from other apps
     * and not present in any imported folder.</p>
     */
    public static class FolderItem {

        /** URI string of the folder, or the literal {@code "LOOSE_TRACKS"} for the special entry. */
        @NonNull
        public final String uriString;

        /** Display name shown to the user. */
        @NonNull
        public final String displayName;

        /** True when this item is the Loose Tracks entry. */
        public final boolean isLooseTracks;

        /** Number of loose tracks; valid only when {@link #isLooseTracks} is true. */
        public final int looseTracksCount;

        /**
         * Constructs a real folder item.
         *
         * @param uriString URI string of the folder
         * @param displayName Display name of the folder
         */
        public FolderItem(@NonNull String uriString, @NonNull String displayName) {
            this.uriString = uriString;
            this.displayName = displayName;
            this.isLooseTracks = false;
            this.looseTracksCount = 0;
        }

        /**
         * Constructs the Loose Tracks item.
         *
         * @param looseTracksCount Number of loose tracks to show
         */
        public FolderItem(int looseTracksCount) {
            this.uriString = "LOOSE_TRACKS";
            this.displayName = "Loose Tracks [" + looseTracksCount + " song"
                + (looseTracksCount != 1 ? "s" : "") + "]";
            this.isLooseTracks = true;
            this.looseTracksCount = looseTracksCount;
        }

        /**
         * Returns a debug representation of this item.
         *
         * @return A string containing the item's fields
         */
        @NonNull
        @Override
        public String toString() {
            return "FolderItem{" +
                    "uriString='" + uriString + '\'' +
                    ", displayName='" + displayName + '\'' +
                    ", isLooseTracks=" + isLooseTracks +
                    ", looseTracksCount=" + looseTracksCount +
                    '}';
        }
    }

    // ========================================================================
    // ViewHolder Class
    // ========================================================================

    /**
     * Caches references to the child views of a folder list row.
     */
    static class FolderViewHolder extends RecyclerView.ViewHolder {

        /** TextView displaying the folder icon. */
        @Nullable
        final TextView folderIcon;

        /** TextView displaying the folder name. */
        @Nullable
        final TextView folderName;

        /** Button that removes the folder. */
        @Nullable
        final Button removeButton;

        /**
         * Constructs a view holder and resolves its child views.
         *
         * @param itemView View for the row
         */
        FolderViewHolder(@NonNull View itemView) {
            super(itemView);
            folderIcon = (TextView) itemView.findViewById(R.id.folderIcon);
            folderName = (TextView) itemView.findViewById(R.id.folderName);
            removeButton = (Button) itemView.findViewById(R.id.removeButton);
        }
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new adapter for the given items.
     *
     * @param context Context used to inflate rows and resolve resources
     * @param folders Folder items to display
     * @param listener Listener notified when a folder is removed
     */
    public FolderAdapter(@NonNull Context context, @NonNull List<FolderItem> folders,
                         @NonNull OnFolderRemoveListener listener) {
        this.context = context;
        this.folders = folders;
        this.removeListener = listener;
        this.themeHelper = ThemeHelper.getInstance(context);
        this.themeManager = ThemeManager.getInstance(context);
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Rebinds every row so the current
     * {@link NavigationController} folder-actions state is reflected on
     * every remove button.
     *
     * <p>Called by the owning activity when the controller's state
     * changes. The adapter does not hold a copy of that state; it queries
     * on bind.</p>
     */
    public void refreshRemoveButtonStates() {
        notifyDataSetChanged();
    }

    /**
     * Replaces the displayed items with the given list.
     *
     * @param newFolders The new folder items to display
     */
    public void updateFolders(@NonNull List<FolderItem> newFolders) {
        folders.clear();
        folders.addAll(newFolders);
        notifyDataSetChanged();
    }

    /**
     * Removes the item at the given position and rebinds the affected
     * range.
     *
     * @param position Position of the item to remove
     */
    public void removeItem(int position) {
        if (position >= 0 && position < folders.size()) {
            folders.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, folders.size() - position);
        }
    }

    // ========================================================================
    // RecyclerView.Adapter Methods
    // ========================================================================

    /**
     * Creates a view holder for a folder row.
     *
     * @param parent Parent view group into which the new view is added
     * @param viewType View type; identical for every row
     * @return A new view holder for the row
     */
    @NonNull
    @Override
    public FolderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_folder, parent, false);
        return new FolderViewHolder(view);
    }

    /**
     * Binds the folder item at the given position to the view holder.
     *
     * <p>Configures the folder icon, the folder name, the remove button
     * state, and the touch feedback for the row.</p>
     *
     * @param holder View holder to bind
     * @param position Position of the item in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final FolderViewHolder holder, int position) {
        if (position < 0 || position >= folders.size()) {
            return;
        }

        final FolderItem folderItem = folders.get(position);
        if (folderItem == null) {
            return;
        }

        final View itemView = holder.itemView;
        final Button removeButton = holder.removeButton;

        if (holder.folderIcon != null) {
            holder.folderIcon.setTypeface(FontAwesome.getTypeface());
            holder.folderIcon.setText(FontAwesome.FOLDER);
            if (themeManager != null && themeHelper != null) {
                themeHelper.setThemeColor(themeManager.getCurrentColor());
                holder.folderIcon.setTextColor(themeHelper.getThemeColorInt());
            }
        }

        if (holder.folderName != null) {
            holder.folderName.setText(folderItem.displayName);
        }

        if (removeButton != null) {
            configureRemoveButton(removeButton, folderItem, holder);
        }

        itemView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setBackgroundColor(Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Returns the number of items currently displayed.
     *
     * @return The number of folder items
     */
    @Override
    public int getItemCount() {
        return folders.size();
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Configures the remove button for a row from the current
     * {@link NavigationController} folder-actions state.
     *
     * @param removeButton Button to configure
     * @param folderItem Folder item associated with the button
     * @param holder View holder that contains the button
     */
    private void configureRemoveButton(@NonNull Button removeButton,
                                        @NonNull FolderItem folderItem,
                                        @NonNull FolderViewHolder holder) {

        boolean enabled = areRemoveButtonsEnabled();

        removeButton.setEnabled(enabled);

        if (themeManager != null && themeHelper != null) {
            themeHelper.setThemeColor(themeManager.getCurrentColor());
            themeHelper.updateButton(removeButton, enabled);
        }

        animateButton(removeButton);

        if (enabled) {
            removeButton.setOnClickListener(createRemoveClickListener(folderItem, holder));
        } else {
            removeButton.setOnClickListener(null);
        }
    }

    /**
     * Returns whether the remove buttons should be interactive.
     *
     * <p>Queries {@link NavigationController}, which owns the
     * folder-actions-disabled state.</p>
     *
     * @return True when remove buttons are enabled
     */
    private boolean areRemoveButtonsEnabled() {
        return !NavigationController.getInstance()
            .isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate
     */
    private void animateButton(@NonNull final Button button) {
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Creates a click listener for the remove button, guarded by a
     * debounce.
     *
     * @param folderItem Folder item associated with the button
     * @param holder View holder that contains the button
     * @return A new click listener
     */
    @NonNull
    private View.OnClickListener createRemoveClickListener(@NonNull final FolderItem folderItem,
                                                             @NonNull final FolderViewHolder holder) {
        return new View.OnClickListener() {
            private long lastClickTime = 0;

            @Override
            public void onClick(@NonNull View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - lastClickTime < DEBOUNCE_DELAY_MS) {
                    return;
                }
                lastClickTime = currentTime;

                int position = holder.getAdapterPosition();
                if (position == RecyclerView.NO_POSITION) {
                    return;
                }

                if (folderItem.isLooseTracks) {
                    removeListener.onLooseTracksRemove();
                } else {
                    removeListener.onFolderRemove(folderItem.uriString, position);
                }
            }
        };
    }
}