package com.ark.llama;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;

import java.util.ArrayList;

/**
 * Answers whether the runtime permissions the app needs are granted.
 *
 * <p>The set of permissions the app requests is version-gated: the
 * media-read permission the app asks for is {@code READ_MEDIA_AUDIO}
 * on API 33 and later and {@code READ_EXTERNAL_STORAGE} below that,
 * {@code POST_NOTIFICATIONS} is required from API 33, the
 * foreground-service media-playback permission is required from API
 * 34, and the Bluetooth connect permission is required from API 31.
 * The set lives here, in one place, so every reader of "are the
 * permissions granted" reads the same answer.</p>
 *
 * <h3>Readers</h3>
 * <p>Three readers use this class:</p>
 * <ul>
 *   <li>{@link MusicPlayer#checkPermissionsAndInitialize()} asks
 *       {@link #getMissing(Context)} for the array it requests. The
 *       activity builds no list of its own.</li>
 *   <li>{@link MusicPlayer#onResume()} asks
 *       {@link #allGranted(Context)} on every pass, so a permission
 *       restore is noticed without a restart and the initialization
 *       flow runs again from a clean slate.</li>
 *   <li>{@link FolderManager} asks {@link #allGranted(Context)} as one
 *       half of {@code areFolderChangesAllowed()}. The folder controls
 *       disable themselves while the app cannot read the music, and
 *       this is the read that drives them.</li>
 * </ul>
 *
 * <p>Because the three readers share this class, they cannot disagree
 * about what "permitted" means. A second copy of the set would drift
 * the moment one of the version gates changed.</p>
 *
 * <h3>Below the runtime-permission model</h3>
 * <p>{@link Build.VERSION_CODES#M} is the floor for the runtime
 * permission model. Below that, permission grants are established at
 * install time and {@link Context#checkSelfPermission(String)} does
 * not apply. Both public methods return the honest answer for that
 * case: {@link #allGranted(Context)} returns true, and
 * {@link #getMissing(Context)} returns an empty array.</p>
 *
 * <h3>Single computation</h3>
 * <p>{@link #allGranted(Context)} is the length of the array
 * {@link #getMissing(Context)} returns. The two answers come from one
 * computation, so a change to the version gates cannot leave the
 * yes-or-no question and the missing-list question in disagreement.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Both methods are static and hold no state. They call
 * {@link Context#checkSelfPermission(String)}, which is safe to call
 * from any thread. Callers in this app call them from the main
 * thread.</p>
 *
 * @see MusicPlayer
 * @see FolderManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.9
 * @since 1.2.9
 */
public final class PermissionChecker {

    // ============================================================================
    // Permission Names
    // ============================================================================

    /**
     * Media-read permission name on API 33 and later.
     *
     * <p>Android 13 replaced the coarse external-storage grant with a
     * granular audio-read permission. The string is declared here
     * rather than read from {@link Manifest.permission}, because the
     * framework constant is not available below API 33 and the check
     * is version gated.</p>
     */
    private static final String PERMISSION_READ_MEDIA_AUDIO =
        "android.permission.READ_MEDIA_AUDIO";

    /**
     * Notification-post permission name on API 33 and later.
     *
     * <p>The playback notification needs this grant to appear in the
     * shade on Android 13 and later. The string is declared here for
     * the same reason as {@link #PERMISSION_READ_MEDIA_AUDIO}.</p>
     */
    private static final String PERMISSION_POST_NOTIFICATIONS =
        "android.permission.POST_NOTIFICATIONS";

    /**
     * Foreground-service media-playback permission name on API 34 and
     * later.
     *
     * <p>Android 14 requires this permission for a service that
     * declares {@code foregroundServiceType="mediaPlayback"} to
     * promote itself to the foreground. The string is declared here for
     * the same reason as {@link #PERMISSION_READ_MEDIA_AUDIO}.</p>
     */
    private static final String
        PERMISSION_FOREGROUND_SERVICE_MEDIA_PLAYBACK =
            "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK";

    /**
     * Bluetooth-connect permission name on API 31 and later.
     *
     * <p>Android 12 requires this permission for the headset media
     * button routing that {@link BluetoothReceiver} and
     * {@link MusicService} rely on. The string is declared here for the
     * same reason as {@link #PERMISSION_READ_MEDIA_AUDIO}.</p>
     */
    private static final String PERMISSION_BLUETOOTH_CONNECT =
        "android.permission.BLUETOOTH_CONNECT";

    // ============================================================================
    // Private Constructor
    // ============================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private PermissionChecker() {
    }

    // ============================================================================
    // Public Methods
    // ============================================================================

    /**
     * Returns whether every runtime permission the app needs is
     * currently granted.
     *
     * <p>Below {@link Build.VERSION_CODES#M} the runtime permission
     * model does not apply, and this method returns true. From API 23
     * on, it checks each permission the running release requires.</p>
     *
     * @param context Context used to check the grants; the application
     *        context is sufficient
     * @return True when every required permission is granted
     */
    public static boolean allGranted(@NonNull Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        return getMissing(context).length == 0;
    }

    /**
     * Returns the runtime permissions the app needs that are not
     * granted.
     *
     * <p>Below {@link Build.VERSION_CODES#M} the runtime permission
     * model does not apply, and the returned array is empty. From API
     * 23 on, the array contains one entry per missing permission, in
     * the order the version gate adds them.</p>
     *
     * <p>Callers that only need a yes-or-no answer should use
     * {@link #allGranted(Context)}, which is the length of this array.</p>
     *
     * @param context Context used to check the grants; the application
     *        context is sufficient
     * @return An array of missing permission names; empty when every
     *         required permission is granted or the runtime permission
     *         model does not apply
     */
    @NonNull
    public static String[] getMissing(@NonNull Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return new String[0];
        }

        final ArrayList<String> missing = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 33) {
            if (context.checkSelfPermission(
                    PERMISSION_READ_MEDIA_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(PERMISSION_READ_MEDIA_AUDIO);
            }
            if (context.checkSelfPermission(
                    PERMISSION_POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(PERMISSION_POST_NOTIFICATIONS);
            }
        } else {
            if (context.checkSelfPermission(
                    Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(
                    Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            if (context.checkSelfPermission(
                    PERMISSION_FOREGROUND_SERVICE_MEDIA_PLAYBACK)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(
                    PERMISSION_FOREGROUND_SERVICE_MEDIA_PLAYBACK);
            }
        }

        if (Build.VERSION.SDK_INT >= 31) {
            if (context.checkSelfPermission(
                    PERMISSION_BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(PERMISSION_BLUETOOTH_CONNECT);
            }
        }

        return missing.toArray(new String[0]);
    }
}