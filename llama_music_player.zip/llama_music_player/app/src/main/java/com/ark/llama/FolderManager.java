package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Activity for managing music folders.
 *
 * <p>This activity allows users to:
 * <ul>
 *   <li>View all imported music folders</li>
 *   <li>Add new folders via Storage Access Framework (SAF)</li>
 *   <li>Remove folders from the playlist (changes applied when UPDATE is clicked)</li>
 *   <li>View and manage loose tracks (songs opened from other apps)</li>
 *   <li>Trigger playlist synchronization after folder changes</li>
 * </ul>
 * </p>
 *
 * <h3>Architecture Overview</h3>
 * <p>FolderManager follows a pending-changes pattern where folder removals
 * are staged in a {@link PendingChanges} holder until the user confirms by
 * clicking UPDATE. This allows for batch operations and prevents
 * unnecessary playlist rebuilds.</p>
 *
 * <p>The activity also triggers the genre loading phase (Phase 2) after the
 * initial playlist scan completes, ensuring that all songs receive their
 * proper genres from ID3 tags in the background without blocking the UI.</p>
 *
 * <h3>State Ownership</h3>
 * <p>Three pieces of state are involved in an update cycle, each with a
 * single owner:</p>
 * <ul>
 *   <li><b>Pending changes</b> — owned by this activity through
 *       {@link #mPendingChanges}. Staging is local to the activity and
 *       lives only for the duration of an editing session.</li>
 *   <li><b>Update-in-progress</b> — owned by {@link NavigationController}.
 *       This activity queries the controller rather than caching the flag,
 *       so the two can never drift even if a broadcast is dropped.</li>
 *   <li><b>Player state</b> — owned by {@link MusicService}. The activity
 *       sends broadcast messages to it; it never reads the service's
 *       internal fields directly.</li>
 * </ul>
 *
 * <h3>Overlay Ownership</h3>
 * <p>Two operations run in sequence during a folder update:</p>
 * <ul>
 *   <li><b>Folder sync</b> — owned by this activity. Its persistent
 *       overlay is shown with the {@code "FOLDER_SYNC"} operation ID and
 *       hidden by the same ID. When the sync completes, the overlay is
 *       torn down cleanly before genre loading is triggered.</li>
 *   <li><b>Genre loading</b> — owned by {@link PlaylistService}. Its
 *       overlay is shown with the {@code "GENRE_UPDATE"} operation ID and
 *       hidden by the same ID. This activity does not show, update, or
 *       hide it; it only observes the {@code GENRE_UPDATE} broadcasts for
 *       its own progress reporting.</li>
 * </ul>
 *
 * <h3>Full Library Wipe</h3>
 * <p>When the user removes every folder and every loose track, this
 * activity runs a full library wipe in {@link #handleNoContentRemaining}:
 * the database is cleared, the SAF permission mappings are dropped, the
 * persisted player state is cleared, and {@code RESET_PLAYER_STATE} is
 * sent with {@code preserve_settings=false} so the service also clears
 * its playback preferences. Leftover {@code temp_audio_*} and
 * {@code backup_*} files in the cache directory are swept. The equalizer
 * preferences are intentionally not touched: the user must be able to add
 * folders back without reconfiguring the equalizer.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — {@link #mPendingChanges} is the only holder of staged
 *       removals. No other field or local variable accumulates them.</li>
 *   <li>I2 — Reads of "is an update in progress" query
 *       {@link NavigationController#isGroupDisabled(NavigationController.ButtonGroup)}
 *       through {@link #isUpdating()}. The activity does not cache the
 *       flag.</li>
 *   <li>I3 — Every path that begins an update calls
 *       {@link NavigationController#beginPlaylistSync()} before modifying
 *       any state, and ends it through the matching end call.</li>
 *   <li>I4 — {@link #mPendingChanges} is cleared only by
 *       {@link #loadFolders()}, which runs on resume and on update
 *       completion. No path clears it mid-cycle.</li>
 *   <li>I5 — The {@code "FOLDER_SYNC"} overlay is owned exclusively by
 *       this activity. It is shown when the first progress update arrives
 *       and hidden by ID before genre loading begins.</li>
 *   <li>I6 — The {@code "GENRE_UPDATE"} overlay is owned exclusively by
 *       {@link PlaylistService}. This activity never shows, updates, or
 *       hides it.</li>
 *   <li>I7 — When a folder-update cycle ends, {@link #loadFolders()} runs
 *       before {@link NavigationController#endPlaylistSync()}, so the
 *       button state callback fired by the end call sees the post-update
 *       state.</li>
 *   <li>I8 — Remove-button enabled state is a function of
 *       {@link NavigationController}'s folder-actions state. This
 *       activity does not push that state into {@link FolderAdapter}; the
 *       adapter queries the controller on bind.</li>
 *   <li>I9 — The full-wipe path clears only library- and session-scoped
 *       preference keys. It never calls {@code prefs.edit().clear()}, and
 *       it never writes or removes any key owned by
 *       {@link EqualizerManager}. See the invariant note on
 *       {@link #handleNoContentRemaining}.</li>
 * </ul>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class FolderManager extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    private static final int FOLDER_SELECT_CODE = 300;
    private static final String TAG = "FolderManager";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_SELECTED_FOLDERS_URIS = "selected_folders_uris";
    private static final String KEY_CURRENT_PLAYING_INDEX = "current_playing_index";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    private static final int STATE_SAVE_DELAY_MS = 150;
    private static final int OVERLAY_HIDE_DELAY_MS = 1500;
    private static final int ANIMATION_DURATION_MS = 80;
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    private static final int EMPTY_CONTAINER_TOP_PADDING_DP = 64;

    private static final String ACTION_SAVE_PLAYER_STATE_NOW = "SAVE_PLAYER_STATE_NOW";
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS = "UPDATE_PLAYLIST_FROM_FOLDERS";
    private static final String ACTION_RESET_PLAYER_STATE = "RESET_PLAYER_STATE";
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";
    private static final String ACTION_SYNC_STARTED = "SYNC_STARTED";
    private static final String ACTION_STOP = "ACTION_STOP";
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    private static final String ACTION_LOOSE_TRACKS_UPDATED = "LOOSE_TRACKS_UPDATED";

    private long mLastCancelClickTime = 0;
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /**
     * Operation ID for the folder-sync overlay owned by this activity.
     *
     * <p>The overlay is shown when the first progress update arrives and
     * hidden by the same ID before genre loading begins. Using a distinct
     * ID from {@code "GENRE_UPDATE"} ensures the folder-sync overlay can
     * be torn down without disturbing the genre-loading overlay that
     * {@link PlaylistService} manages.</p>
     */
    private static final String OP_FOLDER_SYNC = "FOLDER_SYNC";

    // ========================================================================
    // Pending Changes Holder
    // ========================================================================

    private static final class PendingChanges {

        @NonNull
        private final ArrayList<String> mFoldersToRemove = new ArrayList<String>();

        private boolean mClearLooseTracks = false;

        void addFolderToRemove(@NonNull String folderUri) {
            if (!mFoldersToRemove.contains(folderUri)) {
                mFoldersToRemove.add(folderUri);
            }
        }

        void markLooseTracksForRemoval() {
            mClearLooseTracks = true;
        }

        boolean isEmpty() {
            return mFoldersToRemove.isEmpty() && !mClearLooseTracks;
        }

        boolean isClearLooseTracks() {
            return mClearLooseTracks;
        }

        @NonNull
        ArrayList<String> getFoldersToRemove() {
            return new ArrayList<>(mFoldersToRemove);
        }

        void clear() {
            mFoldersToRemove.clear();
            mClearLooseTracks = false;
        }
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    private MusicLibrary mMusicLibrary;
    private RecyclerView mFoldersRecyclerView;
    private FolderAdapter mFolderAdapter;
    private List<FolderAdapter.FolderItem> mFolderItems;
    private TextView mFolderCountText;

    @NonNull
    private final PendingChanges mPendingChanges = new PendingChanges();

    private boolean mGenreUpdateTriggered = false;
    private LinearLayout mEmptyContainer;
    private FrameLayout mRootContainer;
    private ThemeManager mThemeManager;
    private ThemeHelper mThemeHelper;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mLooseTracksUpdateReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_folder_manager);

        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mFolderItems = new ArrayList<FolderAdapter.FolderItem>();

        initializeViews();
        loadFolders();
        registerLooseTracksReceiver();
        registerSyncCompleteReceiver();
        applyThemeToUI();
        themeAllHeaders();

        NavigationController.getInstance().registerListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiverSafely(mThemeReceiver);
        mThemeReceiver = null;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart - FolderManager resumed, update in progress: " + isUpdating());

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }

        ToastManager.ensureOverlayAttached(this);

        updateFolderButtons();

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();

        if (isUpdating()) {
            PlaylistService playlistService = PlaylistService.getInstance(this);
            if (playlistService != null && playlistService.isUpdating()) {
                ToastManager.ensureOverlayAttached(this);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        NavigationController.getInstance().unregisterListener(this);

        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mLooseTracksUpdateReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        mMainHandler.removeCallbacksAndMessages(null);

        ToastManager.hidePersistentOverlay();
    }

    @Override
    public void onBackPressed() {
        returnToMusicPlayer();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                persistFolderPermission(treeUri);
            }
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    // ========================================================================
    // Update State Query
    // ========================================================================

    private boolean isUpdating() {
        return NavigationController.getInstance()
            .isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================

    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Button updateButton = (Button) findViewById(R.id.updateButton);
                    if (updateButton != null) {
                        updateButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(updateButton, !finalDisabled);
                        }
                    }

                    Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                    if (importFolderButton != null) {
                        importFolderButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(importFolderButton, !finalDisabled);
                        }
                    }

                    // The adapter queries NavigationController on bind. A
                    // rebind is all that is needed to reflect the new state.
                    if (mFolderAdapter != null) {
                        mFolderAdapter.refreshRemoveButtonStates();
                    }

                    updateFolderButtons();
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    private void initializeViews() {
        mFoldersRecyclerView = (RecyclerView) findViewById(R.id.foldersRecyclerView);
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setLayoutManager(new LinearLayoutManager(this));

            DividerItemDecoration divider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
            divider.setDrawable(ContextCompat.getDrawable(this, R.drawable.divider_custom));
            mFoldersRecyclerView.addItemDecoration(divider);
        }

        mFolderCountText = (TextView) findViewById(R.id.folderCountText);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);

        animateButton(importFolderButton);
        animateButton(updateButton);
        animateButton(cancelButton);

        mFolderAdapter = new FolderAdapter(this, mFolderItems, new FolderAdapter.OnFolderRemoveListener() {
            @Override
            public void onFolderRemove(@NonNull String folderUriString, int position) {
                mPendingChanges.addFolderToRemove(folderUriString);
                mFolderAdapter.removeItem(position);
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }

            @Override
            public void onLooseTracksRemove() {
                mPendingChanges.markLooseTracksForRemoval();
                for (int index = 0; index < mFolderItems.size(); index++) {
                    if (mFolderItems.get(index).isLooseTracks) {
                        mFolderAdapter.removeItem(index);
                        break;
                    }
                }
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }
        });

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setAdapter(mFolderAdapter);
        }

        if (importFolderButton != null) {
            importFolderButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        selectFolder();
                    }
                }
            });
        }

        if (updateButton != null) {
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        saveChanges();
                    }
                }
            });
        }

        if (cancelButton != null) {
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        returnToMusicPlayer();
                    }
                }
            });
        }
    }

    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // UI State Management Methods
    // ========================================================================

    private void showEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_TOP_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText("Tap IMPORT FOLDER to add music folders.\nTap UPDATE to save changes.\n\nMusic files opened from other apps\nwill appear here as Loose Tracks.");
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mRootContainer != null) {
            mRootContainer.addView(mEmptyContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        }

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.GONE);
        }
    }

    private void hideEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }
        mEmptyContainer = null;

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void updateFolderCount() {
        int folderCount = 0;
        boolean hasLooseTracks = false;

        for (FolderAdapter.FolderItem folderItem : mFolderItems) {
            if (folderItem.isLooseTracks) {
                hasLooseTracks = true;
            } else {
                folderCount++;
            }
        }

        if (hasLooseTracks) {
            folderCount++;
        }

        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));

            if (folderCount == 0) {
                mFolderCountText.setText("0 folders");
            } else if (folderCount == 1) {
                mFolderCountText.setText("1 folder");
            } else {
                mFolderCountText.setText(folderCount + " folders");
            }
        }
    }

    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);

        mThemeHelper.updateButton(importFolderButton, importFolderButton != null && importFolderButton.isEnabled());
        mThemeHelper.updateButton(updateButton, updateButton != null && updateButton.isEnabled());
        mThemeHelper.updateButton(cancelButton, cancelButton != null && cancelButton.isEnabled());

        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }
    }

    private void themeAllHeaders() {
        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("MANAGER") ||
                    text.equals("FOLDER LIST") ||
                    text.contains("folders") ||
                    text.contains("folder")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ========================================================================
    // Folder Management Methods
    // ========================================================================

    private void persistFolderPermission(@NonNull Uri treeUri) {
        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;

        try {
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (SecurityException exception) {
            ToastManager.showToast(this, "Permission denied for folder", ToastManager.LENGTH_NORMAL);
            return;
        }

        String folderUriString = treeUri.toString();
        mMusicLibrary.addFolder(folderUriString);
        cleanLooseSongsInFolder(treeUri);
        loadFolders();

        String folderName = getFolderNameFromUri(treeUri);
        if (folderName != null) {
            ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
        }
    }

    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }

        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null || looseSongs.isEmpty()) {
            return;
        }

        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong != null && looseSong.getPath() != null && looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
            }
        }
    }

    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();

        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) subPath = subPath.replace("%2F", "/");
                if (subPath.contains("/tree/")) subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                if (subPath.contains("/document/")) subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to get folder path", exception);
                return null;
            }
        }
        return null;
    }

    @NonNull
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;

        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to get folder name", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to close cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        if (name == null) {
            name = "Music Folder";
        }

        return CharacterMapper.cleanString(name);
    }

    @NonNull
    private String getStorageType(@NonNull String uriString) {
        String uriLower = uriString.toLowerCase();

        if (uriLower.contains("primary") || uriLower.contains("emulated")) {
            return " [Internal]";
        } else if (uriLower.contains("external") || uriLower.contains("sdcard") ||
                   uriLower.contains("extsdcard") || uriLower.contains("extsd") ||
                   uriLower.matches(".*[0-9a-f]{4}-[0-9a-f]{4}.*")) {
            return " [SD Card]";
        }

        return "";
    }

    private void loadFolders() {
        mFolderItems.clear();
        Set<String> folders = mMusicLibrary.getSelectedFolders();
        mPendingChanges.clear();

        Log.d(TAG, "loadFolders: " + folders.size() + " folders found");

        ArrayList<Song> validLooseSongs = getValidLooseSongs();
        boolean hasLooseSongs = !validLooseSongs.isEmpty();

        if (folders.isEmpty() && !hasLooseSongs) {
            showEmptyView();
        } else {
            hideEmptyView();

            for (final String folderUriString : folders) {
                Uri folderUri = Uri.parse(folderUriString);
                String name = getFolderNameFromUri(folderUri);
                String storageType = getStorageType(folderUriString);
                String displayName = name + storageType;
                mFolderItems.add(new FolderAdapter.FolderItem(folderUriString, displayName));
            }

            if (hasLooseSongs) {
                mFolderItems.add(new FolderAdapter.FolderItem(validLooseSongs.size()));
            }

            mFolderAdapter.refreshRemoveButtonStates();
        }

        updateFolderCount();
        themeAllHeaders();
        updateFolderButtons();
    }

    @NonNull
    private ArrayList<Song> getValidLooseSongs() {
        ArrayList<Song> validLooseSongs = new ArrayList<Song>();
        ArrayList<Song> allLooseSongs = SongDatabase.getInstance(this).getLooseSongs();

        if (allLooseSongs != null) {
            for (Song looseSong : allLooseSongs) {
                if (looseSong != null && looseSong.getPath() != null) {
                    File file = new File(looseSong.getPath());
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(looseSong);
                    } else {
                        SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
                    }
                }
            }
        }

        return validLooseSongs;
    }

    private void selectFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(intent, FOLDER_SELECT_CODE);
        } catch (Exception exception) {
            ToastManager.showToast(this, "No file manager found", ToastManager.LENGTH_NORMAL);
        }
    }

    // ========================================================================
    // Button State Management
    // ========================================================================

    private void updateFolderButtons() {
        // The adapter queries NavigationController on bind; a refresh here
        // is all that is needed to align its view with the controller's.
        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        if (importFolderButton != null) {
            importFolderButton.setEnabled(!isUpdating());
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(importFolderButton, !isUpdating());
            }
        }

        boolean hasFolders = !mFolderItems.isEmpty();
        boolean hasPendingRemovals = !mPendingChanges.isEmpty();
        boolean shouldEnableUpdateButton = (hasFolders || hasPendingRemovals) && !isUpdating();

        Button updateButton = (Button) findViewById(R.id.updateButton);
        if (updateButton != null) {
            updateButton.setEnabled(shouldEnableUpdateButton);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(updateButton, shouldEnableUpdateButton);
            }
        }
    }

    private void disableButton(@Nullable Button button) {
        if (button != null) {
            button.setEnabled(false);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(button, false);
            }
        }
    }

    // ========================================================================
    // Update Management Methods
    // ========================================================================

    private void saveChanges() {
        PlaylistService playlistService = PlaylistService.getInstance(this);
        if (playlistService != null && playlistService.isUpdating()) {
            ToastManager.showToast(this, "Playlist sync already in progress. Please wait...", ToastManager.LENGTH_NORMAL);
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final boolean clearLooseTracks = mPendingChanges.isClearLooseTracks();

        final Set<String> foldersToKeep = new HashSet<String>(mMusicLibrary.getSelectedFolders());
        for (String folderUriString : mPendingChanges.getFoldersToRemove()) {
            foldersToKeep.remove(folderUriString);
        }

        boolean hasLooseAfterClear = false;
        if (!clearLooseTracks) {
            ArrayList<Song> remainingLoose = SongDatabase.getInstance(this).getLooseSongs();
            hasLooseAfterClear = remainingLoose != null && !remainingLoose.isEmpty();
        }

        final boolean hasAnyFolders = !foldersToKeep.isEmpty();
        final boolean hasAnyContent = hasAnyFolders || hasLooseAfterClear;

        updateFolderButtons();

        Intent saveIntent = new Intent(ACTION_SAVE_PLAYER_STATE_NOW);
        sendBroadcast(saveIntent);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MusicService.setPlayerStateBeforeUpdate(FolderManager.this, true);

                Button updateButton = (Button) findViewById(R.id.updateButton);
                Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                disableButton(updateButton);
                disableButton(importFolderButton);

                if (clearLooseTracks) {
                    SongDatabase.getInstance(FolderManager.this).clearLooseSongs();
                }

                for (String folderUriString : mPendingChanges.getFoldersToRemove()) {
                    mMusicLibrary.removeFolder(folderUriString);
                    // Drop the SAF permission mapping for this folder.
                    // Without this the StorageAccessHelper retains a
                    // persistent permission that refers to a folder the user
                    // has removed from the library.
                    try {
                        StorageAccessHelper.getInstance(FolderManager.this)
                            .removeFolderPermission(Uri.parse(folderUriString));
                    } catch (Exception exception) {
                        Log.w(TAG, "Failed to drop SAF permission for " + folderUriString, exception);
                    }
                }

                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putStringSet(KEY_SELECTED_FOLDERS_URIS, foldersToKeep).apply();

                if (!hasAnyContent) {
                    handleNoContentRemaining(prefs);
                    return;
                }

                if (!hasAnyFolders) {
                    handleNoFoldersRemaining(prefs);
                    return;
                }

                performPlaylistUpdate();
            }
        }, STATE_SAVE_DELAY_MS);
    }

    private void updateComplete() {
        Intent updateIntent = new Intent(ACTION_UPDATE_PLAYLIST_FROM_FOLDERS);
        sendBroadcast(updateIntent);

        NavigationController.getInstance().endPlaylistSync();

        loadFolders();
        updateFolderButtons();
    }

    /**
     * Handles the case where the user has removed every folder and every
     * loose track. This is a full library wipe: the database tables, the
     * persisted player state, the folder permission mappings, and any
     * transient cache files are all torn down, and the reset broadcast is
     * sent with {@code preserve_settings=false} so the service also clears
     * the playback preferences that only make sense with a populated
     * library.
     *
     * <p><b>INVARIANT</b>: this method clears only library- and
     * session-scoped preference keys. It never calls
     * {@code prefs.edit().clear()}, and it never writes or removes any key
     * owned by {@link EqualizerManager} (equalizer_enabled,
     * selected_preset, eq_band_*, eq_custom_*, bass_boost_level,
     * surround_level, pitch_level, speed_level, has_custom_*). The user's
     * equalizer settings must survive a full library wipe so that adding
     * folders back does not force them to reconfigure the equalizer.</p>
     *
     * <p>The keys this method is responsible for are exactly:
     * {@code current_playing_index}, {@code current_position},
     * {@code last_playing}, {@code last_song_path},
     * {@code player_state_before_update}; plus, via
     * {@link StorageAccessHelper#clearAll()}, the {@code folder_uri_*},
     * {@code path_uri_*}, and {@code known_folder_uris} keys; and, via the
     * {@code RESET_PLAYER_STATE} receiver in {@link MusicService}, the
     * {@code repeat_mode}, {@code shuffle}, and {@code playlist_sort_mode}
     * keys.</p>
     *
     * @param prefs the shared preferences handle
     */
    private void handleNoContentRemaining(@NonNull SharedPreferences prefs) {
        SongDatabase database = SongDatabase.getInstance(this);
        database.clearCache();
        database.clearLooseSongs();

        // Belt and suspenders: the per-folder removals in saveChanges()
        // drop the mappings for the folders the user just removed, but a
        // full library wipe should also clear any orphaned mappings left
        // behind by a prior session.
        StorageAccessHelper.getInstance(this).clearAll();

        prefs.edit()
            .putInt(KEY_CURRENT_PLAYING_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mMusicLibrary.refreshCache();

        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);

        Intent resetIntent = new Intent(ACTION_RESET_PLAYER_STATE);
        // Full wipe: the service resets repeat mode, shuffle, and sort mode
        // alongside its own teardown.
        resetIntent.putExtra("preserve_settings", false);
        sendBroadcast(resetIntent);

        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);

        ToastManager.showPersistentOverlay(this, "Syncing playlist...");

        // Reload folders and clear pending changes BEFORE ending the sync.
        // The button-state callback fired by endPlaylistSync then sees the
        // post-update state (no folders, no pending removals) and leaves
        // the UPDATE button disabled without flickering through an
        // intermediate enabled state.
        loadFolders();

        NavigationController.getInstance().endPlaylistSync();

        cleanupTempCacheAsync();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();

                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    /**
     * Deletes leftover {@code temp_audio_*} and {@code backup_*} files from
     * the cache directory. These are created during URI-based reads and
     * writes and are normally cleaned up by their own code paths; any that
     * remain at this point indicate a previously interrupted operation.
     *
     * <p>Runs on a short-lived background thread because it touches disk.
     * Failure is logged and ignored: a stale file is not a correctness
     * problem.</p>
     */
    private void cleanupTempCacheAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File cacheDir = getCacheDir();
                    if (cacheDir == null || !cacheDir.isDirectory()) return;
                    File[] files = cacheDir.listFiles();
                    if (files == null) return;
                    for (File file : files) {
                        if (file == null || !file.isFile()) continue;
                        String name = file.getName();
                        if (name.startsWith("temp_audio_") || name.startsWith("backup_")) {
                            if (file.delete()) {
                                Log.d(TAG, "Deleted stale temp file: " + name);
                            }
                        }
                    }
                } catch (Exception exception) {
                    Log.w(TAG, "cleanupTempCache failed", exception);
                }
            }
        }).start();
    }

    private void handleNoFoldersRemaining(@NonNull SharedPreferences prefs) {
        SongDatabase database = SongDatabase.getInstance(this);

        ArrayList<Song> looseSongs = database.getLooseSongs();

        database.clearCache();

        if (!looseSongs.isEmpty()) {
            database.insertSongsBatch(looseSongs);
        }

        prefs.edit()
            .putInt(KEY_CURRENT_PLAYING_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mMusicLibrary.refreshCache();

        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);

        Intent refreshIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
        sendBroadcast(refreshIntent);

        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);

        ToastManager.showPersistentOverlay(this, "Syncing playlist...");

        // Same ordering rule as handleNoContentRemaining: reload folders and
        // clear pending changes before ending the sync.
        loadFolders();

        NavigationController.getInstance().endPlaylistSync();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();

                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    private void performPlaylistUpdate() {
        final boolean[] persistentShown = {false};

        PlaylistService.getInstance(this).updatePlaylist(new PlaylistService.UpdateCallback() {
            @Override
            public void onProgress(final int current, final int total) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String progressMessage;
                        if (current == 0) {
                            progressMessage = "Searching folders...";
                        } else if (current < total) {
                            progressMessage = "Searching folders... " + current + " song" +
                                (current != 1 ? "s" : "") + " found";
                        } else {
                            progressMessage = "Syncing playlist... " + current + " song" +
                                (current != 1 ? "s" : "") + " found";
                        }

                        if (!persistentShown[0]) {
                            ToastManager.showPersistentOverlay(FolderManager.this,
                                progressMessage, OP_FOLDER_SYNC);
                            persistentShown[0] = true;
                        } else {
                            ToastManager.updatePersistentOverlay(progressMessage);
                        }

                        Intent syncStartedIntent = new Intent(ACTION_SYNC_STARTED);
                        syncStartedIntent.putExtra("custom_text", progressMessage);
                        sendBroadcast(syncStartedIntent);
                    }
                });
            }

            @Override
            public void onComplete(final int songCount) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mPendingChanges.isClearLooseTracks()) {
                            Log.d(TAG, "User removed Loose Tracks - deleting loose songs");
                            SongDatabase database = SongDatabase.getInstance(FolderManager.this);
                            database.clearLooseSongs();
                            database.deleteSongsNotInSet(mMusicLibrary.getSelectedFolders(), false);
                        }

                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);

                        // Hand off cleanly: hide this operation's overlay by
                        // its own ID, then let PlaylistService show and own
                        // the "GENRE_UPDATE" overlay for the duration of
                        // genre loading.
                        ToastManager.hidePersistentOverlay(OP_FOLDER_SYNC);

                        triggerGenreUpdate();

                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                updateComplete();
                                updateFolderButtons();
                                loadFolders();
                                mGenreUpdateTriggered = false;
                            }
                        }, OVERLAY_HIDE_DELAY_MS);
                    }
                });
            }

            @Override
            public void onError(@NonNull final String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (persistentShown[0]) {
                            ToastManager.hidePersistentOverlay(OP_FOLDER_SYNC);
                        }

                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);

                        NavigationController.getInstance().endPlaylistSync();

                        updateFolderButtons();
                        ToastManager.showToast(FolderManager.this, "Error: " + error,
                            ToastManager.LENGTH_NORMAL);
                    }
                });
            }
        });
    }

    /**
     * Triggers genre loading via {@link PlaylistService}.
     *
     * <p>{@link PlaylistService} owns the {@code "GENRE_UPDATE"} overlay for
     * the entire lifetime of genre loading. It shows the overlay
     * synchronously on the main thread with the {@code "GENRE_UPDATE"}
     * operation ID, heartbeats it independently of the ID3 read loop, and
     * hides it by the same ID when the load completes. This activity does
     * not show, update, or hide the overlay; it observes the
     * {@code GENRE_UPDATE} broadcasts only for its own progress
     * reporting.</p>
     */
    private void triggerGenreUpdate() {
        if (mGenreUpdateTriggered) {
            Log.d(TAG, "Genre update already triggered, skipping");
            return;
        }
        mGenreUpdateTriggered = true;

        PlaylistService playlistService = PlaylistService.getInstance(this);

        if (playlistService.isGenreLoading()) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        playlistService.triggerGenreLoading();
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================

    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();

                    if (mFolderAdapter != null) {
                        mFolderAdapter.refreshRemoveButtonStates();
                    }

                    ToastManager.refreshThemeColor();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        registerReceiver(mThemeReceiver, filter);
    }

    private void registerLooseTracksReceiver() {
        mLooseTracksUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_LOOSE_TRACKS_UPDATED.equals(intent.getAction())) {
                    loadFolders();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_LOOSE_TRACKS_UPDATED);
        registerReceiver(mLooseTracksUpdateReceiver, filter);
    }

    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SYNC_COMPLETE.equals(intent.getAction())) {
                    Log.d(TAG, "Sync complete - refreshing MusicLibrary cache");
                    if (mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                    }
                    loadFolders();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_SYNC_COMPLETE);
        registerReceiver(mSyncCompleteReceiver, filter);
    }

    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception ignored) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}