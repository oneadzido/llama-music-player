// FolderManager.java
package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Displays and edits the set of imported music folders and the
 * Loose Tracks entry.
 *
 * <p>The activity shows every imported folder and the Loose Tracks
 * entry in a list, lets the user add a folder through the Storage
 * Access Framework, stage folder removals, and commit those
 * removals by tapping UPDATE. Committing runs a playlist sync;
 * when the sync completes this activity broadcasts
 * {@code UPDATE_PLAYLIST_FROM_FOLDERS} and hands ownership of the
 * persistent overlay to {@link MusicPlayer}.</p>
 *
 * <h3>State Ownership</h3>
 * <p>Five pieces of state participate in an update cycle, each with
 * a single owner:</p>
 * <ul>
 *   <li><b>Pending changes</b> — owned by this activity.</li>
 *   <li><b>Update-in-progress</b> — owned by
 *       {@link NavigationController}.</li>
 *   <li><b>Player state</b> — owned by {@link MusicService}.</li>
 *   <li><b>Library reset</b> — owned by {@link PlaylistManager}.</li>
 *   <li><b>Runtime permissions</b> — owned by
 *       {@link PermissionChecker}. The folder-mutating controls
 *       read that owner through this activity's
 *       {@code areFolderChangesAllowed()} and show as disabled
 *       while the app cannot read the music.</li>
 * </ul>
 *
 * <h3>The Update Cycle</h3>
 * <p>An update cycle runs in one of three shapes, chosen from the
 * content that remains after the user's staged removals:</p>
 * <ul>
 *   <li><b>No folders and no loose tracks</b> — the full library
 *       wipe calls {@link PlaylistManager#resetLibrary} in
 *       {@link PlaylistManager.ResetMode#LIBRARY} mode.</li>
 *   <li><b>No folders, loose tracks remain</b> — the loose tracks
 *       are snapshotted before the reset and re-inserted into the
 *       songs table in the reset's completion callback.</li>
 *   <li><b>Some folders remain</b> — the playlist is updated
 *       through {@link PlaylistManager#updatePlaylist}, which scans
 *       every remaining folder and reconciles the songs table
 *       against the paths it finds.</li>
 * </ul>
 *
 * <h3>Permission Gate</h3>
 * <p>The folder-mutating controls are the UPDATE button and the
 * per-row REMOVE control. Both are disabled while the runtime
 * permissions the app needs are not granted: the folder scan cannot
 * read the filesystem without the permission, so UPDATE would find
 * nothing and REMOVE would stage a change with no way to apply
 * it.</p>
 *
 * <p>IMPORT FOLDER button stays live. Opening the SAF picker is a
 * separate grant, and it is the user's legitimate path back to a
 * library the app can read. Disabling it would close the door the
 * user needs.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>The folder list uses weighted height and scrolls naturally in
 * all window sizes. Empty state visibility is determined solely by
 * adapter item count.</p>
 *
 * <h3>Overlay Ownership</h3>
 * <p>This activity owns exactly one persistent overlay during the
 * folder-update cycle: the folder-sync overlay, keyed by
 * {@link #OPERATION_FOLDER_SYNC}. It is shown by the first
 * progress callback and popped on every exit path from the
 * update cycle.</p>
 *
 * <h3>Overlay and Notification Title/Body</h3>
 * <p>The folder-sync overlay's progress messages carry an action
 * verb and a count. The action verb is the overlay's text and the
 * notification mirror's title; the count is the notification
 * mirror's body. The two are resolved from separate string
 * resources and passed to {@link ToastManager} as two separate
 * strings, so neither the overlay nor the notification has to split
 * a joined message.</p>
 *
 * <h3>Language Application</h3>
 * <p>The activity wraps its base context through
 * {@link LanguageManager#wrap(Context)} in
 * {@link #attachBaseContext(Context)}, so every string it resolves
 * through {@code getString} is read from the resource folder that
 * matches the selected language from the moment the activity is
 * created. A {@code LANGUAGE_CHANGED} broadcast is answered with a
 * posted {@code recreate()}, which runs {@code attachBaseContext}
 * again with the new locale already persisted.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. The reset owner and the
 * {@link MusicPlayer} playlist refresh perform their own
 * background work on their own executors.</p>
 *
 * @see FolderAdapter
 * @see NavigationController
 * @see PermissionChecker
 * @see PlaylistManager
 * @see MusicService
 * @see ToastManager
 * @see LanguageManager
 *
 * @author Richard Korbla Adzido
 * @version 1.4.5
 * @since 1.0.0
 */
public class FolderManager extends Activity
        implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Request code for the Storage Access Framework folder picker. */
    private static final int FOLDER_SELECT_CODE = 300;

    /** Log tag for this class. */
    private static final String TAG = "FolderManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS_URIS =
        "selected_folders_uris";

    /** Delay before save operations begin, in milliseconds. */
    private static final long STATE_SAVE_DELAY_MS = 150L;

    /** Animation duration for button press effects, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Padding of the empty-state container, in dp. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /** Broadcast action asking the service to save player state now. */
    private static final String ACTION_SAVE_PLAYER_STATE_NOW =
        "SAVE_PLAYER_STATE_NOW";

    /** Broadcast action asking for a playlist update. */
    private static final String ACTION_UPDATE_PLAYLIST =
        "UPDATE_PLAYLIST";

    /** Broadcast action asking consumers to rebuild the playlist. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS =
        "UPDATE_PLAYLIST_FROM_FOLDERS";

    /** Broadcast action asking the playlist to redraw. */
    private static final String ACTION_DISPLAY_PLAYLIST =
        "DISPLAY_PLAYLIST";

    /** Broadcast action emitted when a sync finishes. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action emitted when a sync starts. */
    private static final String ACTION_SYNC_STARTED = "SYNC_STARTED";

    /** Broadcast action emitted when the theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED =
        "THEME_COLOR_CHANGED";

    /** Broadcast action emitted when the display language changes. */
    private static final String ACTION_LANGUAGE_CHANGED =
        "LANGUAGE_CHANGED";

    /** Broadcast action emitted when the loose tracks list changes. */
    private static final String ACTION_LOOSE_TRACKS_UPDATED =
        "LOOSE_TRACKS_UPDATED";

    /** Debounce delay for the cancel button, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Operation ID for the folder-sync overlay owned by this activity. */
    private static final String OPERATION_FOLDER_SYNC = "FOLDER_SYNC";

    /** Delay before the folder display is reloaded after SYNC_COMPLETE. */
    private static final long FOLDER_RELOAD_DELAY_MS = 100L;

    /** Separator between a folder name and its storage-type suffix. */
    private static final String STORAGE_TYPE_SEPARATOR = " ";

    // ============================================================================
    // Pending Changes Holder
    // ============================================================================

    /**
     * Holds the set of folder removals and the loose-tracks removal
     * flag staged by the user until UPDATE is tapped.
     */
    private static final class PendingChanges {

        /** Folder URI strings staged for removal. */
        @NonNull
        private final ArrayList<String> mFoldersToRemove =
            new ArrayList<String>();

        /** True when the Loose Tracks entry is staged for removal. */
        private boolean mClearLooseTracks = false;

        /**
         * Stages the given folder URI for removal, ignoring
         * duplicates.
         *
         * @param folderUri URI string of the folder to remove
         */
        void addFolderToRemove(@NonNull String folderUri) {
            if (!mFoldersToRemove.contains(folderUri)) {
                mFoldersToRemove.add(folderUri);
            }
        }

        /**
         * Stages the Loose Tracks entry for removal.
         */
        void markLooseTracksForRemoval() {
            mClearLooseTracks = true;
        }

        /**
         * Returns whether nothing has been staged.
         *
         * @return True when no folder removals and no loose-tracks
         *         removal are staged
         */
        boolean isEmpty() {
            return mFoldersToRemove.isEmpty() && !mClearLooseTracks;
        }

        /**
         * Returns whether the Loose Tracks entry is staged for
         * removal.
         *
         * @return True when the Loose Tracks entry is staged
         */
        boolean isClearLooseTracks() {
            return mClearLooseTracks;
        }

        /**
         * Returns a copy of the staged folder removals.
         *
         * @return A copy of the folder removals list
         */
        @NonNull
        ArrayList<String> getFoldersToRemove() {
            return new ArrayList<>(mFoldersToRemove);
        }

        /**
         * Clears every staged change.
         */
        void clear() {
            mFoldersToRemove.clear();
            mClearLooseTracks = false;
        }
    }

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Library facade used to add and remove folders. */
    private MusicLibrary mMusicLibrary;

    /** Recycler view that displays the folder rows. */
    private RecyclerView mFoldersRecyclerView;

    /** Adapter backing the folder recycler view. */
    private FolderAdapter mFolderAdapter;

    /** Folder items currently displayed. */
    private List<FolderAdapter.FolderItem> mFolderItems;

    /** Text view that shows the folder count. */
    private TextView mFolderCountText;

    /** Button that opens the playback-scope dialog. */
    @Nullable private Button mScopeButton;

    /** Holder of the folder removals staged by the user. */
    @NonNull
    private final PendingChanges mPendingChanges =
        new PendingChanges();

    /** Container shown when no folders and no loose tracks remain. */
    private LinearLayout mEmptyContainer;

    /** Root container that hosts the empty state. */
    private FrameLayout mRootContainer;

    /** Manager that supplies the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    /** Receiver for language change broadcasts. */
    @Nullable
    private BroadcastReceiver mLanguageChangedReceiver;

    /** Receiver for loose-track update broadcasts. */
    private BroadcastReceiver mLooseTracksUpdateReceiver;

    /** Receiver for sync-complete broadcasts. */
    private BroadcastReceiver mSyncCompleteReceiver;

    /** Receiver for library reset broadcasts emitted by
     *  {@link PlaylistManager}. */
    private BroadcastReceiver mLibraryResetReceiver;

    /** Timestamp of the last cancel button click, for debouncing. */
    private long mLastCancelClickTime = 0L;

    /** Timestamp of the last SCOPE button click, for debouncing. */
    private long mLastScopeClickTime = 0L;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // Language Application
    // ============================================================================

    /**
     * Wraps the base context with the currently selected locale.
     *
     * <p>The wrap is performed before any activity state is created,
     * so every string resolved through {@code getString} during the
     * activity's lifetime is read from the resource folder that
     * matches the selected language.</p>
     *
     * @param newBase Base context supplied by the framework
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase));
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, loads the folder list, registers
     * receivers, and subscribes to
     * {@link NavigationController} button state changes.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);
        OverlayManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_folder_manager);

        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mFolderItems = new ArrayList<FolderAdapter.FolderItem>();

        initializeViews();

        loadFolders();
        registerLooseTracksReceiver();
        registerSyncCompleteReceiver();
        registerLibraryResetReceiver();
        registerLanguageReceiver();
        applyThemeToUI();
        themeAllHeaders();

        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Reattaches a persistent overlay if one is active, registers
     * the theme receiver if needed, and reloads the folder list.
     */
    @Override
    protected void onResume() {
        super.onResume();

        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(
                        FolderManager.this);
                    ToastManager.reattachToCurrentActivity(
                        FolderManager.this);
                }
            }, 100L);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver so it is not invoked while
     * the activity is not visible.
     */
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiverSafely(mThemeReceiver);
        mThemeReceiver = null;
    }

    /**
     * Reattaches the persistent overlay, refreshes the folder list,
     * and reapplies the theme.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart - FolderManager resumed, update in "
            + "progress: " + isUpdating());

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(
                        FolderManager.this);
                    ToastManager.reattachToCurrentActivity(
                        FolderManager.this);
                }
            }, 100L);
        }

        ToastManager.ensureOverlayAttached(this);

        updateFolderButtons();

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();

        if (isUpdating()) {
            PlaylistManager playlistManager =
                PlaylistManager.getInstance(this);
            if (playlistManager != null && playlistManager.isUpdating()) {
                ToastManager.ensureOverlayAttached(this);
            }
        }
    }

    /**
     * Unregisters listeners and receivers, removes handler callbacks,
     * and releases this activity's library executor.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        NavigationController.getInstance().unregisterListener(this);

        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mLooseTracksUpdateReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mLanguageChangedReceiver);
        mMainHandler.removeCallbacksAndMessages(null);

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }
    }

    /**
     * Returns to the music player instead of leaving the
     * application.
     */
    @Override
    public void onBackPressed() {
        returnToMusicPlayer();
    }

    /**
     * Reapplies immersive mode when the window gains focus and
     * reattaches any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Reapplies the layout for the new window configuration.
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        updateLayoutForConfiguration();
    }

    /**
     * Handles the folder picker result by persisting the chosen
     * folder's permission and importing it.
     *
     * @param requestCode The request code passed to
     *        {@link #startActivityForResult(Intent, int)}
     * @param resultCode The result code returned by the picker
     * @param data The intent carrying the picked URI, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE
                && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                persistFolderPermission(treeUri);
            }
        }
    }

    // ============================================================================
    // Layout
    // ============================================================================

    /**
     * Applies layout adjustments based on current configuration.
     *
     * <p>The folder list uses weighted height and scrolls naturally in
     * all window sizes. Empty state visibility is determined solely by
     * adapter item count.</p>
     */
    private void updateLayoutForConfiguration() {
        if (mFolderAdapter == null) {
            return;
        }
        if (mFolderAdapter.getItemCount() == 0) {
            showEmptyView();
        } else {
            hideEmptyView();
        }
    }

    // ============================================================================
    // Navigation
    // ============================================================================

    /**
     * Returns to the music player activity with the slide-right
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_right, R.anim.slide_out_left);
    }

    // ============================================================================
    // Update State Query
    // ============================================================================

    /**
     * Returns whether a playlist update is in progress, according
     * to {@link NavigationController}.
     *
     * @return True when the folder-actions button group is disabled
     */
    private boolean isUpdating() {
        return NavigationController.getInstance()
            .isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    /**
     * Returns whether the folder-mutating controls should be
     * enabled.
     *
     * <p>Two facts compose the answer. The runtime permissions the
     * app needs must be granted, and no update may be in progress. A
     * control that looks live but cannot act is the wrong state; the
     * disabled state is the honest one for both conditions.</p>
     *
     * <p>The permission answer is owned by
     * {@link PermissionChecker}. The update-in-progress answer is
     * owned by {@link NavigationController}. This method is the
     * single expression of their combination.</p>
     *
     * <p>IMPORT is deliberately not gated on this method. Opening
     * the SAF picker is a separate grant and the user's legitimate
     * path back to a library the app can read.</p>
     *
     * @return True when the folder-mutating controls should be
     *         enabled
     */
    private boolean areFolderChangesAllowed() {
        return PermissionChecker.allGranted(this) && !isUpdating();
    }

    // ============================================================================
    // NavigationController Listener
    // ============================================================================

    /**
     * Refreshes the folder controls when the folder-actions button
     * group's state changes.
     *
     * @param group The button group whose state changed
     * @param disabled True when the group is disabled; unused, the
     *        state is re-read from {@link #isUpdating()}
     */
    @Override
    public void onButtonStateChanged(
            NavigationController.ButtonGroup group,
            boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updateFolderButtons();
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves the activity's views, attaches the folder adapter,
     * and wires the import, update, and cancel buttons.
     *
     * <p>The adapter is constructed with a
     * {@link FolderAdapter.RemoveButtonStateSource} that reads this
     * activity's {@link #areFolderChangesAllowed()}.</p>
     */
    private void initializeViews() {
        mFoldersRecyclerView =
            (RecyclerView) findViewById(R.id.foldersRecyclerView);
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setLayoutManager(
                new LinearLayoutManager(this));

            DividerItemDecoration divider = new DividerItemDecoration(
                this, DividerItemDecoration.VERTICAL);
            divider.setDrawable(ContextCompat.getDrawable(
                this, R.drawable.divider_custom));
            mFoldersRecyclerView.addItemDecoration(divider);
        }

        mFolderCountText =
            (TextView) findViewById(R.id.folderCountText);
        mRootContainer =
            (FrameLayout) findViewById(R.id.rootContainer);

        mScopeButton = (Button) findViewById(R.id.scopeButton);

        Button importFolderButton =
            (Button) findViewById(R.id.importFolderButton);
        Button updateButton =
            (Button) findViewById(R.id.updateButton);
        Button cancelButton =
            (Button) findViewById(R.id.cancelButton);

        animateButton(importFolderButton);
        animateButton(updateButton);
        animateButton(cancelButton);
        animateButton(mScopeButton);

        if (mScopeButton != null) {
            mScopeButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isUpdating()) {
                        return;
                    }
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastScopeClickTime
                            < CLICK_DEBOUNCE_DELAY_MS) {
                        return;
                    }
                    mLastScopeClickTime = currentTime;
                    openPlaybackScopeDialog();
                }
            });
        }

        mFolderAdapter = new FolderAdapter(this, mFolderItems,
            new FolderAdapter.OnFolderRemoveListener() {
            @Override
            public void onFolderRemove(
                    @NonNull String folderUriString, int position) {
                mPendingChanges.addFolderToRemove(folderUriString);
                mFolderAdapter.removeItem(position);
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }

            @Override
            public void onLooseTracksRemove() {
                mPendingChanges.markLooseTracksForRemoval();
                for (int index = 0; index < mFolderItems.size();
                        index++) {
                    if (mFolderItems.get(index).isLooseTracks) {
                        mFolderAdapter.removeItem(index);
                        break;
                    }
                }
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }
        },
            this::areFolderChangesAllowed);

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setAdapter(mFolderAdapter);
        }

        if (importFolderButton != null) {
            importFolderButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        selectFolder();
                    }
                }
            });
        }

        if (updateButton != null) {
            updateButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        saveChanges();
                    }
                }
            });
        }

        if (cancelButton != null) {
            cancelButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        returnToMusicPlayer();
                    }
                }
            });
        }
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button The button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // UI State Management Methods
    // ============================================================================

    /**
     * Shows the empty-state placeholder in the slot the folder list
     * occupies.
     *
     * <p>The placeholder is added as a sibling of the folder list,
     * in the same {@link LinearLayout} the list lives in, carrying
     * the same layout weight. It therefore fills the same vertical
     * band the list fills, and its centred text appears exactly in
     * the middle of the view between the {@code FOLDER LIST} header
     * bar and the import button.</p>
     */
    private void showEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent existingParent = mEmptyContainer.getParent();
            if (existingParent instanceof ViewGroup) {
                ((ViewGroup) existingParent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText(R.string.folder_manager_empty_state);
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mFoldersRecyclerView != null) {
            final ViewParent parent = mFoldersRecyclerView.getParent();
            if (parent instanceof LinearLayout) {
                final LinearLayout parentLayout =
                    (LinearLayout) parent;
                final LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0, 1f);
                parentLayout.addView(mEmptyContainer, params);
            }
            mFoldersRecyclerView.setVisibility(View.GONE);
        }
    }

    /**
     * Removes the empty-state placeholder and shows the folder
     * list.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent parent = mEmptyContainer.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Updates the folder count text to reflect the current display
     * list.
     *
     * <p>The count is resolved through the {@code folder_count}
     * plural. The count includes the Loose Tracks entry when one is
     * present, so the number on screen and the number of rows on
     * screen agree.</p>
     */
    private void updateFolderCount() {
        int folderCount = 0;
        boolean hasLooseTracks = false;

        for (FolderAdapter.FolderItem folderItem : mFolderItems) {
            if (folderItem.isLooseTracks) {
                hasLooseTracks = true;
            } else {
                folderCount++;
            }
        }

        if (hasLooseTracks) {
            folderCount++;
        }

        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(
                Color.parseColor("#C0C0C0"));
            mFolderCountText.setText(
                getResources().getQuantityString(
                    R.plurals.folder_count, folderCount, folderCount));
        }
    }

    /**
     * Applies the current theme color to the activity's buttons
     * and the adapter's remove buttons.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        Button importFolderButton =
            (Button) findViewById(R.id.importFolderButton);
        Button updateButton =
            (Button) findViewById(R.id.updateButton);
        Button cancelButton =
            (Button) findViewById(R.id.cancelButton);

        mThemeHelper.updateButton(importFolderButton,
            importFolderButton != null
                && importFolderButton.isEnabled());
        mThemeHelper.updateButton(updateButton,
            updateButton != null && updateButton.isEnabled());
        mThemeHelper.updateButton(cancelButton,
            cancelButton != null && cancelButton.isEnabled());
        mThemeHelper.updateButton(mScopeButton,
            mScopeButton != null && mScopeButton.isEnabled());

        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }
    }

    /**
     * Applies the header text color to every header TextView in
     * the activity.
     */
    private void themeAllHeaders() {
        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(
                Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews
     * in the given view hierarchy.
     *
     * <p>Comparisons are performed against the current locale's
     * resource values, not against English literals.</p>
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView
                    && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals(getString(
                            R.string.folder_manager_title))
                        || text.equals(getString(
                            R.string.folder_manager_list_header))) {
                    textView.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ============================================================================
    // Folder Management Methods
    // ============================================================================

    /**
     * Persists the given folder's URI permission, adds it to the
     * library, removes any loose songs contained within it, and
     * reloads the folder list.
     *
     * @param treeUri The folder URI chosen by the user
     */
    private void persistFolderPermission(@NonNull Uri treeUri) {
        final StorageAccessHelper storageAccessHelper =
            StorageAccessHelper.getInstance(this);
        final String folderPath =
            storageAccessHelper.getFolderPathFromUri(treeUri);

        if (!storageAccessHelper.storeFolderPermission(
                treeUri, folderPath)) {
            ToastManager.showToast(this,
                getString(R.string.folder_manager_permission_denied),
                ToastManager.LENGTH_NORMAL);
            return;
        }

        final String folderUriString = treeUri.toString();
        mMusicLibrary.addFolder(folderUriString);
        cleanLooseSongsInFolder(treeUri);
        loadFolders();

        final String folderName = getFolderNameFromUri(treeUri);
        if (folderName != null) {
            ToastManager.showToast(this,
                getString(R.string.folder_manager_imported_toast,
                    folderName),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies
     * inside the given folder.
     *
     * @param folderUri The folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }

        ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null || looseSongs.isEmpty()) {
            return;
        }

        String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong != null && looseSong.getPath() != null
                    && looseSong.getPath()
                        .startsWith(normalizedPath)) {
                SongDatabase.getInstance(this)
                    .removeLooseSong(looseSong.getPath());
            }
        }
    }

    /**
     * Returns the filesystem path behind the given folder URI.
     *
     * <p>Delegates to
     * {@link StorageAccessHelper#getFolderPathFromUri(Uri)},
     * which handles both primary and removable storage and
     * consults the persisted URI-to-path mapping when one
     * exists.</p>
     *
     * @param uri Folder URI to inspect
     * @return The filesystem path, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        return StorageAccessHelper.getInstance(this)
            .getFolderPathFromUri(uri);
    }

    /**
     * Returns the display name of the given folder URI, cleaned of
     * control characters and HTML entities.
     *
     * <p>When neither the content resolver nor the URI's last path
     * segment yields a name, the app's default folder name is
     * returned.</p>
     *
     * @param uri The folder URI
     * @return The display name; never null
     */
    @NonNull
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;

        try {
            cursor = getContentResolver().query(
                uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(
                    OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to get folder name", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to close cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        if (name == null) {
            name = getString(R.string.folder_manager_default_name);
        }

        return CharacterMapper.cleanString(name);
    }

    /**
     * Clears the staged changes, rebuilds the display list from
     * the library, and refreshes every dependent view.
     *
     * <p>The Loose Tracks label is resolved here from the plural
     * resource and passed to the adapter as a plain string.</p>
     *
     * <p>The storage-type suffix is resolved by
     * {@link StorageAccessHelper#getStorageType(String)} from its
     * own resource. This method supplies the separator between the
     * folder name and the suffix from
     * {@link #STORAGE_TYPE_SEPARATOR}.</p>
     */
    private void loadFolders() {
        mFolderItems.clear();
        Set<String> folders = mMusicLibrary.getSelectedFolders();
        mPendingChanges.clear();

        Log.d(TAG, "loadFolders: " + folders.size() + " folders found");

        ArrayList<Song> validLooseSongs = getValidLooseSongs();
        boolean hasLooseSongs = !validLooseSongs.isEmpty();

        if (folders.isEmpty() && !hasLooseSongs) {
            showEmptyView();
        } else {
            hideEmptyView();

            for (final String folderUriString : folders) {
                Uri folderUri = Uri.parse(folderUriString);
                String name = getFolderNameFromUri(folderUri);
                String storageType =
                    StorageAccessHelper.getInstance(this)
                        .getStorageType(folderUriString);

                String displayName = storageType.isEmpty()
                    ? name
                    : name + STORAGE_TYPE_SEPARATOR + storageType;

                mFolderItems.add(new FolderAdapter.FolderItem(
                    folderUriString, displayName));
            }

            if (hasLooseSongs) {
                final int looseCount = validLooseSongs.size();
                final String looseLabel =
                    getResources().getQuantityString(
                        R.plurals.folder_manager_loose_tracks,
                        looseCount, looseCount);
                mFolderItems.add(new FolderAdapter.FolderItem(
                    looseLabel, looseCount));
            }

            mFolderAdapter.refreshRemoveButtonStates();
        }

        updateFolderCount();
        themeAllHeaders();
        updateFolderButtons();
    }

    /**
     * Returns every loose song whose file exists and is readable,
     * and removes from the database any loose song whose file does
     * not.
     *
     * @return The list of valid loose songs
     */
    @NonNull
    private ArrayList<Song> getValidLooseSongs() {
        ArrayList<Song> validLooseSongs = new ArrayList<Song>();
        ArrayList<Song> allLooseSongs =
            SongDatabase.getInstance(this).getLooseSongs();

        if (allLooseSongs != null) {
            for (Song looseSong : allLooseSongs) {
                if (looseSong != null
                        && looseSong.getPath() != null) {
                    File file = new File(looseSong.getPath());
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(looseSong);
                    } else {
                        SongDatabase.getInstance(this)
                            .removeLooseSong(looseSong.getPath());
                    }
                }
            }
        }

        return validLooseSongs;
    }

    /**
     * Opens the Storage Access Framework folder picker.
     */
    private void selectFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(intent, FOLDER_SELECT_CODE);
        } catch (Exception exception) {
            ToastManager.showToast(this,
                getString(R.string.folder_manager_no_file_manager),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Opens the playback-scope dialog, pre-populated with the scope
     * currently in force, and applies the user's selection.
     *
     * <p>The current scope is read from {@link SharedPreferences}.
     * The selection is applied by broadcasting
     * {@code APPLY_PLAYBACK_SCOPE} with the serialized scope.</p>
     */
    private void openPlaybackScopeDialog() {
        final String serialized = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString("playback_scope_json", null);
        final PlaybackScope current = PlaybackScope.deserialize(serialized);
        new PlaybackScopeDialog(this, current, mFolderItems, scope -> {
            Intent intent = new Intent("APPLY_PLAYBACK_SCOPE");
            intent.putExtra("scope_json", scope.serialize());
            sendBroadcast(intent);
        }).show();
    }

    // ============================================================================
    // Button State Management
    // ============================================================================

    /**
     * Refreshes the enabled state of the import, update, and scope
     * buttons from the current update-in-progress state and pending
     * changes.
     *
     * <p>The UPDATE button is enabled only when the folder-mutating
     * controls are allowed and there is something for UPDATE to act
     * on. The IMPORT button is gated on the update-in-progress state
     * alone. The SCOPE button is gated on the update-in-progress
     * state alone.</p>
     */
    private void updateFolderButtons() {
        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }

        Button importFolderButton =
            (Button) findViewById(R.id.importFolderButton);
        if (importFolderButton != null) {
            importFolderButton.setEnabled(!isUpdating());
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(
                    importFolderButton, !isUpdating());
            }
        }

        final boolean allowed = areFolderChangesAllowed();
        boolean hasFolders = !mFolderItems.isEmpty();
        boolean hasPendingRemovals = !mPendingChanges.isEmpty();
        boolean shouldEnableUpdateButton =
            (hasFolders || hasPendingRemovals) && allowed;

        Button updateButton =
            (Button) findViewById(R.id.updateButton);
        if (updateButton != null) {
            updateButton.setEnabled(shouldEnableUpdateButton);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(
                    updateButton, shouldEnableUpdateButton);
            }
        }

        final boolean shouldEnableScopeButton = !isUpdating();
        if (mScopeButton != null) {
            mScopeButton.setEnabled(shouldEnableScopeButton);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(
                    mScopeButton, shouldEnableScopeButton);
            }
        }
    }

    /**
     * Disables the given button and reapplies its disabled theme.
     *
     * @param button The button to disable, or null
     */
    private void disableButton(@Nullable Button button) {
        if (button != null) {
            button.setEnabled(false);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(button, false);
            }
        }
    }

    // ============================================================================
    // Update Management
    // ============================================================================

    /**
     * Begins a folder-update cycle.
     *
     * <p>Three cases, each with its own downstream operation:</p>
     * <ul>
     *   <li>No folders and no loose tracks remain: the full
     *       library wipe path calls
     *       {@link PlaylistManager#resetLibrary} in
     *       {@link PlaylistManager.ResetMode#LIBRARY} mode.</li>
     *   <li>No folders but loose tracks remain: the loose tracks
     *       are snapshotted before the reset and re-inserted into
     *       the songs table in the reset's completion
     *       callback.</li>
     *   <li>Some content remains: the playlist is updated through
     *       {@link PlaylistManager#updatePlaylist}, which runs a
     *       folder scan.</li>
     * </ul>
     */
    private void saveChanges() {
        PlaylistManager playlistManager =
            PlaylistManager.getInstance(this);
        if (playlistManager != null && playlistManager.isUpdating()) {
            ToastManager.showToast(this,
                getString(R.string.folder_manager_sync_in_progress),
                ToastManager.LENGTH_NORMAL);
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        OverlayManager.show(OverlayManager.REASON_FOLDER_UPDATE_CYCLE);

        final boolean clearLooseTracks =
            mPendingChanges.isClearLooseTracks();

        final Set<String> foldersToKeep =
            new HashSet<String>(mMusicLibrary.getSelectedFolders());
        for (String folderUriString
                : mPendingChanges.getFoldersToRemove()) {
            foldersToKeep.remove(folderUriString);
        }

        boolean hasLooseAfterClear = false;
        if (!clearLooseTracks) {
            ArrayList<Song> remainingLoose =
                SongDatabase.getInstance(this).getLooseSongs();
            hasLooseAfterClear = remainingLoose != null
                && !remainingLoose.isEmpty();
        }

        final boolean hasAnyFolders = !foldersToKeep.isEmpty();
        final boolean hasAnyContent =
            hasAnyFolders || hasLooseAfterClear;

        updateFolderButtons();

        Intent saveIntent = new Intent(ACTION_SAVE_PLAYER_STATE_NOW);
        sendBroadcast(saveIntent);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MusicService.setPlayerStateBeforeUpdate(
                    FolderManager.this, true);

                Button updateButton =
                    (Button) findViewById(R.id.updateButton);
                Button importFolderButton =
                    (Button) findViewById(R.id.importFolderButton);
                disableButton(updateButton);
                disableButton(importFolderButton);

                if (clearLooseTracks) {
                    SongDatabase.getInstance(FolderManager.this)
                        .clearLooseSongs();
                }

                for (String folderUriString
                        : mPendingChanges.getFoldersToRemove()) {
                    mMusicLibrary.removeFolder(folderUriString);
                    try {
                        StorageAccessHelper.getInstance(
                            FolderManager.this)
                            .removeFolderPermission(
                                Uri.parse(folderUriString));
                    } catch (Exception exception) {
                        Log.w(TAG, "Failed to drop SAF permission for "
                            + folderUriString, exception);
                    }
                }

                SharedPreferences preferences = getSharedPreferences(
                    PREFS_NAME, MODE_PRIVATE);
                preferences.edit()
                    .putStringSet(
                        KEY_SELECTED_FOLDERS_URIS, foldersToKeep)
                    .apply();

                if (!hasAnyContent) {
                    PlaylistManager.getInstance(FolderManager.this)
                        .resetLibrary(
                            PlaylistManager.ResetMode.LIBRARY,
                            new PlaylistManager.ResetCallback() {
                                @Override
                                public void onComplete() {
                                    onResetComplete();
                                }

                                @Override
                                public void onError(
                                        @NonNull String error) {
                                    onResetError(error);
                                }
                            });
                    return;
                }

                if (!hasAnyFolders) {
                    final ArrayList<Song> looseSongsSnapshot =
                        SongDatabase.getInstance(FolderManager.this)
                            .getLooseSongs();

                    PlaylistManager.getInstance(FolderManager.this)
                        .resetLibrary(
                            PlaylistManager.ResetMode.LIBRARY,
                            new PlaylistManager.ResetCallback() {
                                @Override
                                public void onComplete() {
                                    restoreLooseTracks(
                                        looseSongsSnapshot);
                                    onResetComplete();
                                }

                                @Override
                                public void onError(
                                        @NonNull String error) {
                                    onResetError(error);
                                }
                            });
                    return;
                }

                performPlaylistUpdate();
            }
        }, STATE_SAVE_DELAY_MS);
    }

    /**
     * Runs after the reset operation has committed. Rebuilds the
     * folder list and refreshes the update button state.
     */
    private void onResetComplete() {
        loadFolders();
        updateFolderButtons();
    }

    /**
     * Runs when the reset operation fails. Surfaces the error and
     * re-enables the update and import buttons so the user can
     * retry.
     *
     * @param error Description of the failure
     */
    private void onResetError(@NonNull String error) {
        Log.e(TAG, "Library reset failed: " + error);
        updateFolderButtons();
        ToastManager.showToast(FolderManager.this,
            getString(R.string.folder_manager_reset_failed, error),
            ToastManager.LENGTH_NORMAL);
    }

    /**
     * Re-inserts the given loose tracks into the loose-songs table
     * and the songs table after the reset operation has cleared
     * both.
     *
     * @param looseSongsSnapshot Loose tracks captured before the
     *        reset
     */
    private void restoreLooseTracks(
            @NonNull ArrayList<Song> looseSongsSnapshot) {
        if (looseSongsSnapshot.isEmpty()) {
            return;
        }

        SongDatabase database = SongDatabase.getInstance(this);
        for (Song looseSong : looseSongsSnapshot) {
            if (looseSong != null && looseSong.getPath() != null) {
                database.insertLooseSong(looseSong);
            }
        }
        database.insertSongsBatch(looseSongsSnapshot);

        Log.d(TAG, "Restored " + looseSongsSnapshot.size()
            + " loose tracks after reset");

        Intent updatePlaylistIntent =
            new Intent(ACTION_UPDATE_PLAYLIST);
        sendBroadcast(updatePlaylistIntent);

        Intent displayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(displayIntent);
    }

    /**
     * Runs a playlist update through {@link PlaylistManager} and
     * drives the folder-sync overlay from the scan's progress
     * callbacks.
     *
     * <p>Every progress message is composed from two string
     * resources: an action verb and a count. The action verb is the
     * overlay's visible text and the notification mirror's title;
     * the count is the notification mirror's body. The two are
     * passed to {@link ToastManager} as separate strings; the
     * overlay's visible text joins them with a middle dot so the
     * verb and the count read as two columns of one status line.
     * </p>
     */
    private void performPlaylistUpdate() {
        final boolean[] persistentShown = {false};

        PlaylistManager.getInstance(this).updatePlaylist(
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(final int current,
                                   final int total) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        final String action;
                        final String detail;
                        if (current == 0) {
                            action = getString(
                                R.string.folder_manager_searching);
                            detail = "";
                        } else if (current < total) {
                            action = getString(
                                R.string.folder_manager_searching);
                            detail = getString(
                                R.string.folder_manager_searching_found,
                                current);
                        } else {
                            action = getString(
                                R.string.folder_manager_syncing);
                            detail = getString(
                                R.string.folder_manager_syncing_found,
                                current);
                        }

                        final String overlayText =
                            detail.isEmpty()
                                ? action
                                : action + " \u00B7 " + detail;

                        if (!persistentShown[0]) {
                            ToastManager.showPersistentOverlay(
                                FolderManager.this,
                                overlayText,
                                detail,
                                OPERATION_FOLDER_SYNC);
                            persistentShown[0] = true;
                        } else {
                            ToastManager.updatePersistentOverlay(
                                overlayText,
                                detail,
                                OPERATION_FOLDER_SYNC);
                        }

                        Intent syncStartedIntent =
                            new Intent(ACTION_SYNC_STARTED);
                        syncStartedIntent.putExtra(
                            "custom_text", action);
                        syncStartedIntent.putExtra(
                            "custom_detail", detail);
                        syncStartedIntent.putExtra(
                            "operation_id", OPERATION_FOLDER_SYNC);
                        sendBroadcast(syncStartedIntent);
                    }
                });
            }

            @Override
            public void onComplete(final int songCount) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay(
                            OPERATION_FOLDER_SYNC);

                        sendBroadcast(new Intent(
                            ACTION_UPDATE_PLAYLIST_FROM_FOLDERS));
                    }
                });
            }

            @Override
            public void onError(@NonNull final String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (persistentShown[0]) {
                            ToastManager.hidePersistentOverlay(
                                OPERATION_FOLDER_SYNC);
                        }

                        Intent syncCompleteIntent =
                            new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);

                        NavigationController.getInstance()
                            .endPlaylistSync();

                        updateFolderButtons();
                        ToastManager.showToast(FolderManager.this,
                            getString(
                                R.string.folder_manager_error, error),
                            ToastManager.LENGTH_NORMAL);
                    }
                });
            }
        });
    }

    // ============================================================================
    // Broadcast Receiver Methods
    // ============================================================================

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(
                        intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();

                    if (mFolderAdapter != null) {
                        mFolderAdapter.refreshRemoveButtonStates();
                    }

                    ToastManager.refreshThemeColor();
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for language change broadcasts.
     *
     * <p>The receiver answers the broadcast with a posted
     * {@code recreate()}, which runs this activity's
     * {@code attachBaseContext} again with the new locale already
     * persisted.</p>
     */
    private void registerLanguageReceiver() {
        if (mLanguageChangedReceiver != null) {
            return;
        }

        mLanguageChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_LANGUAGE_CHANGED.equals(
                            intent.getAction())) {
                    return;
                }
                if (!isFinishing() && !isDestroyed()) {
                    recreate();
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_LANGUAGE_CHANGED);
        ContextCompat.registerReceiver(
            this, mLanguageChangedReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for loose-track update broadcasts.
     */
    private void registerLooseTracksReceiver() {
        mLooseTracksUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_LOOSE_TRACKS_UPDATED.equals(
                        intent.getAction())) {
                    loadFolders();
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_LOOSE_TRACKS_UPDATED);
        ContextCompat.registerReceiver(
            this, mLooseTracksUpdateReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for sync-complete broadcasts.
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SYNC_COMPLETE.equals(intent.getAction())) {
                    Log.d(TAG,
                        "Sync complete - scheduling folder list reload");
                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            loadFolders();
                        }
                    }, FOLDER_RELOAD_DELAY_MS);
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_SYNC_COMPLETE);
        ContextCompat.registerReceiver(
            this, mSyncCompleteReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for library reset broadcasts emitted
     * by {@link PlaylistManager}.
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(
                            intent.getAction())) {
                    return;
                }
                Log.d(TAG, "LIBRARY_RESET received — invalidating "
                    + "library and reloading folders");

                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }

                loadFolders();
            }
        };

        IntentFilter filter = new IntentFilter(
            PlaylistManager.ACTION_LIBRARY_RESET);
        ContextCompat.registerReceiver(
            this, mLibraryResetReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Unregisters the given receiver, ignoring any exception
     * raised by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception ignored) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density =
            getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}