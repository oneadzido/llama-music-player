package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Activity for managing music folders.
 * 
 * <p>This activity allows users to:
 * <ul>
 *   <li>View all imported music folders</li>
 *   <li>Add new folders via Storage Access Framework (SAF)</li>
 *   <li>Remove folders from the playlist (changes applied when UPDATE is clicked)</li>
 *   <li>View and manage loose tracks (songs opened from other apps)</li>
 *   <li>Trigger playlist synchronization after folder changes</li>
 * </ul>
 * </p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The FolderManager follows a pending-changes pattern where folder removals are
 * staged in {@link #mFoldersToRemove} until the user confirms by clicking UPDATE.
 * This allows for batch operations and prevents unnecessary playlist rebuilds.</p>
 * 
 * <p>The activity also triggers the genre loading phase (Phase 2) after the initial
 * playlist scan completes, ensuring that all songs receive their proper genres
 * from ID3 tags in the background without blocking the UI.</p>
 * 
 * <h3>Integration Points</h3>
 * <ul>
 *   <li>{@link MusicLibrary} - Persistent storage of selected folder URIs</li>
 *   <li>{@link PlaylistService} - Asynchronous playlist rebuilding</li>
 *   <li>{@link SongDatabase} - Loose tracks management</li>
 *   <li>{@link NavigationController} - Global UI state coordination</li>
 *   <li>{@link CharacterMapper} - ID3 tag reading for genre extraction</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class FolderManager extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Request code for folder selection via Storage Access Framework. */
    private static final int FOLDER_SELECT_CODE = 300;
    
    /** Log tag for this class. */
    private static final String TAG = "FolderManager";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing selected folder URIs in SharedPreferences. */
    private static final String KEY_SELECTED_FOLDERS_URIS = "selected_folders_uris";
    
    /** Delay in milliseconds to save player state before folder update. */
    private static final int STATE_SAVE_DELAY_MS = 150;
    
    /** Delay in milliseconds before hiding the overlay after sync completes. */
    private static final int OVERLAY_HIDE_DELAY_MS = 1500;
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Padding for empty container in density-independent pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    
    /** Top padding for empty container in density-independent pixels. */
    private static final int EMPTY_CONTAINER_TOP_PADDING_DP = 64;
    
    /** Intent action for saving player state immediately. */
    private static final String ACTION_SAVE_PLAYER_STATE_NOW = "SAVE_PLAYER_STATE_NOW";
    
    /** Intent action for updating playlist from folders. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS = "UPDATE_PLAYLIST_FROM_FOLDERS";
    
    /** Intent action for resetting player state. */
    private static final String ACTION_RESET_PLAYER_STATE = "RESET_PLAYER_STATE";
    
    /** Intent action for displaying the playlist. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";
    
    /** Intent action for soft updating the playlist. */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";
    
    /** Intent action for sync completion broadcast. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";
    
    /** Intent action for sync start broadcast. */
    private static final String ACTION_SYNC_STARTED = "SYNC_STARTED";
    
    /** Intent action for stopping the music service. */
    private static final String ACTION_STOP = "ACTION_STOP";
    
    /** Intent action for theme color changed broadcast. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    /** Intent action for loose tracks updated broadcast. */
    private static final String ACTION_LOOSE_TRACKS_UPDATED = "LOOSE_TRACKS_UPDATED";
    
    /** Broadcast action for genre update events during genre loading phase. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";
    
    /** Broadcast action for forcing playlist refresh after genre loading. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Timestamp of the last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Manages music library operations including folder and song data. */
    private MusicLibrary mMusicLibrary;
    
    /** RecyclerView for displaying the list of folders. */
    private RecyclerView mFoldersRecyclerView;
    
    /** Adapter for the folder list RecyclerView. */
    private FolderAdapter mFolderAdapter;
    
    /** List of folder items to display in the adapter. */
    private List<FolderAdapter.FolderItem> mFolderItems;
    
    /** TextView displaying the current folder count. */
    private TextView mFolderCountText;
    
    /** List of folders pending removal (applied when UPDATE is clicked). */
    private final ArrayList<String> mFoldersToRemove = new ArrayList<String>();
    
    /** Flag indicating if a playlist update is in progress. */
    private boolean mIsUpdating = false;
    
    /** Flag indicating if genre update has been triggered. */
    private boolean mGenreUpdateTriggered = false;
    
    /** Container for empty state UI when no folders exist. */
    private LinearLayout mEmptyContainer;
    
    /** Root container frame layout. */
    private FrameLayout mRootContainer;
    
    /** Manager for theme color operations. */
    private ThemeManager mThemeManager;
    
    /** Helper for applying theme colors to UI components. */
    private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme color change events. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Broadcast receiver for loose tracks update events. */
    private BroadcastReceiver mLooseTracksUpdateReceiver;
    
    /** Broadcast receiver for sync completion events. */
    private BroadcastReceiver mSyncCompleteReceiver;
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * Initializes managers, sets up UI components, loads folders,
     * registers receivers, and applies theme.
     * 
     * @param savedInstanceState Previously saved state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_folder_manager);
        
        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mFolderItems = new ArrayList<FolderAdapter.FolderItem>();
        
        initializeViews();
        loadFolders();
        registerLooseTracksReceiver();
        registerSyncCompleteReceiver();
        applyThemeToUI();
        themeAllHeaders();
        
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Called when the activity resumes.
     * Re-registers theme receiver, reattaches persistent toasts,
     * reloads folders, and refreshes UI theme.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Sync button state with NavigationController
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        // Reattach persistent toast if it exists with a delay to ensure window is ready
        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        loadFolders();
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Called when the activity pauses.
     * Unregisters the theme receiver to prevent memory leaks.
     */
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiverSafely(mThemeReceiver);
        mThemeReceiver = null;
    }

    /**
     * Called when the activity restarts after being stopped.
     * Synchronizes UI state with ongoing playlist sync operations.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart - FolderManager resumed, sync in progress: " + mIsUpdating);
        
        // Reattach persistent toast if it exists with a delay to ensure window is ready
        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }
        
        // Ensure overlay is attached if needed
        ToastManager.ensureOverlayAttached(this);
        
        boolean isSyncing = NavigationController.getInstance().isGroupDisabled(
            NavigationController.ButtonGroup.FOLDER_ACTIONS);
        
        if (mIsUpdating != isSyncing) {
            mIsUpdating = isSyncing;
            if (mFolderAdapter != null) {
                if (mIsUpdating) {
                    mFolderAdapter.disableRemoveButtons();
                } else {
                    mFolderAdapter.enableRemoveButtons();
                }
            }
            if (!mIsUpdating) {
                updateFolderButtons();
            }
        }
        
        loadFolders();
        applyThemeToUI();
        themeAllHeaders();
        
        if (mIsUpdating) {
            PlaylistService service = PlaylistService.getInstance(this);
            if (service != null && service.isUpdating()) {
                ToastManager.ensureOverlayAttached(this);
            }
        }
    }

    /**
     * Called when the activity is destroyed.
     * Cleans up listeners, receivers, and pending handler callbacks.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        NavigationController.getInstance().unregisterListener(this);
        
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mLooseTracksUpdateReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        mMainHandler.removeCallbacksAndMessages(null);
        
        // Hide ToastManager persistent overlay if showing
        ToastManager.hidePersistentOverlay();
    }

    /**
     * Handles the back button press by returning to the music player.
     */
    @Override
    public void onBackPressed() {
        returnToMusicPlayer();
    }

    /**
     * Called when the window gains or loses focus.
     * Re-applies immersive mode and reattaches persistent toasts.
     * 
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Handles the result from the Storage Access Framework folder picker.
     * 
     * @param requestCode The request code (should be FOLDER_SELECT_CODE)
     * @param resultCode The result code (RESULT_OK if successful)
     * @param data The intent containing the selected folder URI
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                persistFolderPermission(treeUri);
            }
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Returns to the MusicPlayer activity with smooth slide animation.
     * Uses CLEAR_TOP and SINGLE_TOP flags to maintain a single instance.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when the state of a button group changes in NavigationController.
     * Updates UI button states when folder actions are disabled during sync.
     * 
     * @param group The button group that changed
     * @param disabled True if the group is now disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Button updateButton = (Button) findViewById(R.id.updateButton);
                    if (updateButton != null) {
                        updateButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(updateButton, !finalDisabled);
                        }
                    }
                    
                    Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                    if (importFolderButton != null) {
                        importFolderButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(importFolderButton, !finalDisabled);
                        }
                    }
                    
                    if (mFolderAdapter != null) {
                        if (finalDisabled) {
                            mFolderAdapter.disableRemoveButtons();
                        } else {
                            mFolderAdapter.enableRemoveButtons();
                        }
                    }
                    
                    mIsUpdating = finalDisabled;
                    updateFolderButtons();
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets appropriate status bar and navigation bar colors based on Android version.
     * Uses deprecated methods for backward compatibility.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components, sets up the RecyclerView adapter,
     * and configures button click listeners with animations.
     * 
     * <p>This method performs the following:
     * <ol>
     *   <li>Finds and configures the RecyclerView with LinearLayoutManager and divider</li>
     *   <li>Initializes buttons and applies touch animations</li>
     *   <li>Creates FolderAdapter with remove listeners</li>
     *   <li>Sets up click handlers for Import, Update, and Cancel buttons</li>
     * </ol>
     * </p>
     */
    private void initializeViews() {
        mFoldersRecyclerView = (RecyclerView) findViewById(R.id.foldersRecyclerView);
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            
            DividerItemDecoration divider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
            divider.setDrawable(ContextCompat.getDrawable(this, R.drawable.divider_custom));
            mFoldersRecyclerView.addItemDecoration(divider);
        }
        
        mFolderCountText = (TextView) findViewById(R.id.folderCountText);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);

        animateButton(importFolderButton);
        animateButton(updateButton);
        animateButton(cancelButton);

        mFolderAdapter = new FolderAdapter(this, mFolderItems, new FolderAdapter.OnFolderRemoveListener() {
            @Override
            public void onFolderRemove(@NonNull String folderUriString, int position) {
                mFoldersToRemove.add(folderUriString);
                mFolderAdapter.removeItem(position);
                updateFolderCount();
                updateFolderButtons();
                
                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }
            
            @Override
            public void onLooseTracksRemove() {
                mFoldersToRemove.add("LOOSE_TRACKS");
                for (int i = 0; i < mFolderItems.size(); i++) {
                    if (mFolderItems.get(i).isLooseTracks) {
                        mFolderAdapter.removeItem(i);
                        break;
                    }
                }
                updateFolderCount();
                updateFolderButtons();
                
                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }
        });
        
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setAdapter(mFolderAdapter);
        }

        if (importFolderButton != null) {
            importFolderButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!mIsUpdating) {
                        selectFolder();
                    }
                }
            });
        }
        
        if (updateButton != null) {
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!mIsUpdating) {
                        saveChanges();
                    }
                }
            });
        }
        
        if (cancelButton != null) {
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        returnToMusicPlayer();
                    }
                }
            });
        }
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% on touch and returns to normal on release.
     * 
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // UI State Management Methods
    // ========================================================================
    
    /**
     * Displays the empty state view when no folders are present.
     * Creates a dynamic LinearLayout with instructional text and adds it to the root container.
     * Hides the RecyclerView when empty view is shown.
     */
    private void showEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }
        
        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), 
            dpToPx(EMPTY_CONTAINER_TOP_PADDING_DP), 
            dpToPx(EMPTY_CONTAINER_PADDING_DP), 
            dpToPx(EMPTY_CONTAINER_PADDING_DP));
        
        TextView emptyText = new TextView(this);
        emptyText.setText("Tap IMPORT FOLDER to add music folders.\nTap UPDATE to save changes.\n\nMusic files opened from other apps\nwill appear here as Loose Tracks.");
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);
        
        if (mRootContainer != null) {
            mRootContainer.addView(mEmptyContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 
                FrameLayout.LayoutParams.MATCH_PARENT));
        }
        
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.GONE);
        }
    }

    /**
     * Hides the empty state view and shows the RecyclerView.
     * Removes the empty container from the root view and makes the RecyclerView visible.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }
        mEmptyContainer = null;
        
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Updates the folder count display in the header.
     * Counts regular folders and treats loose tracks as one item.
     * Updates the TextView with proper pluralization ("folder" vs "folders").
     */
    private void updateFolderCount() {
        int folderCount = 0;
        boolean hasLooseTracks = false;
        
        for (FolderAdapter.FolderItem item : mFolderItems) {
            if (item.isLooseTracks) {
                hasLooseTracks = true;
            } else {
                folderCount++;
            }
        }
        
        if (hasLooseTracks) {
            folderCount++;
        }
        
        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));
            
            if (folderCount == 0) {
                mFolderCountText.setText("0 folders");
            } else if (folderCount == 1) {
                mFolderCountText.setText("1 folder");
            } else {
                mFolderCountText.setText(folderCount + " folders");
            }
        }
    }

    /**
     * Applies the current theme color to all UI components.
     * Updates buttons using ThemeHelper and refreshes the folder adapter.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);
        
        mThemeHelper.updateButton(importFolderButton, importFolderButton != null && importFolderButton.isEnabled());
        mThemeHelper.updateButton(updateButton, updateButton != null && updateButton.isEnabled());
        mThemeHelper.updateButton(cancelButton, cancelButton != null && cancelButton.isEnabled());
        
        if (mFolderAdapter != null) {
            mFolderAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Applies header styling to all header TextViews in the activity.
     * Recursively traverses the view hierarchy to find and style header texts.
     */
    private void themeAllHeaders() {
        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     * Targets TextViews containing "MANAGER", "FOLDER LIST", or "folders".
     * 
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            
            if (child instanceof TextView && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                
                if (text.equals("MANAGER") || 
                    text.equals("FOLDER LIST") ||
                    text.contains("folders") ||
                    text.contains("folder")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ========================================================================
    // Folder Management Methods
    // ========================================================================
    
    /**
     * Persists folder permission from Storage Access Framework and adds the folder.
     * 
     * <p>This method:
     * <ol>
     *   <li>Requests persistable URI permission from the system</li>
     *   <li>Adds the folder URI to MusicLibrary</li>
     *   <li>Cleans any loose songs that belong to this folder</li>
     *   <li>Reloads the folder list and shows a confirmation toast</li>
     * </ol>
     * </p>
     *
     * @param treeUri The folder URI from SAF
     */
    private void persistFolderPermission(@NonNull Uri treeUri) {
        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
        
        try {
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (SecurityException e) {
            ToastManager.showToast(this, "Permission denied for folder", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        String folderUriString = treeUri.toString();
        mMusicLibrary.addFolder(folderUriString);
        cleanLooseSongsInFolder(treeUri);
        loadFolders();
        
        String folderName = getFolderNameFromUri(treeUri);
        if (folderName != null) {
            ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Removes loose songs that belong to a newly imported folder.
     * This prevents duplicate songs when a folder containing previously imported
     * loose tracks is added.
     *
     * @param folderUri The folder URI being imported
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null || looseSongs.isEmpty()) {
            return;
        }
        
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose != null && loose.getPath() != null && loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }

    /**
     * Extracts the file system path from a folder URI.
     * Supports "primary:" scheme for internal storage paths.
     *
     * @param uri The folder URI
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();
        
        if (uriString.contains("primary:")) {
            try {
                int start = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(start);
                if (subPath.contains("%2F")) subPath = subPath.replace("%2F", "/");
                if (subPath.contains("/tree/")) subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                if (subPath.contains("/document/")) subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception e) {
                Log.e(TAG, "Failed to get folder path", e);
                return null;
            }
        }
        return null;
    }

    /**
     * Gets the display name of a folder from its URI.
     * Uses ContentResolver query to get DISPLAY_NAME column.
     *
     * @param uri The folder URI
     * @return The folder name (cleaned), or "Music Folder" as fallback
     */
    @NonNull
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;
        
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to get folder name", e);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.e(TAG, "Failed to close cursor", e);
                }
            }
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }
        
        if (name == null) {
            name = "Music Folder";
        }
        
        return CharacterMapper.cleanString(name);
    }

    /**
     * Gets the storage type indicator for a folder URI.
     * Detects internal storage, SD card, or external storage based on URI patterns.
     *
     * @param uriString The folder URI string
     * @return "[Internal]" for internal storage, "[SD Card]" for external, or empty string
     */
    @NonNull
    private String getStorageType(@NonNull String uriString) {
        String uriLower = uriString.toLowerCase();
        
        if (uriLower.contains("primary") || uriLower.contains("emulated")) {
            return " [Internal]";
        } else if (uriLower.contains("external") || uriLower.contains("sdcard") || 
                   uriLower.contains("extsdcard") || uriLower.contains("extsd") || 
                   uriLower.matches(".*[0-9a-f]{4}-[0-9a-f]{4}.*")) {
            return " [SD Card]";
        }
        
        return "";
    }

    /**
     * Loads the list of folders from MusicLibrary and updates the UI.
     * Creates FolderItem objects for each folder and for loose tracks if present.
     * Shows empty view when no folders and no loose tracks exist.
     */
    private void loadFolders() {
        mFolderItems.clear();
        Set<String> folders = mMusicLibrary.getSelectedFolders();
        mFoldersToRemove.clear();
        
        Log.d(TAG, "loadFolders: " + folders.size() + " folders found");
        
        ArrayList<Song> validLooseSongs = getValidLooseSongs();
        boolean hasLooseSongs = !validLooseSongs.isEmpty();
        
        if (folders.isEmpty() && !hasLooseSongs) {
            showEmptyView();
        } else {
            hideEmptyView();
            
            for (final String folderUriString : folders) {
                Uri folderUri = Uri.parse(folderUriString);
                String name = getFolderNameFromUri(folderUri);
                String storageType = getStorageType(folderUriString);
                String displayName = name + storageType;
                mFolderItems.add(new FolderAdapter.FolderItem(folderUriString, displayName));
            }
            
            if (hasLooseSongs) {
                mFolderItems.add(new FolderAdapter.FolderItem(validLooseSongs.size()));
            }
            
            mFolderAdapter.notifyDataSetChanged();
        }
        
        updateFolderCount();
        themeAllHeaders();
        updateFolderButtons();
    }

    /**
     * Returns a list of valid loose songs (files that still exist and are readable).
     * Filters out songs that no longer exist on disk and removes them from the database.
     *
     * @return List of valid loose songs
     */
    @NonNull
    private ArrayList<Song> getValidLooseSongs() {
        ArrayList<Song> validLooseSongs = new ArrayList<Song>();
        ArrayList<Song> allLooseSongs = SongDatabase.getInstance(this).getLooseSongs();
        
        if (allLooseSongs != null) {
            for (Song loose : allLooseSongs) {
                if (loose != null && loose.getPath() != null) {
                    File file = new File(loose.getPath());
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(loose);
                    } else {
                        SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
                    }
                }
            }
        }
        
        return validLooseSongs;
    }

    /**
     * Launches the Storage Access Framework folder picker.
     * Uses ACTION_OPEN_DOCUMENT_TREE intent with read permission flags.
     */
    private void selectFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        
        try {
            startActivityForResult(intent, FOLDER_SELECT_CODE);
        } catch (Exception e) {
            ToastManager.showToast(this, "No file manager found", ToastManager.LENGTH_NORMAL);
        }
    }

    // ========================================================================
    // Button State Management
    // ========================================================================
    
    /**
     * Updates folder management buttons state based on current conditions.
     * The UPDATE button is enabled only when there are folders OR pending removals to save.
     * All buttons (IMPORT, UPDATE, and REMOVE) are disabled during sync (mIsUpdating = true).
     */
    private void updateFolderButtons() {
        // Update REMOVE buttons in the adapter - disabled during sync
        if (mFolderAdapter != null) {
            if (mIsUpdating) {
                mFolderAdapter.disableRemoveButtons();
            } else {
                mFolderAdapter.enableRemoveButtons();
            }
        }
        
        // Update IMPORT button - disabled during sync
        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        if (importFolderButton != null) { 
            importFolderButton.setEnabled(!mIsUpdating); 
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(importFolderButton, !mIsUpdating);
            }
        }
        
        // Refresh UPDATE button state - disabled during sync, also check if there's content to update
        boolean hasFolders = !mFolderItems.isEmpty();
        boolean hasPendingRemovals = !mFoldersToRemove.isEmpty();
        boolean shouldEnableUpdateButton = (hasFolders || hasPendingRemovals) && !mIsUpdating;
        
        Button updateButton = (Button) findViewById(R.id.updateButton);
        if (updateButton != null) {
            updateButton.setEnabled(shouldEnableUpdateButton);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(updateButton, shouldEnableUpdateButton);
            }
        }
    }

    /**
     * Disables a button and updates its theme.
     *
     * @param button The button to disable (can be null)
     */
    private void disableButton(@Nullable Button button) {
        if (button != null) { 
            button.setEnabled(false); 
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(button, false);
            }
        }
    }

    // ========================================================================
    // Update Management Methods
    // ========================================================================
    
    /**
     * Saves folder changes and triggers playlist update.
     * Called when the UPDATE button is clicked.
     * 
     * <p>This method performs the following sequence:
     * <ol>
     *   <li>Checks if a sync is already in progress</li>
     *   <li>Begins playlist sync via NavigationController</li>
     *   <li>Saves current player state</li>
     *   <li>Disables UI buttons</li>
     *   <li>Applies pending removals to database</li>
     *   <li>Handles edge cases (no content, no folders)</li>
     *   <li>Triggers playlist update if content exists</li>
     * </ol>
     * </p>
     */
    private void saveChanges() {
        PlaylistService service = PlaylistService.getInstance(this);
        if (service != null && service.isUpdating()) {
            ToastManager.showToast(this, "Playlist sync already in progress. Please wait...", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        NavigationController.getInstance().beginPlaylistSync();
        
        final boolean clearLooseTracks = mFoldersToRemove.contains("LOOSE_TRACKS");
        
        final Set<String> foldersToKeep = new HashSet<String>(mMusicLibrary.getSelectedFolders());
        for (String folderUriString : mFoldersToRemove) {
            foldersToKeep.remove(folderUriString);
        }
        
        boolean hasLooseAfterClear = false;
        if (!clearLooseTracks) {
            ArrayList<Song> remainingLoose = SongDatabase.getInstance(this).getLooseSongs();
            hasLooseAfterClear = remainingLoose != null && !remainingLoose.isEmpty();
        }
        
        final boolean hasAnyFolders = !foldersToKeep.isEmpty();
        final boolean hasAnyContent = hasAnyFolders || hasLooseAfterClear;
        
        mIsUpdating = true;
        updateFolderButtons();
        
        if (mFolderAdapter != null) {
            mFolderAdapter.disableRemoveButtons();
        }
        
        Intent saveIntent = new Intent(ACTION_SAVE_PLAYER_STATE_NOW);
        sendBroadcast(saveIntent);
        
        // Delay execution to allow MusicService to save its state.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MusicService.setPlayerStateBeforeUpdate(FolderManager.this, true);
                
                Button updateButton = (Button) findViewById(R.id.updateButton);
                Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                disableButton(updateButton);
                disableButton(importFolderButton);
                
                if (clearLooseTracks) {
                    SongDatabase.getInstance(FolderManager.this).clearLooseSongs();
                }
                
                for (String folderUriString : mFoldersToRemove) {
                    if (!folderUriString.equals("LOOSE_TRACKS")) {
                        mMusicLibrary.removeFolder(folderUriString);
                    }
                }
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putStringSet(KEY_SELECTED_FOLDERS_URIS, foldersToKeep).apply();
                
                if (!hasAnyContent) {
                    handleNoContentRemaining(prefs);
                    return;
                }
                
                if (!hasAnyFolders) {
                    handleNoFoldersRemaining(prefs);
                    return;
                }
                
                performPlaylistUpdate();
            }
        }, STATE_SAVE_DELAY_MS);
    }
    
    /**
     * Called when playlist update completes successfully.
     * Re-enables UI components and broadcasts update completion.
     */
    private void updateComplete() {
        if (mFolderAdapter != null) {
            mFolderAdapter.enableRemoveButtons();
        }
        
        Intent updateIntent = new Intent(ACTION_UPDATE_PLAYLIST_FROM_FOLDERS);
        sendBroadcast(updateIntent);
        
        NavigationController.getInstance().endPlaylistSync();
        
        loadFolders();
        updateFolderButtons();
    }

    /**
     * Handles the case where all content (folders and loose tracks) has been removed.
     * Clears all state, stops playback, and resets the player.
     *
     * @param prefs SharedPreferences instance
     */
    private void handleNoContentRemaining(@NonNull SharedPreferences prefs) {
        SongDatabase.getInstance(this).clearCache();
        SongDatabase.getInstance(this).clearLooseSongs();
        
        prefs.edit()
            .putInt("current_playing_index", -1)
            .putInt("current_position", 0)
            .putBoolean("last_playing", false)
            .putString("last_song_path", null)
            .putBoolean("player_state_before_update", false)
            .apply();
        
        ArrayList<Song> emptyPlaylist = new ArrayList<Song>();
        mMusicLibrary.refreshSongs(emptyPlaylist);
        
        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);
        
        Intent resetIntent = new Intent(ACTION_RESET_PLAYER_STATE);
        resetIntent.putExtra("preserve_settings", true);
        sendBroadcast(resetIntent);
        
        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);
        
        ToastManager.showPersistentOverlay(this, "Syncing playlist...");
        
        NavigationController.getInstance().endPlaylistSync();
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();
                loadFolders();
                mIsUpdating = false;
                
                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    /**
     * Handles the case where all folders have been removed but loose tracks remain.
     * Clears folder-based songs but preserves loose tracks in the playlist.
     *
     * @param prefs SharedPreferences instance
     */
    private void handleNoFoldersRemaining(@NonNull SharedPreferences prefs) {
        SongDatabase.getInstance(this).clearCache();
        
        prefs.edit()
            .putInt("current_playing_index", -1)
            .putInt("current_position", 0)
            .putBoolean("last_playing", false)
            .putString("last_song_path", null)
            .putBoolean("player_state_before_update", false)
            .apply();
        
        ArrayList<Song> emptyPlaylist = new ArrayList<Song>();
        mMusicLibrary.refreshSongs(emptyPlaylist);
        
        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);
        
        Intent refreshIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
        sendBroadcast(refreshIntent);
        
        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);
        
        ToastManager.showPersistentOverlay(this, "Syncing playlist...");
        
        NavigationController.getInstance().endPlaylistSync();
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();
                loadFolders();
                mIsUpdating = false;
                
                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    /**
     * Performs the actual playlist update by calling PlaylistService.
     * Shows progress updates via persistent overlay and broadcasts sync state.
     * 
     * <p>The update happens asynchronously with callbacks:
     * <ul>
     *   <li>onProgress - Updates the persistent overlay with current scan status</li>
     *   <li>onComplete - Hides overlay and triggers updateComplete()</li>
     *   <li>onError - Shows error message and reverts UI state</li>
     * </ul>
     * </p>
     * 
     * <p>After Phase 1 completes, this method also triggers the genre loading phase
     * (Phase 2) to read ID3 tags and populate genres for all songs in the background.</p>
     */
    private void performPlaylistUpdate() {
        final boolean[] persistentShown = {false};

        PlaylistService.getInstance(this).updatePlaylist(new PlaylistService.UpdateCallback() {
            @Override
            public void onProgress(final int current, final int total) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String progressMessage;
                        if (current == 0) {
                            progressMessage = "Searching folders...";
                        } else if (current < total) {
                            progressMessage = "Searching folders... " + current + " song" + 
                                (current != 1 ? "s" : "") + " found";
                        } else {
                            progressMessage = "Syncing playlist... " + current + " song" + 
                                (current != 1 ? "s" : "") + " found";
                        }
                        
                        if (!persistentShown[0]) {
                            ToastManager.showPersistentOverlay(FolderManager.this, progressMessage);
                            persistentShown[0] = true;
                        } else {
                            ToastManager.updatePersistentOverlay(progressMessage);
                        }
                        
                        Intent syncStartedIntent = new Intent(ACTION_SYNC_STARTED);
                        syncStartedIntent.putExtra("custom_text", progressMessage);
                        sendBroadcast(syncStartedIntent);
                    }
                });
            }
            
            @Override
            public void onComplete(final int songCount) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);
                        
                        ToastManager.updatePersistentOverlay("Loading metadata...");
                        
                        // Trigger genre update after Phase 1 completes
                        triggerGenreUpdate();
                        
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                updateComplete();
                                ToastManager.hidePersistentOverlay();
                                updateFolderButtons();
                                loadFolders();
                                mIsUpdating = false;
                                mGenreUpdateTriggered = false;
                            }
                        }, OVERLAY_HIDE_DELAY_MS);
                    }
                });
            }
            
            @Override
            public void onError(@NonNull final String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mFolderAdapter != null) {
                            mFolderAdapter.enableRemoveButtons();
                        }
                        
                        if (persistentShown[0]) {
                            ToastManager.hidePersistentOverlay();
                        }
                        
                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);
                        
                        NavigationController.getInstance().endPlaylistSync();
                        
                        mIsUpdating = false;
                        updateFolderButtons();
                        ToastManager.showToast(FolderManager.this, "Error: " + error, 
                            ToastManager.LENGTH_NORMAL);
                    }
                });
            }
        });
    }
    
    /**
     * Triggers genre update for songs that still have "Unknown Genre".
     * 
     * <p>This method runs after Phase 1 (fast scan) completes. It identifies all songs
     * that still have "Unknown Genre" and processes them in a background thread,
     * reading the real genre from ID3 tags using CharacterMapper. Each successful
     * genre update triggers a broadcast to refresh the UI for that specific song.</p>
     * 
     * <p>This is Phase 2 of the two-phase loading architecture, providing progressive
     * UI updates as genres become available without blocking the user interface.</p>
     */
    private void triggerGenreUpdate() {
        if (mGenreUpdateTriggered) {
            Log.d(TAG, "Genre update already triggered, skipping");
            return;
        }
        mGenreUpdateTriggered = true;
        
        // Refresh MusicLibrary cache to get the latest songs from database after Phase 1
        if (mMusicLibrary != null) {
            mMusicLibrary.refreshCache();
        }
        
        // Get all songs that need genres
        ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
        final ArrayList<Song> songsNeedingGenres = new ArrayList<Song>();
        
        for (Song song : allSongs) {
            if (song != null && ("Unknown Genre".equals(song.getGenre()) || 
                                 song.getGenre() == null || 
                                 song.getGenre().isEmpty())) {
                songsNeedingGenres.add(song);
            }
        }
        
        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            return;
        }
        
        Log.d(TAG, "Triggering genre update for " + songsNeedingGenres.size() + " songs");
        
        // Show overlay on UI thread
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ToastManager.showPersistentOverlay(FolderManager.this, "Loading metadata...");
            }
        });
        
        // Send broadcast to notify that genre loading has started
        Intent genreStartIntent = new Intent(ACTION_GENRE_UPDATE);
        genreStartIntent.putExtra("status", "START");
        genreStartIntent.putExtra("total", songsNeedingGenres.size());
        sendBroadcast(genreStartIntent);
        
        // Process in background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                final SongDatabase db = SongDatabase.getInstance(FolderManager.this);
                final MusicLibrary musicLibrary = new MusicLibrary(FolderManager.this);
                int updated = 0;
                final int total = songsNeedingGenres.size();
                
                for (Song song : songsNeedingGenres) {
                    if (song == null || TextUtils.isEmpty(song.getPath())) {
                        continue;
                    }
                    
                    // Read genre from file using CharacterMapper (bypasses database cache)
                    String realGenre = CharacterMapper.getGenre(song.getPath());
                    
                    boolean hasRealGenre = (realGenre != null && 
                                           !realGenre.isEmpty() && 
                                           !"Unknown Genre".equals(realGenre));
                    
                    if (hasRealGenre) {
                        Song updatedSong = new Song(
                            song.getTitle(),
                            song.getArtist(),
                            song.getAlbum(),
                            realGenre,
                            song.getPath(),
                            song.getDuration(),
                            song.getUri()
                        );
                        
                        // Update database
                        db.insertSong(updatedSong);
                        
                        // Update in-memory cache
                        musicLibrary.updateSongGenre(song.getPath(), realGenre);
                        
                        // Update local song object
                        song.setGenre(realGenre);
                        updated++;
                        
                        // Send broadcast to update UI for this song
                        Intent genreUpdateIntent = new Intent(ACTION_GENRE_UPDATE);
                        genreUpdateIntent.putExtra("status", "UPDATE");
                        genreUpdateIntent.putExtra("song_path", song.getPath());
                        genreUpdateIntent.putExtra("genre", realGenre);
                        genreUpdateIntent.putExtra("current", updated);
                        genreUpdateIntent.putExtra("total", total);
                        sendBroadcast(genreUpdateIntent);
                        
                        Log.d(TAG, "Genre updated: " + song.getTitle() + " -> " + realGenre);
                    }
                }
                
                Log.d(TAG, "Genre update completed: " + updated + " songs updated out of " + total);
                
                // Send completion broadcast
                Intent genreCompleteIntent = new Intent(ACTION_GENRE_UPDATE);
                genreCompleteIntent.putExtra("status", "COMPLETE");
                genreCompleteIntent.putExtra("current", updated);
                genreCompleteIntent.putExtra("total", total);
                sendBroadcast(genreCompleteIntent);
                
                // Force playlist refresh
                Intent forceRefreshIntent = new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                sendBroadcast(forceRefreshIntent);
                
                // Hide overlay on UI thread
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay();
                    }
                });
            }
        }).start();
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================
    
    /**
     * Registers the theme color change broadcast receiver.
     * Listens for THEME_COLOR_CHANGED action and refreshes UI colors.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    
                    if (mFolderAdapter != null) {
                        mFolderAdapter.notifyDataSetChanged();
                    }
                    
                    ToastManager.refreshThemeColor();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        registerReceiver(mThemeReceiver, filter);
    }

    /**
     * Registers the loose tracks update broadcast receiver.
     * Reloads the folder list when loose tracks are added or removed.
     */
    private void registerLooseTracksReceiver() {
        mLooseTracksUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_LOOSE_TRACKS_UPDATED.equals(intent.getAction())) {
                    loadFolders();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_LOOSE_TRACKS_UPDATED);
        registerReceiver(mLooseTracksUpdateReceiver, filter);
    }
    
    /**
     * Registers the sync completion broadcast receiver.
     * 
     * <p>When Phase 1 (playlist sync) completes, this receiver refreshes
     * the MusicLibrary cache to ensure Phase 2 has access to the latest
     * songs from the database.</p>
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SYNC_COMPLETE.equals(intent.getAction())) {
                    Log.d(TAG, "Sync complete - refreshing MusicLibrary cache");
                    if (mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                    }
                    // Also refresh the folder list (loose tracks count may have changed)
                    loadFolders();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_SYNC_COMPLETE);
        registerReceiver(mSyncCompleteReceiver, filter);
    }

    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}