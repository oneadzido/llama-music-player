package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Displays and edits the set of imported music folders and the Loose
 * Tracks entry.
 *
 * <p>The activity shows every imported folder and the Loose Tracks entry
 * in a list, lets the user add a folder through the Storage Access
 * Framework, stage folder removals, and commit those removals by tapping
 * UPDATE. Committing runs a playlist sync, then triggers genre loading.
 * The activity also provides an empty state shown when no folders and no
 * loose tracks remain.</p>
 *
 * <p>Folder removals are staged in a {@link PendingChanges} holder until
 * the user confirms them, so a batch of removals results in a single
 * playlist rebuild.</p>
 *
 * <h3>State Ownership</h3>
 * <p>Three pieces of state participate in an update cycle, each with a
 * single owner:</p>
 * <ul>
 *   <li><b>Pending changes</b> — owned by this activity through
 *       {@link #mPendingChanges}. Staging is local to the activity and
 *       lives only for the duration of an editing session.</li>
 *   <li><b>Update-in-progress</b> — owned by {@link NavigationController}.
 *       This activity queries the controller rather than caching the flag,
 *       so the two cannot drift even if a broadcast is dropped.</li>
 *   <li><b>Player state</b> — owned by {@link MusicService}. This
 *       activity sends broadcast messages to the service.</li>
 * </ul>
 *
 * <h3>Overlay Ownership</h3>
 * <p>Two operations run in sequence during a folder update. Folder sync
 * is owned by this activity: its persistent overlay is shown with the
 * {@code "FOLDER_SYNC"} operation ID and hidden by the same ID, and when
 * the sync completes the overlay is torn down before genre loading is
 * triggered. Genre loading is owned by {@link PlaylistManager}: its
 * overlay is shown with the {@code "GENRE_UPDATE"} operation ID and
 * hidden by the same ID. This activity observes the {@code GENRE_UPDATE}
 * broadcasts read-only for its own progress reporting.</p>
 *
 * <p>{@link #onDestroy()} does not touch the persistent overlay. The
 * overlay's lifetime is owned by whichever operation showed it, and an
 * activity that is being destroyed while a different operation owns the
 * overlay must not tear that operation's progress down. Overlays are
 * hidden by their owners through
 * {@link ToastManager#hidePersistentOverlay(String)}.</p>
 *
 * <h3>Full Library Wipe</h3>
 * <p>When the user removes every folder and every loose track, this
 * activity runs a full library wipe in
 * {@link #handleNoContentRemaining}: any in-flight scan is cancelled, the
 * database is cleared, the SAF permission mappings are dropped, the
 * persisted player state is cleared, and {@code RESET_PLAYER_STATE} is
 * sent with {@code preserve_settings=false} so the service also clears
 * its playback preferences. Leftover {@code temp_audio_*} and
 * {@code backup_*} files in the cache directory are swept. The equalizer
 * preferences are preserved so the user can add folders back without
 * reconfiguring the equalizer.</p>
 *
 * <p>Both wipe paths call {@link MusicLibrary#invalidate()} rather than
 * {@link MusicLibrary#refreshCache()}. {@code refreshCache} re-reads the
 * songs table while keeping this instance's cached folder set;
 * {@code invalidate} additionally drops the cached set and re-reads it
 * from preferences, so this instance converges on the emptied selection
 * and a later scan cannot rescan the removed folders.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — {@link #mPendingChanges} is the only holder of staged
 *       removals. No other field or local variable accumulates them.</li>
 *   <li>I2 — Reads of "is an update in progress" query
 *       {@link NavigationController#isGroupDisabled(NavigationController.ButtonGroup)}
 *       through {@link #isUpdating()}.</li>
 *   <li>I3 — Every path that begins an update calls
 *       {@link NavigationController#beginPlaylistSync()} before modifying
 *       any state, and ends it through the matching end call.</li>
 *   <li>I4 — {@link #mPendingChanges} is cleared only by
 *       {@link #loadFolders()}, which runs on resume and on update
 *       completion. No path clears it mid-cycle.</li>
 *   <li>I5 — The {@code "FOLDER_SYNC"} overlay is owned exclusively by
 *       this activity. It is shown when the first progress update arrives
 *       and hidden by ID before genre loading begins.</li>
 *   <li>I6 — The {@code "GENRE_UPDATE"} overlay is owned exclusively by
 *       {@link PlaylistManager}. This activity observes it read-only.</li>
 *   <li>I7 — When a folder-update cycle ends, {@link #loadFolders()} runs
 *       before {@link NavigationController#endPlaylistSync()}, so the
 *       button state callback fired by the end call sees the post-update
 *       state.</li>
 *   <li>I8 — Remove-button enabled state is a function of
 *       {@link NavigationController}'s folder-actions state. This
 *       activity pushes no such state into {@link FolderAdapter}; the
 *       adapter queries the controller on bind.</li>
 *   <li>I9 — The full-wipe path cancels any in-flight scan before clearing
 *       the database, clears only library- and session-scoped preference
 *       keys, and writes or removes no key owned by
 *       {@link EqualizerManager}.</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. The background cleanup in
 * {@link #cleanupTempCacheAsync()} runs on a short-lived thread and
 * touches only the cache directory and the log.</p>
 *
 * @see FolderAdapter
 * @see NavigationController
 * @see PlaylistManager
 * @see MusicService
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class FolderManager extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Request code for the Storage Access Framework folder picker. */
    private static final int FOLDER_SELECT_CODE = 300;

    /** Log tag for this class. */
    private static final String TAG = "FolderManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS_URIS = "selected_folders_uris";

    /** Key for the persisted current playing index. */
    private static final String KEY_CURRENT_PLAYING_INDEX = "current_playing_index";

    /** Key for the persisted current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for the persisted player-state-before-update flag. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    /** Delay before save operations begin, in milliseconds. */
    private static final int STATE_SAVE_DELAY_MS = 150;

    /** Delay before hiding the persistent overlay, in milliseconds. */
    private static final int OVERLAY_HIDE_DELAY_MS = 1500;

    /** Animation duration for button press effects, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Horizontal padding of the empty-state container, in dp. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /** Top padding of the empty-state container, in dp. */
    private static final int EMPTY_CONTAINER_TOP_PADDING_DP = 64;

    /** Broadcast action asking the service to save player state now. */
    private static final String ACTION_SAVE_PLAYER_STATE_NOW = "SAVE_PLAYER_STATE_NOW";

    /** Broadcast action asking consumers to rebuild the playlist from folders. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS =
        "UPDATE_PLAYLIST_FROM_FOLDERS";

    /** Broadcast action asking the service to reset player state. */
    private static final String ACTION_RESET_PLAYER_STATE = "RESET_PLAYER_STATE";

    /** Broadcast action asking the playlist to redraw. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";

    /** Broadcast action asking for a soft playlist update. */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";

    /** Broadcast action emitted when a sync finishes. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action emitted when a sync starts. */
    private static final String ACTION_SYNC_STARTED = "SYNC_STARTED";

    /** Service action requesting the service to stop. */
    private static final String ACTION_STOP = "ACTION_STOP";

    /** Broadcast action emitted when the theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /** Broadcast action emitted when the loose tracks list changes. */
    private static final String ACTION_LOOSE_TRACKS_UPDATED = "LOOSE_TRACKS_UPDATED";

    /** Timestamp of the last cancel button click, for debouncing. */
    private long mLastCancelClickTime = 0;

    /** Debounce delay for the cancel button, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Operation ID for the folder-sync overlay owned by this activity. */
    private static final String OP_FOLDER_SYNC = "FOLDER_SYNC";

    // ========================================================================
    // Pending Changes Holder
    // ========================================================================

    /**
     * Holds the set of folder removals and the loose-tracks removal flag
     * staged by the user until UPDATE is tapped.
     */
    private static final class PendingChanges {

        /** Folder URI strings staged for removal. */
        @NonNull
        private final ArrayList<String> mFoldersToRemove = new ArrayList<String>();

        /** True when the Loose Tracks entry is staged for removal. */
        private boolean mClearLooseTracks = false;

        /**
         * Stages the given folder URI for removal, ignoring duplicates.
         *
         * @param folderUri URI string of the folder to remove
         */
        void addFolderToRemove(@NonNull String folderUri) {
            if (!mFoldersToRemove.contains(folderUri)) {
                mFoldersToRemove.add(folderUri);
            }
        }

        /**
         * Stages the Loose Tracks entry for removal.
         */
        void markLooseTracksForRemoval() {
            mClearLooseTracks = true;
        }

        /**
         * Returns whether nothing has been staged.
         *
         * @return True when no folder removals and no loose-tracks
         *         removal are staged
         */
        boolean isEmpty() {
            return mFoldersToRemove.isEmpty() && !mClearLooseTracks;
        }

        /**
         * Returns whether the Loose Tracks entry is staged for removal.
         *
         * @return True when the Loose Tracks entry is staged
         */
        boolean isClearLooseTracks() {
            return mClearLooseTracks;
        }

        /**
         * Returns a copy of the staged folder removals.
         *
         * @return A copy of the folder removals list
         */
        @NonNull
        ArrayList<String> getFoldersToRemove() {
            return new ArrayList<>(mFoldersToRemove);
        }

        /**
         * Clears every staged change.
         */
        void clear() {
            mFoldersToRemove.clear();
            mClearLooseTracks = false;
        }
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Library facade used to add and remove folders. */
    private MusicLibrary mMusicLibrary;

    /** Recycler view that displays the folder rows. */
    private RecyclerView mFoldersRecyclerView;

    /** Adapter backing the folder recycler view. */
    private FolderAdapter mFolderAdapter;

    /** Folder items currently displayed. */
    private List<FolderAdapter.FolderItem> mFolderItems;

    /** Text view that shows the folder count. */
    private TextView mFolderCountText;

    /** Holder of the folder removals staged by the user. */
    @NonNull
    private final PendingChanges mPendingChanges = new PendingChanges();

    /** True once genre loading has been triggered for the current cycle. */
    private boolean mGenreUpdateTriggered = false;

    /** Container shown when no folders and no loose tracks remain. */
    private LinearLayout mEmptyContainer;

    /** Root container that hosts the empty state. */
    private FrameLayout mRootContainer;

    /** Manager that supplies the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    /** Receiver for loose-track update broadcasts. */
    private BroadcastReceiver mLooseTracksUpdateReceiver;

    /** Receiver for sync-complete broadcasts. */
    private BroadcastReceiver mSyncCompleteReceiver;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    /**
     * Initializes the activity, loads the folder list, registers
     * receivers, and subscribes to
     * {@link NavigationController} button state changes.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_folder_manager);

        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mFolderItems = new ArrayList<FolderAdapter.FolderItem>();

        initializeViews();
        loadFolders();
        registerLooseTracksReceiver();
        registerSyncCompleteReceiver();
        applyThemeToUI();
        themeAllHeaders();

        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Reattaches a persistent overlay if one is active, registers the
     * theme receiver if needed, and reloads the folder list.
     */
    @Override
    protected void onResume() {
        super.onResume();

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiverSafely(mThemeReceiver);
        mThemeReceiver = null;
    }

    /**
     * Reattaches the persistent overlay, refreshes the folder list, and
     * reapplies the theme.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart - FolderManager resumed, update in progress: " + isUpdating());

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ToastManager.ensureOverlayAttached(FolderManager.this);
                    ToastManager.reattachToCurrentActivity(FolderManager.this);
                }
            }, 100);
        }

        ToastManager.ensureOverlayAttached(this);

        updateFolderButtons();

        loadFolders();
        applyThemeToUI();
        themeAllHeaders();

        if (isUpdating()) {
            PlaylistManager playlistManager = PlaylistManager.getInstance(this);
            if (playlistManager != null && playlistManager.isUpdating()) {
                ToastManager.ensureOverlayAttached(this);
            }
        }
    }

    /**
     * Unregisters listeners and receivers and removes handler callbacks.
     *
     * <p>Does not tear down the persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; this activity
     * may be destroying itself while {@link PlaylistManager} still owns
     * the {@code "GENRE_UPDATE"} overlay, and the ownership contract on
     * {@link ToastManager} exists precisely so this activity cannot
     * strand that operation's progress. Overlays are hidden by their
     * owners through {@link ToastManager#hidePersistentOverlay(String)}.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        NavigationController.getInstance().unregisterListener(this);

        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mLooseTracksUpdateReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Returns to the music player instead of leaving the application.
     */
    @Override
    public void onBackPressed() {
        returnToMusicPlayer();
    }

    /**
     * Reapplies immersive mode when the window gains focus and reattaches
     * any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Handles the folder picker result by persisting the chosen folder's
     * permission and importing it.
     *
     * @param requestCode The request code passed to
     *        {@link #startActivityForResult(Intent, int)}
     * @param resultCode The result code returned by the picker
     * @param data The intent carrying the picked URI, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                persistFolderPermission(treeUri);
            }
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    /**
     * Returns to the music player activity with the slide-right
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    // ========================================================================
    // Update State Query
    // ========================================================================

    /**
     * Returns whether a playlist update is in progress, according to
     * {@link NavigationController}.
     *
     * @return True when the folder-actions button group is disabled
     */
    private boolean isUpdating() {
        return NavigationController.getInstance()
            .isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================

    /**
     * Applies the disabled state of the folder-actions button group to
     * every button that modifies the folder set, and refreshes the
     * adapter's remove-button state.
     *
     * @param group The button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Button updateButton = (Button) findViewById(R.id.updateButton);
                    if (updateButton != null) {
                        updateButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(updateButton, !finalDisabled);
                        }
                    }

                    Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                    if (importFolderButton != null) {
                        importFolderButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(importFolderButton, !finalDisabled);
                        }
                    }

                    // The adapter queries NavigationController on bind. A
                    // rebind is all that is needed to reflect the new state.
                    if (mFolderAdapter != null) {
                        mFolderAdapter.refreshRemoveButtonStates();
                    }

                    updateFolderButtons();
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    /**
     * Configures the activity window for full-screen immersive display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    /**
     * Resolves the activity's views, attaches the folder adapter, and
     * wires the import, update, and cancel buttons.
     */
    private void initializeViews() {
        mFoldersRecyclerView = (RecyclerView) findViewById(R.id.foldersRecyclerView);
        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setLayoutManager(new LinearLayoutManager(this));

            DividerItemDecoration divider = new DividerItemDecoration(
                this, DividerItemDecoration.VERTICAL);
            divider.setDrawable(ContextCompat.getDrawable(this, R.drawable.divider_custom));
            mFoldersRecyclerView.addItemDecoration(divider);
        }

        mFolderCountText = (TextView) findViewById(R.id.folderCountText);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);

        animateButton(importFolderButton);
        animateButton(updateButton);
        animateButton(cancelButton);

        mFolderAdapter = new FolderAdapter(
            this, mFolderItems, new FolderAdapter.OnFolderRemoveListener() {
            @Override
            public void onFolderRemove(@NonNull String folderUriString, int position) {
                mPendingChanges.addFolderToRemove(folderUriString);
                mFolderAdapter.removeItem(position);
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }

            @Override
            public void onLooseTracksRemove() {
                mPendingChanges.markLooseTracksForRemoval();
                for (int index = 0; index < mFolderItems.size(); index++) {
                    if (mFolderItems.get(index).isLooseTracks) {
                        mFolderAdapter.removeItem(index);
                        break;
                    }
                }
                updateFolderCount();
                updateFolderButtons();

                if (mFolderAdapter.getItemCount() == 0) {
                    showEmptyView();
                }
            }
        });

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setAdapter(mFolderAdapter);
        }

        if (importFolderButton != null) {
            importFolderButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        selectFolder();
                    }
                }
            });
        }

        if (updateButton != null) {
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!isUpdating()) {
                        saveChanges();
                    }
                }
            });
        }

        if (cancelButton != null) {
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        returnToMusicPlayer();
                    }
                }
            });
        }
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button The button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // UI State Management Methods
    // ========================================================================

    /**
     * Displays the empty-state container and hides the folder list.
     */
    private void showEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null
                && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_TOP_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText(
            "Tap IMPORT FOLDER to add music folders.\n"
                + "Tap UPDATE to save changes.\n\n"
                + "Music files opened from other apps\n"
                + "will appear here as Loose Tracks.");
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mRootContainer != null) {
            mRootContainer.addView(mEmptyContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        }

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.GONE);
        }
    }

    /**
     * Removes the empty-state container and shows the folder list.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null && mRootContainer != null
                && mEmptyContainer.getParent() != null) {
            mRootContainer.removeView(mEmptyContainer);
        }
        mEmptyContainer = null;

        if (mFoldersRecyclerView != null) {
            mFoldersRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Updates the folder count text to reflect the current display list.
     */
    private void updateFolderCount() {
        int folderCount = 0;
        boolean hasLooseTracks = false;

        for (FolderAdapter.FolderItem folderItem : mFolderItems) {
            if (folderItem.isLooseTracks) {
                hasLooseTracks = true;
            } else {
                folderCount++;
            }
        }

        if (hasLooseTracks) {
            folderCount++;
        }

        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));

            if (folderCount == 0) {
                mFolderCountText.setText("0 folders");
            } else if (folderCount == 1) {
                mFolderCountText.setText("1 folder");
            } else {
                mFolderCountText.setText(folderCount + " folders");
            }
        }
    }

    /**
     * Applies the current theme color to the activity's buttons and the
     * adapter's remove buttons.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        Button updateButton = (Button) findViewById(R.id.updateButton);
        Button cancelButton = (Button) findViewById(R.id.cancelButton);

        mThemeHelper.updateButton(importFolderButton,
            importFolderButton != null && importFolderButton.isEnabled());
        mThemeHelper.updateButton(updateButton,
            updateButton != null && updateButton.isEnabled());
        mThemeHelper.updateButton(cancelButton,
            cancelButton != null && cancelButton.isEnabled());

        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }
    }

    /**
     * Applies the header text color to every header TextView in the
     * activity.
     */
    private void themeAllHeaders() {
        if (mFolderCountText != null) {
            mFolderCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews in the
     * given view hierarchy.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("MANAGER")
                        || text.equals("FOLDER LIST")
                        || text.contains("folders")
                        || text.contains("folder")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ========================================================================
    // Folder Management Methods
    // ========================================================================

    /**
     * Persists the given folder's URI permission, adds it to the library,
     * removes any loose songs contained within it, and reloads the folder
     * list.
     *
     * @param treeUri The folder URI chosen by the user
     */
    private void persistFolderPermission(@NonNull Uri treeUri) {
        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;

        try {
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (SecurityException exception) {
            ToastManager.showToast(this, "Permission denied for folder",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        String folderUriString = treeUri.toString();
        mMusicLibrary.addFolder(folderUriString);
        cleanLooseSongsInFolder(treeUri);
        loadFolders();

        String folderName = getFolderNameFromUri(treeUri);
        if (folderName != null) {
            ToastManager.showToast(this, "Imported: " + folderName,
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies inside
     * the given folder.
     *
     * @param folderUri The folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }

        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null || looseSongs.isEmpty()) {
            return;
        }

        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong != null && looseSong.getPath() != null
                    && looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
            }
        }
    }

    /**
     * Returns the filesystem path encoded in the given primary-storage
     * tree URI, or null when the URI does not refer to primary storage.
     *
     * @param uri The folder URI to inspect
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();

        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/");
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                }
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to get folder path", exception);
                return null;
            }
        }
        return null;
    }

    /**
     * Returns the display name of the given folder URI, cleaned of
     * control characters and HTML entities.
     *
     * @param uri The folder URI
     * @return The display name; never null
     */
    @NonNull
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;

        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to get folder name", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to close cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        if (name == null) {
            name = "Music Folder";
        }

        return CharacterMapper.cleanString(name);
    }

    /**
     * Clears the staged changes, rebuilds the display list from the
     * library, and refreshes every dependent view.
     */
    private void loadFolders() {
        mFolderItems.clear();
        Set<String> folders = mMusicLibrary.getSelectedFolders();
        mPendingChanges.clear();

        Log.d(TAG, "loadFolders: " + folders.size() + " folders found");

        ArrayList<Song> validLooseSongs = getValidLooseSongs();
        boolean hasLooseSongs = !validLooseSongs.isEmpty();

        if (folders.isEmpty() && !hasLooseSongs) {
            showEmptyView();
        } else {
            hideEmptyView();

            for (final String folderUriString : folders) {
                Uri folderUri = Uri.parse(folderUriString);
                String name = getFolderNameFromUri(folderUri);
                String storageType = StorageAccessHelper.getInstance(this)
                    .getStorageType(folderUriString);
                String displayName = name + storageType;
                mFolderItems.add(new FolderAdapter.FolderItem(folderUriString, displayName));
            }

            if (hasLooseSongs) {
                mFolderItems.add(new FolderAdapter.FolderItem(validLooseSongs.size()));
            }

            mFolderAdapter.refreshRemoveButtonStates();
        }

        updateFolderCount();
        themeAllHeaders();
        updateFolderButtons();
    }

    /**
     * Returns every loose song whose file exists and is readable, and
     * removes from the database any loose song whose file does not.
     *
     * @return The list of valid loose songs
     */
    @NonNull
    private ArrayList<Song> getValidLooseSongs() {
        ArrayList<Song> validLooseSongs = new ArrayList<Song>();
        ArrayList<Song> allLooseSongs = SongDatabase.getInstance(this).getLooseSongs();

        if (allLooseSongs != null) {
            for (Song looseSong : allLooseSongs) {
                if (looseSong != null && looseSong.getPath() != null) {
                    File file = new File(looseSong.getPath());
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(looseSong);
                    } else {
                        SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
                    }
                }
            }
        }

        return validLooseSongs;
    }

    /**
     * Opens the Storage Access Framework folder picker.
     */
    private void selectFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(intent, FOLDER_SELECT_CODE);
        } catch (Exception exception) {
            ToastManager.showToast(this, "No file manager found",
                ToastManager.LENGTH_NORMAL);
        }
    }

    // ========================================================================
    // Button State Management
    // ========================================================================

    /**
     * Refreshes the enabled state of the import and update buttons from
     * the current update-in-progress state and pending changes.
     */
    private void updateFolderButtons() {
        // The adapter queries NavigationController on bind; a refresh here
        // is all that is needed to align its view with the controller's.
        if (mFolderAdapter != null) {
            mFolderAdapter.refreshRemoveButtonStates();
        }

        Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
        if (importFolderButton != null) {
            importFolderButton.setEnabled(!isUpdating());
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(importFolderButton, !isUpdating());
            }
        }

        boolean hasFolders = !mFolderItems.isEmpty();
        boolean hasPendingRemovals = !mPendingChanges.isEmpty();
        boolean shouldEnableUpdateButton = (hasFolders || hasPendingRemovals) && !isUpdating();

        Button updateButton = (Button) findViewById(R.id.updateButton);
        if (updateButton != null) {
            updateButton.setEnabled(shouldEnableUpdateButton);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(updateButton, shouldEnableUpdateButton);
            }
        }
    }

    /**
     * Disables the given button and reapplies its disabled theme.
     *
     * @param button The button to disable, or null
     */
    private void disableButton(@Nullable Button button) {
        if (button != null) {
            button.setEnabled(false);
            if (mThemeHelper != null) {
                mThemeHelper.updateButton(button, false);
            }
        }
    }

    // ========================================================================
    // Update Management Methods
    // ========================================================================

    /**
     * Begins a folder-update cycle. If the user has staged no content
     * removals and some content remains, the playlist is updated through
     * {@link PlaylistManager}. If the user has removed every folder and
     * every loose track, or every folder while loose tracks remain, the
     * corresponding wipe path runs instead.
     */
    private void saveChanges() {
        PlaylistManager playlistManager = PlaylistManager.getInstance(this);
        if (playlistManager != null && playlistManager.isUpdating()) {
            ToastManager.showToast(this,
                "Playlist sync already in progress. Please wait...",
                ToastManager.LENGTH_NORMAL);
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final boolean clearLooseTracks = mPendingChanges.isClearLooseTracks();

        final Set<String> foldersToKeep =
            new HashSet<String>(mMusicLibrary.getSelectedFolders());
        for (String folderUriString : mPendingChanges.getFoldersToRemove()) {
            foldersToKeep.remove(folderUriString);
        }

        boolean hasLooseAfterClear = false;
        if (!clearLooseTracks) {
            ArrayList<Song> remainingLoose = SongDatabase.getInstance(this).getLooseSongs();
            hasLooseAfterClear = remainingLoose != null && !remainingLoose.isEmpty();
        }

        final boolean hasAnyFolders = !foldersToKeep.isEmpty();
        final boolean hasAnyContent = hasAnyFolders || hasLooseAfterClear;

        updateFolderButtons();

        Intent saveIntent = new Intent(ACTION_SAVE_PLAYER_STATE_NOW);
        sendBroadcast(saveIntent);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MusicService.setPlayerStateBeforeUpdate(FolderManager.this, true);

                Button updateButton = (Button) findViewById(R.id.updateButton);
                Button importFolderButton = (Button) findViewById(R.id.importFolderButton);
                disableButton(updateButton);
                disableButton(importFolderButton);

                if (clearLooseTracks) {
                    SongDatabase.getInstance(FolderManager.this).clearLooseSongs();
                }

                for (String folderUriString : mPendingChanges.getFoldersToRemove()) {
                    mMusicLibrary.removeFolder(folderUriString);
                    // Drop the SAF permission mapping for this folder.
                    try {
                        StorageAccessHelper.getInstance(FolderManager.this)
                            .removeFolderPermission(Uri.parse(folderUriString));
                    } catch (Exception exception) {
                        Log.w(TAG, "Failed to drop SAF permission for " + folderUriString,
                            exception);
                    }
                }

                SharedPreferences preferences =
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                preferences.edit()
                    .putStringSet(KEY_SELECTED_FOLDERS_URIS, foldersToKeep)
                    .apply();

                if (!hasAnyContent) {
                    handleNoContentRemaining(preferences);
                    return;
                }

                if (!hasAnyFolders) {
                    handleNoFoldersRemaining(preferences);
                    return;
                }

                performPlaylistUpdate();
            }
        }, STATE_SAVE_DELAY_MS);
    }

    /**
     * Finalizes an update cycle that ran through
     * {@link PlaylistManager#updatePlaylist}.
     */
    private void updateComplete() {
        Intent updateIntent = new Intent(ACTION_UPDATE_PLAYLIST_FROM_FOLDERS);
        sendBroadcast(updateIntent);

        NavigationController.getInstance().endPlaylistSync();

        loadFolders();
        updateFolderButtons();
    }

    /**
     * Handles the case in which the user has removed every folder and
     * every loose track.
     *
     * <p>Any in-flight scan is cancelled, the database tables are cleared,
     * the persisted player state is cleared, the folder permission
     * mappings are dropped, transient cache files are swept, and the
     * reset broadcast is sent with {@code preserve_settings=false}.</p>
     *
     * <p>This method clears only the library- and session-scoped
     * preference keys listed below. It writes or removes no key owned by
     * {@link EqualizerManager} — {@code equalizer_enabled},
     * {@code selected_preset}, {@code eq_band_*}, {@code eq_custom_*},
     * {@code bass_boost_level}, {@code surround_level},
     * {@code pitch_level}, {@code speed_level}, and
     * {@code has_custom_*} — so adding folders back does not force the
     * user to reconfigure the equalizer.</p>
     *
     * <p>The keys this method owns are exactly:
     * {@code current_playing_index}, {@code current_position},
     * {@code last_playing}, {@code last_song_path}, and
     * {@code player_state_before_update}; plus, through
     * {@link StorageAccessHelper#clearAll()}, the {@code folder_uri_*},
     * {@code path_uri_*}, and {@code known_folder_uris} keys; and,
     * through the {@code RESET_PLAYER_STATE} receiver in
     * {@link MusicService}, the {@code repeat_mode}, {@code shuffle}, and
     * {@code playlist_sort_mode} keys.</p>
     *
     * <p>{@link MusicLibrary#invalidate()} runs in place of
     * {@code refreshCache()} so this instance drops its cached folder
     * set and re-reads it from preferences. Without that, a later scan
     * through this instance could rescan the folders that were just
     * removed.</p>
     *
     * @param preferences The shared preferences handle
     */
    private void handleNoContentRemaining(@NonNull SharedPreferences preferences) {
        // Abort any in-flight scan before touching the database. A scan
        // that is past its last flag check would otherwise reinsert the
        // songs this method is about to delete. The generation counter in
        // PlaylistManager ensures the abort is observed even in that
        // window.
        PlaylistManager.getInstance(this).cancelUpdate();

        SongDatabase database = SongDatabase.getInstance(this);
        database.clearCache();
        database.clearLooseSongs();

        StorageAccessHelper.getInstance(this).clearAll();

        preferences.edit()
            .putInt(KEY_CURRENT_PLAYING_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mMusicLibrary.invalidate();

        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);

        Intent resetIntent = new Intent(ACTION_RESET_PLAYER_STATE);
        // Full wipe: the service resets repeat mode, shuffle, and sort mode
        // alongside its own teardown.
        resetIntent.putExtra("preserve_settings", false);
        sendBroadcast(resetIntent);

        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);

        ToastManager.showPersistentOverlay(this, "Syncing playlist...");

        // Reload folders and clear pending changes BEFORE ending the sync.
        // The button-state callback fired by endPlaylistSync then sees the
        // post-update state (no folders, no pending removals) and leaves
        // the UPDATE button disabled without flickering through an
        // intermediate enabled state.
        loadFolders();

        NavigationController.getInstance().endPlaylistSync();

        cleanupTempCacheAsync();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();

                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    /**
     * Deletes leftover {@code temp_audio_*} and {@code backup_*} files
     * from the cache directory.
     *
     * <p>Runs on a short-lived background thread because it touches disk.
     * Failures are logged and ignored: a stale file is not a correctness
     * problem.</p>
     */
    private void cleanupTempCacheAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File cacheDir = getCacheDir();
                    if (cacheDir == null || !cacheDir.isDirectory()) {
                        return;
                    }
                    File[] files = cacheDir.listFiles();
                    if (files == null) {
                        return;
                    }
                    for (File file : files) {
                        if (file == null || !file.isFile()) {
                            continue;
                        }
                        String name = file.getName();
                        if (name.startsWith("temp_audio_") || name.startsWith("backup_")) {
                            if (file.delete()) {
                                Log.d(TAG, "Deleted stale temp file: " + name);
                            }
                        }
                    }
                } catch (Exception exception) {
                    Log.w(TAG, "cleanupTempCache failed", exception);
                }
            }
        }).start();
    }

    /**
     * Handles the case in which every folder has been removed while loose
     * tracks remain.
     *
     * <p>Any in-flight scan is cancelled, the songs table is rebuilt from
     * the remaining loose songs, the persisted player state is cleared,
     * and the playlist is asked to refresh.</p>
     *
     * <p>{@link MusicLibrary#invalidate()} runs in place of
     * {@code refreshCache()} so this instance drops its cached folder
     * set. Without that, this instance would still believe the removed
     * folders are selected and a later scan through it could re-add
     * songs from those folders.</p>
     *
     * @param preferences The shared preferences handle
     */
    private void handleNoFoldersRemaining(@NonNull SharedPreferences preferences) {
        // Same reasoning as handleNoContentRemaining: a scan in flight
        // against the removed folders must not repopulate the database
        // after this method clears it.
        PlaylistManager.getInstance(this).cancelUpdate();

        SongDatabase database = SongDatabase.getInstance(this);

        ArrayList<Song> looseSongs = database.getLooseSongs();

        database.clearCache();

        if (!looseSongs.isEmpty()) {
            database.insertSongsBatch(looseSongs);
        }

        preferences.edit()
            .putInt(KEY_CURRENT_PLAYING_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mMusicLibrary.invalidate();

        Intent stopServiceIntent = new Intent(this, MusicService.class);
        stopServiceIntent.setAction(ACTION_STOP);
        startService(stopServiceIntent);

        Intent refreshIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
        sendBroadcast(refreshIntent);

        Intent refreshDisplayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
        sendBroadcast(refreshDisplayIntent);

        ToastManager.showPersistentOverlay(this, "Syncing playlist...");

        // Same ordering rule as handleNoContentRemaining: reload folders and
        // clear pending changes before ending the sync.
        loadFolders();

        NavigationController.getInstance().endPlaylistSync();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay();
                updateFolderButtons();

                Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                sendBroadcast(syncCompleteIntent);
            }
        }, OVERLAY_HIDE_DELAY_MS);
    }

    /**
     * Runs a playlist update through {@link PlaylistManager} and drives
     * the folder-sync overlay from the scan's progress callbacks.
     */
    private void performPlaylistUpdate() {
        final boolean[] persistentShown = {false};

        PlaylistManager.getInstance(this).updatePlaylist(
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(final int current, final int total) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String progressMessage;
                        if (current == 0) {
                            progressMessage = "Searching folders...";
                        } else if (current < total) {
                            progressMessage = "Searching folders... " + current + " song"
                                + (current != 1 ? "s" : "") + " found";
                        } else {
                            progressMessage = "Syncing playlist... " + current + " song"
                                + (current != 1 ? "s" : "") + " found";
                        }

                        if (!persistentShown[0]) {
                            ToastManager.showPersistentOverlay(FolderManager.this,
                                progressMessage, OP_FOLDER_SYNC);
                            persistentShown[0] = true;
                        } else {
                            ToastManager.updatePersistentOverlay(
                                progressMessage, OP_FOLDER_SYNC);
                        }

                        Intent syncStartedIntent = new Intent(ACTION_SYNC_STARTED);
                        syncStartedIntent.putExtra("custom_text", progressMessage);
                        syncStartedIntent.putExtra("operation_id", OP_FOLDER_SYNC);
                        sendBroadcast(syncStartedIntent);
                    }
                });
            }

            @Override
            public void onComplete(final int songCount) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mPendingChanges.isClearLooseTracks()) {
                            Log.d(TAG, "User removed Loose Tracks - deleting loose songs");
                            SongDatabase database = SongDatabase.getInstance(FolderManager.this);
                            database.clearLooseSongs();
                            database.deleteSongsNotInSet(
                                mMusicLibrary.getSelectedFolders(), false);
                        }

                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);

                        // Hand off cleanly: hide this operation's overlay by
                        // its own ID, then let PlaylistManager show and own
                        // the "GENRE_UPDATE" overlay for the duration of
                        // genre loading.
                        ToastManager.hidePersistentOverlay(OP_FOLDER_SYNC);

                        triggerGenreUpdate();

                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                updateComplete();
                                updateFolderButtons();
                                loadFolders();
                                mGenreUpdateTriggered = false;
                            }
                        }, OVERLAY_HIDE_DELAY_MS);
                    }
                });
            }

            @Override
            public void onError(@NonNull final String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (persistentShown[0]) {
                            ToastManager.hidePersistentOverlay(OP_FOLDER_SYNC);
                        }

                        Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                        sendBroadcast(syncCompleteIntent);

                        NavigationController.getInstance().endPlaylistSync();

                        updateFolderButtons();
                        ToastManager.showToast(FolderManager.this, "Error: " + error,
                            ToastManager.LENGTH_NORMAL);
                    }
                });
            }
        });
    }

    /**
     * Asks {@link PlaylistManager} to begin genre loading.
     *
     * <p>{@link PlaylistManager} owns the {@code "GENRE_UPDATE"} overlay
     * for the entire lifetime of genre loading: it shows the overlay with
     * that operation ID, heartbeats it independently of the ID3 read
     * loop, and hides it by the same ID when the load completes. This
     * activity observes the {@code GENRE_UPDATE} broadcasts read-only for
     * its own progress reporting.</p>
     */
    private void triggerGenreUpdate() {
        if (mGenreUpdateTriggered) {
            Log.d(TAG, "Genre update already triggered, skipping");
            return;
        }
        mGenreUpdateTriggered = true;

        PlaylistManager playlistManager = PlaylistManager.getInstance(this);

        if (playlistManager.isGenreLoading()) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        playlistManager.triggerGenreLoading();
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================

    /**
     * Registers the receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();

                    if (mFolderAdapter != null) {
                        mFolderAdapter.refreshRemoveButtonStates();
                    }

                    ToastManager.refreshThemeColor();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for loose-track update broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerLooseTracksReceiver() {
        mLooseTracksUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_LOOSE_TRACKS_UPDATED.equals(intent.getAction())) {
                    loadFolders();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_LOOSE_TRACKS_UPDATED);
        ContextCompat.registerReceiver(
            this, mLooseTracksUpdateReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for sync-complete broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SYNC_COMPLETE.equals(intent.getAction())) {
                    Log.d(TAG, "Sync complete - refreshing MusicLibrary cache");
                    if (mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                    }
                    loadFolders();
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_SYNC_COMPLETE);
        ContextCompat.registerReceiver(
            this, mSyncCompleteReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised by the
     * framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception ignored) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}