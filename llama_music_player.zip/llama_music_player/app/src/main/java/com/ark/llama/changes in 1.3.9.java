Implementation of Task Blocks

All changes below preserve existing behavior and documentation outside the modified regions.

---

Block 1 — MetadataEditor.java

1a. Augment identity in the SAF picker result

In onActivityResult, inside if (requestCode == REQUEST_SAF_FILE_PICKER) → if (selectedUri != null), replace:

```java
                    mGrantedFileUri = selectedUri;

                    // The picker selection replaces the complete target.
                    // A null path is valid for SAF and must clear any old path.
                    mFilePath = getFilePathFromUri(selectedUri);
```

with:

```java
                    mGrantedFileUri = selectedUri;

                    // Augment identity. The picker result adds the URI; a
                    // resolved path refines the path but never removes one the
                    // caller already supplied. The URI is authoritative for
                    // writing; the path is authoritative for matching receivers.
                    final String resolvedPath =
                        getFilePathFromUri(selectedUri);
                    if (resolvedPath != null) {
                        mFilePath = resolvedPath;
                    }
```

1b. Freeze the submission in performSaveChanges

Replace the tail of performSaveChanges (from mIsSaving.set(true); through the closing }); of the executor block):

```java
        mIsSaving.set(true);
        setActionButtonEnabled(false);

        if (mExecutor == null || mExecutor.isShutdown()) {
            mIsSaving.set(false);
            setActionButtonEnabled(true);
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_no_write_permission),
                ToastManager.LENGTH_NORMAL);
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataWriter.WriteResult result =
                    MetadataWriter.writeMetadataToUri(
                        MetadataEditor.this, targetUri, update);
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay();
                        mIsSaving.set(false);
                        setActionButtonEnabled(true);
                        if (result.isSuccess()) {
                            onSaveSuccess(targetUri, targetPath,
                                albumArtWasDeleted);
                        } else {
                            onSaveFailure(result, targetPath);
                        }
                    }
                });
            }
        });
```

with:

```java
        final MetadataReader.MetadataBundle preEditBundle = mOriginalData;
        final MetadataWriter.UpdateBundle submittedUpdate = update;

        mIsSaving.set(true);
        setActionButtonEnabled(false);

        if (mExecutor == null || mExecutor.isShutdown()) {
            mIsSaving.set(false);
            setActionButtonEnabled(true);
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_no_write_permission),
                ToastManager.LENGTH_NORMAL);
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataWriter.WriteResult result =
                    MetadataWriter.writeMetadataToUri(
                        MetadataEditor.this, targetUri, submittedUpdate);
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay();
                        mIsSaving.set(false);
                        setActionButtonEnabled(true);
                        if (result.isSuccess()) {
                            onSaveSuccess(targetUri, targetPath,
                                albumArtWasDeleted, preEditBundle,
                                submittedUpdate);
                        } else {
                            onSaveFailure(result, targetPath);
                        }
                    }
                });
            }
        });
```

1c. Replace onSaveSuccess entirely

Replace the whole method (javadoc + signature + body) with:

```java
    /**
     * Handles a successful write: verifies the new metadata,
     * evicts the shared album-art caches, persists the merged
     * song, announces the change, and resumes playback when
     * applicable.
     *
     * <p>The broadcast is built from the submitted update
     * overlaid on the pre-edit bundle. The post-write re-read is
     * verification only: when it fails, the submitted values are
     * announced anyway, because the write itself succeeded. A
     * re-read can therefore never suppress the broadcast.</p>
     *
     * <p>The shared album-art cache is evicted for both the path
     * and the URI before the broadcast, so every consumer sees
     * the fresh art as soon as the broadcast lands.</p>
     *
     * <p>The placeholder fallbacks for title, artist, album, and
     * genre in the database write resolve through
     * {@link CharacterMapper}'s producers.</p>
     *
     * @param savedUri URI the write targeted
     * @param savedPath Path the write targeted, or null
     * @param albumArtWasDeleted True when the edit removed the art
     * @param preEditBundle Bundle as loaded before the edit
     * @param submittedUpdate Changes the user submitted
     */
    private void onSaveSuccess(@NonNull Uri savedUri,
            @Nullable String savedPath, boolean albumArtWasDeleted,
            @Nullable MetadataReader.MetadataBundle preEditBundle,
            @NonNull MetadataWriter.UpdateBundle submittedUpdate) {

        // The write succeeded. The announcement is built from the
        // submitted update overlaid on the pre-edit bundle. A
        // re-read is verification only; it cannot suppress the
        // broadcast.
        final MetadataReader.MetadataBundle announcement =
            buildAnnouncementFromSubmitted(
                preEditBundle, submittedUpdate);

        MetadataReader.MetadataBundle verified = null;
        try {
            verified = MetadataReader.readMetadataFromUri(
                this, savedUri);
        } catch (Exception exception) {
            Log.w(TAG, "Post-save re-read failed", exception);
        }
        final boolean verifiedOk = verified != null
            && verified.status
                == MetadataReader.MetadataBundle.Status.SUCCESS;

        if (!verifiedOk) {
            Log.w(TAG, "Post-save verification did not succeed; "
                + "announcing submitted values");
        }

        mOriginalData = verifiedOk ? verified : announcement;

        // Evict the shared album-art cache once, before the
        // broadcast, for both identifiers. Every consumer sees
        // the eviction the moment the broadcast lands.
        evictAlbumArtCaches(savedPath, savedUri);

        // Persist the merged song.
        final MetadataReader.MetadataBundle persistedForDb =
            verifiedOk ? verified : announcement;
        final String dbPath = (savedPath != null)
            ? savedPath
            : getFilePathFromUri(savedUri);
        if (dbPath != null) {
            Song updatedSong = new Song(
                persistedForDb.title != null
                    ? persistedForDb.title
                    : CharacterMapper.getUnknownTitle(),
                persistedForDb.artist != null
                    ? persistedForDb.artist
                    : CharacterMapper.getUnknownArtist(),
                persistedForDb.album != null
                    ? persistedForDb.album
                    : CharacterMapper.getUnknownAlbum(),
                persistedForDb.genre != null
                    ? persistedForDb.genre
                    : CharacterMapper.getUnknownGenre(),
                dbPath,
                persistedForDb.duration,
                savedUri.toString());
            SongDatabase.getInstance(this).insertSong(updatedSong);
        }

        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;

        exitEditMode();

        // Always announce. The URI is always present; the path
        // is present when the editor knows it.
        final String broadcastPath = (savedPath != null)
            ? savedPath
            : getFilePathFromUri(savedUri);
        final Intent updateIntent =
            new Intent(ACTION_METADATA_UPDATED);
        if (broadcastPath != null) {
            updateIntent.putExtra("song_path", broadcastPath);
        }
        updateIntent.putExtra("song_uri", savedUri.toString());
        updateIntent.putExtra("title", announcement.title);
        updateIntent.putExtra("artist", announcement.artist);
        updateIntent.putExtra("album", announcement.album);
        updateIntent.putExtra("genre", announcement.genre);

        final boolean hasArt = announcement.hasAlbumArt();
        updateIntent.putExtra("has_album_art", hasArt);
        updateIntent.putExtra("album_art_removed",
            albumArtWasDeleted && !hasArt);
        if (hasArt && announcement.albumArt != null) {
            updateIntent.putExtra("album_art_bytes",
                announcement.albumArt);
        }
        sendBroadcast(updateIntent);

        if (mPreviousSongState == SONG_STATE_WAS_PLAYING) {
            new Handler(Looper.getMainLooper()).postDelayed(
                new Runnable() {
                @Override
                public void run() {
                    sendBroadcast(new Intent(ACTION_BLUETOOTH_PLAY));
                }
            }, RESUME_PLAYBACK_DELAY_MS);
        }

        applyThemeToUI();

        ToastManager.showToast(this,
            getString(R.string.metadata_toast_updated),
            ToastManager.LENGTH_NORMAL);
    }
```

1d. Add two helpers after onSaveFailure

Insert immediately after the closing brace of onSaveFailure:

```java
    /**
     * Builds the announcement bundle for a successful write by
     * overlaying the submitted changes on the pre-edit bundle.
     *
     * <p>The broadcast announces what the writer was asked to
     * write, not what a subsequent read happens to return. A
     * re-read is verification only; when it fails, the submitted
     * values are still the ones the user chose, and they are the
     * ones the broadcast carries.</p>
     *
     * <p>Fields not present in the update inherit the pre-edit
     * value. A null {@code albumArt} in the update means
     * "unchanged"; a zero-length {@code albumArt} array means
     * "removed" and becomes a null album art on the bundle.</p>
     *
     * @param preEdit Bundle as loaded before the edit, or null
     * @param update Changes submitted by the user
     * @return The announcement bundle
     */
    @NonNull
    private MetadataReader.MetadataBundle buildAnnouncementFromSubmitted(
            @Nullable MetadataReader.MetadataBundle preEdit,
            @NonNull MetadataWriter.UpdateBundle update) {
        final MetadataReader.MetadataBundle out =
            new MetadataReader.MetadataBundle();
        out.status = MetadataReader.MetadataBundle.Status.SUCCESS;

        if (preEdit != null) {
            out.title = preEdit.title;
            out.artist = preEdit.artist;
            out.album = preEdit.album;
            out.year = preEdit.year;
            out.genre = preEdit.genre;
            out.trackNumber = preEdit.trackNumber;
            out.lyrics = preEdit.lyrics;
            out.albumArt = preEdit.albumArt;
            out.format = preEdit.format;
            out.duration = preEdit.duration;
            out.fileSize = preEdit.fileSize;
            out.isWriteSupported = preEdit.isWriteSupported;
        }

        if (update.title != null) out.title = update.title;
        if (update.artist != null) out.artist = update.artist;
        if (update.album != null) out.album = update.album;
        if (update.year != null) out.year = update.year;
        if (update.genre != null) out.genre = update.genre;
        if (update.trackNumber != null) out.trackNumber =
            update.trackNumber;
        if (update.lyrics != null) out.lyrics = update.lyrics;
        if (update.albumArt != null) {
            out.albumArt = update.albumArt.length == 0
                ? null
                : update.albumArt;
        }
        return out;
    }

    /**
     * Evicts the shared album-art cache for the given path and URI.
     *
     * <p>The shared cache is keyed by path in some consumers and
     * by URI in others; evicting both keys before the broadcast
     * lets every consumer see the fresh art as soon as the
     * broadcast lands, regardless of which key it uses.</p>
     *
     * @param path Song path, or null when the editor does not
     *        know one
     * @param uri Song URI
     */
    private void evictAlbumArtCaches(@Nullable String path,
                                     @NonNull Uri uri) {
        android.util.LruCache<String, Bitmap> cache =
            AlbumArtCache.getInstance(this).asLruCache();
        if (cache == null) {
            return;
        }
        if (path != null) {
            cache.remove(path);
        }
        cache.remove(uri.toString());
    }
```

---

Block 2 — MusicPlayer.java

2a. Replace mMetadataUpdatedReceiver.onReceive

Replace the whole onReceive method of mMetadataUpdatedReceiver with:

```java
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist = intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final String uriString =
                    intent.getStringExtra("song_uri");
                final boolean hasAlbumArt =
                    intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved =
                    intent.getBooleanExtra(
                        "album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                // The service updates every playlist entry with
                // this path, evicts and repopulates the shared
                // album-art cache, and broadcasts UPDATE_PLAYER.
                mMusicService.refreshMetadataForSong(
                    songPath, title, artist, album, genre,
                    uriString, albumArtBytes, albumArtRemoved);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                // Invalidate the carousel's per-path cache so a
                // neighbour slot showing the edited song resolves
                // fresh art on its next re-render.
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.invalidatePath(songPath);
                }

                // If the edited song is not current, the UI does
                // not need to change here — a different song is on
                // screen. Ask the playlist to redraw the edited
                // row.
                final Song currentSong =
                    mMusicService.getCurrentSong();
                final boolean editedIsCurrent = currentSong != null
                    && songPath.equals(currentSong.getPath());
                if (!editedIsCurrent) {
                    sendBroadcast(
                        new Intent(ACTION_DISPLAY_PLAYLIST));
                }
            }
```

2b. Add resolveBroadcastSongPath

Add as a new private method (near the other broadcast helpers):

```java
    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the
     * editor knows it. When the editor only knows the URI — a
     * SAF-only write where the content provider does not expose a
     * filesystem path — the path is resolved against the song
     * database by URI match. Both forms name the same song; the
     * resolution keeps consumers that key by path working on
     * paths.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }
```

---

Block 3 — PlaylistActivity.java

3a. Replace mMetadataUpdatedReceiver.onReceive

Replace the whole onReceive method of mMetadataUpdatedReceiver with:

```java
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null || mAdapter == null) {
                    return;
                }

                final int displayPosition =
                    findPositionByPath(songPath);
                if (displayPosition >= 0) {
                    final Song existing =
                        mCurrentDisplayList.get(displayPosition);
                    if (existing != null) {
                        final String title =
                            intent.getStringExtra("title");
                        final String artist =
                            intent.getStringExtra("artist");
                        final String album =
                            intent.getStringExtra("album");
                        final String genre =
                            intent.getStringExtra("genre");
                        final String uriString =
                            intent.getStringExtra("song_uri");

                        final Song updated = new Song(
                            title != null ? title : null,
                            artist != null ? artist : null,
                            album != null ? album : null,
                            genre != null ? genre : null,
                            songPath,
                            existing.getDuration(),
                            uriString != null
                                ? uriString
                                : existing.getUri());
                        mCurrentDisplayList.set(
                            displayPosition, updated);
                        mAdapter.notifyItemChanged(
                            displayPosition);
                    }
                }

                if (songPath.equals(mCurrentPlayingPath)) {
                    mCurrentPlayingPath = songPath;
                    mAdapter.setCurrentPlayingIndex(
                        displayPosition);
                }
            }
```

3b. Add resolveBroadcastSongPath

Add as a new private method (near the other helper methods):

```java
    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the
     * editor knows it. When the editor only knows the URI — a
     * SAF-only write where the content provider does not expose
     * a filesystem path — the path is resolved against the song
     * database by URI match. Both forms name the same song; the
     * resolution keeps consumers that key by path working on
     * paths.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }
```

---

Block 4 — MusicService.java

4a. Add the broadcast-action constant

Alongside the existing ACTION_* constants (ACTION_GENRE_UPDATE, ACTION_SET_PENDING_SONG, etc.):

```java
    /** Broadcast action announcing that a song's metadata was written. */
    private static final String ACTION_METADATA_UPDATED =
        "METADATA_UPDATED";
```

4b. Add the receiver field

Alongside the other receiver fields (near mGenreUpdateReceiver):

```java
    /** Receiver for {@code METADATA_UPDATED} broadcasts. */
    @Nullable
    private BroadcastReceiver mMetadataUpdatedReceiver;
```

4c. Register in onCreate

Immediately after registerGenreUpdateReceiver();:

```java
        registerGenreUpdateReceiver();
        registerMetadataUpdatedReceiver();
```

4d. Unregister in onDestroy

Immediately after unregisterReceiverSafely(mGenreUpdateReceiver);:

```java
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
```

4e. Add registerMetadataUpdatedReceiver and resolveBroadcastSongPath

Insert these two methods near registerGenreUpdateReceiver():

```java
    /**
     * Registers the receiver for {@code METADATA_UPDATED}
     * broadcasts.
     *
     * <p>Registered in {@link #onCreate()} and unregistered in
     * {@link #onDestroy()}, so the edit lands on the in-memory
     * playlist for the service's whole lifetime — including the
     * case where the player activity has been reclaimed but
     * playback continues. The receiver reads the URI fallback
     * through {@link #resolveBroadcastSongPath(Intent)} so a
     * SAF-only write, where the editor does not know a path,
     * still lands on the row keyed by path.</p>
     */
    private void registerMetadataUpdatedReceiver() {
        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null) {
                    return;
                }

                final String title =
                    intent.getStringExtra("title");
                final String artist =
                    intent.getStringExtra("artist");
                final String album =
                    intent.getStringExtra("album");
                final String genre =
                    intent.getStringExtra("genre");
                final String uriString =
                    intent.getStringExtra("song_uri");
                final boolean albumArtRemoved =
                    intent.getBooleanExtra(
                        "album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                refreshMetadataForSong(songPath, title, artist,
                    album, genre, uriString, albumArtBytes,
                    albumArtRemoved);
            }
        };
        registerReceiverSafely(mMetadataUpdatedReceiver,
            new IntentFilter(ACTION_METADATA_UPDATED));
    }

    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the
     * editor knows it. When the editor only knows the URI — a
     * SAF-only write where the content provider does not expose
     * a filesystem path — the path is resolved against the song
     * database by URI match. Both forms name the same song; the
     * resolution keeps consumers that key by path working on
     * paths.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }
```

4f. Replace refreshMetadataForSong

Replace the whole method (javadoc + signature + body):

```java
    /**
     * Refreshes every playlist entry that carries the given path
     * from a change published by {@link MetadataEditor}.
     *
     * <p>Every entry whose path matches is updated, not only the
     * current index. Duplicate paths exist after a loose-track
     * insert that overlapped a scan; every copy must receive the
     * new values so whichever copy the service later selects
     * shows the correct metadata.</p>
     *
     * <p>The shared album-art cache is keyed by path in some
     * consumers and by URI in others. Both keys are evicted, then
     * the resolved art is stored under both keys, so every
     * consumer reads the new art on its next access.</p>
     *
     * <p>The change is announced unconditionally through
     * {@link #broadcastUpdate()}, which dispatches
     * {@code UPDATE_PLAYER} and commits the notification through
     * {@link NotificationController#commitFromBroadcast(long,
     * NotificationController.RenderSnapshot)} on the same
     * main-thread turn. Whether the edited song is current or
     * not, the announcement fires; the player UI, the carousel,
     * the notification, and the media session all adopt the new
     * state together.</p>
     *
     * @param songPath Path of the edited song
     * @param newTitle New title, or null for no change
     * @param newArtist New artist, or null for no change
     * @param newAlbum New album, or null for no change
     * @param newGenre New genre, or null for no change
     * @param uriString New URI string, or null for no change
     * @param albumArtBytes New album art bytes, or null for no
     *        change
     * @param albumArtRemoved True when the album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable String uriString,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            // 1. Update every playlist entry whose path matches,
            //    not only the current index. Duplicate paths
            //    exist after a loose-track insert that overlapped
            //    a scan.
            boolean playlistChanged = false;
            String resolvedUri = (uriString != null
                && !uriString.isEmpty()) ? uriString : null;
            String knownTitle = newTitle;
            String knownArtist = newArtist;
            String knownAlbum = newAlbum;
            String knownGenre = newGenre;
            long knownDuration = 0L;

            if (mCurrentPlaylist != null) {
                for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                    Song song = mCurrentPlaylist.get(i);
                    if (song == null
                            || !songPath.equals(song.getPath())) {
                        continue;
                    }
                    if (knownTitle == null) {
                        knownTitle = song.getTitle();
                    }
                    if (knownArtist == null) {
                        knownArtist = song.getArtist();
                    }
                    if (knownAlbum == null) {
                        knownAlbum = song.getAlbum();
                    }
                    if (knownGenre == null) {
                        knownGenre = song.getGenre();
                    }
                    if (resolvedUri == null) {
                        resolvedUri = song.getUri();
                    }
                    if (knownDuration == 0L) {
                        knownDuration = song.getDuration();
                    }

                    Song updated = new Song(
                        newTitle != null && !newTitle.isEmpty()
                            ? newTitle : song.getTitle(),
                        newArtist != null && !newArtist.isEmpty()
                            ? newArtist : song.getArtist(),
                        newAlbum != null && !newAlbum.isEmpty()
                            ? newAlbum : song.getAlbum(),
                        newGenre != null && !newGenre.isEmpty()
                            ? newGenre : song.getGenre(),
                        songPath,
                        song.getDuration(),
                        resolvedUri != null
                            ? resolvedUri : song.getUri());
                    mCurrentPlaylist.set(i, updated);
                    playlistChanged = true;
                }
            }

            // 2. Persist regardless of whether the path was
            //    current.
            if (playlistChanged) {
                Song persisted = new Song(
                    knownTitle != null ? knownTitle
                        : CharacterMapper.getUnknownTitle(),
                    knownArtist != null ? knownArtist
                        : CharacterMapper.getUnknownArtist(),
                    knownAlbum != null ? knownAlbum
                        : CharacterMapper.getUnknownAlbum(),
                    knownGenre != null ? knownGenre
                        : CharacterMapper.getUnknownGenre(),
                    songPath, knownDuration, resolvedUri);
                SongDatabase.getInstance(this).insertSong(persisted);
            }

            // 3. Evict the SHARED album-art cache under both
            //    keys, then repopulate with the new bytes. The
            //    carousel and the notification both read this
            //    shared cache.
            android.util.LruCache<String, Bitmap> sharedCache =
                AlbumArtCache.getInstance(this).asLruCache();
            if (sharedCache != null) {
                sharedCache.remove(songPath);
                if (resolvedUri != null) {
                    sharedCache.remove(resolvedUri);
                }
            }
            if (mArtCache != null) {
                mArtCache.remove(songPath);
            }

            Bitmap newArt = null;
            if (albumArtRemoved) {
                mResolvedArtPath = songPath;
                mResolvedArt = null;
                if (mCurrentArtLoad != null) {
                    mCurrentArtLoad.cancel(true);
                    mCurrentArtLoad = null;
                }
            } else if (albumArtBytes != null) {
                newArt = BitmapFactory.decodeByteArray(
                    albumArtBytes, 0, albumArtBytes.length);
                if (newArt != null) {
                    if (sharedCache != null) {
                        sharedCache.put(songPath, newArt);
                    }
                    if (mArtCache != null) {
                        mArtCache.put(songPath, newArt);
                    }
                    mResolvedArtPath = songPath;
                    mResolvedArt = newArt;
                }
            }

            // 4. Re-announce unconditionally.
            //    broadcastUpdate() dispatches UPDATE_PLAYER and
            //    commits the notification through
            //    commitFromBroadcast on the same turn, so the
            //    player UI, carousel, notification, and
            //    MediaSession all adopt the new state together.
            broadcastUpdate();
        });
    }
```

---

Block 5 — Integration checklist

After applying Blocks 1–4:

1. Compile. The two signature changes — onSaveSuccess arity (Block 1c, called only from Block 1b) and refreshMetadataForSong arity (Block 4f, called from Block 2a and Block 4e) — are both covered by the blocks above. No other callers exist in the supplied sources.
2. Current-song edit. Play a song, open the metadata editor from the player, change title and album art, save. On the next frame: player title, artist, carousel art, notification title, notification large icon, and MediaSession all show the new values. The playlist row also shows the new title.
3. Non-current edit. Play song A, skip to song B, edit song B's title, skip back to song A. The player and notification show song A (correct — it is current). Open the playlist: song B's row shows the new title. Skip to song B: the player and notification show its new title and art.
4. Service-alive, activity-dead edit. Back out of the player to the launcher while playback continues. Open the metadata editor from the notification's content intent → app → metadata editor. Edit and save. The notification still updates, because MusicService's own METADATA_UPDATED receiver drives the change — no activity needed.
5. SAF re-authorisation edit. Force the URI permission to lapse, tap MODIFY, re-pick the file, edit, save. The player title, carousel art, and notification all update. Before this set of blocks, this case suppressed the broadcast entirely.

Two diagnostic notes if a case fails:

· Case 5 fails → Block 1a — mFilePath assignment in the picker result must not clear an existing path when the URI cannot be resolved to one.
· Case 4 fails → Block 4c — registerMetadataUpdatedReceiver() must be inside onCreate, not only inside onBind.