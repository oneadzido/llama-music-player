package com.ark.llama;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Native Android MediaPlayer wrapper with proper lifecycle management and equalizer support.
 * 
 * <p>This class encapsulates the native MediaPlayer and serves as the fallback player
 * when LlamaPlayer (SoundTouch) fails at runtime. It provides:</p>
 * 
 * <ul>
 *   <li>Complete state machine following MediaPlayer conventions</li>
 *   <li>Audio session ID for equalizer attachment</li>
 *   <li>Built-in position polling for UI updates</li>
 *   <li>Volume control for audio ducking</li>
 *   <li>Thread-safe operations with proper synchronization</li>
 *   <li>Comprehensive error handling and recovery</li>
 * </ul>
 * 
 * <h3>State Machine</h3>
 * <pre>
 * IDLE ── setDataSource() ──► INITIALIZED ── prepareAsync() ──► PREPARING
 *                                                              │
 *                                                              │ onPrepared()
 *                                                              ▼
 *                                                        PREPARED
 *                                                              │
 *                                                              │ start()
 *                                                              ▼
 *                                                         STARTED
 *                                        ┌───────┴───────┐
 *                                        │                                          │
 *                                    pause()                            completion()
 *                                        │                                          │
 *                                        ▼                                        ▼
 *                                    PAUSED                            COMPLETED
 *                                        │                                          │
 *                                        └───────┬───────┘
 *                                                              │
 *                                                   stop() / reset()
 *                                                              │
 *                                                             ▼
 *                                                  IDLE / STOPPED
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class NativeMediaPlayer implements MediaPlayer.OnPreparedListener,
                                          MediaPlayer.OnCompletionListener,
                                          MediaPlayer.OnErrorListener,
                                          MediaPlayer.OnSeekCompleteListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "NativeMediaPlayer";
    
    /** Position polling interval in milliseconds (150ms = ~6-7 fps). */
    private static final int POLLING_INTERVAL_MS = 150;
    
    /** Volume for ducking (30% of normal). */
    private static final float DUCK_VOLUME = 0.3f;
    
    /** Normal volume (100%). */
    private static final float NORMAL_VOLUME = 1.0f;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Player state machine following MediaPlayer conventions.
     */
    public enum State {
        /** Initial state after creation or reset. */
        IDLE,
        
        /** Data source has been set. */
        INITIALIZED,
        
        /** Preparing asynchronously. */
        PREPARING,
        
        /** Ready for playback. */
        PREPARED,
        
        /** Actively playing. */
        STARTED,
        
        /** Paused, can resume. */
        PAUSED,
        
        /** Stopped, need to prepare again. */
        STOPPED,
        
        /** End of stream reached. */
        COMPLETED,
        
        /** Error occurred. */
        ERROR,
        
        /** Resources released. */
        RELEASED
    }
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener for native player events.
     * All callbacks are delivered on the main UI thread.
     */
    public interface NativePlayerListener {
        
        /**
         * Called when the player is prepared and ready for playback.
         */
        void onPrepared();
        
        /**
         * Called when playback completes (end of stream reached).
         */
        void onCompletion();
        
        /**
         * Called when an error occurs.
         *
         * @param what The error code from MediaPlayer
         * @param extra Extra error code
         * @param message Human-readable error message
         */
        void onError(int what, int extra, @NonNull String message);
        
        /**
         * Called periodically with position updates.
         *
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration in milliseconds
         */
        void onPositionUpdate(int positionMs, int durationMs);
        
        /**
         * Called when player state changes.
         *
         * @param newState The new state
         * @param oldState The previous state
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when audio session ID is available (for equalizer attachment).
         *
         * @param sessionId The audio session ID
         */
        void onAudioSessionIdAvailable(int sessionId);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    @NonNull
    private final Context mContext;
    
    /** Native MediaPlayer instance. */
    @Nullable
    private MediaPlayer mMediaPlayer;
    
    /** Current player state. */
    @NonNull
    private State mState = State.IDLE;
    
    /** Lock for state changes. */
    @NonNull
    private final Object mStateLock = new Object();
    
    /** Event listener. */
    @Nullable
    private NativePlayerListener mListener;
    
    /** Current data source (file path). */
    @Nullable
    private String mDataSource;
    
    /** Audio session ID for equalizer. */
    private int mAudioSessionId = 0;
    
    /** Flag indicating if player is prepared. */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if player is playing. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if end of stream reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Current duration in milliseconds. */
    private volatile int mDuration = 0;
    
    /** Current position in milliseconds. */
    private volatile int mCurrentPosition = 0;
    
    /** Handler for main thread operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for position polling. */
    @Nullable
    private Handler mPollingHandler;
    
    /** Runnable for position polling. */
    @Nullable
    private Runnable mPollingRunnable;
    
    /** Flag indicating if polling is active. */
    private final AtomicBoolean mIsPolling = new AtomicBoolean(false);
    
    /** Pending seek position (-1 if none). */
    private volatile int mPendingSeek = -1;
    
    /** Current volume level. */
    private float mCurrentVolume = NORMAL_VOLUME;
    
    /** Normal volume saved for unduck. */
    private float mNormalVolume = NORMAL_VOLUME;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new NativeMediaPlayer.
     *
     * @param context Application context
     */
    public NativeMediaPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "NativeMediaPlayer created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the event listener.
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable NativePlayerListener listener) {
        mListener = listener;
    }
    
    /**
     * Sets the data source for playback.
     *
     * @param filePath Absolute path to the audio file
     * @throws IllegalStateException if called in invalid state
     * @throws IllegalArgumentException if filePath is null or empty
     */
    public void setDataSource(@NonNull String filePath) {
        if (filePath.isEmpty()) {
            throw new IllegalArgumentException("filePath cannot be empty");
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("setDataSource called on released player");
            }
            
            if (mState != State.IDLE && mState != State.STOPPED && mState != State.ERROR) {
                Log.w(TAG, "setDataSource called in state " + mState + ", resetting first");
                resetInternal(false);
            }
            
            mDataSource = filePath;
            mIsPrepared.set(false);
            mIsPlaying.set(false);
            mIsEOS.set(false);
            mDuration = 0;
            mCurrentPosition = 0;
            mPendingSeek = -1;
            mAudioSessionId = 0;
            
            setState(State.INITIALIZED);
            Log.d(TAG, "setDataSource: " + filePath);
        }
    }
    
    /**
     * Prepares the player asynchronously.
     *
     * @throws IllegalStateException if called in invalid state
     */
    public void prepareAsync() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("prepareAsync called on released player");
            }
            
            if (mState != State.INITIALIZED && mState != State.STOPPED) {
                throw new IllegalStateException("prepareAsync called in invalid state: " + mState);
            }
            
            setState(State.PREPARING);
        }
        
        // Start preparation on background thread
        new Thread(this::prepareInternal, "NativeMediaPlayer-Prepare").start();
    }
    
    /**
     * Starts or resumes playback.
     *
     * @throws IllegalStateException if called in invalid state
     */
    public void start() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("start called on released player");
            }
            
            if (mState == State.PREPARED || mState == State.PAUSED || mState == State.COMPLETED) {
                if (mMediaPlayer != null && mIsPrepared.get()) {
                    try {
                        if (mState == State.COMPLETED) {
                            mMediaPlayer.seekTo(0);
                        }
                        mMediaPlayer.start();
                        mIsPlaying.set(true);
                        setState(State.STARTED);
                        startPositionPolling();
                        Log.d(TAG, "start() - playback started");
                    } catch (Exception e) {
                        Log.e(TAG, "start() error", e);
                        notifyError(0, 0, "Failed to start: " + e.getMessage());
                    }
                } else {
                    Log.w(TAG, "start() called but player not prepared");
                }
            } else if (mState == State.STARTED) {
                Log.d(TAG, "start() called while already started, ignoring");
            } else {
                Log.w(TAG, "start() called in invalid state: " + mState);
            }
        }
    }
    
    /**
     * Pauses playback.
     *
     * @throws IllegalStateException if called in invalid state
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("pause called on released player");
            }
            
            if (mState == State.STARTED) {
                if (mMediaPlayer != null && mIsPrepared.get()) {
                    try {
                        mMediaPlayer.pause();
                        mIsPlaying.set(false);
                        setState(State.PAUSED);
                        stopPositionPolling();
                        Log.d(TAG, "pause() - playback paused");
                    } catch (Exception e) {
                        Log.e(TAG, "pause() error", e);
                    }
                }
            } else {
                Log.w(TAG, "pause() called in state: " + mState + ", ignoring");
            }
        }
    }
    
    /**
     * Stops playback and resets to STOPPED state.
     *
     * @throws IllegalStateException if called in invalid state
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("stop called on released player");
            }
            
            Log.d(TAG, "stop() called from state: " + mState);
            
            stopPositionPolling();
            
            if (mMediaPlayer != null && mIsPrepared.get()) {
                try {
                    mMediaPlayer.stop();
                } catch (Exception e) {
                    Log.e(TAG, "stop() error", e);
                }
            }
            
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            setState(State.STOPPED);
        }
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param positionMs Position in milliseconds (clamped to 0-duration)
     */
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.e(TAG, "seekTo called on released player");
                return;
            }
            
            int clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mPendingSeek = clampedPosition;
            
            if (mMediaPlayer != null && mIsPrepared.get()) {
                try {
                    mMediaPlayer.seekTo(clampedPosition);
                    Log.d(TAG, "seekTo: " + clampedPosition + "ms");
                } catch (Exception e) {
                    Log.e(TAG, "seekTo error", e);
                }
            } else {
                Log.d(TAG, "seekTo: pending seek " + clampedPosition + "ms (player not ready)");
            }
        }
    }
    
    /**
     * Returns the current playback position.
     *
     * @return Position in milliseconds, or 0 if not available
     */
    public int getCurrentPosition() {
        if (mMediaPlayer != null && mIsPrepared.get()) {
            try {
                return mMediaPlayer.getCurrentPosition();
            } catch (Exception e) {
                Log.w(TAG, "getCurrentPosition error", e);
            }
        }
        return mCurrentPosition;
    }
    
    /**
     * Returns the total duration.
     *
     * @return Duration in milliseconds, or 0 if not available
     */
    public int getDuration() {
        if (mMediaPlayer != null && mIsPrepared.get()) {
            try {
                return mMediaPlayer.getDuration();
            } catch (Exception e) {
                Log.w(TAG, "getDuration error", e);
            }
        }
        return mDuration;
    }
    
    /**
     * Checks if the player is currently playing.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mMediaPlayer != null && mIsPrepared.get()) {
            try {
                return mMediaPlayer.isPlaying();
            } catch (Exception e) {
                return false;
            }
        }
        return mIsPlaying.get() && mState == State.STARTED;
    }
    
    /**
     * Checks if the player is prepared for playback.
     *
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get() && (mState == State.PREPARED || 
               mState == State.STARTED || mState == State.PAUSED);
    }
    
    /**
     * Checks if end of stream has been reached.
     *
     * @return True if EOS
     */
    public boolean isEOS() {
        return mIsEOS.get();
    }
    
    /**
     * Returns the current player state.
     *
     * @return Current state
     */
    @NonNull
    public State getState() {
        return mState;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Resets the player to IDLE state.
     */
    public void reset() {
        resetInternal(true);
    }
    
    /**
     * Releases all resources held by the player.
     * After release, the player cannot be used again.
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release() called");
            
            stopPositionPolling();
            
            if (mMediaPlayer != null) {
                try {
                    mMediaPlayer.stop();
                    mMediaPlayer.release();
                } catch (Exception e) {
                    Log.e(TAG, "release error", e);
                }
                mMediaPlayer = null;
            }
            
            mIsPrepared.set(false);
            mIsPlaying.set(false);
            mIsEOS.set(false);
            mDuration = 0;
            mAudioSessionId = 0;
            
            setState(State.RELEASED);
            Log.d(TAG, "NativeMediaPlayer released");
        }
    }
    
    /**
     * Sets the volume level for both channels.
     *
     * @param volume Volume level (0.0 to 1.0)
     */
    public void setVolume(float volume) {
        mCurrentVolume = Math.max(0.0f, Math.min(1.0f, volume));
        
        if (mMediaPlayer != null && mIsPrepared.get()) {
            try {
                mMediaPlayer.setVolume(mCurrentVolume, mCurrentVolume);
                Log.d(TAG, "Volume set to: " + mCurrentVolume);
            } catch (Exception e) {
                Log.e(TAG, "setVolume error", e);
            }
        }
    }
    
    /**
     * Ducks volume (reduces to 30%) for transient audio focus loss.
     * Saves current volume for later restoration via {@link #unduck()}.
     */
    public void duck() {
        mNormalVolume = mCurrentVolume;
        setVolume(DUCK_VOLUME);
        Log.d(TAG, "Volume ducked to 30% (was " + mNormalVolume + ")");
    }
    
    /**
     * Restores volume to normal level after ducking.
     */
    public void unduck() {
        setVolume(mNormalVolume);
        Log.d(TAG, "Volume unducked to " + mNormalVolume);
    }
    
    /**
     * Sets playback parameters (speed and pitch).
     * Only available on Android M+ (API 23+).
     *
     * @param tempo Speed multiplier (0.5 to 1.5)
     * @param pitch Pitch multiplier (2^(semitones/12))
     */
    public void setPlaybackParams(float tempo, float pitch) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (mMediaPlayer != null && mIsPrepared.get()) {
                try {
                    android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                    params.setSpeed(tempo);
                    params.setPitch(pitch);
                    mMediaPlayer.setPlaybackParams(params);
                    Log.d(TAG, "PlaybackParams set: tempo=" + tempo + ", pitch=" + pitch);
                } catch (Exception e) {
                    Log.e(TAG, "setPlaybackParams error", e);
                }
            }
        } else {
            Log.w(TAG, "PlaybackParams not supported before Android M");
        }
    }
    
    // ========================================================================
    // Internal Methods
    // ========================================================================
    
    /**
     * Internal preparation logic (runs on background thread).
     */
    private void prepareInternal() {
        try {
            // Create new MediaPlayer
            MediaPlayer player = new MediaPlayer();
            
            // Configure audio attributes for better compatibility
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
                player.setAudioAttributes(attributes);
            } else {
                player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            }
            
            // Set data source
            player.setDataSource(mDataSource);
            
            // Set listeners
            player.setOnPreparedListener(this);
            player.setOnCompletionListener(this);
            player.setOnErrorListener(this);
            player.setOnSeekCompleteListener(this);
            
            // Prepare asynchronously
            player.prepareAsync();
            
            // Store reference
            synchronized (mStateLock) {
                if (mState == State.RELEASED) {
                    player.release();
                    return;
                }
                mMediaPlayer = player;
            }
            
            Log.d(TAG, "prepareInternal: MediaPlayer preparing...");
            
        } catch (IOException e) {
            Log.e(TAG, "prepareInternal: IOException", e);
            notifyError(0, 0, "Failed to open file: " + e.getMessage());
            setState(State.ERROR);
        } catch (Exception e) {
            Log.e(TAG, "prepareInternal: exception", e);
            notifyError(0, 0, "Preparation failed: " + e.getMessage());
            setState(State.ERROR);
        }
    }
    
    /**
     * Internal reset implementation.
     *
     * @param notifyListener Whether to notify listener of state change
     */
    private void resetInternal(boolean notifyListener) {
        synchronized (mStateLock) {
            final State oldState = mState;
            Log.d(TAG, "reset() from state: " + oldState);
            
            stopPositionPolling();
            
            if (mMediaPlayer != null) {
                try {
                    mMediaPlayer.reset();
                } catch (Exception e) {
                    Log.e(TAG, "reset error", e);
                }
            }
            
            mIsPrepared.set(false);
            mIsPlaying.set(false);
            mIsEOS.set(false);
            mDuration = 0;
            mCurrentPosition = 0;
            mPendingSeek = -1;
            mAudioSessionId = 0;
            
            setState(State.IDLE);
            
            if (notifyListener && mListener != null) {
                mMainHandler.post(() -> mListener.onStateChanged(State.IDLE, oldState));
            }
            
            Log.d(TAG, "reset() - IDLE state");
        }
    }
    
    /**
     * Updates the player state with logging and listener notification.
     *
     * @param newState The new state
     */
    private void setState(State newState) {
        synchronized (mStateLock) {
            if (mState == newState) return;
            
            final State oldState = mState;
            mState = newState;
            Log.d(TAG, "State: " + oldState + " -> " + newState);
            
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onStateChanged(newState, oldState));
            }
        }
    }
    
    /**
     * Notifies listener of an error.
     *
     * @param what Error code from MediaPlayer
     * @param extra Extra error code
     * @param message Human-readable error message
     */
    private void notifyError(int what, int extra, @NonNull String message) {
        Log.e(TAG, "Error: what=" + what + ", extra=" + extra + ", message=" + message);
        if (mListener != null) {
            mMainHandler.post(() -> mListener.onError(what, extra, message));
        }
    }
    
    /**
     * Starts position polling for UI updates.
     * Polling runs every POLLING_INTERVAL_MS while playing.
     */
    private void startPositionPolling() {
        if (mIsPolling.getAndSet(true)) {
            return;
        }
        
        if (mPollingHandler == null) {
            mPollingHandler = new Handler(Looper.getMainLooper());
        }
        
        mPollingRunnable = new Runnable() {
            @Override
            public void run() {
                if (mIsPolling.get() && mState == State.STARTED && 
                    mMediaPlayer != null && mIsPrepared.get()) {
                    try {
                        int position = mMediaPlayer.getCurrentPosition();
                        int duration = mMediaPlayer.getDuration();
                        if (duration > 0) {
                            mDuration = duration;
                        }
                        mCurrentPosition = position;
                        
                        if (mListener != null) {
                            mListener.onPositionUpdate(position, duration);
                        }
                    } catch (Exception e) {
                        Log.w(TAG, "Position polling error", e);
                    }
                }
                
                if (mIsPolling.get() && mPollingHandler != null && mPollingRunnable != null) {
                    mPollingHandler.postDelayed(mPollingRunnable, POLLING_INTERVAL_MS);
                }
            }
        };
        
        mPollingHandler.post(mPollingRunnable);
        Log.d(TAG, "Position polling started");
    }
    
    /**
     * Stops position polling.
     */
    private void stopPositionPolling() {
        if (!mIsPolling.getAndSet(false)) {
            return;
        }
        
        if (mPollingHandler != null && mPollingRunnable != null) {
            mPollingHandler.removeCallbacks(mPollingRunnable);
        }
        Log.d(TAG, "Position polling stopped");
    }
    
    // ========================================================================
    // MediaPlayer Callbacks
    // ========================================================================
    
    @Override
    public void onPrepared(MediaPlayer mp) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) return;
            
            try {
                mDuration = mp.getDuration();
                mAudioSessionId = mp.getAudioSessionId();
                mIsPrepared.set(true);
                
                // Apply pending seek
                if (mPendingSeek >= 0) {
                    mp.seekTo(mPendingSeek);
                    mPendingSeek = -1;
                }
                
                setState(State.PREPARED);
                Log.d(TAG, "onPrepared: duration=" + mDuration + "ms, sessionId=" + mAudioSessionId);
                
                // Notify audio session ID for equalizer (CRITICAL for EQ to work)
                if (mListener != null && mAudioSessionId > 0) {
                    mMainHandler.post(() -> mListener.onAudioSessionIdAvailable(mAudioSessionId));
                }
                
                if (mListener != null) {
                    mMainHandler.post(() -> mListener.onPrepared());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "onPrepared error", e);
                setState(State.ERROR);
                notifyError(0, 0, "Error after preparation: " + e.getMessage());
            }
        }
    }
    
    @Override
    public void onCompletion(MediaPlayer mp) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) return;
            
            Log.d(TAG, "onCompletion - end of stream reached");
            
            mIsPlaying.set(false);
            mIsEOS.set(true);
            mCurrentPosition = mDuration;
            stopPositionPolling();
            
            setState(State.COMPLETED);
            
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onCompletion());
            }
        }
    }
    
    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        synchronized (mStateLock) {
            String errorMessage;
            switch (what) {
                case MediaPlayer.MEDIA_ERROR_IO:
                    errorMessage = "I/O error reading file";
                    break;
                case MediaPlayer.MEDIA_ERROR_MALFORMED:
                    errorMessage = "Malformed file format";
                    break;
                case MediaPlayer.MEDIA_ERROR_UNSUPPORTED:
                    errorMessage = "Unsupported audio format";
                    break;
                case MediaPlayer.MEDIA_ERROR_TIMED_OUT:
                    errorMessage = "Operation timed out";
                    break;
                default:
                    errorMessage = "Unknown error (what=" + what + ", extra=" + extra + ")";
                    break;
            }
            
            mIsPrepared.set(false);
            mIsPlaying.set(false);
            stopPositionPolling();
            
            setState(State.ERROR);
            notifyError(what, extra, errorMessage);
            
            return true; // Error handled
        }
    }
    
    @Override
    public void onSeekComplete(MediaPlayer mp) {
        Log.d(TAG, "onSeekComplete");
        // Seek completed successfully - no action needed
    }
}