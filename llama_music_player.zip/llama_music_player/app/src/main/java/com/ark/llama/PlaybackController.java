package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * PlaybackController - Centralized playback state controller (single source of truth).
 * 
 * <p>This class provides thread-safe access to playback state and eliminates
 * race conditions between MusicPlayer and MusicService. All UI components
 * should read playback state from this controller rather than directly from
 * MusicService.</p>
 * 
 * <h3>Architecture</h3>
 * <p>PlaybackController acts as a facade between the UI and MusicService:</p>
 * <ul>
 *   <li>UI components register as listeners and receive callbacks on state changes</li>
 *   <li>MusicService updates the controller via bindService() and periodic polling</li>
 *   <li>All state fields are atomic to ensure thread safety across callbacks</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses:</p>
 * <ul>
 *   <li><b>AtomicBoolean/AtomicLong/AtomicReference</b> for all state fields</li>
 *   <li><b>Synchronized</b> blocks for listener registration</li>
 *   <li><b>Handler</b> to post callbacks to the main thread</li>
 *   <li><b>Volatile</b> fields for polling state</li>
 * </ul>
 * 
 * <h3>Position Polling</h3>
 * <p>The controller polls MusicService every 500ms for position updates.
 * During seeking (when user is dragging the seek bar), position updates are
 * skipped to prevent jitter. Throttling is applied to avoid excessive updates.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 * 
 * @see MusicPlayer
 * @see MusicService
 */
public class PlaybackController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging. */
    private static final String TAG = "PlaybackController";
    
    /** Position polling interval in milliseconds. */
    private static final long POSITION_POLL_INTERVAL_MS = 500;
    
    /** Minimum time between position update callbacks (throttling). */
    private static final long POSITION_UPDATE_THROTTLE_MS = 50;
    
    // ========================================================================
    // Singleton Instance
    // ========================================================================
    
    /** Singleton instance. */
    private static PlaybackController sInstance;
    
    /**
     * Returns the singleton instance of PlaybackController.
     *
     * @return The singleton instance
     */
    public static PlaybackController getInstance() {
        if (sInstance == null) {
            sInstance = new PlaybackController();
        }
        return sInstance;
    }
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     */
    public interface PlaybackListener {
        
        /**
         * Called when play/pause state changes.
         *
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when prepared state changes (song loaded and ready to play).
         *
         * @param isPrepared True if a song is loaded and ready
         */
        void onPreparedStateChanged(boolean isPrepared);
        
        /**
         * Called when a new song is loaded (complete metadata).
         *
         * @param title Song title (never null, may be empty)
         * @param artist Artist name (never null, may be empty)
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when playback position changes (throttled).
         *
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song in milliseconds
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when a playback operation fails.
         *
         * @param operation The operation that failed (e.g., "play", "pause")
         * @param reason Human-readable reason for failure (can be null)
         */
        void onOperationFailed(@NonNull String operation, @Nullable String reason);
    }
    
    // ========================================================================
    // Fields
    // ========================================================================
    
    /** Main thread handler for delivering callbacks. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Registered listener (single listener pattern). */
    private PlaybackListener mListener;
    
    /** Lock object for listener access. */
    private final Object mListenerLock = new Object();
    
    // ------------------------------------------------------------------------
    // Playback State (Atomic for thread safety)
    // ------------------------------------------------------------------------
    
    /** Current play state (true = playing, false = paused). */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Prepared state (true = song loaded and ready). */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /** Current playback position in milliseconds. */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Duration of current song in milliseconds. */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** Current song title. */
    private final AtomicReference<String> mCurrentTitle = new AtomicReference<>("");
    
    /** Current artist name. */
    private final AtomicReference<String> mCurrentArtist = new AtomicReference<>("");
    
    /** Current song file path. */
    private final AtomicReference<String> mCurrentPath = new AtomicReference<>("");
    
    // ------------------------------------------------------------------------
    // Polling and Seeking State
    // ------------------------------------------------------------------------
    
    /** Reference to bound MusicService. */
    private MusicService mMusicService;
    
    /** Runnable for periodic position polling. */
    private Runnable mPositionPollRunnable;
    
    /** Flag indicating if polling is active. */
    private volatile boolean mIsPolling = false;
    
    /** Flag indicating if user is seeking (UI should skip updates). */
    private volatile boolean mIsSeeking = false;
    
    /** Last time a position callback was delivered (for throttling). */
    private long mLastPositionUpdateTime = 0;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     */
    private PlaybackController() {
        Log.d(TAG, "PlaybackController initialized");
    }
    
    // ========================================================================
    // Public API
    // ========================================================================
    
    /**
     * Sets the listener for playback state changes.
     * Only one listener is supported at a time.
     *
     * @param listener The listener to register, or null to clear
     */
    public void setListener(@Nullable PlaybackListener listener) {
        synchronized (mListenerLock) {
            mListener = listener;
        }
        Log.d(TAG, "Listener set: " + (listener != null ? "registered" : "cleared"));
    }
    
    /**
     * Binds the controller to a MusicService instance.
     * Starts polling for position updates and syncs initial state.
     *
     * @param service The MusicService instance to bind to
     */
    public void bindService(@NonNull MusicService service) {
        mMusicService = service;
        
        // Sync initial state from service
        updateFromService();
        
        // Start polling for position updates
        startPolling();
        
        Log.d(TAG, "Bound to MusicService");
    }
    
    /**
     * Unbinds the controller from MusicService.
     * Stops all polling and clears the service reference.
     */
    public void unbindService() {
        stopPolling();
        mMusicService = null;
        
        // Reset state
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mCurrentPosition.set(0);
        mDuration.set(0);
        mCurrentTitle.set("");
        mCurrentArtist.set("");
        mCurrentPath.set("");
        
        Log.d(TAG, "Unbound from MusicService");
    }
    
    /**
     * Notifies the controller that seeking has started.
     * Position updates will be skipped until seek ends.
     */
    public void onSeekStart() {
        mIsSeeking = true;
        Log.d(TAG, "Seek started - UI updates paused");
    }
    
    /**
     * Notifies the controller that seeking has ended.
     * Forces an immediate position update after seek.
     */
    public void onSeekEnd() {
        mIsSeeking = false;
        
        // Force immediate position update after seek
        if (mMusicService != null) {
            long position = mMusicService.getCurrentPosition();
            long duration = mMusicService.getDuration();
            mCurrentPosition.set(position);
            if (duration > 0) {
                mDuration.set(duration);
            }
            notifyPositionChanged(position, duration);
        }
        
        Log.d(TAG, "Seek ended - UI updates resumed");
    }
    
    /**
     * Forces reset of seeking flag (used after timeout).
     */
    public void forceResetSeeking() {
        mIsSeeking = false;
        Log.d(TAG, "Seeking flag force reset");
    }
    
    /**
     * Updates the controller with new song metadata.
     * Called by MusicPlayer when metadata is loaded.
     *
     * @param song The song to update to
     * @param source Source identifier for debugging
     */
    public void updateSong(@NonNull Song song, @NonNull String source) {
        Log.d(TAG, "updateSong from " + source + ": " + song.getTitle());
        
        mCurrentTitle.set(song.getTitle());
        mCurrentArtist.set(song.getArtist());
        mCurrentPath.set(song.getPath());
        
        long duration = song.getDuration();
        if (duration > 0) {
            mDuration.set(duration);
        }
        
        // Notify listeners on main thread
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                notifySongChanged(song.getTitle(), song.getArtist(), song.getPath(), duration);
            }
        });
    }
    
    // ========================================================================
    // State Getters (for UI queries)
    // ========================================================================
    
    /**
     * Returns whether playback is currently active.
     *
     * @return True if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns whether the player is prepared (song loaded and ready).
     *
     * @return True if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position, or 0 if not available
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns the current song title.
     *
     * @return Song title, or empty string if not available
     */
    @NonNull
    public String getCurrentTitle() {
        return mCurrentTitle.get();
    }
    
    /**
     * Returns the current artist name.
     *
     * @return Artist name, or empty string if not available
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist.get();
    }
    
    /**
     * Returns the current song file path.
     *
     * @return File path, or empty string if not available
     */
    @NonNull
    public String getCurrentPath() {
        return mCurrentPath.get();
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Syncs state from the bound MusicService.
     * Called on bind and periodically during polling.
     */
    private void updateFromService() {
        if (mMusicService == null) {
            return;
        }
        
        // Sync play state
        boolean wasPlaying = mIsPlaying.get();
        boolean isPlaying = mMusicService.isPlaying();
        if (wasPlaying != isPlaying) {
            mIsPlaying.set(isPlaying);
            notifyPlayStateChanged(isPlaying);
        }
        
        // Sync prepared state
        boolean wasPrepared = mIsPrepared.get();
        boolean isPrepared = mMusicService.isPlayerPrepared();
        if (wasPrepared != isPrepared) {
            mIsPrepared.set(isPrepared);
            notifyPreparedStateChanged(isPrepared);
        }
        
        // Sync song info if changed
        Song current = mMusicService.getCurrentSong();
        if (current != null) {
            String currentPath = mCurrentPath.get();
            if (!currentPath.equals(current.getPath())) {
                mCurrentTitle.set(current.getTitle());
                mCurrentArtist.set(current.getArtist());
                mCurrentPath.set(current.getPath());
                long duration = mMusicService.getDuration();
                if (duration > 0) {
                    mDuration.set(duration);
                }
                notifySongChanged(current.getTitle(), current.getArtist(), current.getPath(), duration);
            }
        }
        
        // Sync position (non-seek case only)
        if (!mIsSeeking) {
            long position = mMusicService.getCurrentPosition();
            mCurrentPosition.set(position);
        }
    }
    
    /**
     * Starts periodic polling for position updates.
     */
    private void startPolling() {
        if (mIsPolling) {
            return;
        }
        
        mIsPolling = true;
        mLastPositionUpdateTime = 0;
        
        mPositionPollRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mIsPolling || mMusicService == null) {
                    return;
                }
                
                // Update state from service
                updateFromService();
                
                // Schedule next poll
                if (mIsPolling && mMainHandler != null) {
                    mMainHandler.postDelayed(this, POSITION_POLL_INTERVAL_MS);
                }
            }
        };
        
        mMainHandler.post(mPositionPollRunnable);
        Log.d(TAG, "Position polling started");
    }
    
    /**
     * Stops periodic polling for position updates.
     */
    private void stopPolling() {
        mIsPolling = false;
        if (mPositionPollRunnable != null && mMainHandler != null) {
            mMainHandler.removeCallbacks(mPositionPollRunnable);
            mPositionPollRunnable = null;
        }
        Log.d(TAG, "Position polling stopped");
    }
    
    /**
     * Notifies listener of play state change on main thread.
     *
     * @param isPlaying Current play state
     */
    private void notifyPlayStateChanged(final boolean isPlaying) {
        synchronized (mListenerLock) {
            if (mListener == null) {
                return;
            }
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mListenerLock) {
                        if (mListener != null) {
                            mListener.onPlayStateChanged(isPlaying);
                        }
                    }
                }
            });
        }
    }
    
    /**
     * Notifies listener of prepared state change on main thread.
     *
     * @param isPrepared Current prepared state
     */
    private void notifyPreparedStateChanged(final boolean isPrepared) {
        synchronized (mListenerLock) {
            if (mListener == null) {
                return;
            }
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mListenerLock) {
                        if (mListener != null) {
                            mListener.onPreparedStateChanged(isPrepared);
                        }
                    }
                }
            });
        }
    }
    
    /**
     * Notifies listener of song change on main thread.
     *
     * @param title Song title
     * @param artist Artist name
     * @param path File path
     * @param duration Duration in milliseconds
     */
    private void notifySongChanged(final String title, final String artist, 
                                   final String path, final long duration) {
        synchronized (mListenerLock) {
            if (mListener == null) {
                return;
            }
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mListenerLock) {
                        if (mListener != null) {
                            mListener.onSongChanged(title, artist, path, duration);
                        }
                    }
                }
            });
        }
    }
    
    /**
     * Notifies listener of position change on main thread with throttling.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Duration in milliseconds
     */
    private void notifyPositionChanged(final long positionMs, final long durationMs) {
        // Throttle updates to avoid flooding the UI
        long now = SystemClock.elapsedRealtime();
        if (now - mLastPositionUpdateTime < POSITION_UPDATE_THROTTLE_MS) {
            return;
        }
        mLastPositionUpdateTime = now;
        
        synchronized (mListenerLock) {
            if (mListener == null) {
                return;
            }
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mListenerLock) {
                        if (mListener != null) {
                            mListener.onPositionChanged(positionMs, durationMs);
                        }
                    }
                }
            });
        }
    }
    
    /**
     * Notifies listener of operation failure on main thread.
     *
     * @param operation The operation that failed
     * @param reason The reason for failure (can be null)
     */
    @SuppressWarnings("unused")
    private void notifyOperationFailed(final String operation, @Nullable final String reason) {
        synchronized (mListenerLock) {
            if (mListener == null) {
                return;
            }
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mListenerLock) {
                        if (mListener != null) {
                            mListener.onOperationFailed(operation, reason);
                        }
                    }
                }
            });
        }
    }
}