// SongDatabase.java
package com.ark.llama;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Caches song metadata in a local SQLite database.
 *
 * <p>Reading metadata from audio files is expensive, especially for
 * large libraries. This class persists the parsed values — title,
 * artist, album, genre, duration, and document URI — so later reads can
 * return from the database rather than re-parsing every file.</p>
 *
 * <h3>Tables</h3>
 * <p>The database holds two tables with an identical schema. The
 * {@link Table#SONGS} table caches metadata for songs in imported
 * folders. The {@link Table#LOOSE_SONGS} table caches metadata for
 * songs opened as loose tracks. Every read, insert, delete, and clear
 * operation in this class is written once against the {@link Table}
 * enum and exposed to callers through a thin public wrapper that
 * selects the table the caller's semantic implies.</p>
 *
 * <h3>Schema</h3>
 * <p>Each table carries a {@code path} column as the primary key, the
 * text columns {@code title}, {@code artist}, {@code album},
 * {@code genre}, and {@code uri}, and the integer columns
 * {@code duration}, {@code modified}, and {@code file_size}. The
 * {@code modified} and {@code file_size} columns exist for cache
 * validation.</p>
 *
 * <h3>Column Resolution</h3>
 * <p>{@link Cursor#getColumnIndex(String)} walks the cursor's
 * column-name array on every call. Reading six columns per row over a
 * multi-thousand-row result is six multi-thousand-element walks, and it
 * is the dominant cost of a full table read. Every read path in this
 * class resolves the column indexes once per query through
 * {@link RowReader} and then reads each row with the cached indexes.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every database accessor is annotated {@link WorkerThread} and is
 * intended to be called from a background thread. Write-ahead logging
 * is enabled in the constructor, so reads can proceed while a write is
 * in flight. Batch inserts run inside a single transaction.</p>
 *
 * @see Song
 * @see SQLiteOpenHelper
 * @see WorkerThread
 *
 * @author Richard Korbla Adzido
 * @version 1.4.1
 * @since 1.0.0
 */
public class SongDatabase extends SQLiteOpenHelper {

    // ============================================================================
    // Database Constants
    // ============================================================================

    /** Database file name. */
    private static final String DATABASE_NAME = "songs_cache.db";

    /**
     * Database version.
     *
     * <p>Version 2 adds the {@code file_size} and {@code uri} columns
     * to the {@code loose_songs} table so the two tables share the same
     * schema. Version 3 adds the {@code favorite} column to both tables
     * and introduces the targeted write path that never touches it —
     * {@link #setFavorite(String, boolean)} writes it,
     * {@link #updateSongMetadata(Song)} writes everything else.</p>
     */
    private static final int DATABASE_VERSION = 3;

    // ============================================================================
    // Column Constants
    // ============================================================================

    /** File path column; the primary key that uniquely identifies a song. */
    private static final String COL_PATH = "path";

    /** Title column, populated from ID3 tags or the filename fallback. */
    private static final String COL_TITLE = "title";

    /** Artist column, populated from ID3 tags. */
    private static final String COL_ARTIST = "artist";

    /** Album column, populated from ID3 tags. */
    private static final String COL_ALBUM = "album";

    /** Genre column, populated from ID3 tags. */
    private static final String COL_GENRE = "genre";

    /** Duration column, in milliseconds. */
    private static final String COL_DURATION = "duration";

    /** Last-modified timestamp column, used for cache validation. */
    private static final String COL_MODIFIED = "modified";

    /** File size column, used for cache validation. */
    private static final String COL_FILE_SIZE = "file_size";

    /** Document URI column, used for Storage Access Framework writes. */
    private static final String COL_URI = "uri";

    /**
     * Favorite column. Stores 1 when the user has marked the song as a
     * favorite and 0 otherwise. The column is written only by the
     * insert path on a fresh row and by
     * {@link #setFavorite(String, boolean)} on an existing row;
     * {@link #updateSongMetadata(Song)} never touches it.
     */
    private static final String COL_FAVORITE = "favorite";

    // ============================================================================
    // Logging
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "SongDatabase";

    // ============================================================================
    // Table Enum
    // ============================================================================

    /**
     * The two tables this class manages. Both tables share an identical
     * schema.
     */
    private enum Table {

        /** Table that caches metadata for songs in imported folders. */
        SONGS("songs", "idx_path", "idx_title", "idx_modified"),

        /** Table that caches metadata for loose tracks. */
        LOOSE_SONGS("loose_songs", "idx_loose_path", null, null);

        /** Physical name of the table. */
        final String name;

        /** Name of the index on the path column, or null when none is created. */
        @Nullable final String pathIndex;

        /** Name of the index on the title column, or null when none is created. */
        @Nullable final String titleIndex;

        /** Name of the index on the modified column, or null when none is created. */
        @Nullable final String modifiedIndex;

        /**
         * Constructs a table descriptor.
         *
         * @param name Physical name of the table
         * @param pathIndex Name of the index on the path column
         * @param titleIndex Name of the index on the title column, or null
         * @param modifiedIndex Name of the index on the modified column, or null
         */
        Table(@NonNull String name,
              @NonNull String pathIndex,
              @Nullable String titleIndex,
              @Nullable String modifiedIndex) {
            this.name = name;
            this.pathIndex = pathIndex;
            this.titleIndex = titleIndex;
            this.modifiedIndex = modifiedIndex;
        }
    }

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile SongDatabase sInstance;

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * <p>Safe for concurrent use through double-checked locking.</p>
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static SongDatabase getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (SongDatabase.class) {
                if (sInstance == null) {
                    sInstance = new SongDatabase(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the helper and enables write-ahead logging so reads can
     * proceed while a write is in flight.
     *
     * @param context Application context
     */
    private SongDatabase(@NonNull Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    // ============================================================================
    // SQLiteOpenHelper Methods
    // ============================================================================

    /**
     * Enables foreign key constraints when the platform supports them.
     *
     * @param database Database being configured
     */
    @Override
    public void onConfigure(@NonNull SQLiteDatabase database) {
        super.onConfigure(database);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            database.setForeignKeyConstraintsEnabled(true);
        }
    }

    /**
     * Creates both tables and their indexes on first access.
     *
     * @param database Database being created
     */
    @Override
    public void onCreate(@NonNull SQLiteDatabase database) {
        for (Table table : Table.values()) {
            createTable(database, table);
        }
        Log.d(TAG, "Database created successfully with version " + DATABASE_VERSION);
    }

    /**
     * Creates one table and its indexes.
     *
     * @param database Database being modified
     * @param table Table to create
     */
    private void createTable(@NonNull SQLiteDatabase database, @NonNull Table table) {
        database.execSQL("CREATE TABLE " + table.name + " (" +
                COL_PATH + " TEXT PRIMARY KEY, " +
                COL_TITLE + " TEXT, " +
                COL_ARTIST + " TEXT, " +
                COL_ALBUM + " TEXT, " +
                COL_GENRE + " TEXT, " +
                COL_DURATION + " INTEGER, " +
                COL_MODIFIED + " INTEGER, " +
                COL_FILE_SIZE + " INTEGER, " +
                COL_URI + " TEXT, " +
                COL_FAVORITE + " INTEGER DEFAULT 0)");

        if (table.pathIndex != null) {
            database.execSQL("CREATE INDEX " + table.pathIndex + " ON " + table.name
                + "(" + COL_PATH + ")");
        }
        if (table.titleIndex != null) {
            database.execSQL("CREATE INDEX " + table.titleIndex + " ON " + table.name
                + "(" + COL_TITLE + ")");
        }
        if (table.modifiedIndex != null) {
            database.execSQL("CREATE INDEX " + table.modifiedIndex + " ON " + table.name
                + "(" + COL_MODIFIED + ")");
        }
    }

    /**
     * Upgrades the database schema.
     *
     * <p>Version 1 to version 2 adds the {@code file_size} and
     * {@code uri} columns to the loose-songs table so the two tables
     * share the same schema. Version 2 to version 3 adds the
     * {@code favorite} column to both tables; every existing row
     * receives {@code 0}, which is the correct value for a song the
     * user has not yet marked.</p>
     *
     * @param database Database being upgraded
     * @param oldVersion Version number before the upgrade
     * @param newVersion Version number after the upgrade
     */
    @Override
    public void onUpgrade(@NonNull SQLiteDatabase database, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from version " + oldVersion
            + " to " + newVersion);

        if (oldVersion < 2) {
            try {
                database.execSQL("ALTER TABLE " + Table.LOOSE_SONGS.name
                    + " ADD COLUMN " + COL_FILE_SIZE + " INTEGER DEFAULT 0");
                database.execSQL("ALTER TABLE " + Table.LOOSE_SONGS.name
                    + " ADD COLUMN " + COL_URI + " TEXT");
                Log.d(TAG, "Successfully upgraded loose_songs table to version 2");
            } catch (Exception exception) {
                Log.e(TAG, "Failed to upgrade loose_songs table", exception);
            }
        }

        if (oldVersion < 3) {
            try {
                database.execSQL("ALTER TABLE " + Table.SONGS.name
                    + " ADD COLUMN " + COL_FAVORITE + " INTEGER DEFAULT 0");
                database.execSQL("ALTER TABLE " + Table.LOOSE_SONGS.name
                    + " ADD COLUMN " + COL_FAVORITE + " INTEGER DEFAULT 0");
                Log.d(TAG, "Successfully upgraded favorite column to version 3");
            } catch (Exception exception) {
                Log.e(TAG, "Failed to add favorite column", exception);
            }
        }

        Log.d(TAG, "Database upgrade completed");
    }

    // ============================================================================
    // Table-Parameterized Implementation
    // ============================================================================

    /**
     * Returns whether the given table contains a song at the given path.
     *
     * @param table Table to query
     * @param path Song path to check
     * @return True when the table holds a row with the given path
     */
    @WorkerThread
    private boolean hasSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, new String[] {COL_PATH},
                    COL_PATH + "=?", new String[] {path}, null, null, null);
            return cursor != null && cursor.moveToFirst();
        } catch (Exception exception) {
            Log.e(TAG, "hasSong error", exception);
            return false;
        } finally {
            closeCursorSafely(cursor);
        }
    }

    /**
     * Returns the song at the given path from the given table, or null
     * when it is not present.
     *
     * @param table Table to query
     * @param path Song path to look up
     * @return The stored song, or null
     */
    @Nullable
    @WorkerThread
    private Song getSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, null, COL_PATH + "=?",
                    new String[] {path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                RowReader reader = new RowReader(cursor);
                return reader.read(cursor, path);
            }
        } catch (Exception exception) {
            Log.e(TAG, "getSong error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return null;
    }

    /**
     * Inserts the given song into the given table, or updates it in
     * place when a row with the same path already exists.
     *
     * <p>A fresh row is written with every column, including the
     * favorite flag. An existing row is updated through
     * {@link #updateSongMetadataInternalOn(SQLiteDatabase, Table, Song)},
     * which writes every column except the favorite flag; the flag is
     * preserved across the metadata update. This is what lets the
     * scanner, the metadata editor, and the genre loader all call
     * {@code insertSong} without clobbering a user's favorites.</p>
     *
     * @param table Table to modify
     * @param song Song to insert, or null
     */
    @WorkerThread
    private void insertSongInternal(@NonNull Table table, @Nullable Song song) {
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            return;
        }
        try {
            SQLiteDatabase database = getWritableDatabase();
            long rowId = database.insertWithOnConflict(table.name, null,
                buildContentValues(song), SQLiteDatabase.CONFLICT_IGNORE);
            if (rowId == -1L) {
                updateSongMetadataInternalOn(database, table, song);
            }
        } catch (Exception exception) {
            Log.e(TAG, "insertSong error", exception);
        }
    }

    /**
     * Inserts or updates the given songs in the given table inside a
     * single transaction.
     *
     * <p>Each song is written with the same "insert if fresh, update
     * metadata only if present" rule that
     * {@link #insertSongInternal(Table, Song)} uses, so a batch of
     * songs produced by a scan cannot clobber the favorites of rows
     * that already exist. The whole loop runs inside a transaction,
     * so the batch is atomic and the framework commits or rolls back
     * once.</p>
     *
     * @param table Table to modify
     * @param songs Songs to insert, or null
     */
    @WorkerThread
    private void insertSongsBatchInternal(@NonNull Table table,
                                          @Nullable ArrayList<Song> songs) {
        if (songs == null || songs.isEmpty()) {
            return;
        }
        SQLiteDatabase database = null;
        try {
            database = getWritableDatabase();
            database.beginTransaction();
            for (Song song : songs) {
                if (song == null || TextUtils.isEmpty(song.getPath())) {
                    continue;
                }
                long rowId = database.insertWithOnConflict(table.name, null,
                    buildContentValues(song), SQLiteDatabase.CONFLICT_IGNORE);
                if (rowId == -1L) {
                    updateSongMetadataInternalOn(database, table, song);
                }
            }
            database.setTransactionSuccessful();
            Log.d(TAG, "Batch upserted " + songs.size() + " songs into " + table.name);
        } catch (Exception exception) {
            Log.e(TAG, "Batch insert error", exception);
        } finally {
            if (database != null) {
                try {
                    database.endTransaction();
                } catch (Exception ignored) {
                    // The transaction has already ended.
                }
            }
        }
    }

    /**
     * Returns every song in the given table, ordered by title, ignoring
     * case.
     *
     * <p>Column indexes are resolved once for the whole result set
     * through {@link RowReader}, rather than once per row.</p>
     *
     * @param table Table to read from
     * @return The stored songs, ordered by title
     */
    @NonNull
    @WorkerThread
    private ArrayList<Song> getAllSongsInternal(@NonNull Table table) {
        ArrayList<Song> songs = new ArrayList<Song>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, null, null, null, null, null,
                    COL_TITLE + " COLLATE NOCASE ASC");
            if (cursor != null && cursor.moveToFirst()) {
                int pathColumn = cursor.getColumnIndex(COL_PATH);
                if (pathColumn < 0) {
                    return songs;
                }
                RowReader reader = new RowReader(cursor);
                do {
                    String path = cursor.getString(pathColumn);
                    if (path != null) {
                        Song song = reader.read(cursor, path);
                        if (song != null) {
                            songs.add(song);
                        }
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception exception) {
            Log.e(TAG, "getAllSongs error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return songs;
    }

    /**
     * Returns the number of rows in the given table.
     *
     * @param table Table to count
     * @return The number of rows
     */
    @WorkerThread
    private int getSongsCountInternal(@NonNull Table table) {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM " + table.name, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception exception) {
            Log.e(TAG, "getSongsCount error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return 0;
    }

    /**
     * Removes the song at the given path from the given table.
     *
     * @param table Table to modify
     * @param path Path of the song to remove
     */
    @WorkerThread
    private void removeSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return;
        }
        try {
            int deleted = getWritableDatabase().delete(table.name, COL_PATH + "=?",
                new String[] {path});
            if (deleted > 0) {
                Log.d(TAG, "Removed song from " + table.name + ": " + path);
            }
        } catch (Exception exception) {
            Log.e(TAG, "removeSong error", exception);
        }
    }

    /**
     * Removes every row from the given table.
     *
     * @param table Table to clear
     */
    @WorkerThread
    private void clearTableInternal(@NonNull Table table) {
        try {
            int deleted = getWritableDatabase().delete(table.name, null, null);
            Log.d(TAG, "Cleared " + table.name + ", deleted " + deleted + " songs");
        } catch (Exception exception) {
            Log.e(TAG, "clearTable error", exception);
        }
    }

    /**
     * Returns whether the file at the given path has been modified since
     * its last cached entry in the given table.
     *
     * @param table Table to query
     * @param path Path of the file to check
     * @param currentModified Current last-modified timestamp of the file
     * @return True when the cached timestamp differs from
     *         {@code currentModified} or no entry exists
     */
    @WorkerThread
    private boolean isFileModifiedInternal(@NonNull Table table,
                                           @NonNull String path,
                                           long currentModified) {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, new String[] {COL_MODIFIED},
                    COL_PATH + "=?", new String[] {path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                long cachedModified = cursor.getLong(0);
                return cachedModified != currentModified;
            }
        } catch (Exception exception) {
            Log.e(TAG, "isFileModified error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return true;
    }

    // ============================================================================
    // Row Reader
    // ============================================================================

    /**
     * Caches the column indexes of a cursor so per-row reads do not
     * re-resolve them.
     *
     * <p>{@link Cursor#getColumnIndex(String)} walks the cursor's
     * column-name array on every call. Resolving six columns per row
     * over a multi-thousand-row result is six multi-thousand-element
     * walks, and it is the dominant cost of a full table read. Resolve
     * once per query, then read each row with the cached indexes.</p>
     *
     * <p>A missing required column is recorded as a negative index; the
     * reader returns null for every row when a required column is
     * absent, matching the previous behaviour. The favorite column is
     * optional: a cursor from an older schema that predates the column
     * reports a negative index, and the returned song is treated as not
     * favorited rather than failing the read.</p>
     */
    private static final class RowReader {

        /** Index of the title column, or negative when absent. */
        private final int titleColumn;

        /** Index of the artist column, or negative when absent. */
        private final int artistColumn;

        /** Index of the album column, or negative when absent. */
        private final int albumColumn;

        /** Index of the genre column, or negative when absent. */
        private final int genreColumn;

        /** Index of the duration column, or negative when absent. */
        private final int durationColumn;

        /** Index of the URI column, or negative when absent. */
        private final int uriColumn;

        /** Index of the favorite column, or negative when absent. */
        private final int favoriteColumn;

        /**
         * Resolves every column index for the given cursor.
         *
         * @param cursor Cursor whose columns are being resolved
         */
        RowReader(@NonNull Cursor cursor) {
            titleColumn = cursor.getColumnIndex(COL_TITLE);
            artistColumn = cursor.getColumnIndex(COL_ARTIST);
            albumColumn = cursor.getColumnIndex(COL_ALBUM);
            genreColumn = cursor.getColumnIndex(COL_GENRE);
            durationColumn = cursor.getColumnIndex(COL_DURATION);
            uriColumn = cursor.getColumnIndex(COL_URI);
            favoriteColumn = cursor.getColumnIndex(COL_FAVORITE);
        }

        /**
         * Reads the song from the current row of the cursor.
         *
         * @param cursor Cursor positioned at the row to read
         * @param path Path the row belongs to
         * @return The song built from the row, or null when a required
         *         column is absent
         */
        @Nullable
        Song read(@NonNull Cursor cursor, @NonNull String path) {
            if (titleColumn < 0 || artistColumn < 0
                    || albumColumn < 0 || durationColumn < 0) {
                return null;
            }

            String title = cursor.getString(titleColumn);
            String artist = cursor.getString(artistColumn);
            String album = cursor.getString(albumColumn);
            String genre = (genreColumn >= 0) ? cursor.getString(genreColumn) : null;
            long duration = cursor.getLong(durationColumn);
            String uri = (uriColumn >= 0) ? cursor.getString(uriColumn) : null;

            Song song = new Song(title, artist, album, genre, path, duration, uri);
            if (favoriteColumn >= 0) {
                song.setFavorite(cursor.getInt(favoriteColumn) != 0);
            }
            return song;
        }
    }

    // ============================================================================
    // Shared Row Helpers
    // ============================================================================

    /**
     * Builds the full content values for a fresh row, including the
     * favorite column.
     *
     * <p>Used by the fresh-row branch of the insert path. The
     * metadata-only variant below is used by the update branch, so a
     * write to an existing row never touches the favorite flag.</p>
     *
     * @param song Song to convert
     * @return The values to insert
     */
    @NonNull
    private ContentValues buildContentValues(@NonNull Song song) {
        ContentValues values = buildMetadataContentValues(song);
        values.put(COL_FAVORITE, song.isFavorite() ? 1 : 0);
        return values;
    }

    /**
     * Builds the content values for a metadata update, deliberately
     * excluding the favorite column.
     *
     * <p>The favorite flag has its own targeted write path —
     * {@link #setFavorite(String, boolean)} — and every other update
     * goes through this method. This is what makes the favorite flag
     * immune to a metadata edit, a genre load, and the scan's
     * reconciliation pass.</p>
     *
     * @param song Song whose metadata should be written
     * @return The values to update
     */
    @NonNull
    private ContentValues buildMetadataContentValues(@NonNull Song song) {
        ContentValues values = new ContentValues();
        values.put(COL_PATH, song.getPath());
        values.put(COL_TITLE, song.getTitle() != null ? song.getTitle() : "");
        values.put(COL_ARTIST, song.getArtist() != null ? song.getArtist() : "");
        values.put(COL_ALBUM, song.getAlbum() != null ? song.getAlbum() : "");
        values.put(COL_GENRE, song.getGenre() != null ? song.getGenre() : "");
        values.put(COL_DURATION, song.getDuration());
        values.put(COL_MODIFIED, SystemClock.elapsedRealtime());
        values.put(COL_FILE_SIZE, safeGetFileSize(song.getPath()));
        if (song.getUri() != null) {
            values.put(COL_URI, song.getUri());
        }
        return values;
    }

    /**
     * Returns the size of the file at the given path, or 0 when the file
     * is inaccessible.
     *
     * @param path Path of the file to measure
     * @return File size in bytes, or 0
     */
    @WorkerThread
    private long safeGetFileSize(@NonNull String path) {
        try {
            File file = new File(path);
            return (file.exists() && file.canRead()) ? file.length() : 0L;
        } catch (SecurityException exception) {
            Log.w(TAG, "No permission for file size: " + path);
            return 0L;
        }
    }

    /**
     * Closes the given cursor, ignoring any exception raised by the
     * framework.
     *
     * @param cursor Cursor to close, or null
     */
    private void closeCursorSafely(@Nullable Cursor cursor) {
        if (cursor != null) {
            try {
                cursor.close();
            } catch (Exception exception) {
                Log.w(TAG, "Failed to close cursor", exception);
            }
        }
    }

    // ============================================================================
    // Public API - Main Songs Table
    // ============================================================================

    /**
     * Returns whether the songs table contains a song at the given path.
     *
     * @param path Song path to check
     * @return True when the table holds a row with the given path
     */
    @WorkerThread
    public boolean hasSong(@NonNull String path) {
        return hasSongInternal(Table.SONGS, path);
    }

    /**
     * Returns the subset of the given paths that exist in the songs
     * table.
     *
     * @param paths Paths to test, or null
     * @return The set of paths from {@code paths} that are present in the
     *         table; empty when {@code paths} is null or empty
     */
    @NonNull
    @WorkerThread
    public Set<String> getExistingPaths(@Nullable Set<String> paths) {
        Set<String> existing = new HashSet<String>();
        if (paths == null || paths.isEmpty()) {
            return existing;
        }

        String[] pathArray = paths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int index = 0; index < pathArray.length; index++) {
            if (index > 0) {
                placeholders.append(",");
            }
            placeholders.append("?");
        }

        String query = "SELECT " + COL_PATH + " FROM " + Table.SONGS.name
            + " WHERE " + COL_PATH + " IN (" + placeholders.toString() + ")";
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery(query, pathArray);
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndex(COL_PATH);
                if (columnIndex >= 0) {
                    while (cursor.moveToNext()) {
                        String path = cursor.getString(columnIndex);
                        if (path != null) {
                            existing.add(path);
                        }
                    }
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getExistingPaths error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return existing;
    }

    /**
     * Returns the song at the given path from the songs table, or null
     * when it is not present.
     *
     * @param path Song path to look up
     * @return The stored song, or null
     */
    @Nullable
    @WorkerThread
    public Song getSong(@NonNull String path) {
        return getSongInternal(Table.SONGS, path);
    }

    /**
     * Inserts or replaces the given song in the songs table.
     *
     * @param song Song to insert, or null
     */
    @WorkerThread
    public void insertSong(@Nullable Song song) {
        insertSongInternal(Table.SONGS, song);
    }

    /**
     * Inserts or replaces the given songs in the songs table inside a
     * single transaction.
     *
     * @param songs Songs to insert, or null
     */
    @WorkerThread
    public void insertSongsBatch(@Nullable ArrayList<Song> songs) {
        insertSongsBatchInternal(Table.SONGS, songs);
    }

    /**
     * Removes every song from the songs table whose path is not in the
     * given set.
     *
     * <p>When {@code preserveLooseTracks} is true, loose tracks are kept
     * regardless of whether they appear in {@code validPaths}. When it is
     * false, loose tracks are removed unless they are present in
     * {@code validPaths}.</p>
     *
     * <p>When {@code validPaths} is null or empty and
     * {@code preserveLooseTracks} is false, this method logs a warning
     * and returns 0 without deleting anything, so an accidental empty set
     * cannot remove the entire library.</p>
     *
     * @param validPaths Paths to keep, or null
     * @param preserveLooseTracks True to keep loose tracks regardless of
     *        {@code validPaths}
     * @return The number of songs removed
     */
    @WorkerThread
    public int deleteSongsNotInSet(@Nullable Set<String> validPaths,
                                   boolean preserveLooseTracks) {
        Set<String> keepPaths = new HashSet<String>();
        if (validPaths != null) {
            keepPaths.addAll(validPaths);
        }

        if (preserveLooseTracks) {
            ArrayList<Song> looseSongs = getLooseSongs();
            for (Song looseSong : looseSongs) {
                if (looseSong != null && looseSong.getPath() != null) {
                    keepPaths.add(looseSong.getPath());
                }
            }
        }

        if (keepPaths.isEmpty()) {
            Log.w(TAG, "deleteSongsNotInSet called with empty keepPaths and "
                + "preserveLooseTracks=false - skipping deletion to prevent "
                + "accidental data loss");
            return 0;
        }

        String[] keepArray = keepPaths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int index = 0; index < keepArray.length; index++) {
            if (index > 0) {
                placeholders.append(",");
            }
            placeholders.append("?");
        }

        int deleted = 0;
        try {
            deleted = getWritableDatabase().delete(Table.SONGS.name,
                COL_PATH + " NOT IN (" + placeholders.toString() + ")",
                keepArray);
            Log.d(TAG, "Deleted " + deleted + " songs, kept " + keepPaths.size()
                + " (preserveLooseTracks=" + preserveLooseTracks + ")");
        } catch (Exception exception) {
            Log.e(TAG, "deleteSongsNotInSet error", exception);
            return 0;
        }

        return deleted;
    }

    /**
     * Removes every song from the songs table whose path is not in the
     * given set, preserving loose tracks.
     *
     * @param validPaths Paths to keep, or null
     * @return The number of songs removed
     */
    @WorkerThread
    public int deleteSongsNotInSet(@Nullable Set<String> validPaths) {
        return deleteSongsNotInSet(validPaths, true);
    }

    /**
     * Removes every row from the songs table. Loose tracks are
     * preserved, since they live in a separate table.
     */
    @WorkerThread
    public void clearCache() {
        clearTableInternal(Table.SONGS);
    }

    /**
     * Removes the song at the given path from the songs table.
     *
     * @param path Song path to remove
     */
    @WorkerThread
    public void removeSong(@NonNull String path) {
        removeSongInternal(Table.SONGS, path);
    }

    /**
     * Updates the metadata columns of an existing song, leaving the
     * favorite column untouched.
     *
     * <p>This is the single write path for updating a song from a
     * caller that does not intend to change the favorite state — the
     * metadata editor, the genre loader, and the playlist rebuild.
     * The favorite column is written only by
     * {@link #setFavorite(String, boolean)} and by the fresh-row
     * branch of the insert path.</p>
     *
     * <p>The update is a no-op when no row with the given path
     * exists; a caller that means to insert should use
     * {@link #insertSong(Song)}.</p>
     *
     * @param song Song whose metadata should be written; the song's
     *        path names the row
     */
    @WorkerThread
    public void updateSongMetadata(@Nullable Song song) {
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            return;
        }
        updateSongMetadataInternal(Table.SONGS, song);
    }

    /**
     * Updates the metadata columns of the given song in the given
     * table, leaving the favorite column untouched.
     *
     * <p>Obtains the writable database itself; the sibling
     * {@link #updateSongMetadataInternalOn(SQLiteDatabase, Table, Song)}
     * takes an existing database so a batch operation can run inside
     * one transaction.</p>
     *
     * @param table Table whose row should be updated
     * @param song Song whose metadata should be written
     */
    @WorkerThread
    private void updateSongMetadataInternal(@NonNull Table table,
                                            @NonNull Song song) {
        try {
            updateSongMetadataInternalOn(getWritableDatabase(), table, song);
        } catch (Exception exception) {
            Log.e(TAG, "updateSongMetadata error", exception);
        }
    }

    /**
     * Updates the metadata columns of the given song in the given
     * table using the given database handle, leaving the favorite
     * column untouched.
     *
     * <p>The favorite column is written nowhere in this method;
     * {@link #buildMetadataContentValues(Song)} does not carry it.
     * This is what makes the metadata path safe to call from a batch
     * insertion inside a transaction without a row-by-row favorite
     * preservation dance.</p>
     *
     * @param database Database to write through
     * @param table Table whose row should be updated
     * @param song Song whose metadata should be written
     */
    @WorkerThread
    private void updateSongMetadataInternalOn(@NonNull SQLiteDatabase database,
                                              @NonNull Table table,
                                              @NonNull Song song) {
        try {
            database.update(table.name, buildMetadataContentValues(song),
                COL_PATH + "=?", new String[] {song.getPath()});
        } catch (Exception exception) {
            Log.e(TAG, "updateSongMetadataOn error", exception);
        }
    }

    /**
     * Writes the favorite flag for the given song path to both the
     * songs and loose-songs tables.
     *
     * <p>The favorite column is written here and nowhere else. Every
     * other write path — metadata edits, genre loads, playlist
     * rebuilds — goes through {@link #updateSongMetadata(Song)} or
     * the fresh-row branch of the insert path, neither of which
     * touches the column. This is what makes the favorite column
     * immune to every other write path in the process.</p>
     *
     * @param path Path of the song whose flag should be written
     * @param favorite True to mark the song as a favorite
     */
    @WorkerThread
    public void setFavorite(@NonNull String path, boolean favorite) {
        if (TextUtils.isEmpty(path)) {
            return;
        }
        ContentValues values = new ContentValues();
        values.put(COL_FAVORITE, favorite ? 1 : 0);
        try {
            SQLiteDatabase database = getWritableDatabase();
            database.update(Table.SONGS.name, values,
                COL_PATH + "=?", new String[] {path});
            database.update(Table.LOOSE_SONGS.name, values,
                COL_PATH + "=?", new String[] {path});
        } catch (Exception exception) {
            Log.e(TAG, "setFavorite error", exception);
        }
    }

    /**
     * Returns every song in the songs table, ordered by title, ignoring
     * case.
     *
     * @return The stored songs, ordered by title
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getAllSongs() {
        return getAllSongsInternal(Table.SONGS);
    }

    /**
     * Returns the number of songs in the songs table.
     *
     * @return The number of rows in the songs table
     */
    @WorkerThread
    public int getSongsCount() {
        return getSongsCountInternal(Table.SONGS);
    }

    /**
     * Returns whether the file at the given path has been modified since
     * its last cached entry.
     *
     * @param path Path of the file to check
     * @param currentModified Current last-modified timestamp of the file
     * @return True when the cached timestamp differs from
     *         {@code currentModified} or no entry exists
     */
    @WorkerThread
    public boolean isFileModified(@NonNull String path, long currentModified) {
        return isFileModifiedInternal(Table.SONGS, path, currentModified);
    }

    // ============================================================================
    // Public API - Loose Songs Table
    // ============================================================================

    /**
     * Inserts or replaces the given song in the loose-songs table.
     *
     * @param song Song to insert, or null
     */
    @WorkerThread
    public void insertLooseSong(@Nullable Song song) {
        insertSongInternal(Table.LOOSE_SONGS, song);
    }

    /**
     * Returns every song in the loose-songs table, ordered by title,
     * ignoring case.
     *
     * @return The stored loose tracks, ordered by title
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getLooseSongs() {
        return getAllSongsInternal(Table.LOOSE_SONGS);
    }

    /**
     * Removes every row from the loose-songs table.
     */
    @WorkerThread
    public void clearLooseSongs() {
        clearTableInternal(Table.LOOSE_SONGS);
    }

    /**
     * Removes the song at the given path from the loose-songs table.
     *
     * @param path Song path to remove
     */
    @WorkerThread
    public void removeLooseSong(@NonNull String path) {
        removeSongInternal(Table.LOOSE_SONGS, path);
    }
}