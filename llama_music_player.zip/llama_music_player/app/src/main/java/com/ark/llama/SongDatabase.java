package com.ark.llama;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Database helper for caching song metadata with URI support for scoped storage.
 *
 * <p>This class provides a persistent cache for song metadata (title, artist, album,
 * genre, duration, and document URI) to avoid repeatedly reading ID3 tags from audio files.
 * Reading metadata from audio files is an expensive operation, especially when dealing
 * with large music libraries. This cache significantly improves performance by storing
 * parsed metadata in a local SQLite database.</p>
 *
 * <h3>Two Tables, One Shape</h3>
 * <p>The database has two tables:</p>
 * <ul>
 *   <li><b>{@link Table#SONGS}</b> — cached metadata for songs in imported folders</li>
 *   <li><b>{@link Table#LOOSE_SONGS}</b> — cached metadata for songs opened as
 *       loose tracks</li>
 * </ul>
 *
 * <p>Both tables share an identical schema. Every read, insert, delete, and
 * clear operation in this class is written once against the {@link Table}
 * enum and exposed to callers through a thin public wrapper that selects
 * the table the caller's semantic implies. There is no duplicated
 * implementation: a bug fixed in {@link #insertSongInternal} is fixed for
 * both tables.</p>
 *
 * <h3>Schema</h3>
 * <ul>
 *   <li><b>path</b> (TEXT PRIMARY KEY) — absolute file path, unique identifier</li>
 *   <li><b>title</b> (TEXT) — song title from ID3 tags or filename fallback</li>
 *   <li><b>artist</b> (TEXT) — artist name from ID3 tags</li>
 *   <li><b>album</b> (TEXT) — album name from ID3 tags</li>
 *   <li><b>genre</b> (TEXT) — music genre from ID3 tags</li>
 *   <li><b>duration</b> (INTEGER) — track duration in milliseconds</li>
 *   <li><b>modified</b> (INTEGER) — last modified timestamp for cache validation</li>
 *   <li><b>file_size</b> (INTEGER) — file size in bytes for cache validation</li>
 *   <li><b>uri</b> (TEXT) — document URI for scoped storage write access</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>All database operations are annotated with {@code @WorkerThread} and
 * are called from background threads. The class uses write-ahead logging
 * and proper synchronization through SQLite's built-in mechanisms.</p>
 *
 * @see Song
 * @see SQLiteOpenHelper
 * @see WorkerThread
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class SongDatabase extends SQLiteOpenHelper {

    // ========================================================================
    // Database Constants
    // ========================================================================

    /** Database file name. */
    private static final String DB_NAME = "songs_cache.db";

    /**
     * Database version.
     *
     * <p>Version 2 adds COL_FILE_SIZE and COL_URI to the loose_songs table
     * to match the songs table schema for consistency.</p>
     */
    private static final int DB_VERSION = 2;

    // ========================================================================
    // Column Constants
    // ========================================================================

    /** File path (primary key) - uniquely identifies a song. */
    private static final String COL_PATH = "path";

    /** Song title from ID3 tags or filename fallback. */
    private static final String COL_TITLE = "title";

    /** Artist name from ID3 tags. */
    private static final String COL_ARTIST = "artist";

    /** Album name from ID3 tags. */
    private static final String COL_ALBUM = "album";

    /** Music genre from ID3 tags. */
    private static final String COL_GENRE = "genre";

    /** Duration in milliseconds. */
    private static final String COL_DURATION = "duration";

    /** Last modified timestamp for cache validation. */
    private static final String COL_MODIFIED = "modified";

    /** File size in bytes for cache validation. */
    private static final String COL_FILE_SIZE = "file_size";

    /** Document URI for scoped storage write access (Android 10+). */
    private static final String COL_URI = "uri";

    // ========================================================================
    // Logging
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SongDatabase";

    // ========================================================================
    // Table Enum
    // ========================================================================

    /**
     * The two tables this class manages. Both share an identical schema.
     */
    private enum Table {

        /** Songs from imported folders. */
        SONGS("songs", "idx_path", "idx_title", "idx_modified"),

        /** Loose tracks opened from external apps. */
        LOOSE_SONGS("loose_songs", "idx_loose_path", null, null);

        final String name;
        @Nullable final String pathIndex;
        @Nullable final String titleIndex;
        @Nullable final String modifiedIndex;

        Table(@NonNull String name,
              @NonNull String pathIndex,
              @Nullable String titleIndex,
              @Nullable String modifiedIndex) {
            this.name = name;
            this.pathIndex = pathIndex;
            this.titleIndex = titleIndex;
            this.modifiedIndex = modifiedIndex;
        }
    }

    // ========================================================================
    // Singleton Pattern
    // ========================================================================

    /** Singleton instance (volatile for thread safety). */
    @Nullable
    private static volatile SongDatabase sInstance;

    /**
     * Returns the singleton instance of SongDatabase.
     *
     * <p>This method is thread-safe and uses double-checked locking for
     * efficient singleton initialization.</p>
     *
     * @param context Application context (will be converted to application context)
     * @return The singleton instance
     */
    @NonNull
    public static SongDatabase getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (SongDatabase.class) {
                if (sInstance == null) {
                    sInstance = new SongDatabase(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Private constructor for singleton pattern.
     *
     * <p>Enables write-ahead logging for better concurrent read/write performance.</p>
     *
     * @param context Application context
     */
    private SongDatabase(@NonNull Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    // ========================================================================
    // SQLiteOpenHelper Methods
    // ========================================================================

    /**
     * Called when the database is configured.
     *
     * <p>Enables foreign key constraints for referential integrity.</p>
     *
     * @param db The database
     */
    @Override
    public void onConfigure(@NonNull SQLiteDatabase db) {
        super.onConfigure(db);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            db.setForeignKeyConstraintsEnabled(true);
        }
    }

    /**
     * Creates the database tables and indexes.
     *
     * <p>Both tables are created with identical schemas via the shared
     * {@link #createTable(SQLiteDatabase, Table)} helper.</p>
     *
     * @param db The database
     */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        for (Table table : Table.values()) {
            createTable(db, table);
        }
        Log.d(TAG, "Database created successfully with version " + DB_VERSION);
    }

    /**
     * Creates one table and its indexes.
     *
     * @param db the database
     * @param table the table to create
     */
    private void createTable(@NonNull SQLiteDatabase db, @NonNull Table table) {
        db.execSQL("CREATE TABLE " + table.name + " (" +
                COL_PATH + " TEXT PRIMARY KEY, " +
                COL_TITLE + " TEXT, " +
                COL_ARTIST + " TEXT, " +
                COL_ALBUM + " TEXT, " +
                COL_GENRE + " TEXT, " +
                COL_DURATION + " INTEGER, " +
                COL_MODIFIED + " INTEGER, " +
                COL_FILE_SIZE + " INTEGER, " +
                COL_URI + " TEXT)");

        if (table.pathIndex != null) {
            db.execSQL("CREATE INDEX " + table.pathIndex + " ON " + table.name + "(" + COL_PATH + ")");
        }
        if (table.titleIndex != null) {
            db.execSQL("CREATE INDEX " + table.titleIndex + " ON " + table.name + "(" + COL_TITLE + ")");
        }
        if (table.modifiedIndex != null) {
            db.execSQL("CREATE INDEX " + table.modifiedIndex + " ON " + table.name + "(" + COL_MODIFIED + ")");
        }
    }

    /**
     * Upgrades the database schema.
     *
     * <p>Handles migrations between database versions. Currently supports
     * upgrade from version 1 to version 2 by adding missing columns to
     * the loose_songs table.</p>
     *
     * @param db The database
     * @param oldVersion Old version number
     * @param newVersion New version number
     */
    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);

        if (oldVersion < 2) {
            try {
                db.execSQL("ALTER TABLE " + Table.LOOSE_SONGS.name
                    + " ADD COLUMN " + COL_FILE_SIZE + " INTEGER DEFAULT 0");
                db.execSQL("ALTER TABLE " + Table.LOOSE_SONGS.name
                    + " ADD COLUMN " + COL_URI + " TEXT");
                Log.d(TAG, "Successfully upgraded loose_songs table to version 2");
            } catch (Exception exception) {
                Log.e(TAG, "Failed to upgrade loose_songs table", exception);
            }
        }

        Log.d(TAG, "Database upgrade completed");
    }

    // ========================================================================
    // Internal Table-Parameterized Implementation
    // ========================================================================

    /**
     * Checks if a song exists in the given table.
     */
    @WorkerThread
    private boolean hasSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) return false;
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, new String[]{COL_PATH},
                    COL_PATH + "=?", new String[]{path}, null, null, null);
            return cursor != null && cursor.moveToFirst();
        } catch (Exception exception) {
            Log.e(TAG, "hasSong error", exception);
            return false;
        } finally {
            closeCursorSafely(cursor);
        }
    }

    /**
     * Retrieves a single song by path from the given table.
     */
    @Nullable
    @WorkerThread
    private Song getSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) return null;
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, null, COL_PATH + "=?",
                    new String[]{path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                return readSongFromCursor(cursor, path);
            }
        } catch (Exception exception) {
            Log.e(TAG, "getSong error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return null;
    }

    /**
     * Inserts or replaces a single song in the given table.
     */
    @WorkerThread
    private void insertSongInternal(@NonNull Table table, @Nullable Song song) {
        if (song == null || TextUtils.isEmpty(song.getPath())) return;
        ContentValues values = buildContentValues(song);
        try {
            getWritableDatabase().insertWithOnConflict(table.name, null, values,
                SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception exception) {
            Log.e(TAG, "insertSong error", exception);
        }
    }

    /**
     * Inserts or replaces a batch of songs in the given table.
     */
    @WorkerThread
    private void insertSongsBatchInternal(@NonNull Table table, @Nullable ArrayList<Song> songs) {
        if (songs == null || songs.isEmpty()) return;
        SQLiteDatabase database = null;
        try {
            database = getWritableDatabase();
            database.beginTransaction();
            for (Song song : songs) {
                if (song == null || TextUtils.isEmpty(song.getPath())) continue;
                database.insertWithOnConflict(table.name, null,
                    buildContentValues(song), SQLiteDatabase.CONFLICT_REPLACE);
            }
            database.setTransactionSuccessful();
            Log.d(TAG, "Batch inserted " + songs.size() + " songs into " + table.name);
        } catch (Exception exception) {
            Log.e(TAG, "Batch insert error", exception);
        } finally {
            if (database != null) {
                try {
                    database.endTransaction();
                } catch (Exception ignored) {
                }
            }
        }
    }

    /**
     * Reads all songs from the given table, sorted by title.
     */
    @NonNull
    @WorkerThread
    private ArrayList<Song> getAllSongsInternal(@NonNull Table table) {
        ArrayList<Song> songs = new ArrayList<Song>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, null, null, null, null, null,
                    COL_TITLE + " COLLATE NOCASE ASC");
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int pathColumn = cursor.getColumnIndex(COL_PATH);
                    if (pathColumn < 0) continue;
                    String path = cursor.getString(pathColumn);
                    if (path != null) {
                        Song song = readSongFromCursor(cursor, path);
                        if (song != null) songs.add(song);
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception exception) {
            Log.e(TAG, "getAllSongs error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return songs;
    }

    /**
     * Returns the count of rows in the given table.
     */
    @WorkerThread
    private int getSongsCountInternal(@NonNull Table table) {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table.name, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception exception) {
            Log.e(TAG, "getSongsCount error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return 0;
    }

    /**
     * Removes a single song from the given table by path.
     */
    @WorkerThread
    private void removeSongInternal(@NonNull Table table, @NonNull String path) {
        if (TextUtils.isEmpty(path)) return;
        try {
            int deleted = getWritableDatabase().delete(table.name, COL_PATH + "=?",
                new String[]{path});
            if (deleted > 0) {
                Log.d(TAG, "Removed song from " + table.name + ": " + path);
            }
        } catch (Exception exception) {
            Log.e(TAG, "removeSong error", exception);
        }
    }

    /**
     * Deletes all rows from the given table.
     */
    @WorkerThread
    private void clearTableInternal(@NonNull Table table) {
        try {
            int deleted = getWritableDatabase().delete(table.name, null, null);
            Log.d(TAG, "Cleared " + table.name + ", deleted " + deleted + " songs");
        } catch (Exception exception) {
            Log.e(TAG, "clearTable error", exception);
        }
    }

    /**
     * Checks whether a file has been modified since it was cached in the
     * given table.
     */
    @WorkerThread
    private boolean isFileModifiedInternal(@NonNull Table table,
                                           @NonNull String path,
                                           long currentModified) {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(table.name, new String[]{COL_MODIFIED},
                    COL_PATH + "=?", new String[]{path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                long cachedModified = cursor.getLong(0);
                return cachedModified != currentModified;
            }
        } catch (Exception exception) {
            Log.e(TAG, "isFileModified error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return true;
    }

    // ========================================================================
    // Shared Row Helpers
    // ========================================================================

    /**
     * Reads a Song from the current row of the cursor.
     * Returns null if the row is malformed.
     */
    @Nullable
    private Song readSongFromCursor(@NonNull Cursor cursor, @NonNull String path) {
        int titleColumn = cursor.getColumnIndex(COL_TITLE);
        int artistColumn = cursor.getColumnIndex(COL_ARTIST);
        int albumColumn = cursor.getColumnIndex(COL_ALBUM);
        int genreColumn = cursor.getColumnIndex(COL_GENRE);
        int durationColumn = cursor.getColumnIndex(COL_DURATION);
        int uriColumn = cursor.getColumnIndex(COL_URI);

        if (titleColumn < 0 || artistColumn < 0 || albumColumn < 0 || durationColumn < 0) {
            return null;
        }

        String title = cursor.getString(titleColumn);
        String artist = cursor.getString(artistColumn);
        String album = cursor.getString(albumColumn);
        String genre = (genreColumn >= 0) ? cursor.getString(genreColumn) : null;
        long duration = cursor.getLong(durationColumn);
        String uri = (uriColumn >= 0) ? cursor.getString(uriColumn) : null;

        return new Song(title, artist, album, genre, path, duration, uri);
    }

    /**
     * Builds the ContentValues for inserting or replacing a song.
     */
    @NonNull
    private ContentValues buildContentValues(@NonNull Song song) {
        ContentValues values = new ContentValues();
        values.put(COL_PATH, song.getPath());
        values.put(COL_TITLE, song.getTitle() != null ? song.getTitle() : "");
        values.put(COL_ARTIST, song.getArtist() != null ? song.getArtist() : "");
        values.put(COL_ALBUM, song.getAlbum() != null ? song.getAlbum() : "");
        values.put(COL_GENRE, song.getGenre() != null ? song.getGenre() : "");
        values.put(COL_DURATION, song.getDuration());
        values.put(COL_MODIFIED, SystemClock.elapsedRealtime());
        values.put(COL_FILE_SIZE, safeGetFileSize(song.getPath()));
        if (song.getUri() != null) {
            values.put(COL_URI, song.getUri());
        }
        return values;
    }

    /**
     * Safely gets the file size, returning 0 on error.
     *
     * <p>This method handles SecurityException which can occur if the app
     * does not have permission to access the file.</p>
     *
     * @param path File path
     * @return File size in bytes, or 0 if inaccessible
     */
    @WorkerThread
    private long safeGetFileSize(@NonNull String path) {
        try {
            File file = new File(path);
            return (file.exists() && file.canRead()) ? file.length() : 0L;
        } catch (SecurityException exception) {
            Log.w(TAG, "No permission for file size: " + path);
            return 0L;
        }
    }

    /**
     * Safely closes a cursor, ignoring any exceptions.
     *
     * @param cursor The cursor to close (can be null)
     */
    private void closeCursorSafely(@Nullable Cursor cursor) {
        if (cursor != null) {
            try {
                cursor.close();
            } catch (Exception exception) {
                Log.w(TAG, "Failed to close cursor", exception);
            }
        }
    }

    // ========================================================================
    // Public API - Main Songs Table
    // ========================================================================

    /**
     * Checks if a song exists in the songs table.
     */
    @WorkerThread
    public boolean hasSong(@NonNull String path) {
        return hasSongInternal(Table.SONGS, path);
    }

    /**
     * Gets a set of existing paths from a given set of paths.
     */
    @NonNull
    @WorkerThread
    public Set<String> getExistingPaths(@Nullable Set<String> paths) {
        Set<String> existing = new HashSet<String>();
        if (paths == null || paths.isEmpty()) return existing;

        String[] pathArray = paths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int index = 0; index < pathArray.length; index++) {
            if (index > 0) placeholders.append(",");
            placeholders.append("?");
        }

        String query = "SELECT " + COL_PATH + " FROM " + Table.SONGS.name +
                      " WHERE " + COL_PATH + " IN (" + placeholders.toString() + ")";
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery(query, pathArray);
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndex(COL_PATH);
                if (columnIndex >= 0) {
                    while (cursor.moveToNext()) {
                        String path = cursor.getString(columnIndex);
                        if (path != null) existing.add(path);
                    }
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getExistingPaths error", exception);
        } finally {
            closeCursorSafely(cursor);
        }
        return existing;
    }

    /**
     * Retrieves a song from the songs table by its file path.
     */
    @Nullable
    @WorkerThread
    public Song getSong(@NonNull String path) {
        return getSongInternal(Table.SONGS, path);
    }

    /**
     * Inserts or updates a song in the songs table.
     */
    @WorkerThread
    public void insertSong(@Nullable Song song) {
        insertSongInternal(Table.SONGS, song);
    }

    /**
     * Inserts multiple songs into the songs table in a batch transaction.
     */
    @WorkerThread
    public void insertSongsBatch(@Nullable ArrayList<Song> songs) {
        insertSongsBatchInternal(Table.SONGS, songs);
    }

    /**
     * Deletes all songs whose paths are not in the valid set.
     *
     * <p>This method provides control over whether loose tracks are
     * preserved. When preserveLooseTracks is true, loose tracks are kept
     * even if not in validPaths. When false, loose tracks are deleted along
     * with other non-folder songs.</p>
     *
     * <p><b>Safety Check:</b> If validPaths is empty and preserveLooseTracks
     * is false, this method does not delete all songs. It logs a warning
     * and returns 0, preventing accidental data loss from empty path
     * sets.</p>
     *
     * @param validPaths Set of valid paths to keep (can be null or empty)
     * @param preserveLooseTracks True to preserve loose tracks, false to delete them
     * @return Number of songs deleted
     */
    @WorkerThread
    public int deleteSongsNotInSet(@Nullable Set<String> validPaths, boolean preserveLooseTracks) {
        Set<String> keepPaths = new HashSet<String>();
        if (validPaths != null) keepPaths.addAll(validPaths);

        if (preserveLooseTracks) {
            ArrayList<Song> looseSongs = getLooseSongs();
            for (Song looseSong : looseSongs) {
                if (looseSong != null && looseSong.getPath() != null) {
                    keepPaths.add(looseSong.getPath());
                }
            }
        }

        if (keepPaths.isEmpty()) {
            Log.w(TAG, "deleteSongsNotInSet called with empty keepPaths and "
                + "preserveLooseTracks=false - skipping deletion to prevent "
                + "accidental data loss");
            return 0;
        }

        String[] keepArray = keepPaths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int index = 0; index < keepArray.length; index++) {
            if (index > 0) placeholders.append(",");
            placeholders.append("?");
        }

        int deleted = 0;
        try {
            deleted = getWritableDatabase().delete(Table.SONGS.name,
                COL_PATH + " NOT IN (" + placeholders.toString() + ")",
                keepArray);
            Log.d(TAG, "Deleted " + deleted + " songs, kept " + keepPaths.size()
                + " (preserveLooseTracks=" + preserveLooseTracks + ")");
        } catch (Exception exception) {
            Log.e(TAG, "deleteSongsNotInSet error", exception);
            return 0;
        }

        return deleted;
    }

    /**
     * Deletes all songs whose paths are not in the valid set.
     * Default behavior: preserves loose tracks.
     */
    @WorkerThread
    public int deleteSongsNotInSet(@Nullable Set<String> validPaths) {
        return deleteSongsNotInSet(validPaths, true);
    }

    /**
     * Clears all cached songs from the songs table.
     *
     * <p>Loose songs are preserved; they live in a separate table.</p>
     */
    @WorkerThread
    public void clearCache() {
        clearTableInternal(Table.SONGS);
    }

    /**
     * Removes a single song from the songs table by its file path.
     */
    @WorkerThread
    public void removeSong(@NonNull String path) {
        removeSongInternal(Table.SONGS, path);
    }

    /**
     * Returns all songs from the songs table, sorted by title.
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getAllSongs() {
        return getAllSongsInternal(Table.SONGS);
    }

    /**
     * Returns the number of songs in the songs table.
     */
    @WorkerThread
    public int getSongsCount() {
        return getSongsCountInternal(Table.SONGS);
    }

    /**
     * Checks if a file has been modified since it was cached.
     */
    @WorkerThread
    public boolean isFileModified(@NonNull String path, long currentModified) {
        return isFileModifiedInternal(Table.SONGS, path, currentModified);
    }

    // ========================================================================
    // Public API - Loose Songs Table
    // ========================================================================

    /**
     * Inserts a loose song into the loose-songs table.
     *
     * <p>Loose songs are audio files opened from external apps (ACTION_VIEW)
     * that are not in any imported folder. They are stored separately from
     * the main songs table but use the same schema.</p>
     */
    @WorkerThread
    public void insertLooseSong(@Nullable Song song) {
        insertSongInternal(Table.LOOSE_SONGS, song);
    }

    /**
     * Returns all loose songs from the loose-songs table, sorted by title.
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getLooseSongs() {
        return getAllSongsInternal(Table.LOOSE_SONGS);
    }

    /**
     * Clears all loose songs from the loose-songs table.
     */
    @WorkerThread
    public void clearLooseSongs() {
        clearTableInternal(Table.LOOSE_SONGS);
    }

    /**
     * Removes a specific loose song from the loose-songs table.
     */
    @WorkerThread
    public void removeLooseSong(@NonNull String path) {
        removeSongInternal(Table.LOOSE_SONGS, path);
    }
}