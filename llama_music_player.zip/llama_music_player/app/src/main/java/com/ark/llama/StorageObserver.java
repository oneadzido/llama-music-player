package com.ark.llama;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ContentObserver for monitoring storage changes and triggering automatic playlist updates.
 *
 * <p>This class listens for changes in the device's media storage (new audio files added,
 * files modified, or files deleted) and automatically triggers a playlist synchronization
 * to keep the app's playlist in sync with the device's file system.</p>
 *
 * <p>Key Features:</p>
 * <ul>
 *   <li><b>Event-Driven Sync</b> - Reacts to Android MediaStore change notifications</li>
 *   <li><b>Debouncing (Quiet Period)</b> - Waits 5 seconds after last change before syncing</li>
 *   <li><b>Rate Limiting (Cooldown)</b> - Ensures syncs occur at most once per minute</li>
 *   <li><b>Non-Intrusive Updates</b> - Uses SOFT_UPDATE_PLAYLIST broadcast to preserve current playback</li>
 *   <li><b>State Management</b> - Queries {@link NavigationController} for the authoritative
 *       update-in-progress state rather than caching a copy</li>
 *   <li><b>Genre Loading After Sync</b> - Triggers Phase 2 genre loading via PlaylistService</li>
 *   <li><b>WeakReference to Activity</b> - Prevents memory leaks</li>
 *   <li><b>Thread-Safe Operation Tracking</b> - Uses AtomicBoolean and AtomicLong</li>
 * </ul>
 *
 * <h3>Ownership</h3>
 * <p>This observer is a <b>trigger</b>, not a lifecycle owner. It detects that
 * storage changed and asks {@link PlaylistService} to run a scan. It does
 * not call {@link NavigationController#beginPlaylistSync()} or
 * {@link NavigationController#endPlaylistSync()} — those belong to the
 * component that actually runs the scan, and PlaylistService already manages
 * them. The observer queries {@link NavigationController#isGroupDisabled(
 * NavigationController.ButtonGroup)} to know whether a scan is running, so
 * its view of the update state is the controller's view of the update
 * state by construction.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The observer has two lifecycle states, controlled by
 * {@link #startObserving()} and {@link #stopObserving()}:</p>
 * <ul>
 *   <li><b>Observable</b> — registered with the content resolver, listening
 *       for change notifications, and permitted to schedule scans.</li>
 *   <li><b>Shut down</b> — unregistered, no pending scan, and refuses to
 *       restart. Reaching this state is one-way.</li>
 * </ul>
 * <p>The single boolean {@link #mIsActive} tracks whether the observer is in
 * the first state. A second boolean {@link #mHasShutDown} latches the moment
 * the observer leaves the first state and prevents a subsequent
 * {@link #startObserving()} from reviving it. Two flags, each with a
 * distinct, single purpose; no overlap, no ambiguity.</p>
 *
 * @see PlaylistService
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class StorageObserver extends ContentObserver {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "StorageObserver";

    /** Cooldown period between syncs (60 seconds) - prevents CPU thrashing. */
    private static final long SYNC_COOLDOWN_MS = 60000;

    /** Quiet period delay after last change (5 seconds) - batches multiple file operations. */
    private static final long QUIET_PERIOD_MS = 5000;

    /** Delay before triggering genre loading after sync (milliseconds). */
    private static final long GENRE_LOAD_DELAY_MS = 1000;

    /** Delay between the scan's own SYNC_COMPLETE and this observer's follow-up broadcasts. */
    private static final long OPERATION_END_DELAY_MS = 500;

    /** Broadcast action for soft updating the playlist (preserves current playback). */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Weak reference to activity context for showing toasts (prevents memory leaks). */
    @NonNull
    private WeakReference<Activity> mActivityRef;

    /** Application context for accessing content resolver and sending broadcasts. */
    @NonNull
    private final Context mContext;

    /**
     * True between {@link #startObserving()} and {@link #stopObserving()}.
     * Gates change handling, scan scheduling, and restart.
     */
    private final AtomicBoolean mIsActive = new AtomicBoolean(false);

    /**
     * Latches true when {@link #stopObserving()} runs and never returns to
     * false. Prevents a later {@link #startObserving()} from reviving a shut
     * down observer.
     */
    private final AtomicBoolean mHasShutDown = new AtomicBoolean(false);

    /** Timestamp of the last completed sync for rate limiting (thread-safe). */
    private final AtomicLong mLastSyncTime = new AtomicLong(0);

    /** Service for performing the actual playlist update. */
    @NonNull
    private final PlaylistService mPlaylistService;

    /** Main thread handler for delayed operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Runnable for the pending storage update (used for debouncing). */
    @Nullable
    private Runnable mPendingUpdateRunnable = null;

    /** Lock for pending update runnable operations. */
    private final Object mPendingUpdateLock = new Object();

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new StorageObserver.
     * Uses a WeakReference to prevent memory leaks when the activity is destroyed.
     *
     * @param activity The activity context (for showing toasts)
     */
    public StorageObserver(@NonNull Activity activity) {
        super(new Handler(Looper.getMainLooper()));
        mActivityRef = new WeakReference<>(activity);
        mContext = activity.getApplicationContext();
        mPlaylistService = PlaylistService.getInstance(mContext);
    }

    /**
     * Updates the activity reference (called when activity is recreated).
     * Creates a new WeakReference to avoid holding the old activity reference.
     * Called in onResume() of MusicPlayer to ensure toast works.
     *
     * @param activity The current activity
     */
    public void setActivity(@NonNull Activity activity) {
        mActivityRef = new WeakReference<>(activity);
        Log.d(TAG, "Activity reference updated");
    }

    // ========================================================================
    // ContentObserver Callback Methods
    // ========================================================================

    /**
     * Called when a change occurs in the content that this observer is monitoring.
     *
     * @param selfChange True if this is a self-change (caused by the app itself)
     * @param uri The URI of the changed content
     */
    @Override
    public void onChange(boolean selfChange, @Nullable Uri uri) {
        super.onChange(selfChange, uri);
        if (mIsActive.get()) {
            handleChange(uri);
        }
    }

    /**
     * Called when a change occurs (legacy method without URI parameter).
     *
     * @param selfChange True if this is a self-change
     */
    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        if (mIsActive.get()) {
            handleChange(null);
        }
    }

    // ========================================================================
    // Change Handling (Thread-Safe)
    // ========================================================================

    /**
     * Handles storage change events using a 2-tier smart sync strategy:
     * <ol>
     *   <li><b>Cooldown Check</b> - Ensures syncs occur at most once per minute</li>
     *   <li><b>Quiet Period (Debounce)</b> - Waits 5 seconds after last change before syncing</li>
     * </ol>
     * <p>All delays use Handler.postDelayed().</p>
     *
     * @param uri The URI of the changed content (can be null)
     */
    private void handleChange(@Nullable Uri uri) {
        if (uri == null) {
            return;
        }

        String uriString = uri.toString();
        Log.d(TAG, "MediaStore changed: " + uriString);

        if (!uriString.contains("audio") && !uriString.contains("external")) {
            return;
        }

        if (isUpdateInProgress()) {
            Log.d(TAG, "Update in progress, skipping");
            return;
        }

        long currentTime = SystemClock.elapsedRealtime();
        long lastSync = mLastSyncTime.get();

        if (currentTime - lastSync < SYNC_COOLDOWN_MS && lastSync > 0) {
            Log.d(TAG, "Cooldown active - last sync was " + (currentTime - lastSync) + "ms ago, skipping");
            return;
        }

        synchronized (mPendingUpdateLock) {
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                Log.d(TAG, "Cancelled previous pending update, resetting quiet period");
            }

            mPendingUpdateRunnable = new Runnable() {
                @Override
                public void run() {
                    synchronized (mPendingUpdateLock) {
                        mPendingUpdateRunnable = null;
                    }
                    if (mIsActive.get() && !isUpdateInProgress()) {
                        performStorageUpdate();
                    }
                }
            };
            mMainHandler.postDelayed(mPendingUpdateRunnable, QUIET_PERIOD_MS);
        }

        Log.d(TAG, "Quiet period started - sync scheduled in " + QUIET_PERIOD_MS + "ms");
    }

    // ========================================================================
    // Storage Update (Phase 1 - Fast Scan)
    // ========================================================================

    /**
     * Triggers a playlist update for a storage change.
     *
     * <p>Uses {@link PlaylistService#updatePlaylistSilent()}, which manages
     * its own {@link NavigationController} begin/end pair for the duration of
     * the scan. This observer does not touch the controller's lifecycle
     * directly; it only triggers the scan and schedules the follow-up
     * notifications.</p>
     *
     * <p>When the scan completes, the observer broadcasts
     * {@code SOFT_UPDATE_PLAYLIST} so every component with a {@link MusicLibrary}
     * instance refreshes its in-memory song list from the database, and then
     * triggers Phase 2 genre loading via {@link PlaylistService}.</p>
     */
    private void performStorageUpdate() {
        if (!mIsActive.get()) {
            return;
        }

        Log.d(TAG, "Quiet period ended - triggering playlist update...");

        try {
            // PlaylistService owns the NavigationController lifecycle for this
            // scan. We do not begin/end it ourselves.
            mPlaylistService.updatePlaylistSilent();

            mLastSyncTime.set(SystemClock.elapsedRealtime());

            // The scan itself signals SYNC_COMPLETE when it finishes. We
            // schedule our follow-up after a short delay so the broadcast
            // ordering is stable: SYNC_COMPLETE first, SOFT_UPDATE_PLAYLIST
            // second, genre-load trigger third.
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsActive.get()) {
                        return;
                    }

                    Intent softUpdateIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
                    softUpdateIntent.putExtra("preserve_current_song", true);
                    mContext.sendBroadcast(softUpdateIntent);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsActive.get()) {
                                return;
                            }
                            Intent triggerIntent = new Intent(
                                PlaylistService.ACTION_TRIGGER_GENRE_LOADING
                            );
                            mContext.sendBroadcast(triggerIntent);
                        }
                    }, GENRE_LOAD_DELAY_MS);

                    Activity activity = mActivityRef.get();
                    if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
                        ToastManager.showToast(activity, "Playlist updated", ToastManager.LENGTH_SHORT);
                    }
                }
            }, OPERATION_END_DELAY_MS);

        } catch (Exception exception) {
            Log.e(TAG, "Failed to perform storage update", exception);
        }
    }

    /**
     * Cancels any pending storage update.
     * Thread-safe: uses synchronized block on mPendingUpdateLock.
     */
    private void cancelPendingUpdate() {
        synchronized (mPendingUpdateLock) {
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                mPendingUpdateRunnable = null;
                Log.d(TAG, "Cancelled pending update");
            }
        }
    }

    // ========================================================================
    // Update State Query
    // ========================================================================

    /**
     * True while any playlist scan is in progress.
     *
     * <p>Queries {@link NavigationController}, the sole owner of the
     * update-in-progress state. The observer's view is the controller's view
     * by construction.</p>
     *
     * @return true if a playlist scan is in progress
     */
    private boolean isUpdateInProgress() {
        return NavigationController.getInstance()
            .isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    // ========================================================================
    // Lifecycle Management (Thread-Safe)
    // ========================================================================

    /**
     * Starts observing storage changes.
     *
     * <p>Registers content observers for MediaStore audio and external files.
     * No-op if the observer has already been shut down, or if it is already
     * observing.</p>
     */
    public void startObserving() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot start observing - observer has been shut down");
            return;
        }

        if (!mIsActive.compareAndSet(false, true)) {
            Log.d(TAG, "Already observing, skipping");
            return;
        }

        try {
            ContentResolver resolver = mContext.getContentResolver();

            resolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true,
                this
            );

            resolver.registerContentObserver(
                MediaStore.Files.getContentUri("external"),
                true,
                this
            );

            Log.d(TAG, "Started observing storage changes");

        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied for storage observer", exception);
            mIsActive.set(false);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register observer", exception);
            mIsActive.set(false);
        }
    }

    /**
     * Stops observing storage changes and releases resources.
     *
     * <p>Sets the shutdown latch, cancels any pending scan, and unregisters
     * the content observer. Reaching this state is one-way: a later
     * {@link #startObserving()} is refused.</p>
     */
    public void stopObserving() {
        mHasShutDown.set(true);

        cancelPendingUpdate();

        if (!mIsActive.compareAndSet(true, false)) {
            Log.d(TAG, "Not observing, skipping stop");
            return;
        }

        try {
            mContext.getContentResolver().unregisterContentObserver(this);
            Log.d(TAG, "Stopped observing storage changes");
        } catch (Exception exception) {
            Log.e(TAG, "Failed to unregister observer", exception);
        }
    }

    /**
     * Forces an immediate playlist update, bypassing cooldown and quiet period.
     *
     * <p>Useful when the app needs to sync immediately (e.g., after user
     * folder changes). Refused while another scan is in progress.</p>
     */
    public void forceUpdate() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot force update - observer has been shut down");
            return;
        }

        cancelPendingUpdate();
        mLastSyncTime.set(0);

        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!mIsActive.get() || isUpdateInProgress()) {
                    return;
                }
                Log.d(TAG, "Force update triggered");
                performStorageUpdate();
            }
        });
    }

    /**
     * Returns debug information about the observer state.
     *
     * @return Debug string
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append("StorageObserver Debug Info:\n");
        builder.append("  Active: ").append(mIsActive.get()).append("\n");
        builder.append("  Shut down: ").append(mHasShutDown.get()).append("\n");
        builder.append("  Update in progress: ").append(isUpdateInProgress()).append("\n");
        builder.append("  Last sync time: ").append(mLastSyncTime.get()).append("\n");
        builder.append("  Time since last sync: ")
               .append(SystemClock.elapsedRealtime() - mLastSyncTime.get()).append("ms\n");

        synchronized (mPendingUpdateLock) {
            builder.append("  Pending update: ").append(mPendingUpdateRunnable != null).append("\n");
        }

        return builder.toString();
    }
}