// StorageObserver.java
package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Observes the device's music storage and asks the rest of the app
 * to refresh when it changes.
 *
 * <p>The observer watches two content URIs ({@code MediaStore} audio
 * and the app's own {@code SongDatabase}), plus a headset
 * disconnect receiver that asks the app to pause when the headset
 * goes away. When either content observer fires, it schedules a
 * debounced refresh that runs {@link #onStorageChanged()}; the
 * debounce coalesces the burst of change notifications MediaStore
 * emits during a single file operation.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The observer owns the debounce tokens and the list of registered
 * observers/receivers. It owns no playback state, no UI state, and no
 * persisted state. It reads the app's selected folders from
 * {@link SharedPreferences} only to decide whether to schedule a
 * refresh; the folders themselves are owned by
 * {@link MusicLibrary}.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Started by {@link MusicPlayer#onCreate()} through
 * {@link #startObserving()} and stopped from
 * {@link MusicPlayer#onDestroy()} through
 * {@link #stopObserving()}. A {@link StorageObserver} is a per-activity
 * object; it is not a singleton.</p>
 *
 * <h3>Refresh Contract</h3>
 * <p>When the storage changes, the observer sends a
 * {@code DISPLAY_PLAYLIST} broadcast followed by a
 * {@code TRIGGER_GENRE_LOADING} broadcast. The first asks the player
 * screen to redraw from the service; the second asks
 * {@link PlaylistManager} to load genre metadata for any song whose
 * genre is still unknown. Both are delivered through
 * {@link BroadcastTranslator}.</p>
 *
 * <h3>Threading</h3>
 * <p>The content observers fire on the main looper. The debounce
 * posts run on the main looper. Nothing in this class runs on a
 * background thread.</p>
 *
 * @see MusicPlayer
 * @see PlaylistManager
 * @see SongDatabase
 * @see BroadcastTranslator
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
public class StorageObserver {

    private static final String TAG = "StorageObserver";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS =
        "selected_folders_uris";

    /** Delay after a storage change before the refresh runs, in ms. */
    private static final long DEBOUNCE_DELAY_MS = 1500L;

    /** Context used for content resolution and broadcasts. */
    private final Context mContext;

    /** Handler for the debounce posts. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Monotonic token bumped on every schedule; stale posts exit. */
    private long mDebounceToken = 0L;

    /** True between startObserving() and stopObserving(). */
    private boolean mStarted = false;

    /** Content observer over MediaStore audio. */
    private ContentObserver mMediaObserver;

    /** Content observer over the app's song database. */
    private ContentObserver mDatabaseObserver;

    /** Receiver that handles headset disconnect. */
    private BroadcastReceiver mHeadsetReceiver;

    /** Activity reference for posting UI updates, or null. */
    private Activity mActivity;

    /**
     * Constructs the observer.
     *
     * @param context A context; the application context is retained
     */
    public StorageObserver(Context context) {
        mContext = context.getApplicationContext();
    }

    /**
     * Stores the activity reference the observer should route UI
     * work to.
     *
     * @param activity The activity, or null to clear
     */
    public void setActivity(Activity activity) {
        mActivity = activity;
    }

    /**
     * Registers the content observers and the headset receiver.
     * Idempotent: a second call while started returns without
     * registering anything twice.
     */
    public void startObserving() {
        if (mStarted) {
            return;
        }
        mStarted = true;

        mMediaObserver = new ContentObserver(mMainHandler) {
            @Override
            public void onChange(boolean selfChange) {
                super.onChange(selfChange);
                scheduleStorageCheck();
            }

            @Override
            public void onChange(boolean selfChange, Uri uri) {
                super.onChange(selfChange, uri);
                scheduleStorageCheck();
            }
        };

        mDatabaseObserver = new ContentObserver(mMainHandler) {
            @Override
            public void onChange(boolean selfChange) {
                super.onChange(selfChange);
                scheduleStorageCheck();
            }

            @Override
            public void onChange(boolean selfChange, Uri uri) {
                super.onChange(selfChange, uri);
                scheduleStorageCheck();
            }
        };

        try {
            mContext.getContentResolver().registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true, mMediaObserver);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register MediaStore observer",
                exception);
        }

        try {
            mContext.getContentResolver().registerContentObserver(
                SongDatabase.CONTENT_URI, true, mDatabaseObserver);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register SongDatabase observer",
                exception);
        }

        mHeadsetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) {
                    return;
                }
                final String action = intent.getAction();
                if (Intent.ACTION_HEADSET_PLUG.equals(action)) {
                    final int state = intent.getIntExtra(
                        "state", -1);
                    if (state == 0) {
                        sendBroadcast(new Intent(
                            BroadcastTranslator.ACTION_BLUETOOTH_PAUSE));
                    }
                }
            }
        };

        final IntentFilter filter = new IntentFilter(
            Intent.ACTION_HEADSET_PLUG);
        try {
            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.registerReceiver(mContext,
                    mHeadsetReceiver, filter,
                    ContextCompat.RECEIVER_NOT_EXPORTED);
            } else {
                mContext.registerReceiver(mHeadsetReceiver, filter);
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register headset receiver",
                exception);
        }
    }

    /**
     * Unregisters the content observers and the headset receiver.
     * Idempotent.
     */
    public void stopObserving() {
        if (!mStarted) {
            return;
        }
        mStarted = false;

        if (mMediaObserver != null) {
            try {
                mContext.getContentResolver()
                    .unregisterContentObserver(mMediaObserver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister MediaStore observer",
                    exception);
            }
            mMediaObserver = null;
        }

        if (mDatabaseObserver != null) {
            try {
                mContext.getContentResolver()
                    .unregisterContentObserver(mDatabaseObserver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister SongDatabase observer",
                    exception);
            }
            mDatabaseObserver = null;
        }

        if (mHeadsetReceiver != null) {
            try {
                mContext.unregisterReceiver(mHeadsetReceiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister headset receiver",
                    exception);
            }
            mHeadsetReceiver = null;
        }

        mMainHandler.removeCallbacksAndMessages(null);
        mActivity = null;
    }

    /**
     * Schedules the debounced storage check. Cancels any pending
     * post and posts a fresh one.
     */
    private void scheduleStorageCheck() {
        final long token = ++mDebounceToken;
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (token != mDebounceToken) {
                    return;
                }
                onStorageChanged();
            }
        }, DEBOUNCE_DELAY_MS);
    }

    /**
     * Runs the refresh. Reads the app's selected folders; when at
     * least one is configured, sends the display-refresh and
     * genre-load broadcasts.
     */
    private void onStorageChanged() {
        final SharedPreferences preferences =
            mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);
        final Set<String> selectedFolders =
            preferences.getStringSet(KEY_SELECTED_FOLDERS, null);

        if (selectedFolders == null || selectedFolders.isEmpty()) {
            Log.d(TAG, "Storage changed but no folders configured");
            return;
        }

        Log.d(TAG, "Storage changed with "
            + selectedFolders.size() + " folders; refreshing");

        sendBroadcast(new Intent(
            BroadcastTranslator.ACTION_DISPLAY_PLAYLIST));

        sendBroadcast(new Intent(
            BroadcastTranslator.ACTION_TRIGGER_GENRE_LOADING)
            .putExtra(
                BroadcastTranslator.EXTRA_TRIGGER_MESSAGE,
                ""));
    }

    /**
     * Sends the given intent as an app-internal broadcast.
     *
     * @param intent The intent to send
     */
    private void sendBroadcast(Intent intent) {
        try {
            mContext.sendBroadcast(intent);
        } catch (Exception exception) {
            Log.e(TAG, "sendBroadcast failed for "
                + intent.getAction(), exception);
        }
    }
}