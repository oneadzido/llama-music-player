package com.ark.llama;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Observes MediaStore for storage changes and triggers a playlist
 * update on the detected change.
 *
 * <p>When the user adds, modifies, or removes an audio file, Android
 * notifies the registered content observers. This class listens for
 * those notifications, batches multiple notifications through a quiet
 * period, and then asks {@link PlaylistManager} to run a scan. A
 * cooldown prevents the scan from running more than once per
 * {@link #SYNC_COOLDOWN_MS}.</p>
 *
 * <h3>State Ownership</h3>
 * <p>This observer is a trigger, not a lifecycle owner. It detects that
 * storage changed and asks {@link PlaylistManager} to run a scan.
 * {@link PlaylistManager} owns the begin and end of the scan's
 * {@link NavigationController} operation, because it owns the scan
 * itself. This observer reads
 * {@link NavigationController#isGroupDisabled(NavigationController.ButtonGroup)}
 * to learn whether a scan is running; the observer's view of the update
 * state is the controller's view by construction.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The observer has two lifecycle states, controlled by
 * {@link #startObserving()} and {@link #stopObserving()}:</p>
 * <ul>
 *   <li><b>Observable</b> — registered with the content resolver,
 *       listening for change notifications, and permitted to schedule
 *       scans.</li>
 *   <li><b>Shut down</b> — unregistered, with no pending scan, and
 *       refusing to restart. Reaching this state is one-way.</li>
 * </ul>
 * <p>{@link #mIsActive} tracks whether the observer is in the first
 * state. {@link #mHasShutDown} latches the moment the observer leaves
 * the first state and prevents a subsequent {@link #startObserving()}
 * from reviving it. Two flags, each with a distinct purpose.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. The content observer
 * is constructed with the main-thread looper. {@link #mIsActive} and
 * {@link #mHasShutDown} are atomic flags. Pending scan scheduling is
 * guarded by {@link #mPendingUpdateLock}.</p>
 *
 * @see PlaylistManager
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class StorageObserver extends ContentObserver {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "StorageObserver";

    /** Cooldown between consecutive syncs, in milliseconds. */
    private static final long SYNC_COOLDOWN_MS = 60000;

    /** Quiet period after the last change before scheduling a scan, in milliseconds. */
    private static final long QUIET_PERIOD_MS = 5000;

    /** Delay before triggering genre loading after a scan, in milliseconds. */
    private static final long GENRE_LOAD_DELAY_MS = 1000;

    /**
     * Delay between the scan's own {@code SYNC_COMPLETE} broadcast and
     * this observer's follow-up broadcasts.
     */
    private static final long OPERATION_END_DELAY_MS = 500;

    /** Broadcast action that asks the library to reload the playlist. */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";

    // ========================================================================
    // Member Variables
    // ========================================================================

    /**
     * Weak reference to the current activity, used for showing toasts
     * without holding the activity beyond its lifecycle.
     */
    @NonNull
    private WeakReference<Activity> mActivityRef;

    /** Application context used for the content resolver and broadcast dispatch. */
    @NonNull
    private final Context mContext;

    /**
     * True between {@link #startObserving()} and {@link #stopObserving()}.
     * Gates change handling, scan scheduling, and restart.
     */
    private final AtomicBoolean mIsActive = new AtomicBoolean(false);

    /**
     * Latches true when {@link #stopObserving()} runs and stays true.
     * Prevents a later {@link #startObserving()} from reviving a shut
     * down observer.
     */
    private final AtomicBoolean mHasShutDown = new AtomicBoolean(false);

    /** Timestamp of the last completed scan, used for rate limiting. */
    private final AtomicLong mLastSyncTime = new AtomicLong(0);

    /** Manager that performs the scan on request. */
    @NonNull
    private final PlaylistManager mPlaylistManager;

    /** Handler for delayed operations on the main thread. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Runnable for the pending storage update, or null when none is scheduled. */
    @Nullable
    private Runnable mPendingUpdateRunnable = null;

    /** Lock guarding the pending update runnable. */
    private final Object mPendingUpdateLock = new Object();

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the observer and stores a weak reference to the given
     * activity.
     *
     * <p>The weak reference lets the observer show a toast when a scan
     * finishes without holding the activity beyond its lifecycle. The
     * reference is refreshed in {@link #setActivity(Activity)} when the
     * activity resumes.</p>
     *
     * @param activity Activity used to show progress toasts
     */
    public StorageObserver(@NonNull Activity activity) {
        super(new Handler(Looper.getMainLooper()));
        mActivityRef = new WeakReference<>(activity);
        mContext = activity.getApplicationContext();
        mPlaylistManager = PlaylistManager.getInstance(mContext);
    }

    /**
     * Replaces the stored activity reference.
     *
     * <p>Called when the host activity is recreated or resumed, so a
     * later toast is shown in the activity that is on screen.</p>
     *
     * @param activity Activity used to show progress toasts
     */
    public void setActivity(@NonNull Activity activity) {
        mActivityRef = new WeakReference<>(activity);
        Log.d(TAG, "Activity reference updated");
    }

    // ========================================================================
    // ContentObserver Callback Methods
    // ========================================================================

    /**
     * Receives content change notifications that carry a URI.
     *
     * @param selfChange True when the change was caused by this process
     * @param uri URI of the changed content, or null
     */
    @Override
    public void onChange(boolean selfChange, @Nullable Uri uri) {
        super.onChange(selfChange, uri);
        if (mIsActive.get()) {
            handleChange(uri);
        }
    }

    /**
     * Receives content change notifications that do not carry a URI.
     *
     * @param selfChange True when the change was caused by this process
     */
    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        if (mIsActive.get()) {
            handleChange(null);
        }
    }

    // ========================================================================
    // Change Handling
    // ========================================================================

    /**
     * Handles a storage change notification.
     *
     * <p>Ignores notifications that do not refer to audio or external
     * storage. Refuses the change when a scan is already in progress or
     * when the cooldown has not yet elapsed. Otherwise, restarts the
     * quiet period so a burst of changes collapses into a single scan.</p>
     *
     * @param uri URI of the changed content, or null
     */
    private void handleChange(@Nullable Uri uri) {
        if (uri == null) {
            return;
        }

        String uriString = uri.toString();
        Log.d(TAG, "MediaStore changed: " + uriString);

        if (!uriString.contains("audio") && !uriString.contains("external")) {
            return;
        }

        if (isUpdateInProgress()) {
            Log.d(TAG, "Update in progress, skipping");
            return;
        }

        long currentTime = SystemClock.elapsedRealtime();
        long lastSync = mLastSyncTime.get();

        if (currentTime - lastSync < SYNC_COOLDOWN_MS && lastSync > 0) {
            Log.d(TAG, "Cooldown active - last sync was "
                + (currentTime - lastSync) + "ms ago, skipping");
            return;
        }

        synchronized (mPendingUpdateLock) {
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                Log.d(TAG, "Cancelled previous pending update, resetting quiet period");
            }

            mPendingUpdateRunnable = new Runnable() {
                @Override
                public void run() {
                    synchronized (mPendingUpdateLock) {
                        mPendingUpdateRunnable = null;
                    }
                    if (mIsActive.get() && !isUpdateInProgress()) {
                        performStorageUpdate();
                    }
                }
            };
            mMainHandler.postDelayed(mPendingUpdateRunnable, QUIET_PERIOD_MS);
        }

        Log.d(TAG, "Quiet period started - sync scheduled in "
            + QUIET_PERIOD_MS + "ms");
    }

    // ========================================================================
    // Storage Update
    // ========================================================================

    /**
     * Triggers a playlist scan in response to a storage change.
     *
     * <p>Calls {@link PlaylistManager#updatePlaylistSilent()}, which
     * manages its own {@link NavigationController} begin and end for the
     * duration of the scan. After the scan finishes, this method
     * broadcasts {@link #ACTION_SOFT_UPDATE_PLAYLIST} so every component
     * with a {@link MusicLibrary} instance refreshes its in-memory song
     * list, and then asks {@link PlaylistManager} to begin genre loading
     * when one is needed.</p>
     */
    private void performStorageUpdate() {
        if (!mIsActive.get()) {
            return;
        }

        Log.d(TAG, "Quiet period ended - triggering playlist update...");

        try {
            // PlaylistManager owns the NavigationController lifecycle for
            // this scan.
            mPlaylistManager.updatePlaylistSilent();

            mLastSyncTime.set(SystemClock.elapsedRealtime());

            // The scan emits its own SYNC_COMPLETE when it finishes. The
            // follow-up broadcasts are scheduled after a short delay so
            // SYNC_COMPLETE, SOFT_UPDATE_PLAYLIST, and the genre-load
            // trigger reach listeners in that order.
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsActive.get()) {
                        return;
                    }

                    Intent softUpdateIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
                    softUpdateIntent.putExtra("preserve_current_song", true);
                    mContext.sendBroadcast(softUpdateIntent);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsActive.get()) {
                                return;
                            }
                            Intent triggerIntent = new Intent(
                                PlaylistManager.ACTION_TRIGGER_GENRE_LOADING
                            );
                            mContext.sendBroadcast(triggerIntent);
                        }
                    }, GENRE_LOAD_DELAY_MS);

                    Activity activity = mActivityRef.get();
                    if (activity != null
                            && !activity.isFinishing()
                            && !activity.isDestroyed()) {
                        ToastManager.showToast(activity, "Playlist updated",
                            ToastManager.LENGTH_SHORT);
                    }
                }
            }, OPERATION_END_DELAY_MS);

        } catch (Exception exception) {
            Log.e(TAG, "Failed to perform storage update", exception);
        }
    }

    /**
     * Cancels any pending storage update.
     */
    private void cancelPendingUpdate() {
        synchronized (mPendingUpdateLock) {
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                mPendingUpdateRunnable = null;
                Log.d(TAG, "Cancelled pending update");
            }
        }
    }

    // ========================================================================
    // Update State Query
    // ========================================================================

    /**
     * Returns whether a playlist scan is in progress.
     *
     * <p>Queries {@link NavigationController}, which owns the
     * update-in-progress state.</p>
     *
     * @return True when the folder-actions button group is disabled
     */
    private boolean isUpdateInProgress() {
        return NavigationController.getInstance()
            .isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS);
    }

    // ========================================================================
    // Lifecycle Management
    // ========================================================================

    /**
     * Starts observing storage changes.
     *
     * <p>Registers content observers for {@code MediaStore.Audio.Media}
     * and {@code MediaStore.Files} on external storage. Does nothing
     * when the observer has already been shut down or is already
     * observing.</p>
     */
    public void startObserving() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot start observing - observer has been shut down");
            return;
        }

        if (!mIsActive.compareAndSet(false, true)) {
            Log.d(TAG, "Already observing, skipping");
            return;
        }

        try {
            ContentResolver resolver = mContext.getContentResolver();

            resolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true,
                this
            );

            resolver.registerContentObserver(
                MediaStore.Files.getContentUri("external"),
                true,
                this
            );

            Log.d(TAG, "Started observing storage changes");

        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied for storage observer", exception);
            mIsActive.set(false);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register observer", exception);
            mIsActive.set(false);
        }
    }

    /**
     * Stops observing storage changes and releases resources.
     *
     * <p>Sets the shutdown latch, cancels any pending scan, and
     * unregisters the content observer. Reaching this state is one-way: a
     * later {@link #startObserving()} is refused.</p>
     */
    public void stopObserving() {
        mHasShutDown.set(true);

        cancelPendingUpdate();

        if (!mIsActive.compareAndSet(true, false)) {
            Log.d(TAG, "Not observing, skipping stop");
            return;
        }

        try {
            mContext.getContentResolver().unregisterContentObserver(this);
            Log.d(TAG, "Stopped observing storage changes");
        } catch (Exception exception) {
            Log.e(TAG, "Failed to unregister observer", exception);
        }
    }

    /**
     * Forces an immediate playlist scan, bypassing the cooldown and the
     * quiet period.
     *
     * <p>Refused while another scan is in progress or after the observer
     * has been shut down.</p>
     */
    public void forceUpdate() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot force update - observer has been shut down");
            return;
        }

        cancelPendingUpdate();
        mLastSyncTime.set(0);

        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!mIsActive.get() || isUpdateInProgress()) {
                    return;
                }
                Log.d(TAG, "Force update triggered");
                performStorageUpdate();
            }
        });
    }

    /**
     * Returns a human-readable snapshot of the observer's current state.
     *
     * @return A multi-line string describing the active and shutdown
     *         flags, the update-in-progress state, the last sync
     *         timestamp, and whether a scan is pending
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append("StorageObserver Debug Info:\n");
        builder.append("  Active: ").append(mIsActive.get()).append("\n");
        builder.append("  Shut down: ").append(mHasShutDown.get()).append("\n");
        builder.append("  Update in progress: ").append(isUpdateInProgress()).append("\n");
        builder.append("  Last sync time: ").append(mLastSyncTime.get()).append("\n");
        builder.append("  Time since last sync: ")
               .append(SystemClock.elapsedRealtime() - mLastSyncTime.get()).append("ms\n");

        synchronized (mPendingUpdateLock) {
            builder.append("  Pending update: ")
                   .append(mPendingUpdateRunnable != null).append("\n");
        }

        return builder.toString();
    }
}