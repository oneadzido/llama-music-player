// StorageObserver.java
package com.ark.llama;

import android.app.Activity;
import android.content.ContentObserver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;

import java.util.Set;

/**
 * Observes the device's music storage and asks the rest of the app
 * to refresh when it changes.
 *
 * <p>The observer watches {@code MediaStore} audio. When it fires,
 * it schedules a debounced refresh that runs
 * {@link #onStorageChanged()}; the debounce coalesces the burst of
 * change notifications MediaStore emits during a single file
 * operation.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The observer owns the debounce token and the single content
 * observer. It owns no playback state, no UI state, and no
 * persisted state. It reads the app's selected folders from
 * {@link SharedPreferences} only to decide whether to schedule a
 * refresh; the folders themselves are owned by
 * {@link MusicLibrary}.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Started by {@link MusicPlayer#onCreate()} through
 * {@link #startObserving()} and stopped from
 * {@link MusicPlayer#onDestroy()} through
 * {@link #stopObserving()}. A {@link StorageObserver} is a
 * per-activity object; it is not a singleton.</p>
 *
 * <h3>Refresh Contract</h3>
 * <p>When the storage changes, the observer sends a single
 * {@code TRIGGER_GENRE_LOADING} broadcast through
 * {@link BroadcastTranslator}. {@link PlaylistManager} receives it
 * and loads genre metadata for any song whose genre is still
 * unknown. The display refresh and the playlist update are handled
 * by other broadcast stems and do not need a second sender here.</p>
 *
 * <h3>Threading</h3>
 * <p>The content observer fires on the main looper. The debounce
 * post runs on the main looper. Nothing in this class runs on a
 * background thread.</p>
 *
 * @see MusicPlayer
 * @see PlaylistManager
 * @see BroadcastTranslator
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
public class StorageObserver {

    private static final String TAG = "StorageObserver";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS =
        "selected_folders_uris";

    /** Delay after a storage change before the refresh runs, in ms. */
    private static final long DEBOUNCE_DELAY_MS = 1500L;

    /** Context used for content resolution and broadcasts. */
    private final Context mContext;

    /** Handler for the debounce posts. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Monotonic token bumped on every schedule; stale posts exit. */
    private long mDebounceToken = 0L;

    /** True between startObserving() and stopObserving(). */
    private boolean mStarted = false;

    /** Content observer over MediaStore audio. */
    private ContentObserver mMediaObserver;

    /** Activity reference for posting UI updates, or null. */
    private Activity mActivity;

    /**
     * Constructs the observer.
     *
     * @param context A context; the application context is retained
     */
    public StorageObserver(Context context) {
        mContext = context.getApplicationContext();
    }

    /**
     * Stores the activity reference the observer should route UI
     * work to.
     *
     * @param activity The activity, or null to clear
     */
    public void setActivity(Activity activity) {
        mActivity = activity;
    }

    /**
     * Registers the content observer. Idempotent: a second call
     * while started returns without registering anything twice.
     */
    public void startObserving() {
        if (mStarted) {
            return;
        }
        mStarted = true;

        mMediaObserver = new ContentObserver(mMainHandler) {
            @Override
            public void onChange(boolean selfChange) {
                super.onChange(selfChange);
                scheduleStorageCheck();
            }

            @Override
            public void onChange(boolean selfChange, Uri uri) {
                super.onChange(selfChange, uri);
                scheduleStorageCheck();
            }
        };

        try {
            mContext.getContentResolver().registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true, mMediaObserver);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register MediaStore observer",
                exception);
        }
    }

    /**
     * Unregisters the content observer. Idempotent.
     */
    public void stopObserving() {
        if (!mStarted) {
            return;
        }
        mStarted = false;

        if (mMediaObserver != null) {
            try {
                mContext.getContentResolver()
                    .unregisterContentObserver(mMediaObserver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister MediaStore observer",
                    exception);
            }
            mMediaObserver = null;
        }

        mMainHandler.removeCallbacksAndMessages(null);
        mActivity = null;
    }

    /**
     * Schedules the debounced storage check. Cancels any pending
     * post and posts a fresh one.
     */
    private void scheduleStorageCheck() {
        final long token = ++mDebounceToken;
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (token != mDebounceToken) {
                    return;
                }
                onStorageChanged();
            }
        }, DEBOUNCE_DELAY_MS);
    }

    /**
     * Runs the refresh. Reads the app's selected folders; when at
     * least one is configured, sends the genre-load request through
     * {@link BroadcastTranslator}.
     */
    private void onStorageChanged() {
        final SharedPreferences preferences =
            mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);
        final Set<String> selectedFolders =
            preferences.getStringSet(KEY_SELECTED_FOLDERS, null);

        if (selectedFolders == null || selectedFolders.isEmpty()) {
            Log.d(TAG, "Storage changed but no folders configured");
            return;
        }

        Log.d(TAG, "Storage changed with "
            + selectedFolders.size() + " folders; requesting genre load");

        sendBroadcast(new Intent(
            BroadcastTranslator.ACTION_TRIGGER_GENRE_LOADING)
            .putExtra(
                BroadcastTranslator.EXTRA_TRIGGER_MESSAGE,
                ""));
    }

    /**
     * Sends the given intent as an app-internal broadcast.
     *
     * @param intent The intent to send
     */
    private void sendBroadcast(Intent intent) {
        try {
            mContext.sendBroadcast(intent);
        } catch (Exception exception) {
            Log.e(TAG, "sendBroadcast failed for "
                + intent.getAction(), exception);
        }
    }
}