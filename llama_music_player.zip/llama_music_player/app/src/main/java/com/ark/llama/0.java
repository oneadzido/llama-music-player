package com.ark.llama;

// ... all existing imports remain the same ...

import androidx.activity.EdgeToEdge;

// ... rest of imports ...

public class ThemeDialog extends Dialog {

    // ... all constants and member variables remain unchanged ...

    // ========================================================================
    // Window Configuration Methods
    // ========================================================================
    
    /**
     * Configures the dialog window properties for full-screen display.
     * Uses EdgeToEdge API for modern edge-to-edge display.
     * Colors come from the theme (statusBarColor = @color/backgroundDark = #121212).
     */
    private void configureWindow(@NonNull Window window) {
        EdgeToEdge.enable(window);
        
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PresetDialogAnimation);
    }

    // ... rest of the class remains unchanged ...
}