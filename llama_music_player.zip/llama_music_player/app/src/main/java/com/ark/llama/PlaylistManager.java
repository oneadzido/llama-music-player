// PlaylistManager.java
package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Scans the selected music folders through {@link MediaStore},
 * caches the results in the song database, reads ID3 genres on a
 * background thread, adds loose tracks opened from other apps, and
 * owns the full-library reset.
 *
 * <p>A full scan runs in two phases. The fast scan queries
 * MediaStore for each selected folder and persists title, artist,
 * album, and duration; genre is left as {@code null} so the song row
 * constructs with the app's current placeholder and the UI can
 * render immediately. Genre loading reads the ID3 genre for every
 * song whose genre is still unknown and persists each result as it
 * arrives.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns four pieces of state: the scan-in-progress
 * flag, the current scan generation, the genre-load operation ID,
 * and the reset operation ID. {@link NavigationController} owns the
 * update-in-progress state that every component queries.</p>
 *
 * <p>Genre loading and library reset are identified by operation
 * IDs, not by boolean flags. The IDs are the tokens the operation
 * stack in {@link ToastManager} is keyed by. An operation is
 * running while its ID is on the stack; cancelling an operation is
 * removing its ID from the stack.</p>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible overlay message resolves from a string
 * resource through {@link #getLocaleContext()}, which carries the
 * app's selected language. A caller-supplied message overrides the
 * default for a specific invocation.</p>
 *
 * <h3>Overlay Title and Body</h3>
 * <p>Genre-load and reset overlays carry an action verb as their
 * overlay text and the notification mirror's title, and a count as
 * the notification mirror's body. Both strings are passed to
 * {@link ToastManager} as separate arguments; no consumer splits a
 * joined message.</p>
 *
 * <h3>Playlist-Sync Operation Lifecycle</h3>
 * <p>The {@link NavigationController} playlist-sync operation a
 * folder-update cycle takes is held for the duration of the scan
 * itself. It begins when the scan begins and ends the moment the
 * scan finishes, whether the scan succeeded or failed.</p>
 *
 * <h3>Overlay Ownership</h3>
 * <p>This manager owns two operation IDs on the
 * {@link ToastManager} stack: {@link #OPERATION_GENRE_UPDATE} for
 * the genre load and {@link #OPERATION_LIBRARY_RESET} for the
 * reset. It also holds the
 * {@link OverlayManager#REASON_FOLDER_UPDATE_CYCLE} reason across
 * the hand-off from a folder-update cycle to the genre load.</p>
 *
 * <h3>Genre Loading Threading</h3>
 * <p>Genre loading runs entirely on the single-thread executor. The
 * prologue — reading the full song list and filtering out the rows
 * that already have a genre — is O(n) in the library size and runs
 * on the executor as well. The overlay is shown synchronously in
 * the trigger's own turn, before the executor is dispatched.</p>
 *
 * <h3>The reset contract</h3>
 * <p>{@link #resetLibrary(ResetMode, ResetCallback)} runs a full
 * library reset. Its structure follows four rules:</p>
 * <ul>
 *   <li><b>One owner.</b> The reset has a beginning, a middle, and
 *       an end, and this manager owns all three.</li>
 *   <li><b>One write barrier.</b> The database and the SAF mappings
 *       are cleared on the executor, in one place, before any
 *       component is told the reset happened.</li>
 *   <li><b>One invalidation broadcast.</b> After the barrier, a
 *       single {@link #ACTION_LIBRARY_RESET} broadcast tells every
 *       cache owner to drop its song-derived state.</li>
 *   <li><b>One completion signal.</b> The operation ends when its
 *       work completes, not when a timer expires.</li>
 * </ul>
 *
 * <h3>Receiver contract</h3>
 * <p>Every component that holds a {@code MusicLibrary} instance, an
 * album art cache, a displayed playlist, or any other song-derived
 * state must register a receiver for {@link #ACTION_LIBRARY_RESET}
 * in {@code onCreate} and unregister it in {@code onDestroy}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>{@link #mIsUpdating} is an atomic flag that refuses
 * overlapping scans. {@link #mGenreOperationId} and
 * {@link #mResetOperationId} are volatile strings naming the
 * current operation on each channel. Main-thread callbacks are
 * dispatched through {@link #mMainHandler} and
 * {@link #mGenreHandler}. The executor is shut down in
 * {@link #shutdown()} with a bounded wait.</p>
 *
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 * @see OverlayManager
 * @see ToastManager
 * @see LanguageManager
 *
 * @author Richard Korbla Adzido
 * @version 1.4.5
 * @since 1.0.0
 */
public class PlaylistManager {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS =
        "selected_folders_uris";

    /** Number of songs between progress updates, for UI throttling. */
    private static final int PROGRESS_THRESHOLD = 10;

    /** Minimum time between progress updates in milliseconds. */
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500L;

    /** Interval between genre-loading heartbeats, in milliseconds. */
    private static final long GENRE_HEARTBEAT_INTERVAL_MS = 500L;

    /** Interval between library-reset heartbeats, in milliseconds. */
    private static final long RESET_HEARTBEAT_INTERVAL_MS = 500L;

    /** Broadcast action emitted when a scan finishes. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action for genre update lifecycle events. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action emitted when the library has been reset. */
    public static final String ACTION_LIBRARY_RESET = "LIBRARY_RESET";

    /** Intent extra carrying the preserve-settings flag. */
    public static final String EXTRA_PRESERVE_SETTINGS =
        "preserve_settings";

    /** Broadcast action that requests a playlist refresh. */
    public static final String ACTION_PLAYLIST_REFRESH =
        "PLAYLIST_REFRESH";

    /** Broadcast action that requests genre loading. */
    public static final String ACTION_TRIGGER_GENRE_LOADING =
        "com.ark.llama.TRIGGER_GENRE_LOADING";

    /** Intent extra carrying an optional custom overlay message. */
    public static final String EXTRA_TRIGGER_MESSAGE = "trigger_message";

    /** Operation ID that owns the persistent genre-loading overlay. */
    private static final String OPERATION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Operation ID that owns the persistent library-reset overlay. */
    private static final String OPERATION_LIBRARY_RESET = "LIBRARY_RESET";

    /** Timeout for executor shutdown in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000L;

    /** Delay before playlist update broadcasts, in milliseconds. */
    private static final long UPDATE_BROADCAST_DELAY_MS = 200L;

    /** Delay before the sync-complete broadcast, in milliseconds. */
    private static final long SYNC_COMPLETE_DELAY_MS = 400L;

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile PlaylistManager sInstance;

    /**
     * Application instance used to reach
     * {@link NotificationController} for the library
     * notification's teardown, from the genre-load completion
     * path.
     */
    @Nullable
    private static Application sApplication;

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static PlaylistManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (PlaylistManager.class) {
                if (sInstance == null) {
                    sInstance = new PlaylistManager(context);
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Application context. */
    private final Context mContext;

    /** Single-thread executor that runs every scan, genre load, and
     *  reset. */
    private final ExecutorService mExecutor;

    /** True while a scan is in flight. */
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);

    /** Handler for main-thread callbacks and broadcast dispatch. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Generation counter for scan cancellation. */
    @NonNull
    private final AtomicLong mScanGeneration = new AtomicLong(0L);

    /** Operation ID of the genre-load currently running, or null. */
    @Nullable
    private volatile String mGenreOperationId = null;

    /** Operation ID of the reset currently running, or null. */
    @Nullable
    private volatile String mResetOperationId = null;

    // ============================================================================
    // Genre Loading Members
    // ============================================================================

    /** Handler for genre-loading ticks and overlay updates. */
    private final Handler mGenreHandler =
        new Handler(Looper.getMainLooper());

    /** Token for the current genre-loading heartbeat ticker. */
    @NonNull
    private final AtomicLong mGenreHeartbeatToken =
        new AtomicLong(0L);

    /** Token for the current reset heartbeat ticker. */
    @NonNull
    private final AtomicLong mResetHeartbeatToken =
        new AtomicLong(0L);

    /** Token for the playlist-sync heartbeat ticker. */
    @NonNull
    private final AtomicLong mPlaylistSyncHeartbeatToken =
        new AtomicLong(0L);

    /** Receiver for the trigger-genre-loading broadcast. */
    private BroadcastReceiver mTriggerGenreReceiver;

    // ============================================================================
    // Callback Interfaces
    // ============================================================================

    /**
     * Receives progress, completion, and error callbacks from a
     * scan.
     */
    public interface UpdateCallback {

        /**
         * Called periodically while the scan runs.
         *
         * @param current Number of songs processed so far
         * @param total Total number of songs to process
         */
        void onProgress(int current, int total);

        /**
         * Called when the scan completes successfully.
         *
         * @param songCount Number of songs in the database after the
         *        scan
         */
        void onComplete(int songCount);

        /**
         * Called when the scan fails.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    /**
     * Receives the outcome of a library reset.
     */
    public interface ResetCallback {

        /**
         * Called when the reset has completed.
         */
        void onComplete();

        /**
         * Called when the reset failed.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    // ============================================================================
    // Reset Mode
    // ============================================================================

    /**
     * The scope of a library reset.
     */
    public enum ResetMode {

        /**
         * Clear the songs and loose tracks; preserve user settings.
         */
        LIBRARY,

        /**
         * Clear the songs, loose tracks, and user settings.
         */
        FACTORY
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the singleton, registers its trigger receiver, and
     * initialises the overlay manager.
     *
     * @param context A context; the application context is retained
     */
    private PlaylistManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        sApplication = (Application) mContext;
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
        OverlayManager.init(mContext);
    }

    // ============================================================================
    // Localization Helper
    // ============================================================================

    /**
     * Returns the app's locale-wrapped application context.
     *
     * <p>Reads through {@link LanguageManager#getLocalizedContext()}
     * rather than {@link #mContext}. The application context resolves
     * against the system locale; the localized one resolves against the
     * app's selected language. Every user-visible string this class
     * produces reads from the localized context.</p>
     *
     * @return A context whose resources resolve against the app's
     *         currently selected language
     */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context", exception);
            return mContext;
        }
    }

    // ============================================================================
    // Public API - Scans
    // ============================================================================

    /**
     * Runs a full folder scan and reports progress to the given
     * callback.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }

    /**
     * Runs a full folder scan without reporting progress.
     */
    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }

    /**
     * Adds a single song as a loose track and triggers a targeted
     * playlist refresh.
     *
     * @param song Song to add as a loose track
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song,
                                       @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose "
                + "track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mScanGeneration.get() != scanGeneration) {
                        return;
                    }

                    SongDatabase database =
                        SongDatabase.getInstance(mContext);
                    database.insertLooseSong(song);

                    final ArrayList<Song> allSongs =
                        database.getAllSongs();
                    final int totalSongCount = allSongs.size();

                    if (callback != null
                            && !Thread.currentThread()
                                .isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent updatePlaylistIntent =
                                new Intent("UPDATE_PLAYLIST");
                            updatePlaylistIntent.putExtra(
                                "preserve_current_song", true);
                            mContext.sendBroadcast(
                                updatePlaylistIntent);

                            Intent refreshDisplayIntent =
                                new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(
                                refreshDisplayIntent);

                            Intent syncCompleteIntent =
                                new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(
                                syncCompleteIntent);

                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);

                } catch (final Exception exception) {
                    Log.e(TAG, "Failed to add loose track",
                        exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(
                                    exception.getMessage() != null
                                        ? exception.getMessage()
                                        : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance()
                        .endPlaylistSync();
                    mIsUpdating.set(false);
                }
            }
        });
    }

    /**
     * Requests cancellation of any in-flight scan.
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
        mScanGeneration.incrementAndGet();
        Log.d(TAG, "Scan cancel requested (generation "
            + mScanGeneration.get() + ")");
    }

    /**
     * Returns whether a scan is currently in flight.
     *
     * @return True while a scan is running
     */
    public boolean isUpdating() {
        return mIsUpdating.get();
    }

    /**
     * Returns whether a reset is currently in flight.
     *
     * @return True while a reset is running
     */
    public boolean isResetting() {
        return mResetOperationId != null;
    }

    // ============================================================================
    // Public API - Library Reset
    // ============================================================================

    /**
     * Runs a full library reset.
     *
     * <p>The reset has four phases, in this order:</p>
     * <ol>
     *   <li><b>Admission.</b> The method refuses when a scan or
     *       another reset is already in flight.</li>
     *   <li><b>Preparation.</b> It cancels the genre loader,
     *       removes the genre overlay from the stack, takes the
     *       {@link NavigationController} operation, and pushes the
     *       reset overlay.</li>
     *   <li><b>Barrier.</b> On the executor, it clears the database
     *       tables, the SAF folder mappings, and the
     *       folder-selection preference.</li>
     *   <li><b>Dispatch and completion.</b> On the main handler, it
     *       sends {@link #ACTION_LIBRARY_RESET}, then clears the
     *       flags, pops the reset overlay, ends the navigation
     *       operation, and invokes the callback.</li>
     * </ol>
     *
     * @param mode The scope of the reset
     * @param callback Listener that receives the outcome, or null
     */
    public void resetLibrary(@NonNull final ResetMode mode,
                             @Nullable final ResetCallback callback) {
        OverlayManager.hide(
            OverlayManager.REASON_FOLDER_UPDATE_CYCLE);

        if (mIsUpdating.get()) {
            Log.w(TAG, "resetLibrary refused — a scan is in flight");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update in progress");
                    }
                });
            }
            return;
        }
        if (mResetOperationId != null) {
            Log.w(TAG, "resetLibrary refused — a reset is already "
                + "in flight");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Reset in progress");
                    }
                });
            }
            return;
        }

        mIsUpdating.set(true);
        mScanGeneration.incrementAndGet();
        mResetOperationId = OPERATION_LIBRARY_RESET;

        final String genreOperationId = mGenreOperationId;
        if (genreOperationId != null) {
            mGenreOperationId = null;
            ToastManager.cancelOperation(genreOperationId);
        }

        NavigationController.getInstance().beginPlaylistSync();

        Log.d(TAG, "Library reset started (mode=" + mode + ")");

        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay(
                    OPERATION_GENRE_UPDATE);

                Activity currentActivity =
                    ToastManager.getCurrentActivity();
                if (currentActivity != null
                        && !currentActivity.isFinishing()
                        && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(
                        currentActivity,
                        getLocaleContext().getString(
                            R.string.library_clearing),
                        "",
                        OPERATION_LIBRARY_RESET);
                } else {
                    Log.w(TAG, "No activity available for reset "
                        + "overlay");
                }
                startResetHeartbeatTicker(OPERATION_LIBRARY_RESET);
            }
        });

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performResetBarrier();
                } catch (final Exception exception) {
                    Log.e(TAG, "Reset barrier failed", exception);
                    final String message =
                        exception.getMessage() != null
                            ? exception.getMessage()
                            : "Reset failed";
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            postResetCompletion(
                                callback, false, message);
                        }
                    });
                    return;
                }

                cleanupTempCacheAsync();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        sendResetBroadcast(mode);
                        postResetCompletion(callback, true, null);
                    }
                });
            }
        });
    }

    // ============================================================================
    // Reset Internals
    // ============================================================================

    /**
     * Runs the write barrier: clears every content-scoped store and
     * nothing else.
     */
    private void performResetBarrier() {
        Log.d(TAG, "Reset barrier: clearing content");

        SongDatabase database = SongDatabase.getInstance(mContext);
        database.clearCache();
        database.clearLooseSongs();

        StorageAccessHelper.getInstance(mContext).clearAll();

        mContext.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_SELECTED_FOLDERS,
                new HashSet<String>())
            .apply();

        Log.d(TAG, "Reset barrier: content cleared");
    }

    /**
     * Sends the {@link #ACTION_LIBRARY_RESET} broadcast carrying the
     * mode as an extra.
     *
     * @param mode The scope of the reset
     */
    private void sendResetBroadcast(@NonNull ResetMode mode) {
        Intent intent = new Intent(ACTION_LIBRARY_RESET);
        intent.putExtra(EXTRA_PRESERVE_SETTINGS,
            mode == ResetMode.LIBRARY);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "LIBRARY_RESET broadcast sent (preserve_settings="
            + (mode == ResetMode.LIBRARY) + ")");
    }

    /**
     * Ends the reset: stops the heartbeat, clears both gates, pops
     * the reset overlay, ends the navigation operation, and invokes
     * the callback.
     *
     * @param callback Listener to invoke, or null
     * @param success True when the barrier committed
     * @param error Description of the failure, or null on success
     */
    private void postResetCompletion(
            @Nullable final ResetCallback callback,
            final boolean success,
            @Nullable final String error) {
        stopResetHeartbeatTicker();
        mResetOperationId = null;
        mIsUpdating.set(false);

        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_RESET);

        NavigationController.getInstance().endPlaylistSync();

        if (callback != null) {
            if (success) {
                callback.onComplete();
            } else {
                callback.onError(error != null
                    ? error : "Reset failed");
            }
        }

        Log.d(TAG, "Library reset "
            + (success ? "completed" : "failed"));
    }

    /**
     * Starts the reset heartbeat ticker.
     *
     * @param operationId ID of the reset operation
     */
    private void startResetHeartbeatTicker(
            @NonNull final String operationId) {
        final long token = mResetHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mResetHeartbeatToken.get() != token) {
                    return;
                }
                if (!ToastManager.isOperationRunning(operationId)) {
                    return;
                }
                ToastManager.heartbeat(operationId);
                mGenreHandler.postDelayed(
                    this, RESET_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current reset heartbeat ticker. Idempotent.
     */
    private void stopResetHeartbeatTicker() {
        mResetHeartbeatToken.incrementAndGet();
    }

    /**
     * Deletes leftover {@code temp_audio_*} and {@code backup_*}
     * files from the cache directory.
     */
    private void cleanupTempCacheAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File cacheDir = mContext.getCacheDir();
                    if (cacheDir == null
                            || !cacheDir.isDirectory()) {
                        return;
                    }
                    File[] files = cacheDir.listFiles();
                    if (files == null) {
                        return;
                    }
                    for (File file : files) {
                        if (file == null || !file.isFile()) {
                            continue;
                        }
                        String name = file.getName();
                        if (name.startsWith("temp_audio_")
                                || name.startsWith("backup_")) {
                            if (file.delete()) {
                                Log.d(TAG,
                                    "Deleted stale temp file: "
                                        + name);
                            }
                        }
                    }
                } catch (Exception exception) {
                    Log.w(TAG, "cleanupTempCache failed", exception);
                }
            }
        }).start();
    }

    // ============================================================================
    // Genre Loading Methods
    // ============================================================================

    /**
     * Triggers genre loading for every song whose genre is still
     * unknown, using the default progress text.
     */
    public void triggerGenreLoading() {
        triggerGenreLoading(null);
    }

    /**
     * Triggers genre loading for every song whose genre is still
     * unknown, optionally overriding the overlay message.
     *
     * <p>This is the hand-off point between a folder-update cycle
     * and genre loading. It releases the folder-update cycle's dim
     * overlay reason so the dim overlay dismisses and the genre
     * toast can take over. The playlist-sync operation itself has
     * already ended by the time this method is called; it is owned
     * by the scan, not by the genre-loading trigger.</p>
     *
     * <p>The overlay is shown synchronously in this method's own
     * turn, before the executor is dispatched. The caller is the
     * {@code ACTION_TRIGGER_GENRE_LOADING} receiver, whose
     * {@code onReceive} runs on the main looper, so the show is
     * already committed by the time the worker thread can consult
     * {@link ToastManager#isOperationRunning(String)}.</p>
     *
     * @param customMessage Caller-supplied overlay message, or null
     *        to use the resource text
     */
    public void triggerGenreLoading(
            @Nullable final String customMessage) {
        OverlayManager.hide(
            OverlayManager.REASON_FOLDER_UPDATE_CYCLE);

        if (mResetOperationId != null) {
            Log.d(TAG,
                "Genre loading refused — reset in progress");
            return;
        }
        if (mGenreOperationId != null) {
            Log.d(TAG,
                "Genre loading already in progress, skipping");
            return;
        }

        final String operationId = OPERATION_GENRE_UPDATE;
        final String initialMessage = customMessage != null
            ? customMessage
            : getLocaleContext().getString(
                R.string.library_loading_metadata);
        mGenreOperationId = operationId;

        Log.d(TAG, "Starting genre loading...");

        Activity currentActivity = ToastManager.getCurrentActivity();
        if (currentActivity != null
                && !currentActivity.isFinishing()
                && !currentActivity.isDestroyed()) {
            ToastManager.showPersistentOverlay(
                currentActivity,
                initialMessage,
                "",
                operationId);
        } else {
            Log.w(TAG,
                "No activity available for persistent overlay");
        }
        startGenreHeartbeatTicker(operationId);

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                runGenreLoad(operationId, customMessage);
            }
        });
    }

    /**
     * Runs the genre-load loop for the given operation.
     *
     * <p>The filter that selects the songs needing genres uses
     * {@link CharacterMapper#isUnknownGenre(String)}, so a song whose
     * genre is the app's current placeholder is recognised as
     * needing an update, and a song whose genre is a placeholder in
     * any supported language — written under a previous locale — is
     * recognised too.</p>
     *
     * @param operationId ID of the genre-load operation
     * @param customMessage Caller-supplied overlay message, or null
     */
    private void runGenreLoad(@NonNull final String operationId,
                              @Nullable final String customMessage) {
        final ArrayList<Song> allSongs =
            SongDatabase.getInstance(mContext).getAllSongs();

        final ArrayList<Song> songsNeedingGenres =
            new ArrayList<>();
        for (Song song : allSongs) {
            if (song != null
                    && CharacterMapper.isUnknownGenre(
                        song.getGenre())) {
                songsNeedingGenres.add(song);
            }
        }

        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            sendGenreUpdateBroadcast("COMPLETE", null, null, 0, 0);
            mGenreHandler.post(new Runnable() {
                @Override
                public void run() {
                    stopGenreHeartbeatTicker();
                    ToastManager.hidePersistentOverlay(operationId);
                    if (sApplication != null) {
                        NotificationController.getInstance(sApplication)
                            .dismissLibraryStatus(operationId);
                    }
                    mGenreOperationId = null;
                }
            });
            return;
        }

        Log.d(TAG, "Loading genres for "
            + songsNeedingGenres.size() + " songs");

        final SongDatabase database =
            SongDatabase.getInstance(mContext);
        int updatedCount = 0;
        final int total = songsNeedingGenres.size();
        long lastProgressTime = 0L;

        sendGenreUpdateBroadcast("START", null, null, 0, total);

        try {
            for (Song song : songsNeedingGenres) {
                if (!ToastManager.isOperationRunning(operationId)) {
                    Log.d(TAG, "Genre loading cancelled — exiting "
                        + "without completion");
                    mGenreOperationId = null;
                    return;
                }
                if (song == null
                        || TextUtils.isEmpty(song.getPath())) {
                    continue;
                }

                String realGenre =
                    CharacterMapper.getGenre(song.getPath());

                boolean hasRealGenre =
                    !CharacterMapper.isUnknownGenre(realGenre);

                if (hasRealGenre) {
                    Song updatedSong = new Song(
                        song.getTitle(),
                        song.getArtist(),
                        song.getAlbum(),
                        realGenre,
                        song.getPath(),
                        song.getDuration(),
                        song.getUri()
                    );

                    database.insertSong(updatedSong);
                    song.setGenre(realGenre);
                    updatedCount++;

                    sendGenreUpdateBroadcast("UPDATE",
                        song.getPath(), realGenre,
                        updatedCount, total);
                }

                long now = SystemClock.elapsedRealtime();
                if (now - lastProgressTime
                        >= PROGRESS_TIME_THRESHOLD_MS
                        || updatedCount == total
                        || updatedCount == 1) {
                    lastProgressTime = now;
                    final int currentUpdated = updatedCount;
                    final int currentTotal = total;
                    final String title = customMessage != null
                        ? customMessage
                        : getLocaleContext().getString(
                            R.string.library_loading_metadata);
                    final String body = currentUpdated
                        + "/" + currentTotal;
                    mGenreHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ToastManager.updatePersistentOverlay(
                                title, body, operationId);
                        }
                    });
                }
            }
        } finally {
            stopGenreHeartbeatTicker();
        }

        if (!ToastManager.isOperationRunning(operationId)) {
            Log.d(TAG, "Genre loading cancelled before completion");
            mGenreOperationId = null;
            return;
        }

        Log.d(TAG, "Genre loading completed: " + updatedCount
            + "/" + total + " songs updated");

        sendGenreUpdateBroadcast("COMPLETE", null, null,
            updatedCount, total);

        Intent refreshPlaylistIntent =
            new Intent(ACTION_PLAYLIST_REFRESH);
        mContext.sendBroadcast(refreshPlaylistIntent);

        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay(operationId);
                if (sApplication != null) {
                    NotificationController.getInstance(sApplication)
                        .dismissLibraryStatus(operationId);
                }
                mGenreOperationId = null;
            }
        });
    }

    /**
     * Returns whether genre loading is currently in flight.
     *
     * @return True while genre loading is running
     */
    public boolean isGenreLoading() {
        return mGenreOperationId != null;
    }

    /**
     * Starts the genre-loading heartbeat ticker.
     *
     * @param operationId ID of the genre-load operation
     */
    private void startGenreHeartbeatTicker(
            @NonNull final String operationId) {
        final long token = mGenreHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mGenreHeartbeatToken.get() != token) {
                    return;
                }
                if (!ToastManager.isOperationRunning(operationId)) {
                    return;
                }
                ToastManager.heartbeat(operationId);
                mGenreHandler.postDelayed(
                    this, GENRE_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current genre-loading heartbeat ticker. Idempotent.
     */
    private void stopGenreHeartbeatTicker() {
        mGenreHeartbeatToken.incrementAndGet();
    }

    /**
     * Sends a {@code GENRE_UPDATE} broadcast with the given
     * lifecycle values.
     *
     * @param status One of {@code START}, {@code UPDATE}, or
     *        {@code COMPLETE}
     * @param songPath Path of the song whose genre changed, or null
     * @param genre New genre value, or null
     * @param current Number of songs processed so far
     * @param total Total number of songs to process
     */
    private void sendGenreUpdateBroadcast(String status,
                                          String songPath,
                                          String genre,
                                          int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }

    /**
     * Registers the receiver for the trigger-genre-loading
     * broadcast.
     */
    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(
                        intent.getAction())) {
                    String customMessage =
                        intent.getStringExtra(EXTRA_TRIGGER_MESSAGE);
                    triggerGenreLoading(customMessage);
                }
            }
        };
        IntentFilter filter =
            new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        ContextCompat.registerReceiver(
            mContext, mTriggerGenreReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
        Log.d(TAG, "Trigger genre receiver registered");
    }

    /**
     * Unregisters the given receiver, ignoring any exception
     * raised by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    /**
     * Cancels any in-flight scan or reset, stops every heartbeat
     * ticker, unregisters the trigger receiver, and shuts down the
     * executor.
     */
    public void shutdown() {
        cancelUpdate();

        String genreOperationId = mGenreOperationId;
        if (genreOperationId != null) {
            ToastManager.cancelOperation(genreOperationId);
            mGenreOperationId = null;
        }

        mResetOperationId = null;

        stopGenreHeartbeatTicker();
        stopResetHeartbeatTicker();
        stopPlaylistSyncHeartbeat();

        unregisterReceiverSafely(mTriggerGenreReceiver);

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(
                        SHUTDOWN_TIMEOUT_MS,
                        TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG,
                        "Executor did not terminate in time, "
                            + "forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG,
                    "Executor shutdown interrupted", exception);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        sApplication = null;
        Log.d(TAG, "PlaylistManager shut down");
    }

    // ============================================================================
    // Internal Methods
    // ============================================================================

    /**
     * Starts the playlist-sync heartbeat ticker.
     *
     * <p>The ticker satisfies the {@link NavigationController}'s
     * declared liveness window for the full length of a scan. Each
     * tick re-posts itself after {@link #GENRE_HEARTBEAT_INTERVAL_MS}
     * milliseconds until {@link #stopPlaylistSyncHeartbeat()}
     * advances the token, at which point the running ticker exits on
     * its next iteration without re-posting.</p>
     */
    private void startPlaylistSyncHeartbeat() {
        final long token = mPlaylistSyncHeartbeatToken.incrementAndGet();
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mPlaylistSyncHeartbeatToken.get() != token) {
                    return;
                }
                NavigationController.getInstance().heartbeat(
                    NavigationController.Operation.PLAYLIST_SYNC);
                mMainHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current playlist-sync heartbeat ticker. Idempotent.
     */
    private void stopPlaylistSyncHeartbeat() {
        mPlaylistSyncHeartbeatToken.incrementAndGet();
    }

    /**
     * Runs a full folder scan on the executor, reports progress to
     * the given callback, and emits the standard broadcast sequence
     * when the scan finishes.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to suppress progress reporting
     */
    private void updatePlaylistInternal(
            @Nullable final UpdateCallback callback,
            final boolean silent) {
        if (mResetOperationId != null) {
            Log.w(TAG, "Update refused — reset in progress");
            if (callback != null) {
                callback.onError("Reset in progress");
            }
            return;
        }
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();
        startPlaylistSyncHeartbeat();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performScan(callback, silent, scanGeneration);
                } catch (final Exception exception) {
                    Log.e(TAG,
                        "Uncaught exception during playlist update",
                        exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(
                                    exception.getMessage() != null
                                        ? exception.getMessage()
                                        : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    stopPlaylistSyncHeartbeat();
                    NavigationController.getInstance()
                        .endPlaylistSync();
                    mIsUpdating.set(false);
                }
            }
        });
    }

    /**
     * Performs the scan across every selected folder, writes the
     * results to the database, and emits the standard broadcast
     * sequence.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to suppress progress reporting
     * @param scanGeneration Generation value captured at admission
     */
    private void performScan(
            @Nullable final UpdateCallback callback,
            final boolean silent,
            final long scanGeneration) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();

            boolean foundAnySongs = false;

            if (selectedFolders.isEmpty()) {
                SongDatabase database =
                    SongDatabase.getInstance(mContext);

                ArrayList<Song> looseSongs =
                    database.getLooseSongs();

                database.clearCache();

                if (!looseSongs.isEmpty()) {
                    database.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }

                final ArrayList<Song> songsAfterUpdate =
                    database.getAllSongs();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Intent refreshIntent =
                            new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);

                        Intent refreshDisplayIntent =
                            new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(
                            refreshDisplayIntent);

                        if (callback != null) {
                            callback.onComplete(
                                songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }

            final int totalFiles =
                countMusicFiles(selectedFolders);
            final AtomicInteger currentCount =
                new AtomicInteger(0);

            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }

            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get()
                        || mResetOperationId != null) {
                    return;
                }
                int foundInFolder = scanFolderFast(
                    Uri.parse(folderUriString),
                    newSongs, allFoundPaths, currentCount,
                    totalFiles, callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }

            if (!mIsUpdating.get() || mResetOperationId != null) {
                return;
            }

            SongDatabase database =
                SongDatabase.getInstance(mContext);

            if (mScanGeneration.get() != scanGeneration
                    || mResetOperationId != null) {
                return;
            }
            if (!newSongs.isEmpty()) {
                database.insertSongsBatch(newSongs);
            }

            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                final ArrayList<Song> currentSongs =
                    database.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onComplete(
                                currentSongs.size());
                        }
                    }
                });
                return;
            }

            if (mScanGeneration.get() != scanGeneration
                    || mResetOperationId != null) {
                return;
            }
            database.deleteSongsNotInSet(allFoundPaths, true);

            final ArrayList<Song> allSongsAfterUpdate =
                database.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();

            Intent refreshIntent =
                new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);

            Intent refreshDisplayIntent =
                new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);

            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }

                    Intent syncCompleteIntent =
                        new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);

        } catch (final Exception exception) {
            Log.e(TAG, "Update failed: "
                + exception.getMessage(), exception);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(
                            exception.getMessage() != null
                                ? exception.getMessage()
                                : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(exception);
        }
    }

    // ============================================================================
    // Folder and File Scanning
    // ============================================================================

    /**
     * Dispatches a folder scan to the path-based or name-based
     * query, depending on whether the folder URI encodes a
     * filesystem path.
     *
     * @param folderUri Folder URI to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks,
     *        or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found in this folder
     */
    private int scanFolderFast(@NonNull Uri folderUri,
                               @NonNull ArrayList<Song> newSongs,
                               @NonNull Set<String> allFoundPaths,
                               @NonNull AtomicInteger currentCount,
                               int totalFiles,
                               @Nullable UpdateCallback callback,
                               boolean silent) {
        if (!mIsUpdating.get() || mResetOperationId != null) {
            return 0;
        }

        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath,
                    newSongs, allFoundPaths, currentCount,
                    totalFiles, callback, silent);
            } else {
                String folderName =
                    getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(
                        folderName, newSongs, allFoundPaths,
                        currentCount, totalFiles, callback,
                        silent);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan error for folder: " + folderUri,
                exception);
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files under the given filesystem
     * path and adds the results to the given collections.
     *
     * @param folderPath Filesystem path of the folder to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks,
     *        or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found under the given path
     */
    private int queryMediaStoreFast(
            @NonNull String folderPath,
            @NonNull ArrayList<Song> newSongs,
            @NonNull Set<String> allFoundPaths,
            @NonNull AtomicInteger currentCount,
            int totalFiles,
            @Nullable final UpdateCallback callback,
            final boolean silent) {
        if (!mIsUpdating.get() || mResetOperationId != null) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0L};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION},
                selection,
                new String[] {normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst()
                    && mIsUpdating.get()
                    && mResetOperationId == null) {
                int pathColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                SongDatabase database =
                    SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()
                            || mResetOperationId != null) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong =
                            database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle =
                                cursor.getString(titleColumn);
                            String rawArtist =
                                cursor.getString(artistColumn);
                            String rawAlbum =
                                cursor.getString(albumColumn);
                            long duration = (durationColumn != -1L)
                                ? cursor.getLong(durationColumn)
                                : 0L;

                            String title = CharacterMapper
                                .cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex =
                                    fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(
                                        0, dotIndex);
                                }
                                title = CharacterMapper
                                    .cleanMusicMetadata(fileName);
                            }

                            String artist = CharacterMapper
                                .cleanMusicMetadata(rawArtist);

                            String album = CharacterMapper
                                .cleanMusicMetadata(rawAlbum);

                            String genre = null;

                            if (CharacterMapper
                                    .hasProblematicCharacters(title)
                                    || CharacterMapper
                                        .hasProblematicCharacters(
                                            artist)
                                    || CharacterMapper
                                        .hasProblematicCharacters(
                                            album)) {
                                Song parsedSong = CharacterMapper
                                    .getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist,
                                album, genre, filePath, duration,
                                null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG,
                            "Failed to process file: " + filePath,
                            exception);
                    }

                    final int currentValue =
                        currentCount.incrementAndGet();

                    long currentTime =
                        SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent
                        && callback != null
                        && (currentValue - lastProgress[0]
                                >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0]
                                >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null
                                        && mIsUpdating.get()
                                        && mResetOperationId
                                            == null) {
                                    callback.onProgress(
                                        finalCurrent,
                                        finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext()
                        && mIsUpdating.get()
                        && mResetOperationId == null);
            }
        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied scanning folder: "
                + folderPath, exception);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get()
                                && mResetOperationId == null) {
                            callback.onError("Permission denied "
                                + "accessing storage");
                        }
                    }
                });
            }
        } catch (Exception exception) {
            Log.e(TAG, "query error for folder: " + folderPath,
                exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files whose path contains the
     * given folder name as a segment and adds the results to the
     * given collections.
     *
     * @param folderName Name of the folder to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks,
     *        or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found under the given folder name
     */
    private int queryMediaStoreByNameFast(
            @NonNull String folderName,
            @NonNull ArrayList<Song> newSongs,
            @NonNull Set<String> allFoundPaths,
            @NonNull AtomicInteger currentCount,
            int totalFiles,
            @Nullable final UpdateCallback callback,
            final boolean silent) {
        if (!mIsUpdating.get() || mResetOperationId != null) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0L};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION},
                selection,
                new String[] {"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst()
                    && mIsUpdating.get()
                    && mResetOperationId == null) {
                int pathColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(
                    MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                SongDatabase database =
                    SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()
                            || mResetOperationId != null) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong =
                            database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle =
                                cursor.getString(titleColumn);
                            String rawArtist =
                                cursor.getString(artistColumn);
                            String rawAlbum =
                                cursor.getString(albumColumn);
                            long duration = (durationColumn != -1L)
                                ? cursor.getLong(durationColumn)
                                : 0L;

                            String title = CharacterMapper
                                .cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex =
                                    fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(
                                        0, dotIndex);
                                }
                                title = CharacterMapper
                                    .cleanMusicMetadata(fileName);
                            }

                            String artist = CharacterMapper
                                .cleanMusicMetadata(rawArtist);

                            String album = CharacterMapper
                                .cleanMusicMetadata(rawAlbum);

                            String genre = null;

                            if (CharacterMapper
                                    .hasProblematicCharacters(title)
                                    || CharacterMapper
                                        .hasProblematicCharacters(
                                            artist)
                                    || CharacterMapper
                                        .hasProblematicCharacters(
                                            album)) {
                                Song parsedSong = CharacterMapper
                                    .getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist,
                                album, genre, filePath, duration,
                                null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG,
                            "Failed to process file: " + filePath,
                            exception);
                    }

                    final int currentValue =
                        currentCount.incrementAndGet();

                    long currentTime =
                        SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent
                        && callback != null
                        && (currentValue - lastProgress[0]
                                >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0]
                                >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null
                                        && mIsUpdating.get()
                                        && mResetOperationId
                                            == null) {
                                    callback.onProgress(
                                        finalCurrent,
                                        finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext()
                        && mIsUpdating.get()
                        && mResetOperationId == null);
            }
        } catch (Exception exception) {
            Log.e(TAG, "query by name error for: " + folderName,
                exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Returns a copy of the folder URI set currently selected by
     * the user.
     *
     * @return A set containing every selected folder URI
     */
    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = preferences.getStringSet(
            KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (savedFolders != null) {
            result.addAll(savedFolders);
        }
        return result;
    }

    /**
     * Counts the music files MediaStore reports for the given
     * folders.
     *
     * @param selectedFolders Folder URIs to count
     * @return Total music files reported across every folder
     */
    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection =
            MediaStore.Audio.Media.IS_MUSIC + " != 0";

        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath =
                    getFolderPathFromUri(folderUri);

                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/")
                        ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND "
                        + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri,
                            new String[] {
                                MediaStore.Audio.Media.DATA
                            },
                            folderSelection,
                            new String[] {normalizedPath + "%"},
                            null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception exception) {
                                Log.w(TAG,
                                    "Failed to close count "
                                        + "cursor", exception);
                            }
                        }
                    }
                } else {
                    String folderName =
                        getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND "
                            + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri,
                                new String[] {
                                    MediaStore.Audio.Media.DATA
                                },
                                folderSelection,
                                new String[] {"%/"
                                    + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception exception) {
                                    Log.w(TAG, "Failed to close "
                                        + "count cursor", exception);
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "count error for folder: "
                    + folderUriString, exception);
            }
        }

        return total;
    }

    /**
     * Returns the filesystem path behind the given folder URI.
     *
     * <p>Delegates to
     * {@link StorageAccessHelper#getFolderPathFromUri(Uri)},
     * which handles both primary and removable storage and
     * consults the persisted URI-to-path mapping when one
     * exists.</p>
     *
     * @param uri Folder URI to inspect, or null
     * @return The filesystem path, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        return StorageAccessHelper.getInstance(mContext)
            .getFolderPathFromUri(uri);
    }

    /**
     * Returns the cleaned display name of the given folder URI.
     *
     * @param uri Folder URI to inspect, or null
     * @return The cleaned folder name, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(
                uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(
                    android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG,
                        "Failed to close folder name cursor",
                        exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null
            ? CharacterMapper.cleanString(name) : null;
    }
}