package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Scans the selected music folders through {@link MediaStore}, caches
 * the results in the song database, reads ID3 genres on a background
 * thread, and adds loose tracks opened from other apps.
 *
 * <p>A full scan runs in two phases. The fast scan queries MediaStore
 * for each selected folder and persists title, artist, album, and
 * duration; genre is left as {@code null} so the song row constructs
 * with the default placeholder and the UI can render immediately. Genre
 * loading reads the ID3 genre for every song whose genre is still
 * unknown and persists each result as it arrives.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns the scan-in-progress flag, the current scan
 * generation, the genre-loading flag, and the genre heartbeat token.
 * {@link NavigationController} owns the update-in-progress state that
 * every component queries. The persistent genre-loading overlay is owned
 * by this manager: it is shown with the {@code "GENRE_UPDATE"} operation
 * ID, kept alive by a self-scheduling heartbeat ticker that runs
 * independently of the ID3 read loop, and hidden by the same identifier
 * when the load completes. Every other component observes the
 * {@code GENRE_UPDATE} broadcasts read-only.</p>
 *
 * <h3>Ordering</h3>
 * <p>{@link #cancelUpdate()} increments {@link #mScanGeneration} and
 * clears {@link #mIsUpdating}. Every scan captures the generation value
 * at start and re-checks it immediately before each database write, so a
 * cancel that arrives between the loop's flag check and the write still
 * aborts the write. A scan therefore cannot reinsert songs into a
 * database that a concurrent full-library reset has just cleared.</p>
 *
 * <p>Every scan runs on the single-thread executor created in the
 * constructor. Callbacks and broadcast dispatch run on the main handler.
 * Genre loading runs on the same executor; its heartbeat ticker runs on
 * a dedicated main-thread handler.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>{@link #mIsUpdating} and {@link #mIsGenreLoading} are atomic flags
 * that refuse overlapping runs. Main-thread callbacks are dispatched
 * through {@link #mMainHandler} and {@link #mGenreHandler}. The
 * executor is shut down in {@link #shutdown()} with a bounded wait.</p>
 *
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistManager {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS = "selected_folders_uris";

    /** Number of songs between progress updates, for UI throttling. */
    private static final int PROGRESS_THRESHOLD = 10;

    /** Minimum time between progress updates in milliseconds. */
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500;

    /**
     * Interval between genre-loading heartbeats, safely below
     * {@link ToastManager}'s stuck timeout so a slow ID3 read cannot
     * starve the heartbeat and trip the stuck detector.
     */
    private static final long GENRE_HEARTBEAT_INTERVAL_MS = 500;

    /** Broadcast action emitted when a scan finishes. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action for genre update lifecycle events. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action that requests a playlist refresh. */
    public static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Broadcast action that requests genre loading. */
    public static final String ACTION_TRIGGER_GENRE_LOADING =
        "com.ark.llama.TRIGGER_GENRE_LOADING";

    /** Operation ID that owns the persistent genre-loading overlay. */
    private static final String OP_GENRE_UPDATE = "GENRE_UPDATE";

    /** Timeout for executor shutdown in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;

    /** Delay before playlist update broadcasts, in milliseconds. */
    private static final int UPDATE_BROADCAST_DELAY_MS = 200;

    /** Delay before the sync-complete broadcast, in milliseconds. */
    private static final int SYNC_COMPLETE_DELAY_MS = 400;

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    private static PlaylistManager sInstance;

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static synchronized PlaylistManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new PlaylistManager(context);
        }
        return sInstance;
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** Single-thread executor that runs every scan and genre load. */
    private final ExecutorService mExecutor;

    /** True while a scan is in flight. */
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);

    /** Handler for main-thread callbacks and broadcast dispatch. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /**
     * Generation counter for scan cancellation.
     *
     * <p>Incremented by {@link #cancelUpdate()}. Every scan captures the
     * value at start and re-checks it immediately before every database
     * write, so a cancel that arrives between the loop's flag check and
     * the write still aborts the write.</p>
     */
    @NonNull
    private final AtomicLong mScanGeneration = new AtomicLong(0L);

    // ========================================================================
    // Genre Loading Members
    // ========================================================================

    /** True while genre loading is in flight. */
    private final AtomicBoolean mIsGenreLoading = new AtomicBoolean(false);

    /** Handler for genre-loading ticks and overlay updates. */
    private final Handler mGenreHandler = new Handler(Looper.getMainLooper());

    /**
     * Token for the current genre-loading heartbeat ticker. Incremented
     * to invalidate an in-flight ticker when a run completes or is
     * superseded.
     */
    @NonNull
    private final AtomicLong mGenreHeartbeatToken = new AtomicLong(0L);

    /** Receiver for the trigger-genre-loading broadcast. */
    private BroadcastReceiver mTriggerGenreReceiver;

    // ========================================================================
    // Callback Interface
    // ========================================================================

    /**
     * Receives progress, completion, and error callbacks from a scan.
     */
    public interface UpdateCallback {

        /**
         * Called periodically while the scan runs.
         *
         * @param current Number of songs processed so far
         * @param total Total number of songs to process
         */
        void onProgress(int current, int total);

        /**
         * Called when the scan completes successfully.
         *
         * @param songCount Number of songs in the database after the scan
         */
        void onComplete(int songCount);

        /**
         * Called when the scan fails.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the singleton and registers its trigger receiver.
     *
     * @param context A context; the application context is retained
     */
    private PlaylistManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
    }

    // ========================================================================
    // Public API
    // ========================================================================

    /**
     * Runs a full folder scan and reports progress to the given callback.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }

    /**
     * Runs a full folder scan without reporting progress.
     */
    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }

    /**
     * Adds a single song as a loose track and triggers a targeted
     * playlist refresh.
     *
     * <p>No folder scan runs. The song is written to the database, the
     * library cache is refreshed through the standard broadcast
     * sequence, and the callback is notified of the result.</p>
     *
     * @param song Song to add as a loose track
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song,
                                       @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mScanGeneration.get() != scanGeneration) {
                        Log.d(TAG, "Loose-track addition cancelled before insert");
                        return;
                    }

                    SongDatabase database = SongDatabase.getInstance(mContext);
                    database.insertLooseSong(song);
                    Log.d(TAG, "Loose track added: " + song.getPath());

                    final ArrayList<Song> allSongs = database.getAllSongs();
                    final int totalSongCount = allSongs.size();

                    if (callback != null && !Thread.currentThread().isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }

                    Log.d(TAG, "Playlist updated with loose track. Total songs: "
                        + totalSongCount);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent softUpdateIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                            mContext.sendBroadcast(softUpdateIntent);

                            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(refreshDisplayIntent);

                            Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(syncCompleteIntent);

                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);

                } catch (final Exception exception) {
                    Log.e(TAG, "Failed to add loose track", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null
                                    ? exception.getMessage() : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    /**
     * Requests cancellation of any in-flight scan.
     *
     * <p>Clears {@link #mIsUpdating} and increments
     * {@link #mScanGeneration}. Every scan captures the generation value
     * at start and re-checks it immediately before each database write,
     * so a scan that has passed its last flag check but not yet reached
     * its write still aborts. This is the mechanism by which a
     * full-library reset guarantees that no scan reinserts songs after
     * the reset clears them.</p>
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
        mScanGeneration.incrementAndGet();
        Log.d(TAG, "Scan cancel requested (generation "
            + mScanGeneration.get() + ")");
    }

    /**
     * Returns whether a scan is currently in flight.
     *
     * @return True while a scan is running
     */
    public boolean isUpdating() {
        return mIsUpdating.get();
    }

    // ========================================================================
    // Genre Loading Methods
    // ========================================================================

    /**
     * Triggers genre loading for every song whose genre is still
     * unknown.
     *
     * <p>Identifies all songs that carry an unknown genre and processes
     * them on the single-thread executor, reading the real genre from
     * the ID3 tag through {@link CharacterMapper}. Each successful
     * update emits a {@code GENRE_UPDATE} broadcast with the status
     * {@code UPDATE} so listeners can refresh the specific row without a
     * full reload.</p>
     *
     * <p>The persistent overlay is owned by this method for the entire
     * loading lifetime. It is shown with the {@code "GENRE_UPDATE"}
     * operation ID, and a self-scheduling heartbeat ticker started in
     * the same post resets {@link ToastManager}'s stuck timer every
     * {@link #GENRE_HEARTBEAT_INTERVAL_MS} milliseconds independently
     * of the ID3 read loop. The ticker is invalidated on
     * completion.</p>
     *
     * <p>Every call to {@link ToastManager#updatePersistentOverlay} made
     * from this method carries {@link #OP_GENRE_UPDATE} as its ownership
     * token, so a stale progress tick from a run that has already been
     * superseded cannot refresh an overlay that a newer operation has
     * taken over.</p>
     */
    public void triggerGenreLoading() {
        if (mIsGenreLoading.getAndSet(true)) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        Log.d(TAG, "Starting genre loading...");

        final ArrayList<Song> allSongs = SongDatabase.getInstance(mContext).getAllSongs();

        final ArrayList<Song> songsNeedingGenres = new ArrayList<>();
        for (Song song : allSongs) {
            if (song != null && ("Unknown Genre".equals(song.getGenre())
                                 || song.getGenre() == null
                                 || song.getGenre().isEmpty())) {
                songsNeedingGenres.add(song);
            }
        }

        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update");
            mIsGenreLoading.set(false);
            return;
        }

        Log.d(TAG, "Loading genres for " + songsNeedingGenres.size() + " songs");

        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null
                        && !currentActivity.isFinishing()
                        && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity,
                        "Loading metadata... 0/" + songsNeedingGenres.size(),
                        OP_GENRE_UPDATE);
                } else {
                    Log.w(TAG, "No activity available for persistent overlay");
                }
                startGenreHeartbeatTicker();
            }
        });

        sendGenreUpdateBroadcast("START", null, null, 0, songsNeedingGenres.size());

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final SongDatabase database = SongDatabase.getInstance(mContext);
                int updatedCount = 0;
                final int total = songsNeedingGenres.size();
                long lastProgressTime = 0;

                try {
                    for (Song song : songsNeedingGenres) {
                        if (song == null || TextUtils.isEmpty(song.getPath())) {
                            continue;
                        }

                        String realGenre = CharacterMapper.getGenre(song.getPath());

                        boolean hasRealGenre = (realGenre != null
                            && !realGenre.isEmpty()
                            && !"Unknown Genre".equals(realGenre));

                        if (hasRealGenre) {
                            Song updatedSong = new Song(
                                song.getTitle(),
                                song.getArtist(),
                                song.getAlbum(),
                                realGenre,
                                song.getPath(),
                                song.getDuration(),
                                song.getUri()
                            );

                            database.insertSong(updatedSong);
                            song.setGenre(realGenre);
                            updatedCount++;

                            sendGenreUpdateBroadcast("UPDATE", song.getPath(),
                                realGenre, updatedCount, total);

                            Log.d(TAG, "Genre updated: " + song.getTitle()
                                + " -> " + realGenre);
                        }

                        long now = SystemClock.elapsedRealtime();
                        if (now - lastProgressTime >= PROGRESS_TIME_THRESHOLD_MS
                                || updatedCount == total
                                || updatedCount == 1) {
                            lastProgressTime = now;
                            final int currentUpdated = updatedCount;
                            final int currentTotal = total;
                            mGenreHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    ToastManager.updatePersistentOverlay(
                                        "Loading metadata... " + currentUpdated
                                            + "/" + currentTotal,
                                        OP_GENRE_UPDATE);
                                }
                            });
                        }
                    }
                } finally {
                    stopGenreHeartbeatTicker();
                }

                Log.d(TAG, "Genre loading completed: " + updatedCount + "/"
                    + total + " songs updated");

                sendGenreUpdateBroadcast("COMPLETE", null, null, updatedCount, total);

                Intent forceRefreshIntent = new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                mContext.sendBroadcast(forceRefreshIntent);

                mGenreHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay(OP_GENRE_UPDATE);
                        mIsGenreLoading.set(false);
                    }
                });
            }
        });
    }

    /**
     * Returns whether genre loading is currently in flight.
     *
     * @return True while genre loading is running
     */
    public boolean isGenreLoading() {
        return mIsGenreLoading.get();
    }

    /**
     * Starts the genre-loading heartbeat ticker.
     *
     * <p>The ticker resets {@link ToastManager}'s stuck timer every
     * {@link #GENRE_HEARTBEAT_INTERVAL_MS} milliseconds independently of
     * the ID3 read loop, so a slow read cannot starve the heartbeat and
     * trip the stuck detector. The ticker carries
     * {@link #OP_GENRE_UPDATE} as its ownership token, so it is refused
     * once another operation has taken over the overlay.</p>
     */
    private void startGenreHeartbeatTicker() {
        final long token = mGenreHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mGenreHeartbeatToken.get() != token) {
                    return;
                }
                ToastManager.heartbeat(OP_GENRE_UPDATE);
                mGenreHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current genre-loading heartbeat ticker by invalidating
     * its token. Idempotent.
     */
    private void stopGenreHeartbeatTicker() {
        mGenreHeartbeatToken.incrementAndGet();
    }

    /**
     * Sends a {@code GENRE_UPDATE} broadcast with the given lifecycle
     * values.
     *
     * @param status Lifecycle status: {@code START}, {@code UPDATE}, or
     *        {@code COMPLETE}
     * @param songPath Path of the song the update applies to, or null
     * @param genre New genre value, or null
     * @param current Number of genres updated so far
     * @param total Total number of songs in the genre load
     */
    private void sendGenreUpdateBroadcast(String status, String songPath,
                                          String genre, int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }

    /**
     * Registers the receiver for the trigger-genre-loading broadcast.
     */
    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(intent.getAction())) {
                    triggerGenreLoading();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        mContext.registerReceiver(mTriggerGenreReceiver, filter);
        Log.d(TAG, "Trigger genre receiver registered");
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    /**
     * Cancels any in-flight scan, stops the heartbeat ticker, unregisters
     * the trigger receiver, and shuts down the executor.
     */
    public void shutdown() {
        cancelUpdate();

        stopGenreHeartbeatTicker();

        unregisterReceiverSafely(mTriggerGenreReceiver);

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        Log.d(TAG, "PlaylistManager shut down");
    }

    // ========================================================================
    // Internal Methods
    // ========================================================================

    /**
     * Runs a full folder scan on the executor, reports progress to the
     * given callback, and emits the standard broadcast sequence when the
     * scan finishes.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to skip progress callbacks
     */
    private void updatePlaylistInternal(@Nullable final UpdateCallback callback,
                                        final boolean silent) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performScan(callback, silent, scanGeneration);
                } catch (final Exception exception) {
                    Log.e(TAG, "Uncaught exception during playlist update", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null
                                    ? exception.getMessage()
                                    : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }
        });
    }

    /**
     * Performs the scan across every selected folder, writes the results
     * to the database, and emits the standard broadcast sequence.
     *
     * <p>When no folders are selected, the cache is rebuilt from the
     * loose-tracks table. When no songs are found, the existing playlist
     * is preserved. The generation is re-checked before each database
     * write so a cancel aborts mid-scan.</p>
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to skip progress callbacks
     * @param scanGeneration Generation value captured at the start of the
     *        run
     */
    private void performScan(@Nullable final UpdateCallback callback,
                             final boolean silent,
                             final long scanGeneration) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();

            boolean foundAnySongs = false;

            if (selectedFolders.isEmpty()) {
                SongDatabase database = SongDatabase.getInstance(mContext);

                ArrayList<Song> looseSongs = database.getLooseSongs();

                database.clearCache();

                if (!looseSongs.isEmpty()) {
                    database.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }

                final ArrayList<Song> songsAfterUpdate = database.getAllSongs();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);

                        Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(refreshDisplayIntent);

                        if (callback != null) {
                            callback.onComplete(songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }

            final int totalFiles = countMusicFiles(selectedFolders);
            final AtomicInteger currentCount = new AtomicInteger(0);

            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }

            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get()) {
                    Log.d(TAG, "Update cancelled during scanning");
                    return;
                }
                int foundInFolder = scanFolderFast(Uri.parse(folderUriString),
                    newSongs, allFoundPaths, currentCount, totalFiles,
                    callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }

            if (!mIsUpdating.get()) {
                Log.d(TAG, "Update cancelled after scanning");
                return;
            }

            // Re-check the generation before the batch insert. A cancel
            // that arrived between the flag check above and this point
            // would otherwise be missed, and the scan would reinsert songs
            // into a database that a concurrent full-library reset has
            // just cleared.
            if (mScanGeneration.get() != scanGeneration) {
                Log.d(TAG, "Scan cancelled before batch insert, aborting");
                return;
            }

            SongDatabase database = SongDatabase.getInstance(mContext);

            if (!newSongs.isEmpty()) {
                database.insertSongsBatch(newSongs);
                Log.d(TAG, "Inserted " + newSongs.size() + " new songs");
            }

            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                Log.w(TAG, "No songs found in selected folders - "
                    + "preserving existing playlist");
                final ArrayList<Song> currentSongs = database.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onComplete(currentSongs.size());
                        }
                    }
                });
                return;
            }

            // Re-check the generation again before the delete pass. The
            // delete is a database write and must respect the same
            // cancellation contract as the insert above.
            if (mScanGeneration.get() != scanGeneration) {
                Log.d(TAG, "Scan cancelled before delete pass, aborting");
                return;
            }

            database.deleteSongsNotInSet(allFoundPaths, true);

            final ArrayList<Song> allSongsAfterUpdate = database.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();

            Log.d(TAG, "Phase 1 completed. Total songs: " + totalSongCount);

            Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);

            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);

            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);

        } catch (final Exception exception) {
            Log.e(TAG, "Update failed: " + exception.getMessage(), exception);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(exception.getMessage() != null
                            ? exception.getMessage() : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(exception);
        }
    }

    // ========================================================================
    // Folder and File Scanning
    // ========================================================================

    /**
     * Scans a single folder URI and adds its results to the given list.
     *
     * @param folderUri Folder URI to scan
     * @param newSongs List that receives the newly found songs
     * @param allFoundPaths Set that receives every path found in the
     *        folder
     * @param currentCount Counter of songs processed so far
     * @param totalFiles Total number of songs to process
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to skip progress callbacks
     * @return Number of songs found in this folder
     */
    private int scanFolderFast(@NonNull Uri folderUri,
                               @NonNull ArrayList<Song> newSongs,
                               @NonNull Set<String> allFoundPaths,
                               @NonNull AtomicInteger currentCount,
                               int totalFiles,
                               @Nullable UpdateCallback callback,
                               boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath, newSongs,
                    allFoundPaths, currentCount, totalFiles, callback, silent);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(folderName, newSongs,
                        allFoundPaths, currentCount, totalFiles, callback, silent);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan error for folder: " + folderUri, exception);
        }
        return songsFound;
    }

    /**
     * Queries {@link MediaStore} for music files under the given path,
     * adds them to the given list, and reports progress.
     *
     * @param folderPath Folder path to scan
     * @param newSongs List that receives the newly found songs
     * @param allFoundPaths Set that receives every path found
     * @param currentCount Counter of songs processed so far
     * @param totalFiles Total number of songs to process
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to skip progress callbacks
     * @return Number of songs found
     */
    private int queryMediaStoreFast(@NonNull String folderPath,
                                    @NonNull ArrayList<Song> newSongs,
                                    @NonNull Set<String> allFoundPaths,
                                    @NonNull AtomicInteger currentCount,
                                    int totalFiles,
                                    @Nullable final UpdateCallback callback,
                                    final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[] {normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1)
                                ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title)
                                    || CharacterMapper.hasProblematicCharacters(artist)
                                    || CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre,
                                filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null
                        && (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder: " + folderPath + ", found "
                    + processedCount + " songs");
            }
        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied scanning folder: " + folderPath, exception);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get()) {
                            callback.onError("Permission denied accessing storage");
                        }
                    }
                });
            }
        } catch (Exception exception) {
            Log.e(TAG, "query error for folder: " + folderPath, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    /**
     * Queries {@link MediaStore} for music files whose path contains the
     * given folder name, adds them to the given list, and reports
     * progress.
     *
     * @param folderName Folder name to scan
     * @param newSongs List that receives the newly found songs
     * @param allFoundPaths Set that receives every path found
     * @param currentCount Counter of songs processed so far
     * @param totalFiles Total number of songs to process
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to skip progress callbacks
     * @return Number of songs found
     */
    private int queryMediaStoreByNameFast(@NonNull String folderName,
                                          @NonNull ArrayList<Song> newSongs,
                                          @NonNull Set<String> allFoundPaths,
                                          @NonNull AtomicInteger currentCount,
                                          int totalFiles,
                                          @Nullable final UpdateCallback callback,
                                          final boolean silent) {
        if (!mIsUpdating.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[] {"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1)
                                ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title)
                                    || CharacterMapper.hasProblematicCharacters(artist)
                                    || CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre,
                                filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null
                        && (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get());

                Log.d(TAG, "Scanned folder by name: " + folderName + ", found "
                    + processedCount + " songs");
            }
        } catch (Exception exception) {
            Log.e(TAG, "query by name error for: " + folderName, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns a copy of the persisted set of selected folder URI
     * strings.
     *
     * @return A new set containing every selected folder URI
     */
    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = preferences.getStringSet(KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (savedFolders != null) {
            result.addAll(savedFolders);
        }
        return result;
    }

    /**
     * Counts the music files in the given folders through
     * {@link MediaStore}.
     *
     * @param selectedFolders Folder URI strings to count
     * @return The total number of music files in the folders
     */
    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);

                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/")
                        ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND "
                        + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri,
                            new String[] {MediaStore.Audio.Media.DATA},
                            folderSelection, new String[] {normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception exception) {
                                Log.w(TAG, "Failed to close count cursor", exception);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND "
                            + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri,
                                new String[] {MediaStore.Audio.Media.DATA},
                                folderSelection,
                                new String[] {"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception exception) {
                                    Log.w(TAG, "Failed to close count cursor", exception);
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "count error for folder: " + folderUriString, exception);
            }
        }

        Log.d(TAG, "Total music files counted: " + total);
        return total;
    }

    /**
     * Returns the filesystem path encoded in the given primary-storage
     * tree URI, or null when the URI does not refer to primary storage.
     *
     * @param uri Folder URI to inspect, or null
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            int startIndex = uriString.indexOf("primary:") + 8;
            String subPath = uriString.substring(startIndex);
            if (subPath.contains("%2F")) {
                subPath = subPath.replace("%2F", "/");
            }
            if (subPath.contains("/tree/")) {
                subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
            }
            if (subPath.contains("/document/")) {
                subPath = subPath.substring(subPath.indexOf("/document/") + 10);
            }
            String path = "/storage/emulated/0/" + subPath;
            path = Uri.decode(path);
            while (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            return path;
        }
        return null;
    }

    /**
     * Returns the cleaned display name of the given folder URI, or null
     * when it cannot be determined.
     *
     * @param uri Folder URI to inspect, or null
     * @return The cleaned folder name, or null
     */
    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(
                    android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null ? CharacterMapper.cleanString(name) : null;
    }
}