package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Scans the selected music folders through {@link MediaStore}, caches
 * the results in the song database, reads ID3 genres on a background
 * thread, adds loose tracks opened from other apps, and owns the
 * full-library reset.
 *
 * <p>A full scan runs in two phases. The fast scan queries MediaStore
 * for each selected folder and persists title, artist, album, and
 * duration; genre is left as {@code null} so the song row constructs
 * with the default placeholder and the UI can render immediately. Genre
 * loading reads the ID3 genre for every song whose genre is still
 * unknown and persists each result as it arrives.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns four flags: the scan-in-progress flag, the
 * genre-loading flag, the reset-in-progress flag, and the current scan
 * generation. {@link NavigationController} owns the update-in-progress
 * state that every component queries.</p>
 *
 * <p>The persistent overlays used for progress reporting are owned by
 * this manager. Genre loading shows its overlay with the
 * {@code "GENRE_UPDATE"} operation ID and heartbeats it independently of
 * the ID3 read loop. Library reset shows its overlay with the
 * {@code "LIBRARY_RESET"} operation ID and heartbeats it independently of
 * the barrier. Every other component observes the {@code GENRE_UPDATE}
 * and {@code LIBRARY_RESET} broadcasts read-only.</p>
 *
 * <h3>Genre Loading Threading</h3>
 * <p>Genre loading runs entirely on the single-thread executor. The
 * prologue — reading the full song list and filtering out the rows that
 * already have a genre — is O(n) in the library size and runs on the
 * executor as well. Only the overlay show and the overlay updates run
 * on the main handler. The prologue previously ran on the calling
 * thread, which is the main thread; on a multi-thousand-song library it
 * blocked the main thread before the genre overlay had a chance to
 * render, leaving the sync window uncovered.</p>
 *
 * <h3>The reset contract</h3>
 * <p>{@link #resetLibrary(ResetMode, ResetCallback)} runs a full library
 * reset. Its structure follows four rules:</p>
 * <ul>
 *   <li><b>One owner.</b> The reset has a beginning, a middle, and an
 *       end, and this manager owns all three. It is not a step in some
 *       activity's click handler.</li>
 *   <li><b>One write barrier.</b> The database and the SAF mappings are
 *       cleared on the executor, in one place, before any component is
 *       told the reset happened. No reader observes a half-cleared
 *       store.</li>
 *   <li><b>One invalidation broadcast.</b> After the barrier, a single
 *       {@link #ACTION_LIBRARY_RESET} broadcast tells every cache owner
 *       to drop its song-derived state. The reset does not know who the
 *       owners are; the owners listen for the signal.</li>
 *   <li><b>One completion signal.</b> The operation ends when its work
 *       completes, not when a timer expires. The callback fires after
 *       the barrier and after the broadcast dispatches.</li>
 * </ul>
 *
 * <h3>Receiver contract</h3>
 * <p>Every component that holds a {@code MusicLibrary} instance, an
 * album art cache, a displayed playlist, or any other song-derived state
 * must register a receiver for {@link #ACTION_LIBRARY_RESET} in
 * {@code onCreate} and unregister it in {@code onDestroy}. The receiver
 * invalidates the component's song-derived state and, where relevant,
 * applies the empty state. The receiver does not write to the database
 * and does not send further broadcasts; {@code PlaylistManager} owns the
 * reset from start to finish.</p>
 *
 * <h3>Ordering</h3>
 * <p>{@link #cancelUpdate()} increments {@link #mScanGeneration} and
 * clears {@link #mIsUpdating}. Every scan captures the generation value
 * at start and re-checks it immediately before each database write, so a
 * cancel that arrives between the loop's flag check and the write still
 * aborts the write.</p>
 *
 * <p>Every scan runs on the single-thread executor created in the
 * constructor. Callbacks and broadcast dispatch run on the main handler.
 * Genre loading and library reset run on the same executor; their
 * heartbeat tickers run on a dedicated main-thread handler.</p>
 *
 * <p>{@code SYNC_COMPLETE} is emitted exactly once per scan, from
 * {@code performScan}'s happy path, after the caller's
 * {@code onComplete} has returned. The scan's {@code finally} block
 * releases the navigation operation and clears the update flag; it does
 * not emit {@code SYNC_COMPLETE}. Emitting from both places fired the
 * broadcast before {@code onComplete} ran and caused every receiver to
 * reload its state twice.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>{@link #mIsUpdating}, {@link #mIsGenreLoading}, and
 * {@link #mIsResetting} are atomic flags that refuse overlapping runs.
 * Main-thread callbacks are dispatched through {@link #mMainHandler} and
 * {@link #mGenreHandler}. The executor is shut down in
 * {@link #shutdown()} with a bounded wait.</p>
 *
 * @see MusicLibrary
 * @see SongDatabase
 * @see CharacterMapper
 * @see NavigationController
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistManager {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the set of selected folder URI strings. */
    private static final String KEY_SELECTED_FOLDERS = "selected_folders_uris";

    /** Number of songs between progress updates, for UI throttling. */
    private static final int PROGRESS_THRESHOLD = 10;

    /** Minimum time between progress updates in milliseconds. */
    private static final long PROGRESS_TIME_THRESHOLD_MS = 500;

    /**
     * Interval between genre-loading heartbeats, safely below
     * {@link ToastManager}'s stuck timeout so a slow ID3 read cannot
     * starve the heartbeat and trip the stuck detector.
     */
    private static final long GENRE_HEARTBEAT_INTERVAL_MS = 500;

    /**
     * Interval between library-reset heartbeats. Same reasoning as
     * {@link #GENRE_HEARTBEAT_INTERVAL_MS}: the barrier is short but a
     * large library can take longer than
     * {@link ToastManager}'s stuck timeout, and the overlay must not
     * appear stuck.
     */
    private static final long RESET_HEARTBEAT_INTERVAL_MS = 500;

    /** Broadcast action emitted when a scan finishes. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action for genre update lifecycle events. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /**
     * Broadcast action emitted when the library has been reset. Every
     * component that holds song-derived state must register a receiver
     * for this action and invalidate its state.
     */
    public static final String ACTION_LIBRARY_RESET = "LIBRARY_RESET";

    /** Intent extra carrying the preserve-settings flag. */
    public static final String EXTRA_PRESERVE_SETTINGS = "preserve_settings";

    /** Broadcast action that requests a playlist refresh. */
    public static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Broadcast action that requests genre loading. */
    public static final String ACTION_TRIGGER_GENRE_LOADING =
        "com.ark.llama.TRIGGER_GENRE_LOADING";

    /** Operation ID that owns the persistent genre-loading overlay. */
    private static final String OPERATION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Operation ID that owns the persistent library-reset overlay. */
    private static final String OPERATION_LIBRARY_RESET = "LIBRARY_RESET";

    /** Timeout for executor shutdown in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;

    /** Delay before playlist update broadcasts, in milliseconds. */
    private static final int UPDATE_BROADCAST_DELAY_MS = 200;

    /** Delay before the sync-complete broadcast, in milliseconds. */
    private static final int SYNC_COMPLETE_DELAY_MS = 400;

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    private static PlaylistManager sInstance;

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static synchronized PlaylistManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new PlaylistManager(context);
        }
        return sInstance;
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Application context. */
    private final Context mContext;

    /** Single-thread executor that runs every scan, genre load, and reset. */
    private final ExecutorService mExecutor;

    /** True while a scan is in flight. */
    private final AtomicBoolean mIsUpdating = new AtomicBoolean(false);

    /** True while a reset is in flight. */
    private final AtomicBoolean mIsResetting = new AtomicBoolean(false);

    /** Handler for main-thread callbacks and broadcast dispatch. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /**
     * Generation counter for scan cancellation.
     *
     * <p>Incremented by {@link #cancelUpdate()} and
     * {@link #resetLibrary(ResetMode, ResetCallback)}. Every scan
     * captures the value at start and re-checks it immediately before
     * every database write, so a cancel that arrives between the loop's
     * flag check and the write still aborts the write.</p>
     */
    @NonNull
    private final AtomicLong mScanGeneration = new AtomicLong(0L);

    // ========================================================================
    // Genre Loading Members
    // ========================================================================

    /** True while genre loading is in flight. */
    private final AtomicBoolean mIsGenreLoading = new AtomicBoolean(false);

    /** Handler for genre-loading ticks and overlay updates. */
    private final Handler mGenreHandler = new Handler(Looper.getMainLooper());

    /**
     * Token for the current genre-loading heartbeat ticker. Incremented
     * to invalidate an in-flight ticker when a run completes or is
     * superseded.
     */
    @NonNull
    private final AtomicLong mGenreHeartbeatToken = new AtomicLong(0L);

    /**
     * Token for the current reset heartbeat ticker. Incremented to
     * invalidate an in-flight ticker when a run completes or is
     * superseded.
     */
    @NonNull
    private final AtomicLong mResetHeartbeatToken = new AtomicLong(0L);

    /** Receiver for the trigger-genre-loading broadcast. */
    private BroadcastReceiver mTriggerGenreReceiver;

    // ========================================================================
    // Callback Interfaces
    // ========================================================================

    /**
     * Receives progress, completion, and error callbacks from a scan.
     */
    public interface UpdateCallback {

        /**
         * Called periodically while the scan runs.
         *
         * @param current Number of songs processed so far
         * @param total Total number of songs to process
         */
        void onProgress(int current, int total);

        /**
         * Called when the scan completes successfully.
         *
         * @param songCount Number of songs in the database after the scan
         */
        void onComplete(int songCount);

        /**
         * Called when the scan fails.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    /**
     * Receives the outcome of a library reset.
     */
    public interface ResetCallback {

        /**
         * Called when the reset has completed. Every cache owner has
         * been notified through {@link #ACTION_LIBRARY_RESET} by the
         * time this runs.
         */
        void onComplete();

        /**
         * Called when the reset failed. The library may be in a partial
         * state; callers should surface the error to the user.
         *
         * @param error Description of the failure
         */
        void onError(@NonNull String error);
    }

    // ========================================================================
    // Reset Mode
    // ========================================================================

    /**
     * The scope of a library reset.
     */
    public enum ResetMode {

        /**
         * Clear the songs and loose tracks; preserve user settings. The
         * reset clears the database tables, the SAF folder URI mappings,
         * and the folder-selection preference. It does not clear the
         * theme, the equalizer settings, the repeat mode, the shuffle
         * flag, or the sort mode.
         */
        LIBRARY,

        /**
         * Clear the songs, loose tracks, and user settings. Same as
         * {@link #LIBRARY} but the {@code LIBRARY_RESET} broadcast
         * carries {@code preserve_settings = false} so the receivers
         * also clear the settings keys they own.
         */
        FACTORY
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the singleton and registers its trigger receiver.
     *
     * @param context A context; the application context is retained
     */
    private PlaylistManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mExecutor = Executors.newSingleThreadExecutor();
        registerTriggerGenreReceiver();
    }

    // ========================================================================
    // Public API - Scans
    // ========================================================================

    /**
     * Runs a full folder scan and reports progress to the given callback.
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void updatePlaylist(@Nullable UpdateCallback callback) {
        updatePlaylistInternal(callback, false);
    }

    /**
     * Runs a full folder scan without reporting progress.
     */
    public void updatePlaylistSilent() {
        updatePlaylistInternal(null, true);
    }

    /**
     * Adds a single song as a loose track and triggers a targeted
     * playlist refresh.
     *
     * <p>No folder scan runs. The song is written to the database, the
     * library cache is refreshed through the standard broadcast
     * sequence, and the callback is notified of the result.</p>
     *
     * @param song Song to add as a loose track
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     */
    public void addLooseTrackAndUpdate(@NonNull final Song song,
                                       @Nullable final UpdateCallback callback) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update already in progress");
                    }
                });
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mScanGeneration.get() != scanGeneration) {
                        Log.d(TAG, "Loose-track addition cancelled before insert");
                        return;
                    }

                    SongDatabase database = SongDatabase.getInstance(mContext);
                    database.insertLooseSong(song);
                    Log.d(TAG, "Loose track added: " + song.getPath());

                    final ArrayList<Song> allSongs = database.getAllSongs();
                    final int totalSongCount = allSongs.size();

                    if (callback != null && !Thread.currentThread().isInterrupted()) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onProgress(1, 1);
                            }
                        });
                    }

                    Log.d(TAG, "Playlist updated with loose track. Total songs: "
                        + totalSongCount);

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent softUpdateIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                            mContext.sendBroadcast(softUpdateIntent);

                            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                            mContext.sendBroadcast(refreshDisplayIntent);

                            Intent syncCompleteIntent = new Intent("SYNC_COMPLETE");
                            mContext.sendBroadcast(syncCompleteIntent);

                            if (callback != null) {
                                callback.onComplete(totalSongCount);
                            }
                        }
                    }, UPDATE_BROADCAST_DELAY_MS);

                } catch (final Exception exception) {
                    Log.e(TAG, "Failed to add loose track", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null
                                    ? exception.getMessage() : "Unknown error");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    // SYNC_COMPLETE is emitted from the happy path above,
                    // after the callback's onComplete has returned. The
                    // early emit that used to live here fired before
                    // onComplete and caused every receiver to reload its
                    // state twice.
                }
            }
        });
    }

    /**
     * Requests cancellation of any in-flight scan.
     *
     * <p>Clears {@link #mIsUpdating} and increments
     * {@link #mScanGeneration}. Every scan captures the generation value
     * at start and re-checks it immediately before each database write,
     * so a scan that has passed its last flag check but not yet reached
     * its write still aborts.</p>
     */
    public void cancelUpdate() {
        mIsUpdating.set(false);
        mScanGeneration.incrementAndGet();
        Log.d(TAG, "Scan cancel requested (generation "
            + mScanGeneration.get() + ")");
    }

    /**
     * Returns whether a scan is currently in flight.
     *
     * @return True while a scan is running
     */
    public boolean isUpdating() {
        return mIsUpdating.get();
    }

    /**
     * Returns whether a reset is currently in flight.
     *
     * @return True while a reset is running
     */
    public boolean isResetting() {
        return mIsResetting.get();
    }

    // ========================================================================
    // Public API - Library Reset
    // ========================================================================

    /**
     * Runs a full library reset.
     *
     * <p>The reset has four phases, in this order:</p>
     * <ol>
     *   <li><b>Admission.</b> The method refuses when a scan or another
     *       reset is already in flight. It sets {@link #mIsUpdating} and
     *       {@link #mIsResetting} together, so no scan and no second
     *       reset can start while it runs.</li>
     *   <li><b>Preparation.</b> It cancels the genre loader, hides the
     *       genre overlay, takes the {@link NavigationController}
     *       operation, and shows the reset overlay.</li>
     *   <li><b>Barrier.</b> On the executor, it clears the database
     *       tables, the SAF folder mappings, and the folder-selection
     *       preference. Everything above is content. No user settings
     *       are touched.</li>
     *   <li><b>Dispatch and completion.</b> On the main handler, it
     *       sends {@link #ACTION_LIBRARY_RESET}, then clears the flags,
     *       hides the reset overlay, ends the navigation operation, and
     *       invokes the callback.</li>
     * </ol>
     *
     * @param mode The scope of the reset
     * @param callback Listener that receives the outcome, or null
     */
    public void resetLibrary(@NonNull final ResetMode mode,
                             @Nullable final ResetCallback callback) {
        // Admission.
        if (mIsUpdating.get()) {
            Log.w(TAG, "resetLibrary refused — a scan is in flight");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Update in progress");
                    }
                });
            }
            return;
        }
        if (!mIsResetting.compareAndSet(false, true)) {
            Log.w(TAG, "resetLibrary refused — a reset is already in flight");
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onError("Reset in progress");
                    }
                });
            }
            return;
        }

        // We are committed. Take the scan gate and bump the generation
        // so any scan that was scheduled but has not started yet will
        // abort at its next generation check.
        mIsUpdating.set(true);
        mScanGeneration.incrementAndGet();

        // Cancel the genre loader and take the navigation operation.
        // The reset is content-changing work, so it uses the same
        // button-group gate that scans use.
        stopGenreHeartbeatTicker();
        mIsGenreLoading.set(false);
        NavigationController.getInstance().beginPlaylistSync();

        Log.d(TAG, "Library reset started (mode=" + mode + ")");

        // Preparation on the main handler: hide the genre overlay,
        // show the reset overlay, and start the reset heartbeat.
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                ToastManager.hidePersistentOverlay(OPERATION_GENRE_UPDATE);

                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null
                        && !currentActivity.isFinishing()
                        && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity,
                        "Clearing library...", OPERATION_LIBRARY_RESET);
                } else {
                    Log.w(TAG, "No activity available for reset overlay");
                }
                startResetHeartbeatTicker();
            }
        });

        // Barrier on the executor.
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performResetBarrier();
                } catch (final Exception exception) {
                    Log.e(TAG, "Reset barrier failed", exception);
                    final String message = exception.getMessage() != null
                        ? exception.getMessage() : "Reset failed";
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            postResetCompletion(callback, false, message);
                        }
                    });
                    return;
                }

                // Cache cleanup is independent of the DB and does not
                // block completion.
                cleanupTempCacheAsync();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        sendResetBroadcast(mode);
                        postResetCompletion(callback, true, null);
                    }
                });
            }
        });
    }

    // ========================================================================
    // Reset Internals
    // ========================================================================

    /**
     * Runs the write barrier: clears every content-scoped store and
     * nothing else.
     *
     * <p>Runs on the executor. The four operations below are the only
     * content clears in the reset. Every other clear is performed by a
     * cache owner in response to the {@link #ACTION_LIBRARY_RESET}
     * broadcast, so the owner and the key stay together.</p>
     */
    private void performResetBarrier() {
        Log.d(TAG, "Reset barrier: clearing content");

        SongDatabase database = SongDatabase.getInstance(mContext);
        database.clearCache();
        database.clearLooseSongs();

        StorageAccessHelper.getInstance(mContext).clearAll();

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_SELECTED_FOLDERS, new HashSet<String>())
            .apply();

        Log.d(TAG, "Reset barrier: content cleared");
    }

    /**
     * Sends the {@link #ACTION_LIBRARY_RESET} broadcast carrying the
     * mode as an extra.
     *
     * <p>Runs on the main thread. Every receiver registered in the same
     * process dispatches synchronously, so by the time this method
     * returns, every cache owner has invalidated its state and, where
     * relevant, applied the empty state.</p>
     *
     * @param mode The scope of the reset
     */
    private void sendResetBroadcast(@NonNull ResetMode mode) {
        Intent intent = new Intent(ACTION_LIBRARY_RESET);
        intent.putExtra(EXTRA_PRESERVE_SETTINGS, mode == ResetMode.LIBRARY);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "LIBRARY_RESET broadcast sent (preserve_settings="
            + (mode == ResetMode.LIBRARY) + ")");
    }

    /**
     * Ends the reset: stops the heartbeat, clears both flags, hides the
     * reset overlay, ends the navigation operation, and invokes the
     * callback.
     *
     * <p>Runs on the main thread, after the broadcast has dispatched.</p>
     *
     * @param callback Listener to invoke, or null
     * @param success True when the barrier committed
     * @param error Description of the failure, or null on success
     */
    private void postResetCompletion(@Nullable final ResetCallback callback,
                                     final boolean success,
                                     @Nullable final String error) {
        stopResetHeartbeatTicker();
        mIsResetting.set(false);
        mIsUpdating.set(false);

        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_RESET);

        NavigationController.getInstance().endPlaylistSync();

        if (callback != null) {
            if (success) {
                callback.onComplete();
            } else {
                callback.onError(error != null ? error : "Reset failed");
            }
        }

        Log.d(TAG, "Library reset " + (success ? "completed" : "failed"));
    }

    /**
     * Starts the reset heartbeat ticker.
     *
     * <p>Captures a fresh token and posts a self-rescheduling runnable
     * that heartbeats the {@link #OPERATION_LIBRARY_RESET} overlay every
     * {@link #RESET_HEARTBEAT_INTERVAL_MS} milliseconds. When a later
     * call to {@link #stopResetHeartbeatTicker()} increments the token,
     * the ticker observes the mismatch on its next scheduled run and
     * terminates without rescheduling. Idempotent per token: a second
     * call while a ticker is running replaces the ticker rather than
     * starting a second one.</p>
     */
    private void startResetHeartbeatTicker() {
        final long token = mResetHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mResetHeartbeatToken.get() != token) {
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_RESET);
                mGenreHandler.postDelayed(this, RESET_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current reset heartbeat ticker by invalidating its
     * token. Idempotent.
     *
     * <p>The ticker does not stop synchronously; it observes the token
     * mismatch on its next scheduled run and terminates then. This is
     * acceptable because the ticker's only effect is a heartbeat on an
     * overlay that may already be hidden.</p>
     */
    private void stopResetHeartbeatTicker() {
        mResetHeartbeatToken.incrementAndGet();
    }

    /**
     * Deletes leftover {@code temp_audio_*} and {@code backup_*} files
     * from the cache directory.
     *
     * <p>Runs on a short-lived background thread so the reset's
     * completion signal is not delayed by the cache sweep. The sweep is
     * best-effort: a failure to delete a stale file is logged and
     * ignored. The files are safe to delete because the operations that
     * created them have already completed by the time a reset runs.</p>
     */
    private void cleanupTempCacheAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File cacheDir = mContext.getCacheDir();
                    if (cacheDir == null || !cacheDir.isDirectory()) {
                        return;
                    }
                    File[] files = cacheDir.listFiles();
                    if (files == null) {
                        return;
                    }
                    for (File file : files) {
                        if (file == null || !file.isFile()) {
                            continue;
                        }
                        String name = file.getName();
                        if (name.startsWith("temp_audio_") || name.startsWith("backup_")) {
                            if (file.delete()) {
                                Log.d(TAG, "Deleted stale temp file: " + name);
                            }
                        }
                    }
                } catch (Exception exception) {
                    Log.w(TAG, "cleanupTempCache failed", exception);
                }
            }
        }).start();
    }

    // ========================================================================
    // Genre Loading Methods
    // ========================================================================

    /**
     * Triggers genre loading for every song whose genre is still
     * unknown.
     *
     * <p>The overlay show and every overlay update run on the main
     * handler. The prologue — reading the full song list and filtering
     * out the rows that already have a genre — runs on the executor.
     * The prologue is O(n) in the library size and was previously run
     * on the calling thread, which is the main thread; on a
     * multi-thousand-song library it blocked the main thread before the
     * genre overlay had a chance to render.</p>
     *
     * <p>The ID3 read loop itself runs on the executor. Each result is
     * persisted as it arrives, and progress is broadcast through
     * {@link #ACTION_GENRE_UPDATE} with {@code UPDATE} status. The
     * genre overlay is heartbeated independently of the loop through
     * {@link #startGenreHeartbeatTicker()}.</p>
     *
     * <p>Refused when a reset is in flight, or when genre loading is
     * already running. The flag is set with
     * {@link AtomicBoolean#getAndSet(boolean)} so two concurrent callers
     * cannot both pass the check.</p>
     */
    public void triggerGenreLoading() {
        if (mIsResetting.get()) {
            Log.d(TAG, "Genre loading refused — reset in progress");
            return;
        }
        if (mIsGenreLoading.getAndSet(true)) {
            Log.d(TAG, "Genre loading already in progress, skipping");
            return;
        }

        Log.d(TAG, "Starting genre loading...");

        // Show the overlay before the library read so the user has
        // immediate feedback. The count in the message is not yet
        // known; it is filled in once the read completes.
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                Activity currentActivity = ToastManager.getCurrentActivity();
                if (currentActivity != null
                        && !currentActivity.isFinishing()
                        && !currentActivity.isDestroyed()) {
                    ToastManager.showPersistentOverlay(currentActivity,
                        "Loading metadata...", OPERATION_GENRE_UPDATE);
                } else {
                    Log.w(TAG, "No activity available for persistent overlay");
                }
                startGenreHeartbeatTicker();
            }
        });

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Song> allSongs =
                    SongDatabase.getInstance(mContext).getAllSongs();

                final ArrayList<Song> songsNeedingGenres = new ArrayList<>();
                for (Song song : allSongs) {
                    if (song != null && ("Unknown Genre".equals(song.getGenre())
                                         || song.getGenre() == null
                                         || song.getGenre().isEmpty())) {
                        songsNeedingGenres.add(song);
                    }
                }

                if (songsNeedingGenres.isEmpty()) {
                    Log.d(TAG, "No songs need genre update");
                    sendGenreUpdateBroadcast("COMPLETE", null, null, 0, 0);
                    mGenreHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            stopGenreHeartbeatTicker();
                            ToastManager.hidePersistentOverlay(OPERATION_GENRE_UPDATE);
                            mIsGenreLoading.set(false);
                        }
                    });
                    return;
                }

                Log.d(TAG, "Loading genres for "
                    + songsNeedingGenres.size() + " songs");

                final SongDatabase database = SongDatabase.getInstance(mContext);
                int updatedCount = 0;
                final int total = songsNeedingGenres.size();
                long lastProgressTime = 0;

                sendGenreUpdateBroadcast("START", null, null, 0, total);

                try {
                    for (Song song : songsNeedingGenres) {
                        if (mIsResetting.get()) {
                            Log.d(TAG, "Genre loading aborted — reset in progress");
                            break;
                        }
                        if (song == null || TextUtils.isEmpty(song.getPath())) {
                            continue;
                        }

                        String realGenre = CharacterMapper.getGenre(song.getPath());

                        boolean hasRealGenre = (realGenre != null
                            && !realGenre.isEmpty()
                            && !"Unknown Genre".equals(realGenre));

                        if (hasRealGenre) {
                            Song updatedSong = new Song(
                                song.getTitle(),
                                song.getArtist(),
                                song.getAlbum(),
                                realGenre,
                                song.getPath(),
                                song.getDuration(),
                                song.getUri()
                            );

                            database.insertSong(updatedSong);
                            song.setGenre(realGenre);
                            updatedCount++;

                            sendGenreUpdateBroadcast("UPDATE", song.getPath(),
                                realGenre, updatedCount, total);

                            Log.d(TAG, "Genre updated: " + song.getTitle()
                                + " -> " + realGenre);
                        }

                        long now = SystemClock.elapsedRealtime();
                        if (now - lastProgressTime >= PROGRESS_TIME_THRESHOLD_MS
                                || updatedCount == total
                                || updatedCount == 1) {
                            lastProgressTime = now;
                            final int currentUpdated = updatedCount;
                            final int currentTotal = total;
                            mGenreHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    ToastManager.updatePersistentOverlay(
                                        "Loading metadata... " + currentUpdated
                                            + "/" + currentTotal,
                                        OPERATION_GENRE_UPDATE);
                                }
                            });
                        }
                    }
                } finally {
                    stopGenreHeartbeatTicker();
                }

                Log.d(TAG, "Genre loading completed: " + updatedCount + "/"
                    + total + " songs updated");

                sendGenreUpdateBroadcast("COMPLETE", null, null, updatedCount, total);

                Intent forceRefreshIntent =
                    new Intent(ACTION_FORCE_PLAYLIST_REFRESH);
                mContext.sendBroadcast(forceRefreshIntent);

                mGenreHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay(OPERATION_GENRE_UPDATE);
                        mIsGenreLoading.set(false);
                    }
                });
            }
        });
    }

    /**
     * Returns whether genre loading is currently in flight.
     *
     * @return True while genre loading is running
     */
    public boolean isGenreLoading() {
        return mIsGenreLoading.get();
    }

    /**
     * Starts the genre-loading heartbeat ticker.
     *
     * <p>Captures a fresh token and posts a self-rescheduling runnable
     * that heartbeats the {@link #OPERATION_GENRE_UPDATE} overlay every
     * {@link #GENRE_HEARTBEAT_INTERVAL_MS} milliseconds. When a later
     * call to {@link #stopGenreHeartbeatTicker()} increments the token,
     * the ticker observes the mismatch on its next scheduled run and
     * terminates without rescheduling. Idempotent per token: a second
     * call while a ticker is running replaces the ticker rather than
     * starting a second one.</p>
     */
    private void startGenreHeartbeatTicker() {
        final long token = mGenreHeartbeatToken.incrementAndGet();
        mGenreHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mGenreHeartbeatToken.get() != token) {
                    return;
                }
                ToastManager.heartbeat(OPERATION_GENRE_UPDATE);
                mGenreHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS);
            }
        });
    }

    /**
     * Stops the current genre-loading heartbeat ticker by invalidating
     * its token. Idempotent.
     *
     * <p>The ticker does not stop synchronously; it observes the token
     * mismatch on its next scheduled run and terminates then.</p>
     */
    private void stopGenreHeartbeatTicker() {
        mGenreHeartbeatToken.incrementAndGet();
    }

    /**
     * Sends a {@code GENRE_UPDATE} broadcast with the given lifecycle
     * values.
     *
     * <p>The broadcast reaches every registered receiver synchronously.
     * Listeners switch on the {@code status} extra: {@code START},
     * {@code UPDATE}, and {@code COMPLETE}. The {@code song_path} and
     * {@code genre} extras are populated only on {@code UPDATE}. The
     * {@code current} and {@code total} extras carry running counts and
     * are populated on every status except {@code START}, where the
     * total is already known but no songs have been processed.</p>
     *
     * @param status One of {@code START}, {@code UPDATE}, or
     *        {@code COMPLETE}
     * @param songPath Path of the song whose genre changed, or null
     * @param genre New genre value, or null
     * @param current Number of songs processed so far
     * @param total Total number of songs to process
     */
    private void sendGenreUpdateBroadcast(String status, String songPath,
                                          String genre, int current, int total) {
        Intent intent = new Intent(ACTION_GENRE_UPDATE);
        intent.putExtra("status", status);
        intent.putExtra("song_path", songPath);
        intent.putExtra("genre", genre);
        intent.putExtra("current", current);
        intent.putExtra("total", total);
        mContext.sendBroadcast(intent);
    }

    /**
     * Registers the receiver for the trigger-genre-loading broadcast.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerTriggerGenreReceiver() {
        mTriggerGenreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_TRIGGER_GENRE_LOADING.equals(intent.getAction())) {
                    triggerGenreLoading();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_TRIGGER_GENRE_LOADING);
        ContextCompat.registerReceiver(
            mContext, mTriggerGenreReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
        Log.d(TAG, "Trigger genre receiver registered");
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                mContext.unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    /**
     * Cancels any in-flight scan or reset, stops every heartbeat ticker,
     * unregisters the trigger receiver, and shuts down the executor.
     *
     * <p>The executor is given {@link #SHUTDOWN_TIMEOUT_MS} milliseconds
     * to drain before it is forcibly shut down. This bounds the total
     * shutdown time so a slow ID3 read cannot block process teardown
     * indefinitely.</p>
     */
    public void shutdown() {
        cancelUpdate();

        stopGenreHeartbeatTicker();
        stopResetHeartbeatTicker();
        mIsResetting.set(false);

        unregisterReceiverSafely(mTriggerGenreReceiver);

        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException exception) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", exception);
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null);
        Log.d(TAG, "PlaylistManager shut down");
    }

    // ========================================================================
    // Internal Methods
    // ========================================================================

    /**
     * Runs a full folder scan on the executor, reports progress to the
     * given callback, and emits the standard broadcast sequence when the
     * scan finishes.
     *
     * <p>Refuses when a reset is in flight. Refuses when a scan is
     * already running. On admission, takes the
     * {@link NavigationController} playlist-sync operation, captures the
     * current scan generation, and dispatches the scan to the executor.
     * The scan ends with the operation released. The
     * {@code SYNC_COMPLETE} broadcast is emitted from the scan's happy
     * path, after the caller's {@code onComplete} has returned; the
     * {@code finally} block does not emit it.</p>
     *
     * <p>On a scan that completes without error, the callback's
     * {@code onComplete} fires before the {@code SYNC_COMPLETE}
     * broadcast, so a caller that needs the callback to run before the
     * broadcast's effects can rely on that ordering.</p>
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to suppress progress reporting
     */
    private void updatePlaylistInternal(@Nullable final UpdateCallback callback,
                                        final boolean silent) {
        if (mIsResetting.get()) {
            Log.w(TAG, "Update refused — reset in progress");
            if (callback != null) {
                callback.onError("Reset in progress");
            }
            return;
        }
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping");
            if (callback != null) {
                callback.onError("Update already in progress");
            }
            return;
        }

        NavigationController.getInstance().beginPlaylistSync();

        final long scanGeneration = mScanGeneration.get();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    performScan(callback, silent, scanGeneration);
                } catch (final Exception exception) {
                    Log.e(TAG, "Uncaught exception during playlist update", exception);
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onError(exception.getMessage() != null
                                    ? exception.getMessage()
                                    : "Unknown error during scan");
                            }
                        }
                    });
                } finally {
                    NavigationController.getInstance().endPlaylistSync();
                    mIsUpdating.set(false);

                    // SYNC_COMPLETE is emitted from performScan's happy
                    // path, after the caller's onComplete has returned.
                    // The early emit that used to live here fired before
                    // onComplete and caused every receiver to reload its
                    // state twice.
                }
            }
        });
    }

    /**
     * Performs the scan across every selected folder, writes the results
     * to the database, and emits the standard broadcast sequence.
     *
     * <p>Runs on the executor. The scan is a two-phase operation. The
     * first phase queries MediaStore for each selected folder and
     * collects the songs that are not already cached. The second phase
     * writes the new songs in a single batch and deletes the rows whose
     * paths were not seen during the scan.</p>
     *
     * <p>Both phases check {@link #mIsUpdating} and
     * {@link #mIsResetting} at every iteration and again immediately
     * before the database write, against the captured generation value.
     * A cancel that arrives between the loop's flag check and the write
     * still aborts the write, because the generation check is repeated
     * at the write site.</p>
     *
     * <p>When the selected folder set is empty, the scan preserves any
     * loose tracks and clears the songs table. When the folder set is
     * not empty but no songs were found in any folder, the scan
     * preserves the existing playlist rather than deleting it, so a
     * transient media-store problem cannot wipe the library.</p>
     *
     * @param callback Listener that receives progress and completion
     *        callbacks, or null
     * @param silent True to suppress progress reporting
     * @param scanGeneration Generation value captured at admission
     */
    private void performScan(@Nullable final UpdateCallback callback,
                             final boolean silent,
                             final long scanGeneration) {
        try {
            final ArrayList<Song> newSongs = new ArrayList<Song>();
            final Set<String> allFoundPaths = new HashSet<String>();
            Set<String> selectedFolders = getSelectedFolders();

            boolean foundAnySongs = false;

            if (selectedFolders.isEmpty()) {
                SongDatabase database = SongDatabase.getInstance(mContext);

                ArrayList<Song> looseSongs = database.getLooseSongs();

                database.clearCache();

                if (!looseSongs.isEmpty()) {
                    database.insertSongsBatch(looseSongs);
                    foundAnySongs = true;
                }

                final ArrayList<Song> songsAfterUpdate = database.getAllSongs();

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
                        mContext.sendBroadcast(refreshIntent);

                        Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                        mContext.sendBroadcast(refreshDisplayIntent);

                        if (callback != null) {
                            callback.onComplete(songsAfterUpdate.size());
                        }
                    }
                });
                return;
            }

            final int totalFiles = countMusicFiles(selectedFolders);
            final AtomicInteger currentCount = new AtomicInteger(0);

            if (!silent && callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onProgress(0, totalFiles);
                    }
                });
            }

            for (String folderUriString : selectedFolders) {
                if (!mIsUpdating.get() || mIsResetting.get()) {
                    Log.d(TAG, "Update cancelled during scanning");
                    return;
                }
                int foundInFolder = scanFolderFast(Uri.parse(folderUriString),
                    newSongs, allFoundPaths, currentCount, totalFiles,
                    callback, silent);
                if (foundInFolder > 0) {
                    foundAnySongs = true;
                }
            }

            if (!mIsUpdating.get() || mIsResetting.get()) {
                Log.d(TAG, "Update cancelled after scanning");
                return;
            }

            SongDatabase database = SongDatabase.getInstance(mContext);

            if (mScanGeneration.get() != scanGeneration || mIsResetting.get()) {
                Log.d(TAG, "Scan cancelled before batch insert, aborting");
                return;
            }
            if (!newSongs.isEmpty()) {
                database.insertSongsBatch(newSongs);
                Log.d(TAG, "Inserted " + newSongs.size() + " new songs");
            }

            if (!selectedFolders.isEmpty() && !foundAnySongs) {
                Log.w(TAG, "No songs found in selected folders - "
                    + "preserving existing playlist");
                final ArrayList<Song> currentSongs = database.getAllSongs();
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onComplete(currentSongs.size());
                        }
                    }
                });
                return;
            }

            if (mScanGeneration.get() != scanGeneration || mIsResetting.get()) {
                Log.d(TAG, "Scan cancelled before delete pass, aborting");
                return;
            }
            database.deleteSongsNotInSet(allFoundPaths, true);

            final ArrayList<Song> allSongsAfterUpdate = database.getAllSongs();
            final int totalSongCount = allSongsAfterUpdate.size();

            Log.d(TAG, "Phase 1 completed. Total songs: " + totalSongCount);

            Intent refreshIntent = new Intent("SOFT_UPDATE_PLAYLIST");
            mContext.sendBroadcast(refreshIntent);

            Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
            mContext.sendBroadcast(refreshDisplayIntent);

            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onComplete(totalSongCount);
                    }

                    Intent syncCompleteIntent = new Intent(ACTION_SYNC_COMPLETE);
                    mContext.sendBroadcast(syncCompleteIntent);
                }
            }, SYNC_COMPLETE_DELAY_MS);

        } catch (final Exception exception) {
            Log.e(TAG, "Update failed: " + exception.getMessage(), exception);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (callback != null) {
                        callback.onError(exception.getMessage() != null
                            ? exception.getMessage() : "Unknown error");
                    }
                }
            });
            throw new RuntimeException(exception);
        }
    }

    // ========================================================================
    // Folder and File Scanning
    // ========================================================================

    /**
     * Dispatches a folder scan to the path-based or name-based query,
     * depending on whether the folder URI encodes a filesystem path.
     *
     * <p>The path-based query is used when the URI references primary
     * storage and its path can be extracted. The name-based query is the
     * fallback for URIs that do not carry a path, matching on the folder
     * name as a path segment.</p>
     *
     * @param folderUri Folder URI to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen during the
     *        scan
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found in this folder
     */
    private int scanFolderFast(@NonNull Uri folderUri,
                               @NonNull ArrayList<Song> newSongs,
                               @NonNull Set<String> allFoundPaths,
                               @NonNull AtomicInteger currentCount,
                               int totalFiles,
                               @Nullable UpdateCallback callback,
                               boolean silent) {
        if (!mIsUpdating.get() || mIsResetting.get()) {
            return 0;
        }

        int songsFound = 0;
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(folderPath, newSongs,
                    allFoundPaths, currentCount, totalFiles, callback, silent);
            } else {
                String folderName = getFolderNameFromUri(folderUri);
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(folderName, newSongs,
                        allFoundPaths, currentCount, totalFiles, callback, silent);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "scan error for folder: " + folderUri, exception);
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files under the given filesystem
     * path and adds the results to the given collections.
     *
     * <p>Runs on the executor. Reads the path, title, artist, album, and
     * duration columns in a single cursor. Songs already cached in
     * {@link SongDatabase} contribute their cached metadata and are not
     * re-parsed; songs not yet cached are constructed from the cursor
     * values and added to {@code newSongs} for a later batch insert.</p>
     *
     * <p>Progress is reported to the callback through
     * {@link #mMainHandler} at most once every
     * {@link #PROGRESS_THRESHOLD} songs or
     * {@link #PROGRESS_TIME_THRESHOLD_MS} milliseconds, whichever comes
     * first, plus a final report when the last file is processed. A
     * {@code silent} scan suppresses progress entirely.</p>
     *
     * <p>Per-file failures are logged and skipped: an inaccessible file,
     * a metadata read error, or a malformed row does not abort the
     * scan.</p>
     *
     * @param folderPath Filesystem path of the folder to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen during the
     *        scan
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found under the given path
     */
    private int queryMediaStoreFast(@NonNull String folderPath,
                                    @NonNull ArrayList<Song> newSongs,
                                    @NonNull Set<String> allFoundPaths,
                                    @NonNull AtomicInteger currentCount,
                                    int totalFiles,
                                    @Nullable final UpdateCallback callback,
                                    final boolean silent) {
        if (!mIsUpdating.get() || mIsResetting.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[] {normalizedPath + "%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()
                    && !mIsResetting.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get() || mIsResetting.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1)
                                ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title)
                                    || CharacterMapper.hasProblematicCharacters(artist)
                                    || CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre,
                                filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null
                        && (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()
                                        && !mIsResetting.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get()
                        && !mIsResetting.get());

                Log.d(TAG, "Scanned folder: " + folderPath + ", found "
                    + processedCount + " songs");
            }
        } catch (SecurityException exception) {
            Log.e(TAG, "Permission denied scanning folder: " + folderPath, exception);
            if (callback != null && !silent) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsUpdating.get() && !mIsResetting.get()) {
                            callback.onError("Permission denied accessing storage");
                        }
                    }
                });
            }
        } catch (Exception exception) {
            Log.e(TAG, "query error for folder: " + folderPath, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    /**
     * Queries MediaStore for music files whose path contains the given
     * folder name as a segment and adds the results to the given
     * collections.
     *
     * <p>Fallback used when the folder URI does not encode a filesystem
     * path. Matches on {@code %/folderName/%} so a folder name that also
     * appears as a substring elsewhere in the path is not matched.</p>
     *
     * <p>Behaviour is otherwise identical to
     * {@link #queryMediaStoreFast(String, ArrayList, Set, AtomicInteger, int, UpdateCallback, boolean)}:
     * cached songs contribute their cached metadata, uncached songs are
     * added to {@code newSongs}, progress is throttled, and per-file
     * failures are logged and skipped.</p>
     *
     * @param folderName Name of the folder to scan
     * @param newSongs List that receives newly discovered songs
     * @param allFoundPaths Set that receives every path seen during the
     *        scan
     * @param currentCount Running count of processed files
     * @param totalFiles Total files expected across all folders
     * @param callback Listener that receives progress callbacks, or null
     * @param silent True to suppress progress reporting
     * @return Number of songs found under the given folder name
     */
    private int queryMediaStoreByNameFast(@NonNull String folderName,
                                          @NonNull ArrayList<Song> newSongs,
                                          @NonNull Set<String> allFoundPaths,
                                          @NonNull AtomicInteger currentCount,
                                          int totalFiles,
                                          @Nullable final UpdateCallback callback,
                                          final boolean silent) {
        if (!mIsUpdating.get() || mIsResetting.get()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND "
            + MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;

        final int[] lastProgress = {0};
        final long[] lastProgressTime = {0};
        int songsFound = 0;

        try {
            cursor = resolver.query(mediaUri, new String[] {
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION},
                    selection, new String[] {"%/" + folderName + "/%"}, null);

            if (cursor != null && cursor.moveToFirst() && mIsUpdating.get()
                    && !mIsResetting.get()) {
                int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor");
                    return 0;
                }

                int processedCount = 0;
                SongDatabase database = SongDatabase.getInstance(mContext);

                do {
                    if (!mIsUpdating.get() || mIsResetting.get()) {
                        break;
                    }

                    String filePath = cursor.getString(pathColumn);
                    if (TextUtils.isEmpty(filePath)) {
                        continue;
                    }

                    File file = new File(filePath);
                    if (!file.exists() || !file.canRead()) {
                        Log.w(TAG, "Skipping inaccessible file: " + filePath);
                        continue;
                    }

                    allFoundPaths.add(filePath);

                    try {
                        Song cachedSong = database.getSong(filePath);

                        if (cachedSong == null) {
                            String rawTitle = cursor.getString(titleColumn);
                            String rawArtist = cursor.getString(artistColumn);
                            String rawAlbum = cursor.getString(albumColumn);
                            long duration = (durationColumn != -1)
                                ? cursor.getLong(durationColumn) : 0;

                            String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                            if (TextUtils.isEmpty(title)) {
                                String fileName = file.getName();
                                int dotIndex = fileName.lastIndexOf(".");
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex);
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName);
                                if (TextUtils.isEmpty(title)) {
                                    title = "Unknown Title";
                                }
                            }

                            String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                            if (TextUtils.isEmpty(artist)) {
                                artist = "Unknown Artist";
                            }

                            String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                            if (TextUtils.isEmpty(album)) {
                                album = "Unknown Album";
                            }

                            String genre = null;

                            if (CharacterMapper.hasProblematicCharacters(title)
                                    || CharacterMapper.hasProblematicCharacters(artist)
                                    || CharacterMapper.hasProblematicCharacters(album)) {

                                Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                                if (parsedSong != null) {
                                    title = parsedSong.getTitle();
                                    artist = parsedSong.getArtist();
                                    album = parsedSong.getAlbum();
                                    genre = parsedSong.getGenre();
                                }
                            }

                            Song newSong = new Song(title, artist, album, genre,
                                filePath, duration, null);
                            newSongs.add(newSong);
                            songsFound++;
                        } else {
                            songsFound++;
                        }
                    } catch (Exception exception) {
                        Log.e(TAG, "Failed to process file: " + filePath, exception);
                    }

                    final int currentValue = currentCount.incrementAndGet();
                    processedCount++;

                    long currentTime = SystemClock.elapsedRealtime();
                    boolean shouldUpdateProgress = !silent && callback != null
                        && (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD
                            || currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS
                            || currentValue == totalFiles);

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue;
                        lastProgressTime[0] = currentTime;
                        final int finalCurrent = currentValue;
                        final int finalTotal = totalFiles;

                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null && mIsUpdating.get()
                                        && !mIsResetting.get()) {
                                    callback.onProgress(finalCurrent, finalTotal);
                                }
                            }
                        });
                    }

                } while (cursor.moveToNext() && mIsUpdating.get()
                        && !mIsResetting.get());

                Log.d(TAG, "Scanned folder by name: " + folderName + ", found "
                    + processedCount + " songs");
            }
        } catch (Exception exception) {
            Log.e(TAG, "query by name error for: " + folderName, exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close cursor", exception);
                }
            }
        }
        return songsFound;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns a copy of the folder URI set currently selected by the
     * user.
     *
     * <p>The set is stored as a string set under
     * {@link #KEY_SELECTED_FOLDERS}. A defensive copy is returned so the
     * caller cannot mutate the persisted store through the returned
     * reference.</p>
     *
     * @return A set containing every selected folder URI; empty when
     *         none is stored
     */
    @NonNull
    private Set<String> getSelectedFolders() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> savedFolders = preferences.getStringSet(KEY_SELECTED_FOLDERS, null);
        Set<String> result = new HashSet<String>();
        if (savedFolders != null) {
            result.addAll(savedFolders);
        }
        return result;
    }

    /**
     * Counts the music files MediaStore reports for the given folders.
     *
     * <p>Used to size the progress denominator before the scan begins.
     * Each folder is counted with a dedicated cursor query. The total is
     * an upper bound rather than an exact figure: the scan later skips
     * files whose metadata cannot be read, so the running count may
     * finish below the total. Progress reporting clamps to the total to
     * keep the displayed ratio monotonic.</p>
     *
     * @param selectedFolders Folder URIs to count
     * @return Total music files reported across every folder
     */
    private int countMusicFiles(@NonNull Set<String> selectedFolders) {
        int total = 0;
        if (selectedFolders.isEmpty()) {
            return 0;
        }

        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        for (String folderUriString : selectedFolders) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);

                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/")
                        ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND "
                        + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri,
                            new String[] {MediaStore.Audio.Media.DATA},
                            folderSelection, new String[] {normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (Exception exception) {
                                Log.w(TAG, "Failed to close count cursor", exception);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND "
                            + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri,
                                new String[] {MediaStore.Audio.Media.DATA},
                                folderSelection,
                                new String[] {"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try {
                                    cursor.close();
                                } catch (Exception exception) {
                                    Log.w(TAG, "Failed to close count cursor", exception);
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "count error for folder: " + folderUriString, exception);
            }
        }

        Log.d(TAG, "Total music files counted: " + total);
        return total;
    }

    /**
     * Returns the filesystem path encoded in the given primary-storage
     * tree URI, or null when the URI does not refer to primary storage.
     *
     * <p>The URI is decoded by locating the {@code primary:} marker,
     * stripping any wrapping segments, decoding percent escapes, and
     * removing trailing separators. A URI that references removable
     * storage does not contain the marker and returns null, which
     * directs the caller to the name-based query path.</p>
     *
     * @param uri Folder URI to inspect, or null
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFolderPathFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            int startIndex = uriString.indexOf("primary:") + 8;
            String subPath = uriString.substring(startIndex);
            if (subPath.contains("%2F")) {
                subPath = subPath.replace("%2F", "/");
            }
            if (subPath.contains("/tree/")) {
                subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
            }
            if (subPath.contains("/document/")) {
                subPath = subPath.substring(subPath.indexOf("/document/") + 10);
            }
            String path = "/storage/emulated/0/" + subPath;
            path = Uri.decode(path);
            while (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            return path;
        }
        return null;
    }

    /**
     * Returns the cleaned display name of the given folder URI.
     *
     * <p>Prefers the {@link android.provider.OpenableColumns#DISPLAY_NAME}
     * column, falling back to the URI's last path segment when the
     * content resolver does not return a name. The name is passed
     * through {@link CharacterMapper#cleanString(String)} so control
     * characters and HTML entities are removed before it reaches the
     * UI.</p>
     *
     * @param uri Folder URI to inspect, or null
     * @return The cleaned folder name, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFolderNameFromUri(@Nullable Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(
                    android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null ? CharacterMapper.cleanString(name) : null;
    }
}