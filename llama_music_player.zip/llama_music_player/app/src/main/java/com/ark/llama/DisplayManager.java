package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * DisplayManager - Manages all UI display components for MusicPlayer.
 * 
 * <p>This class centralizes management of:</p>
 * <ul>
 *   <li>Album art loading, caching, and display with fade animations</li>
 *   <li>Themed placeholder bitmap generation with color tinting</li>
 *   <li>Loading overlay with dim background and progress spinner</li>
 *   <li>Album art container rounded corner clipping</li>
 * </ul>
 * 
 * <h3>Threading Model</h3>
 * <p>DisplayManager uses two dedicated executors:</p>
 * <ul>
 *   <li><b>mAlbumArtExecutor</b> - Single-thread executor for album art extraction
 *       and downsampling. Tasks are cancelled when new album art is requested.</li>
 *   <li><b>mPlaceholderExecutor</b> - Single-thread executor for placeholder
 *       bitmap generation and theme tinting.</li>
 * </ul>
 * <p>All bitmap operations are performed off the UI thread, with results posted
 * back via Handler. This replaces the deprecated AsyncTask pattern.</p>
 * 
 * <h3>Memory Management</h3>
 * <p>Album art uses an LRU cache with a 50MB size limit to prevent OOM errors.
 * Bitmaps are downsampled to max 1024x1024 pixels. Placeholder bitmaps are
 * recycled when the activity is destroyed or when the theme changes.</p>
 * 
 * <h3>Album Art Update Flow</h3>
 * <ol>
 *   <li>Caller requests updateAlbumArt() with file path</li>
 *   <li>Check LRU cache for existing bitmap</li>
 *   <li>If not cached, submit task to album art executor</li>
 *   <li>Extract embedded album art using MediaMetadataRetriever</li>
 *   <li>Downsample to safe dimensions</li>
 *   <li>Store in cache and post to UI thread for display</li>
 *   <li>Apply fade animation</li>
 * </ol>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 * 
 * @see MusicPlayer
 * @see ThemeManager
 * @see ThemeHelper
 */
public class DisplayManager {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "DisplayManager";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    /** Duration of album art fade animation in milliseconds. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Timeout for loading overlay display in milliseconds. */
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;
    
    // ========================================================================
    // Fields
    // ========================================================================
    
    /** Application context for resource access. */
    @NonNull private final Context mContext;
    
    /** Theme manager for accessing current theme color. */
    @NonNull private final ThemeManager mThemeManager;
    
    /** Theme helper for applying colors to UI components. */
    @NonNull private final ThemeHelper mThemeHelper;
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ------------------------------------------------------------------------
    // Album Art Components
    // ------------------------------------------------------------------------
    
    /** LRU cache for album art bitmaps. */
    @NonNull private final android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Path of currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    /** Currently running album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    
    /** Path of currently loading album art. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    /** Single-thread executor for album art loading. */
    @NonNull private final ExecutorService mAlbumArtExecutor = Executors.newSingleThreadExecutor();
    
    // ------------------------------------------------------------------------
    // Placeholder Components
    // ------------------------------------------------------------------------
    
    /** Themed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Single-thread executor for placeholder generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock object for placeholder synchronization. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ------------------------------------------------------------------------
    // Overlay Components
    // ------------------------------------------------------------------------
    
    /** Dim overlay for loading state. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner inside dim overlay. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new DisplayManager.
     * 
     * <p>Initializes the LRU cache with the configured size limit.</p>
     *
     * @param context Application context for resource access
     * @param themeManager Theme manager for color access
     * @param themeHelper Theme helper for applying colors
     */
    public DisplayManager(@NonNull Context context, 
                          @NonNull ThemeManager themeManager,
                          @NonNull ThemeHelper themeHelper) {
        mContext = context;
        mThemeManager = themeManager;
        mThemeHelper = themeHelper;
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(@NonNull String key, @NonNull Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Updates album art for the given song path.
     * 
     * <p>This method is thread-safe and can be called from any thread.
     * It will:
     * <ul>
     *   <li>Check the LRU cache for existing art</li>
     *   <li>Cancel any pending loading task</li>
     *   <li>Submit a new task to the album art executor</li>
     *   <li>Post the result to the UI thread with fade animation</li>
     * </ul>
     * </p>
     *
     * @param imageView The ImageView to display album art in
     * @param filePath Path to the song file, or null to show placeholder
     */
    public void updateAlbumArt(@Nullable ImageView imageView, @Nullable String filePath) {
        if (imageView == null) {
            return;
        }
        
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder(imageView);
            }
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }
        
        mCurrentAlbumArtPath = filePath;
        
        // Check cache first (fast path)
        final Bitmap cached = mAlbumArtCache.get(filePath);
        if (cached != null && !cached.isRecycled()) {
            applyAlbumArtWithFade(imageView, cached);
            return;
        }
        
        // Cancel pending task if exists
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(() -> {
            if (Thread.interrupted()) {
                return;
            }
            
            final Bitmap bitmap = extractAlbumArt(filePath);
            if (bitmap == null) {
                return;
            }
            
            // Cache the bitmap
            mAlbumArtCache.put(filePath, bitmap);
            
            // Post to UI thread if still current
            mMainHandler.post(() -> {
                if (filePath.equals(mCurrentAlbumArtPath) && imageView != null) {
                    applyAlbumArtWithFade(imageView, bitmap);
                }
            });
        });
    }
    
    /**
     * Extracts embedded album art from an audio file using MediaMetadataRetriever.
     * 
     * <p>Performs downsampling to prevent OOM errors on large embedded images.</p>
     *
     * @param filePath Path to the audio file
     * @return Downsampled bitmap, or null if no album art exists
     */
    @Nullable
    private Bitmap extractAlbumArt(@NonNull String filePath) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(filePath);
            final byte[] artBytes = retriever.getEmbeddedPicture();
            if (artBytes != null) {
                return decodeSampledBitmap(artBytes);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to extract album art for: " + filePath, e);
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception e) {
                    // Ignore
                }
            }
        }
        return null;
    }
    
    /**
     * Decodes a byte array into a sampled bitmap to prevent OOM.
     * 
     * @param data The image byte array
     * @return Sampled bitmap, or null if decoding fails
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Calculates the appropriate sample size for bitmap downsampling.
     * 
     * @param options BitmapFactory.Options with outWidth and outHeight set
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The calculated sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, 
                                       int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Applies album art bitmap with fade animation.
     * 
     * @param imageView The ImageView to update
     * @param bitmap The bitmap to display
     */
    private void applyAlbumArtWithFade(@NonNull ImageView imageView, @NonNull Bitmap bitmap) {
        imageView.setAlpha(0f);
        imageView.setImageBitmap(bitmap);
        imageView.animate()
            .alpha(1f)
            .setDuration(ALBUM_ART_FADE_DURATION_MS)
            .setListener(null)
            .start();
    }
    
    /**
     * Clears the album art cache and resets current path.
     */
    public void clearAlbumArtCache() {
        mAlbumArtCache.evictAll();
        mCurrentAlbumArtPath = null;
    }
    
    /**
     * Removes a specific entry from the album art cache.
     *
     * @param path The song path to remove from cache
     */
    public void removeFromCache(@NonNull String path) {
        mAlbumArtCache.remove(path);
        if (path.equals(mCurrentAlbumArtPath)) {
            mCurrentAlbumArtPath = null;
        }
    }
    
    /**
     * Gets a cached album art bitmap if present.
     *
     * @param path The song path to look up
     * @return Cached bitmap, or null if not in cache
     */
    @Nullable
    public Bitmap getCachedAlbumArt(@NonNull String path) {
        return mAlbumArtCache.get(path);
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Loads and displays the themed placeholder bitmap.
     * 
     * <p>If the placeholder is already generated and cached, displays it immediately.
     * Otherwise, generates a new placeholder asynchronously.</p>
     *
     * @param imageView The ImageView to display the placeholder in
     */
    public void loadAndDisplayPlaceholder(@NonNull ImageView imageView) {
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                imageView.setImageBitmap(mPlaceholderBitmap);
                return;
            }
        }
        generatePlaceholderAsync(imageView);
    }
    
    /**
     * Generates a themed placeholder bitmap asynchronously.
     * 
     * <p>The placeholder is tinted with the current theme color using
     * PorterDuff.Mode.SRC_IN blending.</p>
     *
     * @param imageView The ImageView to display the placeholder in
     */
    private void generatePlaceholderAsync(@NonNull ImageView imageView) {
        // Cancel existing task
        if (mCurrentPlaceholderTask != null && !mCurrentPlaceholderTask.isDone()) {
            mCurrentPlaceholderTask.cancel(true);
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        mCurrentPlaceholderTask = mPlaceholderExecutor.submit(() -> {
            Bitmap tinted = null;
            
            synchronized (mPlaceholderLock) {
                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                    tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                }
            }
            
            if (tinted == null) {
                final BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                final Bitmap loaded = BitmapFactory.decodeResource(
                    mContext.getResources(), 
                    R.drawable.album_art_placeholder, 
                    opts
                );
                
                if (loaded != null) {
                    tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                    loaded.recycle();
                    
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            mOriginalPlaceholderBitmap.recycle();
                        }
                        mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                    }
                }
            }
            
            if (tinted == null) {
                return;
            }
            
            // Apply theme color tint
            final Canvas canvas = new Canvas(tinted);
            final Paint paint = new Paint();
            paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(tinted, 0, 0, paint);
            
            final Bitmap finalTinted = tinted;
            mMainHandler.post(() -> {
                synchronized (mPlaceholderLock) {
                    if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                        mPlaceholderBitmap.recycle();
                    }
                    mPlaceholderBitmap = finalTinted;
                }
                imageView.setImageBitmap(finalTinted);
            });
        });
    }
    
    /**
     * Refreshes the placeholder after theme color change.
     *
     * @param imageView The ImageView to update
     */
    public void refreshPlaceholder(@NonNull ImageView imageView) {
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mPlaceholderBitmap.recycle();
                mPlaceholderBitmap = null;
            }
            if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                mOriginalPlaceholderBitmap.recycle();
                mOriginalPlaceholderBitmap = null;
            }
        }
        loadAndDisplayPlaceholder(imageView);
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a delayed loading overlay with dim background and progress spinner.
     * 
     * <p>The overlay appears after LOADING_OVERLAY_DELAY_MS milliseconds.
     * This prevents flickering for fast operations.</p>
     *
     * @param rootView The root view to attach the overlay to
     */
    public void showDelayedLoadingOverlay(@Nullable ViewGroup rootView) {
        if (rootView == null) {
            return;
        }
        
        mMainHandler.postDelayed(() -> showLoadingOverlay(rootView), LOADING_OVERLAY_DELAY_MS);
    }
    
    /**
     * Shows the loading overlay immediately.
     *
     * @param rootView The root view to attach the overlay to
     */
    private void showLoadingOverlay(@NonNull ViewGroup rootView) {
        if (mDimOverlay != null) {
            return;
        }
        
        final FrameLayout overlay = new FrameLayout(mContext);
        overlay.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
        
        mLoadingSpinner = new ProgressBar(mContext);
        mLoadingSpinner.setIndeterminate(true);
        
        final int sizePx = dpToPx(PROGRESS_BAR_SIZE_DP);
        final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(sizePx, sizePx);
        progressParams.gravity = Gravity.CENTER;
        mLoadingSpinner.setLayoutParams(progressParams);
        
        overlay.addView(mLoadingSpinner);
        rootView.addView(overlay);
        mDimOverlay = overlay;
        
        // Apply theme to progress bar
        if (mThemeHelper != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
    }
    
    /**
     * Hides the loading overlay if it is visible.
     */
    public void hideLoadingOverlay() {
        mMainHandler.removeCallbacksAndMessages(null);
        
        if (mDimOverlay != null && mDimOverlay.getParent() != null) {
            ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
        }
        mDimOverlay = null;
        mLoadingSpinner = null;
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corner clipping to the album art container.
     * 
     * <p>On API 21+ (Lollipop), uses ViewOutlineProvider for proper clipping.
     * On older versions, falls back to background drawable.</p>
     *
     * @param container The FrameLayout container for album art
     */
    public void applyAlbumArtClipping(@NonNull FrameLayout container) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            container.setClipToOutline(true);
            container.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            container.setBackgroundResource(R.drawable.album_art_container);
        } else {
            container.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * mContext.getResources().getDisplayMetrics().density);
    }
    
    /**
     * Releases all resources to prevent memory leaks.
     * 
     * <p>Should be called from MusicPlayer.onDestroy().</p>
     */
    public void release() {
        // Shutdown executors
        mAlbumArtExecutor.shutdownNow();
        mPlaceholderExecutor.shutdownNow();
        
        // Cancel pending tasks
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        if (mCurrentPlaceholderTask != null && !mCurrentPlaceholderTask.isDone()) {
            mCurrentPlaceholderTask.cancel(true);
        }
        
        // Recycle bitmaps
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mPlaceholderBitmap.recycle();
                mPlaceholderBitmap = null;
            }
            if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                mOriginalPlaceholderBitmap.recycle();
                mOriginalPlaceholderBitmap = null;
            }
        }
        
        // Clear cache
        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
        
        // Hide overlay
        hideLoadingOverlay();
        
        // Remove callbacks
        mMainHandler.removeCallbacksAndMessages(null);
    }
    
    // ========================================================================
    // Static Formatting Methods
    // ========================================================================
    
    /**
     * Formats milliseconds into a time string (MM:SS or HH:MM:SS).
     * 
     * @param milliseconds Time in milliseconds
     * @return Formatted time string (e.g., "03:45" or "01:23:45")
     */
    @NonNull
    public static String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    /**
     * Formats a song title with truncation and ellipsis.
     * 
     * @param title The song title (may be null)
     * @return Formatted title, or "Unknown Title" if null
     */
    @NonNull
    public static String formatSongTitle(@Nullable String title) {
        final int MAX_TITLE_LENGTH = 40;
        final String ELLIPSIS = "...";
        
        if (title == null || title.isEmpty()) {
            return "Unknown Title";
        }
        
        if (title.length() > MAX_TITLE_LENGTH) {
            return title.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        return title;
    }
    
    /**
     * Formats an artist name with truncation and ellipsis.
     * 
     * @param artist The artist name (may be null)
     * @return Formatted artist name, or "Unknown Artist" if null
     */
    @NonNull
    public static String formatArtistName(@Nullable String artist) {
        final int MAX_ARTIST_LENGTH = 35;
        final String ELLIPSIS = "...";
        
        if (artist == null || artist.isEmpty()) {
            return "Unknown Artist";
        }
        
        if (artist.length() > MAX_ARTIST_LENGTH) {
            return artist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }
        return artist;
    }
}