package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * DisplayManager - Manages all UI display components for MusicPlayer.
 * 
 * <p>This class centralises album art loading, placeholder generation, loading overlays,
 * and rounded corner clipping. All album art operations are performed on background
 * threads and posted to UI thread with fade animations.</p>
 * 
 * <h3>Key Improvements</h3>
 * <ul>
 *   <li>Window token check before applying fade animation (prevents crash on detached ImageView)</li>
 *   <li>Proper cancellation of pending tasks</li>
 *   <li>Memory‑aware cache management</li>
 *   <li>Thread‑safe placeholder generation with lock</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class DisplayManager {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "DisplayManager";
    private static final int MAX_CACHE_SIZE_MB = 50;
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    private static final int DIM_ALPHA = 180;
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;

    // ========================================================================
    // Fields
    // ========================================================================
    
    @NonNull private final Context mContext;
    @NonNull private final ThemeManager mThemeManager;
    @NonNull private final ThemeHelper mThemeHelper;
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    @NonNull private final android.util.LruCache<String, Bitmap> mAlbumArtCache;
    @Nullable private String mCurrentAlbumArtPath = null;
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    @Nullable private String mCurrentLoadingArtPath = null;
    @NonNull private final ExecutorService mAlbumArtExecutor = Executors.newSingleThreadExecutor();
    
    @Nullable private Bitmap mPlaceholderBitmap = null;
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    @NonNull private final Object mPlaceholderLock = new Object();
    
    @Nullable private View mDimOverlay = null;
    @Nullable private ProgressBar mLoadingSpinner = null;

    // ========================================================================
    // Constructor
    // ========================================================================
    
    public DisplayManager(@NonNull Context context, @NonNull ThemeManager themeManager, @NonNull ThemeHelper themeHelper) {
        mContext = context;
        mThemeManager = themeManager;
        mThemeHelper = themeHelper;
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(@NonNull String key, @NonNull Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
    }

    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Updates album art for the given song path.
     * 
     * <p>Checks cache first, then loads asynchronously. The result is posted
     * to the UI thread only if the ImageView is still attached to a window.</p>
     *
     * @param imageView The ImageView to display album art in
     * @param filePath Path to the song file, or null to show placeholder
     */
    public void updateAlbumArt(@Nullable ImageView imageView, @Nullable String filePath) {
        if (imageView == null) return;
        
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder(imageView);
            }
            return;
        }
        
        final Bitmap cached = mAlbumArtCache.get(filePath);
        boolean cacheValid = (cached != null && !cached.isRecycled());
        
        if (filePath.equals(mCurrentAlbumArtPath) && cacheValid) return;
        if (filePath.equals(mCurrentAlbumArtPath) && !cacheValid) {
            Log.d(TAG, "Cache invalid for current path, resetting");
            mCurrentAlbumArtPath = null;
        }
        
        mCurrentAlbumArtPath = filePath;
        
        if (cacheValid) {
            applyAlbumArtWithFade(imageView, cached);
            return;
        }
        
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(() -> {
            if (Thread.interrupted()) return;
            final Bitmap bitmap = extractAlbumArt(filePath);
            if (bitmap == null) return;
            mAlbumArtCache.put(filePath, bitmap);
            mMainHandler.post(() -> {
                if (filePath.equals(mCurrentAlbumArtPath) && imageView != null) {
                    applyAlbumArtWithFade(imageView, bitmap);
                }
            });
        });
    }

    /**
     * Applies album art with fade animation – checks window token to prevent crash.
     */
    private void applyAlbumArtWithFade(@NonNull ImageView imageView, @NonNull Bitmap bitmap) {
        // FIX: Prevent crash when ImageView is detached from window
        if (imageView.getWindowToken() == null || imageView.getParent() == null) {
            Log.d(TAG, "ImageView not attached, skipping fade animation");
            imageView.setImageBitmap(bitmap);
            return;
        }
        imageView.setAlpha(0f);
        imageView.setImageBitmap(bitmap);
        imageView.animate().alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null).start();
    }

    @Nullable
    private Bitmap extractAlbumArt(@NonNull String filePath) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(filePath);
            byte[] art = retriever.getEmbeddedPicture();
            if (art != null) return decodeSampledBitmap(art);
        } catch (Exception e) {
            Log.e(TAG, "Failed to extract album art", e);
        } finally {
            if (retriever != null) {
                try { retriever.release(); } catch (Exception ignored) {}
            }
        }
        return null;
    }

    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        opts.inSampleSize = calculateInSampleSize(opts, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
        opts.inJustDecodeBounds = false;
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
    }

    private int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        int height = options.outHeight;
        int width = options.outWidth;
        int sample = 1;
        if (height > reqHeight || width > reqWidth) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while ((halfHeight / sample) >= reqHeight && (halfWidth / sample) >= reqWidth) {
                sample *= 2;
            }
        }
        return sample;
    }

    public void clearAlbumArtCache() {
        mAlbumArtCache.evictAll();
        mCurrentAlbumArtPath = null;
    }

    public void resetCurrentArtPath() {
        mCurrentAlbumArtPath = null;
    }

    public void removeFromCache(@NonNull String path) {
        mAlbumArtCache.remove(path);
        if (path.equals(mCurrentAlbumArtPath)) mCurrentAlbumArtPath = null;
    }

    @Nullable
    public Bitmap getCachedAlbumArt(@NonNull String path) {
        return mAlbumArtCache.get(path);
    }

    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    public void loadAndDisplayPlaceholder(@NonNull ImageView imageView) {
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                imageView.setImageBitmap(mPlaceholderBitmap);
                return;
            }
        }
        generatePlaceholderAsync(imageView);
    }

    private void generatePlaceholderAsync(@NonNull ImageView imageView) {
        if (mCurrentPlaceholderTask != null && !mCurrentPlaceholderTask.isDone())
            mCurrentPlaceholderTask.cancel(true);
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        mCurrentPlaceholderTask = mPlaceholderExecutor.submit(() -> {
            Bitmap tinted = null;
            synchronized (mPlaceholderLock) {
                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                    tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                }
            }
            if (tinted == null) {
                Bitmap loaded = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.album_art_placeholder);
                if (loaded != null) {
                    tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                    loaded.recycle();
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled())
                            mOriginalPlaceholderBitmap.recycle();
                        mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                    }
                }
            }
            if (tinted == null) return;
            Canvas canvas = new Canvas(tinted);
            Paint paint = new Paint();
            paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(tinted, 0, 0, paint);
            final Bitmap finalTinted = tinted;
            mMainHandler.post(() -> {
                synchronized (mPlaceholderLock) {
                    if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) mPlaceholderBitmap.recycle();
                    mPlaceholderBitmap = finalTinted;
                }
                imageView.setImageBitmap(finalTinted);
            });
        });
    }

    public void refreshPlaceholder(@NonNull ImageView imageView) {
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mPlaceholderBitmap.recycle();
                mPlaceholderBitmap = null;
            }
            if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                mOriginalPlaceholderBitmap.recycle();
                mOriginalPlaceholderBitmap = null;
            }
        }
        loadAndDisplayPlaceholder(imageView);
    }

    // ========================================================================
    // Loading Overlay
    // ========================================================================
    
    public void showDelayedLoadingOverlay(@Nullable ViewGroup rootView) {
        if (rootView == null) return;
        mMainHandler.postDelayed(() -> showLoadingOverlay(rootView), LOADING_OVERLAY_DELAY_MS);
    }

    private void showLoadingOverlay(@NonNull ViewGroup rootView) {
        if (mDimOverlay != null) return;
        FrameLayout overlay = new FrameLayout(mContext);
        overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
        mLoadingSpinner = new ProgressBar(mContext);
        mLoadingSpinner.setIndeterminate(true);
        int size = dpToPx(PROGRESS_BAR_SIZE_DP);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(size, size);
        params.gravity = Gravity.CENTER;
        mLoadingSpinner.setLayoutParams(params);
        overlay.addView(mLoadingSpinner);
        rootView.addView(overlay);
        mDimOverlay = overlay;
        if (mThemeHelper != null) mThemeHelper.updateProgressBar(mLoadingSpinner);
    }

    public void hideLoadingOverlay() {
        mMainHandler.removeCallbacksAndMessages(null);
        if (mDimOverlay != null && mDimOverlay.getParent() != null) {
            ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
        }
        mDimOverlay = null;
        mLoadingSpinner = null;
    }

    // ========================================================================
    // Clipping
    // ========================================================================
    
    public void applyAlbumArtClipping(@NonNull FrameLayout container) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            container.setClipToOutline(true);
            container.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            container.setBackgroundResource(R.drawable.album_art_container);
        } else {
            container.setBackgroundResource(R.drawable.album_art_container);
        }
    }

    // ========================================================================
    // Utility
    // ========================================================================
    
    private int dpToPx(int dp) {
        return Math.round(dp * mContext.getResources().getDisplayMetrics().density);
    }

    public void release() {
        mAlbumArtExecutor.shutdownNow();
        mPlaceholderExecutor.shutdownNow();
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) mCurrentAlbumArtTask.cancel(true);
        if (mCurrentPlaceholderTask != null && !mCurrentPlaceholderTask.isDone()) mCurrentPlaceholderTask.cancel(true);
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) mPlaceholderBitmap.recycle();
            if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) mOriginalPlaceholderBitmap.recycle();
        }
        mAlbumArtCache.evictAll();
        hideLoadingOverlay();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Static Formatting
    // ========================================================================
    
    @NonNull
    public static String formatTime(int milliseconds) {
        int total = milliseconds / 1000;
        int hours = total / 3600;
        int minutes = (total % 3600) / 60;
        int seconds = total % 60;
        if (hours > 0) return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        else return String.format("%02d:%02d", minutes, seconds);
    }
}