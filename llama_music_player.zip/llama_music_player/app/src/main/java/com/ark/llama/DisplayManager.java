package com.ark.llama;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * DisplayManager - Manages all UI display components for MusicPlayer.
 * 
 * <p>This class extracts display-related logic from MusicPlayer to improve
 * separation of concerns and maintainability. It handles:</p>
 * <ul>
 *   <li><b>Album Art Management</b> - Loading, caching, and displaying album art
 *       with fade animations and memory-efficient bitmap sampling</li>
 *   <li><b>Placeholder Generation</b> - Themed placeholder bitmaps for songs
 *       without embedded album art</li>
 *   <li><b>Loading Overlay</b> - Dim overlay with spinner for long operations</li>
 *   <li><b>Theme Integration</b> - Applying theme colors to all UI components</li>
 *   <li><b>Text Formatting</b> - Time formatting and text truncation utilities</li>
 * </ul>
 * 
 * <h3>Album Art Caching Strategy</h3>
 * <pre>
 *    ┌──────────────────────────────────────────────┐
 *    │                                              Album Art Request                                                    │
 *    └─────────────────────┬────────────────────────┘
 *                                                                  │
 *                                                                 ▼
 *                                         ┌────────────────────┐
 *                                         │              L1 Cache                           │
 *                                         │          (LRU - 50MB)                       │
 *                                         └────┬───────────┬───┘
 *                                                       │ Hit                         │ Miss
 *                                                      ▼                              ▼
 *                                         ┌────────┐       ┌────────────────────────┐
 *                                         │     Return      │       │              Background Extraction              │
 *                                         │     Bitmap      │       │          (MediaMetadataRetriever)          │
 *                                         └────────┘       └───────────┬────────────┘
 *                                                                                                              │
 *                                                                                                             ▼
 *                                                                                           ┌────────────┐
 *                                                                                           │          Store in          │
 *                                                                                           │          Cache             │
 *                                                                                           └────────────┘
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>All methods that modify UI state are designed to be called from the UI thread.
 * Background operations use ExecutorService with proper Future cancellation.
 * Placeholder generation uses a dedicated executor with synchronization locks.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class DisplayManager {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "DisplayManager";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum album art dimension in pixels for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Duration of album art fade animation in milliseconds. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Delay before showing loading overlay (milliseconds). */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Alpha value for dim overlay background (180 = 70% opacity). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in density-independent pixels. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art container in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    /** Maximum length for song title display before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum length for artist name display before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Default placeholder background color (dark gray). */
    private static final String PLACEHOLDER_BG_COLOR = "#1A1A1A";
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Activity reference for UI operations. */
    @NonNull
    private final Activity mActivity;
    
    /** Main thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** LRU cache for album art bitmaps (50MB max). */
    @Nullable
    private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Executor for asynchronous album art loading. */
    @Nullable
    private ExecutorService mAlbumArtExecutor = null;
    
    /** Future for the current album art loading task. */
    @Nullable
    private Future<?> mCurrentAlbumArtTask = null;
    
    /** Path of the album art currently being loaded. */
    @Nullable
    private String mCurrentLoadingArtPath = null;
    
    /** Path of the currently displayed album art. */
    @Nullable
    private String mCurrentAlbumArtPath = null;
    
    /** Placeholder bitmap for when album art is unavailable. */
    @Nullable
    private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap before theme color applied. */
    @Nullable
    private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Executor for placeholder bitmap generation. */
    @NonNull
    private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Future for the current placeholder generation task. */
    @Nullable
    private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock for placeholder bitmap operations. */
    @NonNull
    private final Object mPlaceholderLock = new Object();
    
    /** Dim overlay view for loading states. */
    @Nullable
    private View mDimOverlay = null;
    
    /** Loading spinner shown during long operations. */
    @Nullable
    private ProgressBar mLoadingSpinner = null;
    
    /** Helper for applying theme to UI components. */
    @Nullable
    private ThemeHelper mThemeHelper;
    
    /** Manager for theme color and styling. */
    @Nullable
    private ThemeManager mThemeManager;
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Callback for notification album art updates. */
    @Nullable
    private OnAlbumArtUpdateListener mAlbumArtUpdateListener;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener for album art update events.
     * Used to update notification when album art changes.
     */
    public interface OnAlbumArtUpdateListener {
        /**
         * Called when album art is updated and ready for notification.
         *
         * @param art The album art bitmap (may be null)
         * @param placeholder The placeholder bitmap (may be null)
         * @param artPath The file path of the album art
         */
        void onAlbumArtUpdated(@Nullable Bitmap art, @Nullable Bitmap placeholder, @Nullable String artPath);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new DisplayManager.
     *
     * @param activity The parent activity
     * @param themeManager Theme manager for color access
     * @param themeHelper Theme helper for applying colors
     */
    public DisplayManager(@NonNull Activity activity, 
                          @NonNull ThemeManager themeManager, 
                          @NonNull ThemeHelper themeHelper) {
        mActivity = activity;
        mThemeManager = themeManager;
        mThemeHelper = themeHelper;
        
        // Initialize album art cache
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
            
            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled() && oldValue != mPlaceholderBitmap) {
                    oldValue.recycle();
                }
            }
        };
        
        mAlbumArtExecutor = Executors.newSingleThreadExecutor();
        
        Log.d(TAG, "DisplayManager initialized with " + MAX_CACHE_SIZE_MB + "MB cache");
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Sets the sync in progress flag.
     * Prevents album art updates during sync operations.
     *
     * @param inProgress True if sync is in progress
     */
    public void setSyncInProgress(boolean inProgress) {
        mIsSyncInProgress = inProgress;
    }
    
    /**
     * Sets the listener for album art updates.
     *
     * @param listener The listener to receive callbacks
     */
    public void setAlbumArtUpdateListener(@Nullable OnAlbumArtUpdateListener listener) {
        mAlbumArtUpdateListener = listener;
    }
    
    /**
     * Updates the album art display for the given song file.
     * 
     * <p>This method uses a caching strategy:</p>
     * <ol>
     *   <li>Check if the bitmap is already in the LRU cache</li>
     *   <li>If not, submit a background task to extract embedded album art</li>
     *   <li>Decode the album art with sampling to reduce memory usage</li>
     *   <li>Store in cache and display with fade animation</li>
     *   <li>Fall back to placeholder if no album art is available</li>
     * </ol>
     *
     * @param imageView The ImageView to display album art in
     * @param filePath The file path of the song
     */
    public void updateAlbumArt(@Nullable ImageView imageView, @Nullable final String filePath) {
        if (imageView == null) return;
        
        // Skip updates during sync
        if (mIsSyncInProgress && filePath != null && filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }
        
        // Clear current art if filePath is null
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder(imageView);
            }
            notifyAlbumArtUpdated(null, null, null);
            return;
        }
        
        // Skip if already showing this art
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        
        // Check cache first
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null && !cached.isRecycled()) {
                applyAlbumArtWithFade(imageView, cached);
                return;
            }
        }
        
        // Cancel any ongoing task
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;
        
        // Submit background task
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;
                
                MediaMetadataRetriever retriever = null;
                Bitmap result = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        result = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                
                final Bitmap bitmap = result;
                final ImageView finalImageView = imageView;
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mActivity.isFinishing() || mActivity.isDestroyed()) return;
                        if (!Thread.currentThread().isInterrupted() && 
                            taskPath.equals(mCurrentLoadingArtPath) && 
                            taskPath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, bitmap);
                                applyAlbumArtWithFade(finalImageView, bitmap);
                            } else {
                                loadAndDisplayPlaceholder(finalImageView);
                            }
                        }
                        if (mCurrentAlbumArtTask == Thread.currentThread()) {
                            mCurrentAlbumArtTask = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Applies album art with a fade-in animation.
     *
     * @param imageView The ImageView to apply the bitmap to
     * @param bitmap The album art bitmap to display
     */
    private void applyAlbumArtWithFade(@NonNull ImageView imageView, @Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder(imageView);
            notifyAlbumArtUpdated(null, null, null);
            return;
        }
        
        if (mActivity.isFinishing() || mActivity.isDestroyed()) return;
        
        imageView.setImageBitmap(bitmap);
        imageView.setAlpha(0f);
        
        imageView.animate()
            .alpha(1f)
            .setDuration(ALBUM_ART_FADE_DURATION_MS)
            .setListener(null)
            .start();
        
        notifyAlbumArtUpdated(bitmap, null, mCurrentAlbumArtPath);
    }
    
    /**
     * Notifies listener of album art update for notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path
     */
    private void notifyAlbumArtUpdated(@Nullable Bitmap art, @Nullable Bitmap placeholder, @Nullable String artPath) {
        if (mAlbumArtUpdateListener != null) {
            mAlbumArtUpdateListener.onAlbumArtUpdated(art, placeholder, artPath);
        }
    }
    
    /**
     * Loads and displays the placeholder album art image.
     *
     * @param imageView The ImageView to display the placeholder in
     */
    public void loadAndDisplayPlaceholder(@Nullable ImageView imageView) {
        if (imageView == null) return;
        updatePlaceholderBitmap(imageView);
    }
    
    /**
     * Clears the album art cache.
     */
    public void clearAlbumArtCache() {
        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            Log.d(TAG, "Album art cache cleared");
        }
        mCurrentAlbumArtPath = null;
        mCurrentLoadingArtPath = null;
    }
    
    /**
     * Removes a specific song from the album art cache.
     *
     * @param filePath The file path of the song
     */
    public void removeFromCache(@Nullable String filePath) {
        if (mAlbumArtCache != null && filePath != null) {
            mAlbumArtCache.remove(filePath);
            if (filePath.equals(mCurrentAlbumArtPath)) {
                mCurrentAlbumArtPath = null;
            }
        }
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Updates the placeholder bitmap with the current theme color.
     * 
     * <p>This method runs on a background thread to tint the placeholder
     * drawable with the current theme color.</p>
     *
     * @param imageView The ImageView to update when complete
     */
    private void updatePlaceholderBitmap(@NonNull final ImageView imageView) {
        if (mActivity.isFinishing() || mActivity.isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(mActivity.getResources(), 
                            R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    final ImageView finalImageView = imageView;
                    
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mActivity.isFinishing() || mActivity.isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            finalImageView.setImageBitmap(mPlaceholderBitmap);
                            notifyAlbumArtUpdated(null, mPlaceholderBitmap, null);
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }
    
    /**
     * Refreshes the placeholder bitmap (called when theme changes).
     *
     * @param imageView The ImageView to update
     */
    public void refreshPlaceholder(@Nullable ImageView imageView) {
        if (imageView != null) {
            updatePlaceholderBitmap(imageView);
        }
    }
    
    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    public void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a dim overlay with a loading spinner.
     * 
     * <p>The overlay is added to the decor view's content and
     * prevents user interaction during long operations.</p>
     *
     * @param rootView The root view to add the overlay to
     */
    public void showLoadingOverlay(@Nullable ViewGroup rootView) {
        if (rootView == null) return;
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final FrameLayout overlay = new FrameLayout(mActivity);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 
                    ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
                
                final FrameLayout container = new FrameLayout(mActivity);
                container.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, 
                    FrameLayout.LayoutParams.MATCH_PARENT));
                
                mLoadingSpinner = new ProgressBar(mActivity);
                mLoadingSpinner.setIndeterminate(true);
                
                final int sizePx = dpToPx(PROGRESS_BAR_SIZE_DP);
                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(sizePx, sizePx);
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Shows loading overlay with delay (for operations that might complete quickly).
     *
     * @param rootView The root view to add the overlay to
     */
    public void showDelayedLoadingOverlay(@Nullable ViewGroup rootView) {
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                showLoadingOverlay(rootView);
            }
        }, LOADING_OVERLAY_DELAY_MS);
    }
    
    /**
     * Hides the loading overlay if it is visible.
     */
    public void hideLoadingOverlay() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    /**
     * Cancels any pending delayed loading overlay.
     */
    public void cancelDelayedLoadingOverlay() {
        mMainHandler.removeCallbacksAndMessages(null);
    }
    
    // ========================================================================
    // Text Formatting Methods (Static Utilities)
    // ========================================================================
    
    /**
     * Formats milliseconds into a time string (MM:SS or HH:MM:SS).
     *
     * @param milliseconds The time in milliseconds
     * @return Formatted time string
     */
    @NonNull
    public static String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    /**
     * Truncates text to a maximum length with ellipsis.
     *
     * @param text The text to truncate
     * @param maxLength Maximum length before truncation
     * @return Truncated text with ellipsis if needed
     */
    @NonNull
    public static String truncateText(@Nullable String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        if (maxLength < 4) return text.substring(0, maxLength);
        return text.substring(0, maxLength - 3) + ELLIPSIS;
    }
    
    /**
     * Formats song title for display with truncation.
     *
     * @param title The song title
     * @return Formatted title
     */
    @NonNull
    public static String formatSongTitle(@Nullable String title) {
        return truncateText(title != null ? title : "Unknown Title", MAX_TITLE_LENGTH);
    }
    
    /**
     * Formats artist name for display with truncation.
     *
     * @param artist The artist name
     * @return Formatted artist name
     */
    @NonNull
    public static String formatArtistName(@Nullable String artist) {
        return truncateText(artist != null ? artist : "Unknown Artist", MAX_ARTIST_LENGTH);
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corners to the album art container.
     * 
     * <p>On Android 5.0+, uses ViewOutlineProvider for clipping.
     * On older versions, uses a background drawable with rounded corners.</p>
     *
     * @param container The album art container FrameLayout
     */
    public void applyAlbumArtClipping(@Nullable FrameLayout container) {
        if (container == null) return;
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            container.setClipToOutline(true);
            container.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(android.view.View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            container.setBackgroundResource(R.drawable.album_art_container);
        } else {
            container.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Cleanup Methods
    // ========================================================================
    
    /**
     * Releases all resources held by the DisplayManager.
     * Must be called when the parent activity is destroyed.
     */
    public void release() {
        // Cancel ongoing tasks
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        if (mCurrentPlaceholderTask != null && !mCurrentPlaceholderTask.isDone()) {
            mCurrentPlaceholderTask.cancel(true);
        }
        
        // Shutdown executors
        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdown();
        }
        
        if (mPlaceholderExecutor != null && !mPlaceholderExecutor.isShutdown()) {
            mPlaceholderExecutor.shutdown();
        }
        
        // Clear cache
        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
        
        // Cleanup bitmaps
        cleanupPlaceholderBitmaps();
        
        // Remove callbacks
        mMainHandler.removeCallbacksAndMessages(null);
        
        // Hide overlay
        hideLoadingOverlay();
        
        Log.d(TAG, "DisplayManager resources released");
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Calculates the sample size for efficient bitmap decoding.
     *
     * @param options The BitmapFactory.Options with out dimensions
     * @param reqWidth The requested width
     * @param reqHeight The requested height
     * @return The sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Decodes a byte array into a sampled bitmap to save memory.
     *
     * @param data The byte array containing image data
     * @param reqWidth The requested width
     * @param reqHeight The requested height
     * @return The sampled bitmap, or null if decoding fails
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565; // Use less memory
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Checks if a bitmap is valid for display.
     *
     * @param bitmap The bitmap to check
     * @return True if the bitmap is non-null, not recycled, and has positive dimensions
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    /**
     * Safely recycles a bitmap if it exists and is not already recycled.
     *
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.w(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    /**
     * Converts density-independent pixels to absolute pixels.
     *
     * @param dp The value in dp
     * @return The value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * mActivity.getResources().getDisplayMetrics().density);
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current placeholder bitmap.
     *
     * @return The placeholder bitmap, or null if not available
     */
    @Nullable
    public Bitmap getPlaceholderBitmap() {
        return mPlaceholderBitmap;
    }
    
    /**
     * Returns the cached album art for a file path.
     *
     * @param filePath The file path
     * @return The cached bitmap, or null if not cached
     */
    @Nullable
    public Bitmap getCachedAlbumArt(@Nullable String filePath) {
        if (mAlbumArtCache == null || filePath == null) return null;
        return mAlbumArtCache.get(filePath);
    }
    
    /**
     * Checks if the display manager is initialized and ready.
     *
     * @return True if ready
     */
    public boolean isReady() {
        return mAlbumArtCache != null && mAlbumArtExecutor != null;
    }
}