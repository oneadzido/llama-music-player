package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;

import androidx.core.content.ContextCompat;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Activity for controlling audio effects including equalizer, bass boost, surround,
 * pitch, and speed adjustments.
 * 
 * <p>This activity provides a comprehensive audio effects control panel that allows users to:
 * <ul>
 *   <li>Adjust equalizer band levels with a custom 10-band equalizer</li>
 *   <li>Select from 60 preset equalizer configurations</li>
 *   <li>Control bass boost and surround sound effects</li>
 *   <li>Adjust pitch and playback speed independently</li>
 *   <li>Round to nearest minimum increment for all controls</li>
 *   <li>Reset all effects to factory defaults using the Reset button</li>
 * </ul>
 * </p>
 * 
 * <h3>Rounding Behavior</h3>
 * <p>All SeekBars round to the nearest minimum increment:
 * <ul>
 *   <li><b>EQ Bands:</b> Rounds to nearest 0.1 dB (10 units)</li>
 *   <li><b>Bass Boost:</b> Rounds to nearest 1% (10 units)</li>
 *   <li><b>Surround:</b> Rounds to nearest 1% (10 units)</li>
 *   <li><b>Pitch:</b> Rounds to nearest 0.1 st (17 units)</li>
 *   <li><b>Speed:</b> Rounds to nearest 0.01x (20 units)</li>
 * </ul>
 * </p>
 * 
 * <h3>Reset Behavior</h3>
 * <p>The Reset button resets ALL effects to default values:
 * <ul>
 *   <li><b>EQ Bands:</b> Set to 0.0 dB</li>
 *   <li><b>Bass Boost:</b> Set to 0%</li>
 *   <li><b>Surround:</b> Set to 0%</li>
 *   <li><b>Pitch:</b> Set to 0.0 st</li>
 *   <li><b>Speed:</b> Set to 1.00x</li>
 * </ul>
 * </p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The EqualizerActivity delegates all audio effect processing to {@link EqualizerManager},
 * which handles the low-level Android audio framework interactions. The activity dynamically
 * creates UI controls based on the device's reported capabilities (number of bands,
 * support for bass boost/surround).</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All UI updates are routed through {@link #safeRunOnUiThread(Runnable)} which uses
 * {@link AtomicBoolean} flags to prevent concurrent updates and ensure operations
 * don't execute after the activity is destroyed.</p>
 * 
 * <h3>Integration Points</h3>
 * <ul>
 *   <li>{@link EqualizerManager} - Core audio effect processing</li>
 *   <li>{@link MusicService} - Audio playback service with session ID</li>
 *   <li>{@link PresetDialog} - Modal dialog for preset selection</li>
 *   <li>{@link ThemeHelper} - Dynamic theme color application</li>
 *   <li>{@link ToastManager} - Custom toast notifications</li>
 * </ul>
 * 
 * @see EqualizerManager
 * @see PresetDialog
 * @see ThemeHelper
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.1
 * @since 1.0
 */
public class EqualizerActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging purposes. */
    private static final String TAG = "EqualizerActivity";
    
    /** Broadcast action for audio session changes from MusicService. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Broadcast action for updating playback parameters (pitch/speed). */
    private static final String ACTION_UPDATE_PLAYBACK_PARAMS = "UPDATE_PLAYBACK_PARAMS";
    
    /** Broadcast action for theme color change notifications. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Duration for button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of original size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button release animation (normal size). */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Maximum value for bass boost and surround SeekBars. */
    private static final int SEEKBAR_MAX_BOOST = 1000;
    
    /** Maximum value for pitch and speed SeekBars. */
    private static final int SEEKBAR_MAX = 2000;
    
    /** Default value for bass boost and surround (0%). */
    private static final int BOOST_DEFAULT = 0;
    
    /** Default value for pitch SeekBar (0 semitones). */
    private static final int PITCH_DEFAULT = 1000;
    
    /** Default value for speed SeekBar (1.00x speed). */
    private static final int SPEED_DEFAULT = 1000;
    
    /**
     * Units per 1% for bass boost and surround.
     * Range: 0-1000 represents 0-100%
     * 1% = 10 units
     */
    private static final int BOOST_UNITS_PER_PERCENT = 10;
    
    /**
     * Units per 0.1 dB for equalizer bands.
     * Range: -1500 to +1500 represents -15 to +15 dB
     * 0.1 dB = 10 units
     */
    private static final int EQ_BAND_UNITS_PER_STEP = 10;
    
    /**
     * Units per 0.1 st for pitch.
     * Range: 0-2000 represents -6 to +6 semitones
     * 0.1 st = 17 units
     */
    private static final int PITCH_UNITS_PER_STEP = 17;
    
    /**
     * Units per 0.01x for speed.
     * Range: 0-2000 represents 0.5x to 1.5x
     * 0.01x = 20 units
     */
    private static final int SPEED_UNITS_PER_STEP = 20;
    
    /** Light gray text color for secondary UI elements. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Disabled text color for inactive controls. */
    private static final String COLOR_DISABLED = "#5A5A5A";
    
    /** Debounce delay for preset button clicks in milliseconds. */
    private static final long PRESET_DEBOUNCE_DELAY_MS = 500;
    
    /** Duration for temporary status messages in milliseconds. */
    private static final int STATUS_MESSAGE_DURATION_MS = 1500;
    
    /** Delay for UI refresh after reattaching to audio session. */
    private static final long UI_REFRESH_DELAY_MS = 200;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** Container for dynamic equalizer band controls. */
    private LinearLayout bandsContainer;
    
    /** Button to open preset selection dialog. */
    private Button presetButton;
    
    /** SeekBar for bass boost level (0-100%). */
    private SeekBar bassBoostSeekBar;
    
    /** SeekBar for surround effect level (0-100%). */
    private SeekBar surroundSeekBar;
    
    /** SeekBar for pitch adjustment (-6 to +6 semitones). */
    private SeekBar pitchSeekBar;
    
    /** SeekBar for playback speed adjustment (0.5x to 1.5x). */
    private SeekBar speedSeekBar;
    
    /** Text displaying current bass boost percentage. */
    private TextView bassBoostValueText;
    
    /** Text displaying current surround percentage. */
    private TextView surroundValueText;
    
    /** Text displaying current pitch in semitones (e.g., "+2.0 st", "-1.5 st", "0.0 st"). */
    private TextView pitchValueText;
    
    /** Text displaying current speed multiplier (e.g., "1.00x", "1.50x"). */
    private TextView speedValueText;
    
    /** Button to reset all effects to factory defaults. */
    private Button resetButton;
    
    /** Button to close the equalizer activity. */
    private Button cancelButton;
    
    /** Button to enable/disable the equalizer. */
    private Button enableButton;
    
    /** Text view showing status messages ("ENJOY THE WAVES", "Equalizer: Enabled", etc.). */
    private TextView statusText;
    
    /** Array of SeekBars for each equalizer band. */
    private SeekBar[] bandSeekBars;
    
    /** Array of TextViews displaying current band levels in dB. */
    private TextView[] bandValueTexts;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Handler for main thread operations (delayed tasks, UI updates). */
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if the equalizer is ready for use. */
    private boolean isEqualizerReady = false;
    
    /** Flag indicating if band controls have been created. */
    private boolean areBandsCreated = false;
    
    /** Runnable for reverting status text to default message after delay. */
    private Runnable revertToWavesRunnable;
    
    /** Timestamp of last preset button click for debouncing. */
    private long lastPresetClickTime = 0;
    
    /** Flag indicating if preset dialog is currently showing. */
    private boolean isPresetDialogShowing = false;
    
    /** Atomic flag preventing operations after activity destruction. */
    private final AtomicBoolean isClosing = new AtomicBoolean(false);
    
    /** Atomic flag preventing concurrent UI update operations. */
    private final AtomicBoolean isUpdatingUI = new AtomicBoolean(false);
    
    /** Flag indicating if bass boost rounding is in progress (to prevent recursive updates). */
    private boolean isBassRounding = false;
    
    /** Flag indicating if surround rounding is in progress (to prevent recursive updates). */
    private boolean isSurroundRounding = false;
    
    /** Flag indicating if EQ band rounding is in progress (to prevent recursive updates). */
    private boolean isEqRounding = false;
    
    /** Flag indicating if pitch rounding is in progress (to prevent recursive updates). */
    private boolean isPitchRounding = false;
    
    /** Flag indicating if speed rounding is in progress (to prevent recursive updates). */
    private boolean isSpeedRounding = false;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Manager for all audio effect operations. */
    private EqualizerManager equalizerManager;
    
    /** Manager for theme color storage and retrieval. */
    private ThemeManager themeManager;
    
    /** Helper for applying theme colors to UI components. */
    private ThemeHelper themeHelper;
    
    /** Broadcast receiver for theme color change events. */
    private BroadcastReceiver themeReceiver;
    
    /** Reference to MusicService for playback control. */
    private MusicService musicService;
    
    /** Service connection for binding to MusicService. */
    private ServiceConnection serviceConnection;
    
    /** Flag indicating if MusicService is bound. */
    private boolean isServiceBound = false;
    
    /** Flag indicating if service binding is complete. */
    private boolean isBindingComplete = false;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /**
     * Listens for audio session changes from MusicService.
     * When a new audio session is available, reattaches the equalizer.
     */
    private final BroadcastReceiver audioSessionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) return;
            if (ACTION_AUDIO_SESSION_CHANGED.equals(intent.getAction())) {
                final int newSessionId = intent.getIntExtra("audio_session_id", -1);
                Log.d(TAG, "Audio session changed: " + newSessionId);
                if (newSessionId > 0) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                equalizerManager.attachToAudioSession(newSessionId);
                            }
                        }
                    });
                }
            }
        }
    };
    
    /**
     * Listens for playback parameter update requests.
     * Refreshes all effect values when MusicService requests an update.
     */
    private final BroadcastReceiver updatePlaybackParamsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) return;
            if (ACTION_UPDATE_PLAYBACK_PARAMS.equals(intent.getAction())) {
                safeRunOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateAllEffectValues();
                    }
                });
            }
        }
    };
    
    // ========================================================================
    // Equalizer Listener
    // ========================================================================
    
    /**
     * Callback interface for EqualizerManager events.
     * Updates UI in response to band level changes, preset changes, and ready state.
     */
    private final EqualizerManager.EqualizerListener equalizerListener = new EqualizerManager.EqualizerListener() {
        @Override
        public void onBandLevelsChanged(int[] levels) {
            if (isClosing.get()) return;
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (bandSeekBars != null) updateBandControlsFromLevels();
                }
            });
        }
        
        @Override
        public void onPresetChanged(final int preset, final String presetName) {
            if (isClosing.get()) return;
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (presetButton != null) {
                        presetButton.setText(presetName);
                    }
                    if (statusText != null && equalizerManager != null 
                            && equalizerManager.isEnabled() && hasAudioSession()) {
                        showTemporaryMessage("Equalizer: " + presetName);
                        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                    }
                }
            });
        }
        
        @Override
        public void onEqualizerReady(final boolean ready) {
            if (isClosing.get()) return;
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    isEqualizerReady = ready;
                    boolean hasAudio = hasAudioSession();
                    
                    if (resetButton != null) {
                        resetButton.setEnabled(hasAudio);
                        themeHelper.updateButton(resetButton, hasAudio);
                    }
                    
                    if (ready) {
                        handleEqualizerReady(hasAudio);
                    } else {
                        handleEqualizerNotReady();
                    }
                }
            });
        }
    };
    
    // ========================================================================
    // Thread Safety Methods
    // ========================================================================
    
    /**
     * Safely executes a UI update on the main thread.
     * Prevents execution if the activity is finishing, destroyed, or closing.
     * Uses AtomicBoolean to prevent concurrent UI updates.
     * 
     * @param action The runnable to execute on the UI thread
     */
    private void safeRunOnUiThread(final Runnable action) {
        if (isFinishing() || isDestroyed() || isClosing.get()) return;
        if (!isUpdatingUI.compareAndSet(false, true)) return;
        
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed() && !isClosing.get()) {
                        action.run();
                    }
                } finally {
                    isUpdatingUI.set(false);
                }
            }
        });
    }
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_equalizer);
        
        initializeManagers();
        initializeViews();
        setupListeners();
        registerReceivers();
        bindMusicService();
        
        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
        } else {
            handleNoAudioSession();
        }
        
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        applyThemeToUI();
        themeAllHeaders();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        if (isClosing.get()) return;
        
        registerThemeReceiverIfNeeded();
        updateUI(false);
        updateAllEffectValues();
        
        boolean hasAudio = hasAudioSession();
        updateResetButtonState(hasAudio);
        
        if (!hasAudio) handleNoAudioSession();
        
        updateBandControlsState();
        
        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
            // Refresh all UI controls after reattachment
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isClosing.get() && equalizerManager.isAttached()) {
                        refreshAllUIControls();
                    }
                }
            }, UI_REFRESH_DELAY_MS);
        } else {
            handleNoAudioSession();
        }
        
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        if (themeReceiver != null) {
            try { unregisterReceiver(themeReceiver); } catch (Exception e) {}
            themeReceiver = null;
        }
    }
    
    @Override
    protected void onDestroy() {
        isClosing.set(true);
        super.onDestroy();
        
        unbindServiceSafely();
        unregisterReceiverSafely(audioSessionReceiver);
        unregisterReceiverSafely(updatePlaybackParamsReceiver);
        unregisterReceiverSafely(themeReceiver);
        
        if (revertToWavesRunnable != null) mainHandler.removeCallbacks(revertToWavesRunnable);
        if (equalizerManager != null) equalizerManager.setListener(null);
    }
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && !isClosing.get()) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
    
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
    
    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the EqualizerManager, ThemeManager, and ThemeHelper instances.
     * Sets the equalizer listener to receive callbacks.
     */
    private void initializeManagers() {
        equalizerManager = EqualizerManager.getInstance(this);
        equalizerManager.setListener(equalizerListener);
        themeManager = ThemeManager.getInstance(this);
        themeHelper = ThemeHelper.getInstance(this);
    }
    
    /**
     * Registers broadcast receivers for audio session changes and playback parameter updates.
     */
    private void registerReceivers() {
        IntentFilter audioSessionFilter = new IntentFilter();
        audioSessionFilter.addAction(ACTION_AUDIO_SESSION_CHANGED);
        registerReceiver(audioSessionReceiver, audioSessionFilter);
        
        IntentFilter paramsFilter = new IntentFilter(ACTION_UPDATE_PLAYBACK_PARAMS);
        registerReceiver(updatePlaybackParamsReceiver, paramsFilter);
    }
    
    /**
     * Binds to MusicService to obtain a reference for playback control.
     * The service connection allows notifying the service of parameter changes.
     */
    private void bindMusicService() {
        Intent bindIntent = new Intent(this, MusicService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                musicService = binder.getService();
                isServiceBound = true;
                isBindingComplete = true;
                updateUI(false);
                updateAllEffectValues();
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                musicService = null;
                isServiceBound = false;
            }
        };
        bindService(bindIntent, serviceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Registers the theme receiver if not already registered.
     * Listens for theme color changes to dynamically update UI colors.
     */
    private void registerThemeReceiverIfNeeded() {
        if (themeReceiver != null) return;
        
        themeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (isClosing.get()) return;
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                applyThemeToUI();
                                themeAllHeaders();
                                ToastManager.refreshThemeColor();
                            }
                        }
                    });
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        registerReceiver(themeReceiver, filter);
    }
    
    // ========================================================================
    // Helper Methods for State Management
    // ========================================================================
    
    /**
     * Checks if there is an active audio session.
     * 
     * @return True if audio session ID is greater than 0
     */
    private boolean hasAudioSession() {
        return MusicService.getAudioSessionId() > 0;
    }
    
    /**
     * Checks if the equalizer is operational and ready for use.
     * Requires equalizer to be enabled, attached, and have valid bands.
     * 
     * @return True if equalizer can be used
     */
    private boolean isEqualizerOperational() {
        return equalizerManager != null && 
               equalizerManager.isEnabled() && 
               hasAudioSession() &&
               equalizerManager.isAttached() &&
               equalizerManager.getNumberOfBands() > 0;
    }
    
    /**
     * Refreshes all UI controls from the EqualizerManager.
     * This ensures the UI matches the current state of the manager.
     * Values are read from the manager (not SharedPreferences directly).
     */
    private void refreshAllUIControls() {
        if (equalizerManager == null) return;
        
        boolean isEnabled = equalizerManager.isEnabled();
        boolean hasAudio = hasAudioSession();
        int themeColor = themeHelper.getThemeColorInt();
        
        // Refresh bass boost
        if (bassBoostSeekBar != null) {
            if (equalizerManager.isBassBoostSupported()) {
                int bassLevel = equalizerManager.getBassBoost();
                bassBoostSeekBar.setProgress(bassLevel);
                updateBassBoostValue(bassLevel);
                bassBoostSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                bassBoostSeekBar.setEnabled(false);
                if (bassBoostValueText != null) bassBoostValueText.setText("OFF");
            }
        }
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor((isEnabled && hasAudio && equalizerManager.isBassBoostSupported()) 
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
        
        // Refresh surround
        if (surroundSeekBar != null) {
            if (equalizerManager.isSurroundSupported()) {
                int surroundLevel = equalizerManager.getSurround();
                surroundSeekBar.setProgress(surroundLevel);
                updateSurroundValue(surroundLevel);
                surroundSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                surroundSeekBar.setEnabled(false);
                if (surroundValueText != null) surroundValueText.setText("OFF");
            }
        }
        if (surroundValueText != null) {
            surroundValueText.setTextColor((isEnabled && hasAudio && equalizerManager.isSurroundSupported()) 
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
        
        // Refresh pitch
        if (pitchSeekBar != null) {
            int pitchLevel = equalizerManager.getPitch();
            pitchSeekBar.setProgress(pitchLevel);
            updatePitchValue(pitchLevel);
            pitchSeekBar.setEnabled(hasAudio);
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(hasAudio ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
        
        // Refresh speed
        if (speedSeekBar != null) {
            int speedLevel = equalizerManager.getSpeed();
            speedSeekBar.setProgress(speedLevel);
            updateSpeedValue(speedLevel);
            speedSeekBar.setEnabled(hasAudio);
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(hasAudio ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
        
        // Refresh band controls
        updateBandControlsFromLevels();
        
        // Update preset button
        if (presetButton != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            presetButton.setText(equalizerManager.getPresetName(currentPreset));
            presetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(presetButton, isEnabled && hasAudio);
        }
        
        // Update enable button
        if (enableButton != null) {
            enableButton.setEnabled(hasAudio);
            enableButton.setText(isEnabled ? "DISABLE" : "ENABLE");
            themeHelper.updateButton(enableButton, hasAudio);
        }
        
        // Update reset button
        if (resetButton != null) {
            resetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(resetButton, isEnabled && hasAudio);
        }
        
        // Update status text
        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("ENJOY THE WAVES");
                statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            } else {
                statusText.setText("Equalizer: Disabled");
                statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            }
        }
    }
    
    /**
     * Handles the state when the equalizer becomes ready.
     * Creates band controls, updates UI values, and sets initial state.
     * 
     * @param hasAudio True if an audio session exists
     */
    private void handleEqualizerReady(boolean hasAudio) {
        if (equalizerManager != null && equalizerManager.getNumberOfBands() > 0 && !areBandsCreated) {
            createBandControls();
            areBandsCreated = true;
        }
        
        // Refresh all UI controls
        refreshAllUIControls();
        
        if (hasAudio) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) presetButton.setText("Disabled");
            if (enableButton != null) {
                enableButton.setEnabled(false);
                themeHelper.updateButton(enableButton, false);
                enableButton.setText("ENABLE");
            }
        }
        
        boolean isEnabled = equalizerManager != null && equalizerManager.isEnabled();
        updateUIState(isEnabled);
        
        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("Equalizer: Enabled");
                statusText.setTextColor(themeHelper.getThemeColorInt());
            } else {
                statusText.setText("Equalizer: Disabled");
                statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            }
        }
        
        if (enableButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(enableButton, enableButton.isEnabled());
        }
        if (resetButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(resetButton, resetButton.isEnabled());
        }
    }
    
    /**
     * Handles the state when the equalizer is not ready.
     * Disables all controls and shows disabled status while preserving values.
     */
    private void handleEqualizerNotReady() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
        
        updateUIState(false);
        
        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }
        
        if (presetButton != null) presetButton.setText("Disabled");
        
        // Disable and gray out all controls while preserving their values
        refreshAllUIControls();
    }
    
    /**
     * Handles the case when no audio session is available.
     * Shows disabled state for all controls while preserving values.
     */
    private void handleNoAudioSession() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
        if (presetButton != null) presetButton.setText("Disabled");
        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }
        if (resetButton != null) {
            resetButton.setEnabled(false);
            themeHelper.updateButton(resetButton, false);
        }
        
        // Disable and gray out all controls while preserving their values
        // Read from SharedPreferences to keep values visible
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        // Bass Boost - keep value, disable and gray out
        if (bassBoostSeekBar != null) {
            int savedBass = prefs.getInt("bass_boost_level", 0);
            bassBoostSeekBar.setProgress(savedBass);
            updateBassBoostValue(savedBass);
            bassBoostSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(bassBoostSeekBar, false);
            }
        }
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(Color.parseColor(COLOR_DISABLED));
        }
        
        // Surround - keep value, disable and gray out
        if (surroundSeekBar != null) {
            int savedSurround = prefs.getInt("surround_level", 0);
            surroundSeekBar.setProgress(savedSurround);
            updateSurroundValue(savedSurround);
            surroundSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(surroundSeekBar, false);
            }
        }
        if (surroundValueText != null) {
            surroundValueText.setTextColor(Color.parseColor(COLOR_DISABLED));
        }
        
        // Pitch - keep value, disable and gray out
        if (pitchSeekBar != null) {
            int savedPitch = prefs.getInt("pitch_level", PITCH_DEFAULT);
            pitchSeekBar.setProgress(savedPitch);
            updatePitchValue(savedPitch);
            pitchSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(pitchSeekBar, false);
            }
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(Color.parseColor(COLOR_DISABLED));
        }
        
        // Speed - keep value, disable and gray out
        if (speedSeekBar != null) {
            int savedSpeed = prefs.getInt("speed_level", SPEED_DEFAULT);
            speedSeekBar.setProgress(savedSpeed);
            updateSpeedValue(savedSpeed);
            speedSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(speedSeekBar, false);
            }
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(Color.parseColor(COLOR_DISABLED));
        }
        
        // Band controls - keep values, disable and gray out
        if (bandSeekBars != null) {
            int minLevel = equalizerManager != null ? equalizerManager.getMinBandLevel() : -1500;
            for (int i = 0; i < bandSeekBars.length; i++) {
                SeekBar seekBar = bandSeekBars[i];
                if (seekBar != null) {
                    int savedLevel = prefs.getInt("eq_band_" + i, 0);
                    int progress = savedLevel - minLevel;
                    seekBar.setProgress(Math.max(0, Math.min(seekBar.getMax(), progress)));
                    seekBar.setEnabled(false);
                    if (themeHelper != null) {
                        themeHelper.updateSeekBar(seekBar, false);
                    }
                }
            }
        }
        if (bandValueTexts != null) {
            for (TextView tv : bandValueTexts) {
                if (tv != null) {
                    tv.setTextColor(Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }
    
    /**
     * Updates the reset button's enabled state based on audio session availability.
     * 
     * @param hasAudio True if an audio session exists
     */
    private void updateResetButtonState(boolean hasAudio) {
        if (resetButton != null) {
            resetButton.setEnabled(hasAudio);
            themeHelper.updateButton(resetButton, hasAudio);
        }
    }
    
    /**
     * Updates the state of all band controls.
     * Refreshes band levels from equalizer manager and sets enabled state.
     */
    private void updateBandControlsState() {
        if (bandSeekBars != null) {
            updateBandControlsFromLevels();
            boolean isEnabled = equalizerManager != null && equalizerManager.isEnabled();
            boolean hasAudio = hasAudioSession();
            for (SeekBar seekBar : bandSeekBars) {
                if (seekBar != null) seekBar.setEnabled(isEnabled && hasAudio);
            }
        }
    }
    
    /**
     * Safely unbinds from MusicService, catching any exceptions.
     */
    private void unbindServiceSafely() {
        if (isServiceBound) {
            try { unbindService(serviceConnection); } catch (Exception e) {}
            isServiceBound = false;
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver, catching any exceptions.
     * 
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception e) {}
        }
    }
    
    // ========================================================================
    // UI Display Methods
    // ========================================================================
    
    /**
     * Shows a temporary message in the statusText view.
     * Message reverts to default after 1.5 seconds.
     * 
     * @param message The message to display
     */
    private void showTemporaryMessage(String message) {
        showTemporaryMessage(message, false);
    }
    
    /**
     * Shows a temporary message in the statusText view.
     * Message reverts to default after {@link #STATUS_MESSAGE_DURATION_MS}.
     * 
     * @param message The message to display
     * @param isEnableMessage True if this is an enable/disable message
     */
    private void showTemporaryMessage(String message, boolean isEnableMessage) {
        if (statusText == null || isClosing.get()) return;
        if (revertToWavesRunnable != null) mainHandler.removeCallbacks(revertToWavesRunnable);
        
        statusText.setText(message);
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        
        revertToWavesRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isClosing.get() && statusText != null && equalizerManager != null 
                        && equalizerManager.isEnabled() && hasAudioSession()) {
                    statusText.setText("ENJOY THE WAVES");
                    statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                } else if (!isClosing.get() && statusText != null && hasAudioSession()) {
                    statusText.setText("Equalizer: Disabled");
                    statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                }
            }
        };
        mainHandler.postDelayed(revertToWavesRunnable, STATUS_MESSAGE_DURATION_MS);
    }
    
    /**
     * Shows a persistent disabled message in the statusText view.
     * Removes any pending revert callbacks.
     */
    private void showPersistentDisabledMessage() {
        if (statusText == null || isClosing.get()) return;
        if (revertToWavesRunnable != null) mainHandler.removeCallbacks(revertToWavesRunnable);
        statusText.setText("Equalizer: Disabled");
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets status bar and navigation bar colors based on Android version.
     * Uses deprecated methods for backward compatibility.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components from layout resources.
     * Sets up buttons with animations and initializes effect controls.
     */
    private void initializeViews() {
        bandsContainer = (LinearLayout) findViewById(R.id.bandsContainer);
        presetButton = (Button) findViewById(R.id.presetButton);
        bassBoostSeekBar = (SeekBar) findViewById(R.id.bassBoostSeekBar);
        surroundSeekBar = (SeekBar) findViewById(R.id.surroundSeekBar);
        pitchSeekBar = (SeekBar) findViewById(R.id.pitchSeekBar);
        speedSeekBar = (SeekBar) findViewById(R.id.speedSeekBar);
        bassBoostValueText = (TextView) findViewById(R.id.bassBoostValueText);
        surroundValueText = (TextView) findViewById(R.id.surroundValueText);
        pitchValueText = (TextView) findViewById(R.id.pitchValueText);
        speedValueText = (TextView) findViewById(R.id.speedValueText);
        resetButton = (Button) findViewById(R.id.resetButton);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        enableButton = (Button) findViewById(R.id.enableButton);
        statusText = (TextView) findViewById(R.id.statusText);
        
        animateButton(presetButton);
        animateButton(resetButton);
        animateButton(cancelButton);
        animateButton(enableButton);
        
        initializePresetButtonText();
        initializeResetButtonState();
        initializeEffectControls();
        
        updateUIState(false);
    }
    
    /**
     * Initializes the preset button text based on current preset or disabled state.
     */
    private void initializePresetButtonText() {
        if (hasAudioSession() && equalizerManager != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) presetButton.setText("Disabled");
        }
    }
    
    /**
     * Initializes the reset button's enabled state and text color.
     */
    private void initializeResetButtonState() {
        if (resetButton != null) {
            boolean hasAudio = hasAudioSession();
            resetButton.setEnabled(hasAudio);
            themeHelper.updateButton(resetButton, hasAudio);
        }
    }
    
    /**
     * Initializes all effect controls (bass boost, surround, pitch, speed)
     * with their current values from EqualizerManager.
     */
    private void initializeEffectControls() {
        if (equalizerManager == null) return;
        
        if (equalizerManager.isBassBoostSupported()) {
            bassBoostSeekBar.setMax(SEEKBAR_MAX_BOOST);
            bassBoostSeekBar.setProgress(equalizerManager.getBassBoost());
            updateBassBoostValue(equalizerManager.getBassBoost());
        } else {
            bassBoostSeekBar.setEnabled(false);
            if (bassBoostValueText != null) bassBoostValueText.setText("OFF");
        }
        
        if (equalizerManager.isSurroundSupported()) {
            surroundSeekBar.setMax(SEEKBAR_MAX_BOOST);
            surroundSeekBar.setProgress(equalizerManager.getSurround());
            updateSurroundValue(equalizerManager.getSurround());
        } else {
            surroundSeekBar.setEnabled(false);
            if (surroundValueText != null) surroundValueText.setText("OFF");
        }
        
        pitchSeekBar.setMax(SEEKBAR_MAX);
        pitchSeekBar.setProgress(equalizerManager.getPitch());
        updatePitchValue(equalizerManager.getPitch());
        
        speedSeekBar.setMax(SEEKBAR_MAX);
        speedSeekBar.setProgress(equalizerManager.getSpeed());
        updateSpeedValue(equalizerManager.getSpeed());
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Applies header styling to all header TextViews in the activity.
     * Recursively traverses the view hierarchy to find and style header texts.
     */
    private void themeAllHeaders() {
        if (isClosing.get()) return;
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     * Targets TextViews containing "EQUALIZER", "BASS BOOST", "SURROUND", "PITCH", "SPEED",
     * or "ENJOY THE WAVES".
     * 
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof TextView && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                if (text.equals("EQUALIZER") || text.equals("BASS BOOST") 
                        || text.equals("SURROUND") || text.equals("PITCH") 
                        || text.equals("SPEED") || text.equals("ENJOY THE WAVES")) {
                    textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }
    
    /**
     * Applies the current theme color to all UI components.
     * Updates buttons, seek bars, and text views with the themed color.
     * Handles enabled/disabled states appropriately.
     * 
     * IMPORTANT: This method should ONLY be called on the UI thread.
     * It does NOT use safeRunOnUiThread to prevent recursive deadlocks.
     */
    private void applyThemeToUI() {
        if (isClosing.get() || themeHelper == null || themeManager == null) {
            return;
        }
        
        themeHelper.setThemeColor(themeManager.getCurrentColor());
        
        // Use themeHelper.updateButton for all buttons - this properly maintains ColorStateList
        if (presetButton != null) themeHelper.updateButton(presetButton, presetButton.isEnabled());
        if (resetButton != null) themeHelper.updateButton(resetButton, resetButton.isEnabled());
        if (cancelButton != null) themeHelper.updateButton(cancelButton, cancelButton.isEnabled());
        if (enableButton != null) themeHelper.updateButton(enableButton, enableButton.isEnabled());
        
        if (bassBoostSeekBar != null) themeHelper.updateSeekBar(bassBoostSeekBar, bassBoostSeekBar.isEnabled());
        if (surroundSeekBar != null) themeHelper.updateSeekBar(surroundSeekBar, surroundSeekBar.isEnabled());
        if (pitchSeekBar != null) themeHelper.updateSeekBar(pitchSeekBar, pitchSeekBar.isEnabled());
        if (speedSeekBar != null) themeHelper.updateSeekBar(speedSeekBar, speedSeekBar.isEnabled());
        
        if (bandSeekBars != null) {
            for (SeekBar bandSeekBar : bandSeekBars) {
                if (bandSeekBar != null) themeHelper.updateSeekBar(bandSeekBar, bandSeekBar.isEnabled());
            }
        }
        
        updateValueTextWithSeekBar(bassBoostValueText, bassBoostSeekBar);
        updateValueTextWithSeekBar(surroundValueText, surroundSeekBar);
        updateValueTextWithSeekBar(pitchValueText, pitchSeekBar);
        updateValueTextWithSeekBar(speedValueText, speedSeekBar);
        
        if (statusText != null && equalizerManager != null) {
            if (equalizerManager.isEnabled() && hasAudioSession()) {
                statusText.setText("ENJOY THE WAVES");
                statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            } else {
                statusText.setText("Equalizer: Disabled");
                statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            }
        }
        
        if (bandValueTexts != null && equalizerManager != null) {
            for (TextView tv : bandValueTexts) {
                if (tv != null && equalizerManager.isEnabled() && hasAudioSession()) {
                    themeHelper.updateTextView(tv, true);
                }
            }
        }
    }
    
    /**
     * Updates a value TextView based on its associated SeekBar's enabled state.
     * When SeekBar is disabled, text turns gray; when enabled, uses theme color.
     *
     * @param valueText The TextView displaying the value (e.g., "0%", "0.0 st", "1.00x")
     * @param seekBar The SeekBar controlling the value
     */
    private void updateValueTextWithSeekBar(@Nullable TextView valueText, @Nullable SeekBar seekBar) {
        if (valueText != null && seekBar != null) {
            boolean enabled = seekBar.isEnabled();
            themeHelper.updateTextView(valueText, enabled);
            if (!enabled) {
                valueText.setTextColor(Color.parseColor(COLOR_DISABLED));
            }
        }
    }
    
    // ========================================================================
    // Button Animation
    // ========================================================================
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% on touch and returns to normal on release.
     * 
     * @param button The button to animate (can be null)
     */
    private void animateButton(final Button button) {
        if (button == null || isClosing.get()) return;
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // UI State Management
    // ========================================================================
    
    /**
     * Updates the entire UI state based on equalizer enabled status.
     * Controls enable/disable states for all interactive elements.
     * 
     * @param enabled Current equalizer enabled state
     */
    private void updateUIState(boolean enabled) {
        if (isClosing.get()) return;
        
        boolean hasAudio = hasAudioSession();
        boolean canEnable = isEqualizerReady && hasAudio;
        int themeColor = themeHelper.getThemeColorInt();
        
        updatePresetButtonState(enabled, canEnable, hasAudio);
        updateResetButtonState(canEnable);
        updateBassBoostControlState(enabled, canEnable, themeColor);
        updateSurroundControlState(enabled, canEnable, themeColor);
        updatePitchControlState(canEnable, themeColor);
        updateSpeedControlState(canEnable, themeColor);
        updateBandControlsState(enabled, canEnable, themeColor);
        updateEnableButtonState(canEnable, enabled);
    }
    
    /**
     * Updates the preset button's enabled state and text.
     * ThemeHelper handles the ColorStateList (WHITE on press, theme color normally).
     */
    private void updatePresetButtonState(boolean enabled, boolean canEnable, boolean hasAudio) {
        if (presetButton == null) return;
        boolean shouldBeEnabled = enabled && canEnable;
        presetButton.setEnabled(shouldBeEnabled);
        themeHelper.updateButton(presetButton, shouldBeEnabled);
        if (!hasAudio) {
            presetButton.setText("Disabled");
        } else if (equalizerManager != null) {
            presetButton.setText(equalizerManager.getPresetName(equalizerManager.getCurrentPreset()));
        }
    }
    
    /**
     * Updates the reset button's enabled state.
     * ThemeHelper handles the ColorStateList (WHITE on press, theme color normally).
     */
    private void updateResetButtonState(boolean canEnable) {
        if (resetButton == null) return;
        boolean anyEffectOperational = canEnable;
        resetButton.setEnabled(anyEffectOperational);
        themeHelper.updateButton(resetButton, anyEffectOperational);
    }
    
    /**
     * Updates bass boost control enabled state and value text color.
     */
    private void updateBassBoostControlState(boolean enabled, boolean canEnable, int themeColor) {
        if (bassBoostSeekBar == null || equalizerManager == null) return;
        boolean boosterEnabled = enabled && canEnable && equalizerManager.isBassBoostSupported();
        bassBoostSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(bassBoostSeekBar, boosterEnabled);
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(boosterEnabled ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }
    
    /**
     * Updates surround control enabled state and value text color.
     */
    private void updateSurroundControlState(boolean enabled, boolean canEnable, int themeColor) {
        if (surroundSeekBar == null || equalizerManager == null) return;
        boolean boosterEnabled = enabled && canEnable && equalizerManager.isSurroundSupported();
        surroundSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(surroundSeekBar, boosterEnabled);
        if (surroundValueText != null) {
            surroundValueText.setTextColor(boosterEnabled ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }
    
    /**
     * Updates pitch control enabled state and value text color.
     */
    private void updatePitchControlState(boolean canEnable, int themeColor) {
        if (pitchSeekBar == null) return;
        pitchSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(pitchSeekBar, canEnable);
        if (pitchValueText != null) {
            pitchValueText.setTextColor(canEnable ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }
    
    /**
     * Updates speed control enabled state and value text color.
     */
    private void updateSpeedControlState(boolean canEnable, int themeColor) {
        if (speedSeekBar == null) return;
        speedSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(speedSeekBar, canEnable);
        if (speedValueText != null) {
            speedValueText.setTextColor(canEnable ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }
    
    /**
     * Updates all band controls' enabled state and value text colors.
     */
    private void updateBandControlsState(boolean enabled, boolean canEnable, int themeColor) {
        if (bandSeekBars == null || equalizerManager == null) return;
        for (SeekBar seekBar : bandSeekBars) {
            if (seekBar != null) {
                seekBar.setEnabled(enabled && canEnable);
                themeHelper.updateSeekBar(seekBar, enabled && canEnable);
            }
        }
        if (bandValueTexts != null) {
            for (TextView tv : bandValueTexts) {
                if (tv != null) {
                    tv.setTextColor((enabled && canEnable) ? themeColor : Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }
    
    /**
     * Updates the enable/disable button text and state.
     * ThemeHelper handles the ColorStateList (WHITE on press, theme color normally).
     */
    private void updateEnableButtonState(boolean canEnable, boolean enabled) {
        if (enableButton == null) return;
        enableButton.setEnabled(canEnable);
        if (canEnable) {
            enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        } else {
            enableButton.setText("ENABLE");
        }
        themeHelper.updateButton(enableButton, canEnable);
    }
    
    // ========================================================================
    // Band Control Methods
    // ========================================================================
    
    /**
     * Shows the preset selection dialog.
     * Debounces clicks to prevent multiple dialog instances.
     */
    private void showPresetDialog() {
        if (isClosing.get()) return;
        if (!isEqualizerOperational()) {
            ToastManager.showToast(this, "Enable equalizer first", ToastManager.LENGTH_SHORT);
            return;
        }
        if (equalizerManager == null) return;
        
        String[] presetNames = equalizerManager.getPresetNames();
        int currentPreset = equalizerManager.getCurrentPreset();
        
        PresetDialog dialog = new PresetDialog(this, presetNames, currentPreset, 
            new PresetDialog.OnPresetSelectedListener() {
                @Override
                public void onPresetSelected(int presetIndex, String presetName) {
                    if (!isClosing.get() && isEqualizerOperational() && equalizerManager != null) {
                        equalizerManager.applyPreset(presetIndex);
                    }
                }
            });
        
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                isPresetDialogShowing = false;
            }
        });
        dialog.show();
    }
    
    /**
     * Creates dynamic band controls based on the number of bands reported by the device.
     * Each band gets a frequency label, value display, and SeekBar control.
     * Rounding to nearest 0.1 dB (10 units) is applied during progress changes.
     */
    private void createBandControls() {
        if (bandsContainer == null || isClosing.get() || equalizerManager == null) return;
        bandsContainer.removeAllViews();
        final short numberOfBands = equalizerManager.getNumberOfBands();
        if (numberOfBands == 0) return;
        
        bandSeekBars = new SeekBar[numberOfBands];
        bandValueTexts = new TextView[numberOfBands];
        final int minLevel = equalizerManager.getMinBandLevel();
        final int maxLevel = equalizerManager.getMaxBandLevel();
        final int seekBarWidth = maxLevel - minLevel;
        final int themeColor = themeHelper.getThemeColorInt();
        
        for (int i = 0; i < numberOfBands; i++) {
            createSingleBandControl(i, minLevel, maxLevel, seekBarWidth, themeColor);
        }
    }
    
    /**
     * Creates a single band control row with frequency label, value display, and SeekBar.
     * Adds rounding to nearest 0.1 dB (10 units).
     * 
     * @param bandIndex The index of the band to create
     * @param minLevel Minimum allowed level for this band
     * @param maxLevel Maximum allowed level for this band
     * @param seekBarWidth Width range for the SeekBar
     * @param themeColor Current theme color for value text
     */
    private void createSingleBandControl(final int bandIndex, final int minLevel, 
                                          final int maxLevel, final int seekBarWidth, 
                                          final int themeColor) {
        int frequency = equalizerManager.getCenterFrequency(bandIndex);
        String frequencyText = equalizerManager.getFrequencyLabel(frequency);
        final int currentLevel = equalizerManager.getBandLevel(bandIndex);
        
        LinearLayout bandContainer = new LinearLayout(this);
        bandContainer.setOrientation(LinearLayout.VERTICAL);
        bandContainer.setPadding(0, 4, 0, 4);
        bandContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        TextView frequencyLabel = new TextView(this);
        frequencyLabel.setText(frequencyText);
        frequencyLabel.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        frequencyLabel.setTextSize(12);
        frequencyLabel.setPadding(0, 8, 0, 0);
        frequencyLabel.setLayoutParams(new LinearLayout.LayoutParams(0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        
        final TextView levelText = new TextView(this);
        levelText.setText(formatLevel(currentLevel));
        levelText.setTextColor(themeColor);
        levelText.setTextSize(12);
        levelText.setPadding(0, 8, 0, 0);
        
        topRow.addView(frequencyLabel);
        topRow.addView(levelText);
        
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(seekBarWidth);
        
        int initialProgress = currentLevel - minLevel;
        int roundedInitial = Math.round(initialProgress / (float) EQ_BAND_UNITS_PER_STEP) * EQ_BAND_UNITS_PER_STEP;
        roundedInitial = Math.max(0, Math.min(seekBarWidth, roundedInitial));
        seekBar.setProgress(roundedInitial);
        
        seekBar.setThumb(null);
        seekBar.setEnabled(equalizerManager.isEnabled() && hasAudioSession());
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_progress, null));
        } else {
            seekBar.setProgressDrawable(ContextCompat.getDrawable(this, R.drawable.seekbar_progress));
        }
        themeHelper.updateSeekBar(seekBar, seekBar.isEnabled());
        
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = 8;
        seekParams.bottomMargin = 8;
        seekBar.setLayoutParams(seekParams);
        
        bandContainer.addView(topRow);
        bandContainer.addView(seekBar);
        bandsContainer.addView(bandContainer);
        
        bandSeekBars[bandIndex] = seekBar;
        bandValueTexts[bandIndex] = levelText;
        
        final int min = minLevel;
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isClosing.get() && fromUser && isEqualizerOperational() && equalizerManager != null) {
                    if (isEqRounding) return;
                    
                    int rounded = Math.round(progress / (float) EQ_BAND_UNITS_PER_STEP) * EQ_BAND_UNITS_PER_STEP;
                    rounded = Math.max(0, Math.min(seekBarWidth, rounded));
                    
                    if (rounded != progress) {
                        isEqRounding = true;
                        seekBar.setProgress(rounded);
                        int level = min + rounded;
                        equalizerManager.setBandLevel(bandIndex, level);
                        levelText.setText(formatLevel(level));
                        isEqRounding = false;
                    } else {
                        int level = min + progress;
                        equalizerManager.setBandLevel(bandIndex, level);
                        levelText.setText(formatLevel(level));
                    }
                }
            }
            
            @Override 
            public void onStartTrackingTouch(SeekBar seekBar) {
                isEqRounding = false;
            }
            
            @Override 
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Rounding already handled during progress
            }
        });
    }
    
    /**
     * Updates all band controls to reflect current equalizer levels.
     * Rounds each level to nearest 0.1 dB for consistent display.
     */
    private void updateBandControlsFromLevels() {
        if (isClosing.get() || bandSeekBars == null || equalizerManager == null || !equalizerManager.isAttached()) return;
        final int minLevel = equalizerManager.getMinBandLevel();
        final int themeColor = themeHelper.getThemeColorInt();
        for (int i = 0; i < bandSeekBars.length && i < equalizerManager.getNumberOfBands(); i++) {
            final int level = equalizerManager.getBandLevel(i);
            if (bandSeekBars[i] != null) {
                int progress = level - minLevel;
                int rounded = Math.round(progress / (float) EQ_BAND_UNITS_PER_STEP) * EQ_BAND_UNITS_PER_STEP;
                rounded = Math.max(0, Math.min(bandSeekBars[i].getMax(), rounded));
                bandSeekBars[i].setProgress(rounded);
            }
            if (bandValueTexts[i] != null) {
                bandValueTexts[i].setText(formatLevel(level));
                if (equalizerManager.isEnabled() && hasAudioSession()) {
                    bandValueTexts[i].setTextColor(themeColor);
                }
            }
        }
    }
    
    /**
     * Formats a band level value for display.
     * Rounds to nearest 0.1 dB for consistent display.
     * 
     * @param level The level in millibels (100 = 1 dB)
     * @return Formatted string like "+5.0 dB", "-3.0 dB", or "0.0 dB"
     */
    private String formatLevel(int level) {
        int rounded = Math.round(level / (float) EQ_BAND_UNITS_PER_STEP) * EQ_BAND_UNITS_PER_STEP;
        
        float decibels = rounded / 100.0f;
        if (decibels > 0) {
            return String.format("+%.1f dB", decibels);
        } else if (decibels < 0) {
            return String.format("%.1f dB", decibels);
        } else {
            return "0.0 dB";
        }
    }
    
    // ========================================================================
    // Effect Value Update Methods
    // ========================================================================
    
    /**
     * Updates the bass boost value display as a percentage.
     */
    private void updateBassBoostValue(int value) {
        if (!isClosing.get() && bassBoostValueText != null) {
            bassBoostValueText.setText(((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }
    
    /**
     * Updates the surround effect value display as a percentage.
     */
    private void updateSurroundValue(int value) {
        if (!isClosing.get() && surroundValueText != null) {
            surroundValueText.setText(((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }
    
    /**
     * Updates the pitch value display in semitones.
     * Ranges from -6 to +6 semitones from default.
     * Default value shows as "0.0 st".
     */
    private void updatePitchValue(int value) {
        if (!isClosing.get() && pitchValueText != null) {
            float semitones = (value - PITCH_DEFAULT) / (1000.0f / 6.0f);
            if (Math.abs(semitones) < 0.05f) {
                pitchValueText.setText("0.0 st");
            } else if (semitones > 0) {
                pitchValueText.setText(String.format("+%.1f st", semitones));
            } else {
                pitchValueText.setText(String.format("%.1f st", semitones));
            }
        }
    }
    
    /**
     * Updates the speed value display as a multiplier.
     * Ranges from 0.5x to 1.5x speed.
     * Default value shows as "1.00x".
     */
    private void updateSpeedValue(int value) {
        if (!isClosing.get() && speedValueText != null) {
            float speed = 0.5f + (value / 2000.0f);
            speedValueText.setText(String.format("%.2fx", speed));
        }
    }
    
    /**
     * Updates all effect value displays (bass boost, surround, pitch, speed).
     */
    private void updateAllEffectValues() {
        if (isClosing.get() || equalizerManager == null) return;
        updateBassBoostValue(equalizerManager.getBassBoost());
        updateSurroundValue(equalizerManager.getSurround());
        updatePitchValue(equalizerManager.getPitch());
        updateSpeedValue(equalizerManager.getSpeed());
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Updates UI based on current equalizer state.
     * Shows transition message by default.
     */
    private void updateUI() {
        updateUI(true);
    }
    
    /**
     * Updates UI based on current equalizer state.
     * 
     * @param showTransitionMessage Whether to show "Equalizer: Enabled" message
     */
    private void updateUI(boolean showTransitionMessage) {
        if (isClosing.get() || equalizerManager == null) return;
        boolean enabled = equalizerManager.isEnabled();
        if (enableButton != null) enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        updateUIState(enabled);
        updateAllEffectValues();
        applyThemeToUI();
        if (statusText != null && isEqualizerReady && hasAudioSession()) {
            if (enabled) {
                if (revertToWavesRunnable != null) mainHandler.removeCallbacks(revertToWavesRunnable);
                if (showTransitionMessage) {
                    showTemporaryMessage("Equalizer: Enabled", true);
                } else {
                    statusText.setText("ENJOY THE WAVES");
                    statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else {
                showPersistentDisabledMessage();
            }
        }
    }
    
    /**
     * Notifies MusicService of playback parameter changes (pitch/speed).
     * Broadcasts an intent to trigger parameter updates in the service.
     */
    private void notifyPlaybackParamsChanged() {
        if (isClosing.get()) return;
        Intent intent = new Intent(ACTION_UPDATE_PLAYBACK_PARAMS);
        sendBroadcast(intent);
        Log.d(TAG, "Notified MusicService of playback param changes");
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up all click and change listeners for UI components.
     */
    private void setupListeners() {
        setupPresetButtonListener();
        setupBassBoostListener();
        setupSurroundListener();
        setupPitchListener();
        setupSpeedListener();
        setupResetButtonListener();
        setupEnableButtonListener();
        setupCancelButtonListener();
    }
    
    /**
     * Sets up preset button click listener with debouncing.
     */
    private void setupPresetButtonListener() {
        if (presetButton == null) return;
        presetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isClosing.get() || isPresetDialogShowing) return;
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastPresetClickTime < PRESET_DEBOUNCE_DELAY_MS) return;
                lastPresetClickTime = currentTime;
                isPresetDialogShowing = true;
                showPresetDialog();
            }
        });
    }
    
    /**
     * Sets up bass boost SeekBar change listener with rounding to nearest 1%.
     */
    private void setupBassBoostListener() {
        if (bassBoostSeekBar == null) return;
        
        bassBoostSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isClosing.get() && fromUser && isEqualizerOperational() && equalizerManager != null) {
                    if (isBassRounding) return;
                    
                    int rounded = Math.round(progress / (float) BOOST_UNITS_PER_PERCENT) * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0, Math.min(SEEKBAR_MAX_BOOST, rounded));
                    
                    if (rounded != progress) {
                        isBassRounding = true;
                        bassBoostSeekBar.setProgress(rounded);
                        equalizerManager.setBassBoost(rounded);
                        updateBassBoostValue(rounded);
                        isBassRounding = false;
                    } else {
                        equalizerManager.setBassBoost(progress);
                        updateBassBoostValue(progress);
                    }
                }
            }
            
            @Override 
            public void onStartTrackingTouch(SeekBar seekBar) {
                isBassRounding = false;
            }
            
            @Override 
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Rounding already handled during progress
            }
        });
    }
    
    /**
     * Sets up surround effect SeekBar change listener with rounding to nearest 1%.
     */
    private void setupSurroundListener() {
        if (surroundSeekBar == null) return;
        
        surroundSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isClosing.get() && fromUser && isEqualizerOperational() && equalizerManager != null) {
                    if (isSurroundRounding) return;
                    
                    int rounded = Math.round(progress / (float) BOOST_UNITS_PER_PERCENT) * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0, Math.min(SEEKBAR_MAX_BOOST, rounded));
                    
                    if (rounded != progress) {
                        isSurroundRounding = true;
                        surroundSeekBar.setProgress(rounded);
                        equalizerManager.setSurround(rounded);
                        updateSurroundValue(rounded);
                        isSurroundRounding = false;
                    } else {
                        equalizerManager.setSurround(progress);
                        updateSurroundValue(progress);
                    }
                }
            }
            
            @Override 
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSurroundRounding = false;
            }
            
            @Override 
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Rounding already handled during progress
            }
        });
    }
    
    /**
     * Sets up pitch SeekBar change listener with rounding to nearest 0.1 st.
     * Notifies MusicService of changes when playing to apply real-time effects.
     */
    private void setupPitchListener() {
        if (pitchSeekBar == null) return;
        
        pitchSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isClosing.get() && fromUser && equalizerManager != null) {
                    if (isPitchRounding) return;
                    
                    int rounded = Math.round(progress / (float) PITCH_UNITS_PER_STEP) * PITCH_UNITS_PER_STEP;
                    rounded = Math.max(0, Math.min(SEEKBAR_MAX, rounded));
                    
                    if (rounded != progress) {
                        isPitchRounding = true;
                        pitchSeekBar.setProgress(rounded);
                        equalizerManager.setPitch(rounded);
                        updatePitchValue(rounded);
                        isPitchRounding = false;
                        
                        if (isBindingComplete && musicService != null && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setPitch(progress);
                        updatePitchValue(progress);
                        
                        if (isBindingComplete && musicService != null && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }
            
            @Override 
            public void onStartTrackingTouch(SeekBar seekBar) {
                isPitchRounding = false;
            }
            
            @Override 
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Rounding already handled during progress
            }
        });
    }
    
    /**
     * Sets up speed SeekBar change listener with rounding to nearest 0.01x.
     * Notifies MusicService of changes when playing to apply real-time effects.
     */
    private void setupSpeedListener() {
        if (speedSeekBar == null) return;
        
        speedSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isClosing.get() && fromUser && equalizerManager != null) {
                    if (isSpeedRounding) return;
                    
                    int rounded = Math.round(progress / (float) SPEED_UNITS_PER_STEP) * SPEED_UNITS_PER_STEP;
                    rounded = Math.max(0, Math.min(SEEKBAR_MAX, rounded));
                    
                    if (rounded != progress) {
                        isSpeedRounding = true;
                        speedSeekBar.setProgress(rounded);
                        equalizerManager.setSpeed(rounded);
                        updateSpeedValue(rounded);
                        isSpeedRounding = false;
                        
                        if (isBindingComplete && musicService != null && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setSpeed(progress);
                        updateSpeedValue(progress);
                        
                        if (isBindingComplete && musicService != null && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }
            
            @Override 
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSpeedRounding = false;
            }
            
            @Override 
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Rounding already handled during progress
            }
        });
    }
    
    /**
     * Sets up reset button click listener.
     * Resets ALL effects to default values:
     * - EQ bands: 0.0 dB
     * - Bass Boost: 0%
     * - Surround: 0%
     * - Pitch: 0.0 st
     * - Speed: 1.00x
     */
    private void setupResetButtonListener() {
        if (resetButton == null) return;
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isClosing.get() || equalizerManager == null) return;
                
                boolean eqOperational = isEqualizerOperational();
                boolean anythingChanged = false;
                
                // Reset EQ bands to 0.0 dB
                if (eqOperational) {
                    short numberOfBands = equalizerManager.getNumberOfBands();
                    for (short i = 0; i < numberOfBands; i++) {
                        if (equalizerManager.getBandLevel(i) != 0) {
                            equalizerManager.setBandLevel(i, 0);
                            anythingChanged = true;
                        }
                    }
                    if (anythingChanged) {
                        equalizerManager.clearCustomBandLevels();
                    }
                }
                
                // Reset Bass Boost to 0%
                if (eqOperational && equalizerManager.isBassBoostSupported()) {
                    int currentBass = equalizerManager.getBassBoost();
                    if (currentBass != 0) {
                        equalizerManager.setBassBoost(0);
                        if (bassBoostSeekBar != null) bassBoostSeekBar.setProgress(0);
                        updateBassBoostValue(0);
                        anythingChanged = true;
                    }
                }
                
                // Reset Surround to 0%
                if (eqOperational && equalizerManager.isSurroundSupported()) {
                    int currentSurround = equalizerManager.getSurround();
                    if (currentSurround != 0) {
                        equalizerManager.setSurround(0);
                        if (surroundSeekBar != null) surroundSeekBar.setProgress(0);
                        updateSurroundValue(0);
                        anythingChanged = true;
                    }
                }
                
                // Reset Pitch to 0.0 st
                int currentPitch = equalizerManager.getPitch();
                if (currentPitch != PITCH_DEFAULT) {
                    equalizerManager.setPitch(PITCH_DEFAULT);
                    if (pitchSeekBar != null) pitchSeekBar.setProgress(PITCH_DEFAULT);
                    updatePitchValue(PITCH_DEFAULT);
                    anythingChanged = true;
                }
                
                // Reset Speed to 1.00x
                int currentSpeed = equalizerManager.getSpeed();
                if (currentSpeed != SPEED_DEFAULT) {
                    equalizerManager.setSpeed(SPEED_DEFAULT);
                    if (speedSeekBar != null) speedSeekBar.setProgress(SPEED_DEFAULT);
                    updateSpeedValue(SPEED_DEFAULT);
                    anythingChanged = true;
                }
                
                // If any EQ band was changed, apply preset 0 (Custom)
                if (eqOperational && anythingChanged) {
                    equalizerManager.applyPreset(0);
                }
                
                // Update all band controls to reflect reset
                updateBandControlsFromLevels();
                
                // Show feedback
                if (anythingChanged) {
                    if (isBindingComplete && musicService != null && musicService.isPlaying()) {
                        notifyPlaybackParamsChanged();
                    }
                    ToastManager.showToast(EqualizerActivity.this, "Reset to factory defaults", ToastManager.LENGTH_SHORT);
                } else {
                    ToastManager.showToast(EqualizerActivity.this, "Already at default settings", ToastManager.LENGTH_SHORT);
                }
            }
        });
    }
    
    /**
     * Sets up enable/disable button click listener.
     * Toggles equalizer enabled state and updates UI accordingly.
     */
    private void setupEnableButtonListener() {
        if (enableButton == null) return;
        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isClosing.get() && equalizerManager != null && hasAudioSession()) {
                    boolean newState = !equalizerManager.isEnabled();
                    equalizerManager.setEnabled(newState);
                    updateUI();
                }
            }
        });
    }
    
    /**
     * Sets up cancel button click listener.
     * Finishes the activity with slide-out animation.
     */
    private void setupCancelButtonListener() {
        if (cancelButton == null) return;
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isClosing.get()) {
                    getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    finish();
                }
            }
        });
    }
}