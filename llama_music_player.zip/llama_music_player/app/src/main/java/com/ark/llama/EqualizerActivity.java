package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Provides the UI for adjusting audio effects: a multi-band
 * equalizer, bass boost, surround effect, pitch, and playback speed.
 *
 * <p>The activity reads the device's audio effect capabilities from
 * {@link EqualizerManager} and builds the corresponding controls.
 * One SeekBar is created for each equalizer band the device reports.
 * SeekBars for bass boost and surround snap to the nearest 1%, for
 * pitch to the nearest 0.1 semitone, for speed to the nearest 0.01x,
 * and for each equalizer band to the nearest 0.1 dB. The Reset button
 * restores every effect to its factory default.</p>
 *
 * <p>All audio effect operations are delegated to
 * {@link EqualizerManager}.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>In the full layout, the band controls take the weight they were
 * given in XML and the effect controls sit below them at their
 * natural height. In split mode, the band controls are hidden
 * because their vertical footprint cannot be usefully compressed,
 * and the effect controls are promoted into the weight the bands
 * vacated, inside a scroll container that lets the user reach
 * every control even when the window is shorter than their
 * combined height.</p>
 *
 * <p>The top bar, the status line, the preset button, and the
 * reset button are untouched in both layouts. Every touch target
 * the user's finger depends on keeps its size.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. Work originating from
 * broadcast receivers and service callbacks is routed through
 * {@link #safeRunOnUiThread(Runnable)}, which uses an
 * {@link AtomicBoolean} to refuse overlapping updates and drops
 * any request that arrives after the activity has begun
 * destroying.</p>
 *
 * @see EqualizerManager
 * @see PresetDialog
 * @see ThemeHelper
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.0.0
 */
public class EqualizerActivity extends Activity {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for debugging purposes. */
    private static final String TAG = "EqualizerActivity";

    /** Broadcast action for audio session changes from MusicService. */
    private static final String ACTION_AUDIO_SESSION_CHANGED =
        "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Broadcast action for updating playback parameters. */
    private static final String ACTION_UPDATE_PLAYBACK_PARAMS =
        "UPDATE_PLAYBACK_PARAMS";

    /** Broadcast action for theme color change notifications. */
    private static final String ACTION_THEME_COLOR_CHANGED =
        "THEME_COLOR_CHANGED";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for bass boost level. */
    private static final String KEY_BASS_BOOST = "bass_boost_level";

    /** Key for surround effect level. */
    private static final String KEY_SURROUND = "surround_level";

    /** Key for pitch level. */
    private static final String KEY_PITCH = "pitch_level";

    /** Key for speed level. */
    private static final String KEY_SPEED = "speed_level";

    /** Prefix for equalizer band level keys. */
    private static final String KEY_BAND_PREFIX = "eq_band_";

    /** Duration for button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Scale factor for button release animation. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum value for bass boost and surround SeekBars. */
    private static final int SEEKBAR_MAX_BOOST = 1000;

    /** Maximum value for pitch and speed SeekBars. */
    private static final int SEEKBAR_MAX = 2000;

    /** Default value for pitch SeekBar (0 semitones). */
    private static final int PITCH_DEFAULT = 1000;

    /** Default value for speed SeekBar (1.00x speed). */
    private static final int SPEED_DEFAULT = 1000;

    /** Units per 1% for bass boost and surround. */
    private static final int BOOST_UNITS_PER_PERCENT = 10;

    /** Units per 0.1 dB for equalizer bands. */
    private static final int EQ_BAND_UNITS_PER_STEP = 10;

    /** Units per 0.1 semitone for pitch. */
    private static final int PITCH_UNITS_PER_STEP = 17;

    /** Units per 0.01x for speed. */
    private static final int SPEED_UNITS_PER_STEP = 20;

    /** Light gray text color for secondary UI elements. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Disabled text color for inactive controls. */
    private static final String COLOR_DISABLED = "#5A5A5A";

    /** Debounce delay for preset button clicks in milliseconds. */
    private static final long PRESET_DEBOUNCE_DELAY_MS = 500;

    /** Duration for temporary status messages in milliseconds. */
    private static final int STATUS_MESSAGE_DURATION_MS = 1500;

    /** Delay for UI refresh after reattaching to the audio session. */
    private static final long UI_REFRESH_DELAY_MS = 200;

    /** Window height below which the split layout is applied. */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    // ============================================================================
    // UI Components
    // ============================================================================

    private LinearLayout bandsContainer;
    private LinearLayout bandsWrapper;
    private View effectsScroll;
    private Button presetButton;
    private SeekBar bassBoostSeekBar;
    private SeekBar surroundSeekBar;
    private SeekBar pitchSeekBar;
    private SeekBar speedSeekBar;
    private TextView bassBoostValueText;
    private TextView surroundValueText;
    private TextView pitchValueText;
    private TextView speedValueText;
    private Button resetButton;
    private Button cancelButton;
    private Button enableButton;
    private TextView statusText;
    private SeekBar[] bandSeekBars;
    private TextView[] bandValueTexts;

    // ============================================================================
    // State Management
    // ============================================================================

    private final Handler mainHandler =
        new Handler(Looper.getMainLooper());
    private boolean isEqualizerReady = false;
    private boolean areBandsCreated = false;
    private Runnable revertToWavesRunnable;
    private long lastPresetClickTime = 0;
    private boolean isPresetDialogShowing = false;
    private final AtomicBoolean isClosing = new AtomicBoolean(false);
    private final AtomicBoolean isUpdatingUI =
        new AtomicBoolean(false);
    private boolean isBassRounding = false;
    private boolean isSurroundRounding = false;
    private boolean isEqRounding = false;
    private boolean isPitchRounding = false;
    private boolean isSpeedRounding = false;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    private EqualizerManager equalizerManager;
    private ThemeManager themeManager;
    private ThemeHelper themeHelper;
    private BroadcastReceiver themeReceiver;
    private MusicService musicService;
    private ServiceConnection serviceConnection;
    private boolean isServiceBound = false;
    private boolean isBindingComplete = false;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    private final BroadcastReceiver audioSessionReceiver =
        new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) {
                return;
            }
            if (ACTION_AUDIO_SESSION_CHANGED.equals(
                    intent.getAction())) {
                final int newSessionId =
                    intent.getIntExtra("audio_session_id", -1);
                Log.d(TAG, "Audio session changed: " + newSessionId);
                if (newSessionId > 0) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                equalizerManager.attachToAudioSession(
                                    newSessionId);
                            }
                        }
                    });
                }
            }
        }
    };

    private final BroadcastReceiver updatePlaybackParamsReceiver =
        new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) {
                return;
            }
            if (ACTION_UPDATE_PLAYBACK_PARAMS.equals(
                    intent.getAction())) {
                safeRunOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateAllEffectValues();
                    }
                });
            }
        }
    };

    // ============================================================================
    // Equalizer Listener
    // ============================================================================

    private final EqualizerManager.EqualizerListener equalizerListener =
        new EqualizerManager.EqualizerListener() {

        @Override
        public void onBandLevelsChanged(int[] levels) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (bandSeekBars != null) {
                        updateBandControlsFromLevels();
                    }
                }
            });
        }

        @Override
        public void onPresetChanged(final int preset,
                                    final String presetName) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (presetButton != null) {
                        presetButton.setText(presetName);
                    }
                    if (statusText != null && equalizerManager != null
                            && equalizerManager.isEnabled()
                            && hasAudioSession()) {
                        showTemporaryMessage(
                            "Equalizer: " + presetName);
                        statusText.setTextColor(
                            Color.parseColor(TEXT_COLOR_LIGHT));
                    }
                }
            });
        }

        @Override
        public void onEqualizerReady(final boolean ready) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    isEqualizerReady = ready;
                    boolean hasAudio = hasAudioSession();

                    if (resetButton != null) {
                        resetButton.setEnabled(hasAudio);
                        themeHelper.updateButton(resetButton, hasAudio);
                    }

                    if (ready) {
                        handleEqualizerReady(hasAudio);
                    } else {
                        handleEqualizerNotReady();
                    }
                }
            });
        }
    };

    // ============================================================================
    // Thread Safety Methods
    // ============================================================================

    private void safeRunOnUiThread(final Runnable action) {
        if (isFinishing() || isDestroyed() || isClosing.get()) {
            return;
        }
        if (!isUpdatingUI.compareAndSet(false, true)) {
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()
                            && !isClosing.get()) {
                        action.run();
                    }
                } finally {
                    isUpdatingUI.set(false);
                }
            }
        });
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_equalizer);

        initializeManagers();
        initializeViews();

        setupListeners();
        registerReceivers();
        bindMusicService();

        applyEqualizerSplitLayout(
            getResources().getConfiguration().screenHeightDp);

        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
        } else {
            handleNoAudioSession();
        }

        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
        applyThemeToUI();
        themeAllHeaders();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isClosing.get()) {
            return;
        }

        registerThemeReceiverIfNeeded();
        updateUI(false);
        updateAllEffectValues();

        boolean hasAudio = hasAudioSession();
        updateResetButtonState(hasAudio);

        if (!hasAudio) {
            handleNoAudioSession();
        }

        updateBandControlsState();

        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isClosing.get()
                            && equalizerManager.isAttached()) {
                        refreshAllUIControls();
                    }
                }
            }, UI_REFRESH_DELAY_MS);
        } else {
            handleNoAudioSession();
        }

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (themeReceiver != null) {
            try {
                unregisterReceiver(themeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            themeReceiver = null;
        }
    }

    @Override
    protected void onDestroy() {
        isClosing.set(true);
        super.onDestroy();

        unbindServiceSafely();
        unregisterReceiverSafely(audioSessionReceiver);
        unregisterReceiverSafely(updatePlaybackParamsReceiver);
        unregisterReceiverSafely(themeReceiver);

        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }
        if (equalizerManager != null) {
            equalizerManager.setListener(null);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT
                && !isClosing.get()) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Switches between the full layout and the split-mode layout.
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applyEqualizerSplitLayout(config.screenHeightDp);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(
            R.anim.slide_in_down, R.anim.slide_out_down);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(
            R.anim.slide_in_down, R.anim.slide_out_down);
    }

    // ============================================================================
    // Split Layout
    // ============================================================================

    /**
     * Switches between the band-control layout and the split-mode
     * layout.
     *
     * <p>In the full layout, the band controls take the weight they
     * were given in XML and the effect controls sit below them at
     * their natural height. In split mode, the band controls are
     * hidden because their vertical footprint cannot be usefully
     * compressed, and the effect controls are promoted into the
     * weight the bands vacated, inside a scroll container that lets
     * the user reach every control even when the window is shorter
     * than their combined height.</p>
     *
     * <p>The top bar, the status line, the preset button, and the
     * reset button are untouched in both layouts. Every touch
     * target the user's finger depends on keeps its size.</p>
     *
     * @param screenHeightDp Current window height in dp
     */
    private void applyEqualizerSplitLayout(int screenHeightDp) {
        final boolean isSplit = screenHeightDp
            < SPLIT_SCREEN_MIN_HEIGHT_DP;

        if (bandsWrapper != null) {
            bandsWrapper.setVisibility(
                isSplit ? View.GONE : View.VISIBLE);
        }

        if (effectsScroll != null) {
            final LinearLayout.LayoutParams params =
                (LinearLayout.LayoutParams)
                    effectsScroll.getLayoutParams();
            if (isSplit) {
                params.height = 0;
                params.weight = 1;
            } else {
                params.height =
                    LinearLayout.LayoutParams.WRAP_CONTENT;
                params.weight = 0;
            }
            effectsScroll.setLayoutParams(params);
        }
    }

    // ============================================================================
    // Initialization Methods
    // ============================================================================

    private void initializeManagers() {
        equalizerManager = EqualizerManager.getInstance(this);
        equalizerManager.setListener(equalizerListener);
        themeManager = ThemeManager.getInstance(this);
        themeHelper = ThemeHelper.getInstance(this);
    }

    private void registerReceivers() {
        IntentFilter audioSessionFilter = new IntentFilter();
        audioSessionFilter.addAction(ACTION_AUDIO_SESSION_CHANGED);
        ContextCompat.registerReceiver(
            this, audioSessionReceiver, audioSessionFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED);

        IntentFilter paramsFilter =
            new IntentFilter(ACTION_UPDATE_PLAYBACK_PARAMS);
        ContextCompat.registerReceiver(
            this, updatePlaybackParamsReceiver, paramsFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    private void bindMusicService() {
        Intent bindIntent = new Intent(this, MusicService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name,
                                           IBinder service) {
                MusicService.LocalBinder binder =
                    (MusicService.LocalBinder) service;
                musicService = binder.getService();
                isServiceBound = true;
                isBindingComplete = true;
                updateUI(false);
                updateAllEffectValues();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                musicService = null;
                isServiceBound = false;
            }
        };
        bindService(bindIntent, serviceConnection, BIND_AUTO_CREATE);
    }

    private void registerThemeReceiverIfNeeded() {
        if (themeReceiver != null) {
            return;
        }

        themeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (isClosing.get()) {
                    return;
                }
                if (ACTION_THEME_COLOR_CHANGED.equals(
                        intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                applyThemeToUI();
                                themeAllHeaders();
                                ToastManager.refreshThemeColor();
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        ContextCompat.registerReceiver(
            this, themeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    // ============================================================================
    // State Query Helpers
    // ============================================================================

    private boolean hasAudioSession() {
        return MusicService.getAudioSessionId() > 0;
    }

    private boolean isEqualizerOperational() {
        return equalizerManager != null
            && equalizerManager.isEnabled()
            && hasAudioSession()
            && equalizerManager.isAttached()
            && equalizerManager.getNumberOfBands() > 0;
    }

    private void refreshAllUIControls() {
        if (equalizerManager == null) {
            return;
        }

        boolean isEnabled = equalizerManager.isEnabled();
        boolean hasAudio = hasAudioSession();
        int themeColor = themeHelper.getThemeColorInt();

        if (bassBoostSeekBar != null) {
            if (equalizerManager.isBassBoostSupported()) {
                int bassLevel = equalizerManager.getBassBoost();
                bassBoostSeekBar.setProgress(bassLevel);
                updateBassBoostValue(bassLevel);
                bassBoostSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                bassBoostSeekBar.setEnabled(false);
                if (bassBoostValueText != null) {
                    bassBoostValueText.setText("OFF");
                }
            }
        }
        if (bassBoostValueText != null) {
            boolean active = isEnabled && hasAudio
                && equalizerManager.isBassBoostSupported();
            bassBoostValueText.setTextColor(active
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (surroundSeekBar != null) {
            if (equalizerManager.isSurroundSupported()) {
                int surroundLevel = equalizerManager.getSurround();
                surroundSeekBar.setProgress(surroundLevel);
                updateSurroundValue(surroundLevel);
                surroundSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                surroundSeekBar.setEnabled(false);
                if (surroundValueText != null) {
                    surroundValueText.setText("OFF");
                }
            }
        }
        if (surroundValueText != null) {
            boolean active = isEnabled && hasAudio
                && equalizerManager.isSurroundSupported();
            surroundValueText.setTextColor(active
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (pitchSeekBar != null) {
            int pitchLevel = equalizerManager.getPitch();
            pitchSeekBar.setProgress(pitchLevel);
            updatePitchValue(pitchLevel);
            pitchSeekBar.setEnabled(hasAudio);
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(hasAudio
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (speedSeekBar != null) {
            int speedLevel = equalizerManager.getSpeed();
            speedSeekBar.setProgress(speedLevel);
            updateSpeedValue(speedLevel);
            speedSeekBar.setEnabled(hasAudio);
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(hasAudio
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        updateBandControlsFromLevels();

        if (presetButton != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            presetButton.setText(
                equalizerManager.getPresetName(currentPreset));
            presetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(
                presetButton, isEnabled && hasAudio);
        }

        if (enableButton != null) {
            enableButton.setEnabled(hasAudio);
            enableButton.setText(isEnabled ? "DISABLE" : "ENABLE");
            themeHelper.updateButton(enableButton, hasAudio);
        }

        if (resetButton != null) {
            resetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(
                resetButton, isEnabled && hasAudio);
        }

        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("ENJOY THE WAVES");
            } else {
                statusText.setText("Equalizer: Disabled");
            }
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }
    }

    private void handleEqualizerReady(boolean hasAudio) {
        if (equalizerManager != null
                && equalizerManager.getNumberOfBands() > 0
                && !areBandsCreated) {
            createBandControls();
            areBandsCreated = true;
        }

        refreshAllUIControls();

        if (hasAudio) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(
                    equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) {
                presetButton.setText("Disabled");
            }
            if (enableButton != null) {
                enableButton.setEnabled(false);
                themeHelper.updateButton(enableButton, false);
                enableButton.setText("ENABLE");
            }
        }

        boolean isEnabled = equalizerManager != null
            && equalizerManager.isEnabled();
        updateUIState(isEnabled);

        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("Equalizer: Enabled");
                statusText.setTextColor(
                    themeHelper.getThemeColorInt());
            } else {
                statusText.setText("Equalizer: Disabled");
                statusText.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
            }
        }

        if (enableButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(
                enableButton, enableButton.isEnabled());
        }
        if (resetButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(
                resetButton, resetButton.isEnabled());
        }
    }

    private void handleEqualizerNotReady() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }

        updateUIState(false);

        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }

        if (presetButton != null) {
            presetButton.setText("Disabled");
        }

        refreshAllUIControls();
    }

    private void handleNoAudioSession() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }
        if (presetButton != null) {
            presetButton.setText("Disabled");
        }
        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }
        if (resetButton != null) {
            resetButton.setEnabled(false);
            themeHelper.updateButton(resetButton, false);
        }

        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (bassBoostSeekBar != null) {
            int savedBass = preferences.getInt(KEY_BASS_BOOST, 0);
            bassBoostSeekBar.setProgress(savedBass);
            updateBassBoostValue(savedBass);
            bassBoostSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(bassBoostSeekBar, false);
            }
        }
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (surroundSeekBar != null) {
            int savedSurround =
                preferences.getInt(KEY_SURROUND, 0);
            surroundSeekBar.setProgress(savedSurround);
            updateSurroundValue(savedSurround);
            surroundSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(surroundSeekBar, false);
            }
        }
        if (surroundValueText != null) {
            surroundValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (pitchSeekBar != null) {
            int savedPitch =
                preferences.getInt(KEY_PITCH, PITCH_DEFAULT);
            pitchSeekBar.setProgress(savedPitch);
            updatePitchValue(savedPitch);
            pitchSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(pitchSeekBar, false);
            }
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (speedSeekBar != null) {
            int savedSpeed =
                preferences.getInt(KEY_SPEED, SPEED_DEFAULT);
            speedSeekBar.setProgress(savedSpeed);
            updateSpeedValue(savedSpeed);
            speedSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(speedSeekBar, false);
            }
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (bandSeekBars != null) {
            int minLevel = equalizerManager != null
                ? equalizerManager.getMinBandLevel() : -1500;
            for (int index = 0; index < bandSeekBars.length; index++) {
                SeekBar bandSeekBar = bandSeekBars[index];
                if (bandSeekBar != null) {
                    int savedLevel = preferences.getInt(
                        KEY_BAND_PREFIX + index, 0);
                    int progress = savedLevel - minLevel;
                    bandSeekBar.setProgress(Math.max(0,
                        Math.min(bandSeekBar.getMax(), progress)));
                    bandSeekBar.setEnabled(false);
                    if (themeHelper != null) {
                        themeHelper.updateSeekBar(
                            bandSeekBar, false);
                    }
                }
            }
        }
        if (bandValueTexts != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null) {
                    bandValueText.setTextColor(
                        Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }

    private void updateBandControlsState() {
        if (bandSeekBars != null) {
            updateBandControlsFromLevels();
            boolean isEnabled = equalizerManager != null
                && equalizerManager.isEnabled();
            boolean hasAudio = hasAudioSession();
            for (SeekBar bandSeekBar : bandSeekBars) {
                if (bandSeekBar != null) {
                    bandSeekBar.setEnabled(isEnabled && hasAudio);
                }
            }
        }
    }

    private void unbindServiceSafely() {
        if (isServiceBound) {
            try {
                unbindService(serviceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
            isServiceBound = false;
        }
    }

    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Status Message Methods
    // ============================================================================

    private void showTemporaryMessage(String message) {
        if (statusText == null || isClosing.get()) {
            return;
        }
        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }

        statusText.setText(message);
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));

        revertToWavesRunnable = new Runnable() {
            @Override
            public void run() {
                if (isClosing.get() || statusText == null
                        || equalizerManager == null) {
                    return;
                }
                if (equalizerManager.isEnabled() && hasAudioSession()) {
                    statusText.setText("ENJOY THE WAVES");
                } else if (hasAudioSession()) {
                    statusText.setText("Equalizer: Disabled");
                }
                statusText.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
            }
        };
        mainHandler.postDelayed(
            revertToWavesRunnable, STATUS_MESSAGE_DURATION_MS);
    }

    private void showPersistentDisabledMessage() {
        if (statusText == null || isClosing.get()) {
            return;
        }
        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }
        statusText.setText("Equalizer: Disabled");
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    private void initializeViews() {
        bandsContainer =
            (LinearLayout) findViewById(R.id.bandsContainer);
        bandsWrapper = (LinearLayout) findViewById(R.id.bandsWrapper);
        effectsScroll = findViewById(R.id.effectsScroll);
        presetButton = (Button) findViewById(R.id.presetButton);
        bassBoostSeekBar = (SeekBar) findViewById(R.id.bassBoostSeekBar);
        surroundSeekBar = (SeekBar) findViewById(R.id.surroundSeekBar);
        pitchSeekBar = (SeekBar) findViewById(R.id.pitchSeekBar);
        speedSeekBar = (SeekBar) findViewById(R.id.speedSeekBar);
        bassBoostValueText =
            (TextView) findViewById(R.id.bassBoostValueText);
        surroundValueText =
            (TextView) findViewById(R.id.surroundValueText);
        pitchValueText = (TextView) findViewById(R.id.pitchValueText);
        speedValueText = (TextView) findViewById(R.id.speedValueText);
        resetButton = (Button) findViewById(R.id.resetButton);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        enableButton = (Button) findViewById(R.id.enableButton);
        statusText = (TextView) findViewById(R.id.statusText);

        animateButton(presetButton);
        animateButton(resetButton);
        animateButton(cancelButton);
        animateButton(enableButton);

        initializePresetButtonText();
        initializeResetButtonState();
        initializeEffectControls();

        updateUIState(false);
    }

    private void initializePresetButtonText() {
        if (hasAudioSession() && equalizerManager != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(
                    equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) {
                presetButton.setText("Disabled");
            }
        }
    }

    private void initializeResetButtonState() {
        if (resetButton != null) {
            boolean hasAudio = hasAudioSession();
            resetButton.setEnabled(hasAudio);
            themeHelper.updateButton(resetButton, hasAudio);
        }
    }

    private void initializeEffectControls() {
        if (equalizerManager == null) {
            return;
        }

        if (equalizerManager.isBassBoostSupported()) {
            bassBoostSeekBar.setMax(SEEKBAR_MAX_BOOST);
            bassBoostSeekBar.setProgress(
                equalizerManager.getBassBoost());
            updateBassBoostValue(equalizerManager.getBassBoost());
        } else {
            bassBoostSeekBar.setEnabled(false);
            if (bassBoostValueText != null) {
                bassBoostValueText.setText("OFF");
            }
        }

        if (equalizerManager.isSurroundSupported()) {
            surroundSeekBar.setMax(SEEKBAR_MAX_BOOST);
            surroundSeekBar.setProgress(
                equalizerManager.getSurround());
            updateSurroundValue(equalizerManager.getSurround());
        } else {
            surroundSeekBar.setEnabled(false);
            if (surroundValueText != null) {
                surroundValueText.setText("OFF");
            }
        }

        pitchSeekBar.setMax(SEEKBAR_MAX);
        pitchSeekBar.setProgress(equalizerManager.getPitch());
        updatePitchValue(equalizerManager.getPitch());

        speedSeekBar.setMax(SEEKBAR_MAX);
        speedSeekBar.setProgress(equalizerManager.getSpeed());
        updateSpeedValue(equalizerManager.getSpeed());
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    private void themeAllHeaders() {
        if (isClosing.get()) {
            return;
        }
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof android.view.ViewGroup) {
            themeHeadersRecursive(
                (android.view.ViewGroup) rootView);
        }
    }

    private void themeHeadersRecursive(
            android.view.ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof TextView
                    && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                if (text.equals("EQUALIZER")
                        || text.equals("BASS BOOST")
                        || text.equals("SURROUND")
                        || text.equals("PITCH")
                        || text.equals("SPEED")
                        || text.equals("ENJOY THE WAVES")) {
                    textView.setTextColor(
                        Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else if (child instanceof android.view.ViewGroup) {
                themeHeadersRecursive(
                    (android.view.ViewGroup) child);
            }
        }
    }

    private void applyThemeToUI() {
        if (isClosing.get() || themeHelper == null
                || themeManager == null) {
            return;
        }

        themeHelper.setThemeColor(themeManager.getCurrentColor());

        if (presetButton != null) {
            themeHelper.updateButton(
                presetButton, presetButton.isEnabled());
        }
        if (resetButton != null) {
            themeHelper.updateButton(
                resetButton, resetButton.isEnabled());
        }
        if (cancelButton != null) {
            themeHelper.updateButton(
                cancelButton, cancelButton.isEnabled());
        }
        if (enableButton != null) {
            themeHelper.updateButton(
                enableButton, enableButton.isEnabled());
        }

        if (bassBoostSeekBar != null) {
            themeHelper.updateSeekBar(
                bassBoostSeekBar, bassBoostSeekBar.isEnabled());
        }
        if (surroundSeekBar != null) {
            themeHelper.updateSeekBar(
                surroundSeekBar, surroundSeekBar.isEnabled());
        }
        if (pitchSeekBar != null) {
            themeHelper.updateSeekBar(
                pitchSeekBar, pitchSeekBar.isEnabled());
        }
        if (speedSeekBar != null) {
            themeHelper.updateSeekBar(
                speedSeekBar, speedSeekBar.isEnabled());
        }

        if (bandSeekBars != null) {
            for (SeekBar bandSeekBar : bandSeekBars) {
                if (bandSeekBar != null) {
                    themeHelper.updateSeekBar(
                        bandSeekBar, bandSeekBar.isEnabled());
                }
            }
        }

        updateValueTextWithSeekBar(
            bassBoostValueText, bassBoostSeekBar);
        updateValueTextWithSeekBar(
            surroundValueText, surroundSeekBar);
        updateValueTextWithSeekBar(pitchValueText, pitchSeekBar);
        updateValueTextWithSeekBar(speedValueText, speedSeekBar);

        if (statusText != null && equalizerManager != null) {
            if (equalizerManager.isEnabled() && hasAudioSession()) {
                statusText.setText("ENJOY THE WAVES");
            } else {
                statusText.setText("Equalizer: Disabled");
            }
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }

        if (bandValueTexts != null && equalizerManager != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null
                        && equalizerManager.isEnabled()
                        && hasAudioSession()) {
                    themeHelper.updateTextView(bandValueText, true);
                }
            }
        }
    }

    private void updateValueTextWithSeekBar(
            @Nullable TextView valueText,
            @Nullable SeekBar seekBar) {
        if (valueText != null && seekBar != null) {
            boolean enabled = seekBar.isEnabled();
            themeHelper.updateTextView(valueText, enabled);
            if (!enabled) {
                valueText.setTextColor(
                    Color.parseColor(COLOR_DISABLED));
            }
        }
    }

    // ============================================================================
    // Button Animation
    // ============================================================================

    private void animateButton(@Nullable final Button button) {
        if (button == null || isClosing.get()) {
            return;
        }
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // UI State Management
    // ============================================================================

    private void updateUIState(boolean enabled) {
        if (isClosing.get()) {
            return;
        }

        boolean hasAudio = hasAudioSession();
        boolean canEnable = isEqualizerReady && hasAudio;
        int themeColor = themeHelper.getThemeColorInt();

        updatePresetButtonState(enabled, canEnable, hasAudio);
        updateResetButtonState(canEnable);
        updateBassBoostControlState(enabled, canEnable, themeColor);
        updateSurroundControlState(enabled, canEnable, themeColor);
        updatePitchControlState(canEnable, themeColor);
        updateSpeedControlState(canEnable, themeColor);
        updateBandControlsState(enabled, canEnable, themeColor);
        updateEnableButtonState(canEnable, enabled);
    }

    private void updatePresetButtonState(boolean enabled,
                                         boolean canEnable,
                                         boolean hasAudio) {
        if (presetButton == null) {
            return;
        }
        boolean shouldBeEnabled = enabled && canEnable;
        presetButton.setEnabled(shouldBeEnabled);
        themeHelper.updateButton(presetButton, shouldBeEnabled);
        if (!hasAudio) {
            presetButton.setText("Disabled");
        } else if (equalizerManager != null) {
            presetButton.setText(equalizerManager.getPresetName(
                equalizerManager.getCurrentPreset()));
        }
    }

    private void updateResetButtonState(boolean canEnable) {
        if (resetButton == null) {
            return;
        }
        resetButton.setEnabled(canEnable);
        themeHelper.updateButton(resetButton, canEnable);
    }

    private void updateBassBoostControlState(boolean enabled,
                                             boolean canEnable,
                                             int themeColor) {
        if (bassBoostSeekBar == null || equalizerManager == null) {
            return;
        }
        boolean boosterEnabled = enabled && canEnable
            && equalizerManager.isBassBoostSupported();
        bassBoostSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(bassBoostSeekBar, boosterEnabled);
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(boosterEnabled
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    private void updateSurroundControlState(boolean enabled,
                                            boolean canEnable,
                                            int themeColor) {
        if (surroundSeekBar == null || equalizerManager == null) {
            return;
        }
        boolean boosterEnabled = enabled && canEnable
            && equalizerManager.isSurroundSupported();
        surroundSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(surroundSeekBar, boosterEnabled);
        if (surroundValueText != null) {
            surroundValueText.setTextColor(boosterEnabled
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    private void updatePitchControlState(boolean canEnable,
                                         int themeColor) {
        if (pitchSeekBar == null) {
            return;
        }
        pitchSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(pitchSeekBar, canEnable);
        if (pitchValueText != null) {
            pitchValueText.setTextColor(canEnable
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    private void updateSpeedControlState(boolean canEnable,
                                         int themeColor) {
        if (speedSeekBar == null) {
            return;
        }
        speedSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(speedSeekBar, canEnable);
        if (speedValueText != null) {
            speedValueText.setTextColor(canEnable
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    private void updateBandControlsState(boolean enabled,
                                         boolean canEnable,
                                         int themeColor) {
        if (bandSeekBars == null || equalizerManager == null) {
            return;
        }
        for (SeekBar bandSeekBar : bandSeekBars) {
            if (bandSeekBar != null) {
                bandSeekBar.setEnabled(enabled && canEnable);
                themeHelper.updateSeekBar(
                    bandSeekBar, enabled && canEnable);
            }
        }
        if (bandValueTexts != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null) {
                    bandValueText.setTextColor((enabled && canEnable)
                        ? themeColor
                        : Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }

    private void updateEnableButtonState(boolean canEnable,
                                         boolean enabled) {
        if (enableButton == null) {
            return;
        }
        enableButton.setEnabled(canEnable);
        if (canEnable) {
            enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        } else {
            enableButton.setText("ENABLE");
        }
        themeHelper.updateButton(enableButton, canEnable);
    }

    // ============================================================================
    // Band Control Methods
    // ============================================================================

    private void showPresetDialog() {
        if (isClosing.get()) {
            return;
        }
        if (!isEqualizerOperational()) {
            ToastManager.showToast(this, "Enable equalizer first",
                ToastManager.LENGTH_SHORT);
            return;
        }
        if (equalizerManager == null) {
            return;
        }

        String[] presetNames = equalizerManager.getPresetNames();
        int currentPreset = equalizerManager.getCurrentPreset();

        PresetDialog dialog = new PresetDialog(this, presetNames,
            currentPreset, new PresetDialog.OnPresetSelectedListener() {
                @Override
                public void onPresetSelected(int presetIndex,
                                             String presetName) {
                    if (!isClosing.get()
                            && isEqualizerOperational()
                            && equalizerManager != null) {
                        equalizerManager.applyPreset(presetIndex);
                    }
                }
            });

        dialog.setOnDismissListener(
            new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dismissedDialog) {
                isPresetDialogShowing = false;
            }
        });
        dialog.show();
    }

    private void createBandControls() {
        if (bandsContainer == null || isClosing.get()
                || equalizerManager == null) {
            return;
        }
        bandsContainer.removeAllViews();
        final short numberOfBands =
            equalizerManager.getNumberOfBands();
        if (numberOfBands == 0) {
            return;
        }

        bandSeekBars = new SeekBar[numberOfBands];
        bandValueTexts = new TextView[numberOfBands];
        final int minLevel = equalizerManager.getMinBandLevel();
        final int maxLevel = equalizerManager.getMaxBandLevel();
        final int seekBarWidth = maxLevel - minLevel;
        final int themeColor = themeHelper.getThemeColorInt();

        for (int bandIndex = 0; bandIndex < numberOfBands;
                bandIndex++) {
            createSingleBandControl(
                bandIndex, minLevel, maxLevel, seekBarWidth, themeColor);
        }
    }

    private void createSingleBandControl(final int bandIndex,
                                         final int minLevel,
                                         final int maxLevel,
                                         final int seekBarWidth,
                                         final int themeColor) {
        int frequency = equalizerManager.getCenterFrequency(bandIndex);
        String frequencyText =
            equalizerManager.getFrequencyLabel(frequency);
        final int currentLevel =
            equalizerManager.getBandLevel(bandIndex);

        LinearLayout bandContainer = new LinearLayout(this);
        bandContainer.setOrientation(LinearLayout.VERTICAL);
        bandContainer.setPadding(0, 4, 0, 4);
        bandContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView frequencyLabel = new TextView(this);
        frequencyLabel.setText(frequencyText);
        frequencyLabel.setTextColor(
            Color.parseColor(TEXT_COLOR_LIGHT));
        frequencyLabel.setTextSize(12);
        frequencyLabel.setPadding(0, 8, 0, 0);
        frequencyLabel.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        final TextView levelText = new TextView(this);
        levelText.setText(formatLevel(currentLevel));
        levelText.setTextColor(themeColor);
        levelText.setTextSize(12);
        levelText.setPadding(0, 8, 0, 0);

        topRow.addView(frequencyLabel);
        topRow.addView(levelText);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(seekBarWidth);

        int initialProgress = currentLevel - minLevel;
        int roundedInitial = Math.round(initialProgress
            / (float) EQ_BAND_UNITS_PER_STEP)
            * EQ_BAND_UNITS_PER_STEP;
        roundedInitial = Math.max(0,
            Math.min(seekBarWidth, roundedInitial));
        seekBar.setProgress(roundedInitial);

        seekBar.setThumb(null);
        seekBar.setEnabled(
            equalizerManager.isEnabled() && hasAudioSession());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressDrawable(getResources()
                .getDrawable(R.drawable.seekbar_progress, null));
        } else {
            seekBar.setProgressDrawable(ContextCompat.getDrawable(
                this, R.drawable.seekbar_progress));
        }
        themeHelper.updateSeekBar(seekBar, seekBar.isEnabled());

        LinearLayout.LayoutParams seekParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = 8;
        seekParams.bottomMargin = 8;
        seekBar.setLayoutParams(seekParams);

        bandContainer.addView(topRow);
        bandContainer.addView(seekBar);
        bandsContainer.addView(bandContainer);

        bandSeekBars[bandIndex] = seekBar;
        bandValueTexts[bandIndex] = levelText;

        final int min = minLevel;

        seekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isEqRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) EQ_BAND_UNITS_PER_STEP)
                        * EQ_BAND_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(seekBarWidth, rounded));

                    if (rounded != progress) {
                        isEqRounding = true;
                        seekBar.setProgress(rounded);
                        int level = min + rounded;
                        equalizerManager.setBandLevel(
                            bandIndex, level);
                        levelText.setText(formatLevel(level));
                        isEqRounding = false;
                    } else {
                        int level = min + progress;
                        equalizerManager.setBandLevel(
                            bandIndex, level);
                        levelText.setText(formatLevel(level));
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isEqRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void updateBandControlsFromLevels() {
        if (isClosing.get()
                || bandSeekBars == null
                || equalizerManager == null
                || !equalizerManager.isAttached()) {
            return;
        }
        final int minLevel = equalizerManager.getMinBandLevel();
        final int themeColor = themeHelper.getThemeColorInt();
        for (int bandIndex = 0;
                bandIndex < bandSeekBars.length
                    && bandIndex
                        < equalizerManager.getNumberOfBands();
                bandIndex++) {
            final int level =
                equalizerManager.getBandLevel(bandIndex);
            if (bandSeekBars[bandIndex] != null) {
                int progress = level - minLevel;
                int rounded = Math.round(progress
                    / (float) EQ_BAND_UNITS_PER_STEP)
                    * EQ_BAND_UNITS_PER_STEP;
                rounded = Math.max(0,
                    Math.min(bandSeekBars[bandIndex].getMax(),
                        rounded));
                bandSeekBars[bandIndex].setProgress(rounded);
            }
            if (bandValueTexts[bandIndex] != null) {
                bandValueTexts[bandIndex].setText(
                    formatLevel(level));
                if (equalizerManager.isEnabled()
                        && hasAudioSession()) {
                    bandValueTexts[bandIndex].setTextColor(
                        themeColor);
                }
            }
        }
    }

    private String formatLevel(int level) {
        int rounded = Math.round(level
            / (float) EQ_BAND_UNITS_PER_STEP)
            * EQ_BAND_UNITS_PER_STEP;

        float decibels = rounded / 100.0f;
        if (decibels > 0) {
            return String.format("+%.1f dB", decibels);
        } else if (decibels < 0) {
            return String.format("%.1f dB", decibels);
        } else {
            return "0.0 dB";
        }
    }

    // ============================================================================
    // Effect Value Update Methods
    // ============================================================================

    private void updateBassBoostValue(int value) {
        if (!isClosing.get() && bassBoostValueText != null) {
            bassBoostValueText.setText(
                ((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }

    private void updateSurroundValue(int value) {
        if (!isClosing.get() && surroundValueText != null) {
            surroundValueText.setText(
                ((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }

    private void updatePitchValue(int value) {
        if (!isClosing.get() && pitchValueText != null) {
            float semitones =
                (value - PITCH_DEFAULT) / (1000.0f / 6.0f);
            if (Math.abs(semitones) < 0.05f) {
                pitchValueText.setText("0.0 st");
            } else if (semitones > 0) {
                pitchValueText.setText(
                    String.format("+%.1f st", semitones));
            } else {
                pitchValueText.setText(
                    String.format("%.1f st", semitones));
            }
        }
    }

    private void updateSpeedValue(int value) {
        if (!isClosing.get() && speedValueText != null) {
            float speed = 0.5f + (value / 2000.0f);
            speedValueText.setText(
                String.format("%.2fx", speed));
        }
    }

    private void updateAllEffectValues() {
        if (isClosing.get() || equalizerManager == null) {
            return;
        }
        updateBassBoostValue(equalizerManager.getBassBoost());
        updateSurroundValue(equalizerManager.getSurround());
        updatePitchValue(equalizerManager.getPitch());
        updateSpeedValue(equalizerManager.getSpeed());
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    private void updateUI() {
        updateUI(true);
    }

    private void updateUI(boolean showTransitionMessage) {
        if (isClosing.get() || equalizerManager == null) {
            return;
        }
        boolean enabled = equalizerManager.isEnabled();
        if (enableButton != null) {
            enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        }
        updateUIState(enabled);
        updateAllEffectValues();
        applyThemeToUI();
        if (statusText != null && isEqualizerReady
                && hasAudioSession()) {
            if (enabled) {
                if (revertToWavesRunnable != null) {
                    mainHandler.removeCallbacks(
                        revertToWavesRunnable);
                }
                if (showTransitionMessage) {
                    showTemporaryMessage("Equalizer: Enabled");
                } else {
                    statusText.setText("ENJOY THE WAVES");
                    statusText.setTextColor(
                        Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else {
                showPersistentDisabledMessage();
            }
        }
    }

    private void notifyPlaybackParamsChanged() {
        if (isClosing.get()) {
            return;
        }
        Intent intent = new Intent(ACTION_UPDATE_PLAYBACK_PARAMS);
        sendBroadcast(intent);
        Log.d(TAG,
            "Notified MusicService of playback param changes");
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    private void setupListeners() {
        setupPresetButtonListener();
        setupBassBoostListener();
        setupSurroundListener();
        setupPitchListener();
        setupSpeedListener();
        setupResetButtonListener();
        setupEnableButtonListener();
        setupCancelButtonListener();
    }

    private void setupPresetButtonListener() {
        if (presetButton == null) {
            return;
        }
        presetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClosing.get() || isPresetDialogShowing) {
                    return;
                }
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastPresetClickTime
                        < PRESET_DEBOUNCE_DELAY_MS) {
                    return;
                }
                lastPresetClickTime = currentTime;
                isPresetDialogShowing = true;
                showPresetDialog();
            }
        });
    }

    private void setupBassBoostListener() {
        if (bassBoostSeekBar == null) {
            return;
        }

        bassBoostSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isBassRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) BOOST_UNITS_PER_PERCENT)
                        * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX_BOOST, rounded));

                    if (rounded != progress) {
                        isBassRounding = true;
                        bassBoostSeekBar.setProgress(rounded);
                        equalizerManager.setBassBoost(rounded);
                        updateBassBoostValue(rounded);
                        isBassRounding = false;
                    } else {
                        equalizerManager.setBassBoost(progress);
                        updateBassBoostValue(progress);
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isBassRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setupSurroundListener() {
        if (surroundSeekBar == null) {
            return;
        }

        surroundSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isSurroundRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) BOOST_UNITS_PER_PERCENT)
                        * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX_BOOST, rounded));

                    if (rounded != progress) {
                        isSurroundRounding = true;
                        surroundSeekBar.setProgress(rounded);
                        equalizerManager.setSurround(rounded);
                        updateSurroundValue(rounded);
                        isSurroundRounding = false;
                    } else {
                        equalizerManager.setSurround(progress);
                        updateSurroundValue(progress);
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSurroundRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setupPitchListener() {
        if (pitchSeekBar == null) {
            return;
        }

        pitchSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && equalizerManager != null) {
                    if (isPitchRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) PITCH_UNITS_PER_STEP)
                        * PITCH_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX, rounded));

                    if (rounded != progress) {
                        isPitchRounding = true;
                        pitchSeekBar.setProgress(rounded);
                        equalizerManager.setPitch(rounded);
                        updatePitchValue(rounded);
                        isPitchRounding = false;

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setPitch(progress);
                        updatePitchValue(progress);

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isPitchRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setupSpeedListener() {
        if (speedSeekBar == null) {
            return;
        }

        speedSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && equalizerManager != null) {
                    if (isSpeedRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) SPEED_UNITS_PER_STEP)
                        * SPEED_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX, rounded));

                    if (rounded != progress) {
                        isSpeedRounding = true;
                        speedSeekBar.setProgress(rounded);
                        equalizerManager.setSpeed(rounded);
                        updateSpeedValue(rounded);
                        isSpeedRounding = false;

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setSpeed(progress);
                        updateSpeedValue(progress);

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSpeedRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setupResetButtonListener() {
        if (resetButton == null) {
            return;
        }
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClosing.get() || equalizerManager == null) {
                    return;
                }

                boolean equalizerOperational =
                    isEqualizerOperational();
                boolean anythingChanged = false;

                if (equalizerOperational) {
                    short numberOfBands =
                        equalizerManager.getNumberOfBands();
                    for (short bandIndex = 0;
                            bandIndex < numberOfBands; bandIndex++) {
                        if (equalizerManager.getBandLevel(bandIndex)
                                != 0) {
                            equalizerManager.setBandLevel(
                                bandIndex, 0);
                            anythingChanged = true;
                        }
                    }
                    if (anythingChanged) {
                        equalizerManager.clearCustomBandLevels();
                    }
                }

                if (equalizerOperational
                        && equalizerManager.isBassBoostSupported()) {
                    int currentBass = equalizerManager.getBassBoost();
                    if (currentBass != 0) {
                        equalizerManager.setBassBoost(0);
                        if (bassBoostSeekBar != null) {
                            bassBoostSeekBar.setProgress(0);
                        }
                        updateBassBoostValue(0);
                        anythingChanged = true;
                    }
                }

                if (equalizerOperational
                        && equalizerManager.isSurroundSupported()) {
                    int currentSurround =
                        equalizerManager.getSurround();
                    if (currentSurround != 0) {
                        equalizerManager.setSurround(0);
                        if (surroundSeekBar != null) {
                            surroundSeekBar.setProgress(0);
                        }
                        updateSurroundValue(0);
                        anythingChanged = true;
                    }
                }

                int currentPitch = equalizerManager.getPitch();
                if (currentPitch != PITCH_DEFAULT) {
                    equalizerManager.setPitch(PITCH_DEFAULT);
                    if (pitchSeekBar != null) {
                        pitchSeekBar.setProgress(PITCH_DEFAULT);
                    }
                    updatePitchValue(PITCH_DEFAULT);
                    anythingChanged = true;
                }

                int currentSpeed = equalizerManager.getSpeed();
                if (currentSpeed != SPEED_DEFAULT) {
                    equalizerManager.setSpeed(SPEED_DEFAULT);
                    if (speedSeekBar != null) {
                        speedSeekBar.setProgress(SPEED_DEFAULT);
                    }
                    updateSpeedValue(SPEED_DEFAULT);
                    anythingChanged = true;
                }

                if (equalizerOperational && anythingChanged) {
                    equalizerManager.applyPreset(0);
                }

                updateBandControlsFromLevels();

                if (anythingChanged) {
                    if (isBindingComplete && musicService != null
                            && musicService.isPlaying()) {
                        notifyPlaybackParamsChanged();
                    }
                    ToastManager.showToast(EqualizerActivity.this,
                        "Reset to factory defaults",
                        ToastManager.LENGTH_SHORT);
                } else {
                    ToastManager.showToast(EqualizerActivity.this,
                        "Already at default settings",
                        ToastManager.LENGTH_SHORT);
                }
            }
        });
    }

    private void setupEnableButtonListener() {
        if (enableButton == null) {
            return;
        }
        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isClosing.get()
                        && equalizerManager != null
                        && hasAudioSession()) {
                    boolean newState = !equalizerManager.isEnabled();
                    equalizerManager.setEnabled(newState);
                    updateUI();
                }
            }
        });
    }

    private void setupCancelButtonListener() {
        if (cancelButton == null) {
            return;
        }
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isClosing.get()) {
                    getWindow().setFlags(
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    finish();
                }
            }
        });
    }
}