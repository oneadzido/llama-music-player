package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Provides the UI for adjusting audio effects: a multi-band
 * equalizer, bass boost, surround effect, pitch, and playback speed.
 *
 * <p>The activity reads the device's audio effect capabilities from
 * {@link EqualizerManager} and builds the corresponding controls.
 * One SeekBar is created for each equalizer band the device reports.
 * SeekBars for bass boost and surround snap to the nearest 1%, for
 * pitch to the nearest 0.1 semitone, for speed to the nearest 0.01x,
 * and for each equalizer band to the nearest 0.1 dB. The Reset button
 * restores every effect to its factory default.</p>
 *
 * <p>All audio effect operations are delegated to
 * {@link EqualizerManager}.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>The band controls and the effect controls share a single scroll
 * container. In the full layout, the band wrapper carries weight 1,
 * so it takes whatever space the effect controls leave and the whole
 * column fits the window. In split mode, the band wrapper drops its
 * weight and takes its natural height; the two sections then scroll
 * together as one column whose height is the sum of the two.</p>
 *
 * <p>The top bar, the status line, the preset button, and the reset
 * button are untouched in both layouts. Every touch target the user's
 * finger depends on keeps its size.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. Work originating from
 * broadcast receivers and service callbacks is routed through
 * {@link #safeRunOnUiThread(Runnable)}, which uses an
 * {@link AtomicBoolean} to refuse overlapping updates and drops
 * any request that arrives after the activity has begun
 * destroying.</p>
 *
 * @see EqualizerManager
 * @see PresetDialog
 * @see ThemeHelper
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.0.0
 */
public class EqualizerActivity extends Activity {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for debugging purposes. */
    private static final String TAG = "EqualizerActivity";

    /** Broadcast action for audio session changes from MusicService. */
    private static final String ACTION_AUDIO_SESSION_CHANGED =
        "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Broadcast action for updating playback parameters. */
    private static final String ACTION_UPDATE_PLAYBACK_PARAMS =
        "UPDATE_PLAYBACK_PARAMS";

    /** Broadcast action for theme color change notifications. */
    private static final String ACTION_THEME_COLOR_CHANGED =
        "THEME_COLOR_CHANGED";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for bass boost level. */
    private static final String KEY_BASS_BOOST = "bass_boost_level";

    /** Key for surround effect level. */
    private static final String KEY_SURROUND = "surround_level";

    /** Key for pitch level. */
    private static final String KEY_PITCH = "pitch_level";

    /** Key for speed level. */
    private static final String KEY_SPEED = "speed_level";

    /** Prefix for equalizer band level keys. */
    private static final String KEY_BAND_PREFIX = "eq_band_";

    /** Duration for button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Scale factor for button release animation. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum value for bass boost and surround SeekBars. */
    private static final int SEEKBAR_MAX_BOOST = 1000;

    /** Maximum value for pitch and speed SeekBars. */
    private static final int SEEKBAR_MAX = 2000;

    /** Default value for pitch SeekBar (0 semitones). */
    private static final int PITCH_DEFAULT = 1000;

    /** Default value for speed SeekBar (1.00x speed). */
    private static final int SPEED_DEFAULT = 1000;

    /** Units per 1% for bass boost and surround. */
    private static final int BOOST_UNITS_PER_PERCENT = 10;

    /** Units per 0.1 dB for equalizer bands. */
    private static final int EQ_BAND_UNITS_PER_STEP = 10;

    /** Units per 0.1 semitone for pitch. */
    private static final int PITCH_UNITS_PER_STEP = 17;

    /** Units per 0.01x for speed. */
    private static final int SPEED_UNITS_PER_STEP = 20;

    /** Light gray text color for secondary UI elements. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Disabled text color for inactive controls. */
    private static final String COLOR_DISABLED = "#5A5A5A";

    /** Debounce delay for preset button clicks in milliseconds. */
    private static final long PRESET_DEBOUNCE_DELAY_MS = 500;

    /** Duration for temporary status messages in milliseconds. */
    private static final int STATUS_MESSAGE_DURATION_MS = 1500;

    /** Delay for UI refresh after reattaching to the audio session. */
    private static final long UI_REFRESH_DELAY_MS = 200;

    /** Window height below which the split layout is applied. */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Container into which the per-band controls are built. */
    private LinearLayout bandsContainer;

    /**
     * Wrapper around {@link #bandsContainer}.
     *
     * <p>Carries the layout weight the split layout toggles. In the
     * full layout the wrapper's weight is 1, so the band controls
     * take the space the effect controls leave. In split mode the
     * wrapper's weight is 0, so it takes its natural height and the
     * two sections scroll together inside their shared container.</p>
     */
    private LinearLayout bandsWrapper;

    /** Button that opens the preset selection dialog. */
    private Button presetButton;

    /** SeekBar controlling the bass boost strength. */
    private SeekBar bassBoostSeekBar;

    /** SeekBar controlling the surround effect strength. */
    private SeekBar surroundSeekBar;

    /** SeekBar controlling the pitch shift. */
    private SeekBar pitchSeekBar;

    /** SeekBar controlling the playback speed. */
    private SeekBar speedSeekBar;

    /** Text view displaying the bass boost value as a percentage. */
    private TextView bassBoostValueText;

    /** Text view displaying the surround value as a percentage. */
    private TextView surroundValueText;

    /** Text view displaying the pitch value in semitones. */
    private TextView pitchValueText;

    /** Text view displaying the speed value in multiples of 1.0x. */
    private TextView speedValueText;

    /** Button that resets every effect to its factory default. */
    private Button resetButton;

    /** Button that finishes the activity. */
    private Button cancelButton;

    /** Button that toggles the equalizer's enabled state. */
    private Button enableButton;

    /** Text view displaying the equalizer's status message. */
    private TextView statusText;

    /** SeekBars for the equalizer bands, indexed by band. */
    private SeekBar[] bandSeekBars;

    /** Value labels for the equalizer bands, indexed by band. */
    private TextView[] bandValueTexts;

    // ============================================================================
    // State Management
    // ============================================================================

    /** Handler for every delayed operation in the activity. */
    private final Handler mainHandler =
        new Handler(Looper.getMainLooper());

    /** True once the equalizer has reported itself ready. */
    private boolean isEqualizerReady = false;

    /** True once the per-band controls have been created. */
    private boolean areBandsCreated = false;

    /** Pending runnable that reverts the status line to its default. */
    private Runnable revertToWavesRunnable;

    /** Timestamp of the last preset button click. */
    private long lastPresetClickTime = 0;

    /** True while the preset dialog is showing. */
    private boolean isPresetDialogShowing = false;

    /**
     * True once the activity has begun destroying.
     *
     * <p>Read by every delayed callback to refuse work that would
     * touch a torn-down view hierarchy.</p>
     */
    private final AtomicBoolean isClosing = new AtomicBoolean(false);

    /**
     * Guard that serialises concurrent UI updates.
     *
     * <p>Refuses a second update that arrives while the first is
     * still on the main-thread queue.</p>
     */
    private final AtomicBoolean isUpdatingUI =
        new AtomicBoolean(false);

    /** True while the bass boost SeekBar is snapping its own value. */
    private boolean isBassRounding = false;

    /** True while the surround SeekBar is snapping its own value. */
    private boolean isSurroundRounding = false;

    /** True while an equalizer band SeekBar is snapping its own value. */
    private boolean isEqRounding = false;

    /** True while the pitch SeekBar is snapping its own value. */
    private boolean isPitchRounding = false;

    /** True while the speed SeekBar is snapping its own value. */
    private boolean isSpeedRounding = false;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    /** Singleton that owns the audio effect objects and their settings. */
    private EqualizerManager equalizerManager;

    /** Manager for the current theme color. */
    private ThemeManager themeManager;

    /** Helper for applying theme colors to UI components. */
    private ThemeHelper themeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver themeReceiver;

    /** Bound service used to observe playback state. */
    private MusicService musicService;

    /** Connection used to bind and unbind the service. */
    private ServiceConnection serviceConnection;

    /** True while the service is bound. */
    private boolean isServiceBound = false;

    /** True once the service connection has completed at least once. */
    private boolean isBindingComplete = false;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    /** Receiver for audio session change broadcasts. */
    private final BroadcastReceiver audioSessionReceiver =
        new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) {
                return;
            }
            if (ACTION_AUDIO_SESSION_CHANGED.equals(
                    intent.getAction())) {
                final int newSessionId =
                    intent.getIntExtra("audio_session_id", -1);
                Log.d(TAG, "Audio session changed: " + newSessionId);
                if (newSessionId > 0) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                equalizerManager.attachToAudioSession(
                                    newSessionId);
                            }
                        }
                    });
                }
            }
        }
    };

    /** Receiver for playback parameter update broadcasts. */
    private final BroadcastReceiver updatePlaybackParamsReceiver =
        new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isClosing.get()) {
                return;
            }
            if (ACTION_UPDATE_PLAYBACK_PARAMS.equals(
                    intent.getAction())) {
                safeRunOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateAllEffectValues();
                    }
                });
            }
        }
    };

    // ============================================================================
    // Equalizer Listener
    // ============================================================================

    /**
     * Listener for equalizer state changes.
     *
     * <p>Every callback routes through {@link #safeRunOnUiThread} so
     * a callback that arrives after the activity has begun
     * destroying is discarded.</p>
     */
    private final EqualizerManager.EqualizerListener equalizerListener =
        new EqualizerManager.EqualizerListener() {

        /**
         * Refreshes the per-band SeekBars from the new level array.
         *
         * @param levels The new band level values
         */
        @Override
        public void onBandLevelsChanged(int[] levels) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (bandSeekBars != null) {
                        updateBandControlsFromLevels();
                    }
                }
            });
        }

        /**
         * Updates the preset button label and shows a transient
         * status message while the equalizer is enabled and an
         * audio session is available.
         *
         * @param preset The new preset index
         * @param presetName The name of the new preset
         */
        @Override
        public void onPresetChanged(final int preset,
                                    final String presetName) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (presetButton != null) {
                        presetButton.setText(presetName);
                    }
                    if (statusText != null && equalizerManager != null
                            && equalizerManager.isEnabled()
                            && hasAudioSession()) {
                        showTemporaryMessage(
                            "Equalizer: " + presetName);
                        statusText.setTextColor(
                            Color.parseColor(TEXT_COLOR_LIGHT));
                    }
                }
            });
        }

        /**
         * Updates the ready state, enables or disables the reset
         * button, and dispatches to the ready or not-ready handler.
         *
         * @param ready True when the equalizer is ready for use
         */
        @Override
        public void onEqualizerReady(final boolean ready) {
            if (isClosing.get()) {
                return;
            }
            safeRunOnUiThread(new Runnable() {
                @Override
                public void run() {
                    isEqualizerReady = ready;
                    boolean hasAudio = hasAudioSession();

                    if (resetButton != null) {
                        resetButton.setEnabled(hasAudio);
                        themeHelper.updateButton(resetButton, hasAudio);
                    }

                    if (ready) {
                        handleEqualizerReady(hasAudio);
                    } else {
                        handleEqualizerNotReady();
                    }
                }
            });
        }
    };

    // ============================================================================
    // Thread Safety Methods
    // ============================================================================

    /**
     * Runs the given action on the main thread when the activity is
     * still active, refusing overlapping invocations.
     *
     * <p>Refused when the activity is finishing, destroyed, or has
     * begun destroying, and refused when another update is already
     * in flight. The guard is released when the action completes so
     * a subsequent request can proceed.</p>
     *
     * @param action The action to run on the main thread
     */
    private void safeRunOnUiThread(final Runnable action) {
        if (isFinishing() || isDestroyed() || isClosing.get()) {
            return;
        }
        if (!isUpdatingUI.compareAndSet(false, true)) {
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()
                            && !isClosing.get()) {
                        action.run();
                    }
                } finally {
                    isUpdatingUI.set(false);
                }
            }
        });
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, resolves its views, registers its
     * receivers, binds the service, and applies the split layout for
     * the current window height.
     *
     * <p>Attaches the equalizer to the current audio session when
     * one is available; otherwise routes to the no-audio-session
     * placeholder state.</p>
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_equalizer);

        initializeManagers();
        initializeViews();

        setupListeners();
        registerReceivers();
        bindMusicService();

        applyEqualizerSplitLayout(
            getResources().getConfiguration().screenHeightDp);

        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
        } else {
            handleNoAudioSession();
        }

        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Re-registers the theme receiver, refreshes every control from
     * the current equalizer state, and reattaches to the audio
     * session when one is available.
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (isClosing.get()) {
            return;
        }

        registerThemeReceiverIfNeeded();
        updateUI(false);
        updateAllEffectValues();

        boolean hasAudio = hasAudioSession();
        updateResetButtonState(hasAudio);

        if (!hasAudio) {
            handleNoAudioSession();
        }

        updateBandControlsState();

        int sessionId = MusicService.getAudioSessionId();
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId);
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isClosing.get()
                            && equalizerManager.isAttached()) {
                        refreshAllUIControls();
                    }
                }
            }, UI_REFRESH_DELAY_MS);
        } else {
            handleNoAudioSession();
        }

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onPause() {
        super.onPause();
        if (themeReceiver != null) {
            try {
                unregisterReceiver(themeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            themeReceiver = null;
        }
    }

    /**
     * Marks the activity as closing, unbinds the service,
     * unregisters every receiver, and removes every pending handler
     * callback.
     */
    @Override
    protected void onDestroy() {
        isClosing.set(true);
        super.onDestroy();

        unbindServiceSafely();
        unregisterReceiverSafely(audioSessionReceiver);
        unregisterReceiverSafely(updatePlaybackParamsReceiver);
        unregisterReceiverSafely(themeReceiver);

        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }
        if (equalizerManager != null) {
            equalizerManager.setListener(null);
        }
    }

    /**
     * Reapplies the immersive system UI flags when the window gains
     * focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT
                && !isClosing.get()) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Reapplies the split layout for the new window height.
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applyEqualizerSplitLayout(config.screenHeightDp);
    }

    /**
     * Applies the slide-down exit transition and defers to the
     * default back behaviour.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(
            R.anim.slide_in_down, R.anim.slide_out_down);
    }

    /**
     * Applies the slide-down exit transition and finishes the
     * activity.
     */
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(
            R.anim.slide_in_down, R.anim.slide_out_down);
    }

    // ============================================================================
    // Split Layout
    // ============================================================================

    /**
     * Switches the band wrapper between the full-layout weight and
     * the split-mode natural height.
     *
     * <p>The band wrapper and the effect controls live in the same
     * scroll container, so the only value the split layout changes
     * is whether the band wrapper fills the space the effect
     * controls leave. In the full layout it does; the whole column
     * fits the window and the effect controls sit below it at their
     * natural height. In split mode it does not; the band wrapper
     * takes its natural height and the two sections scroll together
     * inside the shared container, so the user can reach the bands
     * and the effects in either direction.</p>
     *
     * <p>The top bar, the status line, the preset button, and the
     * reset button are untouched in both layouts. Every touch target
     * the user's finger depends on keeps its size.</p>
     *
     * @param screenHeightDp Current window height in dp
     */
    private void applyEqualizerSplitLayout(int screenHeightDp) {
        if (bandsWrapper == null) {
            return;
        }

        final boolean isSplit = screenHeightDp
            < SPLIT_SCREEN_MIN_HEIGHT_DP;
        final LinearLayout.LayoutParams params =
            (LinearLayout.LayoutParams)
                bandsWrapper.getLayoutParams();
        final float newWeight = isSplit ? 0f : 1f;
        if (params.weight != newWeight) {
            params.weight = newWeight;
            bandsWrapper.setLayoutParams(params);
        }
    }

    // ============================================================================
    // Initialization Methods
    // ============================================================================

    /**
     * Resolves the manager singletons and registers this activity as
     * the equalizer listener.
     */
    private void initializeManagers() {
        equalizerManager = EqualizerManager.getInstance(this);
        equalizerManager.setListener(equalizerListener);
        themeManager = ThemeManager.getInstance(this);
        themeHelper = ThemeHelper.getInstance(this);
    }

    /**
     * Registers the audio-session and playback-parameter receivers
     * as not-exported receivers.
     */
    private void registerReceivers() {
        IntentFilter audioSessionFilter = new IntentFilter();
        audioSessionFilter.addAction(ACTION_AUDIO_SESSION_CHANGED);
        ContextCompat.registerReceiver(
            this, audioSessionReceiver, audioSessionFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED);

        IntentFilter paramsFilter =
            new IntentFilter(ACTION_UPDATE_PLAYBACK_PARAMS);
        ContextCompat.registerReceiver(
            this, updatePlaybackParamsReceiver, paramsFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Binds to {@link MusicService} and stores the service reference
     * once connected.
     *
     * <p>Sets {@link #isBindingComplete} on the first connection so
     * pitch and speed listeners can decide whether a running
     * playback needs a parameter refresh. The connection is
     * unbound in {@link #onDestroy()}.</p>
     */
    private void bindMusicService() {
        Intent bindIntent = new Intent(this, MusicService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name,
                                           IBinder service) {
                MusicService.LocalBinder binder =
                    (MusicService.LocalBinder) service;
                musicService = binder.getService();
                isServiceBound = true;
                isBindingComplete = true;
                updateUI(false);
                updateAllEffectValues();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                musicService = null;
                isServiceBound = false;
            }
        };
        bindService(bindIntent, serviceConnection, BIND_AUTO_CREATE);
    }

    /**
     * Registers the theme receiver when one is not already
     * registered.
     *
     * <p>The receiver reapplies the theme, rethemes the header
     * texts, and refreshes the toast theme color whenever a theme
     * change broadcast arrives.</p>
     */
    private void registerThemeReceiverIfNeeded() {
        if (themeReceiver != null) {
            return;
        }

        themeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (isClosing.get()) {
                    return;
                }
                if (ACTION_THEME_COLOR_CHANGED.equals(
                        intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isClosing.get()) {
                                applyThemeToUI();
                                themeAllHeaders();
                                ToastManager.refreshThemeColor();
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        ContextCompat.registerReceiver(
            this, themeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    // ============================================================================
    // State Query Helpers
    // ============================================================================

    /**
     * Returns whether the service has a live audio session.
     *
     * @return True when the audio session id is positive
     */
    private boolean hasAudioSession() {
        return MusicService.getAudioSessionId() > 0;
    }

    /**
     * Returns whether the equalizer is in a usable state.
     *
     * <p>An operational equalizer is enabled, attached to an audio
     * session, and has reported at least one band. Every listener
     * that mutates a band checks this before touching the
     * underlying effect object.</p>
     *
     * @return True when the equalizer can be used
     */
    private boolean isEqualizerOperational() {
        return equalizerManager != null
            && equalizerManager.isEnabled()
            && hasAudioSession()
            && equalizerManager.isAttached()
            && equalizerManager.getNumberOfBands() > 0;
    }

    /**
     * Refreshes every control's progress, enabled state, and theme
     * from the current equalizer state.
     *
     * <p>Reads the settings from {@link EqualizerManager} and writes
     * them into the SeekBars and text views. Called after the
     * service reconnects and after the delayed post-resume refresh,
     * so a value changed from another surface is reflected here.</p>
     */
    private void refreshAllUIControls() {
        if (equalizerManager == null) {
            return;
        }

        boolean isEnabled = equalizerManager.isEnabled();
        boolean hasAudio = hasAudioSession();
        int themeColor = themeHelper.getThemeColorInt();

        if (bassBoostSeekBar != null) {
            if (equalizerManager.isBassBoostSupported()) {
                int bassLevel = equalizerManager.getBassBoost();
                bassBoostSeekBar.setProgress(bassLevel);
                updateBassBoostValue(bassLevel);
                bassBoostSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                bassBoostSeekBar.setEnabled(false);
                if (bassBoostValueText != null) {
                    bassBoostValueText.setText("OFF");
                }
            }
        }
        if (bassBoostValueText != null) {
            boolean active = isEnabled && hasAudio
                && equalizerManager.isBassBoostSupported();
            bassBoostValueText.setTextColor(active
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (surroundSeekBar != null) {
            if (equalizerManager.isSurroundSupported()) {
                int surroundLevel = equalizerManager.getSurround();
                surroundSeekBar.setProgress(surroundLevel);
                updateSurroundValue(surroundLevel);
                surroundSeekBar.setEnabled(isEnabled && hasAudio);
            } else {
                surroundSeekBar.setEnabled(false);
                if (surroundValueText != null) {
                    surroundValueText.setText("OFF");
                }
            }
        }
        if (surroundValueText != null) {
            boolean active = isEnabled && hasAudio
                && equalizerManager.isSurroundSupported();
            surroundValueText.setTextColor(active
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (pitchSeekBar != null) {
            int pitchLevel = equalizerManager.getPitch();
            pitchSeekBar.setProgress(pitchLevel);
            updatePitchValue(pitchLevel);
            pitchSeekBar.setEnabled(hasAudio);
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(hasAudio
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        if (speedSeekBar != null) {
            int speedLevel = equalizerManager.getSpeed();
            speedSeekBar.setProgress(speedLevel);
            updateSpeedValue(speedLevel);
            speedSeekBar.setEnabled(hasAudio);
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(hasAudio
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }

        updateBandControlsFromLevels();

        if (presetButton != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            presetButton.setText(
                equalizerManager.getPresetName(currentPreset));
            presetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(
                presetButton, isEnabled && hasAudio);
        }

        if (enableButton != null) {
            enableButton.setEnabled(hasAudio);
            enableButton.setText(isEnabled ? "DISABLE" : "ENABLE");
            themeHelper.updateButton(enableButton, hasAudio);
        }

        if (resetButton != null) {
            resetButton.setEnabled(isEnabled && hasAudio);
            themeHelper.updateButton(
                resetButton, isEnabled && hasAudio);
        }

        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("ENJOY THE WAVES");
            } else {
                statusText.setText("Equalizer: Disabled");
            }
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }
    }

    /**
     * Handles the equalizer's ready state.
     *
     * <p>Creates the per-band controls on the first ready report,
     * refreshes every effect control, and updates the preset,
     * enable, and reset buttons and the status line to reflect
     * whether the equalizer is enabled and whether an audio session
     * is available.</p>
     *
     * @param hasAudio True when the service has a live audio session
     */
    private void handleEqualizerReady(boolean hasAudio) {
        if (equalizerManager != null
                && equalizerManager.getNumberOfBands() > 0
                && !areBandsCreated) {
            createBandControls();
            areBandsCreated = true;
        }

        refreshAllUIControls();

        if (hasAudio) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(
                    equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) {
                presetButton.setText("Disabled");
            }
            if (enableButton != null) {
                enableButton.setEnabled(false);
                themeHelper.updateButton(enableButton, false);
                enableButton.setText("ENABLE");
            }
        }

        boolean isEnabled = equalizerManager != null
            && equalizerManager.isEnabled();
        updateUIState(isEnabled);

        if (statusText != null) {
            if (isEnabled && hasAudio) {
                statusText.setText("Equalizer: Enabled");
                statusText.setTextColor(
                    themeHelper.getThemeColorInt());
            } else {
                statusText.setText("Equalizer: Disabled");
                statusText.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
            }
        }

        if (enableButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(
                enableButton, enableButton.isEnabled());
        }
        if (resetButton != null && themeHelper != null && hasAudio) {
            themeHelper.updateButton(
                resetButton, resetButton.isEnabled());
        }
    }

    /**
     * Handles the equalizer reporting itself not ready.
     *
     * <p>Disables the enable, preset, and reset buttons, and updates
     * the status line to reflect the unavailable state.</p>
     */
    private void handleEqualizerNotReady() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }

        updateUIState(false);

        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }

        if (presetButton != null) {
            presetButton.setText("Disabled");
        }

        refreshAllUIControls();
    }

    /**
     * Applies the no-audio-session state to every control.
     *
     * <p>Disables every SeekBar, restores its progress from the
     * persisted settings, and displays the disabled state in the
     * status line and the labels. Called during cold start before a
     * session exists and whenever the session is lost.</p>
     */
    private void handleNoAudioSession() {
        if (statusText != null) {
            statusText.setText("Equalizer: Disabled");
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }
        if (presetButton != null) {
            presetButton.setText("Disabled");
        }
        if (enableButton != null) {
            enableButton.setEnabled(false);
            themeHelper.updateButton(enableButton, false);
            enableButton.setText("ENABLE");
        }
        if (resetButton != null) {
            resetButton.setEnabled(false);
            themeHelper.updateButton(resetButton, false);
        }

        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (bassBoostSeekBar != null) {
            int savedBass = preferences.getInt(KEY_BASS_BOOST, 0);
            bassBoostSeekBar.setProgress(savedBass);
            updateBassBoostValue(savedBass);
            bassBoostSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(bassBoostSeekBar, false);
            }
        }
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (surroundSeekBar != null) {
            int savedSurround =
                preferences.getInt(KEY_SURROUND, 0);
            surroundSeekBar.setProgress(savedSurround);
            updateSurroundValue(savedSurround);
            surroundSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(surroundSeekBar, false);
            }
        }
        if (surroundValueText != null) {
            surroundValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (pitchSeekBar != null) {
            int savedPitch =
                preferences.getInt(KEY_PITCH, PITCH_DEFAULT);
            pitchSeekBar.setProgress(savedPitch);
            updatePitchValue(savedPitch);
            pitchSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(pitchSeekBar, false);
            }
        }
        if (pitchValueText != null) {
            pitchValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (speedSeekBar != null) {
            int savedSpeed =
                preferences.getInt(KEY_SPEED, SPEED_DEFAULT);
            speedSeekBar.setProgress(savedSpeed);
            updateSpeedValue(savedSpeed);
            speedSeekBar.setEnabled(false);
            if (themeHelper != null) {
                themeHelper.updateSeekBar(speedSeekBar, false);
            }
        }
        if (speedValueText != null) {
            speedValueText.setTextColor(
                Color.parseColor(COLOR_DISABLED));
        }

        if (bandSeekBars != null) {
            int minLevel = equalizerManager != null
                ? equalizerManager.getMinBandLevel() : -1500;
            for (int index = 0; index < bandSeekBars.length; index++) {
                SeekBar bandSeekBar = bandSeekBars[index];
                if (bandSeekBar != null) {
                    int savedLevel = preferences.getInt(
                        KEY_BAND_PREFIX + index, 0);
                    int progress = savedLevel - minLevel;
                    bandSeekBar.setProgress(Math.max(0,
                        Math.min(bandSeekBar.getMax(), progress)));
                    bandSeekBar.setEnabled(false);
                    if (themeHelper != null) {
                        themeHelper.updateSeekBar(
                            bandSeekBar, false);
                    }
                }
            }
        }
        if (bandValueTexts != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null) {
                    bandValueText.setTextColor(
                        Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }

    /**
     * Refreshes the per-band controls and applies the current
     * enabled state to each band SeekBar.
     */
    private void updateBandControlsState() {
        if (bandSeekBars != null) {
            updateBandControlsFromLevels();
            boolean isEnabled = equalizerManager != null
                && equalizerManager.isEnabled();
            boolean hasAudio = hasAudioSession();
            for (SeekBar bandSeekBar : bandSeekBars) {
                if (bandSeekBar != null) {
                    bandSeekBar.setEnabled(isEnabled && hasAudio);
                }
            }
        }
    }

    /**
     * Unbinds from {@link MusicService} when a binding is active,
     * ignoring any exception raised by the framework.
     */
    private void unbindServiceSafely() {
        if (isServiceBound) {
            try {
                unbindService(serviceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
            isServiceBound = false;
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Status Message Methods
    // ============================================================================

    /**
     * Shows a temporary status message and schedules a revert to the
     * default status line.
     *
     * <p>Cancels any pending revert before scheduling a new one, so a
     * rapid sequence of messages does not leave an old revert to fire
     * on top of the new one.</p>
     *
     * @param message The message to display
     */
    private void showTemporaryMessage(String message) {
        if (statusText == null || isClosing.get()) {
            return;
        }
        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }

        statusText.setText(message);
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));

        revertToWavesRunnable = new Runnable() {
            @Override
            public void run() {
                if (isClosing.get() || statusText == null
                        || equalizerManager == null) {
                    return;
                }
                if (equalizerManager.isEnabled() && hasAudioSession()) {
                    statusText.setText("ENJOY THE WAVES");
                } else if (hasAudioSession()) {
                    statusText.setText("Equalizer: Disabled");
                }
                statusText.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
            }
        };
        mainHandler.postDelayed(
            revertToWavesRunnable, STATUS_MESSAGE_DURATION_MS);
    }

    /**
     * Shows the persistent disabled message and cancels any pending
     * revert.
     */
    private void showPersistentDisabledMessage() {
        if (statusText == null || isClosing.get()) {
            return;
        }
        if (revertToWavesRunnable != null) {
            mainHandler.removeCallbacks(revertToWavesRunnable);
        }
        statusText.setText("Equalizer: Disabled");
        statusText.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display, matching the status and navigation bar colors to the
     * app background.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches press animations to every button,
     * initializes the initial button labels and control values, and
     * applies the initial disabled state.
     *
     * <p>The per-band controls are not created here: they are
     * created when the equalizer first reports itself ready, so a
     * device that reports no bands leaves the band container
     * empty.</p>
     */
    private void initializeViews() {
        bandsContainer =
            (LinearLayout) findViewById(R.id.bandsContainer);
        bandsWrapper = (LinearLayout) findViewById(R.id.bandsWrapper);
        presetButton = (Button) findViewById(R.id.presetButton);
        bassBoostSeekBar = (SeekBar) findViewById(R.id.bassBoostSeekBar);
        surroundSeekBar = (SeekBar) findViewById(R.id.surroundSeekBar);
        pitchSeekBar = (SeekBar) findViewById(R.id.pitchSeekBar);
        speedSeekBar = (SeekBar) findViewById(R.id.speedSeekBar);
        bassBoostValueText =
            (TextView) findViewById(R.id.bassBoostValueText);
        surroundValueText =
            (TextView) findViewById(R.id.surroundValueText);
        pitchValueText = (TextView) findViewById(R.id.pitchValueText);
        speedValueText = (TextView) findViewById(R.id.speedValueText);
        resetButton = (Button) findViewById(R.id.resetButton);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        enableButton = (Button) findViewById(R.id.enableButton);
        statusText = (TextView) findViewById(R.id.statusText);

        animateButton(presetButton);
        animateButton(resetButton);
        animateButton(cancelButton);
        animateButton(enableButton);

        initializePresetButtonText();
        initializeResetButtonState();
        initializeEffectControls();

        updateUIState(false);
    }

    /**
     * Sets the preset button's initial label from the persisted
     * preset when an audio session is available, or to
     * {@code "Disabled"} otherwise.
     */
    private void initializePresetButtonText() {
        if (hasAudioSession() && equalizerManager != null) {
            int currentPreset = equalizerManager.getCurrentPreset();
            if (presetButton != null) {
                presetButton.setText(
                    equalizerManager.getPresetName(currentPreset));
            }
        } else {
            if (presetButton != null) {
                presetButton.setText("Disabled");
            }
        }
    }

    /**
     * Applies the initial enabled state to the reset button from the
     * presence of an audio session.
     */
    private void initializeResetButtonState() {
        if (resetButton != null) {
            boolean hasAudio = hasAudioSession();
            resetButton.setEnabled(hasAudio);
            themeHelper.updateButton(resetButton, hasAudio);
        }
    }

    /**
     * Reads the persisted effect values and applies them to the
     * SeekBars and value labels.
     *
     * <p>Each effect is populated independently, so a device that
     * does not support bass boost or surround shows the disabled
     * state on that control while the others remain populated.</p>
     */
    private void initializeEffectControls() {
        if (equalizerManager == null) {
            return;
        }

        if (equalizerManager.isBassBoostSupported()) {
            bassBoostSeekBar.setMax(SEEKBAR_MAX_BOOST);
            bassBoostSeekBar.setProgress(
                equalizerManager.getBassBoost());
            updateBassBoostValue(equalizerManager.getBassBoost());
        } else {
            bassBoostSeekBar.setEnabled(false);
            if (bassBoostValueText != null) {
                bassBoostValueText.setText("OFF");
            }
        }

        if (equalizerManager.isSurroundSupported()) {
            surroundSeekBar.setMax(SEEKBAR_MAX_BOOST);
            surroundSeekBar.setProgress(
                equalizerManager.getSurround());
            updateSurroundValue(equalizerManager.getSurround());
        } else {
            surroundSeekBar.setEnabled(false);
            if (surroundValueText != null) {
                surroundValueText.setText("OFF");
            }
        }

        pitchSeekBar.setMax(SEEKBAR_MAX);
        pitchSeekBar.setProgress(equalizerManager.getPitch());
        updatePitchValue(equalizerManager.getPitch());

        speedSeekBar.setMax(SEEKBAR_MAX);
        speedSeekBar.setProgress(equalizerManager.getSpeed());
        updateSpeedValue(equalizerManager.getSpeed());
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Reapplies the header text color to every header TextView in
     * the activity hierarchy.
     */
    private void themeAllHeaders() {
        if (isClosing.get()) {
            return;
        }
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof android.view.ViewGroup) {
            themeHeadersRecursive(
                (android.view.ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews in
     * the given view hierarchy whose text names an effect or the
     * equalizer.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(
            android.view.ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof TextView
                    && !(child instanceof Button)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                if (text.equals("EQUALIZER")
                        || text.equals("BASS BOOST")
                        || text.equals("SURROUND")
                        || text.equals("PITCH")
                        || text.equals("SPEED")
                        || text.equals("ENJOY THE WAVES")) {
                    textView.setTextColor(
                        Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else if (child instanceof android.view.ViewGroup) {
                themeHeadersRecursive(
                    (android.view.ViewGroup) child);
            }
        }
    }

    /**
     * Applies the current theme color to every control in the
     * activity and updates the value label colors from each
     * SeekBar's enabled state.
     */
    private void applyThemeToUI() {
        if (isClosing.get() || themeHelper == null
                || themeManager == null) {
            return;
        }

        themeHelper.setThemeColor(themeManager.getCurrentColor());

        if (presetButton != null) {
            themeHelper.updateButton(
                presetButton, presetButton.isEnabled());
        }
        if (resetButton != null) {
            themeHelper.updateButton(
                resetButton, resetButton.isEnabled());
        }
        if (cancelButton != null) {
            themeHelper.updateButton(
                cancelButton, cancelButton.isEnabled());
        }
        if (enableButton != null) {
            themeHelper.updateButton(
                enableButton, enableButton.isEnabled());
        }

        if (bassBoostSeekBar != null) {
            themeHelper.updateSeekBar(
                bassBoostSeekBar, bassBoostSeekBar.isEnabled());
        }
        if (surroundSeekBar != null) {
            themeHelper.updateSeekBar(
                surroundSeekBar, surroundSeekBar.isEnabled());
        }
        if (pitchSeekBar != null) {
            themeHelper.updateSeekBar(
                pitchSeekBar, pitchSeekBar.isEnabled());
        }
        if (speedSeekBar != null) {
            themeHelper.updateSeekBar(
                speedSeekBar, speedSeekBar.isEnabled());
        }

        if (bandSeekBars != null) {
            for (SeekBar bandSeekBar : bandSeekBars) {
                if (bandSeekBar != null) {
                    themeHelper.updateSeekBar(
                        bandSeekBar, bandSeekBar.isEnabled());
                }
            }
        }

        updateValueTextWithSeekBar(
            bassBoostValueText, bassBoostSeekBar);
        updateValueTextWithSeekBar(
            surroundValueText, surroundSeekBar);
        updateValueTextWithSeekBar(pitchValueText, pitchSeekBar);
        updateValueTextWithSeekBar(speedValueText, speedSeekBar);

        if (statusText != null && equalizerManager != null) {
            if (equalizerManager.isEnabled() && hasAudioSession()) {
                statusText.setText("ENJOY THE WAVES");
            } else {
                statusText.setText("Equalizer: Disabled");
            }
            statusText.setTextColor(
                Color.parseColor(TEXT_COLOR_LIGHT));
        }

        if (bandValueTexts != null && equalizerManager != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null
                        && equalizerManager.isEnabled()
                        && hasAudioSession()) {
                    themeHelper.updateTextView(bandValueText, true);
                }
            }
        }
    }

    /**
     * Applies the theme color to the given value label from the
     * given SeekBar's enabled state.
     *
     * <p>An enabled SeekBar gives the label the accent color; a
     * disabled SeekBar gives the label the disabled color.</p>
     *
     * @param valueText The value label, or null
     * @param seekBar The SeekBar whose enabled state drives the
     *        label's color, or null
     */
    private void updateValueTextWithSeekBar(
            @Nullable TextView valueText,
            @Nullable SeekBar seekBar) {
        if (valueText != null && seekBar != null) {
            boolean enabled = seekBar.isEnabled();
            themeHelper.updateTextView(valueText, enabled);
            if (!enabled) {
                valueText.setTextColor(
                    Color.parseColor(COLOR_DISABLED));
            }
        }
    }

    // ============================================================================
    // Button Animation
    // ============================================================================

    /**
     * Attaches a scale-down-on-press animation to the given button
     * for touch feedback.
     *
     * <p>The animation runs on {@code ACTION_DOWN} and reverses on
     * {@code ACTION_UP} or {@code ACTION_CANCEL}. The touch listener
     * returns {@code false} so the button's own click handling is
     * unaffected.</p>
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null || isClosing.get()) {
            return;
        }
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // UI State Management
    // ============================================================================

    /**
     * Applies the current enabled state to every control.
     *
     * <p>Reads the presence of an audio session and the equalizer's
     * ready flag, then dispatches to one helper per control group.
     * The helpers set enabled states, button labels, and text
     * colors.</p>
     *
     * @param enabled True when the equalizer is enabled
     */
    private void updateUIState(boolean enabled) {
        if (isClosing.get()) {
            return;
        }

        boolean hasAudio = hasAudioSession();
        boolean canEnable = isEqualizerReady && hasAudio;
        int themeColor = themeHelper.getThemeColorInt();

        updatePresetButtonState(enabled, canEnable, hasAudio);
        updateResetButtonState(canEnable);
        updateBassBoostControlState(enabled, canEnable, themeColor);
        updateSurroundControlState(enabled, canEnable, themeColor);
        updatePitchControlState(canEnable, themeColor);
        updateSpeedControlState(canEnable, themeColor);
        updateBandControlsState(enabled, canEnable, themeColor);
        updateEnableButtonState(canEnable, enabled);
    }

    /**
     * Applies the current state to the preset button.
     *
     * @param enabled True when the equalizer is enabled
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param hasAudio True when an audio session is available
     */
    private void updatePresetButtonState(boolean enabled,
                                         boolean canEnable,
                                         boolean hasAudio) {
        if (presetButton == null) {
            return;
        }
        boolean shouldBeEnabled = enabled && canEnable;
        presetButton.setEnabled(shouldBeEnabled);
        themeHelper.updateButton(presetButton, shouldBeEnabled);
        if (!hasAudio) {
            presetButton.setText("Disabled");
        } else if (equalizerManager != null) {
            presetButton.setText(equalizerManager.getPresetName(
                equalizerManager.getCurrentPreset()));
        }
    }

    /**
     * Applies the current state to the reset button.
     *
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     */
    private void updateResetButtonState(boolean canEnable) {
        if (resetButton == null) {
            return;
        }
        resetButton.setEnabled(canEnable);
        themeHelper.updateButton(resetButton, canEnable);
    }

    /**
     * Applies the current state to the bass boost SeekBar and its
     * value label.
     *
     * @param enabled True when the equalizer is enabled
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param themeColor The current theme color
     */
    private void updateBassBoostControlState(boolean enabled,
                                             boolean canEnable,
                                             int themeColor) {
        if (bassBoostSeekBar == null || equalizerManager == null) {
            return;
        }
        boolean boosterEnabled = enabled && canEnable
            && equalizerManager.isBassBoostSupported();
        bassBoostSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(bassBoostSeekBar, boosterEnabled);
        if (bassBoostValueText != null) {
            bassBoostValueText.setTextColor(boosterEnabled
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    /**
     * Applies the current state to the surround SeekBar and its
     * value label.
     *
     * @param enabled True when the equalizer is enabled
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param themeColor The current theme color
     */
    private void updateSurroundControlState(boolean enabled,
                                            boolean canEnable,
                                            int themeColor) {
        if (surroundSeekBar == null || equalizerManager == null) {
            return;
        }
        boolean boosterEnabled = enabled && canEnable
            && equalizerManager.isSurroundSupported();
        surroundSeekBar.setEnabled(boosterEnabled);
        themeHelper.updateSeekBar(surroundSeekBar, boosterEnabled);
        if (surroundValueText != null) {
            surroundValueText.setTextColor(boosterEnabled
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    /**
     * Applies the current state to the pitch SeekBar and its value
     * label.
     *
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param themeColor The current theme color
     */
    private void updatePitchControlState(boolean canEnable,
                                         int themeColor) {
        if (pitchSeekBar == null) {
            return;
        }
        pitchSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(pitchSeekBar, canEnable);
        if (pitchValueText != null) {
            pitchValueText.setTextColor(canEnable
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    /**
     * Applies the current state to the speed SeekBar and its value
     * label.
     *
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param themeColor The current theme color
     */
    private void updateSpeedControlState(boolean canEnable,
                                         int themeColor) {
        if (speedSeekBar == null) {
            return;
        }
        speedSeekBar.setEnabled(canEnable);
        themeHelper.updateSeekBar(speedSeekBar, canEnable);
        if (speedValueText != null) {
            speedValueText.setTextColor(canEnable
                ? themeColor : Color.parseColor(COLOR_DISABLED));
        }
    }

    /**
     * Applies the current state to every band SeekBar and its value
     * label.
     *
     * @param enabled True when the equalizer is enabled
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param themeColor The current theme color
     */
    private void updateBandControlsState(boolean enabled,
                                         boolean canEnable,
                                         int themeColor) {
        if (bandSeekBars == null || equalizerManager == null) {
            return;
        }
        for (SeekBar bandSeekBar : bandSeekBars) {
            if (bandSeekBar != null) {
                bandSeekBar.setEnabled(enabled && canEnable);
                themeHelper.updateSeekBar(
                    bandSeekBar, enabled && canEnable);
            }
        }
        if (bandValueTexts != null) {
            for (TextView bandValueText : bandValueTexts) {
                if (bandValueText != null) {
                    bandValueText.setTextColor((enabled && canEnable)
                        ? themeColor
                        : Color.parseColor(COLOR_DISABLED));
                }
            }
        }
    }

    /**
     * Applies the current state to the enable/disable button.
     *
     * @param canEnable True when the equalizer is ready and an audio
     *        session is available
     * @param enabled True when the equalizer is enabled
     */
    private void updateEnableButtonState(boolean canEnable,
                                         boolean enabled) {
        if (enableButton == null) {
            return;
        }
        enableButton.setEnabled(canEnable);
        if (canEnable) {
            enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        } else {
            enableButton.setText("ENABLE");
        }
        themeHelper.updateButton(enableButton, canEnable);
    }

    // ============================================================================
    // Band Control Methods
    // ============================================================================

    /**
     * Shows the preset dialog when the equalizer is operational.
     *
     * <p>Refused when the equalizer is not operational; a short
     * toast asks the user to enable the equalizer first. The dialog
     * reports a selection through
     * {@link PresetDialog.OnPresetSelectedListener}; the activity
     * applies the selected preset through
     * {@link EqualizerManager#applyPreset(int)}.</p>
     */
    private void showPresetDialog() {
        if (isClosing.get()) {
            return;
        }
        if (!isEqualizerOperational()) {
            ToastManager.showToast(this, "Enable equalizer first",
                ToastManager.LENGTH_SHORT);
            return;
        }
        if (equalizerManager == null) {
            return;
        }

        String[] presetNames = equalizerManager.getPresetNames();
        int currentPreset = equalizerManager.getCurrentPreset();

        PresetDialog dialog = new PresetDialog(this, presetNames,
            currentPreset, new PresetDialog.OnPresetSelectedListener() {
                @Override
                public void onPresetSelected(int presetIndex,
                                             String presetName) {
                    if (!isClosing.get()
                            && isEqualizerOperational()
                            && equalizerManager != null) {
                        equalizerManager.applyPreset(presetIndex);
                    }
                }
            });

        dialog.setOnDismissListener(
            new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dismissedDialog) {
                isPresetDialogShowing = false;
            }
        });
        dialog.show();
    }

    /**
     * Builds one control per equalizer band into
     * {@link #bandsContainer}.
     *
     * <p>Removes any existing band controls first, so a second call
     * after a device reconfiguration rebuilds cleanly. The band
     * count is read from {@link EqualizerManager}; a device that
     * reports zero bands leaves the container empty.</p>
     */
    private void createBandControls() {
        if (bandsContainer == null || isClosing.get()
                || equalizerManager == null) {
            return;
        }
        bandsContainer.removeAllViews();
        final short numberOfBands =
            equalizerManager.getNumberOfBands();
        if (numberOfBands == 0) {
            return;
        }

        bandSeekBars = new SeekBar[numberOfBands];
        bandValueTexts = new TextView[numberOfBands];
        final int minLevel = equalizerManager.getMinBandLevel();
        final int maxLevel = equalizerManager.getMaxBandLevel();
        final int seekBarWidth = maxLevel - minLevel;
        final int themeColor = themeHelper.getThemeColorInt();

        for (int bandIndex = 0; bandIndex < numberOfBands;
                bandIndex++) {
            createSingleBandControl(
                bandIndex, minLevel, maxLevel, seekBarWidth, themeColor);
        }
    }

    /**
     * Builds a single band's control: a frequency label, a value
     * label, and a SeekBar whose progress is the band's level offset
     * by the minimum.
     *
     * <p>The SeekBar's listener snaps the progress to
     * {@link #EQ_BAND_UNITS_PER_STEP} units, writes the level to
     * {@link EqualizerManager}, and updates the value label. The
     * snap is guarded by {@link #isEqRounding} so a programmatic
     * re-set does not re-enter the listener.</p>
     *
     * @param bandIndex Index of the band
     * @param minLevel Minimum band level in millibels
     * @param maxLevel Maximum band level in millibels
     * @param seekBarWidth Width of the SeekBar range, in millibels
     * @param themeColor Current theme color
     */
    private void createSingleBandControl(final int bandIndex,
                                         final int minLevel,
                                         final int maxLevel,
                                         final int seekBarWidth,
                                         final int themeColor) {
        int frequency = equalizerManager.getCenterFrequency(bandIndex);
        String frequencyText =
            equalizerManager.getFrequencyLabel(frequency);
        final int currentLevel =
            equalizerManager.getBandLevel(bandIndex);

        LinearLayout bandContainer = new LinearLayout(this);
        bandContainer.setOrientation(LinearLayout.VERTICAL);
        bandContainer.setPadding(0, 4, 0, 4);
        bandContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView frequencyLabel = new TextView(this);
        frequencyLabel.setText(frequencyText);
        frequencyLabel.setTextColor(
            Color.parseColor(TEXT_COLOR_LIGHT));
        frequencyLabel.setTextSize(12);
        frequencyLabel.setPadding(0, 8, 0, 0);
        frequencyLabel.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        final TextView levelText = new TextView(this);
        levelText.setText(formatLevel(currentLevel));
        levelText.setTextColor(themeColor);
        levelText.setTextSize(12);
        levelText.setPadding(0, 8, 0, 0);

        topRow.addView(frequencyLabel);
        topRow.addView(levelText);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(seekBarWidth);

        int initialProgress = currentLevel - minLevel;
        int roundedInitial = Math.round(initialProgress
            / (float) EQ_BAND_UNITS_PER_STEP)
            * EQ_BAND_UNITS_PER_STEP;
        roundedInitial = Math.max(0,
            Math.min(seekBarWidth, roundedInitial));
        seekBar.setProgress(roundedInitial);

        seekBar.setThumb(null);
        seekBar.setEnabled(
            equalizerManager.isEnabled() && hasAudioSession());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressDrawable(getResources()
                .getDrawable(R.drawable.seekbar_progress, null));
        } else {
            seekBar.setProgressDrawable(ContextCompat.getDrawable(
                this, R.drawable.seekbar_progress));
        }
        themeHelper.updateSeekBar(seekBar, seekBar.isEnabled());

        LinearLayout.LayoutParams seekParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = 8;
        seekParams.bottomMargin = 8;
        seekBar.setLayoutParams(seekParams);

        bandContainer.addView(topRow);
        bandContainer.addView(seekBar);
        bandsContainer.addView(bandContainer);

        bandSeekBars[bandIndex] = seekBar;
        bandValueTexts[bandIndex] = levelText;

        final int min = minLevel;

        seekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isEqRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) EQ_BAND_UNITS_PER_STEP)
                        * EQ_BAND_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(seekBarWidth, rounded));

                    if (rounded != progress) {
                        isEqRounding = true;
                        seekBar.setProgress(rounded);
                        int level = min + rounded;
                        equalizerManager.setBandLevel(
                            bandIndex, level);
                        levelText.setText(formatLevel(level));
                        isEqRounding = false;
                    } else {
                        int level = min + progress;
                        equalizerManager.setBandLevel(
                            bandIndex, level);
                        levelText.setText(formatLevel(level));
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isEqRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     * Refreshes every band SeekBar and value label from the current
     * equalizer levels.
     *
     * <p>Refused when the equalizer is not attached, since the
     * levels it reads would be stale. The progress is offset by the
     * device's minimum band level so the SeekBar's zero is the
     * lowest level the device supports.</p>
     */
    private void updateBandControlsFromLevels() {
        if (isClosing.get()
                || bandSeekBars == null
                || equalizerManager == null
                || !equalizerManager.isAttached()) {
            return;
        }
        final int minLevel = equalizerManager.getMinBandLevel();
        final int themeColor = themeHelper.getThemeColorInt();
        for (int bandIndex = 0;
                bandIndex < bandSeekBars.length
                    && bandIndex
                        < equalizerManager.getNumberOfBands();
                bandIndex++) {
            final int level =
                equalizerManager.getBandLevel(bandIndex);
            if (bandSeekBars[bandIndex] != null) {
                int progress = level - minLevel;
                int rounded = Math.round(progress
                    / (float) EQ_BAND_UNITS_PER_STEP)
                    * EQ_BAND_UNITS_PER_STEP;
                rounded = Math.max(0,
                    Math.min(bandSeekBars[bandIndex].getMax(),
                        rounded));
                bandSeekBars[bandIndex].setProgress(rounded);
            }
            if (bandValueTexts[bandIndex] != null) {
                bandValueTexts[bandIndex].setText(
                    formatLevel(level));
                if (equalizerManager.isEnabled()
                        && hasAudioSession()) {
                    bandValueTexts[bandIndex].setTextColor(
                        themeColor);
                }
            }
        }
    }

    /**
     * Formats a band level in millibels as a signed decibel string
     * with one decimal place.
     *
     * @param level Band level in millibels
     * @return The formatted string, such as {@code "+3.0 dB"} or
     *         {@code "0.0 dB"}
     */
    private String formatLevel(int level) {
        int rounded = Math.round(level
            / (float) EQ_BAND_UNITS_PER_STEP)
            * EQ_BAND_UNITS_PER_STEP;

        float decibels = rounded / 100.0f;
        if (decibels > 0) {
            return String.format("+%.1f dB", decibels);
        } else if (decibels < 0) {
            return String.format("%.1f dB", decibels);
        } else {
            return "0.0 dB";
        }
    }

    // ============================================================================
    // Effect Value Update Methods
    // ============================================================================

    /**
     * Updates the bass boost value label from the given strength.
     *
     * @param value Bass boost strength on the SeekBar's scale
     */
    private void updateBassBoostValue(int value) {
        if (!isClosing.get() && bassBoostValueText != null) {
            bassBoostValueText.setText(
                ((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }

    /**
     * Updates the surround value label from the given strength.
     *
     * @param value Surround strength on the SeekBar's scale
     */
    private void updateSurroundValue(int value) {
        if (!isClosing.get() && surroundValueText != null) {
            surroundValueText.setText(
                ((value * 100) / SEEKBAR_MAX_BOOST) + "%");
        }
    }

    /**
     * Updates the pitch value label from the given level.
     *
     * <p>The level is converted to semitones relative to the neutral
     * position and formatted with a leading sign for positive
     * values.</p>
     *
     * @param value Pitch level on the SeekBar's scale
     */
    private void updatePitchValue(int value) {
        if (!isClosing.get() && pitchValueText != null) {
            float semitones =
                (value - PITCH_DEFAULT) / (1000.0f / 6.0f);
            if (Math.abs(semitones) < 0.05f) {
                pitchValueText.setText("0.0 st");
            } else if (semitones > 0) {
                pitchValueText.setText(
                    String.format("+%.1f st", semitones));
            } else {
                pitchValueText.setText(
                    String.format("%.1f st", semitones));
            }
        }
    }

    /**
     * Updates the speed value label from the given level.
     *
     * <p>The level is converted to a multiple where 0.5 is the
     * SeekBar's minimum, 1.0 is the neutral position, and 1.5 is the
     * SeekBar's maximum.</p>
     *
     * @param value Speed level on the SeekBar's scale
     */
    private void updateSpeedValue(int value) {
        if (!isClosing.get() && speedValueText != null) {
            float speed = 0.5f + (value / 2000.0f);
            speedValueText.setText(
                String.format("%.2fx", speed));
        }
    }

    /**
     * Refreshes every effect value label from the current manager
     * state.
     */
    private void updateAllEffectValues() {
        if (isClosing.get() || equalizerManager == null) {
            return;
        }
        updateBassBoostValue(equalizerManager.getBassBoost());
        updateSurroundValue(equalizerManager.getSurround());
        updatePitchValue(equalizerManager.getPitch());
        updateSpeedValue(equalizerManager.getSpeed());
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Refreshes every control and shows a transition message.
     *
     * @see #updateUI(boolean)
     */
    private void updateUI() {
        updateUI(true);
    }

    /**
     * Refreshes every control from the current equalizer state.
     *
     * <p>Updates the enable button's label, applies the current
     * enabled state through {@link #updateUIState(boolean)},
     * refreshes the effect values, applies the theme, and updates
     * the status line. When the equalizer is enabled and an audio
     * session is available, either shows a transient transition
     * message or sets the status to its resting value depending on
     * {@code showTransitionMessage}; otherwise shows the persistent
     * disabled message.</p>
     *
     * @param showTransitionMessage True to flash a transition
     *        message when the equalizer is enabled
     */
    private void updateUI(boolean showTransitionMessage) {
        if (isClosing.get() || equalizerManager == null) {
            return;
        }
        boolean enabled = equalizerManager.isEnabled();
        if (enableButton != null) {
            enableButton.setText(enabled ? "DISABLE" : "ENABLE");
        }
        updateUIState(enabled);
        updateAllEffectValues();
        applyThemeToUI();
        if (statusText != null && isEqualizerReady
                && hasAudioSession()) {
            if (enabled) {
                if (revertToWavesRunnable != null) {
                    mainHandler.removeCallbacks(
                        revertToWavesRunnable);
                }
                if (showTransitionMessage) {
                    showTemporaryMessage("Equalizer: Enabled");
                } else {
                    statusText.setText("ENJOY THE WAVES");
                    statusText.setTextColor(
                        Color.parseColor(TEXT_COLOR_LIGHT));
                }
            } else {
                showPersistentDisabledMessage();
            }
        }
    }

    /**
     * Broadcasts a playback-parameter update request to
     * {@link MusicService}.
     *
     * <p>Sent after a pitch or speed change while the service is
     * playing, so the change reaches the audio pipeline without
     * waiting for the next playback state save.</p>
     */
    private void notifyPlaybackParamsChanged() {
        if (isClosing.get()) {
            return;
        }
        Intent intent = new Intent(ACTION_UPDATE_PLAYBACK_PARAMS);
        sendBroadcast(intent);
        Log.d(TAG,
            "Notified MusicService of playback param changes");
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every click and SeekBar listener used by the
     * activity.
     */
    private void setupListeners() {
        setupPresetButtonListener();
        setupBassBoostListener();
        setupSurroundListener();
        setupPitchListener();
        setupSpeedListener();
        setupResetButtonListener();
        setupEnableButtonListener();
        setupCancelButtonListener();
    }

    /**
     * Attaches the debounced click listener to the preset button.
     *
     * <p>Refuses a second click inside
     * {@link #PRESET_DEBOUNCE_DELAY_MS} milliseconds, and refuses a
     * click while the preset dialog is already showing.</p>
     */
    private void setupPresetButtonListener() {
        if (presetButton == null) {
            return;
        }
        presetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClosing.get() || isPresetDialogShowing) {
                    return;
                }
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastPresetClickTime
                        < PRESET_DEBOUNCE_DELAY_MS) {
                    return;
                }
                lastPresetClickTime = currentTime;
                isPresetDialogShowing = true;
                showPresetDialog();
            }
        });
    }

    /**
     * Attaches the bass boost SeekBar listener.
     *
     * <p>The listener snaps the progress to
     * {@link #BOOST_UNITS_PER_PERCENT} units, writes the strength to
     * {@link EqualizerManager}, and updates the value label. The
     * snap is guarded by {@link #isBassRounding} so a programmatic
     * re-set does not re-enter the listener.</p>
     */
    private void setupBassBoostListener() {
        if (bassBoostSeekBar == null) {
            return;
        }

        bassBoostSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isBassRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) BOOST_UNITS_PER_PERCENT)
                        * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX_BOOST, rounded));

                    if (rounded != progress) {
                        isBassRounding = true;
                        bassBoostSeekBar.setProgress(rounded);
                        equalizerManager.setBassBoost(rounded);
                        updateBassBoostValue(rounded);
                        isBassRounding = false;
                    } else {
                        equalizerManager.setBassBoost(progress);
                        updateBassBoostValue(progress);
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isBassRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     * Attaches the surround SeekBar listener.
     *
     * <p>Symmetric to {@link #setupBassBoostListener()} and guarded
     * by {@link #isSurroundRounding}.</p>
     */
    private void setupSurroundListener() {
        if (surroundSeekBar == null) {
            return;
        }

        surroundSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && isEqualizerOperational()
                        && equalizerManager != null) {
                    if (isSurroundRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) BOOST_UNITS_PER_PERCENT)
                        * BOOST_UNITS_PER_PERCENT;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX_BOOST, rounded));

                    if (rounded != progress) {
                        isSurroundRounding = true;
                        surroundSeekBar.setProgress(rounded);
                        equalizerManager.setSurround(rounded);
                        updateSurroundValue(rounded);
                        isSurroundRounding = false;
                    } else {
                        equalizerManager.setSurround(progress);
                        updateSurroundValue(progress);
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSurroundRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     * Attaches the pitch SeekBar listener.
     *
     * <p>Snaps the progress to {@link #PITCH_UNITS_PER_STEP} units,
     * writes the level to {@link EqualizerManager}, and refreshes
     * the value label. Sends a playback-parameter update to the
     * service when the service is bound and playing. The snap is
     * guarded by {@link #isPitchRounding}.</p>
     */
    private void setupPitchListener() {
        if (pitchSeekBar == null) {
            return;
        }

        pitchSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && equalizerManager != null) {
                    if (isPitchRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) PITCH_UNITS_PER_STEP)
                        * PITCH_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX, rounded));

                    if (rounded != progress) {
                        isPitchRounding = true;
                        pitchSeekBar.setProgress(rounded);
                        equalizerManager.setPitch(rounded);
                        updatePitchValue(rounded);
                        isPitchRounding = false;

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setPitch(progress);
                        updatePitchValue(progress);

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isPitchRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     * Attaches the speed SeekBar listener.
     *
     * <p>Snaps the progress to {@link #SPEED_UNITS_PER_STEP} units,
     * writes the level to {@link EqualizerManager}, and refreshes
     * the value label. Sends a playback-parameter update to the
     * service when the service is bound and playing. The snap is
     * guarded by {@link #isSpeedRounding}.</p>
     */
    private void setupSpeedListener() {
        if (speedSeekBar == null) {
            return;
        }

        speedSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar,
                                          int progress,
                                          boolean fromUser) {
                if (!isClosing.get() && fromUser
                        && equalizerManager != null) {
                    if (isSpeedRounding) {
                        return;
                    }

                    int rounded = Math.round(progress
                        / (float) SPEED_UNITS_PER_STEP)
                        * SPEED_UNITS_PER_STEP;
                    rounded = Math.max(0,
                        Math.min(SEEKBAR_MAX, rounded));

                    if (rounded != progress) {
                        isSpeedRounding = true;
                        speedSeekBar.setProgress(rounded);
                        equalizerManager.setSpeed(rounded);
                        updateSpeedValue(rounded);
                        isSpeedRounding = false;

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    } else {
                        equalizerManager.setSpeed(progress);
                        updateSpeedValue(progress);

                        if (isBindingComplete && musicService != null
                                && musicService.isPlaying()) {
                            notifyPlaybackParamsChanged();
                        }
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSpeedRounding = false;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     * Attaches the reset button listener.
     *
     * <p>Resets every band to zero, resets bass boost, surround,
     * pitch, and speed to their factory defaults, applies the
     * Custom preset, and shows a confirmation toast. When nothing
     * was changed, shows a different toast instead.</p>
     */
    private void setupResetButtonListener() {
        if (resetButton == null) {
            return;
        }
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClosing.get() || equalizerManager == null) {
                    return;
                }

                boolean equalizerOperational =
                    isEqualizerOperational();
                boolean anythingChanged = false;

                if (equalizerOperational) {
                    short numberOfBands =
                        equalizerManager.getNumberOfBands();
                    for (short bandIndex = 0;
                            bandIndex < numberOfBands; bandIndex++) {
                        if (equalizerManager.getBandLevel(bandIndex)
                                != 0) {
                            equalizerManager.setBandLevel(
                                bandIndex, 0);
                            anythingChanged = true;
                        }
                    }
                    if (anythingChanged) {
                        equalizerManager.clearCustomBandLevels();
                    }
                }

                if (equalizerOperational
                        && equalizerManager.isBassBoostSupported()) {
                    int currentBass = equalizerManager.getBassBoost();
                    if (currentBass != 0) {
                        equalizerManager.setBassBoost(0);
                        if (bassBoostSeekBar != null) {
                            bassBoostSeekBar.setProgress(0);
                        }
                        updateBassBoostValue(0);
                        anythingChanged = true;
                    }
                }

                if (equalizerOperational
                        && equalizerManager.isSurroundSupported()) {
                    int currentSurround =
                        equalizerManager.getSurround();
                    if (currentSurround != 0) {
                        equalizerManager.setSurround(0);
                        if (surroundSeekBar != null) {
                            surroundSeekBar.setProgress(0);
                        }
                        updateSurroundValue(0);
                        anythingChanged = true;
                    }
                }

                int currentPitch = equalizerManager.getPitch();
                if (currentPitch != PITCH_DEFAULT) {
                    equalizerManager.setPitch(PITCH_DEFAULT);
                    if (pitchSeekBar != null) {
                        pitchSeekBar.setProgress(PITCH_DEFAULT);
                    }
                    updatePitchValue(PITCH_DEFAULT);
                    anythingChanged = true;
                }

                int currentSpeed = equalizerManager.getSpeed();
                if (currentSpeed != SPEED_DEFAULT) {
                    equalizerManager.setSpeed(SPEED_DEFAULT);
                    if (speedSeekBar != null) {
                        speedSeekBar.setProgress(SPEED_DEFAULT);
                    }
                    updateSpeedValue(SPEED_DEFAULT);
                    anythingChanged = true;
                }

                if (equalizerOperational && anythingChanged) {
                    equalizerManager.applyPreset(0);
                }

                updateBandControlsFromLevels();

                if (anythingChanged) {
                    if (isBindingComplete && musicService != null
                            && musicService.isPlaying()) {
                        notifyPlaybackParamsChanged();
                    }
                    ToastManager.showToast(EqualizerActivity.this,
                        "Reset to factory defaults",
                        ToastManager.LENGTH_SHORT);
                } else {
                    ToastManager.showToast(EqualizerActivity.this,
                        "Already at default settings",
                        ToastManager.LENGTH_SHORT);
                }
            }
        });
    }

    /**
     * Attaches the enable/disable button listener.
     *
     * <p>Toggles the equalizer's enabled state through
     * {@link EqualizerManager} and refreshes every control. Refused
     * when there is no audio session.</p>
     */
    private void setupEnableButtonListener() {
        if (enableButton == null) {
            return;
        }
        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isClosing.get()
                        && equalizerManager != null
                        && hasAudioSession()) {
                    boolean newState = !equalizerManager.isEnabled();
                    equalizerManager.setEnabled(newState);
                    updateUI();
                }
            }
        });
    }

    /**
     * Attaches the cancel button listener.
     *
     * <p>Blocks further touches and finishes the activity, so a
     * second tap during the exit transition cannot reach the
     * underlying controls.</p>
     */
    private void setupCancelButtonListener() {
        if (cancelButton == null) {
            return;
        }
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isClosing.get()) {
                    getWindow().setFlags(
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    finish();
                }
            }
        });
    }
}