// Song.java
package com.ark.llama;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a single audio file and its metadata.
 *
 * <p>A song carries a title, an artist, an album, a genre, an absolute
 * filesystem path, a duration, an optional document URI from the
 * Storage Access Framework, and a favorite flag. The path defaults to
 * the empty string when none is provided. Equality is by path.</p>
 *
 * <h3>Placeholders and the Current Language</h3>
 * <p>Any of the four metadata fields may be absent — the file may carry
 * no tag for the value, the tag may be unreadable, or the tag may hold
 * a recognised placeholder such as {@code "<unknown>"}. In those cases
 * the field is stored as null. The four metadata getters —
 * {@link #getTitle()}, {@link #getArtist()}, {@link #getAlbum()}, and
 * {@link #getGenre()} — resolve a null field, or a field that already
 * holds a placeholder from another locale, against the app's currently
 * selected language through {@link CharacterMapper}. A song whose
 * artist tag is absent is therefore displayed with the German
 * placeholder on a device whose app language is German, with the
 * Arabic placeholder on a device whose app language is Arabic, and
 * with the English placeholder on a device whose app language is
 * English — all from the same {@code Song} instance.</p>
 *
 * <p>The resolution happens on each getter call, not at construction.
 * A language change is reflected on every song the next time its
 * metadata is read; the song is not reconstructed. A stored value that
 * was written under a previous language — the German placeholder
 * cached in the database while the app was set to German, for example
 * — is recognised by {@link CharacterMapper}'s predicate for the
 * field's kind and replaced with the current language's value on the
 * next read.</p>
 *
 * <h3>Favorites</h3>
 * <p>The favorite flag is a per-song bit that the user can toggle. It
 * is persisted by {@link SongDatabase#setFavorite(String, boolean)}
 * and read back by {@link SongDatabase}'s row reader. The flag travels
 * with the song through the three-tier playlist maintained by
 * {@link MusicService} and is not clobbered by a metadata update or a
 * genre load, because {@link SongDatabase#updateSongMetadata(Song)}
 * does not touch the favorite column.</p>
 *
 * <h3>Serialization</h3>
 * <p>The class implements {@link Serializable} so a song can be passed
 * between activities and stored in persistent state. The raw field
 * values are what serialise; the placeholders the getters produce are
 * not part of the persisted form, and a deserialised song resolves its
 * placeholders against whatever language is selected in the process
 * that reads it. The favorite flag is part of the serialized form as
 * of version 2 of the class; older serialized forms deserialize with
 * the flag as {@code false}.</p>
 *
 * @see Serializable
 * @see CharacterMapper
 * @see SongDatabase
 *
 * @author Richard Korbla Adzido
 * @version 1.4.0
 * @since 1.0.0
 */
public class Song implements Serializable {

    // ============================================================================
    // Constants
    // ============================================================================

    /**
     * Serial version identifier.
     *
     * <p>Version 2 adds the {@link #mFavorite} field. The field's
     * default value on a version-1 stream is {@code false}, which is
     * the correct value for every song that existed before the flag
     * was introduced.</p>
     */
    private static final long serialVersionUID = 2L;

    /** Path stored when a song has no filesystem path. */
    private static final String DEFAULT_PATH = "";

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Raw title; null when the song carries no title. */
    @Nullable
    private String mTitle;

    /** Raw artist; null when the song carries no artist. */
    @Nullable
    private String mArtist;

    /** Raw album; null when the song carries no album. */
    @Nullable
    private String mAlbum;

    /** Raw genre; null when the song carries no genre. */
    @Nullable
    private String mGenre;

    /** Absolute filesystem path of the audio file; never null. */
    @NonNull
    private String mPath;

    /** Duration of the song in milliseconds, or 0 when unknown. */
    private long mDuration;

    /** Document URI from the Storage Access Framework, or null. */
    @Nullable
    private String mUri;

    /** True when the user has marked this song as a favorite. */
    private boolean mFavorite;

    // ============================================================================
    // Constructors
    // ============================================================================

    /**
     * Constructs a song without a genre or document URI.
     *
     * @param title Title, or null or empty when the song has no title
     * @param artist Artist, or null or empty when the song has no
     *        artist
     * @param album Album, or null or empty when the song has no album
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String path, long duration) {
        this(title, artist, album, null, path, duration, null);
    }

    /**
     * Constructs a song without a genre.
     *
     * @param title Title, or null or empty when the song has no title
     * @param artist Artist, or null or empty when the song has no
     *        artist
     * @param album Album, or null or empty when the song has no album
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     * @param uri Document URI, or null when none is available
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String path, long duration,
                @Nullable String uri) {
        this(title, artist, album, null, path, duration, uri);
    }

    /**
     * Constructs a song with the given metadata.
     *
     * <p>A null or empty metadata value is stored as null. The
     * corresponding getter resolves it against the app's currently
     * selected language at the moment it is called.</p>
     *
     * <p>The favorite flag starts {@code false}. A caller that knows
     * the flag — {@link SongDatabase}'s row reader, for example —
     * sets it through {@link #setFavorite(boolean)} after
     * construction.</p>
     *
     * @param title Title, or null or empty when the song has no title
     * @param artist Artist, or null or empty when the song has no
     *        artist
     * @param album Album, or null or empty when the song has no album
     * @param genre Genre, or null or empty when the song has no genre
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     * @param uri Document URI, or null when none is available
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String genre,
                @Nullable String path, long duration,
                @Nullable String uri) {
        this.mTitle = normalize(title);
        this.mArtist = normalize(artist);
        this.mAlbum = normalize(album);
        this.mGenre = normalize(genre);
        this.mPath = (path != null) ? path : DEFAULT_PATH;
        this.mDuration = duration;
        this.mUri = uri;
        this.mFavorite = false;
    }

    /**
     * Returns the given raw metadata value with an empty string
     * normalised to null.
     *
     * @param value Raw value, or null
     * @return The value, or null when it is null or empty
     */
    @Nullable
    private static String normalize(@Nullable String value) {
        return (value != null && !value.isEmpty()) ? value : null;
    }

    // ============================================================================
    // Getter Methods
    // ============================================================================

    /**
     * Returns the song title, or the current language's placeholder
     * when the song carries no title.
     *
     * @return The song title; never null
     */
    @NonNull
    public String getTitle() {
        final String title = mTitle;
        if (title == null || CharacterMapper.isUnknownTitle(title)) {
            return CharacterMapper.getUnknownTitle();
        }
        return title;
    }

    /**
     * Returns the artist name, or the current language's placeholder
     * when the song carries no artist.
     *
     * @return The artist name; never null
     */
    @NonNull
    public String getArtist() {
        final String artist = mArtist;
        if (artist == null || CharacterMapper.isUnknownArtist(artist)) {
            return CharacterMapper.getUnknownArtist();
        }
        return artist;
    }

    /**
     * Returns the album name, or the current language's placeholder
     * when the song carries no album.
     *
     * @return The album name; never null
     */
    @NonNull
    public String getAlbum() {
        final String album = mAlbum;
        if (album == null || CharacterMapper.isUnknownAlbum(album)) {
            return CharacterMapper.getUnknownAlbum();
        }
        return album;
    }

    /**
     * Returns the music genre, or the current language's placeholder
     * when the song carries no genre.
     *
     * @return The music genre; never null
     */
    @NonNull
    public String getGenre() {
        final String genre = mGenre;
        if (genre == null || CharacterMapper.isUnknownGenre(genre)) {
            return CharacterMapper.getUnknownGenre();
        }
        return genre;
    }

    /**
     * Returns the absolute filesystem path of the audio file.
     *
     * @return The file path; never null
     */
    @NonNull
    public String getPath() {
        return mPath;
    }

    /**
     * Returns the duration of the song.
     *
     * @return Duration in milliseconds, or 0 when unknown
     */
    public long getDuration() {
        return mDuration;
    }

    /**
     * Returns the document URI as a string.
     *
     * @return The URI string, or null when none is available
     */
    @Nullable
    public String getUri() {
        return mUri;
    }

    /**
     * Returns the document URI as a {@link Uri} object.
     *
     * @return The URI, or null when none is available
     */
    @Nullable
    public Uri getContentUri() {
        return mUri != null ? Uri.parse(mUri) : null;
    }

    /**
     * Returns whether the user has marked this song as a favorite.
     *
     * @return True when the song is a favorite
     */
    public boolean isFavorite() {
        return mFavorite;
    }

    // ============================================================================
    // Setter Methods
    // ============================================================================

    /**
     * Sets the song title.
     *
     * @param title New title, or null or empty when the song has no
     *        title
     */
    public void setTitle(@Nullable String title) {
        this.mTitle = normalize(title);
    }

    /**
     * Sets the artist name.
     *
     * @param artist New artist name, or null or empty when the song
     *        has no artist
     */
    public void setArtist(@Nullable String artist) {
        this.mArtist = normalize(artist);
    }

    /**
     * Sets the album name.
     *
     * @param album New album name, or null or empty when the song has
     *        no album
     */
    public void setAlbum(@Nullable String album) {
        this.mAlbum = normalize(album);
    }

    /**
     * Sets the music genre.
     *
     * @param genre New genre, or null or empty when the song has no
     *        genre
     */
    public void setGenre(@Nullable String genre) {
        this.mGenre = normalize(genre);
    }

    /**
     * Sets the filesystem path.
     *
     * @param path New path, or null to use the default
     */
    public void setPath(@Nullable String path) {
        this.mPath = (path != null) ? path : DEFAULT_PATH;
    }

    /**
     * Sets the duration of the song.
     *
     * @param duration New duration in milliseconds
     */
    public void setDuration(long duration) {
        this.mDuration = duration;
    }

    /**
     * Sets the document URI.
     *
     * @param uri New URI string, or null to clear
     */
    public void setUri(@Nullable String uri) {
        this.mUri = uri;
    }

    /**
     * Sets the favorite flag.
     *
     * @param favorite New value
     */
    public void setFavorite(boolean favorite) {
        this.mFavorite = favorite;
    }

    // ============================================================================
    // Object Methods
    // ============================================================================

    /**
     * Returns whether this song has the same path as the given object.
     *
     * <p>The path uniquely identifies a song within the filesystem, so
     * two songs are equal when their paths match. The favorite flag is
     * not part of equality: marking a song as favorite must not make
     * a list lookup against the same path fail.</p>
     *
     * @param object Object to compare against, or null
     * @return True when the given object is a song with the same path
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        Song song = (Song) object;
        return Objects.equals(mPath, song.mPath);
    }

    /**
     * Returns a hash code derived from the song's path.
     *
     * @return The hash code of the song's path
     */
    @Override
    public int hashCode() {
        return Objects.hash(mPath);
    }

    /**
     * Returns a debug representation of this song.
     *
     * @return A string containing every raw field's value
     */
    @NonNull
    @Override
    public String toString() {
        return "Song{" +
                "title='" + mTitle + '\'' +
                ", artist='" + mArtist + '\'' +
                ", album='" + mAlbum + '\'' +
                ", genre='" + mGenre + '\'' +
                ", path='" + mPath + '\'' +
                ", uri='" + mUri + '\'' +
                ", favorite=" + mFavorite +
                '}';
    }
}