package com.ark.llama;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.Objects;

/**
 * Data model representing an audio song with its metadata.
 * 
 * <p>This class encapsulates all information about a song including:</p>
 * <ul>
 *   <li><b>Title</b> - The name of the song</li>
 *   <li><b>Artist</b> - The performer of the song</li>
 *   <li><b>Album</b> - The album containing the song</li>
 *   <li><b>Genre</b> - The music genre of the song</li>
 *   <li><b>Path</b> - The file system path to the audio file</li>
 *   <li><b>Duration</b> - The length of the song in milliseconds</li>
 *   <li><b>Uri</b> - Document URI for scoped storage access (Android 10+)</li>
 * </ul>
 * 
 * <p>The class implements {@link Serializable} to allow Song objects to be
 * passed between activities and saved to persistent storage.</p>
 * 
 * <p>Equality is based solely on the file path, as each song has a unique
 * path in the file system.</p>
 * 
 * <p>All string fields are guaranteed to be non-null, with default values
 * provided for missing metadata.</p>
 * 
 * @see Serializable
 * @see CharacterMapper
 * @see SongDatabase
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class Song implements Serializable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Serial version UID for compatibility across versions. */
    private static final long serialVersionUID = 1L;
    
    /** Default title for songs with missing or empty title metadata. */
    private static final String DEFAULT_TITLE = "Unknown Title";
    
    /** Default artist for songs with missing or empty artist metadata. */
    private static final String DEFAULT_ARTIST = "Unknown Artist";
    
    /** Default album for songs with missing or empty album metadata. */
    private static final String DEFAULT_ALBUM = "Unknown Album";
    
    /** Default genre for songs with missing or empty genre metadata. */
    private static final String DEFAULT_GENRE = "Unknown Genre";
    
    /** Default path for invalid songs. */
    private static final String DEFAULT_PATH = "";
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The title of the song. Guaranteed never to be null. */
    @NonNull
    private String mTitle;
    
    /** The artist of the song. Guaranteed never to be null. */
    @NonNull
    private String mArtist;
    
    /** The album containing the song. Guaranteed never to be null. */
    @NonNull
    private String mAlbum;
    
    /** The genre of the song. Guaranteed never to be null. */
    @NonNull
    private String mGenre;
    
    /** The absolute file system path of the audio file. Guaranteed never to be null. */
    @NonNull
    private String mPath;
    
    /** The duration of the song in milliseconds. Zero if unknown or invalid. */
    private long mDuration;
    
    /** 
     * Document URI for scoped storage access (Android 10+). 
     * Used for metadata editing operations.
     */
    @Nullable
    private String mUri;
    
    // ========================================================================
    // Constructors
    // ========================================================================
    
    /**
     * Constructs a new Song with the specified metadata.
     *
     * @param title The song title (can be null or empty)
     * @param artist The artist name (can be null or empty)
     * @param album The album name (can be null or empty)
     * @param path The absolute file system path (can be null)
     * @param duration The duration in milliseconds (zero if unknown)
     */
    public Song(@Nullable String title, @Nullable String artist, 
                @Nullable String album, @Nullable String path, long duration) {
        this(title, artist, album, null, path, duration, null);
    }
    
    /**
     * Constructs a new Song with the specified metadata and document URI.
     *
     * @param title The song title (can be null or empty)
     * @param artist The artist name (can be null or empty)
     * @param album The album name (can be null or empty)
     * @param path The absolute file system path (can be null)
     * @param duration The duration in milliseconds (zero if unknown)
     * @param uri The document URI for scoped storage access (can be null)
     */
    public Song(@Nullable String title, @Nullable String artist, 
                @Nullable String album, @Nullable String path, long duration,
                @Nullable String uri) {
        this(title, artist, album, null, path, duration, uri);
    }
    
    /**
     * Constructs a new Song with the specified metadata including genre.
     *
     * @param title The song title (can be null or empty)
     * @param artist The artist name (can be null or empty)
     * @param album The album name (can be null or empty)
     * @param genre The music genre (can be null or empty)
     * @param path The absolute file system path (can be null)
     * @param duration The duration in milliseconds (zero if unknown)
     * @param uri The document URI for scoped storage access (can be null)
     */
    public Song(@Nullable String title, @Nullable String artist, 
                @Nullable String album, @Nullable String genre,
                @Nullable String path, long duration,
                @Nullable String uri) {
        this.mTitle = (title != null && !title.isEmpty()) ? title : DEFAULT_TITLE;
        this.mArtist = (artist != null && !artist.isEmpty()) ? artist : DEFAULT_ARTIST;
        this.mAlbum = (album != null && !album.isEmpty()) ? album : DEFAULT_ALBUM;
        this.mGenre = (genre != null && !genre.isEmpty()) ? genre : DEFAULT_GENRE;
        this.mPath = (path != null) ? path : DEFAULT_PATH;
        this.mDuration = duration;
        this.mUri = uri;
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the song title.
     *
     * @return The song title (never null)
     */
    @NonNull
    public String getTitle() {
        return mTitle;
    }
    
    /**
     * Returns the artist name.
     *
     * @return The artist name (never null)
     */
    @NonNull
    public String getArtist() {
        return mArtist;
    }
    
    /**
     * Returns the album name.
     *
     * @return The album name (never null)
     */
    @NonNull
    public String getAlbum() {
        return mAlbum;
    }
    
    /**
     * Returns the music genre.
     *
     * @return The music genre (never null)
     */
    @NonNull
    public String getGenre() {
        return mGenre;
    }
    
    /**
     * Returns the absolute file system path of the audio file.
     *
     * @return The file path (never null)
     */
    @NonNull
    public String getPath() {
        return mPath;
    }
    
    /**
     * Returns the duration of the song in milliseconds.
     *
     * @return Duration in milliseconds (zero if unknown)
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the document URI string for scoped storage access.
     *
     * @return The URI string, or null if not available
     */
    @Nullable
    public String getUri() {
        return mUri;
    }
    
    /**
     * Returns the document URI as a Uri object.
     *
     * @return The Uri object, or null if not available
     */
    @Nullable
    public Uri getContentUri() {
        return mUri != null ? Uri.parse(mUri) : null;
    }
    
    // ========================================================================
    // Setter Methods
    // ========================================================================
    
    /**
     * Sets the song title.
     *
     * @param title The new title (can be null)
     */
    public void setTitle(@Nullable String title) {
        this.mTitle = (title != null && !title.isEmpty()) ? title : DEFAULT_TITLE;
    }
    
    /**
     * Sets the artist name.
     *
     * @param artist The new artist name (can be null)
     */
    public void setArtist(@Nullable String artist) {
        this.mArtist = (artist != null && !artist.isEmpty()) ? artist : DEFAULT_ARTIST;
    }
    
    /**
     * Sets the album name.
     *
     * @param album The new album name (can be null)
     */
    public void setAlbum(@Nullable String album) {
        this.mAlbum = (album != null && !album.isEmpty()) ? album : DEFAULT_ALBUM;
    }
    
    /**
     * Sets the music genre.
     *
     * @param genre The new genre (can be null)
     */
    public void setGenre(@Nullable String genre) {
        this.mGenre = (genre != null && !genre.isEmpty()) ? genre : DEFAULT_GENRE;
    }
    
    /**
     * Sets the file system path.
     *
     * @param path The new file path (can be null)
     */
    public void setPath(@Nullable String path) {
        this.mPath = (path != null) ? path : DEFAULT_PATH;
    }
    
    /**
     * Sets the song duration.
     *
     * @param duration Duration in milliseconds
     */
    public void setDuration(long duration) {
        this.mDuration = duration;
    }
    
    /**
     * Sets the document URI for scoped storage access.
     *
     * @param uri The URI string (can be null)
     */
    public void setUri(@Nullable String uri) {
        this.mUri = uri;
    }
    
    // ========================================================================
    // Object Methods
    // ========================================================================
    
    /**
     * Compares this song to another object for equality.
     * 
     * <p>Two songs are considered equal if they have the same absolute file
     * system path.</p>
     *
     * @param object The object to compare with
     * @return True if the songs have the same file path
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }
        
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        
        Song song = (Song) object;
        return Objects.equals(mPath, song.mPath);
    }
    
    /**
     * Returns a hash code for this song.
     *
     * @return The hash code value
     */
    @Override
    public int hashCode() {
        return Objects.hash(mPath);
    }
    
    /**
     * Returns a string representation of the song.
     *
     * @return A string representation of the song
     */
    @NonNull
    @Override
    public String toString() {
        return "Song{" +
                "title='" + mTitle + '\'' +
                ", artist='" + mArtist + '\'' +
                ", album='" + mAlbum + '\'' +
                ", genre='" + mGenre + '\'' +
                ", path='" + mPath + '\'' +
                ", uri='" + mUri + '\'' +
                '}';
    }
}