package com.ark.llama;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a single audio file and its metadata.
 *
 * <p>A song carries a title, an artist, an album, a genre, an absolute
 * filesystem path, a duration, and optionally a document URI from the
 * Storage Access Framework. The title, artist, album, and genre fields
 * default to canonical placeholder values when the corresponding
 * metadata is missing, and the path defaults to the empty string when
 * none is provided. Equality is by path.</p>
 *
 * <p>The class implements {@link Serializable} so a song can be passed
 * between activities and stored in persistent state.</p>
 *
 * @see Serializable
 * @see CharacterMapper
 * @see SongDatabase
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class Song implements Serializable {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Serial version identifier. */
    private static final long serialVersionUID = 1L;

    /** Title used when a song has no title metadata. */
    private static final String DEFAULT_TITLE = "Unknown Title";

    /** Artist used when a song has no artist metadata. */
    private static final String DEFAULT_ARTIST = "Unknown Artist";

    /** Album used when a song has no album metadata. */
    private static final String DEFAULT_ALBUM = "Unknown Album";

    /** Genre used when a song has no genre metadata. */
    private static final String DEFAULT_GENRE = "Unknown Genre";

    /** Path used when a song has no filesystem path. */
    private static final String DEFAULT_PATH = "";

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Song title; never null. */
    @NonNull
    private String mTitle;

    /** Artist name; never null. */
    @NonNull
    private String mArtist;

    /** Album name; never null. */
    @NonNull
    private String mAlbum;

    /** Music genre; never null. */
    @NonNull
    private String mGenre;

    /** Absolute filesystem path of the audio file; never null. */
    @NonNull
    private String mPath;

    /** Duration of the song in milliseconds, or 0 when unknown. */
    private long mDuration;

    /** Document URI from the Storage Access Framework, or null. */
    @Nullable
    private String mUri;

    // ========================================================================
    // Constructors
    // ========================================================================

    /**
     * Constructs a song without a genre or document URI.
     *
     * @param title Title, or null or empty to use the default
     * @param artist Artist, or null or empty to use the default
     * @param album Album, or null or empty to use the default
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String path, long duration) {
        this(title, artist, album, null, path, duration, null);
    }

    /**
     * Constructs a song without a genre.
     *
     * @param title Title, or null or empty to use the default
     * @param artist Artist, or null or empty to use the default
     * @param album Album, or null or empty to use the default
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     * @param uri Document URI, or null when none is available
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String path, long duration,
                @Nullable String uri) {
        this(title, artist, album, null, path, duration, uri);
    }

    /**
     * Constructs a song with the given metadata.
     *
     * @param title Title, or null or empty to use the default
     * @param artist Artist, or null or empty to use the default
     * @param album Album, or null or empty to use the default
     * @param genre Genre, or null or empty to use the default
     * @param path Absolute filesystem path, or null to use the default
     * @param duration Duration in milliseconds, or 0 when unknown
     * @param uri Document URI, or null when none is available
     */
    public Song(@Nullable String title, @Nullable String artist,
                @Nullable String album, @Nullable String genre,
                @Nullable String path, long duration,
                @Nullable String uri) {
        this.mTitle = (title != null && !title.isEmpty()) ? title : DEFAULT_TITLE;
        this.mArtist = (artist != null && !artist.isEmpty()) ? artist : DEFAULT_ARTIST;
        this.mAlbum = (album != null && !album.isEmpty()) ? album : DEFAULT_ALBUM;
        this.mGenre = (genre != null && !genre.isEmpty()) ? genre : DEFAULT_GENRE;
        this.mPath = (path != null) ? path : DEFAULT_PATH;
        this.mDuration = duration;
        this.mUri = uri;
    }

    // ========================================================================
    // Getter Methods
    // ========================================================================

    /**
     * Returns the song title.
     *
     * @return The song title; never null
     */
    @NonNull
    public String getTitle() {
        return mTitle;
    }

    /**
     * Returns the artist name.
     *
     * @return The artist name; never null
     */
    @NonNull
    public String getArtist() {
        return mArtist;
    }

    /**
     * Returns the album name.
     *
     * @return The album name; never null
     */
    @NonNull
    public String getAlbum() {
        return mAlbum;
    }

    /**
     * Returns the music genre.
     *
     * @return The music genre; never null
     */
    @NonNull
    public String getGenre() {
        return mGenre;
    }

    /**
     * Returns the absolute filesystem path of the audio file.
     *
     * @return The file path; never null
     */
    @NonNull
    public String getPath() {
        return mPath;
    }

    /**
     * Returns the duration of the song.
     *
     * @return Duration in milliseconds, or 0 when unknown
     */
    public long getDuration() {
        return mDuration;
    }

    /**
     * Returns the document URI as a string.
     *
     * @return The URI string, or null when none is available
     */
    @Nullable
    public String getUri() {
        return mUri;
    }

    /**
     * Returns the document URI as a {@link Uri} object.
     *
     * @return The URI, or null when none is available
     */
    @Nullable
    public Uri getContentUri() {
        return mUri != null ? Uri.parse(mUri) : null;
    }

    // ========================================================================
    // Setter Methods
    // ========================================================================

    /**
     * Sets the song title.
     *
     * @param title New title, or null or empty to use the default
     */
    public void setTitle(@Nullable String title) {
        this.mTitle = (title != null && !title.isEmpty()) ? title : DEFAULT_TITLE;
    }

    /**
     * Sets the artist name.
     *
     * @param artist New artist name, or null or empty to use the default
     */
    public void setArtist(@Nullable String artist) {
        this.mArtist = (artist != null && !artist.isEmpty()) ? artist : DEFAULT_ARTIST;
    }

    /**
     * Sets the album name.
     *
     * @param album New album name, or null or empty to use the default
     */
    public void setAlbum(@Nullable String album) {
        this.mAlbum = (album != null && !album.isEmpty()) ? album : DEFAULT_ALBUM;
    }

    /**
     * Sets the music genre.
     *
     * @param genre New genre, or null or empty to use the default
     */
    public void setGenre(@Nullable String genre) {
        this.mGenre = (genre != null && !genre.isEmpty()) ? genre : DEFAULT_GENRE;
    }

    /**
     * Sets the filesystem path.
     *
     * @param path New path, or null to use the default
     */
    public void setPath(@Nullable String path) {
        this.mPath = (path != null) ? path : DEFAULT_PATH;
    }

    /**
     * Sets the duration of the song.
     *
     * @param duration New duration in milliseconds
     */
    public void setDuration(long duration) {
        this.mDuration = duration;
    }

    /**
     * Sets the document URI.
     *
     * @param uri New URI string, or null to clear
     */
    public void setUri(@Nullable String uri) {
        this.mUri = uri;
    }

    // ========================================================================
    // Object Methods
    // ========================================================================

    /**
     * Returns whether this song has the same path as the given object.
     *
     * <p>The path uniquely identifies a song within the filesystem, so
     * two songs are equal when their paths match.</p>
     *
     * @param object Object to compare against, or null
     * @return True when the given object is a song with the same path
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        Song song = (Song) object;
        return Objects.equals(mPath, song.mPath);
    }

    /**
     * Returns a hash code derived from the song's path.
     *
     * @return The hash code of the song's path
     */
    @Override
    public int hashCode() {
        return Objects.hash(mPath);
    }

    /**
     * Returns a debug representation of this song.
     *
     * @return A string containing every field's value
     */
    @NonNull
    @Override
    public String toString() {
        return "Song{" +
                "title='" + mTitle + '\'' +
                ", artist='" + mArtist + '\'' +
                ", album='" + mAlbum + '\'' +
                ", genre='" + mGenre + '\'' +
                ", path='" + mPath + '\'' +
                ", uri='" + mUri + '\'' +
                '}';
    }
}