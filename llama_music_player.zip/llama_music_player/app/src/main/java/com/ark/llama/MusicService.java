package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * MusicService - Background service for music playback.
 *
 * <p>This service provides the core music playback functionality for the
 * Llama Music Player application. It runs in the background to allow
 * continuous playback even when the app is not in the foreground.</p>
 *
 * <h3>Authoritative Playback State Machine</h3>
 * <p>Playback orchestration is owned by a single state machine. A
 * {@link ServiceState} enum, two monotonic counters ({@code mGeneration}
 * and {@code mStartToken}), and a two-index model ({@code mCurrentIndex} /
 * {@code mTargetIndex}) are the only holders of transition state. All
 * state mutations happen on the main thread. All raw {@link MediaPlayer}
 * calls run on a dedicated {@link HandlerThread}. Only marshalled
 * {@link Runnable}s cross between them.</p>
 *
 * <h3>Two-Index Model</h3>
 * <p>{@code mCurrentIndex} is the index the {@link MediaPlayer} is actually
 * bound to. {@code mTargetIndex} is the index the state machine is driving
 * toward. When {@code mState} is PREPARING, {@code mCurrentIndex} still
 * reflects the outgoing song and {@code mTargetIndex} is the destination.
 * Every request method mutates {@code mTargetIndex} only; only
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <p>{@link #getCurrentSong()} reports the song bound to
 * {@code mCurrentIndex}, never the target. During a transition the
 * activity, the notification, and the MediaSession metadata all continue
 * to describe the outgoing song until
 * {@link #onPlaybackStarted(long, int, Song, int)} commits PLAYING and
 * advances {@code mCurrentIndex} to the target.</p>
 *
 * <h3>Request Base Index</h3>
 * <p>{@link #playNextSong()} and {@link #playPreviousSong()} base their
 * computation on {@code mCurrentIndex}, not {@code mTargetIndex}, even
 * while a transition is in progress. A rapid sequence of NEXT presses
 * during a transition therefore all compute the same next index and
 * collapse to a single advance. The state machine already serializes the
 * requests through {@link #reconcile()}, which returns early while
 * {@code mState == PREPARING}.</p>
 *
 * <h3>Transport Action Debounce</h3>
 * <p>Notification button taps and hardware media keys arrive through the
 * active {@link MediaSessionCompat}'s callback. {@code onStartCommand}
 * intents that carry the same actions arrive on the cold-start path. Both
 * routes pass through {@link #isNotificationActionDebounced(String)}
 * before the request method runs. The window matches the activity's
 * {@code CLICK_DEBOUNCE_DELAY_MS}, so a tap on the notification and a tap
 * on the corresponding on-screen button are subject to the same rate
 * limit. The debounce is a rate limit, not a queue: presses inside the
 * window are dropped, presses outside it reach the state machine as
 * before.</p>
 *
 * <h3>Callback Identity</h3>
 * <p>Two monotonic counters identify continuations. {@link #mGeneration}
 * tags every transition started by {@link #beginTransition(int, int)} and
 * is captured by the {@link MediaPlayer} listeners installed on the player.
 * A callback whose captured generation differs from the current value is
 * inert. This makes concurrent preparations structurally impossible.</p>
 *
 * <p>{@link #mStartToken} tags start and resume continuations — the
 * start-on-prepared leg of a transition, {@link #doResume()}, and the
 * READY branch of {@link #togglePlayPause()}. Resuming a paused player is
 * not a song transition; {@code mGeneration} is left untouched on resume
 * so the {@code onCompletionListener} installed by the current transition
 * remains valid across a pause and resume.</p>
 *
 * <h3>Foreground Lifecycle</h3>
 * <p>The service is promoted to the foreground while playing and demoted
 * while paused. The promotion is driven by two paths:
 * {@link NotificationService#startForegroundSync()}, called from
 * {@link #onStartCommand} and from the two play-start continuations, and
 * {@link NotificationService}'s own state-based promotion inside
 * {@code performUpdateNotification}. Both paths call
 * {@code Service.startForeground} unconditionally. {@code MediaButtonReceiver}
 * starts the service via {@code startForegroundService} on every
 * notification transport button tap, and each such call opens a window
 * within which {@code startForeground} must be called.</p>
 *
 * <p>The demotion happens in {@link #doPause()} through
 * {@link NotificationService#demoteFromForeground()}, which calls
 * {@code stopForeground(false)}. The notification remains posted; only the
 * foreground status is dropped. SystemUI disables the Dismiss action on
 * a notification backed by a foreground service, so the demotion is what
 * makes the paused notification dismissible. A subsequent resume
 * re-promotes through the same {@code startForegroundSync} call in
 * {@link #onPlaybackResumed()}.</p>
 *
 * <h3>Notification Content Ownership</h3>
 * <p>The service is the sole producer of the notification's content.
 * {@link #createNotification()} reads the current song from
 * {@link #getCurrentSong()} and hands its title, artist, and album art to
 * {@link NotificationService} in the same main-thread iteration. The
 * album art decode is started in {@link #beginTransition(int, int)}, in
 * parallel with {@code prepareAsync}, so the cache is warm when the
 * transition commits. This makes the notification rebuild once per state
 * change with all three fields already in place, rather than once for the
 * title and again when a separate consumer's decode completes.</p>
 *
 * <h3>Media Button Routing</h3>
 * <p>Media buttons from headsets, hardware keys, and notification action
 * buttons are delivered to the active {@link MediaSessionCompat}. The
 * session is registered with the framework through
 * {@code androidx.media.session.MediaButtonReceiver} (declared in the
 * manifest), which forwards KeyEvents to the session callback regardless
 * of entry point. The {@code onStartCommand} path handles the cold-start
 * case where a media button arrives before the service has been bound.</p>
 *
 * <h3>Playback Control Entry Points</h3>
 * <p>Three entry points converge on the same state-machine methods:
 * direct calls from a bound activity, {@link MediaSessionCompat.Callback}
 * invocations from headsets and notification buttons, and the intent
 * actions in {@link #onStartCommand}. All three run on the main thread
 * and serialize through {@link #onMain}. The session callback and the
 * intent path additionally share the transport action debounce.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — At most one {@code prepareAsync()} in flight process-wide.</li>
 *   <li>I2 — {@link #releaseMediaPlayer()} runs only on the player
 *       thread.</li>
 *   <li>I3 — MediaPlayer callbacks with a stale generation are inert.</li>
 *   <li>I4 — {@link #setShuffle(boolean)} and {@link #setRepeatMode(int)}
 *       touch only their own field; they never cause a transition.</li>
 *   <li>I5 — {@link #onStall()} mutates state and calls
 *       {@link #reconcile()}; it never invokes a request method.</li>
 *   <li>I6 — State fields are written only on the main thread.</li>
 *   <li>I7 — {@link #setPlaylist(ArrayList, boolean)} resolves an anchor
 *       and re-enters reconciliation. It never bypasses the gate.</li>
 *   <li>I8 — {@link #transitionToIdle()} is idempotent; second callers join
 *       the first.</li>
 *   <li>I9 — Raw {@link MediaPlayer} calls execute only on
 *       {@code mPlayerThread}.</li>
 *   <li>I10 — {@code mGeneration} changes if and only if the state machine
 *       has moved on to a different song preparation. Resume does not
 *       change it; {@code mStartToken} carries the start/resume identity
 *       instead.</li>
 *   <li>I11 — {@link #getCurrentSong()} reports {@code mCurrentIndex} only.
 *       The activity, the notification, and the MediaSession metadata
 *       describe the same song at every instant.</li>
 *   <li>I12 — {@link #playNextSong()} and {@link #playPreviousSong()} base
 *       their computation on {@code mCurrentIndex}, so rapid presses during
 *       a transition collapse to a single advance.</li>
 *   <li>I13 — The service is foreground while {@code mState == PLAYING} and
 *       not foreground in every other state. The paused notification is
 *       dismissible by the user.</li>
 *   <li>I14 — {@link #prefetchNotificationArt(Song)} runs only on
 *       {@code mArtLoader}. The callback it produces checks the song path
 *       against {@link #getCurrentSong()} before touching the
 *       notification, so a late decode cannot overwrite the art of the
 *       song now displayed.</li>
 *   <li>I15 — Transport actions arriving through the active MediaSession
 *       callback pass through {@link #isNotificationActionDebounced(String)}
 *       before reaching the request methods, so the notification's
 *       effective input rate is bounded by the same window the activity's
 *       on-screen buttons use.</li>
 * </ul>
 *
 * <h3>Pause vs Stop</h3>
 * <p>{@link #pause()} retains the {@link MediaPlayer} and its position;
 * {@link #resume()} restarts from that position. {@link #stop()} releases
 * the player but remembers the index in {@code mTargetIndex}, so a
 * subsequent play re-prepares the same track from position 0.
 * {@link #stopCompletely()} tears down to IDLE and clears the playlist.</p>
 *
 * <h3>Timing</h3>
 * <p>The stall detector fires at {@code HEALTH_CHECK_INTERVAL_MS}, posts a
 * real {@code getCurrentPosition()} read to the player thread, and treats
 * a position below 100 ms lasting longer than {@code MAX_STALL_TIME_MS} as
 * a stall. The stall budget accrues only while {@code mState == PLAYING};
 * a slow {@code prepareAsync()} during PREPARING cannot masquerade as a
 * stall. All elapsed-time math uses
 * {@link SystemClock#elapsedRealtime()} to remain immune to wall-clock
 * corrections.</p>
 *
 * <h3>Skip-loop budget</h3>
 * <p>Automatic skipping past invalid tracks is bounded by a wall-clock
 * budget ({@code SKIP_LOOP_BUDGET_MS}) measured from the first consecutive
 * failure. A successful prepare or an explicit user request clears the run
 * and grants a fresh budget. When the budget is spent the loop parks in
 * IDLE with the playlist and target preserved so the next request can
 * retry.</p>
 *
 * @see MediaPlayer
 * @see NotificationService
 * @see EqualizerManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for storing the repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for storing the sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action for genre update events during genre loading. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action for setting a pending song path from external sources. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Intent action for audio session changed broadcast. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Service action for resuming playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME";

    /**
     * Debounce window for transport actions.
     *
     * <p>Applied to notification-originated intents in {@code onStartCommand}
     * and to the same actions when they arrive through the active
     * MediaSession's callback. The window matches the activity's
     * {@code CLICK_DEBOUNCE_DELAY_MS}, so a tap on the notification and a tap
     * on the corresponding on-screen button are subject to the same rate
     * limit. Aligning the two is what keeps the system's notification
     * rendering load equivalent to the app's own UI update rate.</p>
     */
    private static final long NOTIFICATION_ACTION_DEBOUNCE_MS = 500;

    /**
     * Interval for playback health checks in milliseconds. Chosen to keep
     * stall recovery responsive without waking the main handler more often
     * than necessary.
     */
    private static final int HEALTH_CHECK_INTERVAL_MS = 500;

    /**
     * Maximum time in milliseconds without position progress before
     * recovery. Accrues only while {@code mState == PLAYING} — a slow
     * prepareAsync during PREPARING does not count against this budget.
     */
    private static final int MAX_STALL_TIME_MS = 1500;

    /** Maximum recovery attempts before advancing past the failing song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    /**
     * Wall-clock budget for the automatic skip loop. The loop abandons once
     * this many milliseconds have elapsed since its first consecutive
     * failure. A successful prepare or an explicit user request clears the
     * run and grants a fresh budget.
     */
    private static final long SKIP_LOOP_BUDGET_MS = 2500L;

    /**
     * Maximum dimension in pixels for the notification's album art.
     * Matches the bound {@link NotificationService} applies to its own
     * copies, so the two never disagree on the size of the icon they
     * hold.
     */
    private static final int NOTIFICATION_ART_MAX_PX = 300;

    /** Size of the notification album art cache in megabytes. */
    private static final int NOTIFICATION_ART_CACHE_MB = 25;

    // ========================================================================
    // Sort Mode Constants
    // ========================================================================

    /** Sort mode: Title A-Z. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: Title Z-A. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: Artist A-Z. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: Artist Z-A. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: Album A-Z. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: Album Z-A. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: Genre A-Z. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: Genre Z-A. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: Oldest first by file modification date. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: Newest first by file modification date. */
    private static final int SORT_NEWEST = 9;

    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * Playback lifecycle states owned by the main thread. Transitions are
     * serialized through {@link #beginTransition(int, int)} and observed
     * only by listeners whose captured generation matches
     * {@link #mGeneration}.
     */
    private enum ServiceState {
        /** No player bound to a target. */
        IDLE,
        /** Exactly one {@code prepareAsync()} is in flight. */
        PREPARING,
        /** Prepared but not started; awaits an explicit play request. */
        READY,
        /** Actively playing. */
        PLAYING,
        /** Paused; the player is retained and its position held. */
        PAUSED,
        /** Teardown is in flight; all events are dropped. */
        STOPPING
    }

    /** Current state. Written only on the main thread. */
    private ServiceState mState = ServiceState.IDLE;

    /**
     * Identity of the current transition. Bumped by
     * {@link #beginTransition(int, int)} and by
     * {@link #transitionToIdle()}. Listener closures capture this value and
     * compare against it on every callback.
     *
     * <p>This counter is deliberately not bumped on resume. Resume is not a
     * transition; see {@link #mStartToken} for the counter that carries
     * start and resume identity.</p>
     */
    private long mGeneration = 0L;

    /**
     * Identity of the current start/resume continuation. Bumped by the
     * start-on-prepared leg of {@link #beginTransition(int, int)},
     * {@link #doResume()}, and the READY branch of
     * {@link #togglePlayPause()}.
     *
     * <p>This is deliberately separate from {@link #mGeneration}. Resuming
     * a paused player is not a song transition; bumping {@code mGeneration}
     * here would invalidate the {@code onCompletionListener} installed by
     * the current transition. {@code mStartToken} carries the same
     * burst-collapsing guarantee for start and resume continuations without
     * touching the transition identity that listener callbacks depend
     * on.</p>
     */
    private long mStartToken = 0L;

    /**
     * Index the {@link MediaPlayer} is actually bound to. When
     * {@code mState == PREPARING}, this still reflects the outgoing song.
     */
    private int mCurrentIndex = -1;

    /**
     * Index the state machine is driving toward. Mutated by request
     * methods, never by transitions directly.
     */
    private int mTargetIndex = -1;

    /** Seek position applied once {@code onPrepared} fires, then cleared. */
    private int mPendingSeekPosition = 0;

    /** Set by {@link #onStall()} to request a same-index re-prepare. */
    private boolean mForceReprepare = false;

    /**
     * When false, {@code onPrepared} leaves the machine in READY instead of
     * transitioning to PLAYING. Set true for every request except when a
     * caller explicitly wants a prepare-only transition.
     */
    private boolean mAutoStartOnPrepared = true;

    /** {@link SystemClock#elapsedRealtime()} at the moment PLAYING was entered. */
    private long mPlaybackStartElapsed = 0L;

    /** Consecutive stall recovery attempts for the current song. */
    private int mRecoveryAttempts = 0;

    /**
     * {@link SystemClock#elapsedRealtime()} at the first consecutive
     * transition failure, or 0 when no skip-loop run is active. Written and
     * read only on the main thread.
     */
    private long mSkipLoopStartedElapsed = 0L;

    /** Dedicated handler for state-machine posts. Never shared with health. */
    private final Handler mMachineHandler = new Handler(Looper.getMainLooper());

    /** Handler for periodic health checks. */
    private Handler mHealthHandler;

    /** Runnable for health check. */
    private Runnable mHealthCheckRunnable;

    /**
     * Last dispatch time per transport action, keyed by action string.
     * Shared by the intent path in {@link #onStartCommand} and the
     * MediaSession callback in {@link #setupMediaSession()}, so a
     * cold-start NEXT and a session NEXT are treated as one tap for
     * rate-limiting purposes.
     */
    @NonNull
    private final HashMap<String, Long> mLastNotificationActionTime = new HashMap<>();

    // ========================================================================
    // MediaPlayer
    // ========================================================================

    /** MediaPlayer instance for audio playback. Player-thread only. */
    private MediaPlayer mMediaPlayer;

    /**
     * Dedicated thread on which every raw {@link MediaPlayer} call runs.
     * Blocking calls such as {@code setDataSource} and {@code prepareAsync}
     * happen here, never on the main thread.
     */
    private HandlerThread mPlayerThread;

    /** Handler bound to {@link #mPlayerThread}. */
    private Handler mPlayerHandler;

    /** WakeLock to prevent device sleep during playback. Main-thread only. */
    private PowerManager.WakeLock mWakeLock;

    // ========================================================================
    // Notification Album Art
    // ========================================================================

    /**
     * Single-thread executor for notification album art decoding. The
     * decode runs in parallel with the transition's {@code prepareAsync},
     * so the cache is usually warm by the time the transition commits.
     */
    private final ExecutorService mArtLoader = Executors.newSingleThreadExecutor();

    /** Album art cache keyed by song path, bounded by bytes. */
    private LruCache<String, Bitmap> mArtCache;

    /** In-flight notification art load, cancelled when a new target supersedes it. */
    private Future<?> mCurrentArtLoad = null;

    /**
     * Path of the album art the notification currently holds. Used to
     * avoid re-pushing art for the same song when nothing has changed.
     */
    private String mNotificationArtPath = null;

    // ========================================================================
    // Cached playback facts. Written on main from callback data.
    // ========================================================================

    /** Duration of the current track in ms, or 0 when unknown. */
    private int mCachedDuration = 0;

    /** Audio session id of the current player, or 0 when unknown. */
    private int mCachedAudioSessionId = 0;

    /** Last known position in ms. Anchored on state changes. */
    private int mCachedPosition = 0;

    /** Position (ms) at {@link #mPlaybackBaseElapsed}. */
    private int mPlaybackBasePosition = 0;

    /** Anchor time for {@link #mCachedPosition}. 0 when not playing. */
    private long mPlaybackBaseElapsed = 0L;

    /**
     * Bumped whenever the position anchor is re-set while PLAYING. A
     * position read posted before the bump is discarded when it returns.
     * Written and read only on the main thread.
     */
    private long mPositionEpoch = 0L;

    // ========================================================================
    // Playlist and Playback State
    // ========================================================================

    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;

    /** Cached playback flag (mirrors mState == PLAYING for callers). */
    private volatile boolean mIsPlaying = false;

    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;

    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;

    /** Current sort mode for playlist ordering. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** History of shuffled indices (for prev/next in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;

    /** Random number generator for shuffle mode. */
    private Random mRandom;

    /**
     * Path of a song that was added as a loose track and should be played
     * on the next playlist update. Consumed by
     * {@link #setPlaylist(ArrayList, boolean)}.
     */
    private volatile String mPendingSongPath = null;

    // ========================================================================
    // Binder, Library, Notification
    // ========================================================================

    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();

    /** Music library manager for song data. */
    private MusicLibrary mMusicLibrary;

    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;

    // ========================================================================
    // Audio Focus and Session
    // ========================================================================

    /** Audio manager for focus management. */
    private AudioManager mAudioManager;

    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;

    /** Audio focus request for API 26+. */
    private AudioFocusRequest mAudioFocusRequest;

    /**
     * MediaSessionCompat for lock screen, headset, and notification
     * transport controls. Registered with the framework through
     * {@code androidx.media.session.MediaButtonReceiver}.
     */
    private MediaSessionCompat mMediaSession;

    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    private BroadcastReceiver mSetPendingSongReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Local binder for service binding. Allows activities to obtain a
     * reference to the service.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Sort Comparators
    // ========================================================================

    /** Comparator for sorting songs by title A-Z (case-insensitive). */
    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    /** Comparator for sorting songs by title Z-A (case-insensitive). */
    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    /** Comparator for sorting songs by artist A-Z, then title A-Z. */
    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by artist Z-A, then title A-Z. */
    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by album A-Z, then title A-Z. */
    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by album Z-A, then title A-Z. */
    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by genre A-Z, then title A-Z. */
    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by genre Z-A, then title A-Z. */
    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by file modification date, oldest first. */
    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /** Comparator for sorting songs by file modification date, newest first. */
    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Returns the last-modified timestamp of a song's file.
     *
     * @param song The song to query
     * @return The timestamp in milliseconds since epoch, or 0
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }

    /**
     * Returns the comparator for the given sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A comparator implementing the requested order
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ========================================================================
    // Static Helpers
    // ========================================================================

    /**
     * Persists the "player state before update" flag.
     *
     * @param context Application context
     * @param need The flag value to store
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    /**
     * Reads the "player state before update" flag.
     *
     * @param context Application context
     * @return True if the flag is set
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the "player state before update" flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the current audio session ID, or 0 if not attached.
     *
     * @return The audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ========================================================================
    // Service Lifecycle
    // ========================================================================

    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        final int artCacheSize = NOTIFICATION_ART_CACHE_MB * 1024 * 1024;
        mArtCache = new LruCache<String, Bitmap>(artCacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        // Dedicated player thread. Every raw MediaPlayer call posts here;
        // blocking calls never touch the main looper.
        mPlayerThread = new HandlerThread("MediaPlayerThread");
        mPlayerThread.start();
        mPlayerHandler = new Handler(mPlayerThread.getLooper());

        mNotificationService = new NotificationService(this);

        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        // Hand the session token to the notification layer so its
        // MediaStyle can bind to the active session.
        if (mNotificationService != null) {
            mNotificationService.setSessionTokenProvider(this::getSessionToken);
        }

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerSoftUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Promote to foreground synchronously so the framework's foreground
        // contract is satisfied regardless of pending main-looper work.
        // MediaButtonReceiver starts the service via startForegroundService
        // on every notification transport button tap, and each such call
        // opens a window within which startForeground must be called.
        // startForegroundSync therefore calls Service.startForeground
        // unconditionally.
        if (mNotificationService != null) {
            mNotificationService.startForegroundSync();
        }

        if (intent != null && intent.getAction() != null) {
            final String action = intent.getAction();

            // System-routed media button. MediaButtonReceiver forwards the
            // raw KeyEvent here on the cold-start path; on subsequent taps
            // the receiver dispatches directly to the session.
            if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
                KeyEvent event;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent.class);
                } else {
                    @SuppressWarnings("deprecation")
                    KeyEvent deprecatedEvent = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                    event = deprecatedEvent;
                }
                if (event != null && event.getAction() == KeyEvent.ACTION_DOWN
                        && mMediaSession != null) {
                    mMediaSession.getController().dispatchMediaButtonEvent(event);
                }
                return START_STICKY;
            }

            // Debounce transport actions that arrive through the cold-start
            // path. The same window is applied to session callbacks in
            // setupMediaSession, so the two routes share one rate limit.
            if (isNotificationActionDebounced(action)) {
                return START_STICKY;
            }

            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNextSong();
            } else if (action.equals("ACTION_PREV")) {
                playPreviousSong();
            } else if (action.equals("ACTION_STOP")) {
                pause();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) mNotificationService.stopForeground();
            } else if (action.equals(ACTION_BLUETOOTH_RESUME)) {
                handleBluetoothResume();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) playSong(position);
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    /**
     * Returns true if the given transport action was dispatched too
     * recently and should be dropped. Only the three transport actions are
     * debounced; other actions pass through.
     *
     * <p>This method is the shared rate limit for notification button
     * taps, hardware media keys, and cold-start intents. All three routes
     * use the same key per action, so a burst arriving through any
     * combination of them is treated as a single logical tap sequence.
     * The debounce window matches the activity's on-screen button
     * debounce, keeping the notification's effective input rate bounded
     * by the same limit the app UI already enforces.</p>
     *
     * @param action The action string from the intent or session callback
     * @return True if the action should be dropped as a repeat
     */
    private boolean isNotificationActionDebounced(@NonNull String action) {
        if (!"ACTION_PLAY_PAUSE".equals(action)
                && !"ACTION_NEXT".equals(action)
                && !"ACTION_PREV".equals(action)) {
            return false;
        }
        final long now = SystemClock.elapsedRealtime();
        final Long last = mLastNotificationActionTime.get(action);
        if (last != null && now - last < NOTIFICATION_ACTION_DEBOUNCE_MS) {
            return true;
        }
        mLastNotificationActionTime.put(action, now);
        return false;
    }

    /**
     * Resumes playback after a Bluetooth headset connect.
     *
     * <p>Starts with the last song as a single-song playlist so the
     * foreground contract is satisfied with real content, then loads the
     * full library in the background and replaces the playlist when it
     * arrives. If nothing can be resumed, tears down and stops the
     * service.</p>
     */
    private void handleBluetoothResume() {
        onMain(() -> {
            final String lastPath = getSavedSongPath();
            if (lastPath == null || !new File(lastPath).exists()) {
                transitionToIdle();
                stopSelf();
                return;
            }

            Song lastSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (lastSong == null) {
                lastSong = CharacterMapper.getSongFromFile(lastPath);
            }
            if (lastSong == null) {
                transitionToIdle();
                stopSelf();
                return;
            }

            final ArrayList<Song> singleSong = new ArrayList<>();
            singleSong.add(lastSong);
            setPlaylist(singleSong, true);
            resume();

            if (mMusicLibrary == null) mMusicLibrary = new MusicLibrary(this);
            mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
                @Override
                public void onSongsLoaded(ArrayList<Song> songs) {
                    onMain(() -> {
                        if (songs != null && !songs.isEmpty()) {
                            setPlaylist(songs, true);
                        }
                    });
                }

                @Override
                public void onLoadingError(String error) {
                    Log.w(TAG, "Full library load after BT resume failed: " + error);
                }
            });
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtLoader != null && !mArtLoader.isShutdown()) {
            mArtLoader.shutdownNow();
        }

        // Post the release, then drain and quit. quitSafely drains pending
        // messages before the thread exits; join bounds the wait even if
        // the player thread is stuck on a blocking call.
        if (mPlayerHandler != null) {
            mPlayerHandler.post(this::releaseMediaPlayer);
        }
        if (mPlayerThread != null) {
            mPlayerThread.quitSafely();
            try {
                mPlayerThread.join(2000);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            mPlayerThread = null;
            mPlayerHandler = null;
        }

        releaseWakeLock();
        mIsPlaying = false;
        mState = ServiceState.STOPPING;

        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMachineHandler != null) {
            mMachineHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(this::reconcile);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ========================================================================
    // Thread Marshalling and Small Helpers
    // ========================================================================

    /**
     * Runs {@code action} on the main thread, immediately if already there.
     * All state-machine mutations funnel through this method.
     *
     * @param action The action to run
     */
    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) action.run();
        else mMachineHandler.post(action);
    }

    /**
     * Runs {@code action} on the player thread, immediately if already
     * there. All raw MediaPlayer calls funnel through this method.
     *
     * @param action The action to run
     */
    private void onPlayer(@NonNull Runnable action) {
        if (mPlayerHandler == null) return;
        if (Looper.myLooper() == mPlayerHandler.getLooper()) action.run();
        else mPlayerHandler.post(action);
    }

    /**
     * Returns the current playlist size, or 0 if no playlist.
     *
     * @return Playlist size
     */
    private int playlistSize() {
        return mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0;
    }

    /**
     * Checks if the playlist is empty.
     *
     * @return True if the playlist is null or empty
     */
    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    /**
     * Returns the path of the song at the given index.
     *
     * @param index The playlist index
     * @return The path, or null if the index is invalid
     */
    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) return null;
        if (index < 0 || index >= mCurrentPlaylist.size()) return null;
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    /**
     * Returns the playlist index of the song with the given path.
     *
     * @param path The path to search for
     * @return The index, or -1 if not found
     */
    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) return -1;
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) return index;
        }
        return -1;
    }

    /**
     * Acquires the wake lock if not already held.
     */
    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try { mWakeLock.acquire(); } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    /**
     * Releases the wake lock if held.
     */
    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try { mWakeLock.release(); } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    /**
     * Estimates the current position from the anchor. Exact at every
     * health-check boundary; interpolated between them.
     *
     * @return The estimated position in milliseconds
     */
    private int estimateCurrentPosition() {
        if (mState == ServiceState.PLAYING && mPlaybackBaseElapsed > 0L) {
            long elapsedDuration = SystemClock.elapsedRealtime() - mPlaybackBaseElapsed;
            long estimatedDuration = mPlaybackBasePosition + elapsedDuration;
            if (mCachedDuration > 0 && estimatedDuration > mCachedDuration) return mCachedDuration;
            return (int) estimatedDuration;
        }
        return mCachedPosition;
    }

    /**
     * Records a transition failure and reports whether the skip loop has
     * spent its budget.
     *
     * @return true when the loop should give up; false when it may advance
     *         and retry.
     */
    private boolean skipBudgetExhausted() {
        long currentTime = SystemClock.elapsedRealtime();
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = currentTime;
            return false;
        }
        return (currentTime - mSkipLoopStartedElapsed) >= SKIP_LOOP_BUDGET_MS;
    }

    /**
     * Abandons the skip loop once its budget is spent. Releases the player
     * on the player thread and the wake lock on main. Preserves the
     * playlist and target so a subsequent request retries with a fresh
     * budget. Does not post reconcile, so the loop cannot restart from
     * inside the give-up.
     */
    private void abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after "
            + (SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed) + " ms");
        mSkipLoopStartedElapsed = 0L;
        mForceReprepare = false;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mIsPlaying = false;
        mCurrentIndex = -1;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    // ========================================================================
    // Notification Album Art
    // ========================================================================

    /**
     * Starts a background decode of the song's embedded album art unless
     * the art is already cached. Called at the start of every transition
     * so the decode overlaps with {@code prepareAsync}. When the commit
     * fires, the cache is usually warm and the notification receives the
     * new title and the new art in the same main-thread iteration,
     * producing one rebuild instead of two.
     *
     * <p>Any previous load is cancelled. The load places the decoded
     * bitmap in {@link #mArtCache} under the song's path and, if the song
     * is still the one the player is bound to when the load returns, hands
     * the art to the notification through
     * {@link NotificationService#setAlbumArt}. The path check inside that
     * method rejects art whose path does not match the notification's
     * current song, so a load that finishes after the user has moved on
     * cannot overwrite the art of the song now displayed.</p>
     *
     * @param song The target song of a transition
     */
    private void prefetchNotificationArt(@Nullable Song song) {
        if (song == null || song.getPath() == null) return;

        final String path = song.getPath();

        if (mArtCache.get(path) != null) {
            return;
        }

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }

        mCurrentArtLoad = mArtLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;

                Bitmap art = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    byte[] bytes = retriever.getEmbeddedPicture();
                    if (bytes != null && !Thread.currentThread().isInterrupted()) {
                        art = decodeNotificationArt(bytes);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Notification art prefetch failed for " + path, exception);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }

                if (art == null || Thread.currentThread().isInterrupted()) {
                    return;
                }

                mArtCache.put(path, art);

                final Bitmap finalArt = art;
                onMain(() -> {
                    Song current = getCurrentSong();
                    if (current != null
                            && path.equals(current.getPath())
                            && mNotificationService != null
                            && !path.equals(mNotificationArtPath)) {
                        mNotificationService.setAlbumArt(finalArt, null, path);
                        mNotificationArtPath = path;
                    }
                });
            }
        });
    }

    /**
     * Decodes the embedded picture bytes into a bitmap bounded by
     * {@link #NOTIFICATION_ART_MAX_PX} on its longer side. The decode
     * mirrors the downsampling that {@link NotificationService} applies to
     * its own copies, so the two never disagree on the size of the icon
     * they hold.
     *
     * @param data The raw embedded picture bytes
     * @return The downsampled bitmap, or null when decoding fails
     */
    @Nullable
    private Bitmap decodeNotificationArt(@NonNull byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);

        int sampleSize = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) {
            sampleSize *= 2;
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sampleSize;
        return BitmapFactory.decodeByteArray(data, 0, data.length, decode);
    }

    // ========================================================================
    // Pure Functions - No Side Effects, Main Thread Only
    // ========================================================================

    /**
     * Computes the next index from {@code fromIndex}, honoring shuffle and
     * repeat-all wraparound.
     *
     * @param fromIndex The base index
     * @return The next index, or -1 if the playlist is empty
     */
    private int computeNext(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return pickShuffleNext(fromIndex);
        return (fromIndex + 1) % playlistSize();
    }

    /**
     * Computes the previous index from {@code fromIndex}, honoring shuffle
     * history and repeat-all wraparound.
     *
     * @param fromIndex The base index
     * @return The previous index, or -1 if the playlist is empty
     */
    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return popShuffleHistory(fromIndex);
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    /**
     * Picks the next index under shuffle, avoiding the current index.
     *
     * @param fromIndex The current index
     * @return The chosen index
     */
    private int pickShuffleNext(int fromIndex) {
        int size = playlistSize();
        if (size <= 1) return fromIndex;

        if (mShuffleHistory == null) mShuffleHistory = new ArrayList<Integer>();
        if (mShuffleHistory.size() >= size * 2) mShuffleHistory.clear();
        if (mRandom == null) mRandom = new Random();

        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);

        mShuffleHistory.add(candidate);
        return candidate;
    }

    /**
     * Pops the previous index from the shuffle history, or picks a random
     * one if the history is too short.
     *
     * @param fromIndex The current index
     * @return The chosen previous index
     */
    private int popShuffleHistory(int fromIndex) {
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int previousIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
            if (previousIndex >= 0 && previousIndex < playlistSize()) return previousIndex;
        }
        int size = playlistSize();
        if (size <= 1) return fromIndex;
        if (mRandom == null) mRandom = new Random();
        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);
        return candidate;
    }

    // ========================================================================
    // Core: Reconcile and Transition
    // ========================================================================

    /**
     * The single gate between "a target exists" and "a transition begins".
     * Every event (request, completion, stall, playlist update) funnels
     * here. Nothing else calls {@link #beginTransition(int, int)}.
     */
    private void reconcile() {
        if (mState == ServiceState.STOPPING) return;
        if (mState == ServiceState.PREPARING) return;
        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) return;

        boolean need = (mTargetIndex != mCurrentIndex) || mForceReprepare;
        if (!need) return;

        mForceReprepare = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    /**
     * Starts a transition toward {@code index}. The only caller of
     * {@code prepareAsync()}. The raw player work (release, reset,
     * setDataSource, prepareAsync) runs on the player thread. Every
     * listener captures the current generation and posts back to main,
     * where the generation is re-checked before any state mutation.
     *
     * <p>The notification album art decode for the target is started
     * here, before {@code prepareAsync}, so it runs in parallel with the
     * prepare. By the time the transition commits, the cache is usually
     * warm and the notification receives title, artist, and art together
     * in one main-thread iteration.</p>
     *
     * @param index The index to transition to
     * @param seekPosition The position to apply after preparation
     */
    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) return;
        if (playlistEmpty()) { transitionToIdle(); return; }
        if (index < 0 || index >= playlistSize()) return;

        final long generation = ++mGeneration;
        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            mState = ServiceState.IDLE;
            if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
            mTargetIndex = computeNext(index);
            mMachineHandler.post(this::reconcile);
            return;
        }

        prefetchNotificationArt(song);

        final String path = song.getPath();
        final int committedIndex = index;
        final long capturedGeneration = generation;

        onPlayer(() -> {
            releaseMediaPlayer();
            final MediaPlayer player = getOrCreatePlayerRaw();
            removeAllListeners(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            try {
                player.setDataSource(path);
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + path, exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            player.setOnPreparedListener(mediaPlayer -> {
                final int duration;
                final int audioSessionId;
                try {
                    duration = mediaPlayer.getDuration();
                    audioSessionId = mediaPlayer.getAudioSessionId();
                } catch (Exception exception) {
                    mMachineHandler.post(() ->
                        onPrepareFailed(capturedGeneration, committedIndex));
                    return;
                }
                mMachineHandler.post(() -> onPrepared(
                    capturedGeneration, duration, audioSessionId, song, committedIndex));
            });

            player.setOnCompletionListener(mediaPlayer ->
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    onCompletion();
                }));

            player.setOnErrorListener((mediaPlayer, what, extra) -> {
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    onPlayerError(what, extra);
                });
                return true;
            });

            try {
                player.prepareAsync();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "prepareAsync failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
            }
        });
    }

    /**
     * Tears down to IDLE. Idempotent (invariant I8): if already STOPPING,
     * the second caller joins the first and returns.
     */
    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) return;
        mState = ServiceState.STOPPING;
        mGeneration++;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mForceReprepare = false;
        mSkipLoopStartedElapsed = 0L;
        mCurrentIndex = -1;

        mCachedPosition = 0;
        mCachedDuration = 0;
        mCachedAudioSessionId = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;
        mPositionEpoch++;

        stopHealthMonitoring();

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentPlaylist = null;
        mIsPlaying = false;
        if (mShuffleHistory != null) mShuffleHistory.clear();
        EqualizerManager.getInstance(this).detach();

        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mState = ServiceState.IDLE;
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // MediaPlayer Callbacks (main-thread continuations)
    // ========================================================================

    /**
     * Fires when {@code prepareAsync()} completes. Commits the audio
     * session id and duration, applies the pending seek, and — when
     * autostart is enabled — posts a seek+start to the player thread.
     *
     * <p>The start-on-prepared continuation is tagged with a fresh
     * {@link #mStartToken}. A second transition cannot slip in between the
     * generation check and the start post because {@code mState} remains
     * PREPARING until {@link #onPlaybackStarted(long, int, Song, int)}
     * commits PLAYING, and request methods never mutate state during
     * PREPARING. The {@code mStartToken} gate collapses the narrower race
     * where a resume from PAUSED is queued behind this start; only the
     * latest start or resume continuation is allowed to commit.</p>
     *
     * @param generation The generation captured when the transition began
     * @param duration The track duration reported by the player
     * @param audioSessionId The audio session id reported by the player
     * @param song The song that was prepared
     * @param committedIndex The index this preparation was started for
     */
    private void onPrepared(long generation, int duration, int audioSessionId,
                            @NonNull Song song, int committedIndex) {
        if (generation != mGeneration) return;
        if (mState != ServiceState.PREPARING) return;

        if (duration <= 0) {
            onPrepareFailed(generation, committedIndex);
            return;
        }

        int seekPosition = mPendingSeekPosition;
        mPendingSeekPosition = 0;

        mSkipLoopStartedElapsed = 0L;
        mCachedDuration = duration;
        mCachedAudioSessionId = audioSessionId;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        sCurrentAudioSessionId = audioSessionId;
        broadcastAudioSessionChanged(audioSessionId);
        EqualizerManager.getInstance(this).attachToAudioSession(audioSessionId);

        mCurrentIndex = committedIndex;

        if (!mAutoStartOnPrepared) {
            mState = ServiceState.READY;
            mRecoveryAttempts = 0;
            updateMediaSessionMetadata(song, null);
            updateMediaSessionPlaybackState();
            saveCurrentPlayingIndex();
            createNotification();
            broadcastUpdate();
            return;
        }

        final int doSeek = (seekPosition > 0 && seekPosition < duration - 500)
            ? seekPosition : 0;
        final long capturedGeneration = generation;
        final Song capturedSong = song;
        final int capturedIndex = committedIndex;
        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            if (doSeek > 0) {
                try { player.seekTo(doSeek); } catch (Exception ignored) {}
            }
            try {
                player.start();
            } catch (Exception exception) {
                Log.e(TAG, "onPrepared: start() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            final long finalCapturedStartToken = capturedStartToken;
            mMachineHandler.post(() -> {
                if (finalCapturedStartToken != mStartToken) return;
                onPlaybackStarted(capturedGeneration, capturedIndex, capturedSong, doSeek);
            });
        });
    }

    /**
     * Fires once {@code start()} has succeeded on the player thread. Enters
     * PLAYING and runs the full post-start sequence.
     *
     * <p>Foreground promotion is re-established here after the transition
     * commits, so a session that was demoted by an earlier pause returns to
     * its protected state. The call is idempotent: when the promotion is
     * already in place the notification layer performs the same
     * {@code startForeground} call it would have performed on a fresh cold
     * start.</p>
     *
     * @param generation The generation captured when the transition began
     * @param committedIndex The index that was prepared
     * @param song The song that was prepared
     * @param seekPosition The position the track was seeked to before
     *                     starting, or 0
     */
    private void onPlaybackStarted(long generation, int committedIndex,
                                   @NonNull Song song, int seekPosition) {
        if (generation != mGeneration) return;
        if (mState != ServiceState.PREPARING) return;

        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBasePosition = seekPosition;
        mPlaybackBaseElapsed = mPlaybackStartElapsed;
        mCachedPosition = seekPosition;
        mRecoveryAttempts = 0;

        acquireWakeLock();
        requestAudioFocus();
        updatePlaybackParams();
        updateMediaSessionMetadata(song, null);
        updateMediaSessionPlaybackState();
        saveCurrentPlayingIndex();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        createNotification();
        broadcastUpdate();

        // Re-establish the foreground promotion after a transition commit.
        // startForegroundSync posts the notification and promotes in one
        // call; the notification layer's own state-based demote reverses
        // it on the next pause.
        if (mNotificationService != null) {
            mNotificationService.startForegroundSync();
        }

        // A NEXT/PREV that arrived during the async window bumped
        // mTargetIndex. Defer reconcile so we do not release the player
        // from inside its own callback.
        if (mTargetIndex != mCurrentIndex || mForceReprepare) {
            mMachineHandler.post(this::reconcile);
        }
    }

    /**
     * Handles a failed prepare. Releases the player, advances the target,
     * and re-enters reconciliation, bounded by the skip-loop budget.
     *
     * @param generation The generation captured when the transition began
     * @param committedIndex The index this preparation was started for
     */
    private void onPrepareFailed(long generation, int committedIndex) {
        if (generation != mGeneration) return;
        mState = ServiceState.IDLE;
        onPlayer(this::releaseMediaPlayer);
        if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
        mTargetIndex = computeNext(committedIndex);
        mMachineHandler.post(this::reconcile);
    }

    /**
     * Fires when the current track finishes. Chooses the next destination
     * from mRepeatMode. Transitions out of the completion handler are
     * posted, so the player is never released from inside its own callback
     * frame. The end-of-playlist branch pauses in place and does not
     * transition. A same-index destination (repeat-one, or repeat-all on a
     * single-song playlist) sets mForceReprepare so reconcile() restarts
     * playback.
     */
    private void onCompletion() {
        if (mState != ServiceState.PLAYING) return;

        if (playlistEmpty()) { transitionToIdle(); return; }

        int fromIndex = mCurrentIndex;
        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mRepeatMode == 1) {
            nextIndex = computeNext(fromIndex);
        } else if (fromIndex + 1 < playlistSize()) {
            nextIndex = fromIndex + 1;
        } else {
            mState = ServiceState.PAUSED;
            mTargetIndex = fromIndex;
            mPendingSeekPosition = 0;
            mIsPlaying = false;
            mCachedPosition = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            onPlayer(() -> {
                final MediaPlayer player = mMediaPlayer;
                if (player == null) return;
                try { player.pause(); } catch (Exception ignored) {}
                try { player.seekTo(0); } catch (Exception ignored) {}
            });

            releaseWakeLock();
            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        mMachineHandler.post(this::reconcile);
    }

    /**
     * Fires when MediaPlayer reports an error. Releases the player on the
     * player thread and advances past the failed track, bounded by the
     * skip-loop budget.
     *
     * @param what The error type
     * @param extra The error extra code
     */
    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);

        mIsPlaying = false;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        if (playlistEmpty()) { transitionToIdle(); return; }
        if (skipBudgetExhausted()) { abandonSkipLoop(); return; }

        if (mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        mMachineHandler.post(this::reconcile);
    }

    /**
     * Fires from the health check when the real position has not advanced
     * past 100 ms for MAX_STALL_TIME_MS while in PLAYING. Mutates target,
     * then reconciles. Does not call any request method (invariant I5).
     */
    private void onStall() {
        if (mState != ServiceState.PLAYING) return;

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) { transitionToIdle(); return; }
            if (skipBudgetExhausted()) { abandonSkipLoop(); return; }
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
        } else {
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
        }

        reconcile();
    }

    // ========================================================================
    // Health Monitoring
    // ========================================================================

    /**
     * Installs the health check runnable. Each tick posts a real position
     * read to the player thread; the stall decision runs on the returned
     * value. The tick keeps firing while PREPARING or PAUSED too, so the
     * loop survives a transition, but only PLAYING triggers a read.
     */
    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mState == ServiceState.PLAYING) {
                    refreshPositionFromPlayer();
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    /**
     * Posts a real position read to the player thread and, on return,
     * re-anchors the cached position and runs the stall check.
     */
    private void refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) return;

        final long epoch = mPositionEpoch;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;

            final int position;
            try {
                position = player.getCurrentPosition();
            } catch (Exception exception) {
                return;
            }

            mMachineHandler.post(() -> {
                if (epoch != mPositionEpoch) return;
                if (mState != ServiceState.PLAYING) return;

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime();

                long elapsedDuration = SystemClock.elapsedRealtime() - mPlaybackStartElapsed;
                if (position < 100 && elapsedDuration > MAX_STALL_TIME_MS) {
                    onStall();
                } else if (position >= 100) {
                    mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                }
            });
        });
    }

    /**
     * Starts periodic health monitoring.
     */
    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    /**
     * Stops periodic health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ========================================================================
    // Public Request API
    // ========================================================================

    /**
     * Plays the song at the given playlist index.
     *
     * @param index The playlist index
     */
    public void playSong(int index) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Plays the song at the given playlist index at the given position.
     *
     * @param index The playlist index
     * @param position The starting position in milliseconds
     */
    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    /**
     * Plays the song with the given file path. If the song is not in the
     * playlist, parks the path as pending for the next playlist update.
     *
     * @param filePath The file path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG, "playSongByPath: not in playlist, parked: " + filePath);
            }
        });
    }

    /**
     * Advances to the next song in the current playback order.
     *
     * <p>The base index is {@link #mCurrentIndex}. Rapid presses during a
     * transition therefore all compute the same next index and collapse to
     * a single advance. The collapse is structural:
     * {@link #reconcile()} returns early while {@code mState == PREPARING},
     * so only the last computed target survives the burst. Taps arriving
     * through the notification are additionally rate-limited at
     * {@link #isNotificationActionDebounced(String)} before reaching this
     * method.</p>
     */
    public void playNextSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computeNext(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Returns to the previous song in the current playback order.
     *
     * <p>The base index is {@link #mCurrentIndex}, for the same reason as
     * {@link #playNextSong()}. Taps arriving through the notification are
     * additionally rate-limited at
     * {@link #isNotificationActionDebounced(String)} before reaching this
     * method.</p>
     */
    public void playPreviousSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computePrevious(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Toggles between play and pause states based on the current state.
     */
    public void togglePlayPause() {
        onMain(() -> {
            switch (mState) {
                case PLAYING:
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY: {
                    // Bump mStartToken for the same reason as doResume(): a
                    // rapid PLAY/PAUSE burst must not queue multiple
                    // concurrent start continuations from READY. mGeneration
                    // is not touched so the completion listener installed by
                    // the current transition remains valid.
                    final long capturedStartToken = ++mStartToken;
                    onPlayer(() -> {
                        final MediaPlayer player = mMediaPlayer;
                        boolean started = false;
                        if (player != null) {
                            try {
                                player.start();
                                started = true;
                            } catch (Exception exception) {
                                Log.e(TAG, "start() failed from READY", exception);
                            }
                        }
                        final boolean finalStarted = started;
                        mMachineHandler.post(() -> {
                            if (capturedStartToken != mStartToken) return;
                            if (!finalStarted) {
                                mState = ServiceState.IDLE;
                                onPlayer(this::releaseMediaPlayer);
                                broadcastUpdate();
                                return;
                            }
                            mState = ServiceState.PLAYING;
                            mIsPlaying = true;
                            mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                            mPlaybackBaseElapsed = mPlaybackStartElapsed;
                            acquireWakeLock();
                            requestAudioFocus();
                            updatePlaybackParams();
                            savePlayingState();
                            savePlayerState();
                            startHealthMonitoring();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();

                            if (mNotificationService != null) {
                                mNotificationService.startForegroundSync();
                            }
                        });
                    });
                    break;
                }
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        createNotification();
                        return;
                    }
                    mSkipLoopStartedElapsed = 0L;
                    if (mTargetIndex < 0) mTargetIndex = 0;
                    reconcile();
                    break;
                case PREPARING:
                case STOPPING:
                    break;
            }
        });
    }

    /**
     * Pauses playback if currently playing.
     */
    public void pause() {
        onMain(() -> { if (mState == ServiceState.PLAYING) doPause(); });
    }

    /**
     * Resumes playback from the paused or ready state, or restarts from the
     * current target if idle.
     */
    public void resume() {
        onMain(() -> {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                mSkipLoopStartedElapsed = 0L;
                if (mTargetIndex < 0 && !playlistEmpty()) mTargetIndex = 0;
                reconcile();
            }
        });
    }

    /**
     * Stops playback and releases the player but keeps the playlist and
     * the target index so a subsequent play re-prepares the same track.
     */
    public void stop() {
        onMain(() -> {
            if (mState != ServiceState.PLAYING && mState != ServiceState.PAUSED) return;

            int stoppedAtIndex = mCurrentIndex;

            onPlayer(this::releaseMediaPlayer);
            releaseWakeLock();

            mIsPlaying = false;
            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;
            mPendingSeekPosition = 0;
            mForceReprepare = false;
            mSkipLoopStartedElapsed = 0L;
            mState = ServiceState.IDLE;

            mCachedPosition = 0;
            mCachedDuration = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        });
    }

    /**
     * Tears down to IDLE and clears the playlist.
     */
    public void stopCompletely() {
        onMain(this::transitionToIdle);
    }

    /**
     * Internal pause. Anchors the position, posts the pause to the player
     * thread, and releases the wake lock.
     *
     * <p>The service is demoted from the foreground after the pause is
     * committed. SystemUI disables the Dismiss action on a notification
     * backed by a foreground service. The notification itself is retained
     * — only the foreground status is dropped — so the transport controls
     * remain available and a subsequent resume re-promotes without a
     * flash.</p>
     */
    private void doPause() {
        final int position = estimateCurrentPosition();

        mState = ServiceState.PAUSED;
        mIsPlaying = false;
        mCachedPosition = position;
        mPlaybackBasePosition = position;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;
            try { player.pause(); } catch (Exception ignored) {}
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();

        // The notification layer's own state-based demote already drops
        // the foreground promotion whenever the rendered state is not
        // PLAYING. This call commits the demotion in the same frame as
        // the pause, before any scheduled notification rebuild has a
        // chance to run.
        if (mNotificationService != null) {
            mNotificationService.demoteFromForeground();
        }
    }

    /**
     * Internal resume. Posts the start to the player thread and runs the
     * post-resume sequence on main when it returns. Bumps
     * {@link #mStartToken} so a rapid PLAY/PAUSE burst cannot queue multiple
     * concurrent resume continuations; only the latest survives the
     * post-back check. {@link #mGeneration} is not touched: resuming a
     * paused player is not a song transition, and leaving the generation
     * unchanged keeps the completion listener installed by the current
     * transition valid.
     */
    private void doResume() {
        requestAudioFocus();
        updatePlaybackParams();

        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            boolean started = false;
            if (player != null) {
                try {
                    player.start();
                    started = true;
                } catch (Exception exception) {
                    Log.e(TAG, "resume: start() failed", exception);
                }
            }
            final boolean finalStarted = started;
            mMachineHandler.post(() -> {
                if (capturedStartToken != mStartToken) return;
                if (finalStarted) {
                    onPlaybackResumed();
                } else {
                    mState = ServiceState.IDLE;
                    onPlayer(this::releaseMediaPlayer);
                    broadcastUpdate();
                    reconcile();
                }
            });
        });
    }

    /**
     * Fires once {@code start()} has succeeded on the player thread during
     * a resume. Enters PLAYING, runs the post-resume sequence, and
     * re-promotes the service to the foreground so the notification
     * returns to its protected state.
     */
    private void onPlaybackResumed() {
        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBaseElapsed = mPlaybackStartElapsed;

        acquireWakeLock();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();

        if (mNotificationService != null) {
            mNotificationService.startForegroundSync();
        }
    }

    /**
     * Requests a seek. During PREPARING, records the position; it is applied
     * when the transition's onPrepared fires.
     *
     * @param position The position to seek to in milliseconds
     */
    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {

                mPositionEpoch++;

                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player == null) return;
                    try { player.seekTo(position); } catch (Exception ignored) {}
                });

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed = SystemClock.elapsedRealtime();
                }

                savePlayerState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
            }
        });
    }

    // ========================================================================
    // Playlist
    // ========================================================================

    /**
     * Sets the current playlist. Resolves an anchor (pending path, then
     * current path, then saved path, then same-title fallback, then index 0)
     * and either preserves playback on the same song or re-enters
     * reconciliation to begin a transition.
     *
     * @param playlist The new playlist (sorted internally by the current
     *                 sort mode)
     * @param preserveCurrentSong If true, anchors on the current song when
     *                            possible
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) return;

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) { broadcastUpdate(); return; }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));

            if (mCurrentPlaylist != null
                && mCurrentPlaylist.size() == sortedPlaylist.size()
                && sameOrder(mCurrentPlaylist, sortedPlaylist)) {
                broadcastUpdate();
                return;
            }

            String anchorPath = mPendingSongPath;
            if (anchorPath == null) anchorPath = pathOf(mCurrentIndex);
            if (anchorPath == null) anchorPath = getSavedSongPath();

            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null && anchorPath.equals(candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mCurrentPlaylist = sortedPlaylist;

            int resolvedIndex = (anchorPath != null) ? indexOfPath(anchorPath) : -1;

            if (resolvedIndex < 0 && anchorSong != null && anchorSong.getTitle() != null) {
                for (int index = 0; index < sortedPlaylist.size(); index++) {
                    Song candidateSong = sortedPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }
            if (resolvedIndex < 0) resolvedIndex = 0;

            mPendingSongPath = null;

            if (mState == ServiceState.PREPARING) {
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            boolean sameSong = (resolvedIndex == mCurrentIndex)
                            && (mState == ServiceState.PLAYING
                                || mState == ServiceState.PAUSED
                                || mState == ServiceState.READY);

            mTargetIndex = resolvedIndex;

            if (sameSong) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) updateMediaSessionMetadata(currentSong, null);
                updateMediaSessionPlaybackState();
                createNotification();
                broadcastUpdate();
            } else {
                reconcile();
            }
        });
    }

    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    /**
     * Soft-updates the playlist, preserving the current song.
     *
     * @param newPlaylist The new playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    /**
     * Returns a copy of the current playlist.
     *
     * @return A copy of the current playlist, or an empty list when none
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) return new ArrayList<Song>();
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    /**
     * Checks if two playlists contain the same songs in the same order.
     *
     * @param firstPlaylist The first playlist
     * @param secondPlaylist The second playlist
     * @return True if the playlists match element by element
     */
    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) return false;
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null) ? firstSong.getPath() : null;
            String secondPath = (secondSong != null) ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ========================================================================
    // Pending Song Path
    // ========================================================================

    /**
     * Sets the pending song path to be played after a playlist update.
     *
     * @param path The file path of the song to play, or null to clear
     */
    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            mPendingSongPath = path;
            if (path != null) {
                Log.d(TAG, "Pending song path set: " + path);
                playPendingSongIfExists();
            } else {
                Log.d(TAG, "Pending song path cleared");
            }
        });
    }

    /**
     * Gets the pending song path.
     *
     * @return The pending song path, or null if none
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    /**
     * Clears the pending song path.
     */
    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    /**
     * Attempts to play the pending song if it is already present in the
     * current playlist.
     */
    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) return;
            int index = indexOfPath(mPendingSongPath);
            if (index >= 0) {
                mPendingSongPath = null;
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            }
        });
    }

    // ========================================================================
    // Getters and Mode Setters
    // ========================================================================

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return The current position, or 0 when unavailable
     */
    public int getCurrentPosition() {
        return estimateCurrentPosition();
    }

    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return The duration, or 0 when unavailable
     */
    public int getDuration() {
        return mCachedDuration;
    }

    /**
     * Checks if playback is currently active.
     *
     * @return True if the service is playing
     */
    public boolean isPlaying() {
        return mState == ServiceState.PLAYING;
    }

    /**
     * Returns the song the {@link MediaPlayer} is bound to.
     *
     * <p>{@code mCurrentIndex} is the only index this method consults.
     * During PREPARING it still refers to the outgoing song; the
     * destination song is not reported until {@code onPlaybackStarted}
     * commits PLAYING and advances {@code mCurrentIndex} to the target.
     * This keeps the activity, the notification, and the MediaSession
     * metadata describing the same song at every instant.</p>
     *
     * @return The current song, or null when none
     */
    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return null;
        if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return null;
        return mCurrentPlaylist.get(mCurrentIndex);
    }

    /**
     * Returns the current playlist index.
     *
     * @return The current index, or -1 when none
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() { return mRepeatMode; }

    /**
     * Sets the repeat mode. Touches only {@code mRepeatMode} and persists
     * it. No transition is triggered by the change.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() { return mIsShuffle; }

    /**
     * Sets shuffle mode. Touches only {@code mIsShuffle} and persists it.
     * The shuffle history is trimmed lazily inside
     * {@link #pickShuffleNext(int)} when it exceeds twice the playlist
     * size.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if a Bluetooth headset is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ========================================================================
    // Sort Mode
    // ========================================================================

    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ========================================================================
    // Notifications
    // ========================================================================

    /**
     * Updates the playback notification with the current song metadata,
     * album art, and playing state.
     *
     * <p>The song reported to the notification comes from
     * {@link #getCurrentSong()}, which consults {@code mCurrentIndex} only.
     * The notification therefore tracks the song the player is bound to,
     * not the target of an in-flight transition.</p>
     *
     * <p>The title, artist, and album art are handed to the notification in
     * the same main-thread iteration. The notification layer's scheduled-
     * update flag coalesces the two state changes into a single rebuild, so
     * the notification's text and its art commit together whenever the art
     * is already cached. When the art has not yet arrived, the title
     * commits alone and the placeholder fills the icon slot; the art is
     * pushed by {@link #prefetchNotificationArt(Song)}'s completion
     * callback when it is ready, for the same song.</p>
     */
    private void createNotification() {
        if (mNotificationService == null) return;

        Song notificationSong = null;
        if (mState == ServiceState.PLAYING
            || mState == ServiceState.PAUSED
            || mState == ServiceState.PREPARING
            || mState == ServiceState.READY) {
            notificationSong = getCurrentSong();
        }

        if (notificationSong != null) {
            final String path = notificationSong.getPath();

            mNotificationService.updateSongInfo(
                notificationSong.getTitle(),
                notificationSong.getArtist(),
                path);

            if (path != null) {
                Bitmap cachedArt = mArtCache.get(path);
                if (cachedArt != null && !cachedArt.isRecycled()) {
                    mNotificationService.setAlbumArt(cachedArt, null, path);
                    mNotificationArtPath = path;
                }
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationArtPath = null;
        }
        mNotificationService.setPlayingState(mState == ServiceState.PLAYING);
    }

    /**
     * Refreshes the playback notification.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            createNotification();
        }
    }

    // ========================================================================
    // Persistence
    // ========================================================================

    /**
     * Persists the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Saves the full player state.
     */
    private void saveFullState() {
        savePlayerState();
    }

    /**
     * Gets the saved playback position.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    /**
     * Checks whether playback was active before the last state save.
     *
     * @return True if playback was active
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    /**
     * Gets the saved song path.
     *
     * @return The saved song path, or null if none
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Persists the current playing index.
     */
    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Persists the playing state and position.
     */
    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    /**
     * Loads repeat mode and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }

    // ========================================================================
    // MediaPlayer Plumbing (player-thread only)
    // ========================================================================

    /**
     * Removes all listeners from a MediaPlayer.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }

    /**
     * Releases the MediaPlayer and nulls the field.
     */
    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
            try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            try { mMediaPlayer.release(); } catch (Exception ignored) {}
            mMediaPlayer = null;
        }
    }

    /**
     * Gets or creates the MediaPlayer instance.
     *
     * @return The MediaPlayer instance
     */
    @NonNull
    private MediaPlayer getOrCreatePlayerRaw() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    // ========================================================================
    // Playback Params
    // ========================================================================

    /**
     * Updates playback parameters (speed and pitch) from the
     * EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager equalizerManager = EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        final float finalTempo = tempo;
        final float finalSemitones = semitones;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;
            try {
                float pitch = (float) Math.pow(2.0, finalSemitones / 12.0);
                android.media.PlaybackParams playbackParams = player.getPlaybackParams();
                playbackParams.setSpeed(finalTempo);
                playbackParams.setPitch(pitch);
                player.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + finalTempo + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params", exception);
            }
        });
    }

    // ========================================================================
    // MediaSession
    // ========================================================================

    /**
     * Sets up the MediaSessionCompat for lock screen, headset, and
     * notification transport controls. The session is registered with the
     * system through {@code androidx.media.session.MediaButtonReceiver}
     * (declared in the manifest), which delivers all media button events to
     * the session callback regardless of entry point.
     *
     * <p>The session callback is the hot path for notification button taps
     * and hardware media keys. Each transport callback passes through
     * {@link #isNotificationActionDebounced(String)} before reaching the
     * request method, so a burst of taps on the notification's transport
     * buttons is bounded by the same window as a burst on the activity's
     * on-screen buttons. Cold-start intents in {@code onStartCommand}
     * share the same window through the same method.</p>
     */
    private void setupMediaSession() {
        try {
            ComponentName mediaButtonReceiver = new ComponentName(
                this, androidx.media.session.MediaButtonReceiver.class);
            mMediaSession = new MediaSessionCompat(
                this, "LlamaMusicService", mediaButtonReceiver, null);

            mMediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override public void onPlay() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> {
                        if (mState == ServiceState.PAUSED)     doResume();
                        else if (mState == ServiceState.IDLE)  resume();
                        else if (mState == ServiceState.READY) togglePlayPause();
                    });
                }
                @Override public void onPause() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> { if (mState == ServiceState.PLAYING) doPause(); });
                }
                @Override public void onSkipToNext() {
                    if (isNotificationActionDebounced("ACTION_NEXT")) return;
                    playNextSong();
                }
                @Override public void onSkipToPrevious() {
                    if (isNotificationActionDebounced("ACTION_PREV")) return;
                    playPreviousSong();
                }
                @Override public void onStop() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> { if (mState == ServiceState.PLAYING) doPause(); });
                }
                @Override public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId == null) return;
                    try { playSong(Integer.parseInt(mediaId)); }
                    catch (NumberFormatException ignored) {}
                }
            });

            mMediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    /**
     * Returns the active session token, or null if the session is not set
     * up. Used by {@link NotificationService} to bind the notification's
     * MediaStyle to the session so Wear OS, Android Auto, and the system
     * media controls surface pick up the correct transport.
     *
     * @return The session token, or null
     */
    @Nullable
    public MediaSessionCompat.Token getSessionToken() {
        return mMediaSession != null ? mMediaSession.getSessionToken() : null;
    }

    /**
     * Updates the MediaSession metadata.
     *
     * @param song The song whose metadata is displayed (can be null)
     * @param albumArt The album art bitmap to attach (can be null)
     */
    public void updateMediaSessionMetadata(@Nullable Song song, @Nullable Bitmap albumArt) {
        if (mMediaSession == null) return;
        try {
            MediaMetadataCompat.Builder builder = new MediaMetadataCompat.Builder();
            if (song != null) {
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE,  song.getTitle());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.getArtist());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM,  song.getAlbum());
                if (albumArt != null && !albumArt.isRecycled()) {
                    builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, albumArt);
                }
            } else {
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, "Llama Music Player");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "");
            }
            mMediaSession.setMetadata(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession metadata", exception);
        }
    }

    /**
     * Updates only the album art of the MediaSession metadata.
     *
     * @param albumArt The album art bitmap (can be null)
     */
    public void updateMediaSessionArt(@Nullable Bitmap albumArt) {
        updateMediaSessionMetadata(getCurrentSong(), albumArt);
    }

    /**
     * Updates the MediaSession playback state. Reflects the current playing
     * state, position, and supported actions.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null) return;
        try {
            long actions = PlaybackStateCompat.ACTION_PLAY
                         | PlaybackStateCompat.ACTION_PAUSE
                         | PlaybackStateCompat.ACTION_PLAY_PAUSE
                         | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                         | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackStateCompat.ACTION_STOP;
            int frameworkState = (mState == ServiceState.PLAYING)
                ? PlaybackStateCompat.STATE_PLAYING
                : PlaybackStateCompat.STATE_PAUSED;
            PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(frameworkState, getCurrentPosition(), 1.0f);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state", exception);
        }
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    /**
     * Sets up the audio focus request used by the service.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    /**
     * Requests audio focus.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    /**
     * Handles audio focus changes. Pauses on permanent or transient focus
     * loss. Does not auto-resume on gain; the user is expected to resume.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mState == ServiceState.PLAYING) doPause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
            case AudioManager.AUDIOFOCUS_GAIN:
            default:
                break;
        }
    }

    // ========================================================================
    // Media Button
    // ========================================================================

    /**
     * Handles media button events from Bluetooth headsets and hardware keys.
     * When a Bluetooth headset is connected, volume keys are mapped to
     * next and previous track controls.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) { playNextSong(); return; }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) { playPreviousSong(); return; }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: togglePlayPause(); break;
            case KeyEvent.KEYCODE_MEDIA_NEXT: playNextSong(); break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: playPreviousSong(); break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mState == ServiceState.PAUSED) doResume();
                else if (mState == ServiceState.IDLE) resume();
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mState == ServiceState.PLAYING) doPause();
                break;
            default: break;
        }
    }

    // ========================================================================
    // Broadcasts
    // ========================================================================

    /**
     * Broadcasts a full snapshot of playback state. Every field the
     * receiver needs to render a frame is carried here, so receivers never
     * have to query back into the service and race a subsequent transition.
     *
     * <p>Receivers MUST drop any UPDATE_PLAYER whose {@code generation} is
     * strictly less than the highest they have already processed. Equal is
     * accepted: position and duration advance within a generation.</p>
     *
     * <p>Two song paths are carried:</p>
     * <ul>
     *   <li>{@code song_path} — the bound player's song. During PREPARING
     *       this is still the outgoing song.</li>
     *   <li>{@code target_song_path} — the destination. Equal to
     *       {@code song_path} outside PREPARING.</li>
     * </ul>
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", mGeneration);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", mState == ServiceState.PLAYING);
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());
        sendBroadcast(intent);
    }

    /**
     * Broadcasts an audio session change event.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    // ========================================================================
    // Receivers
    // ========================================================================

    /**
     * Registers the notification refresh receiver.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    refreshNotification();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }

    /**
     * Registers the playback params receiver.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    /**
     * Registers the clear playlist receiver.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) stopCompletely();
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }

    /**
     * Registers the theme change receiver.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) createNotification();
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    /**
     * Registers the playing state query receiver.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response = new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", mState == ServiceState.PLAYING);
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit().putBoolean(KEY_LAST_PLAYING,
                            mState == ServiceState.PLAYING).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }

    /**
     * Registers the sort mode receiver.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) return;
                int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) return;
                mCurrentSortMode = newSortMode;
                saveSortMode();
                onMain(() -> {
                    if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
                    String anchorPath = pathOf(mCurrentIndex);
                    Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
                    if (anchorPath != null) {
                        int newIndex = indexOfPath(anchorPath);
                        if (newIndex >= 0) {
                            mCurrentIndex = newIndex;
                            saveCurrentPlayingIndex();
                        }
                    }
                    broadcastUpdate();
                });
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    /**
     * Registers the sync complete receiver.
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) return;
                ToastManager.hidePersistentOverlay();
                refreshNotification();
                broadcastUpdate();
            }
        };
        registerReceiver(mSyncCompleteReceiver, new IntentFilter("SYNC_COMPLETE"));
    }

    /**
     * Registers the genre update receiver.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(intent.getAction())) return;
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    createNotification();
                    broadcastUpdate();
                }
            }
        };
        registerReceiver(mGenreUpdateReceiver, new IntentFilter(ACTION_GENRE_UPDATE));
    }

    /**
     * Registers the soft update playlist receiver.
     */
    private void registerSoftUpdatePlaylistReceiver() {
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (intent == null || !"SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) return;

                if (mMusicLibrary == null) mMusicLibrary = new MusicLibrary(MusicService.this);
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiver(mSoftUpdatePlaylistReceiver, new IntentFilter("SOFT_UPDATE_PLAYLIST"));
    }

    /**
     * Registers the pending song receiver.
     */
    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) setPendingSongPath(path);
                }
            }
        };
        registerReceiver(mSetPendingSongReceiver, new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) return;
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    // ========================================================================
    // Genre and Metadata Updates
    // ========================================================================

    /**
     * Updates the genre for a specific song in the current playlist.
     * Refreshes the notification and media session metadata when the
     * updated song is the currently playing song.
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value
     */
    private void updateGenreInPlaylist(@NonNull String songPath, @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath) || TextUtils.isEmpty(newGenre)) return;
        if (mCurrentPlaylist == null) return;

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                    broadcastUpdate();

                    Song currentSong = getCurrentSong();
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        createNotification();
                        updateMediaSessionMetadata(currentSong, null);
                    }
                }
                break;
            }
        }
    }

    /**
     * Refreshes metadata for the currently playing song. Updates the
     * in-memory playlist entry, persists the change, and refreshes the
     * notification and media session.
     *
     * @param songPath The path of the song to update
     * @param newTitle The new title, or null for no change
     * @param newArtist The new artist, or null for no change
     * @param newAlbum The new album, or null for no change
     * @param newGenre The new genre, or null for no change
     * @param albumArtBytes The new album art bytes, or null for no change
     * @param albumArtRemoved True if the album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;

            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null || !songPath.equals(currentSong.getPath())) return;

            String finalTitle = (newTitle != null && !newTitle.isEmpty())
                ? newTitle : currentSong.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty())
                ? newArtist : currentSong.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty())
                ? newAlbum : currentSong.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty())
                ? newGenre : currentSong.getGenre();

            Song updatedSong = new Song(finalTitle, finalArtist, finalAlbum, finalGenre,
                songPath, currentSong.getDuration(), null);
            if (currentSong.getUri() != null) updatedSong.setUri(currentSong.getUri());

            mCurrentPlaylist.set(mCurrentIndex, updatedSong);
            SongDatabase.getInstance(this).insertSong(updatedSong);

            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        });
    }
}