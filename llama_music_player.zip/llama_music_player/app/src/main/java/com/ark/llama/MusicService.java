package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses Android's MediaPlayer for all audio playback, with
 * pitch and tempo control via MediaPlayer.PlaybackParams (API 23+).</p>
 * 
 * <h3>Pitch and Speed Ranges</h3>
 * <ul>
 *   <li><b>Pitch:</b> -6 to +6 semitones (controlled via EqualizerManager)</li>
 *   <li><b>Speed:</b> 0.5x to 1.5x speed (controlled via EqualizerManager)</li>
 * </ul>
 * 
 * <h3>Sort Modes</h3>
 * <p>The service supports 10 sort modes for playlist ordering:</p>
 * <ul>
 *   <li>0 - Title A-Z (ascending alphabetical by title)</li>
 *   <li>1 - Title Z-A (descending alphabetical by title)</li>
 *   <li>2 - Artist A-Z (ascending alphabetical by artist)</li>
 *   <li>3 - Artist Z-A (descending alphabetical by artist)</li>
 *   <li>4 - Album A-Z (ascending alphabetical by album)</li>
 *   <li>5 - Album Z-A (descending alphabetical by album)</li>
 *   <li>6 - Genre A-Z (ascending alphabetical by genre)</li>
 *   <li>7 - Genre Z-A (descending alphabetical by genre)</li>
 *   <li>8 - Oldest First (by file modification date)</li>
 *   <li>9 - Newest First (by file modification date)</li>
 * </ul>
 * 
 * <h3>Playback State Persistence</h3>
 * <p>The service saves the following to SharedPreferences:</p>
 * <ul>
 *   <li>Current song index</li>
 *   <li>Current playback position</li>
 *   <li>Playing state (playing/paused)</li>
 *   <li>Repeat mode</li>
 *   <li>Shuffle mode</li>
 *   <li>Last song path</li>
 *   <li>Sort mode</li>
 * </ul>
 * 
 * @see MediaPlayer
 * @see EqualizerManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.0
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Broadcast action for genre update events during genre loading phase. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";
    
    /** Broadcast action for setting a pending song path from external sources. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";
    
    /** Delay for song transitions in milliseconds. */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Intent action for audio session changed broadcast. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    
    /** Maximum time in milliseconds without progress before recovery. */
    private static final int MAX_STALL_TIME_MS = 5000;
    
    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Maximum retry attempts for pending song playback. */
    private static final int MAX_PENDING_RETRY_ATTEMPTS = 5;
    
    /** Retry delay base in milliseconds for pending song playback. */
    private static final int PENDING_RETRY_DELAY_MS = 500;
    
    // ========================================================================
    // Sort Mode Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // MediaPlayer Members
    // ========================================================================
    
    /** MediaPlayer instance for audio playback. */
    private MediaPlayer mMediaPlayer;
    
    // ========================================================================
    // Playback State
    // ========================================================================
    
    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song. */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Timestamp when current playback started (for health checks). */
    private long mPlaybackStartTime = 0;
    
    // ========================================================================
    // Sort Mode State
    // ========================================================================
    
    /** Current sort mode for playlist display. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Health Check Components
    // ========================================================================
    
    /** Handler for periodic health checks. */
    private Handler mHealthHandler;
    
    /** Runnable for health check. */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts for current song. */
    private int mRecoveryAttempts = 0;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    /** WakeLock to prevent device sleep during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    /** Audio manager for focus management. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for API 26+. */
    private AudioFocusRequest mAudioFocusRequest;
    
    // ========================================================================
    // Media Session
    // ========================================================================
    
    /** MediaSession for lock screen and headset controls. */
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    /** Lock object for MediaPlayer operations. */
    private final Object mPlayerLock = new Object();
    
    /** Flag indicating if a song transition is in progress. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if a song is being prepared. */
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    
    /** Global preparation ID counter for async operation cancellation. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID (used to ignore stale callbacks). */
    private volatile int mCurrentPrepId = -1;
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    /** History of shuffled indices (for prev/next in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft update. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Pending Song Path for Incoming Files
    // ========================================================================
    
    /**
     * Path of a song that was added as a loose track and should be played
     * when the playlist update completes. This is set by MusicPlayer when
     * handling incoming files and cleared after playback starts.
     */
    private volatile String mPendingSongPath = null;
    
    /** Retry count for pending song playback. */
    private int mPendingRetryCount = 0;
    
    /** Handler for pending song retries. */
    private final Handler mPendingRetryHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for pending song retry. */
    private Runnable mPendingRetryRunnable = null;
    
    // ========================================================================
    // Music Library Reference
    // ========================================================================
    
    /** Music library manager for song data. */
    private MusicLibrary mMusicLibrary;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for sync notification updates. */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates. */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clear playlist commands. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for getting playing state. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates. */
    private BroadcastReceiver mSortModeReceiver;
    
    /** Receiver for sync completion – reloads playlist automatically. */
    private BroadcastReceiver mSyncCompleteReceiver;
    
    /** Receiver for genre updates from Phase 2 loading. */
    private BroadcastReceiver mGenreUpdateReceiver;
    
    /** Receiver for SOFT_UPDATE_PLAYLIST broadcast (targeted playlist updates). */
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    
    /** Receiver for setting pending song path from external sources. */
    private BroadcastReceiver mSetPendingSongReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * Allows activities to obtain a reference to the service.
     */
    public class LocalBinder extends Binder {
        
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes
    // ========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     */
    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     */
    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title.
     */
    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title.
     */
    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by oldest first (by file date), then by title.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by newest first (by file date), then by title.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    /**
     * Sets the player state before update flag.
     * Used to preserve playback state during folder updates.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID.
     * Used by EqualizerActivity to attach to the correct audio session.
     *
     * @return The current audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Pending Song Path Management
    // ========================================================================
    
    /**
     * Sets the pending song path to be played after a playlist update.
     * This is used when a loose track is added via MusicPlayer.handleIncomingFile().
     *
     * @param path The file path of the song to play
     */
    public void setPendingSongPath(@Nullable String path) {
        mPendingSongPath = path;
        mPendingRetryCount = 0;
        cancelPendingRetry();
        if (path != null) {
            Log.d(TAG, "Pending song path set: " + path);
            // Try to play it immediately if it's already in the playlist
            playPendingSongIfExists();
        } else {
            Log.d(TAG, "Pending song path cleared");
        }
    }
    
    /**
     * Gets the pending song path.
     *
     * @return The pending song path, or null if none
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }
    
    /**
     * Clears the pending song path.
     */
    public void clearPendingSongPath() {
        mPendingSongPath = null;
        mPendingRetryCount = 0;
        cancelPendingRetry();
        Log.d(TAG, "Pending song path cleared");
    }
    
    /**
     * Attempts to play the pending song if it exists in the current playlist.
     * This method is called after playlist updates to ensure pending songs are played.
     */
    public void playPendingSongIfExists() {
        if (mPendingSongPath == null) {
            return;
        }
        
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "Playlist empty, pending song will be played on next update");
            return;
        }
        
        String pendingPath = mPendingSongPath;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            Song song = mCurrentPlaylist.get(i);
            if (song != null && pendingPath.equals(song.getPath())) {
                Log.d(TAG, "Found pending song in playlist, playing at index: " + i);
                clearPendingSongPath();
                playSong(i);
                return;
            }
        }
        
        // Song not found yet - schedule retry
        Log.d(TAG, "Pending song not found in playlist, scheduling retry");
        schedulePendingRetry();
    }
    
    /**
     * Schedules a retry for pending song playback with exponential backoff.
     */
    private void schedulePendingRetry() {
        if (mPendingSongPath == null || mPendingRetryCount >= MAX_PENDING_RETRY_ATTEMPTS) {
            if (mPendingRetryCount >= MAX_PENDING_RETRY_ATTEMPTS) {
                Log.w(TAG, "Max retry attempts reached for pending song, giving up");
                clearPendingSongPath();
            }
            return;
        }
        
        cancelPendingRetry();
        mPendingRetryCount++;
        long delay = PENDING_RETRY_DELAY_MS * mPendingRetryCount;
        
        mPendingRetryRunnable = new Runnable() {
            @Override
            public void run() {
                if (mPendingSongPath != null) {
                    Log.d(TAG, "Retry " + mPendingRetryCount + " for pending song");
                    playPendingSongIfExists();
                }
            }
        };
        mPendingRetryHandler.postDelayed(mPendingRetryRunnable, delay);
        Log.d(TAG, "Scheduled pending retry " + mPendingRetryCount + " in " + delay + "ms");
    }
    
    /**
     * Cancels any pending retry for pending song playback.
     */
    private void cancelPendingRetry() {
        if (mPendingRetryRunnable != null) {
            mPendingRetryHandler.removeCallbacks(mPendingRetryRunnable);
            mPendingRetryRunnable = null;
        }
    }
    
    // ========================================================================
    // Force Clear Transition State
    // ========================================================================
    
    /**
     * Forces the service out of a transition state if stuck.
     * Used when playing incoming files to ensure the player is responsive.
     */
    public void forceClearTransitionState() {
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        invalidateAllPreparations();
        Log.d(TAG, "Transition state force-cleared");
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * Initializes all components including MediaSession, audio focus, and notifications.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup media session for lock screen controls
        setupMediaSession();
        
        // Initialize EqualizerManager singleton
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        // Setup audio focus
        setupAudioFocus();
        
        // Initialize health check handler
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Register broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerSoftUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();
        
        // Initialize MusicLibrary
        mMusicLibrary = new MusicLibrary(this);
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Called when the service is started via startService().
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and saves playback state.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        cancelPendingRetry();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        synchronized (mPlayerLock) {
            if (mIsPlaying && mMediaPlayer != null) {
                try {
                    if (!mMediaPlayer.isPlaying()) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                } catch (IllegalStateException e) {
                    Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                    int currentPos = getCurrentPosition();
                    prepareAndPlay(mCurrentIndex, currentPos);
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new TitleAZComparator();
            case SORT_TITLE_ZA:
                return new TitleZAComparator();
            case SORT_ARTIST_AZ:
                return new ArtistAZComparator();
            case SORT_ARTIST_ZA:
                return new ArtistZAComparator();
            case SORT_ALBUM_AZ:
                return new AlbumAZComparator();
            case SORT_ALBUM_ZA:
                return new AlbumZAComparator();
            case SORT_GENRE_AZ:
                return new GenreAZComparator();
            case SORT_GENRE_ZA:
                return new GenreZAComparator();
            case SORT_OLDEST:
                return new OldestFirstComparator();
            case SORT_NEWEST:
                return new NewestFirstComparator();
            default:
                return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return;
        }
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) {
                currentSongPath = currentSong.getPath();
            }
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                Log.d(TAG, "Current song repositioned to index: " + newIndex);
            }
        }
        
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers the notification receiver for sync updates.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    /**
     * Registers the clear playlist receiver.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    /**
     * Registers the theme color change receiver.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the receiver for getting playing state.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    /**
     * Registers the sort mode update receiver.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    /**
     * Registers the sync completion receiver – reloads playlist automatically.
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                    // Reload playlist from database after sync
                    MusicLibrary library = new MusicLibrary(MusicService.this);
                    ArrayList<Song> allSongs = library.getAllSongs();
                    setPlaylist(allSongs, true);
                    // Force prepare first song to create audio session
                    if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                        // If we have songs but no audio session, prepare the first song
                        if (sCurrentAudioSessionId == 0) {
                            Log.d(TAG, "No audio session, preparing first song");
                            prepareOnly(0);
                        }
                        // Ensure current index is valid
                        if (mCurrentIndex == -1) {
                            mCurrentIndex = 0;
                            saveCurrentPlayingIndex();
                        }
                    }
                    // Refresh notification
                    createNotification();
                    broadcastUpdate();
                    Log.d(TAG, "Playlist reloaded after SYNC_COMPLETE, song count: " + 
                          (mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0) +
                          ", audio session: " + sCurrentAudioSessionId);
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("SYNC_COMPLETE");
        registerReceiver(mSyncCompleteReceiver, filter);
    }
    
    /**
     * Registers the genre update broadcast receiver.
     * Updates the in-memory playlist when a song's genre is loaded from ID3 tags.
     * This enables real-time genre display without requiring app restart.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_GENRE_UPDATE.equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");
                    
                    if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String newGenre = intent.getStringExtra("genre");
                        
                        if (songPath != null && newGenre != null) {
                            updateGenreInPlaylist(songPath, newGenre);
                        }
                    } else if ("COMPLETE".equals(status)) {
                        // Refresh notification after all genres are loaded
                        createNotification();
                        broadcastUpdate();
                        Log.d(TAG, "Genre loading complete, notification refreshed");
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_GENRE_UPDATE);
        registerReceiver(mGenreUpdateReceiver, filter);
    }
    
    /**
     * Registers the set pending song receiver.
     * This receiver allows external components to set a pending song path.
     */
    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(intent.getAction())) {
                    String songPath = intent.getStringExtra("song_path");
                    if (songPath != null) {
                        Log.d(TAG, "SET_PENDING_SONG received: " + songPath);
                        setPendingSongPath(songPath);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_SET_PENDING_SONG);
        registerReceiver(mSetPendingSongReceiver, filter);
    }
    
    // ========================================================================
    // SOFT_UPDATE_PLAYLIST Receiver
    // ========================================================================
    
    /**
     * Registers the SOFT_UPDATE_PLAYLIST receiver.
     * This receiver handles targeted playlist updates (e.g., when a loose track is added)
     * and preserves the current song when possible.
     * 
     * <p>The pending song path is handled directly by setPlaylist(), which checks
     * for it FIRST when determining which song to play after the playlist update.</p>
     * 
     * <p>This receiver now respects the preserve_current_song flag passed from
     * StorageObserver to prevent playback interruption during auto-sync.</p>
     */
    private void registerSoftUpdatePlaylistReceiver() {
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    Log.d(TAG, "SOFT_UPDATE_PLAYLIST received - refreshing playlist");
                    
                    // Refresh MusicLibrary to get latest songs (including new loose track)
                    if (mMusicLibrary == null) {
                        mMusicLibrary = new MusicLibrary(MusicService.this);
                    }
                    mMusicLibrary.refreshCache();
                    
                    // Get preserve_current_song flag from intent
                    // Default is true for backward compatibility
                    boolean preserveCurrentSong = intent.getBooleanExtra("preserve_current_song", true);
                    
                    final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                    if (allSongs != null && !allSongs.isEmpty()) {
                        // Use the preserveCurrentSong flag from intent
                        setPlaylist(allSongs, preserveCurrentSong);
                        
                        // Broadcast UI updates
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                broadcastUpdate();
                                updateMediaSessionPlaybackState();
                                createNotification();
                            }
                        });
                    } else {
                        Log.d(TAG, "SOFT_UPDATE_PLAYLIST: No songs found, clearing playlist");
                        setPlaylist(null, false);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("SOFT_UPDATE_PLAYLIST");
        registerReceiver(receiver, filter);
        mSoftUpdatePlaylistReceiver = receiver;
    }
    
    /**
     * Updates the genre for a specific song in the in-memory playlist.
     * This method is called when a genre is loaded from ID3 tags during Phase 2
     * (the background genre loading phase). It ensures the service's playlist
     * stays in sync with the database without requiring a full playlist reload.
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value from ID3 tags
     */
    private void updateGenreInPlaylist(@NonNull String songPath, @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath) || TextUtils.isEmpty(newGenre)) {
            return;
        }
        
        // Update main playlist
        if (mCurrentPlaylist != null) {
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && songPath.equals(song.getPath())) {
                    String oldGenre = song.getGenre();
                    if (!newGenre.equals(oldGenre)) {
                        song.setGenre(newGenre);
                        Log.d(TAG, "Updated genre in playlist: " + song.getTitle() + " -> " + newGenre);
                        
                        // Notify any bound activities of the change
                        broadcastUpdate();
                        
                        // Update notification if this is the current song
                        Song currentSong = getCurrentSong();
                        if (currentSong != null && songPath.equals(currentSong.getPath())) {
                            createNotification();
                            updateMediaSessionMetadata(currentSong, null);
                        }
                    }
                    break;
                }
            }
        }
        
        // Also update loose songs playlist if applicable
        if (mPendingPlaylist != null) {
            for (Song song : mPendingPlaylist) {
                if (song != null && songPath.equals(song.getPath())) {
                    String oldGenre = song.getGenre();
                    if (!newGenre.equals(oldGenre)) {
                        song.setGenre(newGenre);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // MediaPlayer Management
    // ========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
        }
    }
    
    /**
     * Safely resets the MediaPlayer.
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on media player release");
            }
            
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) {
                }
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparing.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            Log.d(TAG, "Attempting recovery from error - resetting player");
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     *
     * @return True if the player is ready
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
    
    // ========================================================================
    // Health Check Methods
    // ========================================================================
    
    /**
     * Starts the playback health monitoring.
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) {
            mHealthHandler = new Handler(Looper.getMainLooper());
        }
        
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        
        Log.d(TAG, "Health monitoring started");
    }
    
    /**
     * Stops the playback health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition + 
                          ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying) {
                    mMediaPlayer.pause();
                }
            } catch (Exception ignored) {}
            
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && 
                    currentIndex < mCurrentPlaylist.size()) {
                    Log.d(TAG, "Restarting playback at index " + currentIndex);
                    prepareAndPlay(currentIndex, currentPosition);
                    
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }
    
    // ========================================================================
    // Async Operation Management
    // ========================================================================
    
    /**
     * Invalidates all pending preparations.
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock.
     *
     * @return True if the lock was acquired
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates and updates the playback notification.
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    /**
     * Refreshes the notification.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            
            if (art != null && !art.isRecycled()) {
                safeArt = art;
            }
            if (placeholder != null && !placeholder.isRecycled()) {
                safePlaceholder = placeholder;
            }
            
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state.
     */
    private void saveFullState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_CURRENT_POSITION, getCurrentPosition());
        editor.putBoolean(KEY_LAST_PLAYING, mIsPlaying);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        if (getCurrentSong() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }
        editor.apply();
    }
    
    /**
     * Gets the saved playback position.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before restart.
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path.
     *
     * @return The saved song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Returns the current playlist.
     *
     * @return A copy of the current playlist (or empty list if none)
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) {
            return new ArrayList<Song>();
        }
        return new ArrayList<Song>(mCurrentPlaylist);
    }
    
    // ========================================================================
    // setPlaylist() - Preserves playback seamlessly
    // ========================================================================
    
    /**
     * Sets the current playlist.
     *
     * <p>This method checks for a pending song path FIRST when determining
     * which song to play after a playlist update. This ensures that incoming
     * files (loose tracks) are played automatically when added.</p>
     * 
     * <p><b>CRITICAL:</b> The currently playing song is NEVER interrupted.
     * If the same song is in the new playlist, playback continues seamlessly
     * without any gap or position loss. If the song changed naturally during
     * the update (e.g., song ended), the new song is preserved.</p>
     *
     * @param playlist The new playlist
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        // Safety check: If playlist is null or empty but we have existing songs,
        // this might be a temporary state - don't clear prematurely
        if ((playlist == null || playlist.isEmpty()) && 
            mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            Log.w(TAG, "setPlaylist called with empty playlist but current playlist has songs - ignoring to prevent data loss");
            broadcastUpdate();
            return;
        }
        
        synchronized (mPlayerLock) {
            // ================================================================
            // Step 1: Capture the CURRENT playback state at this exact moment
            // ================================================================
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            String currentSongTitle = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                // Get current position from active player
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    currentSongPath = currentSong.getPath();
                    currentSongTitle = currentSong.getTitle();
                }
                
                // Save to SharedPreferences
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Captured playback state: " + currentSongPath + " at " + currentPosition + "ms, playing=" + wasPlaying);
            }
            
            // ================================================================
            // Step 2: Handle empty playlist
            // ================================================================
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                Intent updateIntent = new Intent("UPDATE_PLAYER");
                updateIntent.putExtra("current_index", -1);
                updateIntent.putExtra("is_playing", false);
                sendBroadcast(updateIntent);
                return;
            }
            
            // ================================================================
            // Step 3: Sort the new playlist
            // ================================================================
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // ================================================================
            // Step 4: Check if playlist is actually different (optimization)
            // ================================================================
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                boolean same = true;
                for (int i = 0; i < playlist.size(); i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    Log.d(TAG, "Playlist unchanged - no action needed");
                    broadcastUpdate();
                    return;
                }
            }
            
            // ================================================================
            // Step 5: Find the target song - WITH REAL-TIME CHECK
            // ================================================================
            int newIndex = -1;
            String targetPath = null;
            boolean isSameSong = false;
            boolean currentSongRemoved = false;
            
            if (preserveCurrentSong) {
                // ============================================================
                // CRITICAL: Check what the MediaPlayer is ACTUALLY playing NOW
                // The song may have changed naturally (e.g., song ended)
                // ============================================================
                String actualCurrentPath = null;
                String actualCurrentTitle = null;
                int actualCurrentPosition = 0;
                boolean actualWasPlaying = false;
                
                // Get the ACTUAL current song from MediaPlayer
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        actualCurrentPosition = mMediaPlayer.getCurrentPosition();
                        actualWasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        // Ignore
                    }
                }
                
                // Get the actual song from the current playlist
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    Song actualSong = mCurrentPlaylist.get(mCurrentIndex);
                    if (actualSong != null) {
                        actualCurrentPath = actualSong.getPath();
                        actualCurrentTitle = actualSong.getTitle();
                    }
                }
                
                // If the actual current song is different from what we captured,
                // the song changed naturally during the update
                if (actualCurrentPath != null && !actualCurrentPath.equals(currentSongPath)) {
                    Log.d(TAG, "Song changed naturally during update: " + 
                          currentSongPath + " -> " + actualCurrentPath);
                    currentSongPath = actualCurrentPath;
                    currentSongTitle = actualCurrentTitle;
                    currentPosition = actualCurrentPosition;
                    wasPlaying = actualWasPlaying;
                }
                
                // ============================================================
                // PRIORITY 1: Check for pending song path (incoming file)
                // ============================================================
                String pendingPath = getPendingSongPath();
                if (pendingPath != null) {
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(pendingPath)) {
                            newIndex = i;
                            targetPath = pendingPath;
                            isSameSong = false;
                            Log.d(TAG, "Found pending song in playlist at index: " + i);
                            break;
                        }
                    }
                    if (newIndex == -1) {
                        Log.w(TAG, "Pending song not found in playlist: " + pendingPath);
                    }
                }
                
                // ============================================================
                // PRIORITY 2: Current song (may have changed naturally)
                // ============================================================
                if (newIndex == -1 && currentSongPath != null) {
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentSongPath)) {
                            newIndex = i;
                            targetPath = currentSongPath;
                            isSameSong = true;
                            Log.d(TAG, "Current song found in new playlist at index: " + i);
                            break;
                        }
                    }
                }
                
                // ============================================================
                // PRIORITY 3: Fallback to saved path
                // ============================================================
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                targetPath = savedPath;
                                isSameSong = false;
                                Log.d(TAG, "Saved song found in playlist at index: " + i);
                                break;
                            }
                        }
                    }
                }
                
                // Check if the current song was removed
                if (newIndex == -1 && currentSongPath != null) {
                    currentSongRemoved = true;
                    Log.d(TAG, "Current song was removed from playlist: " + currentSongPath);
                }
            }
            
            // ================================================================
            // Step 6: Determine if we need to reset the player
            // ================================================================
            boolean needsPlayerReset = false;
            
            if (currentSongRemoved) {
                // Current song was removed - need to play a different song
                needsPlayerReset = true;
                Log.d(TAG, "Song removed - need to reset player");
            } else if (newIndex >= 0 && currentSongPath != null) {
                // Check if the song at newIndex is the same file
                String newPath = sortedPlaylist.get(newIndex).getPath();
                if (!newPath.equals(currentSongPath)) {
                    // Different song - need to reset
                    needsPlayerReset = true;
                    Log.d(TAG, "Different song at index - need to reset player");
                } else {
                    // SAME SONG - DO NOT RESET
                    needsPlayerReset = false;
                    isSameSong = true;
                    Log.d(TAG, "SAME SONG continues - NO player reset!");
                }
            } else if (newIndex == -1 && !sortedPlaylist.isEmpty()) {
                // No valid index found, default to first song
                needsPlayerReset = true;
                Log.d(TAG, "No valid index - need to reset to first song");
            }
            
            // ================================================================
            // Step 7: Reset player ONLY if needed
            // ================================================================
            if (needsPlayerReset) {
                Log.d(TAG, "Resetting player for song change");
                resetPlayerSafely();
                mIsPlaying = false;
            }
            
            // ================================================================
            // Step 8: Replace the playlist
            // ================================================================
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            // ================================================================
            // Step 9: Set the current index
            // ================================================================
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                Log.d(TAG, "Current index set to: " + newIndex);
            } else if (preserveCurrentSong && currentSongRemoved && !sortedPlaylist.isEmpty()) {
                // Current song removed - find replacement
                int replacementIndex = 0;
                if (currentSongTitle != null && !TextUtils.isEmpty(currentSongTitle)) {
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        Song song = sortedPlaylist.get(i);
                        if (song != null && currentSongTitle.equals(song.getTitle())) {
                            replacementIndex = i;
                            break;
                        }
                    }
                }
                mCurrentIndex = replacementIndex;
                Log.d(TAG, "Current song removed, defaulting to index: " + replacementIndex);
            } else if (!sortedPlaylist.isEmpty()) {
                mCurrentIndex = 0;
                Log.d(TAG, "Defaulting to index 0");
            } else {
                mCurrentIndex = -1;
                Log.w(TAG, "No songs in playlist");
            }
            
            // Validate index bounds
            if (mCurrentIndex >= sortedPlaylist.size()) {
                mCurrentIndex = sortedPlaylist.isEmpty() ? -1 : 0;
            }
            
            saveCurrentPlayingIndex();
            
            // ================================================================
            // Step 10: Resume playback WITHOUT interruption if same song
            // ================================================================
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            // Check for pending song
            String pendingPathAfter = getPendingSongPath();
            boolean shouldPlayPending = pendingPathAfter != null && 
                                       mCurrentIndex >= 0 && 
                                       mCurrentIndex < mCurrentPlaylist.size() &&
                                       pendingPathAfter.equals(mCurrentPlaylist.get(mCurrentIndex).getPath());
            
            if (shouldPlayPending) {
                // Play pending song
                clearPendingSongPath();
                if (mIsPreparing.get()) {
                    invalidateAllPreparations();
                    mIsPreparing.set(false);
                }
                if (mIsTransitioning.get()) {
                    mIsTransitioning.set(false);
                }
                if (mMediaPlayer != null) {
                    releaseMediaPlayer();
                }
                prepareAndPlay(mCurrentIndex, 0);
                
            } else if (isSameSong && !needsPlayerReset && mCurrentIndex >= 0 && 
                       mCurrentIndex < mCurrentPlaylist.size()) {
                // ============================================================
                // SAME SONG - RESUME SEAMLESSLY WITHOUT INTERRUPTION
                // ============================================================
                Log.d(TAG, "SAME SONG - Resuming seamlessly at position: " + savedPosition);
                
                // The player is already playing the correct song
                // Just ensure the state is correct
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        // Check if we're at the right position
                        int currentPos = mMediaPlayer.getCurrentPosition();
                        if (Math.abs(currentPos - savedPosition) > 1000) {
                            // Only seek if we're significantly off
                            mMediaPlayer.seekTo(savedPosition);
                            Log.d(TAG, "Adjusted position from " + currentPos + " to " + savedPosition);
                        }
                        
                        // Ensure playing state matches what it was before
                        if (wasPlayingBefore || wasPlaying) {
                            if (!mIsPlaying) {
                                mMediaPlayer.start();
                                mIsPlaying = true;
                                Log.d(TAG, "Resumed playback");
                            }
                        } else {
                            if (mIsPlaying) {
                                mMediaPlayer.pause();
                                mIsPlaying = false;
                                Log.d(TAG, "Paused playback (was paused before)");
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to resume seamlessly", e);
                        // Fallback: prepare and play
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                } else {
                    // Player not ready - prepare and play
                    prepareAndPlay(mCurrentIndex, savedPosition);
                }
                
                // Update MediaSession with current song
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    updateMediaSessionMetadata(currentSong, null);
                }
                updateMediaSessionPlaybackState();
                createNotification();
                broadcastUpdate();
                
            } else if (wasPlayingBefore && mCurrentIndex >= 0 && 
                       mCurrentIndex < mCurrentPlaylist.size()) {
                // Different song - prepare and play
                Log.d(TAG, "Different song - preparing with saved position: " + savedPosition);
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    if (correctIndex >= 0 && correctIndex < mCurrentPlaylist.size()) {
                        prepareAndPlay(correctIndex, savedPosition);
                    } else if (!mCurrentPlaylist.isEmpty()) {
                        prepareAndPlay(0, 0);
                    }
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    prepareAndPlay(mCurrentIndex, savedPosition);
                }
            } else if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                // No playback requested, but prepare the song
                if (mMediaPlayer == null || !isPlayerReady()) {
                    Log.d(TAG, "Preparing song without playing");
                    prepareOnly(mCurrentIndex);
                }
                mIsPlaying = false;
                createNotification();
            }
            
            // ================================================================
            // Step 11: Final UI update
            // ================================================================
            Intent updateIntent = new Intent("UPDATE_PLAYER");
            updateIntent.putExtra("current_index", mCurrentIndex);
            updateIntent.putExtra("is_playing", mIsPlaying);
            sendBroadcast(updateIntent);
            
            // Check for pending song
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                playPendingSongIfExists();
            }
            
            broadcastUpdate();
            Log.d(TAG, "setPlaylist complete - index=" + mCurrentIndex + 
                  ", isPlaying=" + mIsPlaying + ", sameSong=" + isSameSong);
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        cancelPendingRetry();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on stop");
            }
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) {
                mNotificationService.stopForeground();
            }
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        
        // Ensure UI reflects empty state
        Intent updateIntent = new Intent("UPDATE_PLAYER");
        updateIntent.putExtra("current_index", -1);
        updateIntent.putExtra("is_playing", false);
        sendBroadcast(updateIntent);
    }
    
    /**
     * Soft updates the playlist.
     *
     * @param newPlaylist The new playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The song index
     */
    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        
        // Validate index
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.w(TAG, "playSong called with invalid index: " + index);
            // Try to recover by playing first song if playlist exists
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "Attempting recovery - playing first song");
                index = 0;
            } else {
                // No songs available - update UI and return
                mIsPlaying = false;
                broadcastUpdate();
                createNotification();
                return;
            }
        }
        
        // If we're transitioning, queue the song
        if (mIsTransitioning.get()) {
            Log.d(TAG, "Transition in progress, queueing song at index " + index);
            final int finalIndex = index;
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsTransitioning.get()) {
                        playSong(finalIndex);
                    } else {
                        // If still transitioning after delay, force reset
                        Log.w(TAG, "Transition stuck, forcing reset and playing");
                        mIsTransitioning.set(false);
                        if (mIsPreparing.get()) {
                            invalidateAllPreparations();
                            mIsPreparing.set(false);
                        }
                        playSong(finalIndex);
                    }
                }
            }, SONG_TRANSITION_DELAY_MS);
            return;
        }
        
        // If preparing, invalidate and start fresh
        if (mIsPreparing.get()) {
            invalidateAllPreparations();
            mIsPreparing.set(false);
        }
        
        prepareAndPlay(index, 0);
    }
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     *
     * @param index The song index
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        // Validate index before proceeding
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.e(TAG, "prepareAndPlay called with invalid index: " + index);
            mIsPlaying = false;
            // Try to recover
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "Attempting to recover - playing first song");
                prepareAndPlay(0, 0);
            } else {
                broadcastUpdate();
                createNotification();
                // Ensure UI shows disabled state
                Intent updateIntent = new Intent("UPDATE_PLAYER");
                updateIntent.putExtra("current_index", -1);
                updateIntent.putExtra("is_playing", false);
                sendBroadcast(updateIntent);
            }
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        // Stop current playback gracefully
        stopHealthMonitoring();
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        mIsPlaying = false;
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            // Release and recreate player for clean state
            releaseMediaPlayer();
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                mIsPlaying = false;
                broadcastUpdate();
                createNotification();
                return;
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration: " + duration);
                                mIsPlaying = false;
                                broadcastUpdate();
                                return;
                            }
                            
                            if (finalSeek > 0 && finalSeek < duration - 500) {
                                mp.seekTo(finalSeek);
                            }
                            
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mCurrentIndex = finalIndex;
                            saveCurrentPlayingIndex();
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired");
                            }
                            
                            // Update MediaSession metadata with current song
                            updateMediaSessionMetadata(song, null);
                            
                            updateMediaSessionPlaybackState();
                            broadcastUpdate();
                            createNotification();
                            updatePlaybackParams();
                            
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying = false;
                            broadcastUpdate();
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
            broadcastUpdate();
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
            broadcastUpdate();
        }
    }
    
    /**
     * Prepares a song without starting playback.
     * 
     * <p>This method creates an audio session for the equalizer but does not
     * start playback. It is used to initialize the audio system after a playlist
     * update so that the equalizer can attach before the user presses play.</p>
     *
     * @param index The song index
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.e(TAG, "prepareOnly called with invalid index: " + index);
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance in prepareOnly, ignoring");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            // Update MediaSession metadata even when prepared without playing
                            updateMediaSessionMetadata(song, null);
                            
                            Log.d(TAG, "Song prepared without playing, audio session: " + sCurrentAudioSessionId);
                            
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source in prepareOnly", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state in prepareOnly", e);
            mIsPreparing.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        prepareAndPlay(index, position);
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     * If the song is not found in the playlist, sets it as pending.
     *
     * @param filePath The file path of the song
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) {
            Log.w(TAG, "Cannot play song by path - playlist is null, setting as pending");
            setPendingSongPath(filePath);
            return;
        }
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                // Clear any stuck states before playing
                if (mIsTransitioning.get()) {
                    mIsTransitioning.set(false);
                }
                if (mIsPreparing.get()) {
                    invalidateAllPreparations();
                    mIsPreparing.set(false);
                }
                playSong(i);
                return;
            }
        }
        Log.w(TAG, "Song not found in playlist: " + filePath + " - setting as pending");
        setPendingSongPath(filePath);
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause.
     */
    public void togglePlayPause() {
        if (mMediaPlayer != null && mCurrentIndex >= 0) {
            if (mIsPlaying) {
                pause();
            } else {
                resume();
            }
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
            // We have a playlist and valid index, but no MediaPlayer - prepare and play
            Log.d(TAG, "No MediaPlayer but playlist exists, preparing and playing");
            playSong(mCurrentIndex);
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            // We have a playlist but index is invalid, play first song
            Log.d(TAG, "No valid index, playing first song");
            mCurrentIndex = 0;
            saveCurrentPlayingIndex();
            playSong(0);
        } else {
            // No songs - update UI to show disabled state
            mIsPlaying = false;
            broadcastUpdate();
            createNotification();
            Intent updateIntent = new Intent("UPDATE_PLAYER");
            updateIntent.putExtra("current_index", -1);
            updateIntent.putExtra("is_playing", false);
            sendBroadcast(updateIntent);
        }
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try {
                    mMediaPlayer.pause();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot pause - invalid state", e);
                }
                mIsPlaying = false;
                
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on pause");
                }
                
                savePlayingState();
                savePlayerState();
                saveFullState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                createNotification();
            }
        }
    }
    
    /**
     * Resumes playback.
     */
    public void resume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    if (!mIsPlaying) {
                        requestAudioFocus();
                        updatePlaybackParams();
                        mMediaPlayer.start();
                        mIsPlaying = true;
                        mPlaybackStartTime = System.currentTimeMillis();
                        startHealthMonitoring();
                        
                        if (mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                            Log.d(TAG, "WakeLock acquired on resume");
                        }
                        
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        createNotification();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Resume failed - invalid state", e);
                    mIsPlaying = false;
                    broadcastUpdate();
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                // We have a playlist and valid index, but no MediaPlayer - prepare and play
                Log.d(TAG, "Resume called but no MediaPlayer, playing song at index " + mCurrentIndex);
                playSong(mCurrentIndex);
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                // We have a playlist but index is invalid, play first song
                Log.d(TAG, "Resume called with invalid index, playing first song");
                mCurrentIndex = 0;
                saveCurrentPlayingIndex();
                playSong(0);
            } else {
                // No songs available - update UI
                mIsPlaying = false;
                broadcastUpdate();
                createNotification();
                Intent updateIntent = new Intent("UPDATE_PLAYER");
                updateIntent.putExtra("current_index", -1);
                updateIntent.putExtra("is_playing", false);
                sendBroadcast(updateIntent);
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     */
    public void stop() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try {
                    mMediaPlayer.stop();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot stop - invalid state", e);
                }
                mIsPlaying = false;
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    int duration = mMediaPlayer.getDuration();
                    if (position >= 0 && position < duration) {
                        mMediaPlayer.seekTo(position);
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        savePlayerState();
                        saveFullState();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot seek - invalid state", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Playback Parameter Methods
    // ========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    /**
     * Handles song completion events.
     */
    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                mCurrentIndex = savedIndex;
            } else {
                mCurrentIndex = 0;
            }
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        
        if (mRepeatMode == 2) {
            playSong(mCurrentIndex);
        } else if (mRepeatMode == 1) {
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null) {
                    try {
                        mMediaPlayer.pause();
                    } catch (Exception ignored) {}
                    try {
                        mMediaPlayer.seekTo(0);
                    } catch (Exception ignored) {}
                }
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                });
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Updates the MediaSession metadata (title, artist, album, album art).
     *
     * @param song The current song (can be null)
     * @param albumArt Album art bitmap (can be null, if null tries to use existing or skip)
     */
    public void updateMediaSessionMetadata(@Nullable Song song, @Nullable Bitmap albumArt) {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        try {
            MediaMetadata.Builder builder = new MediaMetadata.Builder();
            if (song != null) {
                builder.putString(MediaMetadata.METADATA_KEY_TITLE, song.getTitle());
                builder.putString(MediaMetadata.METADATA_KEY_ARTIST, song.getArtist());
                builder.putString(MediaMetadata.METADATA_KEY_ALBUM, song.getAlbum());
                // Add album art if provided and valid
                if (albumArt != null && !albumArt.isRecycled()) {
                    builder.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, albumArt);
                }
            } else {
                builder.putString(MediaMetadata.METADATA_KEY_TITLE, "Llama Music Player");
                builder.putString(MediaMetadata.METADATA_KEY_ARTIST, "");
                builder.putString(MediaMetadata.METADATA_KEY_ALBUM, "");
            }
            mMediaSession.setMetadata(builder.build());
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSession metadata", e);
        }
    }
    
    /**
     * Convenience method to update only album art in MediaSession.
     *
     * @param albumArt The album art bitmap
     */
    public void updateMediaSessionArt(@Nullable Bitmap albumArt) {
        Song currentSong = getCurrentSong();
        updateMediaSessionMetadata(currentSong, albumArt);
    }
    
    /**
     * Sets up audio focus for proper audio ducking and interruption handling.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     *
     * @param songPath The path of the song
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }
    
    /**
     * Handles the close action from the notification.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus from the system.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a playback state update to activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) {
                    pause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // No special handling needed
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                // No action needed
                break;
            default:
                break;
        }
    }
}