// MusicService.java
package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Owns the playback state machine, the MediaPlayer lifecycle, and the
 * persisted playback preferences.
 *
 * <p>The service runs in the background and continues playback when the
 * application is not visible. Playback orchestration is owned by a single
 * state machine: a {@link ServiceState} enum, two monotonic counters
 * ({@link #mGeneration} and {@link #mStartToken}), and a two-index model
 * ({@link #mCurrentIndex} and {@link #mTargetIndex}) hold every
 * transition-related value. State mutations happen on the main thread;
 * raw {@link MediaPlayer} calls run on a dedicated
 * {@link HandlerThread}. Only marshalled {@link Runnable}s cross between
 * them.</p>
 *
 * <p>{@link #mCurrentIndex} is the index the MediaPlayer is bound to.
 * {@link #mTargetIndex} is the index the state machine is driving toward.
 * While the state is PREPARING, {@code mCurrentIndex} still reflects the
 * outgoing song and {@code mTargetIndex} is the destination. Every
 * request method mutates {@code mTargetIndex} only;
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The service owns the playback state machine, the MediaPlayer, the
 * persisted playback preferences, and the current playlist. The activity
 * observes the machine through {@code UPDATE_PLAYER} broadcasts and
 * forwards requests back to it.</p>
 *
 * <p>The notification surface and the media session are owned by
 * {@link NotificationController}. The service exposes a
 * {@link NotificationController.ServiceStateSource} that the controller
 * reads. Two projections of the service are written by the controller,
 * with independent lifetimes:</p>
 *
 * <ul>
 *   <li><b>Metadata</b> is written once per commit. The commit is
 *       delivered as it arrives. During the window between a song's
 *       identity being committed and its art resolving, the metadata
 *       carries the same themed placeholder the playback notification
 *       uses as its large icon, so the two surfaces never diverge.</li>
 *   <li><b>Playback state</b> is written on every sync, driven by
 *       {@link #mStateSource}'s
 *       {@code sessionPlaybackState()}.</li>
 * </ul>
 *
 * <h3>The Playback Window</h3>
 * <p>{@link #getWindowSnapshot()} returns the single source of truth for
 * the three-slot album-art carousel. The window names the previous
 * neighbour, the display song, and the next neighbour. It is computed
 * from two pure functions, {@link #peekPreviousIndex(int)} and
 * {@link #peekNextIndex(int)}, which return the positional or
 * shuffle-chosen neighbour under every repeat mode. The carousel does
 * not compute neighbours; it renders the window.</p>
 *
 * <p>Under shuffle, the two peek functions memoise their answers in
 * separate slots, so the answer the window advertises in each
 * direction survives a window read. A single shared memo would be
 * overwritten by whichever peek ran last, and a subsequent commit
 * that consumed the other direction's memo would resolve to a fresh
 * random index rather than the one the window showed. The two memos
 * and the shuffle history are index-keyed, so any operation that
 * changes what an index means — a playlist replacement, a sort
 * reorder, a shuffle toggle, a repeat-mode change, a transition to
 * idle — clears them.</p>
 *
 * <p>The window itself is memoised for the current state. The two peek
 * functions are not idempotent on their own — each one recomputes the
 * neighbour the corresponding memo returns — so two consecutive calls
 * to {@link #getWindowSnapshot()} with the same state would produce
 * two windows with different neighbour paths in the fallback case. The
 * cache keyed on {@code (generation, current path)} holds the window
 * the last call produced, so every consumer of the window in the same
 * state sees the same three paths. This is what keeps the neighbour
 * slot the carousel renders stable across the broadcast that produced
 * it and any refresh that follows.</p>
 *
 * <p>Under repeat-one, the peek functions still return the positional
 * or shuffle-chosen neighbour. The carousel slides the strip toward
 * that neighbour, so the user sees the next or previous song's art
 * nudge into the viewport. The service's own
 * {@link #playNextSong()}, {@link #playPreviousSong()}, and the
 * automatic advance at the end of a track, however, restart the
 * current song rather than advancing, because repeat-one means "keep
 * playing this song". The restart flag the service publishes with the
 * window is true for that case, so the carousel runs its restart
 * animation instead of its commit slide. The animation is the visible
 * acknowledgement that the restart, not an advance, is what
 * happened.</p>
 *
 * <p>On a single-song playlist, or a shuffle re-pick that cannot avoid
 * the current index, the peek functions return the current index. A
 * next or previous request under any repeat mode wraps to the same
 * song; the request is a restart, matching what the automatic advance
 * does at the end of a track. The window names the current path as its
 * own neighbour, the restart flag is true, and the carousel runs the
 * nudge toward that duplicate.</p>
 *
 * <p>The window also carries the service's monotonic transition
 * counter, {@link #mGeneration}. The carousel compares incoming
 * generations to distinguish a fresh transition from a broadcast that
 * merely re-publishes the same window. Under repeat-one, and on a
 * single-song playlist, the current path is unchanged across a
 * restart, so the generation is the only signal that a fresh
 * transition occurred.</p>
 *
 * <h3>Transition Direction</h3>
 * <p>Every transition carries a direction and a restart flag alongside
 * its window. The direction is {@code +1} for a forward transition,
 * {@code -1} for a backward one, and {@code 0} when the transition has
 * no spatial direction — an explicit selection, a same-song reprepare,
 * a metadata re-publication. The restart flag is true when the
 * transition restarts the current song: repeat-one, a single-song
 * playlist, or a shuffle re-pick that cannot avoid the current
 * index.</p>
 *
 * <p>Both values are properties of the generation. Each transition
 * entry point notes them at the moment it decides the target; the next
 * {@link #beginTransition(int, int)} consumes the note into the
 * generation it creates; and {@link #broadcastUpdate()} publishes them
 * with the window. The carousel reads the direction and the restart
 * from the broadcast and renders exactly the animation they describe
 * — a full commit for a neighbour advance, a below-threshold nudge for
 * a restart, a cross-fade for a non-neighbour selection. The carousel
 * does not predict the direction from its memory of an older window,
 * and the service does not need to broadcast a second time to correct
 * it.</p>
 *
 * <p>{@link #playNextSong()} and {@link #playPreviousSong()} are the
 * transport entry points. They note the direction, set the target, and
 * return. The animation begins when the service's committing broadcast
 * reaches the carousel, in the same turn the window, the direction,
 * and the restart are delivered. An automatic advance, a stall
 * recovery, an error fallback, and a prepare-failure fallback all note
 * their own directions through the same mechanism, so every transition
 * the service can produce is animated from one signal.</p>
 *
 * <h3>The Display Song Rule</h3>
 * <p>{@link #getDisplaySong()} is the single expression of "which song
 * is the app showing right now". During PREPARING it is the target;
 * every other state uses the current index. Every consumer of the
 * display identity reads it: {@link #snapshotForNotification()},
 * {@link #getWindowSnapshot()}, {@link #broadcastUpdate()}, and
 * {@link #prefetchNotificationArt()}. There is no second expression of
 * the rule, so there is nothing for one consumer to drift against
 * another.</p>
 *
 * <h3>Request Preservation</h3>
 * <p>Every request method mutates {@code mTargetIndex} and then calls
 * {@link #reconcile()}. When the state is already PREPARING, the
 * request cannot act immediately: a transition is in flight and the
 * player is preparing a track. The target is stored, and
 * {@link #mDeferredReconcile} is set so that the completion of the
 * current prepare re-enters reconciliation with the newest target.
 * This is what keeps a request that arrives during an in-flight
 * transition from being silently lost — a second file opened while
 * the first is still preparing lands on the newest target, not on a
 * positional successor produced by the failure-recovery heuristic.</p>
 *
 * <p>{@link #setPlaylist(ArrayList, boolean)} preserves the target
 * through a rebuild that runs while a transition is in flight. The
 * target's index is re-resolved against the new playlist so the same
 * song is named, and the anchor is not allowed to reset the target to
 * the currently bound song. When the pending path names a song that
 * the rebuilt playlist now contains, that path overrides the in-flight
 * target: the user asked for it, and the transition to it must begin
 * once the current prepare settles. When the anchor is the pending
 * path and the path was not found — the insert that will make it
 * findable has not yet completed — the rebuild returns without
 * touching the target.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every transition ends with a call to {@link #broadcastUpdate()}.
 * That method builds the {@link PlaybackWindow}, sends the
 * {@code UPDATE_PLAYER} broadcast carrying the window, the direction,
 * and the restart, and commits the notification synchronously with the
 * broadcast. The activity's receiver runs synchronously inside
 * {@code sendBroadcast} — the receiver is registered on the main
 * thread and the broadcast is in-process — so by the time
 * {@code broadcastUpdate} reaches the notification commit, the
 * activity has already adopted the window and the transition and
 * either committed synchronously or queued its commit on the
 * carousel's settle frame. The notification commit is
 * {@link NotificationController#commitFromBroadcast(long,
 * NotificationController.RenderSnapshot)}, called on the same
 * main-thread turn with the same snapshot the broadcast described. The
 * notification therefore writes every surface the transition touches —
 * the title, the artist, the art, the play/pause icon, the media
 * session — on the same turn the activity writes the strip, the seek
 * bar, the transport glyph. This is the pattern {@code MusicPlayer}'s
 * receiver uses for the UI, applied to the notification.</p>
 *
 * <p>The commit fires only from {@code broadcastUpdate}. During
 * PREPARING the notification and the player screen both continue to
 * show the song the previous transition committed. Both surfaces
 * advance to the target on the same turn, when the transition
 * commits. The awareness poll runs on its own cadence as the
 * safety-net for position checkpoints and for state changes that do
 * not reach the notification through a broadcast; its reads are
 * dropped by the generation filter whenever a broadcast commit has
 * already advanced past them.</p>
 *
 * <h3>Play State Truth</h3>
 * <p>{@link #isPlaying()} reports the destination of the current
 * transition, not its intermediate position. During PREPARING the
 * destination is determined by both {@link #mAutoStartOnPrepared} and
 * {@link #mPauseAfterPrepare}: the first is the intent the transition
 * was started with, the second is a pause that arrived while the
 * transition was in flight. Every consumer — the player UI's
 * play/pause button, the notification, and the media session — reads
 * that one value. The play icon appears only when the state machine
 * is genuinely paused and will not auto-start.</p>
 *
 * <p>Resume commits PLAYING synchronously before the async
 * {@code player.start()} is dispatched to the player thread. The
 * destination is "playing" from the moment the user asks for it. The
 * async continuation rolls the state back to IDLE only if
 * {@code player.start()} actually fails, and the rollback is guarded
 * by both {@link #mStartToken} and {@link #mState} so a subsequent
 * user action is not clobbered by a start that began before it.</p>
 *
 * <h3>Transport Actions</h3>
 * <p>Every transport action the notification, lockscreen, headset, or
 * player screen produces reaches the state machine on the same
 * main-thread turn that dispatched it. The service does not debounce
 * transport actions: the synchronous PLAYING commit at resume,
 * combined with the {@link #mStartToken} bump at pause and the
 * {@link #mDeferredReconcile} deferral for a next or previous that
 * arrives during a prepare, is enough to handle any sequence of taps
 * correctly. A debounce would only drop user intent that the state
 * machine already knows how to honor.</p>
 *
 * <h3>Volume Semantics</h3>
 * <p>The music stream volume is a listening signal. Zero is silence; a
 * raise from zero is play. The rules are symmetric and independent of
 * what caused the pause: a tap, a Bluetooth disconnect, an audio-focus
 * loss. Raising the volume from PAUSED resumes; raising it during
 * PREPARING clears any pending {@code mPauseAfterPrepare}; raising it
 * while the song is loaded and waiting in READY starts playback
 * through the same transition the play button uses.</p>
 *
 * <p>The rules apply only while the session is active. The session is
 * active once the user has opened the player at least once since
 * process start. The music volume receiver is registered on
 * {@link #onBind(Intent)} and unregistered in {@link #onDestroy()};
 * its presence is the session state. A service created by a sticky
 * restart, a Bluetooth connect, or a media button press — without the
 * user opening the player — never binds and therefore never registers
 * the receiver, so a hardware volume press on those paths is not
 * treated as a transport control.</p>
 *
 * <p>The volume the rules decide from is read at the handling moment,
 * not taken from the broadcast's extra. The broadcast value is used
 * only as a fallback when the read fails. See
 * {@link #onMusicVolumeChanged(int)}.</p>
 *
 * <h3>Audio Focus Semantics</h3>
 * <p>A permanent audio-focus loss pauses playback and does not resume on
 * its own: the user has moved to another app or another permanent audio
 * source. A transient loss pauses and remembers that it did so, because
 * focus returns when the interrupting app finishes — a phone call
 * ending, a navigation prompt finishing, a WhatsApp video status
 * completing. When {@link AudioManager#AUDIOFOCUS_GAIN} arrives and the
 * flag is still set, playback resumes from where it paused. A transient
 * loss that arrived during PREPARING is remembered as a pending pause
 * on the auto-start; when gain arrives before the prepare completes,
 * the pending pause is cleared and the auto-start is re-armed, so the
 * prepared song plays. A transient loss that arrived during PREPARING
 * and settled to READY before gain arrived is started by gain through
 * the same READY branch the play button uses.</p>
 *
 * <p>The flag {@link #mPausedByTransientLoss} is cleared by any
 * user-initiated transition — resume, pause, seek, stop, or a volume
 * drop to zero — so a stale flag cannot resume playback after the user
 * has moved on.</p>
 *
 * <p>A duck request — {@link AudioManager#AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK}
 * — does not pause. The framework sends it when the interrupting app is
 * willing to share the output at a lower level, which is what a
 * navigation prompt or a notification tone does. The service lowers the
 * MediaPlayer's own output volume to {@link #DUCK_VOLUME_FRACTION} and
 * leaves playback running. The system stream volume is not touched, so
 * the volume slider does not move and the music-stream receiver is not
 * involved. When {@link AudioManager#AUDIOFOCUS_GAIN} arrives, the
 * output volume is restored to full. The flag {@link #mIsDucked}
 * carries the state, and {@link #applyDuckVolume(MediaPlayer)} is the
 * single point that reads it.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>{@link #onCreate()} installs the notification controller, loads the
 * persisted playback preferences, sets up the media session and audio
 * focus, starts the player thread, and registers the service's
 * long-lived broadcast receivers. The music volume receiver is
 * registered on bind and unregistered on destroy, so it exists only
 * while a client — in practice, {@link MusicPlayer} — is bound to the
 * service. The Bluetooth pause receiver is registered in
 * {@code onCreate} and unregistered in {@code onDestroy}, so a headset
 * disconnect pauses playback for the service's whole lifetime, whether
 * or not any activity is alive to observe it.</p>
 *
 * <p>{@link #setPlaylist(ArrayList, boolean)} primes the state machine
 * with the persisted playback position and paused state on the first
 * call after process launch. {@link #onDestroy()} saves the full state,
 * releases the MediaPlayer on its thread, tears down the media session,
 * and abandons audio focus.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every state mutation runs on the main thread through
 * {@link #onMain(Runnable)}. Every raw MediaPlayer call runs on
 * {@link #mPlayerThread} through {@link #onPlayer(Runnable)}. Bitmap
 * decoding and playlist reorders run on dedicated single-thread
 * executors.</p>
 *
 * @see MusicPlayer
 * @see MediaPlayer
 * @see NotificationController
 * @see EqualizerManager
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.3.8
 * @since 1.0.0
 */
public class MusicService extends Service {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for the persisted repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for the persisted shuffle flag. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for the persisted player-state-before-update flag. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE =
        "player_state_before_update";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for the persisted playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that carries a genre update. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action that sets a pending song path. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Broadcast action that carries a new audio session identifier. */
    private static final String ACTION_AUDIO_SESSION_CHANGED =
        "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Service action that resumes playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME =
        "ACTION_BLUETOOTH_RESUME";

    /**
     * Broadcast action that requests a pause after a Bluetooth
     * disconnect.
     *
     * <p>Sent by {@link BluetoothReceiver} when the headset or A2DP
     * profile disconnects. Received by the service so the pause fires
     * whether or not the player activity is alive: a headset disconnect
     * is an event about the audio destination, and the component that
     * owns the audio is the component that must be able to end it.</p>
     */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";

    /** Broadcast action sent by the system audio service when a stream's volume changes. */
    private static final String VOLUME_CHANGED_ACTION =
        "android.media.VOLUME_CHANGED_ACTION";

    /** Extra key carrying the type of stream whose volume changed. */
    private static final String EXTRA_VOLUME_STREAM_TYPE =
        "android.media.EXTRA_VOLUME_STREAM_TYPE";

    /** Extra key carrying the resolved stream type when the changed stream is aliased. */
    private static final String EXTRA_VOLUME_STREAM_TYPE_ALIAS =
        "android.media.EXTRA_VOLUME_STREAM_TYPE_ALIAS";

    /** Extra key carrying the new volume of the stream that changed. */
    private static final String EXTRA_VOLUME_STREAM_VALUE =
        "android.media.EXTRA_VOLUME_STREAM_VALUE";

    /** Interval between health checks, in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 500;

    /** Maximum position advance a healthy stream is allowed to sit idle, in milliseconds. */
    private static final int MAX_STALL_TIME_MS = 1500;

    /** Number of consecutive stalls before the service skips to the next track. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    /** Maximum duration of a continuous skip loop, in milliseconds. */
    private static final long SKIP_LOOP_BUDGET_MS = 2500L;

    /**
     * Output volume applied to the MediaPlayer while audio focus is
     * ducked.
     *
     * <p>A duck is a scale applied to the MediaPlayer's own output,
     * not a change to the system stream volume. The value is small
     * enough to be clearly audible as a duck and large enough that
     * the music remains legible underneath the interrupting app.
     * Twenty percent is the value the platform documentation uses as
     * an example.</p>
     */
    private static final float DUCK_VOLUME_FRACTION = 0.2f;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int NOTIFICATION_ART_MAX_PX = 300;

    /** Size of the notification album art cache, in megabytes. */
    private static final int NOTIFICATION_ART_CACHE_MB = 25;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Number of health-check intervals between periodic position checkpoints. */
    private static final int POSITION_SAVE_INTERVAL_TICKS = 10;

    /** Audio session identifier most recently attached to the equalizer. */
    private static int sCurrentAudioSessionId = 0;

    // ============================================================================
    // State Machine
    // ============================================================================

    /**
     * Exhaustive states of the playback state machine.
     */
    private enum ServiceState {

        /** Nothing is bound to the MediaPlayer. */
        IDLE,

        /** A transition is in flight; the target is not yet bound. */
        PREPARING,

        /** A track is prepared but not started. */
        READY,

        /** A track is playing. */
        PLAYING,

        /** A track is prepared, paused, and retains its position. */
        PAUSED,

        /** The service is in the middle of tearing down. */
        STOPPING
    }

    /** Current state of the playback state machine. */
    private ServiceState mState = ServiceState.IDLE;

    /** Monotonic counter that identifies the current transition. */
    private long mGeneration = 0L;

    /**
     * Monotonic counter that identifies the current start or resume
     * continuation.
     *
     * <p>Incremented at the top of {@link #doResume()}, {@link #doPause()},
     * and {@link #onPrepared(long, int, int, Song, int)}. The async
     * continuation a resume queues captures the value at the moment it
     * begins and compares it against this field before rolling the
     * state back: a mismatch means a later operation has superseded the
     * resume, and the rollback must not fire. Without the counter a
     * pause arriving while a resume's {@code player.start()} is still
     * on the player thread would leave the resume's rollback free to
     * clobber the pause's committed state.</p>
     */
    private long mStartToken = 0L;

    /** Index the MediaPlayer is bound to. */
    private int mCurrentIndex = -1;

    /** Index the state machine is driving toward. */
    private int mTargetIndex = -1;

    /** Position requested for the next prepare, in milliseconds. */
    private int mPendingSeekPosition = 0;

    /** True when the next reconciliation must re-prepare the current track. */
    private boolean mForceReprepare = false;

    /** True when a pause arrived during PREPARING and must be honoured at commit. */
    private boolean mPauseAfterPrepare = false;

    /** True when the prepare should start playback on completion. */
    private boolean mAutoStartOnPrepared = true;

    /**
     * True when a transition request arrived while a transition was
     * already in flight.
     *
     * <p>Set by {@link #reconcile()} when it bails on a state of
     * {@link ServiceState#PREPARING} — the only state in which a new
     * target can arrive without being acted on immediately. Cleared
     * by {@link #reconcile()} before it calls
     * {@link #beginTransition(int, int)}, and by the completion of
     * the transition that first observed it, which re-enters
     * reconciliation through
     * {@link #onPrepared(long, int, int, Song, int)} or
     * {@link #onPlaybackStarted(long, int, Song, int)}.</p>
     *
     * <p>The flag exists so that a request arriving during an
     * in-flight transition is not silently lost. Without it, the
     * only re-entry point would be the target-index comparison in
     * the prepare callbacks, which does not fire when a
     * failure-recovery heuristic has already reset the target to a
     * positional successor.</p>
     */
    private boolean mDeferredReconcile = false;

    /**
     * Direction of the current generation's transition.
     *
     * <p>{@code +1} for a forward transition, {@code -1} for a
     * backward one, {@code 0} when the transition has no spatial
     * direction — an explicit selection, a same-song reprepare, a
     * metadata re-publication. Consumed from {@link #mNotedDirection}
     * by {@link #beginTransition(int, int)} and published by
     * {@link #broadcastUpdate()}.</p>
     */
    private int mGenerationDirection = 0;

    /**
     * True when the current generation's transition restarts the
     * current song: repeat-one, a single-song playlist, or a shuffle
     * re-pick that cannot avoid the current index.
     *
     * <p>Consumed from {@link #mNotedRestart} by
     * {@link #beginTransition(int, int)} and published by
     * {@link #broadcastUpdate()}.</p>
     */
    private boolean mGenerationRestart = false;

    /**
     * Direction noted for the next transition to begin.
     *
     * <p>Written by each transition entry point at the moment it
     * decides the target. Consumed by
     * {@link #beginTransition(int, int)} into
     * {@link #mGenerationDirection} and cleared. A request that never
     * reaches {@code beginTransition} — a reconcile that returns
     * early because the target already equals the current song —
     * clears the note on the way out, so a stale value cannot be
     * attributed to a later, unrelated transition.</p>
     */
    private int mNotedDirection = 0;

    /**
     * Restart flag noted for the next transition to begin.
     *
     * <p>Written alongside {@link #mNotedDirection} and consumed by
     * {@link #beginTransition(int, int)} into
     * {@link #mGenerationRestart}.</p>
     */
    private boolean mNotedRestart = false;

    /** Timestamp at which the current PLAYING state began. */
    private long mPlaybackStartElapsed = 0L;

    /** Consecutive stall recovery attempts since the last healthy playback. */
    private int mRecoveryAttempts = 0;

    /** Timestamp at which the current skip loop began. */
    private long mSkipLoopStartedElapsed = 0L;

    /** Ticks accumulated since the last periodic position checkpoint. */
    private int mPositionSaveTickCounter = 0;

    /** Handler that runs every state mutation on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Handler for health checks; null when not monitoring. */
    private Handler mHealthHandler;

    /** Runnable for the periodic health check. */
    private Runnable mHealthCheckRunnable;

    // ============================================================================
    // Shuffle Peek Memos and Window Cache
    // ============================================================================

    /**
     * True when the shuffle next-peek memo holds a valid result.
     *
     * <p>The next peek and the previous peek have independent memos,
     * so a window read that computes both does not lose either. A
     * single shared memo would be overwritten by whichever peek ran
     * last, and a subsequent commit that consumed the other
     * direction's peek would resolve to a fresh random index rather
     * than the one the window showed.</p>
     */
    private boolean mShuffleNextPeekValid = false;

    /**
     * Anchor index the memoised next-peek was computed for.
     */
    private int mShuffleNextPeekFromIndex = -1;

    /**
     * Result the memoised next-peek returns.
     */
    private int mShuffleNextPeekResult = -1;

    /**
     * True when the shuffle previous-peek memo holds a valid result.
     */
    private boolean mShufflePrevPeekValid = false;

    /**
     * Anchor index the memoised previous-peek was computed for.
     */
    private int mShufflePrevPeekFromIndex = -1;

    /**
     * Result the memoised previous-peek returns.
     */
    private int mShufflePrevPeekResult = -1;

    /**
     * The window most recently produced by
     * {@link #getWindowSnapshot()}, or null when no window is cached
     * for the current state.
     *
     * <p>The two peek functions are not idempotent on their own: each
     * one recomputes the neighbour the corresponding memo returns, so
     * two consecutive calls to {@link #getWindowSnapshot()} with the
     * same state would produce two windows with different neighbour
     * paths in the shuffle fallback case. The cache holds the window
     * the last call produced, keyed on the generation and the current
     * path, so every consumer of the window in the same state sees
     * the same three paths.</p>
     *
     * <p>This is what keeps the neighbour slot the carousel renders
     * stable across the broadcast that produced it and any refresh
     * that follows, and what keeps the window's next and previous
     * paths in agreement with the shuffle picks the next commit will
     * consume: the picks are memoised separately, and the window's
     * neighbours are the same indices those picks will return.</p>
     *
     * <p>Cleared by {@link #clearShufflePeek()}, by
     * {@link #transitionToIdle()}, and by {@link #stop()}, so the
     * cache cannot outlive the state that produced it.</p>
     */
    @Nullable private PlaybackWindow mCachedWindow = null;

    // ============================================================================
    // MediaPlayer
    // ============================================================================

    /** MediaPlayer instance, or null when released. */
    private MediaPlayer mMediaPlayer;

    /** Thread on which every raw MediaPlayer call runs. */
    private HandlerThread mPlayerThread;

    /** Handler bound to {@link #mPlayerThread}. */
    private Handler mPlayerHandler;

    /** Wake lock held while playback is running. */
    private PowerManager.WakeLock mWakeLock;

    // ============================================================================
    // Notification Album Art
    // ============================================================================

    /** Executor that decodes notification album art. */
    private final ExecutorService mArtLoader =
        Executors.newSingleThreadExecutor();

    /**
     * Executor for the playlist reorder that a sort-mode change
     * triggers.
     *
     * <p>A single thread is enough: reorders are strictly sequential,
     * each one supersedes the previous, and the supersede guard in
     * {@link #registerSortModeReceiver()} keeps only the last one from
     * committing. Two reorders running in parallel would race on the
     * captured snapshot; sequential execution makes the ordering
     * trivially correct.</p>
     */
    private final ExecutorService mSortExecutor =
        Executors.newSingleThreadExecutor();

    /** Cache of decoded notification album art keyed by song path. */
    private LruCache<String, Bitmap> mArtCache;

    /** Currently running notification art decode task. */
    private Future<?> mCurrentArtLoad = null;

    /** Path of the art currently resolved for the notification, or null. */
    @Nullable
    private String mResolvedArtPath = null;

    /** Bitmap currently resolved for the notification, or null. */
    @Nullable
    private Bitmap mResolvedArt = null;

    // ============================================================================
    // Notification State Source
    // ============================================================================

    /**
     * State source exposed to {@link NotificationController} for
     * rendering the playback notification and for writing the media
     * session.
     *
     * <p>The controller commits the snapshot the service publishes on
     * its {@code UPDATE_PLAYER} broadcast synchronously with the
     * broadcast via
     * {@link NotificationController#commitFromBroadcast(long,
     * NotificationController.RenderSnapshot)}. It also polls
     * {@link #snapshotForNotification()} on a fixed cadence as a
     * safety net; a poll whose generation is strictly lower than the
     * last committed generation is dropped by the controller's
     * generation filter. Every commit writes the media session
     * playback state from {@link #sessionPlaybackState()}.</p>
     */
    private final NotificationController.ServiceStateSource mStateSource =
        new NotificationController.ServiceStateSource() {

            /**
             * Returns a renderable snapshot for the notification, or
             * null when the service has nothing to render.
             *
             * <p>Returns null only when the state machine has no
             * display song. During PREPARING the snapshot reports the
             * target song's identity, so the notification and the
             * media carousel advance with the user's tap rather than
             * waiting for the transition to complete.</p>
             *
             * <p>The {@code isPlaying} field reports the destination
             * of the current transition, not its intermediate
             * position. See {@link MusicService#isPlaying()}.</p>
             *
             * @return A complete renderable snapshot, or null
             */
            @Nullable
            @Override
            public NotificationController.RenderSnapshot
                    snapshotForNotification() {
                final Song displaySong = getDisplaySong();
                if (displaySong == null) {
                    return null;
                }

                final String displayPath = displaySong.getPath();
                if (displayPath == null) {
                    return null;
                }

                final boolean artResolved =
                    displayPath.equals(mResolvedArtPath);
                final Bitmap resolvedArt =
                    artResolved ? mResolvedArt : null;
                final String album = displaySong.getAlbum() != null
                    ? displaySong.getAlbum() : "";

                return new NotificationController.RenderSnapshot(
                    displaySong.getTitle() != null
                        ? displaySong.getTitle() : "",
                    displaySong.getArtist() != null
                        ? displaySong.getArtist() : "",
                    album,
                    displayPath,
                    isPlaying(),
                    mCachedDuration,
                    resolvedArt,
                    artResolved);
            }

            /**
             * Returns whether the service is idle.
             *
             * @return True when the state machine is IDLE
             */
            @Override
            public boolean isIdle() {
                return mState == ServiceState.IDLE;
            }

            /**
             * Returns the playback state to write to the media session.
             *
             * <p>The session reports the destination of the current
             * transition, not the intermediate position of the state
             * machine. During PREPARING the destination is derived
             * from {@link #mAutoStartOnPrepared} and
             * {@link #mPauseAfterPrepare}.</p>
             *
             * <p>{@code STATE_BUFFERING} is never reported. The app
             * prepares local files and the carousel does not need a
             * buffering indication.</p>
             *
             * @return One of {@link PlaybackStateCompat#STATE_NONE},
             *         {@link PlaybackStateCompat#STATE_PLAYING}, or
             *         {@link PlaybackStateCompat#STATE_PAUSED}
             */
            @Override
            public int sessionPlaybackState() {
                switch (mState) {
                    case PLAYING:
                        return PlaybackStateCompat.STATE_PLAYING;
                    case PAUSED:
                    case READY:
                        return PlaybackStateCompat.STATE_PAUSED;
                    case PREPARING:
                        return (mAutoStartOnPrepared
                            && !mPauseAfterPrepare)
                            ? PlaybackStateCompat.STATE_PLAYING
                            : PlaybackStateCompat.STATE_PAUSED;
                    case IDLE:
                    case STOPPING:
                    default:
                        return PlaybackStateCompat.STATE_NONE;
                }
            }

            /**
             * Writes the current playback state to the media session.
             */
            @Override
            public void updateSessionPlaybackState() {
                updateMediaSessionPlaybackState();
            }

            /**
             * Returns the service's monotonic transition counter.
             *
             * <p>Used by the controller's generation filter to reject
             * snapshots whose generation has already been superseded
             * by a newer broadcast commit.</p>
             *
             * @return The current generation
             */
            @Override
            public long getGeneration() {
                return mGeneration;
            }

            /**
             * Writes the given snapshot's metadata to the media
             * session.
             *
             * <p>The notification and the media session are written
             * from the same snapshot in the same main-thread turn, so
             * the two surfaces cannot disagree about which song is
             * playing.</p>
             *
             * <p>When the snapshot carries resolved art, the session
             * metadata receives that bitmap. When the snapshot's art
             * has not yet resolved, the session metadata receives the
             * same themed placeholder the playback notification uses
             * as its large icon. The two surfaces therefore agree on
             * every field the user can see, including the art, at
             * every commit.</p>
             *
             * @param snapshot Committed snapshot, or null to clear
             */
            @Override
            public void applyToMediaSession(
                    @Nullable NotificationController.RenderSnapshot
                        snapshot) {
                if (mMediaSession == null) {
                    return;
                }
                try {
                    MediaMetadataCompat.Builder builder =
                        new MediaMetadataCompat.Builder();
                    if (snapshot != null) {
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_TITLE,
                            snapshot.title);
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ARTIST,
                            snapshot.artist);
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ALBUM,
                            snapshot.album);
                        builder.putLong(
                            MediaMetadataCompat.METADATA_KEY_DURATION,
                            snapshot.durationMs);

                        if (snapshot.artResolved
                                && snapshot.art != null
                                && !snapshot.art.isRecycled()) {
                            builder.putBitmap(
                                MediaMetadataCompat
                                    .METADATA_KEY_ALBUM_ART,
                                snapshot.art);
                        } else if (mNotificationController != null) {
                            Bitmap placeholder =
                                mNotificationController
                                    .getPlaceholderForMediaSession();
                            if (placeholder != null
                                    && !placeholder.isRecycled()) {
                                builder.putBitmap(
                                    MediaMetadataCompat
                                        .METADATA_KEY_ALBUM_ART,
                                    placeholder);
                            }
                        }
                    } else {
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_TITLE, "");
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ARTIST, "");
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ALBUM, "");
                    }
                    mMediaSession.setMetadata(builder.build());
                } catch (Exception exception) {
                    Log.e(TAG, "applyToMediaSession failed", exception);
                }
            }
        };

    // ============================================================================
    // Cached Playback Facts
    // ============================================================================

    /** Duration of the currently prepared track, in milliseconds. */
    private int mCachedDuration = 0;

    /** Audio session identifier of the currently prepared track. */
    private int mCachedAudioSessionId = 0;

    /** Most recently observed playback position, in milliseconds. */
    private int mCachedPosition = 0;

    /** Playback position at the moment playback last started or resumed. */
    private int mPlaybackBasePosition = 0;

    /** Timestamp at which playback last started or resumed. */
    private long mPlaybackBaseElapsed = 0L;

    /** Counter incremented by every position invalidation. */
    private long mPositionEpoch = 0L;

    // ============================================================================
    // Playlist and Playback State
    // ============================================================================

    /** Current playlist, or null before the first assignment. */
    private ArrayList<Song> mCurrentPlaylist;

    /** Current repeat mode: 0 for off, 1 for all, 2 for one. */
    private volatile int mRepeatMode = 0;

    /** True while shuffle is enabled. */
    private volatile boolean mIsShuffle = false;

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** History of shuffle picks; used to implement previous under shuffle. */
    private ArrayList<Integer> mShuffleHistory;

    /** Source of randomness for shuffle selection. */
    private Random mRandom;

    /**
     * Path of the newest incoming-file request, or null when no
     * request is pending.
     *
     * <p>Set by {@link #requestIncomingFile(String)} and by
     * {@link #setPendingSongPath(String)}. Read by
     * {@link #reconcile()} and by the prepare-completion callbacks
     * ({@link #onPrepared} and {@link #onPlaybackStarted}). Cleared
     * only by {@link #beginTransition(int, int)} when the transition
     * it names actually begins, and by {@link #reconcile()} when the
     * path resolves to the current song. Main-thread only.</p>
     *
     * <p>Clearing at transition time rather than at reconcile time
     * is what makes the request survive a deferral: a request that
     * arrives while another transition is preparing stays in this
     * slot until the transition to it starts, not until the request
     * is first seen.</p>
     */
    private volatile String mPendingSongPath = null;

    // ============================================================================
    // Binder, Library, Notification Controller
    // ============================================================================

    /** Binder returned to bound clients. */
    private final IBinder mBinder = new LocalBinder();

    /** In-memory library used to resolve songs on request. */
    private MusicLibrary mMusicLibrary;

    /** Controller that owns every notification surface, or null before onCreate. */
    @Nullable
    private NotificationController mNotificationController;

    // ============================================================================
    // Audio Focus and Session
    // ============================================================================

    /** System audio manager. */
    private AudioManager mAudioManager;

    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;

    /** Audio focus request used on API 26 and later. */
    private AudioFocusRequest mAudioFocusRequest;

    /** Active media session, or null before setup. */
    private MediaSessionCompat mMediaSession;

    /** True while a Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;

    /**
     * True when the current pause was caused by a transient audio-focus
     * loss and playback should resume when focus returns.
     *
     * <p>Set only by {@link #handleAudioFocusChange(int)} on
     * {@link AudioManager#AUDIOFOCUS_LOSS_TRANSIENT}. Cleared the moment
     * the user does anything else — resume, pause, seek, stop — so a
     * stale flag cannot resume playback after the user has moved on.</p>
     */
    private volatile boolean mPausedByTransientLoss = false;

    /**
     * True while the app has been asked to duck its own output for the
     * duration of a transient audio-focus interruption.
     *
     * <p>Set by {@link #handleAudioFocusChange(int)} on
     * {@link AudioManager#AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK}. Cleared
     * on {@link AudioManager#AUDIOFOCUS_GAIN}. While set, the
     * MediaPlayer's own output volume is lowered to
     * {@link #DUCK_VOLUME_FRACTION}. The system stream volume is not
     * touched, so the volume slider does not move and the music-stream
     * receiver is not involved. The flag is applied to a player
     * through {@link #applyDuckVolume(MediaPlayer)}, which is the
     * single point that reads it, and is re-applied to every new
     * player created by {@link #beginTransition(int, int)}.</p>
     */
    private volatile boolean mIsDucked = false;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    /** Receiver for playback parameter update broadcasts. */
    private BroadcastReceiver mPlaybackParamsReceiver;

    /** Receiver for playlist clear broadcasts. */
    private BroadcastReceiver mClearPlaylistReceiver;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    /** Receiver for playing state query broadcasts. */
    private BroadcastReceiver mGetPlayingStateReceiver;

    /** Receiver for sort mode change broadcasts. */
    private BroadcastReceiver mSortModeReceiver;

    /** Receiver for sync completion broadcasts. */
    private BroadcastReceiver mSyncCompleteReceiver;

    /** Receiver for genre update broadcasts. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for soft playlist update broadcasts. */
    private BroadcastReceiver mUpdatePlaylistReceiver;

    /** Receiver for pending song path broadcasts. */
    private BroadcastReceiver mSetPendingSongReceiver;

    /** Receiver for library reset broadcasts emitted by {@link PlaylistManager}. */
    private BroadcastReceiver mLibraryResetReceiver;

    /**
     * Receiver for the Bluetooth-disconnect pause request.
     *
     * <p>Registered in {@link #onCreate()} and unregistered in
     * {@link #onDestroy()}, so the pause is handled for the service's
     * whole lifetime rather than the activity's. When the activity has
     * been reclaimed by the OS or swiped from recents, the service is
     * still the component holding the audio, and this receiver is what
     * lets the disconnect end it.</p>
     */
    @Nullable
    private BroadcastReceiver mBluetoothPauseReceiver;

    /**
     * Receiver for the music-volume-change broadcast.
     *
     * <p>The system audio service sends
     * {@link #VOLUME_CHANGED_ACTION} when the volume of any stream
     * changes. The receiver filters for
     * {@link AudioManager#STREAM_MUSIC} and reacts to the change.</p>
     *
     * <p>This receiver is registered in {@link #onBind(Intent)} and
     * unregistered in {@link #onDestroy()}. Its presence is the
     * session state: a service created without the user opening the
     * player — a sticky restart, a Bluetooth connect, a media button
     * — never binds and therefore never registers the receiver. See
     * {@link #onBind(Intent)} and {@link #onMusicVolumeChanged(int)}.</p>
     */
    @Nullable
    private BroadcastReceiver mMusicVolumeReceiver;

    // ============================================================================
    // Inner Classes
    // ============================================================================

    /**
     * Binder returned from {@link #onBind(Intent)}.
     */
    public class LocalBinder extends Binder {

        /**
         * Returns the service instance.
         *
         * @return The bound service
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ============================================================================
    // Sort Comparators
    // ============================================================================

    /**
     * Orders songs by title, ascending.
     */
    private class TitleAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, ignoring case.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null
                ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null
                ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    /**
     * Orders songs by title, descending.
     */
    private class TitleZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, ignoring case, descending.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null
                ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null
                ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    /**
     * Orders songs by artist, ascending, with title as the tiebreaker.
     */
    private class ArtistAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, ignoring case, with title
         * as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null
                ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null
                ? "" : secondSong.getArtist();
            int comparisonResult =
                firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by artist, descending, with title as the tiebreaker.
     */
    private class ArtistZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null
                ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null
                ? "" : secondSong.getArtist();
            int comparisonResult =
                secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, ascending, with title as the tiebreaker.
     */
    private class AlbumAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, ignoring case, with title as
         * the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null
                ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null
                ? "" : secondSong.getAlbum();
            int comparisonResult =
                firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, descending, with title as the tiebreaker.
     */
    private class AlbumZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null
                ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null
                ? "" : secondSong.getAlbum();
            int comparisonResult =
                secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, ascending, with title as the tiebreaker.
     */
    private class GenreAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, ignoring case, with title as
         * the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null
                ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null
                ? "" : secondSong.getGenre();
            int comparisonResult =
                firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, descending, with title as the tiebreaker.
     */
    private class GenreZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null
                ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null
                ? "" : secondSong.getGenre();
            int comparisonResult =
                secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, oldest first, with
     * title as the tiebreaker.
     */
    private class OldestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, oldest
         * first, with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, newest first, with
     * title as the tiebreaker.
     */
    private class NewestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, newest
         * first, with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch,
     *         or 0 when the song or its path is null
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) {
            return 0;
        }
        return new File(song.getPath()).lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the
     * given sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ============================================================================
    // Static Helpers
    // ============================================================================

    /**
     * Persists the player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @param need New value of the flag
     */
    public static void setPlayerStateBeforeUpdate(
            @NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need)
            .apply();
    }

    /**
     * Returns the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @return The persisted flag value
     */
    public static boolean getPlayerStateBeforeUpdate(
            @NonNull Context context) {
        return context.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     */
    public static void clearPlayerStateBeforeUpdate(
            @NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the audio session identifier most recently attached to
     * the equalizer.
     *
     * @return The audio session identifier, or 0 when no session is
     *         attached
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ============================================================================
    // Service Lifecycle
    // ============================================================================

    /**
     * Initializes the service: installs the notification controller,
     * loads persisted preferences, sets up the media session and
     * audio focus, starts the player thread, and registers the
     * service's long-lived receivers.
     *
     * <p>The music volume receiver is registered in
     * {@link #onBind(Intent)} and unregistered in {@link #onDestroy()},
     * so its lifetime is the session's lifetime rather than the
     * service's. A service created without the user opening the player
     * has no bound client and therefore does not treat a hardware
     * volume press as a transport control.</p>
     *
     * <p>The Bluetooth pause receiver is registered in
     * {@link #onCreate()} and unregistered in {@link #onDestroy()}, so
     * a headset disconnect pauses playback for the service's whole
     * lifetime, whether or not any activity is alive to observe it.</p>
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        final int artCacheSize =
            NOTIFICATION_ART_CACHE_MB * 1024 * 1024;
        mArtCache = new LruCache<String, Bitmap>(artCacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mPlayerThread = new HandlerThread("MediaPlayerThread");
        mPlayerThread.start();
        mPlayerHandler = new Handler(mPlayerThread.getLooper());

        mNotificationController =
            NotificationController.getInstance(this);
        mNotificationController.attachService(this);
        mNotificationController.setStateSource(mStateSource);
        mNotificationController.setSessionTokenProvider(
            this::getSessionToken);

        mAudioManager =
            (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        EqualizerManager.getInstance(this);

        // The music volume receiver is registered in onBind() and
        // unregistered in onDestroy().

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager =
            (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();
        registerLibraryResetReceiver();
        registerBluetoothPauseReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    /**
     * Handles a start command from an intent, dispatching on its
     * action and starting foreground service synchronisation.
     *
     * <p>Foreground promotion is gated on the playlist being
     * non-empty. On a cold start with an empty library, the service
     * stays a plain background service while it waits for content.</p>
     *
     * @param intent The intent delivered to the service, or null
     * @param flags Additional data about the start request
     * @param startId Unique identifier for the start request
     * @return The sticky restart mode
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (mNotificationController != null) {
            final boolean hasContent =
                mCurrentPlaylist != null
                    && !mCurrentPlaylist.isEmpty();
            if (hasContent) {
                mNotificationController.startForegroundSync();
            } else {
                Log.d(TAG,
                    "onStartCommand: no content, skipping foreground promotion");
            }
        }

        if (intent != null && intent.getAction() != null) {
            final String action = intent.getAction();

            if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
                KeyEvent event;
                if (Build.VERSION.SDK_INT
                        >= Build.VERSION_CODES.TIRAMISU) {
                    event = intent.getParcelableExtra(
                        Intent.EXTRA_KEY_EVENT, KeyEvent.class);
                } else {
                    @SuppressWarnings("deprecation")
                    KeyEvent deprecatedEvent =
                        intent.getParcelableExtra(
                            Intent.EXTRA_KEY_EVENT);
                    event = deprecatedEvent;
                }
                if (event != null
                        && event.getAction() == KeyEvent.ACTION_DOWN
                        && mMediaSession != null) {
                    mMediaSession.getController()
                        .dispatchMediaButtonEvent(event);
                }
                return START_STICKY;
            }

            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNextSong();
            } else if (action.equals("ACTION_PREV")) {
                playPreviousSong();
            } else if (action.equals("ACTION_STOP")) {
                pause();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationController != null) {
                    mNotificationController.demoteFromForeground();
                }
            } else if (action.equals(ACTION_BLUETOOTH_RESUME)) {
                handleBluetoothResume();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    /**
     * Handles a Bluetooth resume request by preparing the last
     * played song, resuming playback, and reloading the full library
     * in the background.
     */
    private void handleBluetoothResume() {
        onMain(() -> {
            final String lastPath = getSavedSongPath();
            if (lastPath == null || !new File(lastPath).exists()) {
                transitionToIdle();
                stopSelf();
                return;
            }

            Song lastSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (lastSong == null) {
                lastSong = CharacterMapper.getSongFromFile(lastPath);
            }
            if (lastSong == null) {
                transitionToIdle();
                stopSelf();
                return;
            }

            final ArrayList<Song> singleSong = new ArrayList<>();
            singleSong.add(lastSong);
            setPlaylist(singleSong, true);
            resume();

            if (mMusicLibrary == null) {
                mMusicLibrary = new MusicLibrary(this);
            }
            mMusicLibrary.loadAllSongsAsync(
                new MusicLibrary.OnSongsLoadedListener() {

                    /**
                     * Replaces the single-song playlist with the
                     * full library once the background load
                     * completes.
                     *
                     * @param songs The loaded list of songs
                     */
                    @Override
                    public void onSongsLoaded(
                            ArrayList<Song> songs) {
                        onMain(() -> {
                            if (songs != null && !songs.isEmpty()) {
                                setPlaylist(songs, true);
                            }
                        });
                    }

                    /**
                     * Logs the failure; the single-song playlist
                     * remains active.
                     *
                     * @param error Description of the failure
                     */
                    @Override
                    public void onLoadingError(String error) {
                        Log.w(TAG,
                            "Full library load after BT resume failed: "
                                + error);
                    }
                });
        });
    }

    /**
     * Returns the binder that exposes this service to bound clients,
     * and registers the music volume receiver.
     *
     * <p>Binding is the "player opened" signal. {@link MusicPlayer}
     * starts the service and binds it in
     * {@code proceedWithInitialization()}; it is the only
     * {@link android.content.ServiceConnection} in the process. A
     * service created without a bind — a {@code START_STICKY}
     * restart, a Bluetooth connect via {@code BluetoothReceiver}, a
     * media button delivered by {@code MediaButtonReceiver} — has
     * no client and never reaches this method.</p>
     *
     * <p>The music volume receiver is registered here and nowhere
     * else. Its presence is the session state: there is no separate
     * flag to fall out of sync with it, and a registration failure
     * leaves {@code mMusicVolumeReceiver} null so the next bind
     * retries. {@link #registerMusicVolumeReceiver()} is idempotent,
     * so a repeat bind is a no-op.
     * {@link #unregisterMusicVolumeReceiver()} in {@link #onDestroy()}
     * is the single teardown path.</p>
     *
     * @param intent Intent that triggered the binding
     * @return The binder
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        registerMusicVolumeReceiver();
        return mBinder;
    }

    /**
     * Releases every resource held by the service.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtLoader != null && !mArtLoader.isShutdown()) {
            mArtLoader.shutdownNow();
        }
        if (mSortExecutor != null && !mSortExecutor.isShutdown()) {
            mSortExecutor.shutdownNow();
        }

        if (mPlayerHandler != null) {
            mPlayerHandler.post(this::releaseMediaPlayer);
        }
        if (mPlayerThread != null) {
            mPlayerThread.quitSafely();
            try {
                mPlayerThread.join(2000);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            mPlayerThread = null;
            mPlayerHandler = null;
        }

        releaseWakeLock();
        mState = ServiceState.STOPPING;

        if (mNotificationController != null) {
            mNotificationController.detachService();
            mNotificationController = null;
        }

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        unregisterMusicVolumeReceiver();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    /**
     * Checkpoints the position when memory pressure rises, and
     * releases caches that can be rebuilt.
     *
     * <p>{@code onTrimMemory} is a system hint. Under sustained
     * pressure the notification art cache and the equalizer's own
     * allocations are the two largest things this service holds.</p>
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(() -> {
            if (mState == ServiceState.PLAYING) {
                savePlayingState();
            }
            if (level >= TRIM_MEMORY_BACKGROUND && mArtCache != null) {
                mArtCache.evictAll();
            }
            reconcile();
        });
    }

    /**
     * Saves the full player state before the task is removed.
     *
     * @param rootIntent The original root intent
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ============================================================================
    // Thread Marshalling and Small Helpers
    // ============================================================================

    /**
     * Runs the given action on the main thread.
     *
     * @param action Action to run
     */
    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action.run();
        } else {
            mMainHandler.post(action);
        }
    }

    /**
     * Runs the given action on the player thread.
     *
     * @param action Action to run
     */
    private void onPlayer(@NonNull Runnable action) {
        if (mPlayerHandler == null) {
            return;
        }
        if (Looper.myLooper() == mPlayerHandler.getLooper()) {
            action.run();
        } else {
            mPlayerHandler.post(action);
        }
    }

    /**
     * Returns the size of the current playlist.
     *
     * @return The playlist size
     */
    private int playlistSize() {
        return mCurrentPlaylist != null
            ? mCurrentPlaylist.size() : 0;
    }

    /**
     * Returns whether the current playlist is empty.
     *
     * @return True when the playlist is empty
     */
    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    /**
     * Returns the path of the song at the given index, or null when
     * the index is out of range.
     *
     * @param index Playlist index
     * @return The path, or null
     */
    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) {
            return null;
        }
        if (index < 0 || index >= mCurrentPlaylist.size()) {
            return null;
        }
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    /**
     * Returns the playlist index of the song with the given path, or
     * -1 when it is not in the playlist.
     *
     * @param path Path to search for
     * @return The index, or -1
     */
    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Acquires the partial wake lock, ignoring any failure.
     */
    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try {
                mWakeLock.acquire();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    /**
     * Releases the partial wake lock, ignoring any failure.
     */
    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    /**
     * Estimates the current playback position from the cached base
     * and elapsed time.
     *
     * @return The estimated position in milliseconds
     */
    private int estimateCurrentPosition() {
        if (mState == ServiceState.PLAYING
                && mPlaybackBaseElapsed > 0L) {
            long elapsedDuration =
                SystemClock.elapsedRealtime() - mPlaybackBaseElapsed;
            long estimatedDuration =
                mPlaybackBasePosition + elapsedDuration;
            if (mCachedDuration > 0
                    && estimatedDuration > mCachedDuration) {
                return mCachedDuration;
            }
            return (int) estimatedDuration;
        }
        return mCachedPosition;
    }

    /**
     * Returns whether the current skip loop has exceeded its budget.
     *
     * @return True when the skip budget is exhausted
     */
    private boolean skipBudgetExhausted() {
        long currentTime = SystemClock.elapsedRealtime();
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = currentTime;
            return false;
        }
        return (currentTime - mSkipLoopStartedElapsed)
            >= SKIP_LOOP_BUDGET_MS;
    }

    /**
     * Abandons the current skip loop, transitions to IDLE, and
     * broadcasts the resulting state.
     */
    private void abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after "
            + (SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed)
            + " ms");
        mSkipLoopStartedElapsed = 0L;
        mPauseAfterPrepare = false;
        mForceReprepare = false;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentIndex = -1;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        savePlayingState();
        savePlayerState();
        broadcastUpdate();
    }

    // ============================================================================
    // Music Volume Receiver
    // ============================================================================

    /**
     * Registers the receiver for the music-volume-change broadcast.
     *
     * <p>Called from {@link #onBind(Intent)}. The receiver's lifetime
     * is tied to the session — the period during which a client has
     * the service bound — rather than to the service's own lifetime.
     * A service created without a bind never registers it, so a
     * hardware volume press on such a service is not treated as a
     * transport control.</p>
     *
     * <p>Idempotent. Returns immediately when a receiver is already
     * registered, so a repeat bind is safe.</p>
     *
     * <p>Registered with {@code RECEIVER_EXPORTED} because the
     * sender is the system process. The receiver filters by the
     * stream-type extra so only changes to the music stream are
     * acted on. On releases where the changed stream is aliased,
     * the primary stream-type extra may be absent; the alias extra
     * is checked as a fallback.</p>
     */
    private void registerMusicVolumeReceiver() {
        if (mMusicVolumeReceiver != null) {
            return;
        }
        mMusicVolumeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !VOLUME_CHANGED_ACTION.equals(
                            intent.getAction())) {
                    return;
                }
                int streamType = intent.getIntExtra(
                    EXTRA_VOLUME_STREAM_TYPE, -1);
                if (streamType == -1) {
                    streamType = intent.getIntExtra(
                        EXTRA_VOLUME_STREAM_TYPE_ALIAS, -1);
                }
                if (streamType != AudioManager.STREAM_MUSIC) {
                    return;
                }
                final int newVolume = intent.getIntExtra(
                    EXTRA_VOLUME_STREAM_VALUE, -1);
                if (newVolume < 0) {
                    return;
                }
                onMusicVolumeChanged(newVolume);
            }
        };
        try {
            ContextCompat.registerReceiver(
                this, mMusicVolumeReceiver,
                new IntentFilter(VOLUME_CHANGED_ACTION),
                ContextCompat.RECEIVER_EXPORTED);
            Log.d(TAG, "Music volume receiver registered");
        } catch (Exception exception) {
            Log.w(TAG, "Failed to register music volume receiver",
                exception);
            mMusicVolumeReceiver = null;
        }
    }

    /**
     * Unregisters the music-volume receiver. Idempotent.
     *
     * <p>Called from {@link #onDestroy()}. The receiver's field is
     * cleared on both paths — success and failure — so the next bind
     * sees a null field and re-registers. The session is therefore
     * torn down cleanly whether or not the framework raised on the
     * unregister call.</p>
     */
    private void unregisterMusicVolumeReceiver() {
        if (mMusicVolumeReceiver != null) {
            try {
                unregisterReceiver(mMusicVolumeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mMusicVolumeReceiver = null;
        }
    }

    /**
     * Reacts to a change in the music stream volume.
     *
     * <p>The two rules are symmetric: zero is silence, non-zero is
     * play. A drop to zero pauses; a raise to non-zero resumes, or —
     * when the song is loaded and waiting in READY — starts playback.
     * This holds regardless of what caused the pause: a tap, a
     * Bluetooth disconnect, an audio-focus loss. The user's act of
     * raising the volume is itself a signal that they want to hear the
     * music.</p>
     *
     * <p>The current system volume is read at the handling moment and
     * clamped to {@code [0, getStreamMaxVolume(STREAM_MUSIC)]}. The
     * broadcast value is used only as a fallback when the read fails.
     * Reading at the handling moment keeps the decision on the value
     * the user has most recently set.</p>
     *
     * <p>Resume is gated on the clamped target being non-zero and on
     * nothing else. It is not gated on a delta, on the value having
     * changed, or on the new value being greater than the old one. A
     * raise from the device maximum resumes; a lower from the device
     * maximum resumes and lowers; a raise at the device minimum
     * resumes.</p>
     *
     * <p>READY is the cold-start case: a song has been prepared and is
     * waiting for the play button. Raising the volume starts playback,
     * so the volume gesture is live from the moment the song loads,
     * not only after the first tap on play.</p>
     *
     * <p>When the raise lands during PREPARING, any pending
     * {@link #mPauseAfterPrepare} is cleared so the transition settles
     * in PLAYING. The user who raises the volume mid-transition is
     * cancelling the pause they may have scheduled.</p>
     *
     * <p>When the drop lands at zero while a song is playing, any
     * pending {@link #mPausedByTransientLoss} is cleared first: the
     * user is asking for silence, and the transient-loss memory does
     * not apply to an explicit volume-driven pause.</p>
     *
     * <p>A duck does not change the system stream volume, so the
     * music-stream receiver is not invoked when a duck begins or
     * ends. The duck path and the volume path do not interact.</p>
     *
     * @param broadcastVolume The music stream volume carried by the
     *        broadcast, used only as a fallback when the read fails
     */
    private void onMusicVolumeChanged(int broadcastVolume) {
        int target = broadcastVolume;
        if (mAudioManager != null) {
            try {
                final int maxVolume = mAudioManager.getStreamMaxVolume(
                    AudioManager.STREAM_MUSIC);
                if (maxVolume > 0) {
                    final int currentVolume =
                        mAudioManager.getStreamVolume(
                            AudioManager.STREAM_MUSIC);
                    if (currentVolume >= 0) {
                        target = currentVolume;
                    }
                    target = Math.max(0,
                        Math.min(maxVolume, target));
                }
            } catch (Exception exception) {
                Log.w(TAG, "Failed to read current music volume",
                    exception);
                target = broadcastVolume;
            }
        }
        if (target < 0) {
            target = 0;
        }

        if (target == 0) {
            if (mState == ServiceState.PLAYING) {
                mPausedByTransientLoss = false;
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        } else {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = false;
            } else if (mState == ServiceState.READY) {
                // Cold-start case: the song is prepared but the user
                // has not pressed play. Raising the volume is a
                // listening signal, so start playback through the
                // same READY branch the play button uses.
                togglePlayPause();
            }
        }
    }

    // ============================================================================
    // Notification Album Art Prefetch
    // ============================================================================

    /**
     * Loads the notification art for the current display song, using
     * the LRU cache when available.
     *
     * <p>The display song is read through {@link #getDisplaySong()}, so
     * the same rule that governs the notification, the media session,
     * and the playback window governs the art prefetch. The rule is
     * expressed once; this method is one of its consumers.</p>
     *
     * <p>When the decode resolves, the callback re-reads the display
     * song and installs the resolved art only when the display song's
     * path is still the path the decode was launched for. The check is
     * expressed in terms of {@link #getDisplaySong()}, so the same rule
     * that governs every other display consumer governs this one.</p>
     *
     * <p>When the decode resolves and the display song has not moved
     * on, the callback sets {@link #mResolvedArtPath} and
     * {@link #mResolvedArt}. If the state machine is past PREPARING
     * — the transition has already committed and the notification
     * has been written with the placeholder — the callback pokes the
     * {@link NotificationController}'s awareness poll so the real
     * bitmap replaces the placeholder on the same main-thread turn
     * as the resolve. During PREPARING, the resolve is left for the
     * commit to pick up: the commit that fires from
     * {@link #broadcastUpdate()} reads {@link #mResolvedArt} and
     * writes the real bitmap instead of the placeholder.</p>
     */
    private void prefetchNotificationArt() {
        final Song displaySong = getDisplaySong();
        if (displaySong == null) {
            return;
        }
        final String path = displaySong.getPath();
        if (path == null) {
            return;
        }

        if (mArtCache.get(path) != null) {
            mResolvedArtPath = path;
            mResolvedArt = mArtCache.get(path);
            return;
        }

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }

        mCurrentArtLoad = mArtLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap art = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    byte[] bytes = retriever.getEmbeddedPicture();
                    if (bytes != null
                            && !Thread.currentThread().isInterrupted()) {
                        art = decodeNotificationArt(bytes);
                    }
                } catch (Exception exception) {
                    Log.e(TAG,
                        "Notification art prefetch failed for " + path,
                        exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception ignored) {
                            // The retriever is not in a state that
                            // permits release.
                        }
                    }
                }

                if (art != null
                        && !Thread.currentThread().isInterrupted()) {
                    mArtCache.put(path, art);
                }

                final Bitmap finalArt = art;
                onMain(() -> {
                    final Song currentDisplaySong = getDisplaySong();
                    if (currentDisplaySong == null
                            || !path.equals(
                                currentDisplaySong.getPath())) {
                        return;
                    }
                    mResolvedArtPath = path;
                    mResolvedArt = finalArt;

                    if (mNotificationController != null
                            && mState != ServiceState.PREPARING) {
                        mNotificationController.pokeAwareness();
                    }
                });
            }
        });
    }

    /**
     * Decodes the given image bytes into a notification-sized
     * bitmap.
     *
     * @param data Image bytes to decode
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeNotificationArt(@NonNull byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);

        int sampleSize = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) {
            sampleSize *= 2;
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sampleSize;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, decode);
    }

    // ============================================================================
    // Shuffle Peek Memos and Window Cache
    // ============================================================================

    /**
     * Invalidates the shuffle peek memos and the cached window.
     *
     * <p>Called whenever a change makes the memoised results or the
     * cached window stale: a playlist replacement, a sort reorder, a
     * shuffle toggle, a repeat-mode change, a transition to idle, or
     * the consumption of a peek by a commit. All three are
     * index-keyed, and any operation that changes what an index means
     * invalidates them.</p>
     */
    private void clearShufflePeek() {
        mShuffleNextPeekValid = false;
        mShuffleNextPeekFromIndex = -1;
        mShuffleNextPeekResult = -1;
        mShufflePrevPeekValid = false;
        mShufflePrevPeekFromIndex = -1;
        mShufflePrevPeekResult = -1;
        mCachedWindow = null;
    }

    // ============================================================================
    // Pure Functions
    // ============================================================================

    /**
     * Returns the positional or shuffle-chosen next index, without
     * committing.
     *
     * <p>Pure. Under shuffle the result is the memoised shuffle pick;
     * otherwise the result is the positional wrap. The result is
     * returned even under repeat-one: the peek names the neighbour the
     * carousel slides toward, which is the positional or shuffle-chosen
     * next, not the current song the service restarts. Calling this
     * method does not mutate the shuffle history or any other state
     * beyond the next-peek memo.</p>
     *
     * @param fromIndex Index to peek from
     * @return The next index, or -1 when the playlist is empty
     */
    private int peekNextIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize == 0) {
            return -1;
        }
        if (mIsShuffle) {
            return peekShuffleNextIndex(fromIndex);
        }
        return (fromIndex + 1) % playlistSize;
    }

    /**
     * Returns the positional or shuffle-chosen previous index,
     * without committing.
     *
     * <p>Pure. Under shuffle the result is the memoised shuffle
     * previous pick; otherwise the result is the positional wrap. The
     * result is returned even under repeat-one: the peek names the
     * neighbour the carousel slides toward, which is the positional or
     * shuffle-chosen previous, not the current song the service
     * restarts. Calling this method does not mutate the shuffle
     * history or any other state beyond the previous-peek memo.</p>
     *
     * @param fromIndex Index to peek from
     * @return The previous index, or -1 when the playlist is empty
     */
    private int peekPreviousIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize == 0) {
            return -1;
        }
        if (mIsShuffle) {
            return peekShufflePreviousIndex(fromIndex);
        }
        return (fromIndex - 1 + playlistSize) % playlistSize;
    }

    /**
     * Returns the shuffle-chosen next index, memoising the result so a
     * subsequent commit returns the same index.
     *
     * <p>The memo is separate from the previous-peek memo, so a window
     * read that computes both peeks preserves both answers. A commit
     * that consumes the next peek returns the same index the window
     * advertised in its next slot.</p>
     *
     * @param fromIndex Index to peek from
     * @return The shuffle-chosen next index
     */
    private int peekShuffleNextIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        if (mShuffleNextPeekValid
                && mShuffleNextPeekFromIndex == fromIndex) {
            return mShuffleNextPeekResult;
        }
        if (mRandom == null) {
            mRandom = new Random();
        }
        int candidateIndex;
        int guardCount = 0;
        do {
            candidateIndex = mRandom.nextInt(playlistSize);
            guardCount++;
        } while (candidateIndex == fromIndex && guardCount < 8);

        mShuffleNextPeekValid = true;
        mShuffleNextPeekFromIndex = fromIndex;
        mShuffleNextPeekResult = candidateIndex;
        return candidateIndex;
    }

    /**
     * Returns the shuffle-chosen previous index, memoising the result
     * so a subsequent commit returns the same index.
     *
     * <p>When the shuffle history holds at least two entries, the
     * previous index is the second-to-last entry. Otherwise a fresh
     * pick is made. Neither case mutates the history; the commit is
     * what pops.</p>
     *
     * <p>The memo is separate from the next-peek memo, so a window
     * read that computes both peeks preserves both answers. This is
     * what lets the fallback fresh pick the window advertises in its
     * previous slot be the same index a subsequent Previous press
     * advances to, even when the history is exhausted.</p>
     *
     * @param fromIndex Index to peek from
     * @return The shuffle-chosen previous index
     */
    private int peekShufflePreviousIndex(int fromIndex) {
        if (mShufflePrevPeekValid
                && mShufflePrevPeekFromIndex == fromIndex) {
            return mShufflePrevPeekResult;
        }
        int previousIndex;
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int candidateIndex =
                mShuffleHistory.get(mShuffleHistory.size() - 2);
            if (candidateIndex >= 0
                    && candidateIndex < playlistSize()) {
                previousIndex = candidateIndex;
            } else {
                previousIndex = freshShufflePick(fromIndex);
            }
        } else {
            previousIndex = freshShufflePick(fromIndex);
        }
        mShufflePrevPeekValid = true;
        mShufflePrevPeekFromIndex = fromIndex;
        mShufflePrevPeekResult = previousIndex;
        return previousIndex;
    }

    /**
     * Returns a fresh shuffle pick that differs from the given index.
     *
     * @param fromIndex Index to avoid
     * @return The pick
     */
    private int freshShufflePick(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        if (mRandom == null) {
            mRandom = new Random();
        }
        int candidateIndex;
        int guardCount = 0;
        do {
            candidateIndex = mRandom.nextInt(playlistSize);
            guardCount++;
        } while (candidateIndex == fromIndex && guardCount < 8);
        return candidateIndex;
    }

    /**
     * Returns the index that follows the given index under the
     * current shuffle and repeat mode, and commits the choice.
     *
     * <p>Under shuffle the result is a fresh or memoised pick and the
     * shuffle history is advanced. Otherwise the result is the
     * positional wrap. Repeat-one is not special-cased here: the
     * service's public request methods and the automatic advance
     * intercept repeat-one before calling this method, so this method
     * always returns the neighbour a positional or shuffle advance
     * would reach.</p>
     *
     * @param fromIndex Starting index
     * @return The next index, or -1 when the playlist is empty
     */
    private int computeNext(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return pickShuffleNext(fromIndex);
        }
        return (fromIndex + 1) % playlistSize();
    }

    /**
     * Returns the index that precedes the given index under the
     * current shuffle and repeat mode, and commits the choice.
     *
     * <p>Under shuffle the result pops the shuffle history.
     * Otherwise the result is the positional wrap. Repeat-one is not
     * special-cased here; see {@link #computeNext(int)}.</p>
     *
     * @param fromIndex Starting index
     * @return The previous index, or -1 when the playlist is empty
     */
    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return popShuffleHistory(fromIndex);
        }
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    /**
     * Picks the next index under shuffle, pushes it onto the shuffle
     * history, and returns it.
     *
     * <p>Consumes the memoised next peek so the index the window
     * advertised in its next slot is the index the service plays.</p>
     *
     * @param fromIndex Starting index
     * @return The shuffled next index
     */
    private int pickShuffleNext(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        int nextIndex = peekShuffleNextIndex(fromIndex);

        if (mShuffleHistory == null) {
            mShuffleHistory = new ArrayList<Integer>();
        }
        if (mShuffleHistory.size() >= playlistSize * 2) {
            mShuffleHistory.clear();
        }
        mShuffleHistory.add(nextIndex);
        clearShufflePeek();
        return nextIndex;
    }

    /**
     * Pops the previous index off the shuffle history, or picks a new
     * one when the history is empty.
     *
     * <p>Consumes the memoised previous peek so the index the window
     * advertised in its previous slot is the index the service plays,
     * in both the history-backed and the fallback case.</p>
     *
     * @param fromIndex Starting index
     * @return The previous index under shuffle
     */
    private int popShuffleHistory(int fromIndex) {
        int previousIndex = peekShufflePreviousIndex(fromIndex);
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
        }
        clearShufflePeek();
        return previousIndex;
    }

    // ============================================================================
    // Display Song and Window Snapshot
    // ============================================================================

    /**
     * Returns the display song for the current state of the state
     * machine.
     *
     * <p>During PREPARING the display song is the target; every other
     * state uses the current index. This is the rule that
     * {@link #snapshotForNotification()},
     * {@link #getWindowSnapshot()}, {@link #broadcastUpdate()}, and
     * {@link #prefetchNotificationArt()} all read. It is expressed
     * here, once.</p>
     *
     * @return The display song, or null when no song is bound
     */
    @Nullable
    private Song getDisplaySong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return null;
        }
        if (mState == ServiceState.PREPARING) {
            if (mTargetIndex < 0
                    || mTargetIndex >= mCurrentPlaylist.size()) {
                return null;
            }
            Song targetSong = mCurrentPlaylist.get(mTargetIndex);
            if (targetSong == null
                    || TextUtils.isEmpty(targetSong.getPath())) {
                return null;
            }
            return targetSong;
        }
        if (mCurrentIndex >= 0
                && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null
                    || TextUtils.isEmpty(currentSong.getPath())) {
                return null;
            }
            return currentSong;
        }
        return null;
    }

    /**
     * Returns the window the carousel should render.
     *
     * <p>The window names the previous neighbour, the display song,
     * and the next neighbour. Neighbours are always positional or
     * shuffle-chosen; they are not nulled out for a repeat mode. Under
     * repeat-one the window publishes the positional or shuffle-chosen
     * neighbours while the service restarts the current song; the
     * restart flag published alongside the window is true, so the
     * carousel slides the strip toward the neighbour and springs back
     * under the restart animation. Under repeat off at the last song
     * the window publishes the wrap-around neighbour, because that is
     * what an explicit next or previous request would advance to; the
     * automatic advance at the end of the playlist broadcasts an
     * unchanged generation with direction 0 and the strip does not
     * move.</p>
     *
     * <p>On a single-song playlist, or a shuffle re-pick that cannot
     * avoid the current index, the neighbour is the current song
     * itself. The next and previous requests wrap onto the same index
     * and the service restarts the song; the window names the current
     * path as its own neighbour so the carousel has somewhere to
     * slide and the nudge that follows is the visible acknowledgement
     * of the restart.</p>
     *
     * <p>The window is memoised for the current state. The two peek
     * functions are not idempotent on their own: each one recomputes
     * the neighbour the corresponding memo returns, so two consecutive
     * calls with the same state would produce two windows with
     * different neighbour paths in the shuffle fallback case. The
     * cache keyed on the generation and the display path holds the
     * window the last call produced, so every consumer in the same
     * state sees the same three paths.</p>
     *
     * <p>The window also carries the service's monotonic transition
     * counter. The carousel compares incoming generations to tell a
     * fresh transition apart from a broadcast that merely re-publishes
     * the same window, which is what lets it animate a same-song
     * restart.</p>
     *
     * @return The window, or {@link PlaybackWindow#EMPTY} when idle
     */
    @NonNull
    public PlaybackWindow getWindowSnapshot() {
        Song displaySong = getDisplaySong();
        if (displaySong == null) {
            mCachedWindow = null;
            return PlaybackWindow.EMPTY;
        }
        int displayIndex = indexOfPath(displaySong.getPath());
        if (displayIndex < 0) {
            mCachedWindow = null;
            return PlaybackWindow.EMPTY;
        }

        PlaybackWindow cached = mCachedWindow;
        if (cached != null
                && cached.generation == mGeneration
                && displaySong.getPath().equals(cached.currentPath)) {
            return cached;
        }

        int previousIndex = peekPreviousIndex(displayIndex);
        int nextIndex = peekNextIndex(displayIndex);

        String previousPath = (previousIndex >= 0)
            ? pathOf(previousIndex) : null;
        String nextPath = (nextIndex >= 0)
            ? pathOf(nextIndex) : null;

        PlaybackWindow window = new PlaybackWindow(
            previousPath, displaySong.getPath(), nextPath, mGeneration);
        mCachedWindow = window;
        return window;
    }

    // ============================================================================
    // Core: Reconcile and Transition
    // ============================================================================

    /**
     * Notes the direction and restart for the next transition to
     * begin.
     *
     * <p>Each transition entry point calls this at the moment it
     * decides the target. {@link #beginTransition(int, int)} consumes
     * the noted values into {@link #mGenerationDirection} and
     * {@link #mGenerationRestart}, and {@link #broadcastUpdate()}
     * publishes them alongside the window.</p>
     *
     * @param direction +1 for a forward transition, -1 for a backward
     *        one, 0 for a transition with no spatial direction
     * @param restart True when the transition restarts the current
     *        song
     */
    private void noteTransition(int direction, boolean restart) {
        mNotedDirection = direction;
        mNotedRestart = restart;
    }

    /**
     * Clears any note that no transition will consume.
     *
     * <p>Called by {@link #reconcile()} on the paths where it decides
     * no transition is warranted. Without the clear, a note written
     * for a target that turned out to equal the current song would
     * survive and be attributed to a later, unrelated transition.</p>
     */
    private void clearNotedTransition() {
        mNotedDirection = 0;
        mNotedRestart = false;
    }

    /**
     * Begins a transition when one is warranted by the current
     * target and state.
     *
     * <p>A request that arrives while a transition is in flight does
     * not act immediately — the state is {@link ServiceState#PREPARING}
     * and the player is already preparing a track. The target is
     * still updated, and the flag {@link #mDeferredReconcile} is set
     * so the prepare callbacks re-enter reconciliation with the
     * newest target when the current prepare completes.</p>
     *
     * <p>When no transition is warranted — the target equals the
     * current song and no reprepare is forced, or the target is out
     * of range — the noted direction and restart are cleared. The
     * note was for a transition that will not run, and leaving it in
     * place would attribute it to the next transition to begin. The
     * deferred flag is cleared alongside the note: the deferred
     * request has been serviced by the fact that the target and
     * current index agree, and a later completion callback must not
     * re-enter reconciliation on its behalf.</p>
     *
     * <p>A pending incoming-file path is resolved against the current
     * playlist before the need check. A pending path that resolves
     * to an index overrides the reconcile's ordinary target; one
     * that resolves to the current song is consumed without a
     * transition.</p>
     */
    private void reconcile() {
        if (mState == ServiceState.STOPPING) {
            clearNotedTransition();
            return;
        }
        if (mState == ServiceState.PREPARING) {
            // A target arrived while a transition is in flight.
            // Record it so the completion of the current prepare
            // re-enters reconciliation with the newest target,
            // even if a failure-recovery heuristic has already
            // run.
            mDeferredReconcile = true;
            return;
        }

        // A pending incoming-file path is the explicit request.
        // Resolve it against the current playlist and let it
        // override whatever else set mTargetIndex. The slot is
        // consumed only when it resolves to the current song
        // (no transition to run) or inside beginTransition when
        // the transition it names begins.
        if (mPendingSongPath != null) {
            final int pendingIndex = indexOfPath(mPendingSongPath);
            if (pendingIndex >= 0) {
                mTargetIndex = pendingIndex;
                if (pendingIndex == mCurrentIndex
                        && !mForceReprepare) {
                    mPendingSongPath = null;
                }
            }
            // If the path was not found, leave it set. The rebuild
            // that adds it will re-enter reconciliation.
        }

        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) {
            clearNotedTransition();
            return;
        }

        boolean need = (mTargetIndex != mCurrentIndex)
            || mForceReprepare;
        if (!need) {
            // The deferred request has been serviced: the target
            // resolves to the current song. Clear the flag so a
            // stale request cannot be re-entered by a later
            // completion callback.
            mDeferredReconcile = false;
            clearNotedTransition();
            return;
        }

        mForceReprepare = false;
        mDeferredReconcile = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    /**
     * Starts a new transition toward the given index, captures a
     * fresh generation along with the noted direction and restart,
     * and dispatches {@code prepareAsync} on the player thread.
     *
     * <p>Every new MediaPlayer is created here. Its output volume is
     * applied from the current duck state through
     * {@link #applyDuckVolume(MediaPlayer)} before the player is
     * prepared, so a track change that happens while audio focus is
     * ducked does not momentarily play the new track at full
     * volume.</p>
     *
     * <p>The notification is committed when the transition commits,
     * not when the prepare begins. During PREPARING the notification
     * and the player screen both continue to show the song the
     * previous transition committed; both surfaces advance to the
     * target when {@link #broadcastUpdate()} fires.</p>
     *
     * <p>A pending incoming-file path that names the target is
     * consumed here — at the moment the transition begins — rather
     * than at reconcile time. Consuming at transition time is what
     * keeps a request from being spent on a reconcile that does not
     * produce a transition.</p>
     *
     * @param index Target playlist index
     * @param seekPosition Position to seek to after prepare
     */
    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) {
            return;
        }
        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (index < 0 || index >= playlistSize()) {
            return;
        }

        // Consume the pending incoming path only when the
        // transition it names actually begins. A pending path that
        // arrived for a different target survives and is checked
        // again on the completion of this transition.
        if (mPendingSongPath != null
                && mPendingSongPath.equals(pathOf(index))) {
            mPendingSongPath = null;
        }

        final long generation = ++mGeneration;
        mGenerationDirection = mNotedDirection;
        mGenerationRestart = mNotedRestart;
        mNotedDirection = 0;
        mNotedRestart = false;

        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            mState = ServiceState.IDLE;
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(index);
            noteTransition(+1, false);
            mMainHandler.post(this::reconcile);
            return;
        }

        prefetchNotificationArt();

        final String path = song.getPath();
        final int committedIndex = index;
        final long capturedGeneration = generation;

        onPlayer(() -> {
            releaseMediaPlayer();
            final MediaPlayer player = getOrCreatePlayerRaw();
            removeAllListeners(player);
            applyDuckVolume(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
                return;
            }

            try {
                player.setDataSource(path);
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + path,
                    exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
                return;
            }

            player.setOnPreparedListener(mediaPlayer -> {
                final int duration;
                final int audioSessionId;
                try {
                    duration = mediaPlayer.getDuration();
                    audioSessionId = mediaPlayer.getAudioSessionId();
                } catch (Exception exception) {
                    mMainHandler.post(() ->
                        onPrepareFailed(
                            capturedGeneration, committedIndex));
                    return;
                }
                mMainHandler.post(() -> onPrepared(
                    capturedGeneration, duration, audioSessionId, song,
                    committedIndex));
            });

            player.setOnCompletionListener(mediaPlayer ->
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onCompletion();
                }));

            player.setOnErrorListener((mediaPlayer, what, extra) -> {
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onPlayerError(what, extra);
                });
                return true;
            });

            try {
                player.prepareAsync();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "prepareAsync failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
            }
        });
    }

    /**
     * Tears the state machine down to IDLE and clears every field
     * that describes "what was playing".
     *
     * <p>Idempotent. Captures a fresh generation so any in-flight
     * prepare callback is discarded. Clears the playlist, the
     * shuffle history, the cached window, the resolved notification
     * art, the noted transition values, and the static audio session
     * identifier. Releases the MediaPlayer on its thread, releases the
     * wake lock, releases the audio effects, writes the idle values
     * to SharedPreferences, and cancels the playback notification
     * through the controller.</p>
     */
    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) {
            return;
        }

        if (mState == ServiceState.IDLE
                && mCurrentPlaylist == null
                && mCurrentIndex == -1
                && mTargetIndex == -1) {
            return;
        }

        mState = ServiceState.STOPPING;
        mGeneration++;
        mGenerationDirection = 0;
        mGenerationRestart = false;
        clearNotedTransition();
        mCachedWindow = null;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mPauseAfterPrepare = false;
        mForceReprepare = false;
        mDeferredReconcile = false;
        mSkipLoopStartedElapsed = 0L;
        mCurrentIndex = -1;
        mPendingSongPath = null;

        mPositionSaveTickCounter = 0;

        mCachedPosition = 0;
        mCachedDuration = 0;
        mCachedAudioSessionId = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;
        mPositionEpoch++;

        mResolvedArtPath = null;
        mResolvedArt = null;
        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtCache != null) {
            mArtCache.evictAll();
        }

        stopHealthMonitoring();

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentPlaylist = null;
        if (mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        clearShufflePeek();

        EqualizerManager.getInstance(this).release();

        sCurrentAudioSessionId = 0;

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        if (mNotificationController != null) {
            mNotificationController.clearPlaybackNotification();
        }

        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(false);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to deactivate MediaSession",
                    exception);
            }
        }

        mState = ServiceState.IDLE;
        broadcastUpdate();
    }

    // ============================================================================
    // MediaPlayer Callbacks
    // ============================================================================

    /**
     * Handles a successful {@code prepareAsync} callback on the main
     * thread.
     *
     * <p>When the transition is bound to {@code READY} — a cold-start
     * restore, a pause that arrived during PREPARING — the method
     * re-enters reconciliation after publishing the READY state,
     * because a different target may have arrived while the track was
     * preparing. That target's transition was deferred by
     * {@link #reconcile()}'s PREPARING guard, and no other path
     * triggers it now that the state has settled.
     * {@link #onPlaybackStarted(long, int, Song, int)} carries the
     * same check for the auto-start branch.</p>
     *
     * <p>The re-check includes {@link #mDeferredReconcile}, which is
     * set whenever a request arrived during the transition. Without
     * it, a request that landed on the target index the transition
     * was already driving toward would be lost when a
     * failure-recovery heuristic had previously reset the target to
     * a positional successor.</p>
     *
     * @param generation Generation of the transition
     * @param duration Duration of the prepared track in milliseconds
     * @param audioSessionId Audio session identifier of the prepared
     *        track
     * @param song The song that was prepared
     * @param committedIndex The index the track was bound to
     */
    private void onPrepared(long generation, int duration,
                            int audioSessionId, @NonNull Song song,
                            int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        if (duration <= 0) {
            onPrepareFailed(generation, committedIndex);
            return;
        }

        int seekPosition = mPendingSeekPosition;
        mPendingSeekPosition = 0;

        mSkipLoopStartedElapsed = 0L;
        mCachedDuration = duration;
        mCachedAudioSessionId = audioSessionId;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        sCurrentAudioSessionId = audioSessionId;
        broadcastAudioSessionChanged(audioSessionId);
        EqualizerManager.getInstance(this)
            .attachToAudioSession(audioSessionId);

        mCurrentIndex = committedIndex;

        if (mPauseAfterPrepare) {
            mPauseAfterPrepare = false;
            mAutoStartOnPrepared = false;
        }

        if (!mAutoStartOnPrepared) {
            if (seekPosition > 0 && seekPosition < duration - 500) {
                final int finalSeekPosition = seekPosition;
                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player != null) {
                        try {
                            player.seekTo(finalSeekPosition);
                        } catch (Exception ignored) {
                            // The player is not in a state that
                            // permits seeking.
                        }
                    }
                });
                mCachedPosition = seekPosition;
                mPlaybackBasePosition = seekPosition;
            }

            mState = ServiceState.READY;
            mRecoveryAttempts = 0;

            if (mMediaSession != null) {
                try {
                    mMediaSession.setActive(true);
                } catch (Exception ignored) {
                    // The session is not in a state that permits
                    // activation.
                }
            }

            saveCurrentPlayingIndex();
            broadcastUpdate();

            // A different target may have arrived while this song
            // was preparing. The transition to it was deferred
            // because the state was PREPARING, and no other path
            // triggers it now that the state has settled at READY.
            // Begin it here, mirroring the check in
            // onPlaybackStarted. The deferred flag is included so
            // that a request whose target coincides with the song
            // just prepared still re-enters reconciliation. The
            // pending-path term covers a request that arrived
            // before the playlist rebuild could resolve it.
            if (mDeferredReconcile
                    || mPendingSongPath != null
                    || mTargetIndex != mCurrentIndex
                    || mForceReprepare) {
                mMainHandler.post(this::reconcile);
            }
            return;
        }

        final int doSeek = (seekPosition > 0
            && seekPosition < duration - 500) ? seekPosition : 0;
        final long capturedGeneration = generation;
        final Song capturedSong = song;
        final int capturedIndex = committedIndex;
        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                mMainHandler.post(() ->
                    onPrepareFailed(
                        capturedGeneration, capturedIndex));
                return;
            }
            if (doSeek > 0) {
                try {
                    player.seekTo(doSeek);
                } catch (Exception ignored) {
                    // The player is not in a state that permits
                    // seeking.
                }
            }
            try {
                player.start();
            } catch (Exception exception) {
                Log.e(TAG, "onPrepared: start() failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() ->
                    onPrepareFailed(
                        capturedGeneration, capturedIndex));
                return;
            }
            final long finalCapturedStartToken = capturedStartToken;
            mMainHandler.post(() -> {
                if (finalCapturedStartToken != mStartToken) {
                    return;
                }
                onPlaybackStarted(capturedGeneration, capturedIndex,
                    capturedSong, doSeek);
            });
        });
    }

    /**
     * Commits the transition to PLAYING and starts the notification,
     * the wake lock, audio focus, and the health monitor.
     *
     * <p>When a request arrived during this transition, the re-check
     * at the end of this method re-enters reconciliation with the
     * newest target. The deferred flag is included so a request
     * whose target coincides with the song just started still
     * triggers the re-check. The re-check also includes
     * {@code mPendingSongPath != null}, so a request whose path was
     * parked during the prepare re-enters reconciliation even when
     * the target and current indices agree.</p>
     *
     * @param generation Generation of the transition
     * @param committedIndex Index the track was bound to
     * @param song The song that started playing
     * @param seekPosition Position the track started at
     */
    private void onPlaybackStarted(long generation, int committedIndex,
                                   @NonNull Song song, int seekPosition) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        mState = ServiceState.PLAYING;
        mPositionSaveTickCounter = 0;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBasePosition = seekPosition;
        mPlaybackBaseElapsed = mPlaybackStartElapsed;
        mCachedPosition = seekPosition;
        mRecoveryAttempts = 0;

        acquireWakeLock();
        requestAudioFocus();

        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits
                // activation.
            }
        }

        updatePlaybackParams();
        saveCurrentPlayingIndex();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }

        if (mDeferredReconcile
                || mPendingSongPath != null
                || mTargetIndex != mCurrentIndex
                || mForceReprepare) {
            mMainHandler.post(this::reconcile);
        }
    }

    /**
     * Handles a failed prepare by checking the skip budget and
     * advancing to the next track.
     *
     * <p>A request that arrived while the failed transition was in
     * flight is preserved. The failure-recovery heuristic — advance
     * to the positional successor — does not overwrite a target the
     * user asked for. When {@link #mDeferredReconcile} is set, the
     * target is left alone and reconciliation is re-entered, which
     * begins the transition the user's request named. Otherwise the
     * fallback advances forward and notes the direction so the
     * carousel renders the advance it produced.</p>
     *
     * @param generation Generation of the transition
     * @param committedIndex Index the track was bound to
     */
    private void onPrepareFailed(long generation, int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        onPlayer(this::releaseMediaPlayer);
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }
        if (mDeferredReconcile) {
            mMainHandler.post(this::reconcile);
            return;
        }
        mTargetIndex = computeNext(committedIndex);
        noteTransition(+1, false);
        mMainHandler.post(this::reconcile);
    }

    /**
     * Advances to the next track when the current track completes.
     *
     * <p>The destination is chosen under the same rules the transport
     * buttons and the window use. Under repeat-one the same song is
     * re-prepared, so the restart flag noted for the next transition
     * is true and the carousel runs its restart animation instead of a
     * full commit slide. Under shuffle, whether repeat is off or all,
     * the destination is the shuffle-chosen next index, so the
     * automatic advance agrees with the window and with a next
     * request; without shuffle the destination is the positional
     * successor, except at the last song under repeat off, where the
     * advance pauses without a transition. On a single-song playlist,
     * the destination is the same index and the advance restarts the
     * song.</p>
     */
    private void onCompletion() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }

        int fromIndex = mCurrentIndex;
        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mRepeatMode == 1 || mIsShuffle) {
            nextIndex = computeNext(fromIndex);
        } else if (fromIndex + 1 < playlistSize()) {
            nextIndex = fromIndex + 1;
        } else {
            mState = ServiceState.PAUSED;
            mTargetIndex = fromIndex;
            mPendingSeekPosition = 0;
            mCachedPosition = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            onPlayer(() -> {
                final MediaPlayer player = mMediaPlayer;
                if (player == null) {
                    return;
                }
                try {
                    player.pause();
                } catch (Exception ignored) {
                    // The player is not in a state that permits
                    // pausing.
                }
                try {
                    player.seekTo(0);
                } catch (Exception ignored) {
                    // The player is not in a state that permits
                    // seeking.
                }
            });

            releaseWakeLock();
            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            return;
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        noteTransition(+1, nextIndex == fromIndex);
        mMainHandler.post(this::reconcile);
    }

    /**
     * Handles a MediaPlayer error by checking the skip budget and
     * advancing to the next track.
     *
     * <p>The fallback is a forward advance, so the direction noted for
     * the transition it begins is {@code +1}. The carousel renders the
     * advance the service actually produced, regardless of the request
     * that led to the failed transition.</p>
     *
     * @param what The error type
     * @param extra The extra error code
     */
    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);

        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }

        if (mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        noteTransition(+1, false);
        mMainHandler.post(this::reconcile);
    }

    /**
     * Reacts to a detected playback stall by either re-preparing
     * the current track from the persisted position or, after
     * {@link #MAX_RECOVERY_ATTEMPTS} attempts, advancing to the
     * next track.
     *
     * <p>A reprepare of the same song has no spatial direction, so it
     * notes direction 0 and the carousel snaps and re-renders. An
     * advance notes {@code +1} and the carousel runs its commit
     * slide.</p>
     */
    private void onStall() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) {
                transitionToIdle();
                return;
            }
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
            noteTransition(+1, false);
        } else {
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
            noteTransition(0, false);
        }

        reconcile();
    }

    // ============================================================================
    // Health Monitoring
    // ============================================================================

    /**
     * Installs the runnable used by
     * {@link #startHealthMonitoring()}.
     */
    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mState == ServiceState.PLAYING) {
                    refreshPositionFromPlayer();
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null
                            && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(
                            this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    /**
     * Reads the current position from the player, detects stalls,
     * and checkpoints the persisted position on a fixed interval.
     */
    private void refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        final long epoch = mPositionEpoch;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }

            final int position;
            try {
                position = player.getCurrentPosition();
            } catch (Exception exception) {
                return;
            }

            mMainHandler.post(() -> {
                if (epoch != mPositionEpoch) {
                    return;
                }
                if (mState != ServiceState.PLAYING) {
                    return;
                }

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime();

                long elapsedDuration = SystemClock.elapsedRealtime()
                    - mPlaybackStartElapsed;
                if (position < 100
                        && elapsedDuration > MAX_STALL_TIME_MS) {
                    onStall();
                } else if (position >= 100) {
                    mPlaybackStartElapsed =
                        SystemClock.elapsedRealtime();
                }

                mPositionSaveTickCounter++;
                if (mPositionSaveTickCounter
                        >= POSITION_SAVE_INTERVAL_TICKS) {
                    mPositionSaveTickCounter = 0;
                    savePlayingState();
                }
            });
        });
    }

    /**
     * Starts the periodic health check.
     */
    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(
                mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    /**
     * Cancels any pending health check.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ============================================================================
    // Public Request API
    // ============================================================================

    /**
     * Requests playback of the song at the given index.
     *
     * <p>An explicit selection, so no direction is noted; the
     * transition that begins carries direction 0 and the carousel
     * runs its reveal when the song changes.</p>
     *
     * @param index Playlist index to play
     */
    public void playSong(int index) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given index, starting at
     * the given position.
     *
     * @param index Playlist index to play
     * @param position Start position in milliseconds
     */
    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given path.
     *
     * @param filePath Path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG,
                    "playSongByPath: not in playlist, parked: "
                        + filePath);
            }
        });
    }

    /**
     * Records the given path as the newest incoming-file request and,
     * when the playlist already contains it, asks the state machine
     * to transition to it on the same turn.
     *
     * <p>The path is stored in {@link #mPendingSongPath} and
     * {@link #reconcile()} is called. If the path is in the current
     * playlist, reconcile resolves it and begins the transition. If
     * the path is not yet in the playlist — the loose-track insert
     * is still in progress — the slot is left set and the rebuild
     * that adds the path re-enters reconciliation. The slot is not
     * cleared until the transition it names actually begins, so a
     * request that arrives while another transition is preparing
     * survives the prepare.</p>
     *
     * <p>Called from the activity on the main thread. A second call
     * before the first has transitioned overwrites the field — the
     * newest request is the one the user wants.</p>
     *
     * @param filePath Absolute path of the incoming file
     */
    public void requestIncomingFile(@NonNull String filePath) {
        onMain(() -> {
            mPendingSongPath = filePath;
            reconcile();
        });
    }

    /**
     * Requests the next song.
     *
     * <p>The transport entry point. The direction is noted as
     * {@code +1} and the restart flag is set when the request resolves
     * to a restart — repeat-one, a single-song playlist, or a shuffle
     * re-pick that cannot avoid the current index. The generation that
     * begins carries both values, and the service's committing
     * broadcast publishes them alongside the window. The carousel
     * reads them from the broadcast and runs the animation they
     * describe; the request itself does not start an animation on the
     * caller's turn.</p>
     */
    public void playNextSong() {
        onMain(() -> {
            if (playlistEmpty() || mState == ServiceState.STOPPING) {
                return;
            }

            mSkipLoopStartedElapsed = 0L;
            int baseIndex = (mState == ServiceState.PREPARING
                    && mTargetIndex >= 0)
                ? mTargetIndex
                : mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }

            final boolean restart;
            if (mRepeatMode == 2) {
                // Repeat-one restarts the same song. The reprepare is
                // what makes reconcile() begin a fresh transition
                // even though the target index has not changed.
                mTargetIndex = baseIndex;
                mForceReprepare = true;
                restart = true;
            } else {
                mTargetIndex = computeNext(baseIndex);
                restart = (mTargetIndex == baseIndex);
                if (restart) {
                    // A wrap that lands on the current index — a
                    // single-song playlist, or a shuffle pick that
                    // cannot avoid the current index — is a restart.
                    mForceReprepare = true;
                }
            }
            mPendingSeekPosition = 0;
            noteTransition(+1, restart);
            reconcile();
        });
    }

    /**
     * Requests the previous song.
     *
     * <p>Symmetric to {@link #playNextSong()}. The direction is noted
     * as {@code -1}; the restart flag is set when the request resolves
     * to a restart. The generation that begins carries both values and
     * they travel to the carousel on the service's committing
     * broadcast. Under shuffle the target is the memoised previous
     * peek, so the index the window advertised in its previous slot
     * is the index the service plays, in both the history-backed and
     * the fallback case.</p>
     */
    public void playPreviousSong() {
        onMain(() -> {
            if (playlistEmpty() || mState == ServiceState.STOPPING) {
                return;
            }

            mSkipLoopStartedElapsed = 0L;
            int baseIndex = (mState == ServiceState.PREPARING
                    && mTargetIndex >= 0)
                ? mTargetIndex
                : mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }

            final boolean restart;
            if (mRepeatMode == 2) {
                mTargetIndex = baseIndex;
                mForceReprepare = true;
                restart = true;
            } else {
                mTargetIndex = computePrevious(baseIndex);
                restart = (mTargetIndex == baseIndex);
                if (restart) {
                    mForceReprepare = true;
                }
            }
            mPendingSeekPosition = 0;
            noteTransition(-1, restart);
            reconcile();
        });
    }

    /**
     * Toggles between playing and paused according to the current
     * state.
     *
     * <p>A user-initiated pause clears {@link #mPausedByTransientLoss}:
     * the user is asking for silence, and the transient-loss memory
     * does not apply to a deliberate action.</p>
     *
     * <p>During PREPARING the toggle reflects the destination the
     * transition is currently headed toward. A transition heading
     * toward playback gets a pending pause and a cleared
     * transient-loss flag; a transition already headed toward pause
     * has the pending pause cleared and the auto-start re-armed. The
     * icon follows the destination at commit, on the same
     * main-thread turn as the player screen.</p>
     *
     * <p>The {@code READY} branch routes through {@link #doResume()}
     * so the state commits synchronously, matching the {@code PAUSED}
     * branch and the cold-start volume-raise path.</p>
     */
    public void togglePlayPause() {
        onMain(() -> {
            switch (mState) {
                case PLAYING:
                    mPausedByTransientLoss = false;
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY:
                    // Route READY through doResume() so the state
                    // commits synchronously with the user's tap,
                    // matching the PAUSED resume path.
                    doResume();
                    break;
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        return;
                    }
                    mSkipLoopStartedElapsed = 0L;
                    if (mTargetIndex < 0) {
                        mTargetIndex = 0;
                    }
                    reconcile();
                    break;
                case PREPARING: {
                    final boolean currentlyHeadsToPlay =
                        mAutoStartOnPrepared && !mPauseAfterPrepare;
                    mPausedByTransientLoss = false;
                    if (currentlyHeadsToPlay) {
                        // The transition is heading toward playback.
                        // Schedule the pause.
                        mPauseAfterPrepare = true;
                    } else {
                        // The transition is currently headed toward
                        // pause (a prior pause, or a transient-loss
                        // suppression). Clear the pause and re-arm
                        // the auto-start.
                        mPauseAfterPrepare = false;
                        mAutoStartOnPrepared = true;
                    }
                    break;
                }
                case STOPPING:
                    break;
            }
        });
    }

    /**
     * Requests a pause. A user-initiated pause clears
     * {@link #mPausedByTransientLoss}: the user is asking for silence,
     * and the transient-loss memory does not apply to a deliberate
     * action.
     */
    public void pause() {
        onMain(() -> {
            mPausedByTransientLoss = false;
            if (mState == ServiceState.PLAYING) {
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        });
    }

    /**
     * Requests a resume.
     *
     * <p>During PREPARING the resume clears a pending pause and
     * re-arms the auto-start. A resume that arrives during a
     * transition is the user's request to hear the track the
     * transition is preparing; the notification's play icon follows
     * it at commit.</p>
     */
    public void resume() {
        onMain(() -> {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                mSkipLoopStartedElapsed = 0L;
                if (mTargetIndex < 0 && !playlistEmpty()) {
                    mTargetIndex = 0;
                }
                reconcile();
            } else if (mState == ServiceState.PREPARING) {
                // A resume supersedes a pending pause scheduled by
                // an earlier tap or a transient-loss suppression.
                mPausedByTransientLoss = false;
                if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                    mPauseAfterPrepare = false;
                    mAutoStartOnPrepared = true;
                }
            }
        });
    }

    /**
     * Releases the player but remembers the current index so a
     * subsequent play re-prepares the same track from position
     * zero.
     */
    public void stop() {
        onMain(() -> {
            if (mState != ServiceState.PLAYING
                    && mState != ServiceState.PAUSED) {
                return;
            }

            int stoppedAtIndex = mCurrentIndex;

            onPlayer(this::releaseMediaPlayer);
            releaseWakeLock();

            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;
            mPendingSeekPosition = 0;
            mPauseAfterPrepare = false;
            mForceReprepare = false;
            mDeferredReconcile = false;
            mSkipLoopStartedElapsed = 0L;
            clearNotedTransition();
            mCachedWindow = null;
            mState = ServiceState.IDLE;

            mPositionSaveTickCounter = 0;

            mCachedPosition = 0;
            mCachedDuration = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Tears down to IDLE and clears the playlist.
     */
    public void stopCompletely() {
        onMain(this::transitionToIdle);
    }

    /**
     * Pauses the player, updates the cached position, saves state,
     * broadcasts the change, and demotes the notification from the
     * foreground.
     *
     * <p>Bumps {@link #mStartToken} at entry. A resume whose
     * {@code player.start()} is still on the player thread captures
     * {@code mStartToken} when it begins; the pause's bump makes the
     * resume's continuation skip its rollback, so the pause's
     * committed {@code PAUSED} state is not clobbered by a start
     * that began before it.</p>
     */
    private void doPause() {
        mStartToken++;

        mPositionSaveTickCounter = 0;

        final int position = estimateCurrentPosition();

        mState = ServiceState.PAUSED;
        mCachedPosition = position;
        mPlaybackBasePosition = position;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                player.pause();
            } catch (Exception ignored) {
                // The player is not in a state that permits pausing.
            }
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.demoteFromForeground();
        }
    }

    /**
     * Resumes the player, reacquires audio focus, and commits
     * PLAYING synchronously.
     *
     * <p>The state is committed synchronously, before the
     * {@link MediaPlayer#start()} call is dispatched to the player
     * thread. The notification, the media session, and the player
     * screen all read the destination of the transition, and the
     * destination is "playing" the moment the user asks for it; the
     * async continuation exists only to roll the state back if
     * {@code start()} actually fails. Committing first keeps the
     * play/pause icon on every surface in step with the user's tap
     * rather than with the player thread's schedule, and matches the
     * pattern {@link #doPause()} uses: state first, async work
     * second.</p>
     *
     * <p>The failure rollback is guarded by both
     * {@link #mStartToken} and the state machine's state. A pause or
     * a new transition that arrives while a resume's
     * {@code player.start()} is in flight bumps {@code mStartToken}
     * or changes the state; either signal causes the resume's
     * continuation to skip the rollback, so a subsequent user
     * action is not clobbered by a start that began before it.</p>
     *
     * <p>Clears {@link #mPausedByTransientLoss} at entry. Any path
     * that reaches a resume is a user or system action that
     * supersedes a pending transient-loss auto-resume.</p>
     */
    private void doResume() {
        mPausedByTransientLoss = false;
        requestAudioFocus();
        updatePlaybackParams();

        final long capturedStartToken = ++mStartToken;

        // Commit PLAYING synchronously so every surface flips to
        // the destination on the same turn as the user's tap. The
        // async continuation below exists only to roll back if
        // player.start() actually fails.
        onPlaybackResumed();

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            boolean started = false;
            if (player != null) {
                try {
                    player.start();
                    started = true;
                } catch (Exception exception) {
                    Log.e(TAG, "resume: start() failed", exception);
                }
            }
            if (started) {
                return;
            }
            mMainHandler.post(() -> {
                if (capturedStartToken != mStartToken) {
                    // A newer resume or a pause has superseded
                    // this one; its outcome is already committed.
                    return;
                }
                if (mState != ServiceState.PLAYING) {
                    // A pause, a next, a stop, or a transition
                    // has superseded this resume; its committed
                    // state is the one to keep.
                    return;
                }
                mState = ServiceState.IDLE;
                onPlayer(this::releaseMediaPlayer);
                releaseWakeLock();
                savePlayerState();
                broadcastUpdate();
                reconcile();
            });
        });
    }

    /**
     * Commits the resume: sets PLAYING, acquires the wake lock,
     * reactivates the media session, saves state, and commits the
     * notification.
     *
     * <p>Called synchronously from {@link #doResume()} before the
     * async {@code player.start()} is dispatched. Every surface
     * therefore flips to the destination on the same main-thread
     * turn as the user's tap, rather than on the player thread's
     * schedule. The async continuation in {@link #doResume()} rolls
     * the state back to IDLE if {@code player.start()} fails.</p>
     */
    private void onPlaybackResumed() {
        mState = ServiceState.PLAYING;
        mPositionSaveTickCounter = 0;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBaseElapsed = mPlaybackStartElapsed;

        acquireWakeLock();
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits
                // activation.
            }
        }
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }
    }

    /**
     * Requests a seek to the given position.
     *
     * @param position Target position in milliseconds
     */
    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {

                mPositionEpoch++;

                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player == null) {
                        return;
                    }
                    try {
                        player.seekTo(position);
                    } catch (Exception ignored) {
                        // The player is not in a state that permits
                        // seeking.
                    }
                });

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed =
                        SystemClock.elapsedRealtime();
                }

                mPositionSaveTickCounter = 0;

                savePlayerState();
                broadcastUpdate();
            }
        });
    }

    // ============================================================================
    // Playlist
    // ============================================================================

    /**
     * Replaces the current playlist, resolves an anchor song, and
     * re-enters reconciliation when the anchor changed.
     *
     * <p>Anchor precedence is: pending song path, then the currently
     * bound path, then the persisted last path. A pending song path
     * is an explicit play request — it is set when the user opens a
     * file from outside the app, and the rebuild that follows an
     * {@code UPDATE_PLAYLIST} broadcast is the point at which that
     * request is fulfilled. A pending-path anchor is therefore
     * allowed to auto-play on cold start; only a persisted-state
     * anchor pauses. See the cold-start branch below.</p>
     *
     * <p>The pending slot is consumed only when the path it names was
     * actually found by its own path in the rebuilt playlist. A
     * fallback to a title match or to index 0 does not consume it: a
     * second loose-track open that arrived before the first one's
     * insert completed leaves the slot set, so the rebuild triggered
     * by the second insert resolves the path the user asked for last
     * rather than the slot having been cleared by the first rebuild.
     * Two rapid opens therefore resolve in order: the first rebuild
     * finds the second path absent and preserves the slot, the second
     * rebuild finds it present, plays it, and clears.</p>
     *
     * <p>When the state is {@link ServiceState#PREPARING} the rebuild
     * preserves the transition in flight. The target's index is
     * re-resolved against the new playlist so the same song is named,
     * and the anchor is not allowed to reset the target to the
     * currently bound song. When the pending path names a song the
     * rebuilt playlist now contains, that path overrides the
     * in-flight target: the user asked for it, and the transition to
     * it must begin once the current prepare settles. This is the
     * case an incoming file produces when a next or previous request
     * is still preparing — without the override, the rebuild would
     * adopt the new playlist and the new song's display identity
     * while the old target kept playing. When the anchor is the
     * pending path and the path was not found — the insert that will
     * make it findable has not yet completed — the rebuild returns
     * without touching the target. The pending slot is left in place
     * across the rebuild. It is consumed only by
     * {@code beginTransition} when the transition it names actually
     * begins.</p>
     *
     * @param playlist New playlist to install
     * @param preserveCurrentSong True to preserve the current song
     *        when present in the new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist,
                            boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) {
                return;
            }

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) {
                    broadcastUpdate();
                    return;
                }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist =
                new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist,
                getComparatorForSortMode(mCurrentSortMode));

            if (mCurrentPlaylist != null
                && mCurrentPlaylist.size() == sortedPlaylist.size()
                && sameOrder(mCurrentPlaylist, sortedPlaylist)) {
                broadcastUpdate();
                return;
            }

            final String playingPath = pathOf(mCurrentIndex);
            final String targetPath = pathOf(mTargetIndex);
            final boolean hasPendingSong = (mPendingSongPath != null);

            String anchorPath = mPendingSongPath;
            if (anchorPath == null) {
                anchorPath = playingPath;
            }
            if (anchorPath == null) {
                anchorPath = getSavedSongPath();
            }

            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null
                            && anchorPath.equals(
                                candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mCurrentPlaylist = sortedPlaylist;

            // The playlist replacement invalidates every index-keyed
            // state. The shuffle peek memos, the shuffle history, and
            // the cached window all name indices, and those indices
            // no longer refer to the same songs.
            clearShufflePeek();
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }

            int resolvedIndex = (anchorPath != null)
                ? indexOfPath(anchorPath) : -1;

            if (resolvedIndex < 0 && anchorSong != null
                    && anchorSong.getTitle() != null) {
                for (int index = 0;
                        index < sortedPlaylist.size(); index++) {
                    Song candidateSong = sortedPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(
                            candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }

            // The anchor is the pending path and the path was not
            // found: the insert that will make it findable has not
            // yet completed. The rebuild leaves the target alone.
            // The pending slot is preserved (cleared only inside
            // beginTransition), and the rebuild that follows the
            // insert resolves it. Falling back to index 0 here
            // would start a transition to an unrelated song.
            if (hasPendingSong
                    && resolvedIndex < 0
                    && mState != ServiceState.PREPARING) {
                broadcastUpdate();
                return;
            }

            if (resolvedIndex < 0) {
                resolvedIndex = 0;
            }

            if (mState == ServiceState.PREPARING) {
                // The state machine is already driving toward a
                // target. A rebuild must not change the destination
                // the user named: the target's index is re-resolved
                // against the new playlist so the same song is
                // named.
                if (targetPath != null) {
                    final int newTargetIndex =
                        indexOfPath(targetPath);
                    if (newTargetIndex >= 0) {
                        mTargetIndex = newTargetIndex;
                    }
                }

                // The pending slot is not consumed here. It is
                // consumed only inside beginTransition when the
                // transition it names actually begins, so a
                // request that arrives during the prepare survives
                // and is re-checked by the completion callback.
                reconcile();
                broadcastUpdate();
                return;
            }

            final String resolvedPath = pathOf(resolvedIndex);
            final boolean sameSong = (playingPath != null)
                                  && !hasPendingSong
                                  && playingPath.equals(resolvedPath)
                                  && (mState == ServiceState.PLAYING
                                      || mState == ServiceState.PAUSED
                                      || mState == ServiceState.READY);

            if (sameSong) {
                mCurrentIndex = resolvedIndex;
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            final boolean coldStart = (mCurrentIndex == -1
                                    && mState == ServiceState.IDLE);
            if (coldStart) {
                if (anchorPath != null
                        && anchorPath.equals(getSavedSongPath())) {
                    final int savedPosition = getSavedPosition();
                    if (savedPosition > 0) {
                        mPendingSeekPosition = savedPosition;
                    }
                }
                // A pending song path is an explicit play request —
                // the user opened a file from outside. The cold-start
                // pause is for state restoration, not for explicit
                // play requests, so it is not applied when the anchor
                // came from the pending path.
                if (!wasPlayingBeforeRestart() && !hasPendingSong) {
                    mPauseAfterPrepare = true;
                }
            }

            mTargetIndex = resolvedIndex;
            reconcile();
        });
    }

    /**
     * Replaces the current playlist without preserving the current
     * song.
     *
     * @param playlist New playlist to install
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    /**
     * Replaces the current playlist, preserving the current song
     * when it is present in the new playlist.
     *
     * @param newPlaylist New playlist to install
     */
    public void updatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    /**
     * Returns a copy of the current playlist.
     *
     * @return A copy of the current playlist
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) {
            return new ArrayList<Song>();
        }
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    /**
     * Returns whether two playlists contain the same song paths in
     * the same order.
     *
     * @param firstPlaylist First playlist
     * @param secondPlaylist Second playlist
     * @return True when the two are in the same order
     */
    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) {
            return false;
        }
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null)
                ? firstSong.getPath() : null;
            String secondPath = (secondSong != null)
                ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null
                    : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ============================================================================
    // Pending Song Path
    // ============================================================================

    /**
     * Sets the song path queued for playback once it enters the
     * playlist.
     *
     * <p>A non-null path is handed off through
     * {@link #requestIncomingFile(String)}, which stores it in
     * {@link #mPendingSongPath} and re-enters reconciliation. A null
     * path clears the slot unconditionally.</p>
     *
     * <p>The slot is consumed only when the transition it names
     * begins, or when the reconcile that reads it resolves it to the
     * current song. A rebuild that runs before either of those
     * leaves the slot set, so a second request that arrives before
     * the first insert completes is not overwritten by the first
     * request's completion.</p>
     *
     * @param path Path to queue, or null to clear
     */
    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            if (path == null) {
                mPendingSongPath = null;
                Log.d(TAG, "Pending song path cleared");
                return;
            }
            requestIncomingFile(path);
        });
    }

    /**
     * Returns the song path currently queued for playback.
     *
     * @return The queued path, or null
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    /**
     * Clears the queued song path.
     */
    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    /**
     * Plays the queued song path when it is present in the current
     * playlist.
     *
     * <p>Kept as public API for compatibility. The current
     * implementation routes through the same slot that
     * {@link #requestIncomingFile(String)} uses, so calling this
     * method after a handoff is equivalent to the reconcile the
     * request already ran. The slot is consumed only when the
     * transition it names begins.</p>
     */
    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) {
                return;
            }
            reconcile();
        });
    }

    // ============================================================================
    // Getters and Mode Setters
    // ============================================================================

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return The current position
     */
    public int getCurrentPosition() {
        return estimateCurrentPosition();
    }

    /**
     * Returns the duration of the currently prepared track in
     * milliseconds.
     *
     * @return The duration
     */
    public int getDuration() {
        return mCachedDuration;
    }

    /**
     * Returns whether playback is running, or is on a transition
     * that will settle in PLAYING.
     *
     * <p>During PREPARING the destination is determined by both
     * {@link #mAutoStartOnPrepared} and {@link #mPauseAfterPrepare}:
     * the first is the intent the transition was started with, the
     * second is a pause that arrived while the transition was in
     * flight. The play icon appears only when neither flag will
     * produce playback — the state machine is genuinely paused and
     * will not auto-start.</p>
     *
     * @return True when playback is running or will be running
     */
    public boolean isPlaying() {
        switch (mState) {
            case PLAYING:
                return true;
            case PREPARING:
                return mAutoStartOnPrepared && !mPauseAfterPrepare;
            default:
                return false;
        }
    }

    /**
     * Returns whether the state machine holds a song that is loaded
     * but not currently playing.
     *
     * <p>This is the case a volume-key press starts playback from:
     * the song is bound, either paused at a position or prepared at
     * its start and waiting for the play button.</p>
     *
     * @return True when the state is PAUSED or READY
     */
    public boolean isPausedOrReady() {
        return mState == ServiceState.PAUSED
            || mState == ServiceState.READY;
    }

    /**
     * Returns the song bound to {@link #mCurrentIndex}.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return null;
        }
        if (mCurrentIndex < 0
                || mCurrentIndex >= mCurrentPlaylist.size()) {
            return null;
        }
        return mCurrentPlaylist.get(mCurrentIndex);
    }

    /**
     * Returns the index the MediaPlayer is bound to.
     *
     * @return The current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Sets the index the MediaPlayer is bound to and persists it.
     *
     * @param index New current index
     */
    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    /**
     * Returns the current repeat mode.
     *
     * @return The repeat mode
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }

    /**
     * Sets the repeat mode, persists it, and broadcasts the new
     * state.
     *
     * @param mode New repeat mode
     */
    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            // The repeat mode changes what "next" and "previous"
            // mean. Any memoised shuffle peek and any cached window
            // were computed under the previous mode and no longer
            // describe the next commit.
            clearShufflePeek();
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Returns whether shuffle is enabled.
     *
     * @return True when shuffle is enabled
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }

    /**
     * Sets the shuffle flag, persists it, and broadcasts the new
     * state.
     *
     * <p>The shuffle peek memos, the shuffle history, and the cached
     * window are all index-keyed. Toggling shuffle changes what an
     * index means for a subsequent next or previous request, so all
     * three are cleared. The history clear is what prevents a
     * backward swipe under the new shuffle state from consuming an
     * index recorded under the previous one.</p>
     *
     * @param shuffle New shuffle flag
     */
    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            clearShufflePeek();
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Records whether a Bluetooth headset is currently connected.
     *
     * @param connected True when connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ============================================================================
    // Sort Mode
    // ============================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(
                PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ============================================================================
    // Persistence
    // ============================================================================

    /**
     * Writes the current playback state to SharedPreferences.
     */
    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, isPlaying())
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Writes the full playback state to SharedPreferences.
     */
    private void saveFullState() {
        savePlayerState();
    }

    /**
     * Returns the persisted playback position.
     *
     * @return The persisted position
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    /**
     * Returns whether the persisted state indicates that playback
     * was active before the last restart.
     *
     * @return True when playback was active
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    /**
     * Returns the persisted last song path.
     *
     * @return The last song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Persists the current playing index and last song path.
     */
    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Persists the last playing flag and current position.
     */
    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, isPlaying())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    /**
     * Reads the persisted repeat mode and shuffle flag into memory.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = preferences.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = preferences.getBoolean(KEY_SHUFFLE, false);
    }

    // ============================================================================
    // MediaPlayer Plumbing (player-thread only)
    // ============================================================================

    /**
     * Detaches every listener from the given player.
     *
     * @param player Player to detach listeners from, or null
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) {
            return;
        }
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
            // The player is not in a state that permits listener
            // changes.
        }
    }

    /**
     * Stops, resets, and releases the MediaPlayer, then clears the
     * field.
     */
    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
            } catch (Exception ignored) {
                // The player is not in a state that permits stopping.
            }
            try {
                mMediaPlayer.reset();
            } catch (Exception ignored) {
                // The player is not in a state that permits resetting.
            }
            try {
                mMediaPlayer.release();
            } catch (Exception ignored) {
                // The player is already released.
            }
            mMediaPlayer = null;
        }
    }

    /**
     * Returns the MediaPlayer instance, creating one when none
     * exists.
     *
     * @return The MediaPlayer
     */
    @NonNull
    private MediaPlayer getOrCreatePlayerRaw() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    // ============================================================================
    // Playback Params
    // ============================================================================

    /**
     * Applies the current tempo and pitch from
     * {@link EqualizerManager} to the MediaPlayer on the player
     * thread.
     */
    public void updatePlaybackParams() {
        EqualizerManager equalizerManager =
            EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        final float finalTempo = tempo;
        final float finalSemitones = semitones;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                float pitch =
                    (float) Math.pow(2.0, finalSemitones / 12.0);
                android.media.PlaybackParams playbackParams =
                    player.getPlaybackParams();
                playbackParams.setSpeed(finalTempo);
                playbackParams.setPitch(pitch);
                player.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + finalTempo
                    + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params",
                    exception);
            }
        });
    }

    // ============================================================================
    // MediaSession
    // ============================================================================

    /**
     * Creates the media session, installs the callback, and sets
     * the flags.
     *
     * <p>The session is created inactive. Activation is owned by
     * the playback state machine: the READY transition of
     * {@link #onPrepared}, the PLAYING transitions of
     * {@link #onPlaybackStarted} and {@link #onPlaybackResumed},
     * and the READY branch of {@link #togglePlayPause} activate it
     * once a track is bound. {@link #transitionToIdle} deactivates
     * it.</p>
     *
     * <p>The callbacks clear {@link #mPausedByTransientLoss} on
     * pause and stop, because a user action through the media
     * session is a deliberate transition that supersedes a pending
     * transient-loss auto-resume.</p>
     *
     * <p>The PREPARING branches of {@code onPlay} and {@code onPause}
     * mirror the transport API's PREPARING handling: a play
     * requested during a transition clears a pending pause and
     * re-arms the auto-start, and a pause requested during a
     * transition schedules a pending pause. The play/pause icon
     * follows the request at commit, on the same main-thread turn
     * as the player screen.</p>
     *
     * <p>The callbacks do not debounce. Rapid taps reach the state
     * machine on the same main-thread turn that dispatched them, and
     * the synchronous PLAYING commit at resume, the
     * {@link #mStartToken} bump at pause, and the
     * {@link #mDeferredReconcile} deferral for a next or previous
     * that arrives during a prepare are enough to handle any
     * sequence correctly.</p>
     */
    private void setupMediaSession() {
        try {
            ComponentName mediaButtonReceiver = new ComponentName(
                this,
                androidx.media.session.MediaButtonReceiver.class);
            mMediaSession = new MediaSessionCompat(
                this, "LlamaMusicService", mediaButtonReceiver, null);

            mMediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    onMain(() -> {
                        if (mState == ServiceState.PAUSED) {
                            doResume();
                        } else if (mState == ServiceState.IDLE) {
                            resume();
                        } else if (mState == ServiceState.READY) {
                            togglePlayPause();
                        } else if (mState == ServiceState.PREPARING) {
                            mPausedByTransientLoss = false;
                            if (mPauseAfterPrepare
                                    || !mAutoStartOnPrepared) {
                                mPauseAfterPrepare = false;
                                mAutoStartOnPrepared = true;
                            }
                        }
                    });
                }

                @Override
                public void onPause() {
                    onMain(() -> {
                        mPausedByTransientLoss = false;
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        } else if (mState
                                == ServiceState.PREPARING) {
                            mPauseAfterPrepare = true;
                        }
                    });
                }

                @Override
                public void onSkipToNext() {
                    playNextSong();
                }

                @Override
                public void onSkipToPrevious() {
                    playPreviousSong();
                }

                @Override
                public void onStop() {
                    onMain(() -> {
                        mPausedByTransientLoss = false;
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        }
                    });
                }

                @Override
                public void onPlayFromMediaId(String mediaId,
                                              Bundle extras) {
                    if (mediaId == null) {
                        return;
                    }
                    try {
                        playSong(Integer.parseInt(mediaId));
                    } catch (NumberFormatException ignored) {
                        // The media identifier is not a playlist
                        // index.
                    }
                }
            });

            mMediaSession.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    /**
     * Returns the current media session token, or null when no
     * session exists.
     *
     * @return The session token, or null
     */
    @Nullable
    public MediaSessionCompat.Token getSessionToken() {
        return mMediaSession != null
            ? mMediaSession.getSessionToken() : null;
    }

    /**
     * Writes the current playback state to the media session.
     *
     * <p>Called by {@link NotificationController} on every sync,
     * regardless of whether a render committed. The value is
     * derived from the state machine through
     * {@link #mStateSource}'s {@code sessionPlaybackState()}, so
     * the session receives a state change on every transition.</p>
     *
     * <p>The position is included so the framework delivers the
     * update as a genuine change: it advances with playback and is
     * different on each sync.</p>
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null) {
            return;
        }
        try {
            long actions = PlaybackStateCompat.ACTION_PLAY
                         | PlaybackStateCompat.ACTION_PAUSE
                         | PlaybackStateCompat.ACTION_PLAY_PAUSE
                         | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                         | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackStateCompat.ACTION_STOP;

            PlaybackStateCompat.Builder builder =
                new PlaybackStateCompat.Builder()
                    .setActions(actions)
                    .setState(mStateSource.sessionPlaybackState(),
                        getCurrentPosition(), 1.0f);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state",
                exception);
        }
    }

    // ============================================================================
    // Audio Focus
    // ============================================================================

    /**
     * Creates the audio focus listener and, on API 26 and later,
     * the audio focus request.
     */
    private void setupAudioFocus() {
        mAudioFocusListener =
            focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(
                        AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(
                AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    /**
     * Requests audio focus using the API-appropriate mechanism.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null
                && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /**
     * Abandons audio focus using the API-appropriate mechanism.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(
                    mAudioFocusRequest);
            }
        } else if (mAudioManager != null
                && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    /**
     * Reacts to a change in audio focus.
     *
     * <p>A permanent loss pauses and does not resume automatically:
     * the user has moved on to another app or to another permanent
     * audio source. A transient loss pauses and remembers that it
     * did so, because focus returns when the interrupting app is
     * done — a phone call ending, a navigation prompt finishing, a
     * WhatsApp video status completing. When
     * {@link AudioManager#AUDIOFOCUS_GAIN} arrives and the flag is
     * still set, playback resumes from where it paused.</p>
     *
     * <p>A transient loss that arrives while the state machine is
     * PREPARING sets a pending pause on the auto-start and remembers
     * that it did so. When {@link AudioManager#AUDIOFOCUS_GAIN}
     * arrives before the prepare completes, the pending pause is
     * cleared and the auto-start is re-armed, so the prepared song
     * plays. When the prepare completed to READY while the loss was
     * active, gain starts the song through the same READY branch the
     * play button uses. This is what keeps the song's playback — and
     * the notification's play/pause icon — in agreement with the
     * focus state at every point between the loss and the gain.</p>
     *
     * <p>A duck request —
     * {@link AudioManager#AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK} — does
     * not pause. The interrupting app has signalled that it is
     * willing to share the output at a lower level, which is what a
     * navigation prompt or a notification tone does. The service
     * lowers the MediaPlayer's own output volume to
     * {@link #DUCK_VOLUME_FRACTION} and leaves playback running. The
     * system stream volume is untouched, so the volume slider does
     * not move and the music-stream receiver does not fire.
     * {@link AudioManager#AUDIOFOCUS_GAIN} restores the volume to
     * full.</p>
     *
     * <p>The notification surface follows the state machine's
     * destination through the same commit path every transition
     * uses: {@link #broadcastUpdate}. A focus event that changes the
     * state — a loss that pauses, a gain that resumes — runs through
     * {@link #doPause} or {@link #doResume}, both of which commit
     * through {@code broadcastUpdate}. A focus event that does not
     * change the state — a duck, a gain without a remembered pause,
     * a loss while already paused — has nothing to commit; the
     * notification already shows the correct state from the last
     * transition.</p>
     *
     * @param focusChange The audio focus change code
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                if (mState == ServiceState.PLAYING) {
                    mPausedByTransientLoss = false;
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPauseAfterPrepare = true;
                    mAutoStartOnPrepared = false;
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mState == ServiceState.PLAYING) {
                    mPausedByTransientLoss = true;
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPauseAfterPrepare = true;
                    mAutoStartOnPrepared = false;
                    mPausedByTransientLoss = true;
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                mIsDucked = true;
                onPlayer(() -> applyDuckVolume(mMediaPlayer));
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (mIsDucked) {
                    mIsDucked = false;
                    onPlayer(() -> applyDuckVolume(mMediaPlayer));
                }
                if (mPausedByTransientLoss) {
                    mPausedByTransientLoss = false;
                    if (mState == ServiceState.PAUSED) {
                        doResume();
                        // doResume() calls broadcastUpdate(),
                        // which commits the notification.
                    } else if (mState == ServiceState.PREPARING) {
                        // The transient loss suppressed the
                        // auto-start. Clear the pending pause and
                        // re-arm the auto-start so the prepared
                        // song plays.
                        mPauseAfterPrepare = false;
                        mAutoStartOnPrepared = true;
                    } else if (mState == ServiceState.READY) {
                        // The prepare completed to READY while the
                        // transient loss was active. Start now.
                        togglePlayPause();
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * Applies the current duck state to the given player's output
     * volume.
     *
     * <p>Called on the player thread. The system stream volume is
     * not touched: the duck is a scale applied to the MediaPlayer's
     * own output. This is what keeps the volume slider still and
     * keeps the music-stream receiver out of the duck path.</p>
     *
     * <p>Reads {@link #mIsDucked} and writes the resulting volume
     * to the given player. A null player is a no-op, which is the
     * case when the state machine is IDLE and no MediaPlayer is
     * bound.</p>
     *
     * @param player The player to adjust, or null when none exists
     */
    private void applyDuckVolume(@Nullable MediaPlayer player) {
        if (player == null) {
            return;
        }
        final float volume = mIsDucked ? DUCK_VOLUME_FRACTION : 1.0f;
        try {
            player.setVolume(volume, volume);
        } catch (Exception ignored) {
            // The player is not in a state that permits volume
            // changes.
        }
    }

    // ============================================================================
    // Media Button
    // ============================================================================

    /**
     * Handles a media key press.
     *
     * <p>The PREPARING branches of {@code MEDIA_PLAY} and
     * {@code MEDIA_PAUSE} mirror the transport API's PREPARING
     * handling: a play key clears a pending pause and re-arms the
     * auto-start, and a pause key schedules a pending pause. The
     * play/pause icon follows the key press at commit, on the same
     * main-thread turn as the player screen.</p>
     *
     * @param keyCode The key code to handle
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNextSong();
                return;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPreviousSong();
                return;
            }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mState == ServiceState.PAUSED) {
                    doResume();
                } else if (mState == ServiceState.IDLE) {
                    resume();
                } else if (mState == ServiceState.READY) {
                    togglePlayPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPausedByTransientLoss = false;
                    if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                        mPauseAfterPrepare = false;
                        mAutoStartOnPrepared = true;
                    }
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mState == ServiceState.PLAYING) {
                    mPausedByTransientLoss = false;
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPausedByTransientLoss = false;
                    mPauseAfterPrepare = true;
                }
                break;
            default:
                break;
        }
    }

    // ============================================================================
    // Broadcasts
    // ============================================================================

    /**
     * Sends the current full playback snapshot as an
     * {@code UPDATE_PLAYER} broadcast, and commits the same snapshot
     * to the notification synchronously with the broadcast.
     *
     * <p>The broadcast carries the window the carousel should render,
     * the direction and restart of the transition that produced it,
     * and the display title and artist the player UI should show.
     * Every surface — the player UI, the carousel, the notification,
     * the media session — reads the same display song and the same
     * transition. The {@code is_playing} extra reports the destination
     * of the current transition, not its intermediate position, so the
     * play/pause button never flashes a pause icon during a
     * next/previous switch.</p>
     *
     * <p>The window carries the service's monotonic transition
     * counter; the direction and the restart are properties of that
     * same generation. The carousel compares the generation against
     * the one it last held to distinguish a fresh transition from a
     * re-publication, and reads the direction and restart to choose
     * the animation. This is the single signal every transition the
     * service can produce reaches the carousel through, whether it
     * originated from a transport button, a swipe, a headset key, an
     * automatic advance, a stall recovery, or an error fallback.</p>
     *
     * <p>After the broadcast has been dispatched, the same snapshot
     * is committed to the notification through
     * {@link NotificationController#commitFromBroadcast(long,
     * NotificationController.RenderSnapshot)}. The activity's receiver
     * has run by that point — the broadcast is in-process and the
     * receiver is registered on the main thread — so the notification
     * commit lands in the same main-thread turn as the activity's
     * adoption of the window and the transition. The notification and
     * the activity therefore draw the same song, artist, art, and
     * play/pause icon at the same instant, which is the behaviour the
     * user observes from the player and expects from the
     * notification.</p>
     *
     * <p>This is the only path that commits the notification. State
     * changes that do not end in a broadcast — a hover, a transient
     * focus duck, a metadata cache update — do not change the
     * notification, because they do not change what the notification
     * displays.</p>
     */
    private void broadcastUpdate() {
        PlaybackWindow windowSnapshot = getWindowSnapshot();
        Song displaySong = getDisplaySong();
        final long generation = mGeneration;

        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", generation);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", isPlaying());
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());

        // Window the carousel renders.
        intent.putExtra("window_previous_path",
            windowSnapshot.previousPath);
        intent.putExtra("window_current_path",
            windowSnapshot.currentPath);
        intent.putExtra("window_next_path",
            windowSnapshot.nextPath);

        // Transition the window describes.
        intent.putExtra("transition_direction", mGenerationDirection);
        intent.putExtra("transition_restart", mGenerationRestart);

        // Display identity the player UI renders.
        if (displaySong != null) {
            intent.putExtra("display_title", displaySong.getTitle());
            intent.putExtra("display_artist",
                displaySong.getArtist());
        }

        sendBroadcast(intent);

        if (mNotificationController != null) {
            // Commit the notification synchronously with the
            // broadcast. The snapshot is built from the same
            // main-thread state the broadcast describes, so the
            // notification and the activity commit the same data on
            // the same turn — the same pattern MusicPlayer's receiver
            // uses. A stale poll from the controller's awareness loop
            // is dropped by the generation filter in
            // NotificationController.syncOnce().
            final NotificationController.RenderSnapshot snapshot =
                mStateSource.snapshotForNotification();
            mNotificationController.commitFromBroadcast(
                generation, snapshot);
        }
    }

    /**
     * Sends the current audio session identifier as an
     * {@code AUDIO_SESSION_CHANGED} broadcast.
     *
     * @param sessionId The audio session identifier
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    // ============================================================================
    // Receivers
    // ============================================================================

    /**
     * Registers the receiver for playback parameter update
     * broadcasts.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(
                        intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiverSafely(mPlaybackParamsReceiver,
            new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    /**
     * Registers the receiver for playlist clear broadcasts.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiverSafely(mClearPlaylistReceiver,
            new IntentFilter("CLEAR_PLAYLIST"));
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(
                        intent.getAction())) {
                    // The notification surface observes theme
                    // changes on its own.
                }
            }
        };
        registerReceiverSafely(mThemeReceiver,
            new IntentFilter("THEME_COLOR_CHANGED"));
    }

    /**
     * Registers the receiver for playing state query broadcasts.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response =
                        new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", isPlaying());
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_LAST_PLAYING, isPlaying())
                        .apply();
                }
            }
        };
        registerReceiverSafely(mGetPlayingStateReceiver,
            new IntentFilter("GET_PLAYING_STATE"));
    }

    /**
     * Registers the receiver for sort mode change broadcasts.
     *
     * <p>The reorder that this receiver performs changes what every
     * index means. The shuffle peek memos, the shuffle history, and
     * the cached window are all index-keyed, so all three are cleared
     * before the re-anchor. The current song is re-anchored on its
     * path, which is stable across the reorder; without the clears, a
     * subsequent next or previous request would resolve through an
     * index that no longer refers to the same song.</p>
     *
     * <p>The sort itself runs on {@link #mSortExecutor}, not on the
     * main thread. A sort-mode change is a user-initiated reorder of
     * the whole playlist, and its cost is proportional to the
     * playlist size. Running it on the main thread would stall the
     * spinner the playlist activity shows for the operation, which is
     * the exact animation that tells the user the reorder is in
     * progress. The receiver captures the current playlist, the
     * anchor path, and the requested sort mode on the main thread,
     * sorts a copy on the executor, and posts the swap and the
     * broadcast back to the main thread.</p>
     *
     * <p>A newer sort-mode change that arrives while an older one is
     * still sorting sets {@link #mCurrentSortMode} to the newer
     * value. The older task's commit step compares that field against
     * the mode it captured; a mismatch means the newer task is
     * responsible for the reorder and the older task exits without
     * touching state. This is what makes a rapid sequence of sort
     * taps produce one committed reorder at the end of the sequence
     * rather than one per tap.</p>
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(
                        intent.getAction())) {
                    return;
                }
                final int newSortMode = intent.getIntExtra(
                    EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) {
                    return;
                }
                mCurrentSortMode = newSortMode;
                saveSortMode();

                if (mCurrentPlaylist == null
                        || mCurrentPlaylist.isEmpty()) {
                    return;
                }

                // Capture on the main thread: the snapshot to sort,
                // the anchor that must survive the reorder, and the
                // mode the sort will run under. The current-mode
                // field is the supersede token.
                final ArrayList<Song> snapshot =
                    new ArrayList<>(mCurrentPlaylist);
                final String anchorPath = pathOf(mCurrentIndex);
                final int sortMode = newSortMode;

                mSortExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Collections.sort(snapshot,
                            getComparatorForSortMode(sortMode));

                        onMain(new Runnable() {
                            @Override
                            public void run() {
                                if (mCurrentSortMode != sortMode) {
                                    // A newer cycle has superseded
                                    // this one; its own task is
                                    // responsible for the reorder.
                                    return;
                                }
                                if (mCurrentPlaylist == null
                                        || mCurrentPlaylist
                                            .isEmpty()) {
                                    return;
                                }

                                mCurrentPlaylist = snapshot;

                                // The reorder invalidates every
                                // index-keyed state. The shuffle peek
                                // memos, the shuffle history, and the
                                // cached window all name indices, and
                                // those indices no longer refer to
                                // the same songs.
                                clearShufflePeek();
                                if (mShuffleHistory != null) {
                                    mShuffleHistory.clear();
                                }

                                if (anchorPath != null) {
                                    int newIndex =
                                        indexOfPath(anchorPath);
                                    if (newIndex >= 0) {
                                        mCurrentIndex = newIndex;
                                        mTargetIndex = newIndex;
                                        saveCurrentPlayingIndex();
                                    }
                                }
                                broadcastUpdate();
                            }
                        });
                    }
                });
            }
        };
        registerReceiverSafely(mSortModeReceiver,
            new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    /**
     * Registers the receiver for sync completion broadcasts.
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                broadcastUpdate();
            }
        };
        registerReceiverSafely(mSyncCompleteReceiver,
            new IntentFilter("SYNC_COMPLETE"));
    }

    /**
     * Registers the receiver for genre update broadcasts.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(
                        intent.getAction())) {
                    return;
                }
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(
                        intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    broadcastUpdate();
                }
            }
        };
        registerReceiverSafely(mGenreUpdateReceiver,
            new IntentFilter(ACTION_GENRE_UPDATE));
    }

    /**
     * Registers the receiver for soft playlist update broadcasts.
     */
    private void registerUpdatePlaylistReceiver() {
        mUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYLIST".equals(
                            intent.getAction())) {
                    return;
                }

                if (mMusicLibrary == null) {
                    mMusicLibrary =
                        new MusicLibrary(MusicService.this);
                }
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs =
                    mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiverSafely(mUpdatePlaylistReceiver,
            new IntentFilter("UPDATE_PLAYLIST"));
    }

    /**
     * Registers the receiver for pending song path broadcasts.
     */
    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(
                        intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) {
                        setPendingSongPath(path);
                    }
                }
            }
        };
        registerReceiverSafely(mSetPendingSongReceiver,
            new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    /**
     * Registers the receiver for library reset broadcasts emitted
     * by {@link PlaylistManager}.
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!PlaylistManager.ACTION_LIBRARY_RESET.equals(
                        intent.getAction())) {
                    return;
                }
                final boolean preserveSettings =
                    intent.getBooleanExtra(
                        PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);
                Log.d(TAG,
                    "LIBRARY_RESET received (preserve_settings="
                        + preserveSettings + ")");
                onMain(() -> {
                    stopCompletely();

                    mResolvedArtPath = null;
                    mResolvedArt = null;
                    if (mCurrentArtLoad != null) {
                        mCurrentArtLoad.cancel(true);
                        mCurrentArtLoad = null;
                    }
                    if (mArtCache != null) {
                        mArtCache.evictAll();
                    }

                    if (mMusicLibrary != null) {
                        mMusicLibrary.invalidate();
                    }

                    if (!preserveSettings) {
                        mRepeatMode = 0;
                        mIsShuffle = false;
                        mCurrentSortMode = SORT_TITLE_AZ;
                        if (mShuffleHistory != null) {
                            mShuffleHistory.clear();
                        }
                        clearShufflePeek();
                        savePlayerState();
                        saveSortMode();
                    }
                });
            }
        };
        registerReceiverSafely(mLibraryResetReceiver,
            new IntentFilter(PlaylistManager.ACTION_LIBRARY_RESET));
    }

    /**
     * Registers the receiver for the Bluetooth-disconnect pause
     * request.
     *
     * <p>Called from {@link #onCreate()} and unregistered in
     * {@link #onDestroy()}. The service owns this pause because the
     * service owns the audio: a headset disconnect is an event about
     * the audio destination, and the component that owns the audio is
     * the component that must be able to end it. The receiver is live
     * for the service's whole lifetime, so a disconnect that arrives
     * while no activity is showing still pauses the music.</p>
     *
     * <p>The pause goes through {@link #pause()}, the same method the
     * transport button uses. The state machine, the persisted
     * {@code last_playing} flag, the notification surface, and the
     * {@code UPDATE_PLAYER} broadcast all come out the normal way.</p>
     */
    private void registerBluetoothPauseReceiver() {
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_BLUETOOTH_PAUSE.equals(
                            intent.getAction())) {
                    return;
                }
                pause();
            }
        };
        registerReceiverSafely(mBluetoothPauseReceiver,
            new IntentFilter(ACTION_BLUETOOTH_PAUSE));
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG,
                "Failed to register receiver", exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) {
            return;
        }
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
            // The receiver was already unregistered.
        }
    }

    // ============================================================================
    // Genre and Metadata Updates
    // ============================================================================

    /**
     * Updates the in-memory genre of the given song.
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     */
    private void updateGenreInPlaylist(@NonNull String songPath,
                                       @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath)
                || TextUtils.isEmpty(newGenre)) {
            return;
        }
        if (mCurrentPlaylist == null) {
            return;
        }

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                }
                break;
            }
        }
    }

    /**
     * Refreshes the current song's metadata from a change published
     * by {@link MetadataEditor}.
     *
     * @param songPath Path of the edited song
     * @param newTitle New title, or null for no change
     * @param newArtist New artist, or null for no change
     * @param newAlbum New album, or null for no change
     * @param newGenre New genre, or null for no change
     * @param albumArtBytes New album art bytes, or null for no
     *        change
     * @param albumArtRemoved True when the album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            if (mCurrentPlaylist == null) {
                return;
            }
            if (mCurrentIndex < 0
                    || mCurrentIndex >= mCurrentPlaylist.size()) {
                return;
            }

            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null
                    || !songPath.equals(currentSong.getPath())) {
                return;
            }

            String finalTitle =
                (newTitle != null && !newTitle.isEmpty())
                    ? newTitle : currentSong.getTitle();
            String finalArtist =
                (newArtist != null && !newArtist.isEmpty())
                    ? newArtist : currentSong.getArtist();
            String finalAlbum =
                (newAlbum != null && !newAlbum.isEmpty())
                    ? newAlbum : currentSong.getAlbum();
            String finalGenre =
                (newGenre != null && !newGenre.isEmpty())
                    ? newGenre : currentSong.getGenre();

            Song updatedSong = new Song(finalTitle, finalArtist,
                finalAlbum, finalGenre, songPath,
                currentSong.getDuration(), null);
            if (currentSong.getUri() != null) {
                updatedSong.setUri(currentSong.getUri());
            }

            mCurrentPlaylist.set(mCurrentIndex, updatedSong);
            SongDatabase.getInstance(this).insertSong(updatedSong);

            if (albumArtRemoved) {
                mArtCache.remove(songPath);
                mResolvedArtPath = songPath;
                mResolvedArt = null;
            } else if (albumArtBytes != null) {
                mArtCache.remove(songPath);
                final Bitmap newArt = BitmapFactory.decodeByteArray(
                    albumArtBytes, 0, albumArtBytes.length);
                if (newArt != null) {
                    mArtCache.put(songPath, newArt);
                    mResolvedArtPath = songPath;
                    mResolvedArt = newArt;
                }
            }

            broadcastUpdate();
        });
    }
}