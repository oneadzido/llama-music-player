package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MusicService - Background service for music playback with dual-player optimization.
 * 
 * <p>This service implements a dual-player strategy for optimal user experience.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> for playlist access (readers can read concurrently)</li>
 *   <li><b>AtomicBoolean</b> for transition flags and state flags</li>
 *   <li><b>AtomicInteger</b> for counters and preparation IDs</li>
 *   <li><b>AtomicLong</b> for position tracking</li>
 *   <li><b>Copy-on-write</b> pattern for playlist snapshots</li>
 *   <li><b>Handler</b> for main thread operations</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // =========================================================================
    // Constants
    // =========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Notification ID for foreground service. */
    private static final int NOTIFICATION_ID = 1;
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Broadcast action when player is ready. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Delay for song transition in milliseconds. */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Broadcast action for audio session changes. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 1500;
    
    /** Maximum stall time before recovery in milliseconds. */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    /** Maximum recovery attempts before giving up. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Broadcast action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Delay before pre-initialization in milliseconds. */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay before resetting seek state in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    // Dual-Player Constants
    /** Timeout for LlamaPlayer initialization in milliseconds. */
    private static final int LLAMA_PLAYER_INIT_TIMEOUT_MS = 5000;
    
    /** Number of songs to preload ahead. */
    private static final int PRELOAD_AHEAD_COUNT = 2;
    
    /** Delay before starting preload in milliseconds. */
    private static final int PRELOAD_START_DELAY_MS = 500;
    
    /** Duration of transition fade in milliseconds. */
    private static final int TRANSITION_FADE_MS = 50;
    
    /** Number of volume fade steps. */
    private static final int VOLUME_FADE_STEPS = 10;
    
    /** Interval between volume fade steps in milliseconds. */
    private static final int VOLUME_FADE_INTERVAL_MS = 20;
    
    // Sort Mode Constants
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    // =========================================================================
    // Static Members
    // =========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static volatile int sCurrentAudioSessionId = 0;
    
    /**
     * Returns the current audio session ID.
     * Thread-safe: volatile read.
     *
     * @return Current audio session ID, or 0 if not available
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    /**
     * Sets the player state before folder update.
     * Thread-safe: uses SharedPreferences.apply().
     *
     * @param context Application context
     * @param need True if state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before folder update.
     * Thread-safe: uses SharedPreferences.
     *
     * @param context Application context
     * @return True if state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before folder update.
     * Thread-safe: uses SharedPreferences.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    // =========================================================================
    // Member Variables
    // =========================================================================
    
    /** Application context. */
    @NonNull private Context mContext;
    
    /** Native MediaPlayer fallback player. */
    @Nullable private NativeMediaPlayer mNativeMediaPlayer;
    
    /** LlamaPlayer with SoundTouch effects. */
    @Nullable private LlamaPlayer mLlamaPlayer;
    
    /** Decoder manager for audio decoding. */
    @Nullable private DecoderManager mDecoderManager;
    
    /** PlaybackController for centralized state management. */
    @Nullable private PlaybackController mPlaybackController;
    
    /** Notification service for media controls. */
    @Nullable private NotificationService mNotificationService;
    
    // =========================================================================
    // Playlist Management (Thread-Safe with ReadWriteLock)
    // =========================================================================
    
    /** Read/write lock for playlist access. */
    private final ReentrantReadWriteLock mPlaylistLock = new ReentrantReadWriteLock();
    
    /** Current playlist (protected by mPlaylistLock). */
    @Nullable private ArrayList<Song> mCurrentPlaylist;
    
    /** Current playlist index (volatile for visibility). */
    private volatile int mCurrentIndex = -1;
    
    /** Repeat mode: 0=off, 1=all, 2=one. */
    private volatile int mRepeatMode = 0;
    
    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** True if playback is currently active. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Current playlist sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // =========================================================================
    // Dual-Player State (Thread-Safe)
    // =========================================================================
    
    /** Flag indicating if LlamaPlayer is ready. */
    private final AtomicBoolean mLlamaPlayerReady = new AtomicBoolean(false);
    
    /** Flag indicating if LlamaPlayer preload was attempted. */
    private final AtomicBoolean mLlamaPlayerPreloadAttempted = new AtomicBoolean(false);
    
    /** Flag indicating if LlamaPlayer has failed. */
    private final AtomicBoolean mLlamaPlayerFailed = new AtomicBoolean(false);
    
    /** Flag indicating if LlamaPlayer is currently active. */
    private volatile boolean mIsUsingLlamaPlayer = false;
    
    /** Flag indicating if NativeMediaPlayer has started. */
    private volatile boolean mNativePlayerStarted = false;
    
    /** Pending transition position for LlamaPlayer. */
    private volatile int mPendingTransitionPosition = -1;
    
    /** Flag indicating if a transition is in progress. */
    private final AtomicBoolean mTransitionInProgress = new AtomicBoolean(false);
    
    /** Current playback position (atomic for thread safety). */
    private final AtomicInteger mCurrentPlaybackPosition = new AtomicInteger(0);
    
    /** Handler for preload operations. */
    private final Handler mPreloadHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for preload operations. */
    @Nullable private Runnable mPreloadRunnable = null;
    
    /** Index of the next song to preload. */
    private volatile int mNextPreloadIndex = -1;
    
    /** Flag indicating if transition to LlamaPlayer is queued. */
    private volatile boolean mTransitionToLlamaQueued = false;
    
    // =========================================================================
    // Seek and State Management (Thread-Safe)
    // =========================================================================
    
    /** Flag indicating if a seek operation is in progress. */
    private final AtomicBoolean mSeekInProgress = new AtomicBoolean(false);
    
    /** Last seek position (-1 if none). */
    private volatile int mLastSeekPosition = -1;
    
    /** Flag indicating if preparing fallback player. */
    private final AtomicBoolean mIsPreparingFallback = new AtomicBoolean(false);
    
    /** Global preparation ID for stale callback detection. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID. */
    private volatile int mCurrentPrepId = -1;
    
    /** Flag indicating if completion is in progress. */
    private final AtomicBoolean mIsCompleting = new AtomicBoolean(false);
    
    /** Main thread handler for UI operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // =========================================================================
    // Audio Focus and Wake Lock
    // =========================================================================
    
    /** AudioManager for audio focus management. */
    @Nullable private AudioManager mAudioManager;
    
    /** Audio focus change listener. */
    @Nullable private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O and above. */
    @Nullable private AudioFocusRequest mAudioFocusRequest;
    
    /** Wake lock for background playback. */
    @Nullable private PowerManager.WakeLock mWakeLock;
    
    // =========================================================================
    // Media Session
    // =========================================================================
    
    /** MediaSession for lock screen controls. */
    @Nullable private MediaSession mMediaSession;
    
    // =========================================================================
    // Shuffle History
    // =========================================================================
    
    /** History of shuffled song indices. */
    @Nullable private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle. */
    @Nullable private Random mRandom;
    
    // =========================================================================
    // Pending Operations
    // =========================================================================
    
    /** Pending playlist to apply. */
    @Nullable private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if there is a pending playlist. */
    private boolean mHasPendingPlaylist = false;
    
    /** Flag indicating if restoring playback after update. */
    private boolean mIsRestoringPlayback = false;
    
    /** Number of recovery attempts. */
    private int mRecoveryAttempts = 0;
    
    /** Timestamp when playback started. */
    private long mPlaybackStartTime = 0;
    
    // =========================================================================
    // Broadcast Receivers
    // =========================================================================
    
    /** Receiver for playback parameter updates. */
    @Nullable private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for getting playing state. */
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    
    // =========================================================================
    // Binder
    // =========================================================================
    
    /**
     * Local binder for service binding.
     * Provides access to the MusicService instance.
     */
    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    private final IBinder mBinder = new LocalBinder();
    
    // =========================================================================
    // Sort Comparator Classes (thread-safe as they have no state)
    // =========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle() != null ? a.getTitle() : "";
            String titleB = b.getTitle() != null ? b.getTitle() : "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle() != null ? a.getTitle() : "";
            String titleB = b.getTitle() != null ? b.getTitle() : "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist() != null ? a.getArtist() : "";
            String artistB = b.getArtist() != null ? b.getArtist() : "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist() != null ? a.getArtist() : "";
            String artistB = b.getArtist() != null ? b.getArtist() : "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum() != null ? a.getAlbum() : "";
            String albumB = b.getAlbum() != null ? b.getAlbum() : "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum() != null ? a.getAlbum() : "";
            String albumB = b.getAlbum() != null ? b.getAlbum() : "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre() != null ? a.getGenre() : "";
            String genreB = b.getGenre() != null ? b.getGenre() : "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre() != null ? a.getGenre() : "";
            String genreB = b.getGenre() != null ? b.getGenre() : "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by date (oldest first), then by title.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by date (newest first), then by title.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // =========================================================================
    // Service Lifecycle Methods
    // =========================================================================
    
    /**
     * Called when the service is created.
     * 
     * <p>Initializes all components including:
     * <ul>
     *   <li>Notification service and foreground service</li>
     *   <li>Audio manager and audio focus</li>
     *   <li>Media session for lock screen controls</li>
     *   <li>PlaybackController and EqualizerManager</li>
     *   <li>Dual-player initialization (NativeMediaPlayer and LlamaPlayer)</li>
     * </ul>
     * </p>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        // Note: mContext is initialized in onCreate, not as field initializer
        // This is safe because onCreate runs on main thread
        mContext = getApplicationContext();
        
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        createForegroundNotificationChannel();
        Notification notification = createMinimalForegroundNotification();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.d(TAG, "Foreground service started");
        
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();
        
        mPlaybackController = PlaybackController.getInstance();
        EqualizerManager.getInstance(this);
        
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // DUAL-PLAYER INITIALIZATION
        initNativeMediaPlayer();
        initLlamaPlayerInBackground();
        
        registerReceivers();
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is started.
     *
     * @param intent The intent that was used to start
     * @param flags Additional data about the start request
     * @param startId A unique integer representing the start request
     * @return The return code indicating how to continue
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "ACTION_PLAY_PAUSE":
                    togglePlayPause();
                    break;
                case "ACTION_NEXT":
                    playNext();
                    break;
                case "ACTION_PREV":
                    playPrevious();
                    break;
                case "ACTION_CLOSE":
                    handleCloseAction();
                    break;
                case "ACTION_STOP_NOTIFICATION":
                    if (mNotificationService != null) {
                        mNotificationService.stopForeground();
                    }
                    break;
                case "PLAY_SONG":
                    String songPath = intent.getStringExtra("song_path");
                    if (songPath != null) {
                        playSongByPath(songPath);
                    } else {
                        int position = intent.getIntExtra("position", -1);
                        if (position >= 0) {
                            playSong(position);
                        }
                    }
                    break;
                case "UPDATE_PLAYBACK_PARAMS":
                    updatePlaybackParams();
                    break;
            }
        }
        return START_STICKY;
    }
    
    /**
     * Plays a song by file path.
     *
     * @param filePath The file path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null) return;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                    playSong(i, true);
                    return;
                }
            }
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Handles the close action to stop the service.
     */
    private void handleCloseAction() {
        savePlayerState();
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.stop();
        }
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.stop();
        }
        
        mPlaylistLock.writeLock().lock();
        try {
            if (mCurrentPlaylist != null) {
                mCurrentPlaylist.clear();
            }
        } finally {
            mPlaylistLock.writeLock().unlock();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and cleans up.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        if (mPreloadRunnable != null) {
            mPreloadHandler.removeCallbacks(mPreloadRunnable);
        }
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.release();
            mLlamaPlayer = null;
        }
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.release();
            mNativeMediaPlayer = null;
        }
        if (mDecoderManager != null) {
            mDecoderManager.release();
            mDecoderManager = null;
        }
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        
        super.onDestroy();
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    /**
     * Returns a thread-safe snapshot of the current playlist.
     * Use this method instead of direct access to mCurrentPlaylist.
     *
     * @return A copy of the current playlist, or empty list if null
     */
    @NonNull
    private ArrayList<Song> getPlaylistSnapshot() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null) {
                return new ArrayList<>();
            }
            return new ArrayList<>(mCurrentPlaylist);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Updates the playlist with a new list (thread-safe).
     *
     * @param newPlaylist The new playlist (can be null)
     * @param preserveCurrentSong Whether to try to preserve the current song
     */
    public void setPlaylist(ArrayList<Song> newPlaylist, boolean preserveCurrentSong) {
        mPlaylistLock.writeLock().lock();
        try {
            String currentSongPath = null;
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    currentSongPath = currentSong.getPath();
                }
            }
            
            if (newPlaylist == null || newPlaylist.isEmpty()) {
                handleEmptyPlaylistLocked();
                return;
            }
            
            ArrayList<Song> sortedPlaylist = new ArrayList<>(newPlaylist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            int newIndex = -1;
            if (preserveCurrentSong && currentSongPath != null) {
                for (int i = 0; i < sortedPlaylist.size(); i++) {
                    Song song = sortedPlaylist.get(i);
                    if (song != null && currentSongPath.equals(song.getPath())) {
                        newIndex = i;
                        break;
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
            } else if (sortedPlaylist.size() > 0) {
                mCurrentIndex = 0;
                prepareSong(mCurrentIndex, 0);
            }
            
            preloadNextSongs();
            
        } finally {
            mPlaylistLock.writeLock().unlock();
        }
        
        broadcastUpdate();
        createNotification();
    }
    
    /**
     * Handles empty playlist case (must be called with write lock held).
     */
    private void handleEmptyPlaylistLocked() {
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.stop();
        }
        if (mLlamaPlayer != null && mLlamaPlayerReady.get()) {
            mLlamaPlayer.stop();
        }
        
        mCurrentPlaylist = null;
        mCurrentIndex = -1;
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.reset();
        }
        
        if (mShuffleHistory != null) mShuffleHistory.clear();
        createNotification();
        broadcastUpdate();
    }
    
    /**
     * Gets the current song (thread-safe, returns a copy if needed).
     *
     * @return The current Song, or null
     */
    @Nullable
    public Song getCurrentSong() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                Song song = mCurrentPlaylist.get(mCurrentIndex);
                if (song != null) {
                    // Return a defensive copy if needed
                    return new Song(
                        song.getTitle(), song.getArtist(), song.getAlbum(),
                        song.getGenre(), song.getPath(), song.getDuration(), song.getUri()
                    );
                }
            }
            return null;
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    // =========================================================================
    // NativeMediaPlayer Initialization
    // =========================================================================
    
    /**
     * Initializes the NativeMediaPlayer fallback player.
     * Sets up all callbacks for prepared, completion, error, position update,
     * state change, and audio session ID events.
     */
    private void initNativeMediaPlayer() {
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.release();
        }
        
        mNativeMediaPlayer = new NativeMediaPlayer(this);
        mNativeMediaPlayer.setListener(new NativeMediaPlayer.NativePlayerListener() {
            @Override
            public void onPrepared() {
                Log.d(TAG, "NativeMediaPlayer: onPrepared() - READY");
                handleNativePlayerPrepared();
            }
            
            @Override
            public void onCompletion() {
                Log.d(TAG, "NativeMediaPlayer: onCompletion()");
                handleCompletion();
            }
            
            @Override
            public void onError(int what, int extra, @NonNull String message) {
                Log.e(TAG, "NativeMediaPlayer error: " + message);
                handleNativePlayerError();
            }
            
            @Override
            public void onPositionUpdate(int positionMs, int durationMs) {
                mCurrentPlaybackPosition.set(positionMs);
                if (!mIsUsingLlamaPlayer && mPlaybackController != null && !mSeekInProgress.get()) {
                    mPlaybackController.updatePosition(positionMs, "NativeMediaPlayer.onPositionUpdate");
                    mPlaybackController.setDuration(durationMs, "NativeMediaPlayer.onPositionUpdate");
                }
            }
            
            @Override
            public void onStateChanged(NativeMediaPlayer.State newState, NativeMediaPlayer.State oldState) {
                handleNativePlayerStateChange(newState, oldState);
            }
            
            @Override
            public void onAudioSessionIdAvailable(int sessionId) {
                sCurrentAudioSessionId = sessionId;
                broadcastAudioSessionChanged(sCurrentAudioSessionId);
                EqualizerManager.getInstance(MusicService.this)
                    .attachToAudioSession(sCurrentAudioSessionId);
                Log.d(TAG, "NativeMediaPlayer audio session: " + sessionId);
            }
        });
        
        Log.d(TAG, "NativeMediaPlayer initialized");
    }
    
    // =========================================================================
    // LlamaPlayer Background Preload
    // =========================================================================
    
    /**
     * Initializes LlamaPlayer in the background for seamless transition.
     * 
     * <p>This method starts a background thread that initializes the SoundTouch
     * processor and preloads the next song. If LlamaPlayer initializes successfully,
     * it will be ready to take over playback when needed.</p>
     */
    private void initLlamaPlayerInBackground() {
        if (mLlamaPlayerPreloadAttempted.getAndSet(true)) {
            Log.d(TAG, "LlamaPlayer preload already attempted");
            return;
        }
        
        if (!SoundTouch.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available");
            mLlamaPlayerFailed.set(true);
            return;
        }
        
        mPreloadRunnable = () -> {
            Log.d(TAG, "Starting LlamaPlayer background preload...");
            
            try {
                mDecoderManager = new DecoderManager();
                
                mLlamaPlayer = new LlamaPlayer(MusicService.this);
                mLlamaPlayer.setListener(new LlamaPlayer.PlaybackListener() {
                    @Override
                    public void onStateChanged(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
                        handleLlamaPlayerStateChange(newState, oldState);
                    }
                    
                    @Override
                    public void onPrepared() {
                        Log.d(TAG, "LlamaPlayer: onPrepared() - READY!");
                        mLlamaPlayerReady.set(true);
                        
                        if (mPendingTransitionPosition >= 0) {
                            transitionToLlamaPlayer(mPendingTransitionPosition);
                            mPendingTransitionPosition = -1;
                        } else if (mNativePlayerStarted && mCurrentPlaybackPosition.get() > 0 && !mTransitionToLlamaQueued) {
                            mTransitionToLlamaQueued = true;
                            transitionToLlamaPlayer(mCurrentPlaybackPosition.get());
                        }
                    }
                    
                    @Override
                    public void onCompletion() {
                        Log.d(TAG, "LlamaPlayer: onCompletion()");
                        handleCompletion();
                    }
                    
                    @Override
                    public void onPositionUpdate(long position) {
                        if (mIsUsingLlamaPlayer && mPlaybackController != null && !mSeekInProgress.get()) {
                            mPlaybackController.updatePosition(position, "LlamaPlayer.onPositionUpdate");
                        }
                        mCurrentPlaybackPosition.set((int) position);
                    }
                    
                    @Override
                    public void onError(String error) {
                        Log.e(TAG, "LlamaPlayer error: " + error);
                        mLlamaPlayerReady.set(false);
                        mLlamaPlayerFailed.set(true);
                        
                        if (mIsUsingLlamaPlayer) {
                            fallbackToNativePlayer();
                        }
                    }
                });
                
                preloadNextSongs();
                Log.d(TAG, "LlamaPlayer background preload started");
                
            } catch (Exception e) {
                Log.e(TAG, "Failed to initialize LlamaPlayer", e);
                mLlamaPlayerReady.set(false);
                mLlamaPlayerFailed.set(true);
            }
        };
        
        mPreloadHandler.postDelayed(mPreloadRunnable, PRELOAD_START_DELAY_MS);
    }
    
    /**
     * Preloads the next song in the playlist for seamless transitions.
     */
    private void preloadNextSongs() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                return;
            }
            
            int nextIndex = mCurrentIndex + 1;
            if (nextIndex >= mCurrentPlaylist.size()) {
                if (mRepeatMode == 1) {
                    nextIndex = 0;
                } else {
                    return;
                }
            }
            
            mNextPreloadIndex = nextIndex;
            Song nextSong = mCurrentPlaylist.get(nextIndex);
            if (nextSong != null && nextSong.getPath() != null) {
                Log.d(TAG, "Preloading next song: " + nextSong.getTitle());
            }
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    // =========================================================================
    // Transition Methods
    // =========================================================================
    
    /**
     * Transitions playback from NativeMediaPlayer to LlamaPlayer.
     * 
     * <p>This method performs a cross-fade transition to ensure smooth audio
     * when switching players. It fades out the NativeMediaPlayer while fading
     * in the LlamaPlayer for seamless audio experience.</p>
     *
     * @param positionMs The position in milliseconds to seek to in LlamaPlayer
     */
    private void transitionToLlamaPlayer(int positionMs) {
        if (mTransitionInProgress.getAndSet(true)) {
            Log.d(TAG, "Transition already in progress");
            return;
        }
        
        if (mLlamaPlayer == null || !mLlamaPlayerReady.get()) {
            Log.d(TAG, "LlamaPlayer not ready yet");
            mPendingTransitionPosition = positionMs;
            mTransitionInProgress.set(false);
            return;
        }
        
        if (!mIsUsingLlamaPlayer) {
            Log.d(TAG, "Starting transition to LlamaPlayer at position " + positionMs + "ms");
            
            try {
                final float currentVolume;
                if (mNativeMediaPlayer != null) {
                    currentVolume = mNativeMediaPlayer.getVolume();
                } else {
                    currentVolume = 1.0f;
                }
                
                Song currentSong = getCurrentSong();
                if (currentSong != null && currentSong.getPath() != null) {
                    mLlamaPlayer.reset();
                    mLlamaPlayer.setDataSource(currentSong.getPath());
                    mLlamaPlayer.prepareAsync();
                    
                    final int finalPosition = positionMs;
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                            mLlamaPlayer.seekTo(finalPosition);
                            
                            if (mIsPlaying.get()) {
                                performCrossFadeTransition(currentVolume);
                            } else {
                                completeTransition();
                            }
                        }
                    }, 100);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Transition to LlamaPlayer failed", e);
                mLlamaPlayerFailed.set(true);
                mTransitionInProgress.set(false);
            }
        }
    }
    
    /**
     * Performs a cross-fade transition between players.
     *
     * @param startVolume The starting volume for the fade out
     */
    private void performCrossFadeTransition(float startVolume) {
        // Fade out NativeMediaPlayer
        for (int i = VOLUME_FADE_STEPS; i >= 0; i--) {
            final float volume = startVolume * i / VOLUME_FADE_STEPS;
            final int delay = (VOLUME_FADE_STEPS - i) * VOLUME_FADE_INTERVAL_MS;
            
            mMainHandler.postDelayed(() -> {
                if (mNativeMediaPlayer != null) {
                    mNativeMediaPlayer.setVolume(volume);
                }
            }, delay);
        }
        
        // Start LlamaPlayer and fade in
        mMainHandler.postDelayed(() -> {
            if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                int llamaSessionId = mLlamaPlayer.getAudioSessionId();
                if (llamaSessionId > 0) {
                    sCurrentAudioSessionId = llamaSessionId;
                    broadcastAudioSessionChanged(sCurrentAudioSessionId);
                    EqualizerManager.getInstance(MusicService.this)
                        .attachToAudioSession(sCurrentAudioSessionId);
                }
                
                mLlamaPlayer.start();
                mIsUsingLlamaPlayer = true;
                mIsPlaying.set(true);
                
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(true, "transitionToLlamaPlayer");
                }
                
                for (int i = 0; i <= VOLUME_FADE_STEPS; i++) {
                    final float volume = startVolume * i / VOLUME_FADE_STEPS;
                    final int delay = i * VOLUME_FADE_INTERVAL_MS;
                    
                    mMainHandler.postDelayed(() -> {
                        if (mLlamaPlayer != null) {
                            mLlamaPlayer.setVolume(volume);
                        }
                    }, delay);
                }
                
                mMainHandler.postDelayed(() -> {
                    if (mNativeMediaPlayer != null) {
                        mNativeMediaPlayer.pause();
                    }
                    mTransitionInProgress.set(false);
                }, TRANSITION_FADE_MS);
            }
        }, VOLUME_FADE_INTERVAL_MS * VOLUME_FADE_STEPS);
    }
    
    /**
     * Completes the transition without cross-fade.
     * Used when playback is not active during transition.
     */
    private void completeTransition() {
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            int llamaSessionId = mLlamaPlayer.getAudioSessionId();
            if (llamaSessionId > 0) {
                sCurrentAudioSessionId = llamaSessionId;
                broadcastAudioSessionChanged(sCurrentAudioSessionId);
                EqualizerManager.getInstance(MusicService.this)
                    .attachToAudioSession(sCurrentAudioSessionId);
            }
            
            mLlamaPlayer.start();
            mIsUsingLlamaPlayer = true;
            mIsPlaying.set(true);
            
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(true, "transitionToLlamaPlayer");
            }
            
            if (mNativeMediaPlayer != null) {
                mNativeMediaPlayer.pause();
            }
        }
        mTransitionInProgress.set(false);
    }
    
    /**
     * Falls back to NativeMediaPlayer when LlamaPlayer fails.
     */
    private void fallbackToNativePlayer() {
        Log.w(TAG, "Falling back to NativeMediaPlayer");
        
        mIsUsingLlamaPlayer = false;
        mNativePlayerStarted = false;
        
        int currentPosition = mCurrentPlaybackPosition.get();
        Song currentSong = getCurrentSong();
        
        if (currentSong != null && mNativeMediaPlayer != null) {
            mNativeMediaPlayer.setDataSource(currentSong.getPath());
            mNativeMediaPlayer.prepareAsync();
            
            final int finalPosition = currentPosition;
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
                    mNativeMediaPlayer.seekTo(finalPosition);
                    if (mIsPlaying.get()) {
                        mNativeMediaPlayer.start();
                    }
                }
            }, 100);
        }
        
        sendPlayerStatusBroadcast(false);
    }
    
    // =========================================================================
    // Player State Handlers
    // =========================================================================
    
    /**
     * Handles NativeMediaPlayer prepared event.
     */
    private void handleNativePlayerPrepared() {
        mIsPreparingFallback.set(false);
        mNativePlayerStarted = true;
        
        if (mPlaybackController != null) {
            mPlaybackController.setPrepared(true, "NativeMediaPlayer.onPrepared");
            mPlaybackController.setDuration(mNativeMediaPlayer.getDuration(), "NativeMediaPlayer.onPrepared");
            
            Song currentSong = getCurrentSong();
            if (currentSong != null) {
                mPlaybackController.updateSong(currentSong, "NativeMediaPlayer.onPrepared");
            }
        }
        
        updateMediaSessionMetadata();
        sendPlayerStatusBroadcast(false);
        
        Intent readyIntent = new Intent(ACTION_PLAYER_READY);
        sendBroadcast(readyIntent);
        
        broadcastUpdate();
        createNotification();
    }
    
    /**
     * Handles NativeMediaPlayer state changes.
     *
     * @param newState The new state
     * @param oldState The previous state
     */
    private void handleNativePlayerStateChange(NativeMediaPlayer.State newState, NativeMediaPlayer.State oldState) {
        Log.d(TAG, "NativeMediaPlayer state: " + oldState + " -> " + newState);
        
        switch (newState) {
            case STARTED:
                if (!mIsUsingLlamaPlayer) {
                    mIsPlaying.set(true);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(true, "NativeMediaPlayer.STARTED");
                    }
                    requestAudioFocus();
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire(3600000);
                    }
                }
                break;
                
            case PAUSED:
                if (!mIsUsingLlamaPlayer) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "NativeMediaPlayer.PAUSED");
                    }
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                    }
                    abandonAudioFocus();
                }
                break;
                
            case COMPLETED:
                if (!mIsUsingLlamaPlayer) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "NativeMediaPlayer.COMPLETED");
                    }
                }
                break;
                
            case ERROR:
            case RELEASED:
                if (!mIsUsingLlamaPlayer) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "NativeMediaPlayer.ERROR");
                    }
                }
                break;
                
            default:
                break;
        }
        
        broadcastUpdate();
        createNotification();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Handles LlamaPlayer state changes.
     *
     * @param newState The new state
     * @param oldState The previous state
     */
    private void handleLlamaPlayerStateChange(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
        Log.d(TAG, "LlamaPlayer state: " + oldState + " -> " + newState);
        
        switch (newState) {
            case STARTED:
                if (mIsUsingLlamaPlayer) {
                    mIsPlaying.set(true);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(true, "LlamaPlayer.STARTED");
                    }
                }
                break;
                
            case PAUSED:
                if (mIsUsingLlamaPlayer) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "LlamaPlayer.PAUSED");
                    }
                }
                break;
                
            case COMPLETED:
                if (mIsUsingLlamaPlayer) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "LlamaPlayer.COMPLETED");
                    }
                }
                break;
                
            case PREPARED:
                if (mPlaybackController != null) {
                    mPlaybackController.setPrepared(true, "LlamaPlayer.PREPARED");
                    if (mLlamaPlayer != null) {
                        mPlaybackController.setDuration(mLlamaPlayer.getDuration(), "LlamaPlayer.PREPARED");
                    }
                }
                break;
                
            default:
                break;
        }
    }
    
    /**
     * Handles NativeMediaPlayer errors.
     */
    private void handleNativePlayerError() {
        Log.e(TAG, "NativeMediaPlayer error");
        mIsPreparingFallback.set(false);
        
        if (mPlaybackController != null) {
            mPlaybackController.notifyOperationFailed("play", "NativeMediaPlayer error");
        }
        
        playNext();
    }
    
    /**
     * Handles song completion (end of stream reached).
     */
    private void handleCompletion() {
        if (!mIsCompleting.compareAndSet(false, true)) {
            Log.d(TAG, "handleCompletion already in progress");
            return;
        }
        
        try {
            broadcastSongCompletion();
            
            mPlaylistLock.readLock().lock();
            try {
                if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "handleCompletion");
                        mPlaybackController.setPrepared(false, "handleCompletion");
                    }
                    updateNotificationPlaybackState(false);
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                    }
                    return;
                }
            } finally {
                mPlaylistLock.readLock().unlock();
            }
            
            if (mRepeatMode == 2) {
                if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
                    mLlamaPlayer.seekTo(0);
                    mLlamaPlayer.start();
                } else if (mNativeMediaPlayer != null) {
                    mNativeMediaPlayer.seekTo(0);
                    mNativeMediaPlayer.start();
                }
            } else if (mRepeatMode == 1) {
                playNext();
            } else {
                mPlaylistLock.readLock().lock();
                try {
                    if (mCurrentPlaylist != null && mCurrentIndex + 1 < mCurrentPlaylist.size()) {
                        playNext();
                    } else {
                        mIsPlaying.set(false);
                        if (mPlaybackController != null) {
                            mPlaybackController.setPlaying(false, "handleCompletion.end");
                            mPlaybackController.setPrepared(false, "handleCompletion.end");
                        }
                        updateNotificationPlaybackState(false);
                        
                        if (mWakeLock != null && mWakeLock.isHeld()) {
                            mWakeLock.release();
                        }
                        
                        savePlayingState();
                        
                        if (mNotificationService != null) {
                            mNotificationService.updateSongInfo(null, null, null);
                            mNotificationService.setPlayingState(false);
                            mNotificationService.forceUpdate();
                        }
                    }
                } finally {
                    mPlaylistLock.readLock().unlock();
                }
            }
        } finally {
            mIsCompleting.set(false);
        }
    }
    
    // =========================================================================
    // Playlist Helper Methods
    // =========================================================================
    
    /**
     * Prepares a song for playback.
     *
     * @param index The index of the song to prepare
     * @param seekPosition The position to seek to (0 for start)
     */
    private void prepareSong(int index, int seekPosition) {
        mPlaylistLock.readLock().lock();
        Song song;
        try {
            if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
                return;
            }
            song = mCurrentPlaylist.get(index);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
        
        if (song == null || song.getPath() == null) {
            return;
        }
        
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.setDataSource(song.getPath());
            mNativeMediaPlayer.prepareAsync();
            
            if (seekPosition > 0) {
                final int finalSeek = seekPosition;
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
                        mNativeMediaPlayer.seekTo(finalSeek);
                    }
                }, 100);
            }
        }
    }
    
    // =========================================================================
    // Playback Control Methods
    // =========================================================================
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The index of the song to play
     * @param autoStart True to start playback immediately
     */
    public synchronized void playSong(int index, boolean autoStart) {
        mPlaylistLock.readLock().lock();
        Song song;
        try {
            if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
                return;
            }
            song = mCurrentPlaylist.get(index);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
        
        if (song == null || song.getPath() == null) {
            return;
        }
        
        mCurrentIndex = index;
        mIsPlaying.set(autoStart);
        
        if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.setDataSource(song.getPath());
            mNativeMediaPlayer.prepareAsync();
            
            if (autoStart) {
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
                        mNativeMediaPlayer.start();
                        mNativePlayerStarted = true;
                    }
                }, 100);
            }
        }
        
        savePlayerState();
        broadcastUpdate();
        createNotification();
    }
    
    /**
     * Plays a song at the specified index with auto-start enabled.
     *
     * @param index The index of the song to play
     */
    public void playSong(int index) {
        playSong(index, true);
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                return;
            }
            
            int nextIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                    mShuffleHistory.clear();
                }
                do {
                    nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                         mShuffleHistory.contains(nextIndex));
                mShuffleHistory.add(nextIndex);
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            playSong(nextIndex, true);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                return;
            }
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null && mShuffleHistory.size() >= 2) {
                prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                mShuffleHistory.remove(mShuffleHistory.size() - 1);
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            playSong(prevIndex, true);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        if (mIsPlaying.get()) {
            pause();
        } else if (isAnyPlayerPrepared()) {
            resume();
        } else {
            mPlaylistLock.readLock().lock();
            try {
                if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                    playSong(0, true);
                }
            } finally {
                mPlaylistLock.readLock().unlock();
            }
        }
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
            mLlamaPlayer.pause();
        } else if (mNativeMediaPlayer != null) {
            mNativeMediaPlayer.pause();
        }
        mIsPlaying.set(false);
        
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(false, "pause");
        }
        
        savePlayingState();
        broadcastUpdate();
        createNotification();
    }
    
    /**
     * Resumes playback.
     */
    public void resume() {
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            mLlamaPlayer.start();
        } else if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
            mNativeMediaPlayer.start();
        } else {
            mPlaylistLock.readLock().lock();
            try {
                if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                    playSong(mCurrentIndex >= 0 ? mCurrentIndex : 0, true);
                }
            } finally {
                mPlaylistLock.readLock().unlock();
            }
        }
        
        mIsPlaying.set(true);
        
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(true, "resume");
        }
        
        savePlayingState();
        broadcastUpdate();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in milliseconds.
     *
     * @param position The position to seek to
     */
    public void seekTo(int position) {
        mSeekInProgress.set(true);
        mLastSeekPosition = position;
        
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            mLlamaPlayer.seekTo(position);
        } else if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
            mNativeMediaPlayer.seekTo(position);
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.updatePosition(position, "seekTo");
        }
        
        mMainHandler.postDelayed(() -> {
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
        }, SEEK_RESET_DELAY_MS);
    }
    
    /**
     * Updates playback parameters (pitch and speed) from EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            mLlamaPlayer.setPitch(semitones);
            mLlamaPlayer.setTempo(tempo);
            Log.d(TAG, "LlamaPlayer params updated");
        }
        
        if (mNativeMediaPlayer != null && mNativeMediaPlayer.isPrepared()) {
            mNativeMediaPlayer.setPlaybackParams(tempo, (float) Math.pow(2.0, semitones / 12.0));
            Log.d(TAG, "NativeMediaPlayer params updated");
        }
    }
    
    // =========================================================================
    // Getter Methods
    // =========================================================================
    
    /**
     * Checks if any player is currently playing.
     *
     * @return True if playing
     */
    public boolean isAnyPlayerPlaying() {
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
            return mLlamaPlayer.isPlaying();
        }
        if (mNativeMediaPlayer != null) {
            return mNativeMediaPlayer.isPlaying();
        }
        return false;
    }
    
    /**
     * Checks if any player is prepared for playback.
     *
     * @return True if prepared
     */
    public boolean isAnyPlayerPrepared() {
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
            return mLlamaPlayer.isPrepared();
        }
        if (mNativeMediaPlayer != null) {
            return mNativeMediaPlayer.isPrepared();
        }
        return false;
    }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        if (mSeekInProgress.get() && mLastSeekPosition >= 0) {
            return mLastSeekPosition;
        }
        
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
            return (int) mLlamaPlayer.getCurrentPosition();
        }
        if (mNativeMediaPlayer != null) {
            return mNativeMediaPlayer.getCurrentPosition();
        }
        return 0;
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Duration
     */
    public int getDuration() {
        if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
            return (int) mLlamaPlayer.getDuration();
        }
        if (mNativeMediaPlayer != null) {
            return mNativeMediaPlayer.getDuration();
        }
        return 0;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Returns the current repeat mode.
     *
     * @return Repeat mode (0=off, 1=all, 2=one)
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode Repeat mode (0=off, 1=all, 2=one)
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        // Handle Bluetooth connection if needed
    }
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Refreshes the notification.
     */
    public void refreshNotification() {
        createNotification();
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    /**
     * Handles media button events.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying.get() && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying.get()) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Refreshes metadata for a song after editing.
     *
     * @param songPath The path of the song
     * @param newTitle The new title (null if unchanged)
     * @param newArtist The new artist (null if unchanged)
     * @param newAlbum The new album (null if unchanged)
     * @param newGenre The new genre (null if unchanged)
     * @param albumArtBytes The new album art bytes (null if unchanged)
     * @param albumArtRemoved True if album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        // Update the song in the playlist if it's currently loaded
        mPlaylistLock.writeLock().lock();
        try {
            if (mCurrentPlaylist != null) {
                for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                    Song song = mCurrentPlaylist.get(i);
                    if (song != null && songPath.equals(song.getPath())) {
                        Song updatedSong = new Song(
                            newTitle != null ? newTitle : song.getTitle(),
                            newArtist != null ? newArtist : song.getArtist(),
                            newAlbum != null ? newAlbum : song.getAlbum(),
                            newGenre != null ? newGenre : song.getGenre(),
                            song.getPath(),
                            song.getDuration(),
                            song.getUri()
                        );
                        mCurrentPlaylist.set(i, updatedSong);
                        break;
                    }
                }
            }
        } finally {
            mPlaylistLock.writeLock().unlock();
        }
        
        // Refresh the current song display if this is the current song
        Song currentSong = getCurrentSong();
        if (currentSong != null && songPath.equals(currentSong.getPath())) {
            if (mPlaybackController != null) {
                Song refreshedSong = new Song(
                    newTitle != null ? newTitle : currentSong.getTitle(),
                    newArtist != null ? newArtist : currentSong.getArtist(),
                    newAlbum != null ? newAlbum : currentSong.getAlbum(),
                    newGenre != null ? newGenre : currentSong.getGenre(),
                    currentSong.getPath(),
                    currentSong.getDuration(),
                    currentSong.getUri()
                );
                mPlaybackController.updateSong(refreshedSong, "refreshMetadataForSong");
            }
            broadcastUpdate();
            createNotification();
        }
    }
    
    // =========================================================================
    // Private Helper Methods
    // =========================================================================
    
    /**
     * Gets the last modified date of a song file.
     *
     * @param song The song
     * @return Last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    /**
     * Returns the comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return The comparator
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    /**
     * Loads sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state to SharedPreferences.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Updates the notification playback state.
     *
     * @param isPlaying True if playing
     */
    private void updateNotificationPlaybackState(boolean isPlaying) {
        if (mNotificationService != null) {
            mNotificationService.setPlayingState(isPlaying);
            mNotificationService.forceUpdate();
        }
    }
    
    /**
     * Creates and updates the notification.
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        Song song = getCurrentSong();
        boolean hasSong = (song != null);
        
        if (hasSong) {
            mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            mNotificationService.setPlayingState(mIsPlaying.get());
        } else {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        mNotificationService.forceUpdate();
    }
    
    /**
     * Broadcasts a playlist update to connected activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying.get());
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts song completion event.
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts audio session change to EqualizerActivity.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Sends a player status broadcast.
     *
     * @param isLlamaPlayerActive True if LlamaPlayer is active
     */
    private void sendPlayerStatusBroadcast(boolean isLlamaPlayerActive) {
        Intent intent = new Intent(ACTION_PLAYER_STATUS_UPDATE);
        intent.putExtra("player_type", isLlamaPlayerActive ? "LlamaPlayer" : "NativeMediaPlayer");
        sendBroadcast(intent);
    }
    
    // =========================================================================
    // Notification and Foreground Methods
    // =========================================================================
    
    /**
     * Creates the notification channel for Android O and above.
     */
    private void createForegroundNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "foreground_channel",
                "Music Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Required for background music playback");
            channel.setSound(null, null);
            channel.enableVibration(false);
            
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * Creates a minimal foreground notification.
     *
     * @return The notification
     */
    private Notification createMinimalForegroundNotification() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, MusicPlayer.class), flags);
        
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("foreground_channel");
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
               .setContentTitle("Llama Music Player")
               .setContentText("ENJOY THE WAVES")
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setVisibility(Notification.VISIBILITY_PUBLIC);
        
        return builder.build();
    }
    
    // =========================================================================
    // Media Session Methods
    // =========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying.get() && mCurrentIndex >= 0) {
                            resume();
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying.get()) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        seekTo((int) pos);
                    }
                });
                
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Updates the MediaSession metadata for lock screen display.
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            return;
        }
        
        android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
        builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                          currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                          currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                          currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album");
        builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
        
        mMediaSession.setMetadata(builder.build());
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        try {
            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
            long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                          PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                          PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
            int state = mIsPlaying.get() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
            stateBuilder.setState(state, getCurrentPosition(), 1.0f);
            stateBuilder.setActions(actions);
            mMediaSession.setPlaybackState(stateBuilder.build());
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSession state", e);
        }
    }
    
    // =========================================================================
    // Audio Focus Methods
    // =========================================================================
    
    /**
     * Sets up audio focus for proper audio handling with other apps.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Requests audio focus for playback.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus when playback stops.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Handles audio focus changes.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                Log.d(TAG, "Audio focus lost - pausing playback");
                if (mIsPlaying.get()) {
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                Log.d(TAG, "Audio focus ducking - reducing volume");
                if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
                    mLlamaPlayer.duck();
                } else if (mNativeMediaPlayer != null) {
                    mNativeMediaPlayer.duck();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                Log.d(TAG, "Audio focus gained - restoring volume");
                if (mIsUsingLlamaPlayer && mLlamaPlayer != null) {
                    mLlamaPlayer.unduck();
                } else if (mNativeMediaPlayer != null) {
                    mNativeMediaPlayer.unduck();
                }
                break;
                
            default:
                break;
        }
    }
    
    // =========================================================================
    // Broadcast Receiver Registration
    // =========================================================================
    
    /**
     * Registers broadcast receivers for service communication.
     */
    private void registerReceivers() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
        
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying.get());
                    Song currentSong = getCurrentSong();
                    responseIntent.putExtra("song_path", currentSong != null ? currentSong.getPath() : null);
                    responseIntent.putExtra("position", getCurrentPosition());
                    sendBroadcast(responseIntent);
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }
}