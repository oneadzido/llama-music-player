package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback.
 * 
 * <p>This service is the single source of truth for all playback state:
 * playlist, current song, position, play/pause state, repeat mode, shuffle mode.
 * Activities must read state from this service and never maintain local copies.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All state is protected by mPlayerLock. Async preparation uses a preparation ID
 * to ignore stale callbacks. Broadcasts are sent to notify activities of changes.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 2.0
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast when playlist changes (order, content, or current index). */
    public static final String ACTION_PLAYLIST_CHANGED = "com.ark.llama.PLAYLIST_CHANGED";
    
    /** Broadcast when playback state changes (play/pause, position). */
    public static final String ACTION_PLAYBACK_STATE_CHANGED = "com.ark.llama.PLAYBACK_STATE_CHANGED";

    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";

    // Sort mode constants
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;

    // Health check constants
    private static final long HEALTH_CHECK_INTERVAL_MS = 3000;
    private static final long MAX_STALL_TIME_MS = 5000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    // ========================================================================
    // Fields
    // ========================================================================
    
    private MediaPlayer mMediaPlayer;
    private final Object mPlayerLock = new Object();
    private ArrayList<Song> mCurrentPlaylist;
    private int mCurrentIndex = -1;
    private boolean mIsPlaying = false;
    private int mRepeatMode = 0;
    private boolean mIsShuffle = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;

    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    private int mCurrentPrepId = -1;

    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    private AudioFocusRequest mAudioFocusRequest;
    private MediaSession mMediaSession;
    private NotificationService mNotificationService;

    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;

    private Handler mHealthHandler;
    private Runnable mHealthCheckRunnable;
    private int mRecoveryAttempts = 0;
    private long mPlaybackStartTime = 0;

    private BroadcastReceiver mSortModeReceiver;

    // ========================================================================
    // Binder
    // ========================================================================
    
    public class LocalBinder extends Binder {
        public MusicService getService() { return MusicService.this; }
    }
    private final IBinder mBinder = new LocalBinder();

    // ========================================================================
    // Service Lifecycle
    // ========================================================================
    
    @Override
    public void onCreate() {
        super.onCreate();
        mNotificationService = new NotificationService(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        mShuffleHistory = new ArrayList<>();
        mRandom = new Random();
        mHealthHandler = new Handler(Looper.getMainLooper());

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerSortModeReceiver();
        Log.d(TAG, "MusicService created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "ACTION_PLAY_PAUSE": togglePlayPause(); break;
                case "ACTION_NEXT": playNext(); break;
                case "ACTION_PREV": playPrevious(); break;
                case "ACTION_STOP": stopCompletely(); break;
                case "PLAY_SONG":
                    String path = intent.getStringExtra("song_path");
                    if (path != null) playSongByPath(path);
                    else {
                        int pos = intent.getIntExtra("position", -1);
                        if (pos >= 0) playSong(pos);
                    }
                    break;
            }
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        saveFullState();
        releaseMediaPlayer();
        if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
        if (mNotificationService != null) mNotificationService.stopForeground();
        if (mMediaSession != null) mMediaSession.release();
        abandonAudioFocus();
        unregisterReceiverSafely(mSortModeReceiver);
        Log.d(TAG, "MusicService destroyed");
        super.onDestroy();
    }

    // ========================================================================
    // Public API - State Queries (Thread-Safe)
    // ========================================================================

    /**
     * Returns a copy of the current playlist.
     * Activities must use this to display the playlist.
     *
     * @return A new ArrayList containing all songs in the current playlist
     */
    @NonNull
    public ArrayList<Song> getCurrentPlaylist() {
        synchronized (mPlayerLock) {
            return mCurrentPlaylist != null ? new ArrayList<>(mCurrentPlaylist) : new ArrayList<>();
        }
    }

    /**
     * Returns the number of songs in the current playlist.
     *
     * @return Playlist size, or 0 if no playlist
     */
    public int getPlaylistSize() {
        synchronized (mPlayerLock) {
            return mCurrentPlaylist == null ? 0 : mCurrentPlaylist.size();
        }
    }

    /**
     * Returns the index of the currently playing song.
     *
     * @return Current index, or -1 if none
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Returns whether playback is currently active.
     *
     * @return True if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying && isPlayerReady();
    }

    /**
     * Returns whether the MediaPlayer is prepared (song loaded).
     *
     * @return True if prepared
     */
    public boolean isPlayerPrepared() {
        return isPlayerReady();
    }

    /**
     * Returns the currently playing song.
     *
     * @return Current Song object, or null if none
     */
    @Nullable
    public Song getCurrentSong() {
        synchronized (mPlayerLock) {
            if (mCurrentIndex >= 0 && mCurrentPlaylist != null && mCurrentIndex < mCurrentPlaylist.size()) {
                return mCurrentPlaylist.get(mCurrentIndex);
            }
            return null;
        }
    }

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Position, or 0 if not available
     */
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    Log.e(TAG, "getCurrentPosition error", e);
                }
            }
            return 0;
        }
    }

    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    Log.e(TAG, "getDuration error", e);
                }
            }
            return 0;
        }
    }

    /**
     * Returns the current repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }

    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        broadcastPlaylistChanged();
    }

    /**
     * Returns whether shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }

    /**
     * Sets shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        broadcastPlaylistChanged();
    }

    // ========================================================================
    // Public API - Playlist and Playback Control
    // ========================================================================

    /**
     * Sets the current playlist.
     * 
     * @param playlist The new playlist
     * @param preserveCurrentSong True to keep the same song (by path) if possible
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                saveFullState();
                broadcastPlaylistChanged();
                return;
            }
            
            // Apply current sort mode
            ArrayList<Song> sorted = new ArrayList<>(playlist);
            Collections.sort(sorted, getComparatorForSortMode(mCurrentSortMode));
            
            // Find the index of the currently playing song if preserving
            int newIndex = -1;
            if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                for (int i = 0; i < sorted.size(); i++) {
                    if (sorted.get(i).getPath().equals(currentPath)) {
                        newIndex = i;
                        break;
                    }
                }
            }
            
            // Fallback to saved last song path
            if (newIndex == -1 && preserveCurrentSong) {
                String savedPath = getSavedSongPath();
                if (savedPath != null) {
                    for (int i = 0; i < sorted.size(); i++) {
                        if (sorted.get(i).getPath().equals(savedPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
            }
            
            if (newIndex == -1) newIndex = 0;
            
            boolean needsReset = (mCurrentIndex != newIndex) || 
                                 (mCurrentPlaylist != null && mCurrentPlaylist.size() != sorted.size());
            if (needsReset) {
                resetPlayerSafely();
            }
            
            mCurrentPlaylist = sorted;
            mCurrentIndex = newIndex;
            saveCurrentPlayingIndex();
            
            // Resume playback if it was playing before
            if (preserveCurrentSong && wasPlayingBeforeRestart()) {
                int savedPos = getSavedPosition();
                prepareAndPlay(mCurrentIndex, savedPos);
            } else if (preserveCurrentSong) {
                prepareOnly(mCurrentIndex);
            }
            
            broadcastPlaylistChanged();
        }
    }

    /**
     * Plays a song at the specified index.
     *
     * @param index The playlist index
     */
    public void playSong(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.w(TAG, "playSong: invalid index " + index);
            return;
        }
        prepareAndPlay(index, 0);
    }

    /**
     * Plays a song by its file path.
     *
     * @param path The absolute file path
     */
    public void playSongByPath(@NonNull String path) {
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(path)) {
                playSong(i);
                return;
            }
        }
        Log.w(TAG, "playSongByPath: path not found in playlist: " + path);
    }

    /**
     * Plays the next song (respects shuffle and repeat).
     */
    public void playNext() {
        if (!acquireTransitionLock()) return;
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory.size() >= mCurrentPlaylist.size()) mShuffleHistory.clear();
                do {
                    nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && mShuffleHistory.contains(nextIndex));
                mShuffleHistory.add(nextIndex);
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            mCurrentIndex = nextIndex;
            playSong(mCurrentIndex);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, 500);
        }
    }

    /**
     * Plays the previous song (respects shuffle and repeat).
     */
    public void playPrevious() {
        if (!acquireTransitionLock()) return;
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory.size() >= 2) {
                prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                mShuffleHistory.remove(mShuffleHistory.size() - 1);
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            mCurrentIndex = prevIndex;
            playSong(mCurrentIndex);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, 500);
        }
    }

    /**
     * Toggles between play and pause.
     */
    public void togglePlayPause() {
        if (mMediaPlayer != null && mCurrentIndex >= 0) {
            if (mIsPlaying) pause();
            else resume();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
            playSong(0);
        }
        broadcastPlaybackStateChanged();
        createNotification();
    }

    /**
     * Pauses playback.
     */
    public void pause() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try {
                    mMediaPlayer.pause();
                } catch (Exception e) {
                    Log.e(TAG, "pause error", e);
                }
                mIsPlaying = false;
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                savePlayingState();
                broadcastPlaybackStateChanged();
                createNotification();
            }
        }
    }

    /**
     * Resumes playback.
     */
    public void resume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                if (!mIsPlaying) {
                    requestAudioFocus();
                    try {
                        mMediaPlayer.start();
                    } catch (Exception e) {
                        Log.e(TAG, "resume start error", e);
                        return;
                    }
                    mIsPlaying = true;
                    startHealthMonitoring();
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                    }
                    savePlayingState();
                    broadcastPlaybackStateChanged();
                    createNotification();
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                playSong(0);
            }
        }
    }

    /**
     * Seeks to the specified position.
     *
     * @param position Position in milliseconds
     */
    public void seekTo(int position) {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    mMediaPlayer.seekTo(position);
                } catch (Exception e) {
                    Log.e(TAG, "seekTo error", e);
                }
            }
        }
    }

    /**
     * Stops playback and clears the playlist.
     */
    public void stopCompletely() {
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            resetPlayerSafely();
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            mIsPlaying = false;
            saveFullState();
            broadcastPlaylistChanged();
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
    }

    // ========================================================================
    // Internal MediaPlayer Methods (Thread-Safe)
    // ========================================================================

    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }

    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) {}
                try {
                    mMediaPlayer.reset();
                } catch (Exception e) {
                    Log.w(TAG, "reset failed, releasing", e);
                    releaseMediaPlayer();
                }
            }
            mIsPlaying = false;
        }
    }

    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) {}
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }

    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.e(TAG, "prepareAndPlay: invalid index");
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping");
            return;
        }
        
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        
        final Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "prepareAndPlay: null song or path");
            return;
        }
        
        try {
            synchronized (mPlayerLock) {
                // Reset or create player
                if (mMediaPlayer == null) {
                    mMediaPlayer = new MediaPlayer();
                } else {
                    removeAllListeners(mMediaPlayer);
                    try {
                        mMediaPlayer.reset();
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "reset failed, creating new player", e);
                        mMediaPlayer.release();
                        mMediaPlayer = new MediaPlayer();
                    }
                }
                
                mMediaPlayer.setDataSource(song.getPath());
                mIsPreparing.set(true);
                mCurrentIndex = index;
                
                mMediaPlayer.setOnPreparedListener(mp -> {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId || mMediaPlayer != mp) {
                            Log.d(TAG, "Stale onPrepared callback, ignoring");
                            return;
                        }
                        mIsPreparing.set(false);
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration");
                                return;
                            }
                            if (seekPosition > 0 && seekPosition < duration - 500) {
                                mp.seekTo(seekPosition);
                            }
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = SystemClock.elapsedRealtime();
                            startHealthMonitoring();
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                            }
                            savePlayingState();
                            broadcastPlaybackStateChanged();
                            createNotification();
                        } catch (Exception e) {
                            Log.e(TAG, "onPrepared start error", e);
                            mIsPlaying = false;
                        }
                    }
                });
                
                mMediaPlayer.setOnCompletionListener(mp -> {
                    synchronized (mPlayerLock) {
                        handleCompletion();
                    }
                });
                
                mMediaPlayer.setOnErrorListener((mp, what, extra) -> {
                    Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                    mIsPlaying = false;
                    mIsPreparing.set(false);
                    // Attempt recovery
                    if (mCurrentIndex >= 0 && mCurrentPlaylist != null && mCurrentIndex < mCurrentPlaylist.size()) {
                        final int recoverIndex = mCurrentIndex;
                        final int recoverPos = getCurrentPosition();
                        releaseMediaPlayer();
                        new Handler(Looper.getMainLooper()).postDelayed(() -> prepareAndPlay(recoverIndex, recoverPos), 500);
                    }
                    return true;
                });
                
                mMediaPlayer.prepareAsync();
            }
        } catch (IOException e) {
            Log.e(TAG, "prepareAndPlay data source error", e);
            mIsPreparing.set(false);
        }
    }

    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        
        final Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        
        try {
            synchronized (mPlayerLock) {
                if (mMediaPlayer == null) {
                    mMediaPlayer = new MediaPlayer();
                } else {
                    removeAllListeners(mMediaPlayer);
                    try {
                        mMediaPlayer.reset();
                    } catch (IllegalStateException e) {
                        mMediaPlayer.release();
                        mMediaPlayer = new MediaPlayer();
                    }
                }
                mMediaPlayer.setDataSource(song.getPath());
                mIsPreparing.set(true);
                mCurrentIndex = index;
                
                mMediaPlayer.setOnPreparedListener(mp -> {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId || mMediaPlayer != mp) return;
                        mIsPreparing.set(false);
                        // Do not start playback
                    }
                });
                mMediaPlayer.prepareAsync();
            }
        } catch (IOException e) {
            Log.e(TAG, "prepareOnly error", e);
            mIsPreparing.set(false);
        }
    }

    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            mIsPlaying = false;
            return;
        }
        
        if (mRepeatMode == 2) {
            // Repeat one: replay same song
            seekTo(0);
            if (!mIsPlaying) resume();
        } else if (mRepeatMode == 1 || mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            // End of playlist
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mMediaPlayer != null) {
                try {
                    mMediaPlayer.pause();
                    mMediaPlayer.seekTo(0);
                } catch (Exception ignored) {}
            }
            savePlayingState();
            broadcastPlaybackStateChanged();
            createNotification();
        }
    }

    // ========================================================================
    // Health Check & Recovery
    // ========================================================================

    private void startHealthMonitoring() {
        if (mHealthHandler == null) return;
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = SystemClock.elapsedRealtime();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
    }

    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }

    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        int position = getCurrentPosition();
        long elapsed = SystemClock.elapsedRealtime() - mPlaybackStartTime;
        if (position < 100 && elapsed > MAX_STALL_TIME_MS) {
            Log.w(TAG, "Playback stall detected");
            recoverFromStall();
        } else if (position > 100) {
            mPlaybackStartTime = SystemClock.elapsedRealtime();
        }
    }

    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        mRecoveryAttempts++;
        final int currentIdx = mCurrentIndex;
        final int currentPos = getCurrentPosition();
        stopHealthMonitoring();
        releaseMediaPlayer();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (currentIdx >= 0 && mCurrentPlaylist != null && currentIdx < mCurrentPlaylist.size()) {
                prepareAndPlay(currentIdx, currentPos);
                sendBroadcast(new Intent("PLAYBACK_RECOVERED"));
            }
        }, 500);
    }

    // ========================================================================
    // State Persistence
    // ========================================================================

    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }

    private void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }

    private void saveFullState() {
        savePlayerState();
    }

    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }

    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    private boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }

    private int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }

    private String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }

    // ========================================================================
    // Sort Mode Support
    // ========================================================================

    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle());
            case SORT_TITLE_ZA: return (a, b) -> b.getTitle().compareToIgnoreCase(a.getTitle());
            case SORT_ARTIST_AZ:
                return (a, b) -> {
                    int cmp = a.getArtist().compareToIgnoreCase(b.getArtist());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_ARTIST_ZA:
                return (a, b) -> {
                    int cmp = b.getArtist().compareToIgnoreCase(a.getArtist());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_ALBUM_AZ:
                return (a, b) -> {
                    int cmp = a.getAlbum().compareToIgnoreCase(b.getAlbum());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_ALBUM_ZA:
                return (a, b) -> {
                    int cmp = b.getAlbum().compareToIgnoreCase(a.getAlbum());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_GENRE_AZ:
                return (a, b) -> {
                    int cmp = a.getGenre().compareToIgnoreCase(b.getGenre());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_GENRE_ZA:
                return (a, b) -> {
                    int cmp = b.getGenre().compareToIgnoreCase(a.getGenre());
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_OLDEST:
                return (a, b) -> {
                    long dateA = new File(a.getPath()).lastModified();
                    long dateB = new File(b.getPath()).lastModified();
                    int cmp = Long.compare(dateA, dateB);
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            case SORT_NEWEST:
                return (a, b) -> {
                    long dateA = new File(a.getPath()).lastModified();
                    long dateB = new File(b.getPath()).lastModified();
                    int cmp = Long.compare(dateB, dateA);
                    if (cmp == 0) return a.getTitle().compareToIgnoreCase(b.getTitle());
                    return cmp;
                };
            default: return (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle());
        }
    }

    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newMode) {
                        mCurrentSortMode = newMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                        }
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }

    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        String currentPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
        }
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        if (currentPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                if (mCurrentPlaylist.get(i).getPath().equals(currentPath)) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
            }
        }
        broadcastPlaylistChanged();
        Log.d(TAG, "Playlist reordered with sort mode " + mCurrentSortMode);
    }

    // ========================================================================
    // Broadcast Helpers
    // ========================================================================

    private void broadcastPlaylistChanged() {
        Intent intent = new Intent(ACTION_PLAYLIST_CHANGED);
        sendBroadcast(intent);
    }

    private void broadcastPlaybackStateChanged() {
        Intent intent = new Intent(ACTION_PLAYBACK_STATE_CHANGED);
        intent.putExtra("is_playing", mIsPlaying);
        intent.putExtra("current_index", mCurrentIndex);
        sendBroadcast(intent);
    }

    private void createNotification() {
        if (mNotificationService == null) return;
        Song song = getCurrentSong();
        if (song != null) {
            mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }

    // ========================================================================
    // Audio Focus and MediaSession
    // ========================================================================

    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> {
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    if (mIsPlaying) pause();
                    break;
                // ducking handled automatically
            }
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(attrs)
                .build();
        }
    }

    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mMediaSession = new MediaSession(this, "LlamaMusicService");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() { togglePlayPause(); }
                @Override public void onPause() { pause(); }
                @Override public void onSkipToNext() { playNext(); }
                @Override public void onSkipToPrevious() { playPrevious(); }
                @Override public void onStop() { pause(); }
            });
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        }
    }

    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        PlaybackState.Builder builder = new PlaybackState.Builder();
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                       PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                       PlaybackState.ACTION_STOP;
        int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        builder.setState(state, getCurrentPosition(), 1.0f);
        builder.setActions(actions);
        mMediaSession.setPlaybackState(builder.build());
        Song song = getCurrentSong();
        if (song != null) {
            android.media.MediaMetadata.Builder meta = new android.media.MediaMetadata.Builder();
            meta.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, song.getTitle());
            meta.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, song.getArtist());
            meta.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, song.getAlbum());
            mMediaSession.setMetadata(meta.build());
        }
    }

    // ========================================================================
    // Utility Methods
    // ========================================================================

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        }
    }

    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }

    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }

    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
}