package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MusicService - Background service for music playback with MediaPlayer.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>MediaPlayer-Based Playback</b> - Uses Android's native MediaPlayer for
 *       reliable audio playback across all Android versions</li>
 *   <li><b>Full MediaSession Integration</b> - Complete lock screen controls with
 *       metadata, album art, and playback state</li>
 *   <li><b>Playlist Management</b> - Supports shuffle, repeat modes, and 10 sort modes</li>
 *   <li><b>Playback Persistence</b> - Saves position, playing state, and current song</li>
 *   <li><b>Health Monitoring</b> - Detects and recovers from playback stalls</li>
 *   <li><b>Audio Focus Management</b> - Proper ducking and interruption handling</li>
 *   <li><b>WakeLock Management</b> - Prevents device sleep during playback</li>
 *   <li><b>Broadcast Integration</b> - Communicates with UI components via Intents</li>
 *   <li><b>Equalizer Support</b> - Integrates with EqualizerManager for audio effects</li>
 * </ul>
 * 
 * <h3>Thread Safety Enhancements</h3>
 * <p>This version includes enhanced thread safety beyond the original:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> - For playlist access (multiple readers, single writer)</li>
 *   <li><b>AtomicReference</b> - For current song to prevent torn reads/writes</li>
 *   <li><b>CopyOnWriteArrayList</b> - For shuffle history (thread-safe iteration)</li>
 *   <li><b>AtomicInteger/AtomicBoolean/AtomicLong</b> - For all state variables</li>
 *   <li><b>Stricter locking</b> - All state modifications are properly synchronized</li>
 *   <li><b>Immutable snapshot pattern</b> - For thread-safe playlist iteration</li>
 * </ul>
 * 
 * <h3>MediaSession Lock Screen Integration</h3>
 * <p>The service provides full lock screen controls including:</p>
 * <ul>
 *   <li>Play/Pause/Next/Previous buttons</li>
 *   <li>Song title, artist, album display</li>
 *   <li>Album art image</li>
 *   <li>Seek bar (when supported by device)</li>
 *   <li>Voice command support ("Play [song name]")</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state (true = playing, false = paused). */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state (true = on, false = off). */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state flag before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode from PlaylistActivity. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Intent extra key for sort mode value. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Broadcast action for audio session ID changes (for equalizer attachment). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Delay for song transitions in milliseconds (allows smooth crossfade). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Health check interval in milliseconds (checks for playback stalls). */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    
    /** Maximum time without progress before recovery attempt (5 seconds). */
    private static final int MAX_STALL_TIME_MS = 5000;
    
    /** Maximum recovery attempts before skipping stuck song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    // ========================================================================
    // Sort Mode Constants (10 modes for playlist ordering)
    // ========================================================================
    
    /** Sort by title A-Z (ascending alphabetical). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort by title Z-A (descending alphabetical). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort by artist name A-Z, then by title. */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort by artist name Z-A, then by title. */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort by album name A-Z, then by title. */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort by album name Z-A, then by title. */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort by genre A-Z, then by title. */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort by genre Z-A, then by title. */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort by file modification date (oldest first), then by title. */
    private static final int SORT_OLDEST = 8;
    
    /** Sort by file modification date (newest first), then by title. */
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment (static for cross-component access). */
    private static volatile int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // Enhanced Thread-Safe Members
    // ========================================================================
    
    /**
     * Read/write lock for playlist access.
     * <p><b>Locking Strategy:</b></p>
     * <ul>
     *   <li><b>Read Lock:</b> Used for getAllSongs(), getCurrentSong(), and any
     *       operation that only reads playlist data without modification.</li>
     *   <li><b>Write Lock:</b> Used for setPlaylist(), addSong(), removeSong(),
     *       and any playlist modification.</li>
     * </ul>
     * <p>This allows concurrent reads while ensuring exclusive writes.</p>
     */
    private final ReentrantReadWriteLock mPlaylistLock = new ReentrantReadWriteLock();
    
    /** Read lock for playlist access (multiple readers allowed). */
    private final ReentrantReadWriteLock.ReadLock mPlaylistReadLock = mPlaylistLock.readLock();
    
    /** Write lock for playlist modification (exclusive access). */
    private final ReentrantReadWriteLock.WriteLock mPlaylistWriteLock = mPlaylistLock.writeLock();
    
    /** Lock object for synchronizing all MediaPlayer operations (separate from playlist lock). */
    private final Object mPlayerLock = new Object();
    
    /** 
     * AtomicReference for current song (prevents torn reads/writes).
     * Provides memory visibility guarantees without explicit synchronization.
     */
    private final AtomicReference<Song> mCurrentSongRef = new AtomicReference<>(null);
    
    /** 
     * Thread-safe list for shuffle history.
     * CopyOnWriteArrayList provides safe iteration even during modification.
     */
    private final java.util.concurrent.CopyOnWriteArrayList<Integer> mShuffleHistory = 
        new java.util.concurrent.CopyOnWriteArrayList<>();
    
    /** 
     * Thread-local random generator for better concurrency.
     * Each thread gets its own Random instance, eliminating contention.
     */
    private final ThreadLocal<Random> mRandom = ThreadLocal.withInitial(Random::new);
    
    // ========================================================================
    // Atomic State Variables (Lock-Free, Thread-Safe)
    // ========================================================================
    
    /** Current playlist index (atomic for safe concurrent access). */
    private final AtomicInteger mCurrentIndex = new AtomicInteger(-1);
    
    /** Flag indicating if playback is currently active (atomic). */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if player is prepared (song loaded and ready to play). */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one (atomic). */
    private final AtomicInteger mRepeatMode = new AtomicInteger(0);
    
    /** Flag indicating if shuffle mode is enabled (atomic). */
    private final AtomicBoolean mIsShuffle = new AtomicBoolean(false);
    
    /** Current sort mode for playlist display (atomic). */
    private final AtomicInteger mCurrentSortMode = new AtomicInteger(SORT_TITLE_AZ);
    
    /** Timestamp when current playback started (for health checking). */
    private final AtomicLong mPlaybackStartTime = new AtomicLong(0);
    
    /** Number of recovery attempts for the current song. */
    private final AtomicInteger mRecoveryAttempts = new AtomicInteger(0);
    
    // ========================================================================
    // Async Operation Tracking (Thread-Safe)
    // ========================================================================
    
    /** Flag indicating if a song transition is in progress (prevents concurrent transitions). */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if a song is being prepared asynchronously. */
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    
    /** Global counter for preparation IDs (incremented on each prepare). */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** 
     * Current preparation ID (used to ignore stale onPrepared callbacks).
     * Volatile ensures visibility across threads.
     */
    private volatile int mCurrentPrepId = -1;
    
    // ========================================================================
    // Regular Members (Protected by Locks or Thread-Safe by Design)
    // ========================================================================
    
    /** Native Android MediaPlayer instance for audio playback. */
    private MediaPlayer mMediaPlayer;
    
    /** LRU cache for album art bitmaps to avoid repeated decoding. */
    private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** File path of the album art currently being displayed. */
    private String mCurrentAlbumArtPath = null;
    
    /** Current playlist of Song objects (protected by mPlaylistWriteLock). */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Pending playlist for soft update (used during folder sync). */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    /** WakeLock to prevent device from sleeping during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    /** Audio manager for requesting and abandoning audio focus. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes (phone calls, other apps). */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O+ (API 26+). */
    private AudioFocusRequest mAudioFocusRequest;
    
    /** MediaSession for lock screen controls and Bluetooth headset integration. */
    private MediaSession mMediaSession;
    
    /** Flag indicating if a Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    /** Handler for periodic health checks on the main thread. */
    private Handler mHealthHandler;
    
    /** Runnable that performs the health check. */
    private Runnable mHealthCheckRunnable;
    
    /** Service for managing the media notification. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers (Registered/Unregistered on Main Thread)
    // ========================================================================
    
    /** Receiver for sync state updates (affects notification appearance). */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates (pitch/speed from equalizer). */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clearing the playlist. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes (updates notification colors). */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for requests to get the current playing state. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates from PlaylistActivity. */
    private BroadcastReceiver mSortModeReceiver;
    
    /** Binder instance that allows activities to obtain a reference to this service. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * Allows activities to obtain a direct reference to the service instance.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    /**
     * Immutable snapshot of playlist state for thread-safe reading.
     * 
     * <p>This class creates a defensive copy of the playlist to prevent
     * modification while iterating. Used by methods that need to safely
     * access playlist data without holding the read lock for extended periods.</p>
     */
    private static class PlaylistSnapshot {
        /** Defensive copy of all songs in the playlist (never null). */
        @NonNull final ArrayList<Song> songs;
        
        /** Current playing index at snapshot time. */
        final int currentIndex;
        
        /** Shuffle state at snapshot time. */
        final boolean isShuffle;
        
        /** Repeat mode at snapshot time. */
        final int repeatMode;
        
        /**
         * Constructs an immutable snapshot of playlist state.
         *
         * @param songs The current playlist (will be defensively copied)
         * @param currentIndex The current playing index
         * @param isShuffle Current shuffle state
         * @param repeatMode Current repeat mode
         */
        PlaylistSnapshot(@NonNull ArrayList<Song> songs, int currentIndex, 
                         boolean isShuffle, int repeatMode) {
            this.songs = new ArrayList<>(songs); // Defensive copy
            this.currentIndex = currentIndex;
            this.isShuffle = isShuffle;
            this.repeatMode = repeatMode;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes (Stateless, Thread-Safe)
    // ========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z (ascending alphabetical).
     * Null titles are treated as empty strings.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A (descending alphabetical).
     * Thread-safe: stateless, no shared mutable state.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (oldest first), then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (newest first), then by title for ties.
     * Thread-safe: stateless, no shared mutable state.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    /**
     * Sets the player state before update flag.
     * Used to preserve playback state during folder updates.
     * Thread-safe: SharedPreferences.Editor.apply() is atomic.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     * Thread-safe: SharedPreferences reads are thread-safe.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     * Thread-safe: SharedPreferences.Editor.apply() is atomic.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID for equalizer attachment.
     * Thread-safe: volatile read.
     *
     * @return The current audio session ID (0 if none)
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * Initializes all components including MediaSession, audio focus, and notification.
     * Thread-safe: runs on main thread, all initialization is single-threaded.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        // Initialize album art cache with size limit
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
        
        // Initialize state flags
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        mIsPrepared.set(false);
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager for focus management
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup MediaSession for lock screen controls
        setupMediaSession();
        
        // Initialize EqualizerManager singleton
        EqualizerManager.getInstance(this);
        
        // Setup audio focus handling
        setupAudioFocus();
        
        // Initialize health check handler (for MediaPlayer fallback only)
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Register all broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Called when the service is started via startService().
     * Handles media button actions from the notification.
     * Thread-safe: runs on main thread, actions are delegated to synchronized methods.
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "ACTION_PLAY_PAUSE":
                    togglePlayPause();
                    break;
                case "ACTION_NEXT":
                    playNext();
                    break;
                case "ACTION_PREV":
                    playPrevious();
                    break;
                case "ACTION_CLOSE":
                    handleCloseAction();
                    break;
                case "ACTION_STOP":
                    stopCompletely();
                    break;
                case "ACTION_STOP_NOTIFICATION":
                    if (mNotificationService != null) {
                        mNotificationService.stopForeground();
                    }
                    break;
                case "PLAY_SONG":
                    String songPath = intent.getStringExtra("song_path");
                    if (songPath != null) {
                        playSongByPath(songPath);
                    } else {
                        int position = intent.getIntExtra("position", -1);
                        if (position >= 0) {
                            playSong(position);
                        }
                    }
                    break;
                case "UPDATE_PLAYBACK_PARAMS":
                    updatePlaybackParams();
                    break;
                default:
                    break;
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and saves playback state.
     * Thread-safe: all resources are released with proper locking.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        // Invalidate any pending preparations
        invalidateAllPreparations();
        
        // Save state before destroying
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        
        // Release WakeLock if held
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        
        // Release MediaPlayer
        releaseMediaPlayer();
        
        // Clean up notification service
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        // Release MediaSession
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Clean up health handler
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        // Unregister all broadcast receivers
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     * Attempts to recover if MediaPlayer is in an invalid state.
     * Thread-safe: uses synchronized block on mPlayerLock.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying.get() && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex.get(), currentPos);
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex.get(), currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     * Saves state before the service is potentially destroyed.
     * Thread-safe: delegates to other thread-safe methods.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * Default is SORT_TITLE_AZ (Title A-Z).
     * Thread-safe: uses AtomicInteger.set().
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode.set(prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ));
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode.get());
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     * Thread-safe: uses AtomicInteger.get() for atomic read.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode.get()).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode.get());
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     * All comparators use secondary sorting by Title (A-Z) when primary keys match.
     * Thread-safe: returns a new Comparator instance each call.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     * This is a reliable method that works across all Android versions.
     * Thread-safe: pure function, no shared state.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     * Preserves the currently playing song's position.
     * Thread-safe: acquires write lock for playlist modification.
     */
    private void reorderPlaylistByCurrentSort() {
        mPlaylistWriteLock.lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            // Save current song path to find it after sorting
            String currentSongPath = null;
            int currentIdx = mCurrentIndex.get();
            if (currentIdx >= 0 && currentIdx < mCurrentPlaylist.size()) {
                Song currentSong = mCurrentPlaylist.get(currentIdx);
                if (currentSong != null) currentSongPath = currentSong.getPath();
            }
            
            // Apply sorting
            Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode.get()));
            
            // Restore current index by finding the song in the sorted list
            if (currentSongPath != null) {
                int newIndex = -1;
                for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                    Song song = mCurrentPlaylist.get(i);
                    if (song != null && currentSongPath.equals(song.getPath())) {
                        newIndex = i;
                        break;
                    }
                }
                if (newIndex >= 0) {
                    mCurrentIndex.set(newIndex);
                    saveCurrentPlayingIndex();
                    Log.d(TAG, "Current song repositioned to index: " + newIndex);
                }
            }
            
            Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode.get());
        } finally {
            mPlaylistWriteLock.unlock();
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers the notification receiver for sync state updates.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver for equalizer updates.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    /**
     * Registers the clear playlist receiver.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    /**
     * Registers the theme color change receiver for notification colors.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the receiver for requests to get the playing state.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying.get());
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying.get()).apply();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    /**
     * Registers the sort mode update receiver from PlaylistActivity.
     * Thread-safe: runs on main thread during service creation.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode.get() != newSortMode) {
                        mCurrentSortMode.set(newSortMode);
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     * Thread-safe: catches all exceptions, safe to call from any thread.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // MediaPlayer Management
    // ========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer to prevent memory leaks.
     * Thread-safe: caller must hold mPlayerLock.
     *
     * @param player The MediaPlayer to clean (can be null)
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }
    
    /**
     * Safely resets the MediaPlayer without releasing it.
     * Thread-safe: synchronized on mPlayerLock.
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {}
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {}
            }
            mIsPlaying.set(false);
            mIsPrepared.set(false);
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     * Thread-safe: synchronized on mPlayerLock.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on media player release");
            }
            
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {}
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {}
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying.set(false);
            mIsPrepared.set(false);
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance.
     * Thread-safe: synchronized on mPlayerLock.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying.get();
                        mIsPlaying.set(false);
                        mIsPreparing.set(false);
                        mIsPrepared.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        // Attempt recovery if we were playing
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex.get() >= 0 && mCurrentIndex.get() < mCurrentPlaylist.size()) {
                            
                            Log.d(TAG, "Attempting recovery from error - resetting player");
                            final int recoverIndex = mCurrentIndex.get();
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     * A player is ready if it has a valid duration.
     * Thread-safe: synchronized on mPlayerLock.
     *
     * @return True if the player is ready
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
    
    // ========================================================================
    // Health Check Methods (Playback Stall Detection)
    // ========================================================================
    
    /**
     * Starts the playback health monitoring.
     * Checks every 3 seconds if playback is making progress.
     * Thread-safe: uses Atomic variables and Handler on main thread.
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) {
            mHealthHandler = new Handler(Looper.getMainLooper());
        }
        
        stopHealthMonitoring();
        mRecoveryAttempts.set(0);
        mPlaybackStartTime.set(System.currentTimeMillis());
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying.get() && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        
        Log.d(TAG, "Health monitoring started");
    }
    
    /**
     * Stops the playback health monitoring.
     * Thread-safe: removes callbacks on main thread Handler.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     * A stall is detected when position hasn't advanced past 100ms after 5 seconds.
     * Thread-safe: uses Atomic variables for state reads/writes.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying.get()) return;
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime.get() > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime.get();
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition + 
                          ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                // Progress detected - reset start time
                mPlaybackStartTime.set(System.currentTimeMillis());
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     * After max attempts, skips to next song.
     * Thread-safe: uses AtomicInteger for attempt counter.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts.get() >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts.set(0);
            playNext();
            return;
        }
        
        mRecoveryAttempts.incrementAndGet();
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts.get() + ")");
        
        final int currentIndex = mCurrentIndex.get();
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying.get()) {
                    mMediaPlayer.pause();
                }
            } catch (Exception ignored) {}
            releaseMediaPlayer();
        }
        
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && 
                    currentIndex < mCurrentPlaylist.size()) {
                    Log.d(TAG, "Restarting playback at index " + currentIndex);
                    prepareAndPlay(currentIndex, currentPosition);
                    
                    // Broadcast that recovery was successful
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }
    
    // ========================================================================
    // Async Operation Management (Stale Callback Prevention)
    // ========================================================================
    
    /**
     * Invalidates all pending preparations.
     * Increments the global preparation ID so stale callbacks are ignored.
     * Thread-safe: AtomicInteger.incrementAndGet().
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock to prevent concurrent song transitions.
     * Thread-safe: AtomicBoolean.compareAndSet().
     *
     * @return True if the lock was acquired
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     * Thread-safe: AtomicBoolean.set().
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates and updates the media notification.
     * Thread-safe: delegates to NotificationService (handles its own threading).
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex.get() >= 0 && mCurrentIndex.get() < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying.get());
    }
    
    /**
     * Refreshes the notification (called after sync state changes).
     * Thread-safe: delegates to NotificationService.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     * Called from DisplayManager when album art is loaded.
     * Thread-safe: delegates to NotificationService.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            if (art != null && !art.isRecycled()) safeArt = art;
            if (placeholder != null && !placeholder.isRecycled()) safePlaceholder = placeholder;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
            
            // Also update MediaSession album art
            updateMediaSessionAlbumArt(safeArt, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     * Called periodically and on service destroy.
     * Thread-safe: SharedPreferences.Editor.apply() is atomic.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex.get())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_REPEAT_MODE, mRepeatMode.get())
            .putBoolean(KEY_SHUFFLE, mIsShuffle.get())
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state (same as savePlayerState).
     * Thread-safe: delegates to savePlayerState().
     */
    private void saveFullState() {
        savePlayerState();
    }
    
    /**
     * Gets the saved playback position from SharedPreferences.
     * Thread-safe: SharedPreferences reads are thread-safe.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before app restart.
     * Thread-safe: SharedPreferences reads are thread-safe.
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path from SharedPreferences.
     * Thread-safe: SharedPreferences reads are thread-safe.
     *
     * @return The saved song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     * Thread-safe: SharedPreferences.Editor.apply() is atomic.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex.get())
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state (isPlaying + position).
     * Thread-safe: SharedPreferences.Editor.apply() is atomic.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     * Thread-safe: uses AtomicInteger.set() and AtomicBoolean.set().
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode.set(prefs.getInt(KEY_REPEAT_MODE, 0));
        mIsShuffle.set(prefs.getBoolean(KEY_SHUFFLE, false));
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Sets the current playlist.
     * Thread-safe: acquires write lock for playlist modification.
     *
     * @param playlist The new playlist
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        mPlaylistWriteLock.lock();
        try {
            invalidateAllPreparations();
            
            // Save current position and playing state
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex.get() >= 0 && 
                mCurrentIndex.get() < mCurrentPlaylist.size()) {
                
                synchronized (mPlayerLock) {
                    if (mMediaPlayer != null && isPlayerReady()) {
                        try {
                            currentPosition = mMediaPlayer.getCurrentPosition();
                            wasPlaying = mMediaPlayer.isPlaying();
                        } catch (Exception e) {
                            currentPosition = getSavedPosition();
                        }
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex.get()).getPath();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            
            // Handle empty playlist
            if (playlist == null || playlist.isEmpty()) {
                synchronized (mPlayerLock) {
                    resetPlayerSafely();
                }
                mCurrentPlaylist = null;
                mCurrentIndex.set(-1);
                mIsPrepared.set(false);
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                updateMediaSessionMetadata();
                return;
            }
            
            // Sort the new playlist according to current sort mode
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode.get()));
            
            // Force player reset when not preserving current song
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                invalidateAllPreparations();
                synchronized (mPlayerLock) {
                    resetPlayerSafely();
                }
                mIsPlaying.set(false);
                mIsPrepared.set(false);
            }
            
            // Find the current song in the new playlist
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex.get() >= 0 && 
                    mCurrentIndex.get() < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex.get()).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            // Determine if we need to reset the player
            boolean currentSongPositionChanged = (newIndex != -1 && newIndex != mCurrentIndex.get());
            boolean playlistStructureChanged = (mCurrentPlaylist != null && 
                                               mCurrentPlaylist.size() != sortedPlaylist.size());
            
            boolean currentSongChanged = false;
            if (mCurrentPlaylist != null && mCurrentIndex.get() >= 0 && 
                mCurrentIndex.get() < mCurrentPlaylist.size()) {
                String oldPath = mCurrentPlaylist.get(mCurrentIndex.get()).getPath();
                if (newIndex >= 0 && newIndex < sortedPlaylist.size()) {
                    String newPath = sortedPlaylist.get(newIndex).getPath();
                    currentSongChanged = !oldPath.equals(newPath);
                }
            }
            
            boolean needsReset = currentSongPositionChanged || playlistStructureChanged || currentSongChanged;
            
            if (needsReset && preserveCurrentSong) {
                Log.d(TAG, "Playlist/song changed, resetting player");
                synchronized (mPlayerLock) {
                    resetPlayerSafely();
                }
                mIsPrepared.set(false);
            }
            
            // Replace the playlist
            mCurrentPlaylist = sortedPlaylist;
            mShuffleHistory.clear();
            
            // Set the current index
            if (newIndex >= 0) {
                mCurrentIndex.set(newIndex);
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex.set(savedIndex);
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex.set(0);
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                mCurrentIndex.set(-1);
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            
            saveCurrentPlayingIndex();
            
            // Resume playback if needed
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && 
                mCurrentIndex.get() >= 0 && mCurrentIndex.get() < mCurrentPlaylist.size()) {
                
                if (needsReset) {
                    if (isFolderUpdate) {
                        int correctIndex = mCurrentIndex.get();
                        String savedPath = getSavedSongPath();
                        if (savedPath != null) {
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                    correctIndex = i;
                                    break;
                                }
                            }
                        }
                        prepareAndPlay(correctIndex, savedPosition);
                        clearPlayerStateBeforeUpdate(this);
                    } else {
                        prepareAndPlay(mCurrentIndex.get(), savedPosition);
                    }
                } else if (!mIsPlaying.get()) {
                    Log.d(TAG, "Same song, resuming playback without reset");
                    resume();
                }
                
            } else if (preserveCurrentSong && mCurrentPlaylist != null && 
                       mCurrentIndex.get() >= 0 && needsReset) {
                prepareOnly(mCurrentIndex.get());
                mIsPlaying.set(false);
                mIsPrepared.set(false);
                createNotification();
            } else if (!preserveCurrentSong) {
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            
            broadcastUpdate();
        } finally {
            mPlaylistWriteLock.unlock();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     * Thread-safe: delegates to setPlaylist(playlist, false).
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     * Thread-safe: acquires write lock and mPlayerLock.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        
        mPlaylistWriteLock.lock();
        try {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            
            invalidateAllPreparations();
            synchronized (mPlayerLock) {
                resetPlayerSafely();
            }
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on stop");
            }
            
            mCurrentPlaylist = null;
            mCurrentIndex.set(-1);
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            mCurrentAlbumArtPath = null;
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            
            mShuffleHistory.clear();
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) {
                mNotificationService.stopForeground();
            }
        } finally {
            mPlaylistWriteLock.unlock();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        // Clear MediaSession metadata
        updateMediaSessionMetadata();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist (preserves current song and position).
     * Thread-safe: uses atomic flag and delegates state saving.
     *
     * @param newPlaylist The new playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     * Thread-safe: synchronized on MusicService instance.
     *
     * @param index The song index in the playlist
     */
    public synchronized void playSong(int index) {
        playSong(index, false);
    }
    
    /**
     * Plays a song at the specified index with force preparation option.
     * Thread-safe: synchronized on MusicService instance.
     *
     * @param index The song index in the playlist
     * @param forcePrepare True to force preparation even if already at this index
     */
    public synchronized void playSong(int index, boolean forcePrepare) {
        mRecoveryAttempts.set(0);
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // Check if we're already playing this song and not forcing prepare
        if (!forcePrepare && index == mCurrentIndex.get() && mMediaPlayer != null && isPlayerReady()) {
            resume();
            return;
        }
        
        prepareAndPlay(index, 0);
    }
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     * This is the core playback method that uses MediaPlayer.
     * Thread-safe: uses preparation ID pattern to ignore stale callbacks.
     *
     * @param index The song index
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            // Configure audio attributes for better compatibility
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
                player.setAudioAttributes(attributes);
            } else {
                player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparing.set(true);
            mCurrentIndex.set(finalIndex);
            mCurrentAlbumArtPath = song.getPath();
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        mIsPrepared.set(true);
                        
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration: " + duration);
                                mIsPlaying.set(false);
                                mIsPrepared.set(false);
                                broadcastUpdate();
                                return;
                            }
                            
                            if (finalSeek > 0 && finalSeek < duration - 500) {
                                mp.seekTo(finalSeek);
                            }
                            
                            // Update audio session ID for equalizer
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mCurrentIndex.set(finalIndex);
                            saveCurrentPlayingIndex();
                            
                            // Set completion listener
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            // Start playback
                            mp.start();
                            mIsPlaying.set(true);
                            mPlaybackStartTime.set(System.currentTimeMillis());
                            startHealthMonitoring();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired");
                            }
                            
                            // Update MediaSession with metadata and playback state
                            updateMediaSessionMetadata();
                            updateMediaSessionPlaybackState();
                            broadcastUpdate();
                            createNotification();
                            updatePlaybackParams();
                            
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying.set(false);
                            mIsPrepared.set(false);
                            broadcastUpdate();
                        }
                    }
                }
            });
            
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    Log.e(TAG, "MediaPlayer error during preparation: what=" + what + " extra=" + extra);
                    mIsPreparing.set(false);
                    mIsPlaying.set(false);
                    mIsPrepared.set(false);
                    broadcastUpdate();
                    return true;
                }
            });
            
            player.prepareAsync();
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare player", e);
            mIsPreparing.set(false);
            mIsPrepared.set(false);
        }
    }
    
    /**
     * Prepares a song without starting playback.
     * Used for pre-loading the next song or when preserving current song.
     * Thread-safe: uses preparation ID pattern and mPlayerLock.
     *
     * @param index The song index to prepare
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            // Configure audio attributes
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
                player.setAudioAttributes(attributes);
            } else {
                player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            }
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex.set(finalIndex);
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance in prepareOnly, ignoring");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        mIsPrepared.set(true);
                        
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                            mIsPrepared.set(false);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare player", e);
            mIsPreparing.set(false);
            mIsPrepared.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     * Thread-safe: synchronized on MusicService instance.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts.set(0);
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        prepareAndPlay(index, position);
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     * Searches the playlist for a song with matching path.
     * Thread-safe: synchronized on MusicService instance.
     *
     * @param filePath The file path of the song
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts.set(0);
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     * Handles repeat modes and shuffle properly.
     * Thread-safe: uses transition lock to prevent concurrent transitions.
     */
    public synchronized void playNext() {
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            // Check for pending playlist update
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode.get()));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex.set(savedIndex);
                } else {
                    mCurrentIndex.set(0);
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex.get());
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle.get()) {
                if (!mShuffleHistory.isEmpty()) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    Random rand = mRandom.get();
                    do {
                        nextIndex = rand.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex.get() && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex.get() + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex.get() + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex.set(nextIndex);
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * Handles repeat modes and shuffle properly.
     * Thread-safe: uses transition lock to prevent concurrent transitions.
     */
    public synchronized void playPrevious() {
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            // Check for pending playlist update
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode.get()));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex.set(savedIndex);
                } else {
                    mCurrentIndex.set(0);
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex.get());
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle.get() && !mShuffleHistory.isEmpty()) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    Random rand = mRandom.get();
                    do {
                        prevIndex = rand.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex.get() && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex.get() > 0 ? mCurrentIndex.get() - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex.set(prevIndex);
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause.
     * Thread-safe: synchronized on MusicService instance.
     */
    public void togglePlayPause() {
        if (mMediaPlayer != null && mCurrentIndex.get() >= 0) {
            if (mIsPlaying.get()) {
                pause();
            } else {
                resume();
            }
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex.get() < 0) {
            playSong(0);
        }
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Pauses playback.
     * Thread-safe: synchronized on mPlayerLock.
     */
    public void pause() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying.get() && isPlayerReady()) {
                try {
                    mMediaPlayer.pause();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot pause - invalid state", e);
                }
                mIsPlaying.set(false);
                
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on pause");
                }
                
                savePlayingState();
                savePlayerState();
                saveFullState();
                updateMediaSessionPlaybackState();
                broadcastUpdate();
                createNotification();
            }
        }
    }
    
    /**
     * Resumes playback from paused state.
     * Thread-safe: synchronized on mPlayerLock.
     */
    public void resume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex.get() >= 0 && isPlayerReady()) {
                try {
                    if (!mIsPlaying.get()) {
                        requestAudioFocus();
                        updatePlaybackParams();
                        mMediaPlayer.start();
                        mIsPlaying.set(true);
                        mPlaybackStartTime.set(System.currentTimeMillis());
                        startHealthMonitoring();
                        
                        if (mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                            Log.d(TAG, "WakeLock acquired on resume");
                        }
                        
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        updateMediaSessionPlaybackState();
                        broadcastUpdate();
                        createNotification();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Resume failed - invalid state", e);
                    mIsPlaying.set(false);
                    broadcastUpdate();
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex.get() < 0) {
                playSong(0);
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     * Thread-safe: synchronized on mPlayerLock.
     */
    public void stop() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying.get() && isPlayerReady()) {
                try {
                    mMediaPlayer.stop();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot stop - invalid state", e);
                }
                mIsPlaying.set(false);
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     * Thread-safe: synchronized on mPlayerLock.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    int duration = mMediaPlayer.getDuration();
                    if (position >= 0 && position < duration) {
                        mMediaPlayer.seekTo(position);
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        savePlayerState();
                        saveFullState();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot seek - invalid state", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Playback Parameter Methods (Pitch and Speed)
    // ========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     * Called when the user adjusts pitch or speed in the equalizer.
     * Thread-safe: synchronized on mPlayerLock.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        float pitch = (float) Math.pow(2.0, semitones / 12.0);
                        android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                        params.setSpeed(tempo);
                        params.setPitch(pitch);
                        mMediaPlayer.setPlaybackParams(params);
                        Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
                        
                        // Update MediaSession with new playback speed
                        updateMediaSessionPlaybackState();
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to set playback params", e);
                    }
                }
            }
        } else {
            Log.w(TAG, "PlaybackParams not supported before Android M");
        }
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    /**
     * Handles song completion events.
     * Determines next action based on repeat mode and playlist state.
     * Thread-safe: called from MediaPlayer callback (main thread).
     */
    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying.set(false);
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        // Check for pending playlist update
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode.get()));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                mCurrentIndex.set(savedIndex);
            } else {
                mCurrentIndex.set(0);
            }
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex.get());
            return;
        }
        
        // Handle repeat modes
        if (mRepeatMode.get() == 2) {
            // Repeat one: play the same song again
            playSong(mCurrentIndex.get());
        } else if (mRepeatMode.get() == 1) {
            // Repeat all: play next song, wrap around at end
            playNext();
        } else if (mCurrentIndex.get() + 1 < mCurrentPlaylist.size()) {
            // Normal mode, not at end
            playNext();
        } else {
            // End of playlist reached, stop playback
            mIsPlaying.set(false);
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null) {
                    try {
                        mMediaPlayer.pause();
                    } catch (Exception ignored) {}
                    try {
                        mMediaPlayer.seekTo(0);
                    } catch (Exception ignored) {}
                }
            }
            
            // Save state
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            
            // Broadcast updates
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            updateMediaSessionMetadata();
            createNotification();
        }
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * Thread-safe: synchronized on mPlayerLock.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex.get() >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     * Thread-safe: synchronized on mPlayerLock.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex.get() >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     * Thread-safe: uses AtomicBoolean.get().
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if any player (MediaPlayer) is playing.
     * Thread-safe: uses AtomicBoolean.get().
     *
     * @return True if playing
     */
    public boolean isAnyPlayerPlaying() {
        return isPlaying();
    }
    
    /**
     * Checks if any player is prepared.
     * Thread-safe: uses isPlayerReady() which has proper locking.
     *
     * @return True if prepared
     */
    public boolean isAnyPlayerPrepared() {
        return isPlayerReady();
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     * Thread-safe: caller should hold mPlayerLock.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     * Thread-safe: uses AtomicReference and playlist read lock.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        Song song = mCurrentSongRef.get();
        if (song != null) return song;
        
        mPlaylistReadLock.lock();
        try {
            if (mCurrentIndex.get() >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex.get() < mCurrentPlaylist.size()) {
                song = mCurrentPlaylist.get(mCurrentIndex.get());
                mCurrentSongRef.set(song);
                return song;
            }
        } finally {
            mPlaylistReadLock.unlock();
        }
        return null;
    }
    
    /**
     * Returns the current playlist index.
     * Thread-safe: AtomicInteger.get().
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex.get();
    }
    
    /**
     * Sets the current playlist index.
     * Thread-safe: AtomicInteger.set().
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex.set(index);
        saveCurrentPlayingIndex();
        saveFullState();
        updateMediaSessionMetadata();
    }
    
    /**
     * Returns the repeat mode.
     * Thread-safe: AtomicInteger.get().
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode.get();
    }
    
    /**
     * Sets the repeat mode.
     * Thread-safe: AtomicInteger.set().
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode.set(mode);
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     * Thread-safe: AtomicBoolean.get().
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle.get();
    }
    
    /**
     * Sets the shuffle mode.
     * Thread-safe: AtomicBoolean.set().
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle.set(shuffle);
        if (shuffle) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state for media button handling.
     * Thread-safe: volatile write.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // Media Session Methods (Complete Lock Screen Integration)
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls and Bluetooth integration.
     * This provides lock screen playback controls, metadata display, album art,
     * voice command support, and seek bar on supported devices.
     * Thread-safe: called from onCreate (main thread only).
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setActive(true);
                mMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | 
                                       MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
                
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        Log.d(TAG, "MediaSession: onPlay");
                        if (!mIsPlaying.get() && mCurrentIndex.get() >= 0) {
                            resume();
                        } else if (mCurrentIndex.get() < 0 && mCurrentPlaylist != null && 
                                   !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        Log.d(TAG, "MediaSession: onPause");
                        if (mIsPlaying.get()) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        Log.d(TAG, "MediaSession: onSkipToNext");
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        Log.d(TAG, "MediaSession: onSkipToPrevious");
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        Log.d(TAG, "MediaSession: onStop");
                        pause();
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        Log.d(TAG, "MediaSession: onSeekTo " + pos + "ms");
                        seekTo((int) pos);
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        Log.d(TAG, "MediaSession: onPlayFromMediaId " + mediaId);
                        if (mediaId != null) {
                            try {
                                int index = Integer.parseInt(mediaId);
                                if (index >= 0 && mCurrentPlaylist != null && 
                                    index < mCurrentPlaylist.size()) {
                                    playSong(index);
                                }
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                    
                    @Override
                    public void onPlayFromSearch(String query, Bundle extras) {
                        Log.d(TAG, "MediaSession: onPlayFromSearch " + query);
                        if (mCurrentPlaylist != null && query != null && !query.isEmpty()) {
                            String lowerQuery = query.toLowerCase();
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                Song song = mCurrentPlaylist.get(i);
                                if (song != null) {
                                    String title = song.getTitle();
                                    String artist = song.getArtist();
                                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                                        (artist != null && artist.toLowerCase().contains(lowerQuery))) {
                                        playSong(i);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                });
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                    mMediaSession.setPlaybackToLocal(audioAttributes);
                }
                
                updateMediaSessionPlaybackState();
                updateMediaSessionMetadata();
                
                Intent intent = new Intent(this, MusicPlayer.class);
                intent.setAction(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    flags |= PendingIntent.FLAG_IMMUTABLE;
                }
                PendingIntent pi = PendingIntent.getActivity(this, 0, intent, flags);
                mMediaSession.setSessionActivity(pi);
                
                Log.d(TAG, "MediaSession fully initialized and active");
                
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Updates MediaSession with current song metadata (title, artist, album, album art).
     * This ensures lock screen shows correct song information.
     * Thread-safe: synchronizes on mPlayerLock for cache access.
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            Log.d(TAG, "MediaSession metadata cleared - no current song");
            return;
        }
        
        android.media.MediaMetadata.Builder metadataBuilder = new android.media.MediaMetadata.Builder()
            .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title")
            .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist")
            .putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album")
            .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration())
            .putLong(android.media.MediaMetadata.METADATA_KEY_TRACK_NUMBER, mCurrentIndex.get() + 1);
        
        if (mCurrentPlaylist != null) {
            metadataBuilder.putLong(android.media.MediaMetadata.METADATA_KEY_NUM_TRACKS, mCurrentPlaylist.size());
        }
        
        // Add album art if available in cache
        if (mCurrentAlbumArtPath != null && mAlbumArtCache != null) {
            Bitmap albumArt = mAlbumArtCache.get(mCurrentAlbumArtPath);
            if (albumArt != null && !albumArt.isRecycled()) {
                metadataBuilder.putBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART, albumArt);
                Log.d(TAG, "MediaSession metadata: album art added for " + currentSong.getTitle());
            }
        }
        
        mMediaSession.setMetadata(metadataBuilder.build());
        Log.d(TAG, "MediaSession metadata updated: " + currentSong.getTitle() + " - " + currentSong.getArtist());
    }
    
    /**
     * Updates MediaSession playback state (playing/paused, position, speed).
     * This ensures lock screen controls show correct state.
     * Thread-safe: uses atomic reads for state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        try {
            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
            
            long actions = PlaybackState.ACTION_PLAY | 
                          PlaybackState.ACTION_PAUSE |
                          PlaybackState.ACTION_SKIP_TO_NEXT | 
                          PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                          PlaybackState.ACTION_STOP |
                          PlaybackState.ACTION_SEEK_TO |
                          PlaybackState.ACTION_PLAY_PAUSE;
            
            int state = mIsPlaying.get() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
            long position = getCurrentPosition();
            float playbackSpeed = 1.0f;
            
            // Get current speed from EqualizerManager
            EqualizerManager eq = EqualizerManager.getInstance(this);
            int speedLevel = eq.getSpeed();
            playbackSpeed = 0.5f + (speedLevel / 2000.0f);
            
            stateBuilder.setState(state, position, playbackSpeed);
            stateBuilder.setActions(actions);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                stateBuilder.setActiveQueueItemId(mCurrentIndex.get());
            }
            
            mMediaSession.setPlaybackState(stateBuilder.build());
            Log.d(TAG, "MediaSession playback state: " + (mIsPlaying.get() ? "PLAYING" : "PAUSED") + 
                  " at " + position + "ms, speed=" + playbackSpeed);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSession state", e);
        }
    }
    
    /**
     * Updates MediaSession album art when it changes.
     * Called from DisplayManager when album art is loaded.
     * Thread-safe: caches album art and updates metadata.
     *
     * @param albumArt The album art bitmap, or null to remove
     * @param artPath The file path of the album art for cache lookup
     */
    public void updateMediaSessionAlbumArt(@Nullable Bitmap albumArt, @Nullable String artPath) {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        // Cache the album art if provided
        if (albumArt != null && !albumArt.isRecycled() && artPath != null && mAlbumArtCache != null) {
            mAlbumArtCache.put(artPath, albumArt);
            mCurrentAlbumArtPath = artPath;
        }
        
        // Update metadata with new album art
        updateMediaSessionMetadata();
        Log.d(TAG, "MediaSession album art updated");
    }
    
    /**
     * Returns the MediaSession token for use with MediaBrowser/MediaController.
     * This allows other components to control playback from the lock screen.
     * Thread-safe: returns reference to existing token.
     *
     * @return MediaSession token, or null if not available
     */
    @Nullable
    public MediaSession.Token getMediaSessionToken() {
        if (mMediaSession != null) {
            return mMediaSession.getSessionToken();
        }
        return null;
    }
    
    /**
     * Checks if MediaSession is active and ready.
     * Thread-safe: returns boolean state.
     *
     * @return True if MediaSession is active
     */
    public boolean isMediaSessionActive() {
        return mMediaSession != null && mMediaSession.isActive();
    }
    
    // ========================================================================
    // Metadata Editor Helper Methods
    // ========================================================================
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     * Called from MetadataEditor after saving changes.
     * Thread-safe: acquires write lock for playlist modification.
     *
     * @param songPath The path of the song
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        mPlaylistWriteLock.lock();
        try {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex.get() < 0 || mCurrentIndex.get() >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex.get());
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            // Apply updates
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, 
                                    songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
                // Remove from cache
                if (mAlbumArtCache != null && mCurrentAlbumArtPath != null) {
                    mAlbumArtCache.remove(mCurrentAlbumArtPath);
                }
            } else if (albumArtBytes != null && albumArtBytes.length > 0) {
                Log.d(TAG, "New album art provided for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex.get(), updated);
            mCurrentSongRef.set(updated);
            
            // Update database
            SongDatabase.getInstance(this).insertSong(updated);
            
            // Update MediaSession with new metadata
            updateMediaSessionMetadata();
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        } finally {
            mPlaylistWriteLock.unlock();
        }
    }
    
    // ========================================================================
    // Handle Close Action (from notification)
    // ========================================================================
    
    /**
     * Handles the close action from the notification.
     * Stops playback and closes the app when the user taps "Close" in the notification.
     * Thread-safe: acquires write lock and player lock.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        mPlaylistWriteLock.lock();
        try {
            invalidateAllPreparations();
            synchronized (mPlayerLock) {
                resetPlayerSafely();
            }
            
            if (mCurrentPlaylist != null) {
                mCurrentPlaylist.clear();
            }
            mCurrentIndex.set(-1);
            mCurrentAlbumArtPath = null;
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex.get())
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            
            if (mNotificationService != null) {
                mNotificationService.updateSongInfo(null, null, null);
                mNotificationService.setPlayingState(false);
                mNotificationService.stopForeground();
            }
            stopForeground(true);
        } finally {
            mPlaylistWriteLock.unlock();
        }
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    // ========================================================================
    // Audio Focus Methods
    // ========================================================================
    
    /**
     * Requests audio focus from the system.
     * Used for ducking when other apps play audio or phone calls come in.
     * Thread-safe: uses AudioManager system calls.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus when playback stops.
     * Thread-safe: uses AudioManager system calls.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Sets up audio focus with proper handling for all Android versions.
     * Thread-safe: called from onCreate (main thread only).
     */
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     * Thread-safe: called from AudioFocusChangeListener (main thread).
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                // Permanent loss - always pause, never auto-resume
                Log.d(TAG, "Audio focus: PERMANENT LOSS - pausing playback");
                if (mIsPlaying.get()) {
                    pause();
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // Temporary loss (notification, voice assistant, navigation)
                Log.d(TAG, "Audio focus: TRANSIENT LOSS - pausing playback (will auto-resume)");
                if (mIsPlaying.get()) {
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, true).apply();
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // Can continue playing at reduced volume
                Log.d(TAG, "Audio focus: DUCKING - lowering volume (auto-handled by system)");
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                // Focus regained - auto-resume if we were playing before
                Log.d(TAG, "Audio focus: GAIN - focus regained");
                
                boolean wasPlayingBeforeLoss = prefs.getBoolean(KEY_LAST_PLAYING, false);
                
                if (wasPlayingBeforeLoss && !mIsPlaying.get() && mCurrentPlaylist != null && 
                    !mCurrentPlaylist.isEmpty() && mCurrentIndex.get() >= 0) {
                    
                    Log.d(TAG, "Auto-resuming playback after focus gain");
                    
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mMediaPlayer != null && getCurrentSong() != null && 
                                mCurrentIndex.get() >= 0 && !mIsPlaying.get()) {
                                resume();
                            }
                            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                                .edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                        }
                    }, 100);
                } else {
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                }
                break;
                
            default:
                Log.v(TAG, "Unhandled audio focus change: " + focusChange);
                break;
        }
    }
    
    // ========================================================================
    // Broadcast Methods
    // ========================================================================
    
    /**
     * Broadcasts a playback state update to all activities.
     * Used by MusicPlayer to update its UI.
     * Thread-safe: sendBroadcast is thread-safe.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex.get());
        intent.putExtra("is_playing", mIsPlaying.get());
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     * Thread-safe: sendBroadcast is thread-safe.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    // ========================================================================
    // Media Button Handling (Bluetooth Headsets)
    // ========================================================================
    
    /**
     * Handles media button events from Bluetooth headsets.
     * Maps volume keys to next/previous when Bluetooth is connected.
     * Thread-safe: calls synchronized methods.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        // Standard media button handling
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying.get() && mCurrentIndex.get() >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying.get()) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
}