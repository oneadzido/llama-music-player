package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MusicService - Background service for music playback using LlamaPlayer.
 * 
 * <p>This service provides a robust, single-player implementation using LlamaPlayer,
 * which offers independent pitch and tempo control through the SoundTouch library.
 * The service manages playlist operations, playback state, notifications, and
 * audio focus in a thread-safe manner.</p>
 * 
 * <h3>Architecture Overview</h3>
 * <pre>
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │                         MusicService                                 │
 * │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
 * │  │ LlamaPlayer │  │Notification │  │MediaSession │  │PlaybackCtrl │ │
 * │  │  (Core)     │  │  Service    │  │ (Lock Screen)│  │(State Mgmt) │ │
 * │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
 * │         │               │               │               │          │
 * │         └───────────────┴───────────────┴───────────────┘          │
 * │                                   │                                  │
 * │                          ┌─────────▼─────────┐                       │
 * │                          │   Audio Focus     │                       │
 * │                          │   Wake Lock       │                       │
 * │                          └───────────────────┘                       │
 * └─────────────────────────────────────────────────────────────────────┘
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>ReentrantReadWriteLock</b> for playlist access (multiple readers)</li>
 *   <li><b>AtomicBoolean</b> for state flags</li>
 *   <li><b>Volatile</b> for simple flags where atomic operations aren't needed</li>
 *   <li><b>Handler</b> for main thread operations</li>
 * </ul>
 * 
 * <h3>Playback State Machine</h3>
 * <pre>
 *                    ┌─────────────────────────────────────┐
 *                    │              IDLE                    │
 *                    │        (No song loaded)              │
 *                    └─────────────────┬───────────────────┘
 *                                      │ setDataSource() + prepareAsync()
 *                                      ▼
 *                    ┌─────────────────────────────────────┐
 *                    │            PREPARING                 │
 *                    │      (Loading song asynchronously)   │
 *                    └─────────────────┬───────────────────┘
 *                                      │ onPrepared()
 *                                      ▼
 *                    ┌─────────────────────────────────────┐
 *                    │             PREPARED                 │
 *                    │       (Song ready to play)           │
 *                    └─────────┬───────────────┬───────────┘
 *                              │ start()       │
 *                              ▼               │
 *                    ┌─────────────────┐       │
 *                    │    STARTED      │       │
 *                    │   (Playing)     │       │
 *                    └─────────┬───────┘       │
 *                              │ pause()       │
 *                              ▼               │
 *                    ┌─────────────────┐       │
 *                    │    PAUSED       │       │
 *                    │   (Suspended)   │       │
 *                    └─────────┬───────┘       │
 *                              │ start()       │
 *                              └───────────────┘
 * </pre>
 * 
 * <h3>Notification Behavior</h3>
 * <p>The notification is ONLY shown when a song is loaded (playing or paused).
 * When the app is closed or no song is loaded, the notification automatically
 * disappears. This follows Android's best practices for media notifications.</p>
 * 
 * <h3>Audio Focus Integration</h3>
 * <p>The service properly handles audio focus changes from other apps:
 * <ul>
 *   <li><b>Loss</b> - Pauses playback</li>
 *   <li><b>Loss Transient</b> - Pauses playback temporarily</li>
 *   <li><b>Loss Transient Can Duck</b> - Reduces volume to 30%</li>
 *   <li><b>Gain</b> - Restores volume to normal</li>
 * </ul>
 * </p>
 * 
 * @see LlamaPlayer
 * @see PlaybackController
 * @see NotificationService
 * @see EqualizerManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service implements LlamaPlayer.PlaybackListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Notification ID for foreground service. */
    private static final int NOTIFICATION_ID = 1;
    
    // SharedPreferences Keys
    // ========================================================================
    
    /** Key for storing the current playlist index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    // Broadcast Actions
    // ========================================================================
    
    /** Action for toggling play/pause from notification. */
    private static final String ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE";
    
    /** Action for skipping to next song from notification. */
    private static final String ACTION_NEXT = "ACTION_NEXT";
    
    /** Action for skipping to previous song from notification. */
    private static final String ACTION_PREV = "ACTION_PREV";
    
    /** Action for closing the app and stopping service. */
    private static final String ACTION_CLOSE = "ACTION_CLOSE";
    
    /** Action for stopping the notification only. */
    private static final String ACTION_STOP_NOTIFICATION = "ACTION_STOP_NOTIFICATION";
    
    /** Action for playing a specific song by path or position. */
    private static final String ACTION_PLAY_SONG = "PLAY_SONG";
    
    /** Action for updating playback parameters (pitch/speed). */
    private static final String ACTION_UPDATE_PLAYBACK_PARAMS = "UPDATE_PLAYBACK_PARAMS";
    
    /** Action for broadcasting audio session ID changes (for equalizer). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Action for broadcasting when player is ready. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    // Sort Mode Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    /** Default sort mode (Title A-Z). */
    private static final int DEFAULT_SORT_MODE = SORT_TITLE_AZ;
    
    // Volume Control Constants
    // ========================================================================
    
    /** Volume level for ducking (30% of normal). */
    private static final float DUCK_VOLUME = 0.3f;
    
    /** Normal volume level (100%). */
    private static final float NORMAL_VOLUME = 1.0f;
    
    /** Delay before resetting seek state after user stops seeking (milliseconds). */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static volatile int sCurrentAudioSessionId = 0;
    
    /**
     * Returns the current audio session ID.
     * Thread-safe: volatile read.
     *
     * @return Current audio session ID, or 0 if not available
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    /**
     * Sets the player state before folder update.
     * Used to preserve playback state during playlist sync.
     *
     * @param context Application context
     * @param need True if state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Clears the player state before folder update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    @NonNull
    private Context mContext;
    
    /** Core audio player with pitch/tempo control. */
    @Nullable
    private LlamaPlayer mPlayer;
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable
    private PlaybackController mPlaybackController;
    
    /** Service for managing media notifications. */
    @Nullable
    private NotificationService mNotificationService;
    
    // Playlist Management (Thread-Safe with ReadWriteLock)
    // ========================================================================
    
    /** Read/write lock for thread-safe playlist access. */
    private final ReentrantReadWriteLock mPlaylistLock = new ReentrantReadWriteLock();
    
    /** Current playlist (protected by mPlaylistLock). */
    @Nullable
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song. */
    private volatile int mCurrentIndex = -1;
    
    /** Repeat mode: 0=off, 1=all, 2=one. */
    private volatile int mRepeatMode = 0;
    
    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Current playlist sort mode. */
    private volatile int mCurrentSortMode = DEFAULT_SORT_MODE;
    
    // Playback State (Thread-Safe)
    // ========================================================================
    
    /** Flag indicating if playback is currently active. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if player is prepared (song loaded, ready to play). */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if a seek operation is in progress. */
    private final AtomicBoolean mSeekInProgress = new AtomicBoolean(false);
    
    /** Last seek position (-1 if none). */
    private volatile int mLastSeekPosition = -1;
    
    // Shuffle Management
    // ========================================================================
    
    /** History of shuffled song indices for navigation. */
    @Nullable
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    @Nullable
    private Random mRandom;
    
    // Audio Focus and System Integration
    // ========================================================================
    
    /** AudioManager for audio focus management. */
    @Nullable
    private AudioManager mAudioManager;
    
    /** Audio focus change listener. */
    @Nullable
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O and above. */
    @Nullable
    private AudioFocusRequest mAudioFocusRequest;
    
    /** Wake lock for background playback. */
    @Nullable
    private PowerManager.WakeLock mWakeLock;
    
    /** MediaSession for lock screen controls. */
    @Nullable
    private MediaSession mMediaSession;
    
    /** Main thread handler for UI operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for playback parameter updates from equalizer. */
    @Nullable
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for getting playing state for other components. */
    @Nullable
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates from PlaylistActivity. */
    @Nullable
    private BroadcastReceiver mSortModeReceiver;
    
    // Binder
    // ========================================================================
    
    /** Binder for service binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Binder Class
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * Provides access to the MusicService instance.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the MusicService instance.
         *
         * @return The service instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * 
     * <p>Initializes all components in the following order:</p>
     * <ol>
     *   <li>PlaybackController and EqualizerManager singletons</li>
     *   <li>Shuffle history and random generator</li>
     *   <li>Saved settings from SharedPreferences</li>
     *   <li>Audio focus and media session</li>
     *   <li>Wake lock for background playback</li>
     *   <li>Notification service (minimal, updates when song loads)</li>
     *   <li>LlamaPlayer core instance</li>
     *   <li>Broadcast receivers for inter-component communication</li>
     * </ol>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        mContext = getApplicationContext();
        
        // Initialize centralized state managers
        mPlaybackController = PlaybackController.getInstance();
        EqualizerManager.getInstance(mContext);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<>();
        mRandom = new Random();
        
        // Load saved preferences
        loadSettings();
        
        // Setup system integrations
        setupAudioFocus();
        setupMediaSession();
        
        // Setup wake lock for background playback
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize notification service (will only show when a song is loaded)
        mNotificationService = new NotificationService(this);
        mNotificationService.setPlayingState(false);
        
        // Create the core audio player
        createPlayer();
        
        // Register broadcast receivers
        registerReceivers();
        
        // Start foreground service with minimal notification
        // This will be updated with actual song info when a song is loaded
        startForeground(NOTIFICATION_ID, createMinimalNotification());
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Called when the service is started.
     * 
     * <p>Handles intent actions from notifications, activities, and other components.</p>
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing the start request
     * @return START_STICKY to restart service if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            switch (action) {
                case ACTION_PLAY_PAUSE:
                    togglePlayPause();
                    break;
                    
                case ACTION_NEXT:
                    playNext();
                    break;
                    
                case ACTION_PREV:
                    playPrevious();
                    break;
                    
                case ACTION_CLOSE:
                    handleCloseAction();
                    break;
                    
                case ACTION_STOP_NOTIFICATION:
                    if (mNotificationService != null) {
                        mNotificationService.stopForeground();
                    }
                    break;
                    
                case ACTION_PLAY_SONG:
                    String songPath = intent.getStringExtra("song_path");
                    if (songPath != null) {
                        playSongByPath(songPath);
                    } else {
                        int position = intent.getIntExtra("position", -1);
                        if (position >= 0) {
                            playSong(position);
                        }
                    }
                    break;
                    
                case ACTION_UPDATE_PLAYBACK_PARAMS:
                    updatePlaybackParams();
                    break;
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * 
     * <p>Performs comprehensive cleanup:</p>
     * <ul>
     *   <li>Saves current playback state to SharedPreferences</li>
     *   <li>Releases LlamaPlayer resources</li>
     *   <li>Stops notification service and foreground</li>
     *   <li>Releases wake lock</li>
     *   <li>Releases media session</li>
     *   <li>Abandons audio focus</li>
     * </ul>
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        // Save current state before cleanup
        savePlayerState();
        
        // Release the core player
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        
        // Release notification service
        if (mNotificationService != null) {
            mNotificationService.release();
            mNotificationService = null;
        }
        stopForeground(true);
        
        // Release wake lock
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released");
        }
        
        // Release media session
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        super.onDestroy();
    }
    
    // ========================================================================
    // Player Management Methods
    // ========================================================================
    
    /**
     * Creates or recreates the LlamaPlayer instance.
     * Sets the playback listener for state callbacks.
     */
    private void createPlayer() {
        if (mPlayer != null) {
            mPlayer.release();
        }
        
        mPlayer = new LlamaPlayer(this);
        mPlayer.setListener(this);
        
        Log.d(TAG, "LlamaPlayer created");
    }
    
    // ========================================================================
    // LlamaPlayer.PlaybackListener Implementation
    // ========================================================================
    
    /**
     * Called when the player state changes.
     * Updates PlaybackController and notification accordingly.
     *
     * @param newState The new state (never null)
     * @param oldState The previous state (may be null on first callback)
     */
    @Override
    public void onStateChanged(@NonNull LlamaPlayer.State newState, @Nullable LlamaPlayer.State oldState) {
        Log.d(TAG, "Player state: " + oldState + " -> " + newState);
        
        switch (newState) {
            case PREPARED:
                handlePrepared();
                break;
                
            case STARTED:
                handleStarted();
                break;
                
            case PAUSED:
                handlePaused();
                break;
                
            case COMPLETED:
                handleCompletion();
                break;
                
            case ERROR:
                handleError();
                break;
                
            default:
                break;
        }
    }
    
    /**
     * Called when the song is prepared and ready for playback.
     * Updates PlaybackController, notification, and media session.
     */
    @Override
    public void onPrepared() {
        Log.d(TAG, "LlamaPlayer: onPrepared() - READY");
        // Handled in onStateChanged PREPARED
    }
    
    /**
     * Called when the song completes normally (end of file reached).
     */
    @Override
    public void onCompletion() {
        Log.d(TAG, "LlamaPlayer: onCompletion()");
        // Handled in onStateChanged COMPLETED
    }
    
    /**
     * Called periodically with the current playback position.
     * Updates PlaybackController for UI display.
     *
     * @param positionMs Current position in milliseconds
     */
    @Override
    public void onPositionUpdate(long positionMs) {
        if (!mSeekInProgress.get() && mPlaybackController != null) {
            mPlaybackController.updatePosition(positionMs, "LlamaPlayer.onPositionUpdate");
        }
    }
    
    /**
     * Called when an error occurs during playback or preparation.
     *
     * @param error Human-readable description of the error
     */
    @Override
    public void onError(@NonNull String error) {
        Log.e(TAG, "LlamaPlayer error: " + error);
        handleError();
    }
    
    // ========================================================================
    // State Handlers
    // ========================================================================
    
    /**
     * Handles the PREPARED state.
     * Updates PlaybackController with duration and audio session ID,
     * broadcasts player ready, and updates notification.
     */
    private void handlePrepared() {
        if (mPlayer == null) return;
        
        mIsPrepared.set(true);
        
        // Update PlaybackController
        if (mPlaybackController != null) {
            mPlaybackController.setDuration(mPlayer.getDuration(), "MusicService.onPrepared");
            mPlaybackController.setPrepared(true, "MusicService.onPrepared");
        }
        
        // Update audio session ID for equalizer
        int sessionId = mPlayer.getAudioSessionId();
        if (sessionId > 0) {
            sCurrentAudioSessionId = sessionId;
            broadcastAudioSessionChanged(sessionId);
            Log.d(TAG, "Audio session ID: " + sessionId);
        }
        
        // Update current song in PlaybackController
        Song currentSong = getCurrentSong();
        if (currentSong != null && mPlaybackController != null) {
            mPlaybackController.updateSong(currentSong, "MusicService.onPrepared");
        }
        
        // Broadcast that player is ready
        Intent readyIntent = new Intent(ACTION_PLAYER_READY);
        sendBroadcast(readyIntent);
        
        // Update notification with song info (only if song is loaded)
        updateNotification();
        
        // Update media session metadata
        updateMediaSessionMetadata();
        
        Log.d(TAG, "Player prepared - duration: " + mPlayer.getDuration() + "ms, session: " + sessionId);
    }
    
    /**
     * Handles the STARTED state.
     * Updates PlaybackController, acquires wake lock, requests audio focus,
     * and updates notification.
     */
    private void handleStarted() {
        mIsPlaying.set(true);
        
        // Update PlaybackController
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(true, "MusicService.onStarted");
        }
        
        // Acquire wake lock to keep CPU awake during playback
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            mWakeLock.acquire(3600000); // 1 hour timeout
            Log.d(TAG, "WakeLock acquired");
        }
        
        // Request audio focus
        requestAudioFocus();
        
        // Update notification
        updateNotification();
        
        // Update media session playback state
        updateMediaSessionPlaybackState();
        
        broadcastUpdate();
    }
    
    /**
     * Handles the PAUSED state.
     * Updates PlaybackController, releases wake lock, abandons audio focus,
     * and updates notification.
     */
    private void handlePaused() {
        mIsPlaying.set(false);
        
        // Update PlaybackController
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(false, "MusicService.onPaused");
        }
        
        // Release wake lock to save battery
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released");
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Update notification (still shows song info, just paused state)
        updateNotification();
        
        // Update media session playback state
        updateMediaSessionPlaybackState();
        
        broadcastUpdate();
    }
    
    /**
     * Handles song completion (end of stream reached).
     * Plays next song based on repeat mode or stops playback.
     */
    private void handleCompletion() {
        Log.d(TAG, "Song completed");
        
        broadcastSongCompletion();
        
        if (mRepeatMode == 2) {
            // Repeat one: seek to beginning and play
            if (mPlayer != null) {
                mPlayer.seekTo(0);
                mPlayer.start();
            }
        } else if (mRepeatMode == 1) {
            // Repeat all: play next song
            playNext();
        } else {
            // No repeat: check if there are more songs
            mPlaylistLock.readLock().lock();
            try {
                if (mCurrentPlaylist != null && mCurrentIndex + 1 < mCurrentPlaylist.size()) {
                    playNext();
                } else {
                    // End of playlist, stop playback
                    mIsPlaying.set(false);
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "MusicService.onCompletion.end");
                        mPlaybackController.setPrepared(false, "MusicService.onCompletion.end");
                    }
                    
                    // Update notification to show paused state
                    updateNotification();
                    
                    // Save state
                    savePlayingState();
                    
                    // Clear notification song info when no song is loaded
                    if (mNotificationService != null) {
                        mNotificationService.updateSongInfo(null, null, null);
                        mNotificationService.setPlayingState(false);
                        mNotificationService.forceUpdate();
                    }
                    
                    Log.d(TAG, "End of playlist - playback stopped");
                }
            } finally {
                mPlaylistLock.readLock().unlock();
            }
        }
    }
    
    /**
     * Handles error state.
     * Resets player state and attempts recovery.
     */
    private void handleError() {
        Log.e(TAG, "Player error - entering error state");
        
        mIsPrepared.set(false);
        mIsPlaying.set(false);
        
        if (mPlaybackController != null) {
            mPlaybackController.setPrepared(false, "MusicService.onError");
            mPlaybackController.setPlaying(false, "MusicService.onError");
            mPlaybackController.notifyOperationFailed("playback", "Player error occurred");
        }
        
        // Release wake lock
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Try to recreate player
        createPlayer();
    }
    
    // ========================================================================
    // Playlist Management Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Returns a thread-safe snapshot of the current playlist.
     *
     * @return A copy of the current playlist, or empty list if null
     */
    @NonNull
    private ArrayList<Song> getPlaylistSnapshot() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null) {
                return new ArrayList<>();
            }
            return new ArrayList<>(mCurrentPlaylist);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Sets the playlist and optionally preserves the current song.
     *
     * @param newPlaylist The new playlist (can be null)
     * @param preserveCurrentSong Whether to try to preserve the current song
     */
    public void setPlaylist(ArrayList<Song> newPlaylist, boolean preserveCurrentSong) {
        mPlaylistLock.writeLock().lock();
        try {
            // Save current song path if preserving
            String currentSongPath = null;
            if (preserveCurrentSong && mCurrentPlaylist != null && 
                mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    currentSongPath = currentSong.getPath();
                }
            }
            
            // Handle empty playlist
            if (newPlaylist == null || newPlaylist.isEmpty()) {
                handleEmptyPlaylistLocked();
                return;
            }
            
            // Sort the new playlist
            ArrayList<Song> sortedPlaylist = new ArrayList<>(newPlaylist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // Find the preserved song index if needed
            int newIndex = -1;
            if (preserveCurrentSong && currentSongPath != null) {
                for (int i = 0; i < sortedPlaylist.size(); i++) {
                    Song song = sortedPlaylist.get(i);
                    if (song != null && currentSongPath.equals(song.getPath())) {
                        newIndex = i;
                        break;
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            
            // Update current index
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
            } else if (!sortedPlaylist.isEmpty()) {
                mCurrentIndex = 0;
                prepareSong(mCurrentIndex);
            }
            
            // Clear shuffle history when playlist changes
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            
            Log.d(TAG, "Playlist set: " + sortedPlaylist.size() + " songs, index=" + mCurrentIndex);
            
        } finally {
            mPlaylistLock.writeLock().unlock();
        }
        
        broadcastUpdate();
        updateNotification();
    }
    
    /**
     * Handles empty playlist case (must be called with write lock held).
     */
    private void handleEmptyPlaylistLocked() {
        // Stop playback
        if (mPlayer != null && mIsPrepared.get()) {
            mPlayer.stop();
        }
        
        mCurrentPlaylist = null;
        mCurrentIndex = -1;
        mIsPrepared.set(false);
        mIsPlaying.set(false);
        
        // Clear notification
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        
        // Reset PlaybackController
        if (mPlaybackController != null) {
            mPlaybackController.reset();
        }
        
        // Clear shuffle history
        if (mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        
        broadcastUpdate();
    }
    
    /**
     * Returns the current song.
     *
     * @return The current Song, or null if none
     */
    @Nullable
    public Song getCurrentSong() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                Song song = mCurrentPlaylist.get(mCurrentIndex);
                if (song != null) {
                    // Return a defensive copy
                    return new Song(
                        song.getTitle(), song.getArtist(), song.getAlbum(),
                        song.getGenre(), song.getPath(), song.getDuration(), song.getUri()
                    );
                }
            }
            return null;
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index, or -1 if none
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Returns the current repeat mode.
     *
     * @return Repeat mode (0=off, 1=all, 2=one)
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode Repeat mode (0=off, 1=all, 2=one)
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        updateNotification();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        updateNotification();
    }
    
    /**
     * Returns the current playback position.
     *
     * @return Position in milliseconds
     */
    public int getCurrentPosition() {
        if (mSeekInProgress.get() && mLastSeekPosition >= 0) {
            return mLastSeekPosition;
        }
        if (mPlayer != null) {
            return (int) mPlayer.getCurrentPosition();
        }
        return 0;
    }
    
    /**
     * Returns the total duration of the current song.
     *
     * @return Duration in milliseconds
     */
    public int getDuration() {
        if (mPlayer != null) {
            return (int) mPlayer.getDuration();
        }
        return 0;
    }
    
    /**
     * Checks if any player is currently playing.
     *
     * @return True if playing
     */
    public boolean isAnyPlayerPlaying() {
        return mIsPlaying.get() && mPlayer != null && mPlayer.isPlaying();
    }
    
    /**
     * Checks if any player is prepared for playback.
     *
     * @return True if prepared
     */
    public boolean isAnyPlayerPrepared() {
        return mIsPrepared.get() && mPlayer != null && mPlayer.isPrepared();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The index of the song to play
     * @param autoStart True to start playback immediately
     */
    public synchronized void playSong(int index, boolean autoStart) {
        mPlaylistLock.readLock().lock();
        Song song;
        try {
            if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
                Log.w(TAG, "playSong: invalid index " + index);
                return;
            }
            song = mCurrentPlaylist.get(index);
        } finally {
            mPlaylistLock.readLock().unlock();
        }
        
        if (song == null || song.getPath() == null) {
            Log.w(TAG, "playSong: invalid song at index " + index);
            return;
        }
        
        Log.d(TAG, "playSong: " + song.getTitle() + " at index " + index);
        
        // Set current index
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        
        // Load and play the song
        if (mPlayer != null) {
            try {
                mPlayer.reset();
                mPlayer.setDataSource(song.getPath());
                mPlayer.prepareAsync();
                mIsPlaying.set(autoStart);
                
                // Update PlaybackController
                if (mPlaybackController != null) {
                    mPlaybackController.updateSong(song, "MusicService.playSong");
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to play song", e);
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("play", e.getMessage());
                }
            }
        }
        
        savePlayerState();
        broadcastUpdate();
        updateNotification();
    }
    
    /**
     * Plays a song at the specified index with auto-start enabled.
     *
     * @param index The index of the song to play
     */
    public void playSong(int index) {
        playSong(index, true);
    }
    
    /**
     * Plays a song by file path.
     *
     * @param filePath The file path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null) return;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && filePath.equals(song.getPath())) {
                    playSong(i, true);
                    return;
                }
            }
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Prepares a song without starting playback.
     *
     * @param index The index of the song to prepare
     */
    private void prepareSong(int index) {
        playSong(index, false);
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.w(TAG, "playNext: playlist is empty");
                return;
            }
            
            int nextIndex;
            if (mIsShuffle && mShuffleHistory != null && mRandom != null) {
                // Shuffle mode: pick a random song not recently played
                if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                    mShuffleHistory.clear();
                }
                do {
                    nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                         mShuffleHistory.contains(nextIndex));
                if (mShuffleHistory != null) {
                    mShuffleHistory.add(nextIndex);
                }
            } else {
                // Normal mode: go to next index, wrap around if repeat all is on
                nextIndex = (mCurrentIndex + 1);
                if (nextIndex >= mCurrentPlaylist.size()) {
                    if (mRepeatMode == 1) {
                        nextIndex = 0;
                    } else {
                        Log.d(TAG, "playNext: end of playlist, no repeat");
                        return;
                    }
                }
            }
            
            playSong(nextIndex, true);
            
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        mPlaylistLock.readLock().lock();
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.w(TAG, "playPrevious: playlist is empty");
                return;
            }
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null && mShuffleHistory.size() >= 2) {
                // Shuffle mode: go back in history
                prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                mShuffleHistory.remove(mShuffleHistory.size() - 1);
            } else {
                // Normal mode: go to previous index
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            playSong(prevIndex, true);
            
        } finally {
            mPlaylistLock.readLock().unlock();
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        if (mPlayer == null) return;
        
        if (mIsPlaying.get()) {
            pause();
        } else if (mIsPrepared.get()) {
            resume();
        } else {
            // No song prepared, try to play the first song
            mPlaylistLock.readLock().lock();
            try {
                if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                    playSong(0, true);
                }
            } finally {
                mPlaylistLock.readLock().unlock();
            }
        }
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        if (mPlayer != null && mIsPlaying.get()) {
            mPlayer.pause();
            // State change will be handled in onStateChanged
        }
    }
    
    /**
     * Resumes playback.
     */
    public void resume() {
        if (mPlayer != null && mIsPrepared.get() && !mIsPlaying.get()) {
            mPlayer.start();
            // State change will be handled in onStateChanged
        }
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param positionMs Position in milliseconds
     */
    public void seekTo(int positionMs) {
        mSeekInProgress.set(true);
        mLastSeekPosition = positionMs;
        
        if (mPlayer != null && mIsPrepared.get()) {
            mPlayer.seekTo(positionMs);
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.updatePosition(positionMs, "MusicService.seekTo");
        }
        
        mMainHandler.postDelayed(() -> {
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
        }, SEEK_RESET_DELAY_MS);
    }
    
    /**
     * Updates playback parameters (pitch and speed) from EqualizerManager.
     */
    public void updatePlaybackParams() {
        if (mPlayer == null || !mIsPrepared.get()) return;
        
        EqualizerManager eq = EqualizerManager.getInstance(this);
        
        // Get speed (tempo)
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        
        // Get pitch (semitones)
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        mPlayer.setPitch(semitones);
        mPlayer.setTempo(tempo);
        
        Log.d(TAG, "Playback params updated: tempo=" + tempo + ", pitch=" + semitones + "st");
    }
    
/**
 * Handles media button events (play/pause, next, previous) from headset controls.
 *
 * @param keyCode The key code of the pressed button
 */
public void handleMediaButton(int keyCode) {
    Log.d(TAG, "handleMediaButton: " + keyCode);
    
    switch (keyCode) {
        case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            togglePlayPause();
            break;
        case KeyEvent.KEYCODE_MEDIA_NEXT:
            playNext();
            break;
        case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            playPrevious();
            break;
        case KeyEvent.KEYCODE_MEDIA_PLAY:
            if (!mIsPlaying.get() && mCurrentIndex >= 0) {
                resume();
            }
            break;
        case KeyEvent.KEYCODE_MEDIA_PAUSE:
            if (mIsPlaying.get()) {
                pause();
            }
            break;
        default:
            Log.d(TAG, "Unhandled media button: " + keyCode);
            break;
    }
}

/**
 * Sets the Bluetooth connection state.
 * Used to adjust behavior when Bluetooth headset is connected/disconnected.
 *
 * @param connected True if Bluetooth is connected
 */
public void setBluetoothConnected(boolean connected) {
    Log.d(TAG, "setBluetoothConnected: " + connected);
    // Currently just logging - can be extended for Bluetooth-specific behavior
    // For example: adjust buffer sizes, change audio routing hints, etc.
}

/**
 * Handles trim memory events from the system.
 * Called when the system is running low on memory.
 *
 * @param level The memory trim level
 */
public void onTrimMemory(int level) {
    Log.d(TAG, "onTrimMemory: " + level);
    
    // Clear caches based on memory pressure
    if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
        // Moderate memory pressure - clear some caches
        if (mNotificationService != null) {
            // Notification service can clear album art cache
        }
    } else if (level >= TRIM_MEMORY_RUNNING_LOW) {
        // High memory pressure - clear more aggressively
        if (mPlayer != null && !mIsPlaying.get()) {
            // If not playing, consider releasing some resources
        }
    }
}

/**
 * Refreshes the notification (called when metadata changes).
 */
public void refreshNotification() {
    Log.d(TAG, "refreshNotification");
    updateNotification();
}

    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Song currentSong = getCurrentSong();
        
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, currentSong != null ? currentSong.getPath() : null)
            .apply();
        
        Log.d(TAG, "Player state saved");
    }
    
    /**
     * Saves only the playing state (used during quick operations).
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying.get())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Song currentSong = getCurrentSong();
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, currentSong != null ? currentSong.getPath() : null)
            .apply();
    }
    
    // ========================================================================
    // Load Settings Methods
    // ========================================================================
    
    /**
     * Loads saved settings from SharedPreferences.
     */
    private void loadSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, DEFAULT_SORT_MODE);
        
        Log.d(TAG, "Settings loaded: index=" + mCurrentIndex + ", repeat=" + mRepeatMode + 
              ", shuffle=" + mIsShuffle + ", sortMode=" + mCurrentSortMode);
    }
    
    // ========================================================================
    // Sort Methods
    // ========================================================================
    
    /**
     * Returns the comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return The comparator
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return (a, b) -> {
                    String titleA = a.getTitle() != null ? a.getTitle() : "";
                    String titleB = b.getTitle() != null ? b.getTitle() : "";
                    return titleA.compareToIgnoreCase(titleB);
                };
            case SORT_TITLE_ZA:
                return (a, b) -> {
                    String titleA = a.getTitle() != null ? a.getTitle() : "";
                    String titleB = b.getTitle() != null ? b.getTitle() : "";
                    return titleB.compareToIgnoreCase(titleA);
                };
            case SORT_ARTIST_AZ:
                return (a, b) -> {
                    String artistA = a.getArtist() != null ? a.getArtist() : "";
                    String artistB = b.getArtist() != null ? b.getArtist() : "";
                    int artistCompare = artistA.compareToIgnoreCase(artistB);
                    if (artistCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return artistCompare;
                };
            case SORT_ARTIST_ZA:
                return (a, b) -> {
                    String artistA = a.getArtist() != null ? a.getArtist() : "";
                    String artistB = b.getArtist() != null ? b.getArtist() : "";
                    int artistCompare = artistB.compareToIgnoreCase(artistA);
                    if (artistCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return artistCompare;
                };
            case SORT_ALBUM_AZ:
                return (a, b) -> {
                    String albumA = a.getAlbum() != null ? a.getAlbum() : "";
                    String albumB = b.getAlbum() != null ? b.getAlbum() : "";
                    int albumCompare = albumA.compareToIgnoreCase(albumB);
                    if (albumCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return albumCompare;
                };
            case SORT_ALBUM_ZA:
                return (a, b) -> {
                    String albumA = a.getAlbum() != null ? a.getAlbum() : "";
                    String albumB = b.getAlbum() != null ? b.getAlbum() : "";
                    int albumCompare = albumB.compareToIgnoreCase(albumA);
                    if (albumCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return albumCompare;
                };
            case SORT_GENRE_AZ:
                return (a, b) -> {
                    String genreA = a.getGenre() != null ? a.getGenre() : "";
                    String genreB = b.getGenre() != null ? b.getGenre() : "";
                    int genreCompare = genreA.compareToIgnoreCase(genreB);
                    if (genreCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return genreCompare;
                };
            case SORT_GENRE_ZA:
                return (a, b) -> {
                    String genreA = a.getGenre() != null ? a.getGenre() : "";
                    String genreB = b.getGenre() != null ? b.getGenre() : "";
                    int genreCompare = genreB.compareToIgnoreCase(genreA);
                    if (genreCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return genreCompare;
                };
            case SORT_OLDEST:
                return (a, b) -> {
                    long dateA = getSongDate(a);
                    long dateB = getSongDate(b);
                    int dateCompare = Long.compare(dateA, dateB);
                    if (dateCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return dateCompare;
                };
            case SORT_NEWEST:
                return (a, b) -> {
                    long dateA = getSongDate(a);
                    long dateB = getSongDate(b);
                    int dateCompare = Long.compare(dateB, dateA);
                    if (dateCompare == 0) {
                        String titleA = a.getTitle() != null ? a.getTitle() : "";
                        String titleB = b.getTitle() != null ? b.getTitle() : "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                    return dateCompare;
                };
            default:
                return (a, b) -> {
                    String titleA = a.getTitle() != null ? a.getTitle() : "";
                    String titleB = b.getTitle() != null ? b.getTitle() : "";
                    return titleA.compareToIgnoreCase(titleB);
                };
        }
    }
    
    /**
     * Gets the last modified date of a song file.
     *
     * @param song The song
     * @return Last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    // ========================================================================
    // Broadcast Methods
    // ========================================================================
    
    /**
     * Broadcasts a playlist update to connected activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying.get());
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts song completion event.
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts audio session change to EqualizerActivity.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates a minimal foreground notification (shown when no song is loaded).
     *
     * @return The notification
     */
    private Notification createMinimalNotification() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, MusicPlayer.class), flags);
        
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "foreground_channel",
                "Music Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Required for background music playback");
            channel.setSound(null, null);
            channel.enableVibration(false);
            
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
            builder.setChannelId("foreground_channel");
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
               .setContentTitle("Llama Music Player")
               .setContentText("ENJOY THE WAVES")
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setVisibility(Notification.VISIBILITY_PUBLIC);
        
        return builder.build();
    }
    
    /**
     * Updates the notification with current song info and playback state.
     * The notification is ONLY shown when a song is loaded.
     */
    private void updateNotification() {
        if (mNotificationService == null) return;
        
        Song song = getCurrentSong();
        boolean hasSong = (song != null && song.getPath() != null);
        
        if (hasSong) {
            // Show notification with song info
            mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            mNotificationService.setPlayingState(mIsPlaying.get());
            mNotificationService.forceUpdate();
            Log.d(TAG, "Notification updated: " + song.getTitle() + " - " + (mIsPlaying.get() ? "Playing" : "Paused"));
        } else {
            // No song loaded - clear notification
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.forceUpdate();
            Log.d(TAG, "Notification cleared - no song loaded");
        }
    }
    
    /**
     * Handles close action to stop the service.
     */
    private void handleCloseAction() {
        savePlayerState();
        
        // Stop playback
        if (mPlayer != null) {
            mPlayer.stop();
        }
        
        // Clear playlist
        mPlaylistLock.writeLock().lock();
        try {
            if (mCurrentPlaylist != null) {
                mCurrentPlaylist.clear();
            }
        } finally {
            mPlaylistLock.writeLock().unlock();
        }
        mCurrentIndex = -1;
        
        // Clear saved state
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        // Clear notification
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying.get() && mCurrentIndex >= 0) {
                            resume();
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying.get()) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        handleCloseAction();
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        seekTo((int) pos);
                    }
                });
                
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
                Log.d(TAG, "MediaSession setup complete");
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Updates the MediaSession metadata for lock screen display.
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            return;
        }
        
        android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
        builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                          currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                          currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                          currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album");
        builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
        
        mMediaSession.setMetadata(builder.build());
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        try {
            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
            long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                          PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                          PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
            int state = mIsPlaying.get() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
            stateBuilder.setState(state, getCurrentPosition(), 1.0f);
            stateBuilder.setActions(actions);
            mMediaSession.setPlaybackState(stateBuilder.build());
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSession state", e);
        }
    }
    
    // ========================================================================
    // Audio Focus Methods
    // ========================================================================
    
    /**
     * Sets up audio focus for proper audio handling with other apps.
     */
    private void setupAudioFocus() {
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        mAudioFocusListener = focusChange -> {
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    Log.d(TAG, "Audio focus lost - pausing playback");
                    if (mIsPlaying.get()) {
                        pause();
                    }
                    break;
                    
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    Log.d(TAG, "Audio focus ducking - reducing volume");
                    if (mPlayer != null) {
                        mPlayer.duck();
                    }
                    break;
                    
                case AudioManager.AUDIOFOCUS_GAIN:
                    Log.d(TAG, "Audio focus gained - restoring volume");
                    if (mPlayer != null) {
                        mPlayer.unduck();
                    }
                    break;
                    
                default:
                    break;
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioManager != null) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Requests audio focus for playback.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (mAudioManager == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            mAudioManager.requestAudioFocus(mAudioFocusRequest);
        } else if (mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus when playback stops.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (mAudioManager == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
        } else if (mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers broadcast receivers for service communication.
     */
    private void registerReceivers() {
        // Playback parameters receiver
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_PLAYBACK_PARAMS.equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter(ACTION_UPDATE_PLAYBACK_PARAMS));
        
        // Get playing state receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying.get());
                    Song currentSong = getCurrentSong();
                    responseIntent.putExtra("song_path", currentSong != null ? currentSong.getPath() : null);
                    responseIntent.putExtra("position", getCurrentPosition());
                    sendBroadcast(responseIntent);
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
        
        // Sort mode receiver
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, DEFAULT_SORT_MODE);
                    if (newSortMode != mCurrentSortMode) {
                        mCurrentSortMode = newSortMode;
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
                        
                        // Resort playlist
                        mPlaylistLock.writeLock().lock();
                        try {
                            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                                String currentPath = getCurrentSong() != null ? getCurrentSong().getPath() : null;
                                
                                Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
                                
                                // Find new index for current song
                                if (currentPath != null) {
                                    int newIndex = -1;
                                    for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                        Song song = mCurrentPlaylist.get(i);
                                        if (song != null && currentPath.equals(song.getPath())) {
                                            newIndex = i;
                                            break;
                                        }
                                    }
                                    if (newIndex >= 0) {
                                        mCurrentIndex = newIndex;
                                        saveCurrentPlayingIndex();
                                    }
                                }
                            }
                        } finally {
                            mPlaylistLock.writeLock().unlock();
                        }
                        
                        broadcastUpdate();
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }
}