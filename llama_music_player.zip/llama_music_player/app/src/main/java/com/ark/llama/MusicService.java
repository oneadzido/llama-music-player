package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

/**
 * MusicService - Background service for music playback.
 *
 * <p>This service provides the core music playback functionality for the
 * Llama Music Player application. It runs in the background to allow
 * continuous playback even when the app is not in the foreground.</p>
 *
 * <h3>Authoritative Playback State Machine</h3>
 * <p>Playback orchestration is owned by a single state machine. A
 * {@link ServiceState} enum, a monotonic {@code mGeneration} counter, and a
 * two-index model ({@code mCurrentIndex} / {@code mTargetIndex}) are the
 * only holders of transition state. All state mutations happen on the main
 * thread; the {@code mPlayerLock} guards raw {@link MediaPlayer} calls
 * only — never orchestration.</p>
 *
 * <h3>Two-Index Model</h3>
 * <p>{@code mCurrentIndex} is the index the {@link MediaPlayer} is actually
 * bound to. {@code mTargetIndex} is the index the state machine is driving
 * toward. When {@code mState} is PREPARING, {@code mCurrentIndex} still
 * reflects the outgoing song and {@code mTargetIndex} is the destination.
 * Every request method mutates {@code mTargetIndex} only; only
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <h3>Generation-Based Callback Identity</h3>
 * <p>{@code mGeneration} is incremented by
 * {@link #beginTransition(int, int)}. Every {@link MediaPlayer} listener
 * installed on a player captures the current generation at installation
 * time and compares it against {@code mGeneration} on every invocation. A
 * callback whose captured generation differs is inert: it does not mutate
 * state, does not release the player, and does not re-arm another listener.
 * This is what makes concurrent preparations structurally impossible.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — At most one {@code prepareAsync()} in flight process-wide.</li>
 *   <li>I2 — {@link #releaseMediaPlayer()} runs only from
 *       {@link #beginTransition(int, int)}, {@link #transitionToIdle()},
 *       {@link #stop()}, or {@link #onDestroy()}.</li>
 *   <li>I3 — MediaPlayer callbacks with a stale generation are inert.</li>
 *   <li>I4 — {@link #setShuffle(boolean)} and {@link #setRepeatMode(int)}
 *       touch only their own field; they never cause a transition.</li>
 *   <li>I5 — {@link #onStall()} mutates state and calls {@link #reconcile()};
 *       it never invokes a request method.</li>
 *   <li>I6 — State fields are written only on the main thread.</li>
 *   <li>I7 — {@link #setPlaylist(ArrayList, boolean)} resolves an anchor
 *       and re-enters reconciliation. It never bypasses the gate.</li>
 *   <li>I8 — {@link #transitionToIdle()} is idempotent; second callers join
 *       the first.</li>
 * </ul>
 *
 * <h3>Pause vs Stop</h3>
 * <p>{@link #pause()} retains the {@link MediaPlayer} and its position;
 * {@link #resume()} restarts from that position. {@link #stop()} releases
 * the player but remembers the index in {@code mTargetIndex}, so a
 * subsequent play re-prepares the same track from position 0.
 * {@link #stopCompletely()} tears down to IDLE and clears the playlist.</p>
 *
 * <h3>Timing</h3>
 * <p>The stall detector fires at {@code HEALTH_CHECK_INTERVAL_MS} and
 * treats a position below 100 ms lasting longer than
 * {@code MAX_STALL_TIME_MS} as a stall. The stall budget accrues only while
 * {@code mState == PLAYING}; a slow {@code prepareAsync()} during PREPARING
 * cannot masquerade as a stall. All elapsed-time math uses
 * {@link SystemClock#elapsedRealtime()} to remain immune to wall-clock
 * corrections.</p>
 *
 * @see MediaPlayer
 * @see EqualizerManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for storing the repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for storing the sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action for genre update events during genre loading. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action for setting a pending song path from external sources. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Intent action for audio session changed broadcast. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";

    /**
     * Interval for playback health checks in milliseconds. Chosen to keep
     * stall recovery responsive without waking the main handler more often
     * than necessary.
     */
    private static final int HEALTH_CHECK_INTERVAL_MS = 500;

    /**
     * Maximum time in milliseconds without position progress before
     * recovery. Accrues only while {@code mState == PLAYING} — a slow
     * prepareAsync during PREPARING does not count against this budget.
     */
    private static final int MAX_STALL_TIME_MS = 1500;

    /** Maximum recovery attempts before advancing past the failing song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    // ========================================================================
    // Sort Mode Constants
    // ========================================================================

    /** Sort mode: Title A-Z. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: Title Z-A. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: Artist A-Z. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: Artist Z-A. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: Album A-Z. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: Album Z-A. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: Genre A-Z. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: Genre Z-A. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: Oldest first by file modification date. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: Newest first by file modification date. */
    private static final int SORT_NEWEST = 9;

    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * Playback lifecycle states owned by the main thread. Transitions are
     * serialized through {@link #beginTransition(int, int)} and observed
     * only by listeners whose captured generation matches
     * {@link #mGeneration}.
     */
    private enum ServiceState {
        /** No player bound to a target. */
        IDLE,
        /** Exactly one {@code prepareAsync()} is in flight. */
        PREPARING,
        /** Prepared but not started; awaits an explicit play request. */
        READY,
        /** Actively playing. */
        PLAYING,
        /** Paused; the player is retained and its position held. */
        PAUSED,
        /** Teardown is in flight; all events are dropped. */
        STOPPING
    }

    /** Current state. Written only on the main thread. */
    private ServiceState mState = ServiceState.IDLE;

    /**
     * Identity of the current transition. Bumped by
     * {@link #beginTransition(int, int)}. Listener closures capture this
     * value and compare against it on every callback.
     */
    private long mGeneration = 0L;

    /**
     * Index the {@link MediaPlayer} is actually bound to. When
     * {@code mState == PREPARING}, this still reflects the outgoing song.
     */
    private int mCurrentIndex = -1;

    /**
     * Index the state machine is driving toward. Mutated by request
     * methods, never by transitions directly.
     */
    private int mTargetIndex = -1;

    /** Seek position applied once {@code onPrepared} fires, then cleared. */
    private int mPendingSeekPosition = 0;

    /** Set by {@link #onStall()} to request a same-index re-prepare. */
    private boolean mForceReprepare = false;

    /**
     * When false, {@code onPrepared} leaves the machine in READY instead of
     * transitioning to PLAYING. Set true for every request except when a
     * caller explicitly wants a prepare-only transition.
     */
    private boolean mAutoStartOnPrepared = true;

    /** {@link SystemClock#elapsedRealtime()} at the moment PLAYING was entered. */
    private long mPlaybackStartElapsed = 0L;

    /** Consecutive stall recovery attempts for the current song. */
    private int mRecoveryAttempts = 0;

    /** Dedicated handler for state-machine posts. Never shared with health. */
    private final Handler mMachineHandler = new Handler(Looper.getMainLooper());

    /** Handler for periodic health checks. */
    private Handler mHealthHandler;

    /** Runnable for health check. */
    private Runnable mHealthCheckRunnable;

    // ========================================================================
    // MediaPlayer
    // ========================================================================

    /** MediaPlayer instance for audio playback. */
    private MediaPlayer mMediaPlayer;

    /**
     * Lock for raw {@link MediaPlayer} method invocations. Guards against
     * concurrent access from a stray background thread. Never protects
     * orchestration — that is main-thread serialized.
     */
    private final Object mPlayerLock = new Object();

    /** WakeLock to prevent device sleep during playback. */
    private PowerManager.WakeLock mWakeLock;

    // ========================================================================
    // Playlist and Playback State
    // ========================================================================

    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;

    /** Cached playback flag (mirrors mState == PLAYING for callers). */
    private volatile boolean mIsPlaying = false;

    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;

    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;

    /** Current sort mode for playlist ordering. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** History of shuffled indices (for prev/next in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;

    /** Random number generator for shuffle mode. */
    private Random mRandom;

    /**
     * Path of a song that was added as a loose track and should be played
     * on the next playlist update. Consumed by
     * {@link #setPlaylist(ArrayList, boolean)}.
     */
    private volatile String mPendingSongPath = null;

    // ========================================================================
    // Binder, Library, Notification
    // ========================================================================

    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();

    /** Music library manager for song data. */
    private MusicLibrary mMusicLibrary;

    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;

    // ========================================================================
    // Audio Focus and Session
    // ========================================================================

    /** Audio manager for focus management. */
    private AudioManager mAudioManager;

    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;

    /** Audio focus request for API 26+. */
    private AudioFocusRequest mAudioFocusRequest;

    /** MediaSession for lock screen and headset controls. */
    private MediaSession mMediaSession;

    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    private BroadcastReceiver mSetPendingSongReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Local binder for service binding. Allows activities to obtain a
     * reference to the service.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Sort Comparators
    // ========================================================================

    /**
     * Comparator that orders songs by title in ascending alphabetical order.
     */
    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    /**
     * Comparator that orders songs by title in descending alphabetical order.
     */
    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    /**
     * Comparator that orders songs by artist in ascending order, with title
     * used as a secondary sort key.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by artist in descending order, with title
     * used as a secondary sort key.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by album in ascending order, with title
     * used as a secondary sort key.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by album in descending order, with title
     * used as a secondary sort key.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by genre in ascending order, with title
     * used as a secondary sort key.
     */
    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by genre in descending order, with title
     * used as a secondary sort key.
     */
    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by file modification date, oldest first.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Comparator that orders songs by file modification date, newest first.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }

    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ========================================================================
    // Static Helpers
    // ========================================================================

    /**
     * Sets the player state before update flag.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the current audio session ID.
     *
     * @return The current audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ========================================================================
    // Service Lifecycle
    // ========================================================================

    /**
     * Called when the service is created. Initializes notification service,
     * audio manager, media session, audio focus, wake lock, and broadcast
     * receivers.
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        // Notification setup so the foreground entry is present before any
        // playback request arrives.
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);

        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        // Restore persisted mode settings before the state machine is
        // exercised so that computeNext/computePrevious observe them.
        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        // Health handler is created empty; installHealthCheckRunnable()
        // populates the runnable field it references.
        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "LlamaMusicPlayer::Playback");
            // Reference-counted false: acquire/release are idempotent, which
            // matches the state machine's single-acquire semantics.
            mWakeLock.setReferenceCounted(false);
        }

        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerSoftUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    /**
     * Called when the service is started via startService(). Dispatches the
     * incoming action to the corresponding playback control method. All
     * target methods marshal onto main internally.
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();

            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNextSong();
            } else if (action.equals("ACTION_PREV")) {
                playPreviousSong();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) mNotificationService.stopForeground();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) playSong(position);
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /**
     * Called when the service is destroyed. Releasing the player is done
     * under the lock; all other teardown steps are single-threaded via the
     * main looper.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        // Stop recurring work before teardown so no stall callback fires
        // into a releasing player.
        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        synchronized (mPlayerLock) {
            releaseMediaPlayer();
        }
        releaseWakeLock();
        mIsPlaying = false;
        mState = ServiceState.STOPPING;

        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMachineHandler != null) {
            mMachineHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    /**
     * Called when the system is running low on memory. Memory pressure is
     * not a transition trigger; a reconcile is scheduled so a stalled IDLE
     * with a target is retried.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(this::reconcile);
    }

    /**
     * Called when the task is removed from the recent apps list. Saves the
     * current playback state.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ========================================================================
    // Thread Marshalling and Small Helpers
    // ========================================================================

    /**
     * Runs {@code action} on the main thread, immediately if already there.
     * All state-machine mutations funnel through this method.
     *
     * @param action The runnable to execute on the main thread
     */
    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) action.run();
        else mMachineHandler.post(action);
    }

    private int playlistSize() {
        return mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0;
    }

    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) return null;
        if (index < 0 || index >= mCurrentPlaylist.size()) return null;
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) return -1;
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) return index;
        }
        return -1;
    }

    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try { mWakeLock.acquire(); } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try { mWakeLock.release(); } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    // ========================================================================
    // Pure Functions - No Side Effects, Main Thread Only
    // ========================================================================

    /**
     * Computes the next index from {@code fromIndex}. Shuffle-aware.
     *
     * @param fromIndex The starting index
     * @return The next index, or -1 if the playlist is empty
     */
    private int computeNext(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return pickShuffleNext(fromIndex);
        return (fromIndex + 1) % playlistSize();
    }

    /**
     * Computes the previous index from {@code fromIndex}. Shuffle-aware.
     *
     * @param fromIndex The starting index
     * @return The previous index, or -1 if the playlist is empty
     */
    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return popShuffleHistory(fromIndex);
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    /**
     * Picks the next index in shuffle mode. Appends to mShuffleHistory.
     * Clears history lazily when it exceeds twice the playlist size; this
     * keeps setShuffle() a pure setter (invariant I4).
     *
     * @param fromIndex The current index
     * @return The next shuffle index
     */
    private int pickShuffleNext(int fromIndex) {
        int size = playlistSize();
        if (size <= 1) return fromIndex;

        if (mShuffleHistory == null) mShuffleHistory = new ArrayList<Integer>();
        if (mShuffleHistory.size() >= size * 2) mShuffleHistory.clear();
        if (mRandom == null) mRandom = new Random();

        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);

        mShuffleHistory.add(candidate);
        return candidate;
    }

    /**
     * Pops the previous index from shuffle history, or picks a fresh random
     * when history is too shallow to step back.
     *
     * @param fromIndex The current index
     * @return The previous shuffle index
     */
    private int popShuffleHistory(int fromIndex) {
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int previousIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
            if (previousIndex >= 0 && previousIndex < playlistSize()) return previousIndex;
        }
        int size = playlistSize();
        if (size <= 1) return fromIndex;
        if (mRandom == null) mRandom = new Random();
        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);
        return candidate;
    }

    // ========================================================================
    // Core: Reconcile and Transition
    // ========================================================================

    /**
     * The single gate between "a target exists" and "a transition begins".
     * Every event (request, completion, stall, playlist update) funnels
     * here. Nothing else calls {@link #beginTransition(int, int)}.
     */
    private void reconcile() {
        if (mState == ServiceState.STOPPING) return;
        if (mState == ServiceState.PREPARING) return;
        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) return;

        boolean need = (mTargetIndex != mCurrentIndex) || mForceReprepare;
        if (!need) return;

        mForceReprepare = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    /**
     * Starts a transition toward {@code index}. The only caller of
     * {@code prepareAsync()}. Listener closures capture the current
     * generation and compare it against {@link #mGeneration} on every
     * invocation (invariant I3).
     *
     * <p>All MediaPlayer method calls (reset, setDataSource, prepareAsync)
     * are made under {@code mPlayerLock}. The listener installations are
     * also under the lock, guaranteeing that no other thread can install a
     * listener on the same player instance between release and prepare.</p>
     *
     * @param index The target index
     * @param seekPosition Position to seek to once prepared, or 0 for no seek
     */
    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) return;

        if (playlistEmpty()) { transitionToIdle(); return; }
        if (index < 0 || index >= playlistSize()) return;

        // Bump generation first so any in-flight callback from the previous
        // transition becomes inert before we touch the player.
        final long generation = ++mGeneration;
        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            // Invalid slot; step past it without instantiating a player.
            mState = ServiceState.IDLE;
            mTargetIndex = computeNext(index);
            mMachineHandler.post(this::reconcile);
            return;
        }

        final MediaPlayer player;
        synchronized (mPlayerLock) {
            // Release any prior player. This is the second of only two
            // release sites (the other is transitionToIdle).
            releaseMediaPlayer();
            player = getOrCreatePlayer();
            removeAllListeners(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                mState = ServiceState.IDLE;
                releaseMediaPlayer();
                return;
            }

            try {
                player.setDataSource(song.getPath());
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + song.getPath(), exception);
                mState = ServiceState.IDLE;
                releaseMediaPlayer();
                // Skip past the failing track.
                mTargetIndex = computeNext(index);
                mMachineHandler.post(this::reconcile);
                return;
            }
        }

        final int committedIndex = index;

        // Listeners capture the generation. Any callback that fires with a
        // stale generation returns immediately without touching state.
        player.setOnPreparedListener(mediaPlayer -> {
            if (generation != mGeneration) return;
            onPrepared(mediaPlayer, song, committedIndex);
        });
        player.setOnCompletionListener(mediaPlayer -> {
            if (generation != mGeneration) return;
            onCompletion();
        });
        player.setOnErrorListener((mediaPlayer, what, extra) -> {
            if (generation != mGeneration) return true;
            onPlayerError(what, extra);
            return true;
        });

        try {
            player.prepareAsync();
        } catch (IllegalStateException exception) {
            if (generation != mGeneration) return;
            Log.e(TAG, "prepareAsync failed", exception);
            mState = ServiceState.IDLE;
            releaseMediaPlayer();
        }
    }

    /**
     * Tears down to IDLE. Idempotent (invariant I8): if already STOPPING,
     * the second caller joins the first and returns.
     */
    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) return;
        mState = ServiceState.STOPPING;
        mGeneration++;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mForceReprepare = false;
        mCurrentIndex = -1;

        stopHealthMonitoring();

        synchronized (mPlayerLock) {
            releaseMediaPlayer();
        }
        releaseWakeLock();

        mCurrentPlaylist = null;
        mIsPlaying = false;
        if (mShuffleHistory != null) mShuffleHistory.clear();
        EqualizerManager.getInstance(this).detach();

        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        mState = ServiceState.IDLE;
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // MediaPlayer Callbacks
    // ========================================================================

    /**
     * Fires when {@code prepareAsync()} completes. Commits mCurrentIndex,
     * starts playback (or enters READY if {@code mAutoStartOnPrepared} is
     * false), and re-enters reconcile() to catch a target that was advanced
     * during the async window.
     *
     * @param mediaPlayer The MediaPlayer that finished preparing
     * @param song The song that was prepared
     * @param committedIndex The index this preparation was started for
     */
    private void onPrepared(@NonNull MediaPlayer mediaPlayer, @NonNull Song song, int committedIndex) {
        if (mState != ServiceState.PREPARING) return;

        try {
            int duration = mediaPlayer.getDuration();
            if (duration <= 0) throw new IllegalStateException("invalid duration");

            int seekPosition = mPendingSeekPosition;
            mPendingSeekPosition = 0;
            if (seekPosition > 0 && seekPosition < duration - 500) {
                mediaPlayer.seekTo(seekPosition);
            }

            sCurrentAudioSessionId = mediaPlayer.getAudioSessionId();
            broadcastAudioSessionChanged(sCurrentAudioSessionId);
            EqualizerManager.getInstance(this).attachToAudioSession(sCurrentAudioSessionId);

            mCurrentIndex = committedIndex;

            // Non-autostart requests leave the machine in READY. The next
            // togglePlayPause starts playback.
            if (!mAutoStartOnPrepared) {
                mState = ServiceState.READY;
                mRecoveryAttempts = 0;
                updateMediaSessionMetadata(song, null);
                updateMediaSessionPlaybackState();
                saveCurrentPlayingIndex();
                createNotification();
                broadcastUpdate();
                return;
            }

            mState = ServiceState.PLAYING;
            mediaPlayer.start();
            mPlaybackStartElapsed = SystemClock.elapsedRealtime();
            mRecoveryAttempts = 0;
            mIsPlaying = true;

            acquireWakeLock();
            requestAudioFocus();
            updatePlaybackParams();
            updateMediaSessionMetadata(song, null);
            updateMediaSessionPlaybackState();
            saveCurrentPlayingIndex();
            savePlayingState();
            savePlayerState();
            startHealthMonitoring();
            createNotification();
            broadcastUpdate();

            // A NEXT/PREV that arrived during the async window bumped
            // mTargetIndex. Defer reconcile so we do not release the player
            // from inside its own callback.
            if (mTargetIndex != mCurrentIndex || mForceReprepare) {
                mMachineHandler.post(this::reconcile);
            }
        } catch (IllegalStateException exception) {
            Log.e(TAG, "onPrepared: player in illegal state", exception);
            mState = ServiceState.IDLE;
            releaseMediaPlayer();
            broadcastUpdate();
        }
    }

    /**
     * Fires when the current track finishes. Chooses the next destination
     * from mRepeatMode. Forward and backward transitions are posted to main
     * so the player is not released from inside its own completion callback.
     * The end-of-playlist branch pauses in place and does not transition.
     * A same-index destination (repeat-one, or repeat-all on a single-song
     * playlist) sets mForceReprepare so reconcile() restarts playback.
     */
    private void onCompletion() {
        if (mState != ServiceState.PLAYING) return;

        if (playlistEmpty()) { transitionToIdle(); return; }

        int fromIndex = mCurrentIndex;
        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mRepeatMode == 1) {
            nextIndex = computeNext(fromIndex);
        } else if (fromIndex + 1 < playlistSize()) {
            nextIndex = fromIndex + 1;
        } else {
            // End of playlist, no repeat. Pause on the last track and reset
            // position so a subsequent play restarts it from the beginning.
            mState = ServiceState.PAUSED;
            mTargetIndex = fromIndex;
            mPendingSeekPosition = 0;
            mIsPlaying = false;
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null) {
                    try { mMediaPlayer.pause(); } catch (Exception ignored) {}
                    try { mMediaPlayer.seekTo(0); } catch (Exception ignored) {}
                }
            }
            releaseWakeLock();
            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        mMachineHandler.post(this::reconcile);
    }

    /**
     * Fires when MediaPlayer reports an error. Releases the player and
     * advances past the failed track.
     *
     * @param what The error type
     * @param extra The error extra code
     */
    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);

        mIsPlaying = false;
        mState = ServiceState.IDLE;
        releaseMediaPlayer();

        if (!playlistEmpty() && mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        mMachineHandler.post(this::reconcile);
    }

    /**
     * Fires from the health check when position has not advanced past 100 ms
     * for MAX_STALL_TIME_MS while in PLAYING. Mutates target, then
     * reconciles. Does not call any request method (invariant I5).
     */
    private void onStall() {
        if (mState != ServiceState.PLAYING) return;

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) { transitionToIdle(); return; }
            // Give up on the current track; advance.
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
        } else {
            // Re-prepare the same index, seeking back to the last known
            // good position.
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
        }

        reconcile();
    }

    // ========================================================================
    // Health Monitoring
    // ========================================================================

    /**
     * Installs the health check runnable. Called once from onCreate; the
     * runnable reschedules itself.
     */
    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                // Stall budget accrues only in PLAYING. A slow prepareAsync
                // during PREPARING must not be treated as a stall.
                if (mState == ServiceState.PLAYING) {
                    int position = getCurrentPosition();
                    long elapsed = SystemClock.elapsedRealtime() - mPlaybackStartElapsed;
                    if (position < 100 && elapsed > MAX_STALL_TIME_MS) {
                        onStall();
                    } else if (position >= 100) {
                        // Progress observed; reset the stall clock.
                        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                    }
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    /**
     * Starts the health monitoring cycle. Called whenever the state machine
     * enters PLAYING.
     */
    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    /**
     * Stops the health monitoring cycle.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ========================================================================
    // Public Request API
    // ========================================================================

    /**
     * Requests playback of the song at {@code index}. Marshals onto main.
     *
     * @param index The index to play
     */
    public void playSong(int index) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests playback at {@code index} starting from {@code position} ms.
     *
     * @param index The index to play
     * @param position The position to seek to in milliseconds
     */
    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    /**
     * Requests playback by file path. When the path is not in the playlist,
     * parks it as {@code mPendingSongPath}; setPlaylist will resolve it as
     * an anchor on the next update.
     *
     * @param filePath The file path of the song
     */
    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG, "playSongByPath: not in playlist, parked: " + filePath);
            }
        });
    }

    /**
     * Requests the next song. The base-index selection is critical: when a
     * transition is in flight we compute from {@code mTargetIndex} so rapid
     * NEXT presses advance the eventual destination by one each. Without
     * this, five presses in a burst would collapse into a single skip
     * because they would all read the same {@code mCurrentIndex}.
     */
    public void playNextSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            int baseIndex = (mState == ServiceState.PREPARING) ? mTargetIndex : mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computeNext(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests the previous song. Uses the same base-index rule as
     * {@link #playNextSong()}.
     */
    public void playPreviousSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            int baseIndex = (mState == ServiceState.PREPARING) ? mTargetIndex : mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computePrevious(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Toggles between play and pause based on the current state.
     */
    public void togglePlayPause() {
        onMain(() -> {
            switch (mState) {
                case PLAYING:
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY:
                    // Prepared but never started. Just start it.
                    synchronized (mPlayerLock) {
                        if (mMediaPlayer != null) {
                            try { mMediaPlayer.start(); }
                            catch (Exception exception) {
                                Log.e(TAG, "start() failed from READY", exception);
                                mState = ServiceState.IDLE;
                                releaseMediaPlayer();
                                broadcastUpdate();
                                return;
                            }
                        }
                    }
                    mState = ServiceState.PLAYING;
                    mIsPlaying = true;
                    mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                    acquireWakeLock();
                    requestAudioFocus();
                    updatePlaybackParams();
                    savePlayingState();
                    savePlayerState();
                    startHealthMonitoring();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                    break;
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        createNotification();
                        return;
                    }
                    if (mTargetIndex < 0) mTargetIndex = 0;
                    reconcile();
                    break;
                case PREPARING:
                case STOPPING:
                    // Transition in flight; drop. The transition's tail will
                    // see the newer request when it re-enters reconcile().
                    break;
            }
        });
    }

    /**
     * Requests pause. No-op unless PLAYING.
     */
    public void pause() {
        onMain(() -> { if (mState == ServiceState.PLAYING) doPause(); });
    }

    /**
     * Requests resume. Handles PAUSED, READY, and IDLE-with-target.
     */
    public void resume() {
        onMain(() -> {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                if (mTargetIndex < 0 && !playlistEmpty()) mTargetIndex = 0;
                reconcile();
            }
        });
    }

    /**
     * Stops playback but retains the current song as a future target.
     * Position resets to 0 on next play. Distinct from pause, which retains
     * the player and its position.
     */
    public void stop() {
        onMain(() -> {
            if (mState != ServiceState.PLAYING && mState != ServiceState.PAUSED) return;

            int stoppedAtIndex = mCurrentIndex;

            synchronized (mPlayerLock) {
                releaseMediaPlayer();
            }
            releaseWakeLock();

            mIsPlaying = false;
            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;   // remember where we stopped
            mPendingSeekPosition = 0;        // position resets to 0 on next play
            mForceReprepare = false;
            mState = ServiceState.IDLE;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        });
    }

    /**
     * Tears down to IDLE and clears the playlist. Idempotent.
     */
    public void stopCompletely() {
        onMain(this::transitionToIdle);
    }

    /**
     * Internal pause. Called from togglePlayPause, audio focus loss, and
     * completion-at-end-of-playlist.
     */
    private void doPause() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                try { mMediaPlayer.pause(); } catch (Exception ignored) {}
            }
        }
        mState = ServiceState.PAUSED;
        mIsPlaying = false;
        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    /**
     * Internal resume. Called from togglePlayPause and audio focus gain.
     */
    private void doResume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mState = ServiceState.IDLE;
                reconcile();
                return;
            }
            requestAudioFocus();
            updatePlaybackParams();
            try {
                mMediaPlayer.start();
            } catch (Exception exception) {
                Log.e(TAG, "resume: start() failed", exception);
                mState = ServiceState.IDLE;
                releaseMediaPlayer();
                broadcastUpdate();
                return;
            }
        }
        mState = ServiceState.PLAYING;
        mIsPlaying = true;
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        acquireWakeLock();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    /**
     * Requests a seek. During PREPARING, records the position; it is applied
     * when the transition's onPrepared fires.
     *
     * @param position The position to seek to in milliseconds
     */
    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {
                synchronized (mPlayerLock) {
                    if (mMediaPlayer != null) {
                        try { mMediaPlayer.seekTo(position); } catch (Exception ignored) {}
                    }
                }
                savePlayerState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
            }
        });
    }

    // ========================================================================
    // Playlist
    // ========================================================================

    /**
     * Sets the current playlist. Resolves an anchor (pending path, then
     * current path, then saved path, then same-title fallback, then index 0)
     * and either preserves playback on the same song or re-enters
     * reconciliation to begin a transition.
     *
     * <p>During PREPARING, only {@code mTargetIndex} is updated; the async
     * onPrepared tail handles the case where the committed index differs
     * from the resolved index.</p>
     *
     * @param playlist The new playlist (sorted internally by the current
     *                 sort mode)
     * @param preserveCurrentSong If true, anchors on the current song when
     *                            possible
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) return;

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) { broadcastUpdate(); return; }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));

            // Fast path: identical order and content. No state change.
            if (mCurrentPlaylist != null
                && mCurrentPlaylist.size() == sortedPlaylist.size()
                && sameOrder(mCurrentPlaylist, sortedPlaylist)) {
                broadcastUpdate();
                return;
            }

            // Resolve anchor BEFORE assigning mCurrentPlaylist so pathOf()
            // reads the old list. Prefer pending, then current, then saved.
            String anchorPath = mPendingSongPath;
            if (anchorPath == null) anchorPath = pathOf(mCurrentIndex);
            if (anchorPath == null) anchorPath = getSavedSongPath();

            // A copy of the anchor Song for title fallback.
            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null && anchorPath.equals(candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mCurrentPlaylist = sortedPlaylist;

            int resolvedIndex = (anchorPath != null) ? indexOfPath(anchorPath) : -1;

            // Anchor removed: fall back to same-title match, else index 0.
            if (resolvedIndex < 0 && anchorSong != null && anchorSong.getTitle() != null) {
                for (int index = 0; index < sortedPlaylist.size(); index++) {
                    Song candidateSong = sortedPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }
            if (resolvedIndex < 0) resolvedIndex = 0;

            mPendingSongPath = null;

            // Mid-prepare: do not yank the player. Update the destination;
            // onPrepared's tail reconciles if the committed index differs.
            if (mState == ServiceState.PREPARING) {
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            boolean sameSong = (resolvedIndex == mCurrentIndex)
                            && (mState == ServiceState.PLAYING
                                || mState == ServiceState.PAUSED
                                || mState == ServiceState.READY);

            mTargetIndex = resolvedIndex;

            if (sameSong) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) updateMediaSessionMetadata(currentSong, null);
                updateMediaSessionPlaybackState();
                createNotification();
                broadcastUpdate();
            } else {
                reconcile();
            }
        });
    }

    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    /**
     * Soft update: equivalent to
     * {@link #setPlaylist(ArrayList, boolean)} with
     * {@code preserveCurrentSong = true}. The anchor resolver does the
     * work; no separate staging is needed under the state machine.
     *
     * @param newPlaylist The new playlist to apply
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    /**
     * Returns the current playlist.
     *
     * @return A copy of the current playlist, or an empty list when none
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) return new ArrayList<Song>();
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    /**
     * Compares two playlists by path order. Used by the fast path in
     * setPlaylist to skip redundant updates.
     *
     * @param firstPlaylist First playlist
     * @param secondPlaylist Second playlist
     * @return True if both lists have identical path order
     */
    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) return false;
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null) ? firstSong.getPath() : null;
            String secondPath = (secondSong != null) ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ========================================================================
    // Pending Song Path
    // ========================================================================

    /**
     * Sets the pending song path to be played after a playlist update. The
     * value is a hint consumed by
     * {@link #setPlaylist(ArrayList, boolean)} as the primary anchor when
     * resolving which song to preserve across a list change.
     *
     * @param path The file path of the song to play, or null to clear
     */
    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            mPendingSongPath = path;
            if (path != null) {
                Log.d(TAG, "Pending song path set: " + path);
                playPendingSongIfExists();
            } else {
                Log.d(TAG, "Pending song path cleared");
            }
        });
    }

    /**
     * Gets the pending song path.
     *
     * @return The pending song path, or null if none
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    /**
     * Clears the pending song path.
     */
    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    /**
     * Attempts to play the pending song if it is already present in the
     * current playlist. Otherwise the pending path is left in place for
     * setPlaylist to consume as an anchor.
     */
    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) return;
            int index = indexOfPath(mPendingSongPath);
            if (index >= 0) {
                mPendingSongPath = null;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            }
        });
    }

    /**
     * No-op. Transition state is cleared implicitly by generation bumps at
     * the start of every {@link #beginTransition(int, int)}; an external
     * force-clear would violate invariant I1. Retained as a named entry
     * point so callers have an explicit "reset" they can invoke without
     * effect.
     */
    public void forceClearTransitionState() {
        Log.d(TAG, "forceClearTransitionState: no-op under state machine");
    }

    // ========================================================================
    // Getters and Mode Setters
    // ========================================================================

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return The current position, or 0 when unavailable
     */
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mState != ServiceState.IDLE
                && mState != ServiceState.STOPPING) {
                try { return mMediaPlayer.getCurrentPosition(); }
                catch (Exception exception) { return 0; }
            }
        }
        return 0;
    }

    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return The duration, or 0 when unavailable
     */
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mState != ServiceState.IDLE
                && mState != ServiceState.STOPPING) {
                try { return mMediaPlayer.getDuration(); }
                catch (Exception exception) { return 0; }
            }
        }
        return 0;
    }

    /**
     * Checks if playback is currently active.
     *
     * @return True if the service is playing
     */
    public boolean isPlaying() {
        if (mState != ServiceState.PLAYING) return false;
        synchronized (mPlayerLock) {
            return isMediaPlayerPlaying(mMediaPlayer);
        }
    }

    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try { return player.isPlaying(); } catch (Exception exception) { return false; }
    }

    /**
     * Returns the currently playing song. During PREPARING, returns the
     * target song so the notification and lock screen reflect the
     * destination as soon as the request is issued, not after the async
     * prepare completes.
     *
     * @return The current song, or null when none
     */
    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return null;

        int index = mCurrentIndex;
        if (mState == ServiceState.PREPARING && mTargetIndex >= 0) {
            index = mTargetIndex;
        }
        if (index < 0 || index >= mCurrentPlaylist.size()) return null;
        return mCurrentPlaylist.get(index);
    }

    /**
     * Returns the current playlist index.
     *
     * @return The current index, or -1 when none
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() { return mRepeatMode; }

    /**
     * Sets the repeat mode. Touches only {@code mRepeatMode} and persists
     * it. No transition is triggered by the change.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() { return mIsShuffle; }

    /**
     * Sets shuffle mode. Touches only {@code mIsShuffle} and persists it.
     * The shuffle history is trimmed lazily inside
     * {@link #pickShuffleNext(int)} when it exceeds twice the playlist
     * size, so no separate clear is required here.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if a Bluetooth headset is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ========================================================================
    // Sort Mode
    // ========================================================================

    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ========================================================================
    // Notifications
    // ========================================================================

    /**
     * Updates the playback notification with the current song metadata and
     * playing state.
     */
    private void createNotification() {
        if (mNotificationService == null) return;

        Song notificationSong = null;
        if (mState == ServiceState.PLAYING
            || mState == ServiceState.PAUSED
            || mState == ServiceState.PREPARING
            || mState == ServiceState.READY) {
            notificationSong = getCurrentSong();
        }

        if (notificationSong != null) {
            mNotificationService.updateSongInfo(
                notificationSong.getTitle(),
                notificationSong.getArtist(),
                notificationSong.getPath());
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mState == ServiceState.PLAYING);
    }

    /**
     * Refreshes the playback notification, including the sync state.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }

    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap (can be null)
     * @param artPath The file path associated with the album art (can be null)
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService == null) return;
        Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
        Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
        mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
    }

    // ========================================================================
    // Persistence
    // ========================================================================

    /**
     * Persists the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    private void saveFullState() {
        savePlayerState();
    }

    /**
     * Gets the saved playback position.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    /**
     * Checks whether playback was active before the last state save.
     *
     * @return True if playback was active
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    /**
     * Gets the saved song path.
     *
     * @return The saved song path, or null if none
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    /**
     * Loads repeat mode and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = preferences.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = preferences.getBoolean(KEY_SHUFFLE, false);
    }

    // ========================================================================
    // MediaPlayer Plumbing
    // ========================================================================

    /**
     * Removes all listeners from a MediaPlayer. Callers invoke this under
     * mPlayerLock before release or reset so that late callbacks are
     * detached from the invalidated player.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }

    /**
     * Releases the MediaPlayer and the wake lock. This is the single point
     * of release (besides transitionToIdle, which calls it under the same
     * lock) and nulls the instance inside the lock to prevent
     * use-after-release.
     */
    private void releaseMediaPlayer() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try { mWakeLock.release(); } catch (Exception ignored) {}
        }
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
            try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            try { mMediaPlayer.release(); } catch (Exception ignored) {}
            mMediaPlayer = null;
        }
        mIsPlaying = false;
    }

    /**
     * Gets or creates the MediaPlayer instance.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
            }
            return mMediaPlayer;
        }
    }

    // ========================================================================
    // Playback Params
    // ========================================================================

    /**
     * Updates playback parameters (speed and pitch) from the
     * EqualizerManager. Converts the speed level to tempo and the pitch
     * level to semitones.
     */
    public void updatePlaybackParams() {
        EqualizerManager equalizerManager = EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        if (mMediaPlayer != null) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams playbackParams = mMediaPlayer.getPlaybackParams();
                playbackParams.setSpeed(tempo);
                playbackParams.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params", exception);
            }
        }
    }

    // ========================================================================
    // MediaSession
    // ========================================================================

    /**
     * Sets up the MediaSession for lock screen and headset controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            mMediaSession = new MediaSession(this, "LlamaMusicService");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() {
                    // MediaSession callbacks may arrive off-main; route
                    // through the request API which marshals internally.
                    if (mState == ServiceState.PAUSED) doResume();
                    else if (mState == ServiceState.IDLE) resume();
                }
                @Override public void onPause() {
                    if (mState == ServiceState.PLAYING) doPause();
                }
                @Override public void onSkipToNext() { playNextSong(); }
                @Override public void onSkipToPrevious() { playPreviousSong(); }
                @Override public void onStop() { pause(); }
                @Override public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId != null) {
                        try { playSong(Integer.parseInt(mediaId)); }
                        catch (NumberFormatException ignored) {}
                    }
                }
            });
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    /**
     * Updates the MediaSession metadata.
     *
     * @param song The song whose metadata is displayed (can be null)
     * @param albumArt The album art bitmap to attach (can be null)
     */
    public void updateMediaSessionMetadata(@Nullable Song song, @Nullable Bitmap albumArt) {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            MediaMetadata.Builder builder = new MediaMetadata.Builder();
            if (song != null) {
                builder.putString(MediaMetadata.METADATA_KEY_TITLE, song.getTitle());
                builder.putString(MediaMetadata.METADATA_KEY_ARTIST, song.getArtist());
                builder.putString(MediaMetadata.METADATA_KEY_ALBUM, song.getAlbum());
                if (albumArt != null && !albumArt.isRecycled()) {
                    builder.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, albumArt);
                }
            } else {
                builder.putString(MediaMetadata.METADATA_KEY_TITLE, "Llama Music Player");
                builder.putString(MediaMetadata.METADATA_KEY_ARTIST, "");
                builder.putString(MediaMetadata.METADATA_KEY_ALBUM, "");
            }
            mMediaSession.setMetadata(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession metadata", exception);
        }
    }

    /**
     * Updates only the album art of the MediaSession metadata.
     *
     * @param albumArt The album art bitmap (can be null)
     */
    public void updateMediaSessionArt(@Nullable Bitmap albumArt) {
        updateMediaSessionMetadata(getCurrentSong(), albumArt);
    }

    /**
     * Updates the MediaSession playback state. Reflects the current playing
     * state, position, and supported actions. Uses the framework's
     * {@link android.media.session.PlaybackState} (distinct from
     * {@link ServiceState}, which tracks this service's own machine).
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            PlaybackState.Builder builder = new PlaybackState.Builder();
            long actions = PlaybackState.ACTION_PLAY
                         | PlaybackState.ACTION_PAUSE
                         | PlaybackState.ACTION_SKIP_TO_NEXT
                         | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackState.ACTION_STOP;
            int frameworkState = (mState == ServiceState.PLAYING)
                ? PlaybackState.STATE_PLAYING
                : PlaybackState.STATE_PAUSED;
            builder.setState(frameworkState, getCurrentPosition(), 1.0f);
            builder.setActions(actions);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state", exception);
        }
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    /**
     * Sets up the audio focus request used by the service.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    /**
     * Handles audio focus changes. Pauses on permanent or transient focus
     * loss. Does not auto-resume on gain; the user is expected to resume.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mState == ServiceState.PLAYING) doPause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
            case AudioManager.AUDIOFOCUS_GAIN:
            default:
                break;
        }
    }

    // ========================================================================
    // Media Button
    // ========================================================================

    /**
     * Handles media button events from Bluetooth headsets and hardware keys.
     * When a Bluetooth headset is connected, volume keys are mapped to
     * next and previous track controls.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) { playNextSong(); return; }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) { playPreviousSong(); return; }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: togglePlayPause(); break;
            case KeyEvent.KEYCODE_MEDIA_NEXT: playNextSong(); break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: playPreviousSong(); break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mState == ServiceState.PAUSED) doResume();
                else if (mState == ServiceState.IDLE) resume();
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mState == ServiceState.PLAYING) doPause();
                break;
            default: break;
        }
    }

    // ========================================================================
    // Broadcasts
    // ========================================================================

    /**
     * Broadcasts a full snapshot of playback state. Every field the
     * receiver needs to render a frame is carried here, so receivers never
     * have to query back into the service and race a subsequent transition.
     *
     * <p>Receivers MUST drop any UPDATE_PLAYER whose {@code generation} is
     * strictly less than the highest they have already processed. Equal is
     * accepted: position and duration advance within a generation.</p>
     *
     * <p>Two song paths are carried:</p>
     * <ul>
     *   <li>{@code song_path} — the bound player's song. During PREPARING
     *       this is still the outgoing song.</li>
     *   <li>{@code target_song_path} — the destination. Equal to
     *       {@code song_path} outside PREPARING.</li>
     * </ul>
     *
     * <p>Receivers that render the destination as "current" (title bar,
     * notification alignment) read {@code target_song_path} when
     * {@code state} is PREPARING so they align with
     * {@link #getCurrentSong()}, which returns the destination during the
     * same window. Receivers that render the bound player (playlist
     * highlight, seek bar) read {@code song_path}.</p>
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", mGeneration);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", mState == ServiceState.PLAYING);
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());
        sendBroadcast(intent);
    }

    /**
     * Broadcasts an audio session change event.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    // ========================================================================
    // Receivers
    // ========================================================================

    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    refreshNotification();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }

    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) stopCompletely();
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }

    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) createNotification();
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response = new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", mState == ServiceState.PLAYING);
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit().putBoolean(KEY_LAST_PLAYING,
                            mState == ServiceState.PLAYING).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }

    /**
     * Sort mode updates are applied to the live playlist. The anchor
     * (current song path) is captured before the sort, then located again
     * after; the current index is rewritten only if the song is still
     * present.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) return;
                int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) return;
                mCurrentSortMode = newSortMode;
                saveSortMode();
                onMain(() -> {
                    if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
                    String anchorPath = pathOf(mCurrentIndex);
                    Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
                    if (anchorPath != null) {
                        int newIndex = indexOfPath(anchorPath);
                        if (newIndex >= 0) {
                            mCurrentIndex = newIndex;
                            saveCurrentPlayingIndex();
                        }
                    }
                    broadcastUpdate();
                });
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) return;
                ToastManager.hidePersistentOverlay();
                refreshNotification();
                broadcastUpdate();
            }
        };
        registerReceiver(mSyncCompleteReceiver, new IntentFilter("SYNC_COMPLETE"));
    }

    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(intent.getAction())) return;
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    createNotification();
                    broadcastUpdate();
                }
            }
        };
        registerReceiver(mGenreUpdateReceiver, new IntentFilter(ACTION_GENRE_UPDATE));
    }

    /**
     * SOFT_UPDATE_PLAYLIST reloads the library cache and applies the new
     * playlist through the anchor resolver (preserveCurrentSong = true).
     */
    private void registerSoftUpdatePlaylistReceiver() {
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (intent == null || !"SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) return;

                if (mMusicLibrary == null) mMusicLibrary = new MusicLibrary(MusicService.this);
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiver(mSoftUpdatePlaylistReceiver, new IntentFilter("SOFT_UPDATE_PLAYLIST"));
    }

    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) setPendingSongPath(path);
                }
            }
        };
        registerReceiver(mSetPendingSongReceiver, new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) return;
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    // ========================================================================
    // Genre and Metadata Updates
    // ========================================================================

    /**
     * Updates the genre for a specific song in the current playlist.
     * Refreshes the notification and media session metadata when the
     * updated song is the currently playing song.
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value
     */
    private void updateGenreInPlaylist(@NonNull String songPath, @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath) || TextUtils.isEmpty(newGenre)) return;
        if (mCurrentPlaylist == null) return;

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                    broadcastUpdate();

                    Song currentSong = getCurrentSong();
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        createNotification();
                        updateMediaSessionMetadata(currentSong, null);
                    }
                }
                break;
            }
        }
    }

    /**
     * Refreshes metadata for the currently playing song. Updates the
     * in-memory playlist entry, persists the change, and refreshes the
     * notification and media session.
     *
     * @param songPath The path of the song to update
     * @param newTitle The new title, or null for no change
     * @param newArtist The new artist, or null for no change
     * @param newAlbum The new album, or null for no change
     * @param newGenre The new genre, or null for no change
     * @param albumArtBytes The new album art bytes, or null for no change
     * @param albumArtRemoved True if the album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;

            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null || !songPath.equals(currentSong.getPath())) return;

            String finalTitle = (newTitle != null && !newTitle.isEmpty())
                ? newTitle : currentSong.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty())
                ? newArtist : currentSong.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty())
                ? newAlbum : currentSong.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty())
                ? newGenre : currentSong.getGenre();

            Song updatedSong = new Song(finalTitle, finalArtist, finalAlbum, finalGenre,
                songPath, currentSong.getDuration(), null);
            if (currentSong.getUri() != null) updatedSong.setUri(currentSong.getUri());

            mCurrentPlaylist.set(mCurrentIndex, updatedSong);
            SongDatabase.getInstance(this).insertSong(updatedSong);

            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        });
    }

    // ========================================================================
    // Close Action
    // ========================================================================

    /**
     * Handles the close action from the notification: tears down to IDLE,
     * stops the service, and launches the main activity with the close flag.
     */
    private void handleCloseAction() {
        onMain(() -> {
            transitionToIdle();
            stopSelf();
            Intent closeIntent = new Intent(this, MusicPlayer.class);
            closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            closeIntent.putExtra("close_app", true);
            startActivity(closeIntent);
        });
    }
}