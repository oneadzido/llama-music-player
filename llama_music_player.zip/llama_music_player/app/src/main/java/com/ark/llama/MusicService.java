package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback.
 * This is the single source of truth for playback state.
 */
public class MusicService extends Service {

    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    public static final String ACTION_PLAYLIST_CHANGED = "com.ark.llama.PLAYLIST_CHANGED";

    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";

    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;

    private static final long HEALTH_CHECK_INTERVAL_MS = 3000;
    private static final long MAX_STALL_TIME_MS = 5000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    // Static current audio session ID
    private static int sCurrentAudioSessionId = 0;

    private MediaPlayer mMediaPlayer;
    private final Object mPlayerLock = new Object();
    private ArrayList<Song> mCurrentPlaylist;
    private int mCurrentIndex = -1;
    private boolean mIsPlaying = false;
    private int mRepeatMode = 0;
    private boolean mIsShuffle = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;

    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    private int mCurrentPrepId = -1;

    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    private AudioFocusRequest mAudioFocusRequest;
    private MediaSession mMediaSession;
    private NotificationService mNotificationService;

    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;

    private Handler mHealthHandler;
    private Runnable mHealthCheckRunnable;
    private int mRecoveryAttempts = 0;
    private long mPlaybackStartTime = 0;

    private BroadcastReceiver mSortModeReceiver;
    private volatile boolean mIsBluetoothConnected = false;

    public class LocalBinder extends Binder {
        public MusicService getService() { return MusicService.this; }
    }

    private final IBinder mBinder = new LocalBinder();

    // ========== Static methods ==========

    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    // ========== Service lifecycle ==========

    @Override
    public void onCreate() {
        super.onCreate();
        mNotificationService = new NotificationService(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        mShuffleHistory = new ArrayList<>();
        mRandom = new Random();
        mHealthHandler = new Handler(Looper.getMainLooper());

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerSortModeReceiver();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "ACTION_PLAY_PAUSE": togglePlayPause(); break;
                case "ACTION_NEXT": playNext(); break;
                case "ACTION_PREV": playPrevious(); break;
                case "ACTION_STOP": stopCompletely(); break;
                case "PLAY_SONG":
                    String path = intent.getStringExtra("song_path");
                    if (path != null) playSongByPath(path);
                    else {
                        int pos = intent.getIntExtra("position", -1);
                        if (pos >= 0) playSong(pos);
                    }
                    break;
            }
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        saveFullState();
        releaseMediaPlayer();
        if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
        if (mNotificationService != null) mNotificationService.stopForeground();
        if (mMediaSession != null) mMediaSession.release();
        abandonAudioFocus();
        unregisterReceiverSafely(mSortModeReceiver);
        super.onDestroy();
    }

    // ========== Public API ==========

    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }

    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }

    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) playNext();
            else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) playPrevious();
            return;
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: togglePlayPause(); break;
            case KeyEvent.KEYCODE_MEDIA_NEXT: playNext(); break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: playPrevious(); break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: if (!mIsPlaying && mCurrentIndex >= 0) resume(); break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: if (mIsPlaying) pause(); break;
        }
    }

    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null || mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null || !songPath.equals(current.getPath())) return;

            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();

            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) updated.setUri(current.getUri());
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            broadcastPlaylistChanged();
            createNotification();
        }
    }

    public ArrayList<Song> getCurrentPlaylist() {
        synchronized (mPlayerLock) {
            return mCurrentPlaylist != null ? new ArrayList<>(mCurrentPlaylist) : new ArrayList<>();
        }
    }

    public int getPlaylistSize() {
        synchronized (mPlayerLock) {
            return mCurrentPlaylist == null ? 0 : mCurrentPlaylist.size();
        }
    }

    public int getCurrentIndex() { return mCurrentIndex; }
    public boolean isPlaying() { return mIsPlaying && isPlayerReady(); }
    public boolean isPlayerPrepared() { return isPlayerReady(); }
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && mCurrentIndex < mCurrentPlaylist.size())
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try { return mMediaPlayer.getCurrentPosition(); } catch (Exception e) { return 0; }
            }
            return 0;
        }
    }
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try { return mMediaPlayer.getDuration(); } catch (Exception e) { return 0; }
            }
            return 0;
        }
    }
    public int getRepeatMode() { return mRepeatMode; }
    public void setRepeatMode(int mode) { mRepeatMode = mode; savePlayerState(); }
    public boolean isShuffle() { return mIsShuffle; }
    public void setShuffle(boolean shuffle) { mIsShuffle = shuffle; if (shuffle) mShuffleHistory.clear(); savePlayerState(); }

    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                saveFullState();
                broadcastPlaylistChanged();
                return;
            }
            ArrayList<Song> sorted = new ArrayList<>(playlist);
            Collections.sort(sorted, getComparatorForSortMode(mCurrentSortMode));
            int newIndex = -1;
            if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                for (int i = 0; i < sorted.size(); i++) {
                    if (sorted.get(i).getPath().equals(currentPath)) { newIndex = i; break; }
                }
            }
            if (newIndex == -1 && preserveCurrentSong) {
                String savedPath = getSavedSongPath();
                if (savedPath != null) {
                    for (int i = 0; i < sorted.size(); i++) {
                        if (sorted.get(i).getPath().equals(savedPath)) { newIndex = i; break; }
                    }
                }
            }
            if (newIndex == -1) newIndex = 0;
            boolean needsReset = (mCurrentIndex != newIndex) || (mCurrentPlaylist != null && mCurrentPlaylist.size() != sorted.size());
            if (needsReset) resetPlayerSafely();
            mCurrentPlaylist = sorted;
            mCurrentIndex = newIndex;
            saveCurrentPlayingIndex();
            if (preserveCurrentSong && wasPlayingBeforeRestart()) {
                int savedPos = getSavedPosition();
                prepareAndPlay(mCurrentIndex, savedPos);
            } else if (preserveCurrentSong) {
                prepareOnly(mCurrentIndex);
            }
            broadcastPlaylistChanged();
        }
    }

    public void playSong(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        prepareAndPlay(index, 0);
    }

    public void playSongByPath(String path) {
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(path)) {
                playSong(i);
                return;
            }
        }
    }

    public void playNext() {
        if (!acquireTransitionLock()) return;
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory.size() >= mCurrentPlaylist.size()) mShuffleHistory.clear();
                do {
                    nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && mShuffleHistory.contains(nextIndex));
                mShuffleHistory.add(nextIndex);
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            mCurrentIndex = nextIndex;
            playSong(mCurrentIndex);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, 500);
        }
    }

    public void playPrevious() {
        if (!acquireTransitionLock()) return;
        try {
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            int prevIndex;
            if (mIsShuffle && mShuffleHistory.size() >= 2) {
                prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                mShuffleHistory.remove(mShuffleHistory.size() - 1);
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            mCurrentIndex = prevIndex;
            playSong(mCurrentIndex);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, 500);
        }
    }

    public void togglePlayPause() {
        if (mMediaPlayer != null && mCurrentIndex >= 0) {
            if (mIsPlaying) pause();
            else resume();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
            playSong(0);
        }
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    public void pause() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try { mMediaPlayer.pause(); } catch (Exception e) { Log.e(TAG, "pause error", e); }
                mIsPlaying = false;
                if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
                savePlayingState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                createNotification();
            }
        }
    }

    public void resume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                if (!mIsPlaying) {
                    requestAudioFocus();
                    mMediaPlayer.start();
                    mIsPlaying = true;
                    startHealthMonitoring();
                    if (mWakeLock != null && !mWakeLock.isHeld()) mWakeLock.acquire();
                    savePlayingState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                playSong(0);
            }
        }
    }

    public void seekTo(int position) {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try { mMediaPlayer.seekTo(position); } catch (Exception e) { Log.e(TAG, "seek error", e); }
            }
        }
    }

    public void stopCompletely() {
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            resetPlayerSafely();
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            mIsPlaying = false;
            saveFullState();
            broadcastPlaylistChanged();
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
    }

    // ========== Internal methods ==========

    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try { mMediaPlayer.getDuration(); return true; } catch (Exception e) { return false; }
        }
    }

    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
        } catch (Exception ignored) {}
    }

    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception e) {
                    Log.w(TAG, "reset failed, releasing", e);
                    releaseMediaPlayer();
                }
            }
            mIsPlaying = false;
        }
    }

    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.release(); } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }

    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (mIsPreparing.get()) return;
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        final Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        try {
            synchronized (mPlayerLock) {
                if (mMediaPlayer == null) mMediaPlayer = new MediaPlayer();
                else {
                    removeAllListeners(mMediaPlayer);
                    try { mMediaPlayer.reset(); } catch (IllegalStateException e) {
                        mMediaPlayer.release();
                        mMediaPlayer = new MediaPlayer();
                    }
                }
                mMediaPlayer.setDataSource(song.getPath());
                mIsPreparing.set(true);
                mCurrentIndex = index;
                mMediaPlayer.setOnPreparedListener(mp -> {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId || mMediaPlayer != mp) return;
                        mIsPreparing.set(false);
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) return;
                            if (seekPosition > 0 && seekPosition < duration - 500) mp.seekTo(seekPosition);
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = SystemClock.elapsedRealtime();
                            startHealthMonitoring();
                            if (mWakeLock != null && !mWakeLock.isHeld()) mWakeLock.acquire();
                            savePlayingState();
                            broadcastUpdate();
                            createNotification();
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            // Notify equalizer
                            Intent sessionIntent = new Intent("com.ark.llama.AUDIO_SESSION_CHANGED");
                            sessionIntent.putExtra("audio_session_id", sCurrentAudioSessionId);
                            sendBroadcast(sessionIntent);
                        } catch (Exception e) { Log.e(TAG, "onPrepared error", e); }
                    }
                });
                mMediaPlayer.setOnCompletionListener(mp -> handleCompletion());
                mMediaPlayer.setOnErrorListener((mp, what, extra) -> {
                    Log.e(TAG, "MediaPlayer error: " + what + "," + extra);
                    mIsPlaying = false;
                    mIsPreparing.set(false);
                    return true;
                });
                mMediaPlayer.prepareAsync();
            }
        } catch (IOException e) {
            Log.e(TAG, "prepareAndPlay error", e);
            mIsPreparing.set(false);
        }
    }

    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        final Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        try {
            synchronized (mPlayerLock) {
                if (mMediaPlayer == null) mMediaPlayer = new MediaPlayer();
                else {
                    removeAllListeners(mMediaPlayer);
                    try { mMediaPlayer.reset(); } catch (IllegalStateException e) {
                        mMediaPlayer.release();
                        mMediaPlayer = new MediaPlayer();
                    }
                }
                mMediaPlayer.setDataSource(song.getPath());
                mIsPreparing.set(true);
                mMediaPlayer.setOnPreparedListener(mp -> {
                    if (mCurrentPrepId != myPrepId) return;
                    mIsPreparing.set(false);
                    sCurrentAudioSessionId = mp.getAudioSessionId();
                });
                mMediaPlayer.prepareAsync();
            }
        } catch (IOException e) {
            Log.e(TAG, "prepareOnly error", e);
            mIsPreparing.set(false);
        }
    }

    private void handleCompletion() {
        if (mCurrentPlaylist == null) { mIsPlaying = false; return; }
        if (mRepeatMode == 2) { seekTo(0); if (!mIsPlaying) resume(); }
        else if (mRepeatMode == 1 || mCurrentIndex + 1 < mCurrentPlaylist.size()) { playNext(); }
        else {
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mMediaPlayer != null) {
                try { mMediaPlayer.pause(); mMediaPlayer.seekTo(0); } catch (Exception ignored) {}
            }
            savePlayingState();
            broadcastUpdate();
            createNotification();
        }
    }

    // Health monitoring
    private void startHealthMonitoring() {
        if (mHealthHandler == null) return;
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = SystemClock.elapsedRealtime();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mIsPlaying) return;
                int pos = getCurrentPosition();
                long elapsed = SystemClock.elapsedRealtime() - mPlaybackStartTime;
                if (pos < 100 && elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected");
                    if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
                        mRecoveryAttempts = 0;
                        playNext();
                    } else {
                        mRecoveryAttempts++;
                        stopHealthMonitoring();
                        releaseMediaPlayer();
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            if (mCurrentIndex >= 0 && mCurrentPlaylist != null && mCurrentIndex < mCurrentPlaylist.size())
                                prepareAndPlay(mCurrentIndex, getCurrentPosition());
                        }, 500);
                    }
                } else if (pos > 100) {
                    mPlaybackStartTime = SystemClock.elapsedRealtime();
                }
                if (mIsPlaying && mHealthHandler != null)
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
    }

    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }

    // State persistence
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }

    private void saveFullState() { savePlayerState(); }

    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_CURRENT_INDEX, mCurrentIndex).putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null).apply();
    }

    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).putInt(KEY_CURRENT_POSITION, getCurrentPosition()).apply();
    }

    private boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }

    private int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }

    private String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }

    // Sort mode
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return (a,b) -> a.getTitle().compareToIgnoreCase(b.getTitle());
            case SORT_TITLE_ZA: return (a,b) -> b.getTitle().compareToIgnoreCase(a.getTitle());
            case SORT_ARTIST_AZ:
                return (a,b) -> { int cmp = a.getArtist().compareToIgnoreCase(b.getArtist()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_ARTIST_ZA:
                return (a,b) -> { int cmp = b.getArtist().compareToIgnoreCase(a.getArtist()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_ALBUM_AZ:
                return (a,b) -> { int cmp = a.getAlbum().compareToIgnoreCase(b.getAlbum()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_ALBUM_ZA:
                return (a,b) -> { int cmp = b.getAlbum().compareToIgnoreCase(a.getAlbum()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_GENRE_AZ:
                return (a,b) -> { int cmp = a.getGenre().compareToIgnoreCase(b.getGenre()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_GENRE_ZA:
                return (a,b) -> { int cmp = b.getGenre().compareToIgnoreCase(a.getGenre()); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_OLDEST:
                return (a,b) -> { long da = new File(a.getPath()).lastModified(), db = new File(b.getPath()).lastModified(); int cmp = Long.compare(da, db); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            case SORT_NEWEST:
                return (a,b) -> { long da = new File(a.getPath()).lastModified(), db = new File(b.getPath()).lastModified(); int cmp = Long.compare(db, da); return cmp == 0 ? a.getTitle().compareToIgnoreCase(b.getTitle()) : cmp; };
            default: return (a,b) -> a.getTitle().compareToIgnoreCase(b.getTitle());
        }
    }

    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newMode) {
                        mCurrentSortMode = newMode;
                        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
                            broadcastPlaylistChanged();
                        }
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    // Broadcast helpers
    private void broadcastPlaylistChanged() {
        sendBroadcast(new Intent(ACTION_PLAYLIST_CHANGED));
    }

    private void broadcastUpdate() {
        sendBroadcast(new Intent("UPDATE_PLAYER"));
    }

    private void createNotification() {
        if (mNotificationService == null) return;
        Song song = getCurrentSong();
        if (song != null) mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
        else mNotificationService.updateSongInfo(null, null, null);
        mNotificationService.setPlayingState(mIsPlaying);
    }

    // Audio focus and MediaSession
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                if (mIsPlaying) pause();
            }
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setOnAudioFocusChangeListener(mAudioFocusListener).setAudioAttributes(attrs).build();
        }
    }

    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { if (mAudioFocusRequest != null && mAudioManager != null) mAudioManager.requestAudioFocus(mAudioFocusRequest); }
        else if (mAudioManager != null && mAudioFocusListener != null) mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
    }

    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { if (mAudioFocusRequest != null && mAudioManager != null) mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest); }
        else if (mAudioManager != null && mAudioFocusListener != null) mAudioManager.abandonAudioFocus(mAudioFocusListener);
    }

    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mMediaSession = new MediaSession(this, "LlamaMusicService");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() { togglePlayPause(); }
                @Override public void onPause() { pause(); }
                @Override public void onSkipToNext() { playNext(); }
                @Override public void onSkipToPrevious() { playPrevious(); }
                @Override public void onStop() { pause(); }
            });
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        }
    }

    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        PlaybackState.Builder builder = new PlaybackState.Builder();
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
        int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        builder.setState(state, getCurrentPosition(), 1.0f);
        builder.setActions(actions);
        mMediaSession.setPlaybackState(builder.build());
        Song song = getCurrentSong();
        if (song != null) {
            android.media.MediaMetadata.Builder meta = new android.media.MediaMetadata.Builder();
            meta.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, song.getTitle());
            meta.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, song.getArtist());
            meta.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, song.getAlbum());
            mMediaSession.setMetadata(meta.build());
        }
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private boolean acquireTransitionLock() { return mIsTransitioning.compareAndSet(false, true); }
    private void releaseTransitionLock() { mIsTransitioning.set(false); }
    private void invalidateAllPreparations() { mCurrentPrepId = mGlobalPrepId.incrementAndGet(); }
}