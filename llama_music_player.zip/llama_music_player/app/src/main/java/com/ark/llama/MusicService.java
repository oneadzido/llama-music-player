package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with LlamaMediaPlayer.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>LlamaMediaPlayer-Based Playback</b> - Uses the custom LlamaMediaPlayer
 *       wrapper which provides a complete state machine, position polling,
 *       audio focus handling, and comprehensive error recovery</li>
 *   <li><b>Full MediaSession Integration</b> - Complete lock screen controls with
 *       metadata, album art, and playback state</li>
 *   <li><b>Playlist Management</b> - Supports shuffle, repeat modes, and 10 sort modes</li>
 *   <li><b>Playback Persistence</b> - Saves position, playing state, and current song</li>
 *   <li><b>Health Monitoring</b> - Detects and recovers from playback stalls</li>
 *   <li><b>Audio Focus Management</b> - Proper ducking and interruption handling</li>
 *   <li><b>WakeLock Management</b> - Prevents device sleep during playback</li>
 *   <li><b>Broadcast Integration</b> - Communicates with UI components via Intents</li>
 *   <li><b>Equalizer Support</b> - Integrates with EqualizerManager for audio effects</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>LlamaMediaPlayer's internal locks</b> - Delegates thread safety to the custom player</li>
 *   <li><b>AtomicBoolean</b> - For transition flags</li>
 *   <li><b>volatile</b> - For frequently-read playback state variables</li>
 *   <li><b>Synchronized blocks</b> - For playlist modifications</li>
 * </ul>
 * 
 * <h3>MediaSession Lock Screen Integration</h3>
 * <p>The service provides full lock screen controls including:</p>
 * <ul>
 *   <li>Play/Pause/Next/Previous buttons</li>
 *   <li>Song title, artist, album display</li>
 *   <li>Album art image</li>
 *   <li>Seek bar (when supported by device)</li>
 *   <li>Voice command support ("Play [song name]")</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service implements LlamaMediaPlayer.NativePlayerListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state (true = playing, false = paused). */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state (true = on, false = off). */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state flag before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode from PlaylistActivity. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Intent extra key for sort mode value. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Broadcast action for audio session ID changes (for equalizer attachment). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Delay for song transitions in milliseconds (allows smooth crossfade). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    // ========================================================================
    // Sort Mode Constants (10 modes for playlist ordering)
    // ========================================================================
    
    /** Sort by title A-Z (ascending alphabetical). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort by title Z-A (descending alphabetical). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort by artist name A-Z, then by title. */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort by artist name Z-A, then by title. */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort by album name A-Z, then by title. */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort by album name Z-A, then by title. */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort by genre A-Z, then by title. */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort by genre Z-A, then by title. */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort by file modification date (oldest first), then by title. */
    private static final int SORT_OLDEST = 8;
    
    /** Sort by file modification date (newest first), then by title. */
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment (static for cross-component access). */
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // LlamaMediaPlayer Members
    // ========================================================================
    
    /**
     * Custom LlamaMediaPlayer instance that provides:
     * - Complete state machine (IDLE -> INITIALIZED -> PREPARING -> PREPARED -> STARTED/PAUSED -> COMPLETED)
     * - Built-in position polling (150ms intervals for UI updates)
     * - Audio session ID management for equalizer attachment
     * - Volume control with ducking support
     * - Thread safety with internal state lock
     * - Comprehensive error handling with callbacks
     * - Playback parameters (pitch/speed) on API 23+
     */
    @Nullable
    private LlamaMediaPlayer mLlamaPlayer;
    
    // ========================================================================
    // Album Art Cache
    // ========================================================================
    
    /** LRU cache for album art bitmaps to avoid repeated decoding. */
    private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** File path of the album art currently being displayed. */
    private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Playback State (volatile for thread-safe reads)
    // ========================================================================
    
    /** Current playlist of Song objects. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song in the playlist (-1 = none). */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active (read from LlamaPlayer). */
    private volatile boolean mIsPlaying = false;
    
    /** Flag indicating if player is prepared (read from LlamaPlayer). */
    private volatile boolean mIsPrepared = false;
    
    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Current sort mode for playlist display (default: Title A-Z). */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    /** WakeLock to prevent device from sleeping during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    /** Audio manager for requesting and abandoning audio focus. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes (phone calls, other apps). */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O+ (API 26+). */
    private AudioFocusRequest mAudioFocusRequest;
    
    /** Flag indicating if we have audio focus. */
    private boolean mHasAudioFocus = false;
    
    /** Flag indicating if we should duck volume on focus loss. */
    private boolean mShouldDuck = false;
    
    // ========================================================================
    // Media Session (Lock Screen Controls)
    // ========================================================================
    
    /** MediaSession for lock screen controls and Bluetooth headset integration. */
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    /** Flag indicating if a Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    /** Flag indicating if a song transition is in progress (prevents concurrent transitions). */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    // ========================================================================
    // Binder for Activity Binding
    // ========================================================================
    
    /** Binder instance that allows activities to obtain a reference to this service. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    /** History of shuffled indices (for prev/next navigation in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft update (used during folder sync). */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    /** Service for managing the media notification. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for sync state updates (affects notification appearance). */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates (pitch/speed from equalizer). */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clearing the playlist. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes (updates notification colors). */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for requests to get the current playing state. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates from PlaylistActivity. */
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * Allows activities to obtain a direct reference to the service instance.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes (Java 7 compatible - no lambdas)
    // ========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z (ascending alphabetical).
     * Null titles are treated as empty strings.
     */
    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A (descending alphabetical).
     */
    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title for ties.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title for ties.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title for ties.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title for ties.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title for ties.
     */
    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title for ties.
     */
    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (oldest first), then by title for ties.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (newest first), then by title for ties.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    /**
     * Sets the player state before update flag.
     * Used to preserve playback state during folder updates.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID for equalizer attachment.
     *
     * @return The current audio session ID (0 if none)
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * Initializes all components including LlamaMediaPlayer, MediaSession, audio focus, and notification.
     * This method runs on the main thread.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        // Initialize album art cache with size limit
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager for focus management
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup MediaSession for lock screen controls
        setupMediaSession();
        
        // Initialize EqualizerManager singleton
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        // Setup audio focus handling
        setupAudioFocus();
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize LlamaMediaPlayer (custom playback engine)
        initializeLlamaPlayer();
        
        // Register all broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Initializes the custom LlamaMediaPlayer instance.
     * Sets up the listener for all player callbacks including state changes,
     * position updates, error handling, and audio session availability.
     */
    private void initializeLlamaPlayer() {
        mLlamaPlayer = new LlamaMediaPlayer(this);
        mLlamaPlayer.setListener(this);
        Log.d(TAG, "LlamaMediaPlayer initialized");
    }
    
    /**
     * Called when the service is started via startService().
     * Handles media button actions from the notification.
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "ACTION_PLAY_PAUSE":
                    togglePlayPause();
                    break;
                case "ACTION_NEXT":
                    playNext();
                    break;
                case "ACTION_PREV":
                    playPrevious();
                    break;
                case "ACTION_CLOSE":
                    handleCloseAction();
                    break;
                case "ACTION_STOP":
                    stopCompletely();
                    break;
                case "ACTION_STOP_NOTIFICATION":
                    if (mNotificationService != null) {
                        mNotificationService.stopForeground();
                    }
                    break;
                case "PLAY_SONG":
                    String songPath = intent.getStringExtra("song_path");
                    if (songPath != null) {
                        playSongByPath(songPath);
                    } else {
                        int position = intent.getIntExtra("position", -1);
                        if (position >= 0) {
                            playSong(position);
                        }
                    }
                    break;
                case "UPDATE_PLAYBACK_PARAMS":
                    updatePlaybackParams();
                    break;
                default:
                    break;
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and saves playback state.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        // Save state before destroying
        saveFullState();
        savePlayerState();
        
        // Release WakeLock if held
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        
        // Release LlamaMediaPlayer
        if (mLlamaPlayer != null) {
            mLlamaPlayer.release();
            mLlamaPlayer = null;
        }
        
        // Clean up notification service
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        // Release MediaSession
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Unregister all broadcast receivers
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     * Forwards to LlamaMediaPlayer for cache cleanup.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE && mLlamaPlayer != null) {
            // LlamaMediaPlayer handles its own cleanup
            Log.d(TAG, "onTrimMemory: " + level);
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     * Saves state before the service is potentially destroyed.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // LlamaMediaPlayer.NativePlayerListener Callbacks
    // ========================================================================
    
    /**
     * Called when LlamaMediaPlayer is prepared and ready for playback.
     * Updates state flags, saves position, and refreshes notification.
     */
    @Override
    public void onPrepared() {
        synchronized (this) {
            mIsPrepared = true;
            mIsPlaying = false;
            
            // Update PlaybackController
            PlaybackController.getInstance().setPrepared(true, "MusicService.onPrepared");
            
            // Save current playing index
            saveCurrentPlayingIndex();
            
            Log.d(TAG, "LlamaPlayer prepared - duration: " + getDuration() + "ms, session: " + sCurrentAudioSessionId);
            
            // Update MediaSession metadata
            updateMediaSessionMetadata();
            createNotification();
        }
    }
    
    /**
     * Called when playback completes (end of stream reached).
     * Handles repeat modes and playlist advancement.
     */
    @Override
    public void onCompletion() {
        Log.d(TAG, "onCompletion - end of stream reached");
        
        // Update PlaybackController
        PlaybackController.getInstance().setPlaying(false, "MusicService.onCompletion");
        PlaybackController.getInstance().updatePosition(0, "MusicService.onCompletion");
        
        // Broadcast completion to UI
        Intent completionIntent = new Intent("UPDATE_PLAYER");
        completionIntent.putExtra("song_completed", true);
        completionIntent.putExtra("completed_position", getDuration());
        sendBroadcast(completionIntent);
        
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "onCompletion: playlist is null");
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        // Handle repeat modes
        if (mRepeatMode == 2) {
            // Repeat one: play the same song again
            playSong(mCurrentIndex, true);
        } else if (mRepeatMode == 1) {
            // Repeat all: play next song, wrap around at end
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            // Normal mode, not at end
            playNext();
        } else {
            // End of playlist reached, stop playback
            mIsPlaying = false;
            
            // Update PlaybackController
            PlaybackController.getInstance().setPlaying(false, "MusicService.onCompletion.end");
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            // Save state
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            
            // Broadcast updates
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            updateMediaSessionMetadata();
            createNotification();
        }
    }
    
    /**
     * Called when LlamaMediaPlayer encounters an error.
     * Attempts recovery or falls back to next song.
     *
     * @param what The primary error code
     * @param extra Extra error code
     * @param message Human-readable error message
     */
    @Override
    public void onError(int what, int extra, @NonNull String message) {
        Log.e(TAG, "LlamaPlayer error: what=" + what + ", extra=" + extra + ", message=" + message);
        
        // Update PlaybackController
        PlaybackController.getInstance().setPrepared(false, "MusicService.onError");
        PlaybackController.getInstance().setPlaying(false, "MusicService.onError");
        PlaybackController.getInstance().notifyOperationFailed("playback", message);
        
        mIsPrepared = false;
        mIsPlaying = false;
        
        createNotification();
        broadcastUpdate();
        
        // Attempt recovery by playing next song
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "Attempting recovery - playing next song");
            playNext();
        }
    }
    
    /**
     * Called periodically with position updates from LlamaMediaPlayer (every 150ms).
     * Updates PlaybackController and broadcasts to UI.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Total duration in milliseconds
     */
    @Override
    public void onPositionUpdate(int positionMs, int durationMs) {
        // Update PlaybackController (single source of truth)
        PlaybackController.getInstance().updatePosition(positionMs, "MusicService.onPositionUpdate");
        PlaybackController.getInstance().setDuration(durationMs, "MusicService.onPositionUpdate");
        
        // Broadcast to UI for seek bar updates
        Intent updateIntent = new Intent("UPDATE_PLAYER");
        updateIntent.putExtra("position", positionMs);
        updateIntent.putExtra("duration", durationMs);
        sendBroadcast(updateIntent);
    }
    
    /**
     * Called when LlamaMediaPlayer state changes.
     * Updates internal state flags and PlaybackController.
     *
     * @param newState The new state
     * @param oldState The previous state
     */
    @Override
    public void onStateChanged(@NonNull LlamaMediaPlayer.State newState, @Nullable LlamaMediaPlayer.State oldState) {
        Log.d(TAG, "State changed: " + oldState + " -> " + newState);
        
        switch (newState) {
            case PREPARED:
                mIsPrepared = true;
                PlaybackController.getInstance().setPrepared(true, "MusicService.onStateChanged.PREPARED");
                break;
            case STARTED:
                mIsPlaying = true;
                PlaybackController.getInstance().setPlaying(true, "MusicService.onStateChanged.STARTED");
                break;
            case PAUSED:
                mIsPlaying = false;
                PlaybackController.getInstance().setPlaying(false, "MusicService.onStateChanged.PAUSED");
                break;
            case COMPLETED:
                mIsPlaying = false;
                PlaybackController.getInstance().setPlaying(false, "MusicService.onStateChanged.COMPLETED");
                break;
            case STOPPED:
                mIsPrepared = false;
                mIsPlaying = false;
                PlaybackController.getInstance().setPrepared(false, "MusicService.onStateChanged.STOPPED");
                PlaybackController.getInstance().setPlaying(false, "MusicService.onStateChanged.STOPPED");
                break;
            case ERROR:
                mIsPrepared = false;
                mIsPlaying = false;
                PlaybackController.getInstance().setPrepared(false, "MusicService.onStateChanged.ERROR");
                PlaybackController.getInstance().setPlaying(false, "MusicService.onStateChanged.ERROR");
                break;
            default:
                break;
        }
        
        // Update notification and broadcast        createNotification();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Called when audio session ID is available from LlamaMediaPlayer.
     * Critical for equalizer to attach to the correct audio session.
     *
     * @param sessionId The audio session ID from MediaPlayer
     */
    @Override
    public void onAudioSessionIdAvailable(int sessionId) {
        Log.d(TAG, "Audio session ID available: " + sessionId);
        sCurrentAudioSessionId = sessionId;
        
        // Broadcast to equalizer
        broadcastAudioSessionChanged(sessionId);
        
        // Attach equalizer
        EqualizerManager.getInstance(this).attachToAudioSession(sessionId);
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * Default is SORT_TITLE_AZ (Title A-Z).
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     * All comparators use secondary sorting by Title (A-Z) when primary keys match.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     * This is a reliable method that works across all Android versions.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     * Preserves the currently playing song's position.
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        // Save current song path to find it after sorting
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        // Apply sorting
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        // Restore current index by finding the song in the sorted list
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                Log.d(TAG, "Current song repositioned to index: " + newIndex);
            }
        }
        
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers the notification receiver for sync state updates.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver for equalizer updates.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    /**
     * Registers the clear playlist receiver.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    /**
     * Registers the theme color change receiver for notification colors.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the receiver for requests to get the playing state.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    /**
     * Registers the sort mode update receiver from PlaylistActivity.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Sets the current playlist.
     * Uses LlamaMediaPlayer's reset() to clear state before loading new playlist.
     *
     * @param playlist The new playlist
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (this) {
            // Save current position and playing state
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                    try {
                        currentPosition = mLlamaPlayer.getCurrentPosition();
                        wasPlaying = mLlamaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            
            // Handle empty playlist
            if (playlist == null || playlist.isEmpty()) {
                if (mLlamaPlayer != null) {
                    mLlamaPlayer.reset();
                }
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                mIsPlaying = false;
                mIsPrepared = false;
                
                // Update PlaybackController
                PlaybackController.getInstance().reset();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                updateMediaSessionMetadata();
                return;
            }
            
            // Sort the new playlist according to current sort mode
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // Force player reset when not preserving current song
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                if (mLlamaPlayer != null) {
                    mLlamaPlayer.reset();
                }
                mIsPlaying = false;
                mIsPrepared = false;
            }
            
            // Find the current song in the new playlist
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            // Determine if we need to reset the player
            boolean currentSongPositionChanged = (newIndex != -1 && newIndex != mCurrentIndex);
            boolean playlistStructureChanged = (mCurrentPlaylist != null && 
                                               mCurrentPlaylist.size() != sortedPlaylist.size());
            
            boolean currentSongChanged = false;
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                String oldPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                if (newIndex >= 0 && newIndex < sortedPlaylist.size()) {
                    String newPath = sortedPlaylist.get(newIndex).getPath();
                    currentSongChanged = !oldPath.equals(newPath);
                }
            }
            
            boolean needsReset = currentSongPositionChanged || playlistStructureChanged || currentSongChanged;
            
            if (needsReset && preserveCurrentSong && mLlamaPlayer != null) {
                Log.d(TAG, "Playlist/song changed, resetting player");
                mLlamaPlayer.reset();
            }
            
            // Replace the playlist
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            // Set the current index
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex = 0;
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                mCurrentIndex = -1;
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            
            saveCurrentPlayingIndex();
            
            // Resume playback if needed
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (needsReset) {
                    if (isFolderUpdate) {
                        int correctIndex = mCurrentIndex;
                        String savedPath = getSavedSongPath();
                        if (savedPath != null) {
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                    correctIndex = i;
                                    break;
                                }
                            }
                        }
                        prepareAndPlay(correctIndex, savedPosition);
                        clearPlayerStateBeforeUpdate(this);
                    } else {
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                } else if (!mIsPlaying) {
                    Log.d(TAG, "Same song, resuming playback without reset");
                    resume();
                }
                
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0 && needsReset) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            } else if (!preserveCurrentSong) {
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        synchronized (this) {
            mIsTransitioning.set(false);
            
            if (mLlamaPlayer != null) {
                mLlamaPlayer.reset();
                mLlamaPlayer.release();
                mLlamaPlayer = null;
                initializeLlamaPlayer();
            }
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on stop");
            }
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            mCurrentAlbumArtPath = null;
            mIsPlaying = false;
            mIsPrepared = false;
            
            // Reset PlaybackController
            PlaybackController.getInstance().reset();
            
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) {
                mNotificationService.stopForeground();
            }
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        // Clear MediaSession metadata
        updateMediaSessionMetadata();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist (preserves current song and position).
     *
     * @param newPlaylist The new playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The song index in the playlist
     */
    public synchronized void playSong(int index) {
        playSong(index, false);
    }
    
    /**
     * Plays a song at the specified index with force preparation.
     *
     * @param index The song index in the playlist
     * @param forcePrepare True to force preparation even if index is current
     */
    public synchronized void playSong(int index, boolean forcePrepare) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // Check if we're already playing this song and not forcing prepare
        if (!forcePrepare && index == mCurrentIndex && mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            resume();
            return;
        }
        
        prepareAndPlay(index, 0);
    }
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     * Delegates to LlamaMediaPlayer for all playback operations.
     *
     * @param index The song index
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size() || mLlamaPlayer == null) {
            return;
        }
        
        try {
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            // Reset player for new song
            mLlamaPlayer.reset();
            
            // Set data source
            mLlamaPlayer.setDataSource(song.getPath());
            
            // Prepare asynchronously (LlamaMediaPlayer handles the background thread)
            mLlamaPlayer.prepareAsync();
            
            // Update state
            mCurrentIndex = index;
            mCurrentAlbumArtPath = song.getPath();
            
            // Save state
            saveCurrentPlayingIndex();
            
            // If seek position provided, seek after preparation
            if (seekPosition > 0) {
                final int finalSeek = seekPosition;
                final int finalIndex = index;
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                            mLlamaPlayer.seekTo(finalSeek);
                        }
                    }
                }, 100);
            }
            
            Log.d(TAG, "prepareAndPlay: " + song.getTitle() + " at index " + index);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare player", e);
        }
    }
    
    /**
     * Prepares a song without starting playback.
     * Used for pre-loading the next song or when preserving current song.
     *
     * @param index The song index to prepare
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size() || mLlamaPlayer == null) {
            return;
        }
        
        try {
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            // Reset and prepare
            mLlamaPlayer.reset();
            mLlamaPlayer.setDataSource(song.getPath());
            mLlamaPlayer.prepareAsync();
            
            mCurrentIndex = index;
            mCurrentAlbumArtPath = song.getPath();
            
            Log.d(TAG, "prepareOnly: " + song.getTitle() + " at index " + index);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare player", e);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size() || mLlamaPlayer == null) {
            return;
        }
        prepareAndPlay(index, position);
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     * Searches the playlist for a song with matching path.
     *
     * @param filePath The file path of the song
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     * Handles repeat modes and shuffle properly.
     */
    public synchronized void playNext() {
        if (!mIsTransitioning.compareAndSet(false, true)) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            // Check for pending playlist update
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    mIsTransitioning.set(false);
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * Handles repeat modes and shuffle properly.
     */
    public synchronized void playPrevious() {
        if (!mIsTransitioning.compareAndSet(false, true)) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            // Check for pending playlist update
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    mIsTransitioning.set(false);
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause.
     */
    public void togglePlayPause() {
        if (mLlamaPlayer != null && mCurrentIndex >= 0) {
            if (mIsPlaying) {
                pause();
            } else {
                resume();
            }
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
            playSong(0);
        }
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        if (mLlamaPlayer != null && mIsPlaying && mLlamaPlayer.isPrepared()) {
            try {
                mLlamaPlayer.pause();
                mIsPlaying = false;
                
                // Update PlaybackController
                PlaybackController.getInstance().setPlaying(false, "MusicService.pause");
                PlaybackController.getInstance().onPause();
                
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on pause");
                }
                
                savePlayingState();
                savePlayerState();
                saveFullState();
                updateMediaSessionPlaybackState();
                broadcastUpdate();
                createNotification();
            } catch (Exception e) {
                Log.e(TAG, "Cannot pause - invalid state", e);
            }
        }
    }
    
    /**
     * Resumes playback from paused state.
     */
    public void resume() {
        if (mLlamaPlayer != null && mCurrentIndex >= 0 && mLlamaPlayer.isPrepared()) {
            try {
                if (!mIsPlaying) {
                    requestAudioFocus();
                    updatePlaybackParams();
                    mLlamaPlayer.start();
                    mIsPlaying = true;
                    
                    // Update PlaybackController
                    PlaybackController.getInstance().setPlaying(true, "MusicService.resume");
                    PlaybackController.getInstance().onResume();
                    
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                        Log.d(TAG, "WakeLock acquired on resume");
                    }
                    
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    updateMediaSessionPlaybackState();
                    broadcastUpdate();
                    createNotification();
                }
            } catch (Exception e) {
                Log.e(TAG, "Resume failed - invalid state", e);
                mIsPlaying = false;
                broadcastUpdate();
            }
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
            playSong(0);
        }
    }
    
    /**
     * Stops playback and resets the player.
     */
    public void stop() {
        if (mLlamaPlayer != null && mIsPlaying && mLlamaPlayer.isPrepared()) {
            try {
                mLlamaPlayer.stop();
                mIsPlaying = false;
            } catch (Exception e) {
                Log.e(TAG, "Cannot stop - invalid state", e);
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            try {
                int duration = mLlamaPlayer.getDuration();
                if (position >= 0 && position < duration) {
                    mLlamaPlayer.seekTo(position);
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    savePlayerState();
                    saveFullState();
                }
            } catch (Exception e) {
                Log.e(TAG, "Cannot seek - invalid state", e);
            }
        }
    }
    
    // ========================================================================
    // Playback Parameter Methods (Pitch and Speed)
    // ========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     * Called when the user adjusts pitch or speed in the equalizer.
     * Delegates to LlamaMediaPlayer.setPlaybackParams().
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                mLlamaPlayer.setPlaybackParams(tempo, pitch);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
                
                // Update MediaSession with new playback speed
                updateMediaSessionPlaybackState();
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        if (mLlamaPlayer != null && mCurrentIndex >= 0 && mLlamaPlayer.isPrepared()) {
            try {
                return mLlamaPlayer.getCurrentPosition();
            } catch (Exception e) {
                return 0;
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        if (mLlamaPlayer != null && mCurrentIndex >= 0 && mLlamaPlayer.isPrepared()) {
            try {
                return mLlamaPlayer.getDuration();
            } catch (Exception e) {
                return 0;
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying;
    }
    
    /**
     * Checks if any player (LlamaMediaPlayer) is playing.
     *
     * @return True if playing
     */
    public boolean isAnyPlayerPlaying() {
        return mIsPlaying;
    }
    
    /**
     * Checks if any player is prepared.
     *
     * @return True if prepared
     */
    public boolean isAnyPlayerPrepared() {
        return mIsPrepared;
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
        updateMediaSessionMetadata();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state for media button handling.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // Media Session Methods (Complete Lock Screen Integration)
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls and Bluetooth integration.
     * This provides:
     * <ul>
     *   <li>Lock screen playback controls (play/pause/next/previous)</li>
     *   <li>Song metadata display (title, artist, album)</li>
     *   <li>Album art display</li>
     *   <li>Voice command support ("Play [song name]")</li>
     *   <li>Seek bar on supported devices</li>
     * </ul>
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                // Create MediaSession with a unique tag
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setActive(true);
                
                // Set flags for media buttons and transport controls
                mMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | 
                                       MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
                
                // Set callback for all media button events
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        Log.d(TAG, "MediaSession: onPlay");
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        Log.d(TAG, "MediaSession: onPause");
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        Log.d(TAG, "MediaSession: onSkipToNext");
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        Log.d(TAG, "MediaSession: onSkipToPrevious");
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        Log.d(TAG, "MediaSession: onStop");
                        pause();
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        Log.d(TAG, "MediaSession: onSeekTo " + pos + "ms");
                        seekTo((int) pos);
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        Log.d(TAG, "MediaSession: onPlayFromMediaId " + mediaId);
                        if (mediaId != null) {
                            try {
                                int index = Integer.parseInt(mediaId);
                                if (index >= 0 && mCurrentPlaylist != null && 
                                    index < mCurrentPlaylist.size()) {
                                    playSong(index);
                                }
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                    
                    @Override
                    public void onPlayFromSearch(String query, Bundle extras) {
                        Log.d(TAG, "MediaSession: onPlayFromSearch " + query);
                        // Search for the first song matching the query
                        if (mCurrentPlaylist != null && query != null && !query.isEmpty()) {
                            String lowerQuery = query.toLowerCase();
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                Song song = mCurrentPlaylist.get(i);
                                if (song != null) {
                                    String title = song.getTitle();
                                    String artist = song.getArtist();
                                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                                        (artist != null && artist.toLowerCase().contains(lowerQuery))) {
                                        playSong(i);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                });
                
                // Indicate this is a local playback session (not casting)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                    mMediaSession.setPlaybackToLocal(audioAttributes);
                }
                
                // Set initial playback state
                updateMediaSessionPlaybackState();
                
                // Set initial metadata (will be updated when song loads)
                updateMediaSessionMetadata();
                
                // Set the session activity intent
                Intent intent = new Intent(this, MusicPlayer.class);
                intent.setAction(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    flags |= PendingIntent.FLAG_IMMUTABLE;
                }
                PendingIntent pi = PendingIntent.getActivity(this, 0, intent, flags);
                mMediaSession.setSessionActivity(pi);
                
                Log.d(TAG, "MediaSession fully initialized and active");
                
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Updates MediaSession with current song metadata (title, artist, album, album art).
     * This ensures lock screen shows correct song information.
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            Log.d(TAG, "MediaSession metadata cleared - no current song");
            return;
        }
        
        android.media.MediaMetadata.Builder metadataBuilder = new android.media.MediaMetadata.Builder()
            .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title")
            .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist")
            .putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album")
            .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration())
            .putLong(android.media.MediaMetadata.METADATA_KEY_TRACK_NUMBER, mCurrentIndex + 1);
        
        if (mCurrentPlaylist != null) {
            metadataBuilder.putLong(android.media.MediaMetadata.METADATA_KEY_NUM_TRACKS, mCurrentPlaylist.size());
        }
        
        // Add album art if available in cache
        if (mCurrentAlbumArtPath != null && mAlbumArtCache != null) {
            Bitmap albumArt = mAlbumArtCache.get(mCurrentAlbumArtPath);
            if (albumArt != null && !albumArt.isRecycled()) {
                metadataBuilder.putBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART, albumArt);
                Log.d(TAG, "MediaSession metadata: album art added for " + currentSong.getTitle());
            }
        }
        
        mMediaSession.setMetadata(metadataBuilder.build());
        Log.d(TAG, "MediaSession metadata updated: " + currentSong.getTitle() + " - " + currentSong.getArtist());
    }
    
    /**
     * Updates MediaSession playback state (playing/paused, position, speed).
     * This ensures lock screen controls show correct state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        try {
            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
            
            long actions = PlaybackState.ACTION_PLAY | 
                          PlaybackState.ACTION_PAUSE |
                          PlaybackState.ACTION_SKIP_TO_NEXT | 
                          PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                          PlaybackState.ACTION_STOP |
                          PlaybackState.ACTION_SEEK_TO |
                          PlaybackState.ACTION_PLAY_PAUSE;
            
            int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
            long position = getCurrentPosition();
            float playbackSpeed = 1.0f;
            
            // Get current speed from EqualizerManager
            EqualizerManager eq = EqualizerManager.getInstance(this);
            int speedLevel = eq.getSpeed();
            playbackSpeed = 0.5f + (speedLevel / 2000.0f);
            
            stateBuilder.setState(state, position, playbackSpeed);
            stateBuilder.setActions(actions);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                stateBuilder.setActiveQueueItemId(mCurrentIndex);
            }
            
            mMediaSession.setPlaybackState(stateBuilder.build());
            Log.d(TAG, "MediaSession playback state: " + (mIsPlaying ? "PLAYING" : "PAUSED") + 
                  " at " + position + "ms, speed=" + playbackSpeed);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSession state", e);
        }
    }
    
    /**
     * Updates MediaSession album art when it changes.
     * Called from DisplayManager when album art is loaded.
     *
     * @param albumArt The album art bitmap, or null to remove
     * @param artPath The file path of the album art for cache lookup
     */
    public void updateMediaSessionAlbumArt(@Nullable Bitmap albumArt, @Nullable String artPath) {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }
        
        // Cache the album art if provided
        if (albumArt != null && !albumArt.isRecycled() && artPath != null && mAlbumArtCache != null) {
            mAlbumArtCache.put(artPath, albumArt);
            mCurrentAlbumArtPath = artPath;
        }
        
        // Update metadata with new album art
        updateMediaSessionMetadata();
        Log.d(TAG, "MediaSession album art updated");
    }
    
    /**
     * Returns the MediaSession token for use with MediaBrowser/MediaController.
     *
     * @return MediaSession token, or null if not available
     */
    @Nullable
    public MediaSession.Token getMediaSessionToken() {
        if (mMediaSession != null) {
            return mMediaSession.getSessionToken();
        }
        return null;
    }
    
    /**
     * Checks if MediaSession is active and ready.
     *
     * @return True if MediaSession is active
     */
    public boolean isMediaSessionActive() {
        return mMediaSession != null && mMediaSession.isActive();
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates and updates the media notification.
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    /**
     * Refreshes the notification (called after sync state changes).
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     * Called from DisplayManager when album art is loaded.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            if (art != null && !art.isRecycled()) safeArt = art;
            if (placeholder != null && !placeholder.isRecycled()) safePlaceholder = placeholder;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
            
            // Also update MediaSession album art
            updateMediaSessionAlbumArt(safeArt, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     * Called periodically and on service destroy.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state (same as savePlayerState).
     */
    private void saveFullState() {
        savePlayerState();
    }
    
    /**
     * Gets the saved playback position from SharedPreferences.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before app restart.
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path from SharedPreferences.
     *
     * @return The saved song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state (isPlaying + position).
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Audio Focus Methods
    // ========================================================================
    
    /**
     * Requests audio focus from the system.
     * Used for ducking when other apps play audio or phone calls come in.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                int result = mAudioManager.requestAudioFocus(mAudioFocusRequest);
                mHasAudioFocus = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            int result = mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            mHasAudioFocus = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED);
        }
    }
    
    /**
     * Abandons audio focus when playback stops.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
        mHasAudioFocus = false;
    }
    
    /**
     * Sets up audio focus with proper handling for all Android versions.
     * LlamaMediaPlayer handles the actual ducking via its duck() method.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     * Uses LlamaMediaPlayer's duck() and unduck() methods for volume control.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                // Permanent loss - always pause, never auto-resume
                Log.d(TAG, "Audio focus: PERMANENT LOSS - pausing playback");
                if (mLlamaPlayer != null && mIsPlaying) {
                    pause();
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // Temporary loss (notification, voice assistant, navigation)
                Log.d(TAG, "Audio focus: TRANSIENT LOSS - pausing playback (will auto-resume)");
                if (mLlamaPlayer != null && mIsPlaying) {
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, true).apply();
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // Can continue playing at reduced volume - use LlamaMediaPlayer.duck()
                Log.d(TAG, "Audio focus: DUCKING - lowering volume via LlamaMediaPlayer");
                if (mLlamaPlayer != null && mIsPlaying) {
                    mLlamaPlayer.duck();
                    mShouldDuck = true;
                }
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                // Focus regained - restore volume via LlamaMediaPlayer.unduck()
                Log.d(TAG, "Audio focus: GAIN - focus regained");
                
                // Restore volume if we were ducking
                if (mShouldDuck && mLlamaPlayer != null) {
                    mLlamaPlayer.unduck();
                    mShouldDuck = false;
                }
                
                boolean wasPlayingBeforeLoss = prefs.getBoolean(KEY_LAST_PLAYING, false);
                
                if (wasPlayingBeforeLoss && !mIsPlaying && mCurrentPlaylist != null && 
                    !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                    
                    Log.d(TAG, "Auto-resuming playback after focus gain");
                    
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mLlamaPlayer != null && getCurrentSong() != null && 
                                mCurrentIndex >= 0 && !mIsPlaying) {
                                resume();
                            }
                            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                                .edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                        }
                    }, 100);
                } else {
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, false).apply();
                }
                break;
                
            default:
                Log.v(TAG, "Unhandled audio focus change: " + focusChange);
                break;
        }
    }
    
    // ========================================================================
    // Broadcast Methods
    // ========================================================================
    
    /**
     * Broadcasts a playback state update to all activities.
     * Used by MusicPlayer to update its UI.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    // ========================================================================
    // Metadata Editor Helper Methods
    // ========================================================================
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     * Called from MetadataEditor after saving changes.
     *
     * @param songPath The path of the song
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (this) {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            // Apply updates
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, 
                                    songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
                // Remove from cache
                if (mAlbumArtCache != null && mCurrentAlbumArtPath != null) {
                    mAlbumArtCache.remove(mCurrentAlbumArtPath);
                }
            } else if (albumArtBytes != null && albumArtBytes.length > 0) {
                Log.d(TAG, "New album art provided for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            
            // Update database
            SongDatabase.getInstance(this).insertSong(updated);
            
            // Update MediaSession with new metadata
            updateMediaSessionMetadata();
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }
    
    // ========================================================================
    // Handle Close Action (from notification)
    // ========================================================================
    
    /**
     * Handles the close action from the notification.
     * Stops playback and closes the app when the user taps "Close" in the notification.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.reset();
        }
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        mCurrentAlbumArtPath = null;
        mIsPlaying = false;
        mIsPrepared = false;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    // ========================================================================
    // Media Button Handling (Bluetooth Headsets)
    // ========================================================================
    
    /**
     * Handles media button events from Bluetooth headsets.
     * Maps volume keys to next/previous when Bluetooth is connected.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        // Standard media button handling
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
}