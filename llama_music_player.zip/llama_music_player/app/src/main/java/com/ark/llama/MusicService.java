package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * MusicService - Background service for music playback.
 *
 * <p>This service provides the core music playback functionality for the
 * Llama Music Player application. It runs in the background to allow
 * continuous playback even when the app is not in the foreground.</p>
 *
 * <h3>Authoritative Playback State Machine</h3>
 * <p>Playback orchestration is owned by a single state machine. A
 * {@link ServiceState} enum, two monotonic counters ({@code mGeneration}
 * and {@code mStartToken}), and a two-index model ({@code mCurrentIndex} /
 * {@code mTargetIndex}) are the only holders of transition state. All
 * state mutations happen on the main thread. All raw {@link MediaPlayer}
 * calls run on a dedicated {@link HandlerThread}. Only marshalled
 * {@link Runnable}s cross between them.</p>
 *
 * <h3>Two-Index Model</h3>
 * <p>{@code mCurrentIndex} is the index the {@link MediaPlayer} is actually
 * bound to. {@code mTargetIndex} is the index the state machine is driving
 * toward. When {@code mState} is PREPARING, {@code mCurrentIndex} still
 * reflects the outgoing song and {@code mTargetIndex} is the destination.
 * Every request method mutates {@code mTargetIndex} only; only
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <p>{@link #getCurrentSong()} reports the song bound to
 * {@code mCurrentIndex}. During a transition the activity, the
 * notification, and the MediaSession metadata all continue to describe the
 * outgoing song until {@link #onPlaybackStarted(long, int, Song, int)}
 * commits PLAYING and advances {@code mCurrentIndex} to the target.</p>
 *
 * <h3>Cold-Start Restore</h3>
 * <p>{@link #setPlaylist(ArrayList, boolean)} primes the state machine with
 * the persisted playback position and paused state on the first call after
 * process launch. The prepared track parks in READY at the retained
 * position, and a subsequent Play resumes from there instead of restarting
 * from zero.</p>
 *
 * <h3>Notification Rendering</h3>
 * <p>The playback notification is produced by
 * {@link NotificationController}, which owns the notification surface
 * process-wide. {@code MusicService} exposes a
 * {@link NotificationController.ServiceStateSource} that the controller
 * polls at a fixed cadence. The service does not push notification updates
 * — it publishes a complete {@link NotificationController.RenderSnapshot}
 * when it has one and returns null otherwise. This makes the notification
 * surface structurally incapable of rendering a state the service has not
 * committed to, and it collapses bursts of rapid transitions into a single
 * render at the controller's layer.</p>
 *
 * <p>The {@link NotificationController.RenderSnapshot#artResolved} flag
 * distinguishes "art decode still pending" from "art resolved to no art."
 * Without it, a song transition would visibly flash the placeholder and
 * then swap to the real art a moment later. With it, the controller holds
 * the outgoing song's art during the pending window and swaps directly to
 * the incoming song's art (or to the placeholder, if the song genuinely
 * has none) in one visible transition.</p>
 *
 * <p>The service attaches to the controller in {@code onCreate} and
 * detaches in {@code onDestroy}. Attach installs the state source and the
 * session-token provider; detach clears both and cancels any pending
 * awareness or render work.</p>
 *
 * <h3>Request Base Index</h3>
 * <p>{@link #playNextSong()} and {@link #playPreviousSong()} base their
 * computation on {@code mCurrentIndex}, not {@code mTargetIndex}, even
 * while a transition is in progress. A rapid sequence of NEXT presses
 * during a transition therefore all compute the same next index and
 * collapse to a single advance. The state machine already serializes the
 * requests through {@link #reconcile()}, which returns early while
 * {@code mState == PREPARING}.</p>
 *
 * <h3>Pause During a Transition</h3>
 * <p>A pause requested while {@code mState == PREPARING} is recorded in
 * {@link #mPauseAfterPrepare} and honored when the transition commits:
 * {@link #onPrepared} takes the READY branch instead of the autostart
 * branch, so the prepared song is parked paused rather than started. The
 * flag is cleared by every failure path that abandons the transition.</p>
 *
 * <h3>Transport Action Debounce</h3>
 * <p>Notification button taps and hardware media keys arrive through the
 * active {@link MediaSessionCompat}'s callback. {@code onStartCommand}
 * intents that carry the same actions arrive on the cold-start path. Both
 * routes pass through {@link #isNotificationActionDebounced(String)}
 * before the request method runs. The window matches the activity's
 * {@code CLICK_DEBOUNCE_DELAY_MS}, so a tap on the notification and a tap
 * on the corresponding on-screen button are subject to the same rate
 * limit.</p>
 *
 * <h3>Callback Identity</h3>
 * <p>Two monotonic counters identify continuations. {@link #mGeneration}
 * tags every transition started by {@link #beginTransition(int, int)} and
 * is captured by the {@link MediaPlayer} listeners installed on the player.
 * A callback whose captured generation differs from the current value is
 * inert. {@link #mStartToken} tags start and resume continuations.</p>
 *
 * <h3>MediaSession Activation</h3>
 * <p>The session is deactivated while the state machine is idle and
 * reactivated whenever a track is bound. Deactivation happens in
 * {@link #transitionToIdle()}, immediately after the metadata is cleared.
 * Reactivation happens in {@link #onPlaybackStarted(long, int, Song, int)}
 * and in the READY branch of
 * {@link #onPrepared(long, int, int, Song, int)}. Keeping the session
 * inactive while nothing is loaded prevents the system media controls from
 * surfacing a "Llama Music Player" entry with no content.</p>
 *
 * <h3>Library Reset</h3>
 * <p>When the user removes every folder and every loose track, the library
 * becomes empty and the service must tear itself down completely. That
 * teardown is owned by this service, not by any activity: the service
 * registers its own receiver for {@code RESET_PLAYER_STATE} and reacts to
 * it directly. This makes the reset reachable regardless of whether
 * {@code MusicPlayer} happens to be alive at the moment the broadcast is
 * emitted. {@link #transitionToIdle()} clears every field that describes
 * "what was playing", including the MediaSession metadata, the resolved
 * notification art, the art cache, the static audio-session ID exposed to
 * {@link EqualizerManager}, and the transport-action debounce map. When
 * {@code preserve_settings} is false, the receiver additionally clears the
 * in-memory library, the persisted playback preferences, and the released
 * audio effects.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — At most one {@code prepareAsync()} in flight process-wide.</li>
 *   <li>I2 — {@link #releaseMediaPlayer()} runs only on the player thread.</li>
 *   <li>I3 — MediaPlayer callbacks with a stale generation are inert.</li>
 *   <li>I4 — {@link #setShuffle(boolean)} and {@link #setRepeatMode(int)}
 *       touch only their own field; they never cause a transition.</li>
 *   <li>I5 — {@link #onStall()} mutates state and calls
 *       {@link #reconcile()}; it never invokes a request method.</li>
 *   <li>I6 — State fields are written only on the main thread.</li>
 *   <li>I7 — {@link #setPlaylist(ArrayList, boolean)} resolves an anchor
 *       and re-enters reconciliation. It never bypasses the gate.</li>
 *   <li>I8 — {@link #transitionToIdle()} is idempotent.</li>
 *   <li>I9 — Raw {@link MediaPlayer} calls execute only on
 *       {@code mPlayerThread}.</li>
 *   <li>I10 — {@code mGeneration} changes if and only if the state machine
 *       has moved on to a different song preparation.</li>
 *   <li>I11 — {@link #getCurrentSong()} reports {@code mCurrentIndex} only.</li>
 *   <li>I12 — {@link #playNextSong()} and {@link #playPreviousSong()} base
 *       their computation on {@code mCurrentIndex}.</li>
 *   <li>I13 — The service is foreground while {@code mState == PLAYING} and
 *       not foreground in every other state.</li>
 *   <li>I14 — The playback notification is produced by
 *       {@link NotificationController} only, from a snapshot the service
 *       has marked complete.</li>
 *   <li>I15 — Transport actions arriving through the active MediaSession
 *       callback pass through {@link #isNotificationActionDebounced(String)}.</li>
 *   <li>I16 — {@link #mPauseAfterPrepare} is cleared by every path that
 *       ends a transition.</li>
 *   <li>I17 — {@link #mResolvedArtPath} and {@link #mResolvedArt} are
 *       written only on the main thread, after the decode callback
 *       returns, and only when the resolved path matches the state
 *       machine's authoritative song.</li>
 *   <li>I18 — {@code RESET_PLAYER_STATE} is received by this service's own
 *       receiver, independent of any activity. {@link #transitionToIdle()}
 *       leaves no field describing a song that no longer exists in the
 *       library, and reports {@code STATE_STOPPED} to the MediaSession.</li>
 *   <li>I19 — Equalizer preferences are never touched by the reset path.
 *       {@link EqualizerManager#release()} saves the settings to
 *       SharedPreferences and tears the effects down; it never removes
 *       those keys.</li>
 *   <li>I20 — The MediaSession is active if and only if a track is bound
 *       (state is PLAYING, PAUSED, or READY). It is inactive in IDLE.</li>
 * </ul>
 *
 * <h3>Pause vs Stop</h3>
 * <p>{@link #pause()} retains the {@link MediaPlayer} and its position;
 * {@link #resume()} restarts from that position. {@link #stop()} releases
 * the player but remembers the index in {@code mTargetIndex}, so a
 * subsequent play re-prepares the same track from position 0.
 * {@link #stopCompletely()} tears down to IDLE and clears the playlist.</p>
 *
 * <h3>Timing</h3>
 * <p>The stall detector fires at {@code HEALTH_CHECK_INTERVAL_MS} and treats
 * a position below 100 ms lasting longer than {@code MAX_STALL_TIME_MS} as
 * a stall. The stall budget accrues only while {@code mState == PLAYING}.
 * All elapsed-time math uses {@link SystemClock#elapsedRealtime()}.</p>
 *
 * @see MediaPlayer
 * @see NotificationController
 * @see EqualizerManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================

    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    private static final String ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME";
    private static final String ACTION_RESET_PLAYER_STATE = "RESET_PLAYER_STATE";

    private static final long NOTIFICATION_ACTION_DEBOUNCE_MS = 500;
    private static final int HEALTH_CHECK_INTERVAL_MS = 500;
    private static final int MAX_STALL_TIME_MS = 1500;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    private static final long SKIP_LOOP_BUDGET_MS = 2500L;
    private static final int NOTIFICATION_ART_MAX_PX = 300;
    private static final int NOTIFICATION_ART_CACHE_MB = 25;

    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;

    private static int sCurrentAudioSessionId = 0;

    // ========================================================================
    // State Machine
    // ========================================================================

    private enum ServiceState {
        IDLE,
        PREPARING,
        READY,
        PLAYING,
        PAUSED,
        STOPPING
    }

    private ServiceState mState = ServiceState.IDLE;
    private long mGeneration = 0L;
    private long mStartToken = 0L;
    private int mCurrentIndex = -1;
    private int mTargetIndex = -1;
    private int mPendingSeekPosition = 0;
    private boolean mForceReprepare = false;
    private boolean mPauseAfterPrepare = false;
    private boolean mAutoStartOnPrepared = true;
    private long mPlaybackStartElapsed = 0L;
    private int mRecoveryAttempts = 0;
    private long mSkipLoopStartedElapsed = 0L;

    private final Handler mMachineHandler = new Handler(Looper.getMainLooper());
    private Handler mHealthHandler;
    private Runnable mHealthCheckRunnable;

    @NonNull
    private final HashMap<String, Long> mLastNotificationActionTime = new HashMap<>();

    // ========================================================================
    // MediaPlayer
    // ========================================================================

    private MediaPlayer mMediaPlayer;
    private HandlerThread mPlayerThread;
    private Handler mPlayerHandler;
    private PowerManager.WakeLock mWakeLock;

    // ========================================================================
    // Notification Album Art
    // ========================================================================

    private final ExecutorService mArtLoader = Executors.newSingleThreadExecutor();
    private LruCache<String, Bitmap> mArtCache;
    private Future<?> mCurrentArtLoad = null;

    @Nullable
    private String mResolvedArtPath = null;

    @Nullable
    private Bitmap mResolvedArt = null;

    // ========================================================================
    // Notification State Source
    // ========================================================================

    private final NotificationController.ServiceStateSource mStateSource =
        new NotificationController.ServiceStateSource() {

            @Nullable
            @Override
            public NotificationController.RenderSnapshot snapshotForNotification() {
                if (mState == ServiceState.PREPARING || mState == ServiceState.IDLE) {
                    return null;
                }

                Song currentSong = getCurrentSong();
                if (currentSong == null) {
                    return null;
                }
                String currentPath = currentSong.getPath();
                if (currentPath == null) {
                    return null;
                }

                final boolean artResolved = currentPath.equals(mResolvedArtPath);
                final Bitmap resolvedArt = artResolved ? mResolvedArt : null;

                return new NotificationController.RenderSnapshot(
                    currentSong.getTitle(),
                    currentSong.getArtist(),
                    currentPath,
                    mState == ServiceState.PLAYING,
                    resolvedArt,
                    artResolved);
            }

            @Override
            public boolean isIdle() {
                return mState == ServiceState.IDLE;
            }
        };

    // ========================================================================
    // Cached playback facts
    // ========================================================================

    private int mCachedDuration = 0;
    private int mCachedAudioSessionId = 0;
    private int mCachedPosition = 0;
    private int mPlaybackBasePosition = 0;
    private long mPlaybackBaseElapsed = 0L;
    private long mPositionEpoch = 0L;

    // ========================================================================
    // Playlist and Playback State
    // ========================================================================

    private ArrayList<Song> mCurrentPlaylist;
    private volatile boolean mIsPlaying = false;
    private volatile int mRepeatMode = 0;
    private volatile boolean mIsShuffle = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;
    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;
    private volatile String mPendingSongPath = null;

    // ========================================================================
    // Binder, Library, Notification Controller
    // ========================================================================

    private final IBinder mBinder = new LocalBinder();
    private MusicLibrary mMusicLibrary;

    @Nullable
    private NotificationController mNotificationController;

    // ========================================================================
    // Audio Focus and Session
    // ========================================================================

    private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    private AudioFocusRequest mAudioFocusRequest;
    private MediaSessionCompat mMediaSession;
    private volatile boolean mIsBluetoothConnected = false;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    private BroadcastReceiver mSetPendingSongReceiver;
    private BroadcastReceiver mResetPlayerStateReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Sort Comparators
    // ========================================================================

    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) return comparisonResult;
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }

    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ========================================================================
    // Static Helpers
    // ========================================================================

    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ========================================================================
    // Service Lifecycle
    // ========================================================================

    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        final int artCacheSize = NOTIFICATION_ART_CACHE_MB * 1024 * 1024;
        mArtCache = new LruCache<String, Bitmap>(artCacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mPlayerThread = new HandlerThread("MediaPlayerThread");
        mPlayerThread.start();
        mPlayerHandler = new Handler(mPlayerThread.getLooper());

        mNotificationController = NotificationController.getInstance(this);
        mNotificationController.attachService(this);
        mNotificationController.setStateSource(mStateSource);
        mNotificationController.setSessionTokenProvider(this::getSessionToken);

        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerSoftUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();
        registerResetPlayerStateReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }

        if (intent != null && intent.getAction() != null) {
            final String action = intent.getAction();

            if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
                KeyEvent event;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent.class);
                } else {
                    @SuppressWarnings("deprecation")
                    KeyEvent deprecatedEvent = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                    event = deprecatedEvent;
                }
                if (event != null && event.getAction() == KeyEvent.ACTION_DOWN
                        && mMediaSession != null) {
                    mMediaSession.getController().dispatchMediaButtonEvent(event);
                }
                return START_STICKY;
            }

            if (isNotificationActionDebounced(action)) {
                return START_STICKY;
            }

            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNextSong();
            } else if (action.equals("ACTION_PREV")) {
                playPreviousSong();
            } else if (action.equals("ACTION_STOP")) {
                pause();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationController != null) {
                    mNotificationController.demoteFromForeground();
                }
            } else if (action.equals(ACTION_BLUETOOTH_RESUME)) {
                handleBluetoothResume();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) playSong(position);
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    private boolean isNotificationActionDebounced(@NonNull String action) {
        if (!"ACTION_PLAY_PAUSE".equals(action)
                && !"ACTION_NEXT".equals(action)
                && !"ACTION_PREV".equals(action)) {
            return false;
        }
        final long now = SystemClock.elapsedRealtime();
        final Long last = mLastNotificationActionTime.get(action);
        if (last != null && now - last < NOTIFICATION_ACTION_DEBOUNCE_MS) {
            return true;
        }
        mLastNotificationActionTime.put(action, now);
        return false;
    }

    private void handleBluetoothResume() {
        onMain(() -> {
            final String lastPath = getSavedSongPath();
            if (lastPath == null || !new File(lastPath).exists()) {
                transitionToIdle();
                stopSelf();
                return;
            }

            Song lastSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (lastSong == null) {
                lastSong = CharacterMapper.getSongFromFile(lastPath);
            }
            if (lastSong == null) {
                transitionToIdle();
                stopSelf();
                return;
            }

            final ArrayList<Song> singleSong = new ArrayList<>();
            singleSong.add(lastSong);
            setPlaylist(singleSong, true);
            resume();

            if (mMusicLibrary == null) mMusicLibrary = new MusicLibrary(this);
            mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
                @Override
                public void onSongsLoaded(ArrayList<Song> songs) {
                    onMain(() -> {
                        if (songs != null && !songs.isEmpty()) {
                            setPlaylist(songs, true);
                        }
                    });
                }

                @Override
                public void onLoadingError(String error) {
                    Log.w(TAG, "Full library load after BT resume failed: " + error);
                }
            });
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtLoader != null && !mArtLoader.isShutdown()) {
            mArtLoader.shutdownNow();
        }

        if (mPlayerHandler != null) {
            mPlayerHandler.post(this::releaseMediaPlayer);
        }
        if (mPlayerThread != null) {
            mPlayerThread.quitSafely();
            try {
                mPlayerThread.join(2000);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            mPlayerThread = null;
            mPlayerHandler = null;
        }

        releaseWakeLock();
        mIsPlaying = false;
        mState = ServiceState.STOPPING;

        if (mNotificationController != null) {
            mNotificationController.detachService();
            mNotificationController = null;
        }

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMachineHandler != null) {
            mMachineHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);
        unregisterReceiverSafely(mResetPlayerStateReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(this::reconcile);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ========================================================================
    // Thread Marshalling and Small Helpers
    // ========================================================================

    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) action.run();
        else mMachineHandler.post(action);
    }

    private void onPlayer(@NonNull Runnable action) {
        if (mPlayerHandler == null) return;
        if (Looper.myLooper() == mPlayerHandler.getLooper()) action.run();
        else mPlayerHandler.post(action);
    }

    private int playlistSize() {
        return mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0;
    }

    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) return null;
        if (index < 0 || index >= mCurrentPlaylist.size()) return null;
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) return -1;
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) return index;
        }
        return -1;
    }

    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try {
                mWakeLock.acquire();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    private int estimateCurrentPosition() {
        if (mState == ServiceState.PLAYING && mPlaybackBaseElapsed > 0L) {
            long elapsedDuration = SystemClock.elapsedRealtime() - mPlaybackBaseElapsed;
            long estimatedDuration = mPlaybackBasePosition + elapsedDuration;
            if (mCachedDuration > 0 && estimatedDuration > mCachedDuration) {
                return mCachedDuration;
            }
            return (int) estimatedDuration;
        }
        return mCachedPosition;
    }

    private boolean skipBudgetExhausted() {
        long currentTime = SystemClock.elapsedRealtime();
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = currentTime;
            return false;
        }
        return (currentTime - mSkipLoopStartedElapsed) >= SKIP_LOOP_BUDGET_MS;
    }

    private void abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after "
            + (SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed) + " ms");
        mSkipLoopStartedElapsed = 0L;
        mPauseAfterPrepare = false;
        mForceReprepare = false;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mIsPlaying = false;
        mCurrentIndex = -1;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // Notification Album Art Prefetch
    // ========================================================================

    private void prefetchNotificationArt(@Nullable Song song) {
        if (song == null || song.getPath() == null) return;

        final String path = song.getPath();

        if (mArtCache.get(path) != null) {
            mResolvedArtPath = path;
            mResolvedArt = mArtCache.get(path);
            return;
        }

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }

        mCurrentArtLoad = mArtLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap art = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    byte[] bytes = retriever.getEmbeddedPicture();
                    if (bytes != null && !Thread.currentThread().isInterrupted()) {
                        art = decodeNotificationArt(bytes);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Notification art prefetch failed for " + path, exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception ignored) {
                        }
                    }
                }

                if (art != null && !Thread.currentThread().isInterrupted()) {
                    mArtCache.put(path, art);
                }

                final Bitmap finalArt = art;
                onMain(() -> {
                    final String expectedPath;
                    if (mState == ServiceState.PREPARING) {
                        expectedPath = pathOf(mTargetIndex);
                    } else {
                        expectedPath = pathOf(mCurrentIndex);
                    }
                    if (expectedPath == null || !path.equals(expectedPath)) {
                        return;
                    }
                    mResolvedArtPath = path;
                    mResolvedArt = finalArt;
                });
            }
        });
    }

    @Nullable
    private Bitmap decodeNotificationArt(@NonNull byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);

        int sampleSize = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) {
            sampleSize *= 2;
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sampleSize;
        return BitmapFactory.decodeByteArray(data, 0, data.length, decode);
    }

    // ========================================================================
    // Pure Functions
    // ========================================================================

    private int computeNext(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return pickShuffleNext(fromIndex);
        return (fromIndex + 1) % playlistSize();
    }

    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) return -1;
        if (mIsShuffle) return popShuffleHistory(fromIndex);
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    private int pickShuffleNext(int fromIndex) {
        int size = playlistSize();
        if (size <= 1) return fromIndex;

        if (mShuffleHistory == null) mShuffleHistory = new ArrayList<Integer>();
        if (mShuffleHistory.size() >= size * 2) mShuffleHistory.clear();
        if (mRandom == null) mRandom = new Random();

        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);

        mShuffleHistory.add(candidate);
        return candidate;
    }

    private int popShuffleHistory(int fromIndex) {
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int previousIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
            if (previousIndex >= 0 && previousIndex < playlistSize()) return previousIndex;
        }
        int size = playlistSize();
        if (size <= 1) return fromIndex;
        if (mRandom == null) mRandom = new Random();
        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);
        return candidate;
    }

    // ========================================================================
    // Core: Reconcile and Transition
    // ========================================================================

    private void reconcile() {
        if (mState == ServiceState.STOPPING) return;
        if (mState == ServiceState.PREPARING) return;
        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) return;

        boolean need = (mTargetIndex != mCurrentIndex) || mForceReprepare;
        if (!need) return;

        mForceReprepare = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) return;
        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (index < 0 || index >= playlistSize()) return;

        final long generation = ++mGeneration;
        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            mState = ServiceState.IDLE;
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(index);
            mMachineHandler.post(this::reconcile);
            return;
        }

        prefetchNotificationArt(song);

        final String path = song.getPath();
        final int committedIndex = index;
        final long capturedGeneration = generation;

        onPlayer(() -> {
            releaseMediaPlayer();
            final MediaPlayer player = getOrCreatePlayerRaw();
            removeAllListeners(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            try {
                player.setDataSource(path);
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + path, exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            player.setOnPreparedListener(mediaPlayer -> {
                final int duration;
                final int audioSessionId;
                try {
                    duration = mediaPlayer.getDuration();
                    audioSessionId = mediaPlayer.getAudioSessionId();
                } catch (Exception exception) {
                    mMachineHandler.post(() ->
                        onPrepareFailed(capturedGeneration, committedIndex));
                    return;
                }
                mMachineHandler.post(() -> onPrepared(
                    capturedGeneration, duration, audioSessionId, song, committedIndex));
            });

            player.setOnCompletionListener(mediaPlayer ->
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    onCompletion();
                }));

            player.setOnErrorListener((mediaPlayer, what, extra) -> {
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    onPlayerError(what, extra);
                });
                return true;
            });

            try {
                player.prepareAsync();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "prepareAsync failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) return;
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
            }
        });
    }

    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) return;

        if (mState == ServiceState.IDLE
                && mCurrentPlaylist == null
                && mCurrentIndex == -1
                && mTargetIndex == -1) {
            return;
        }

        mState = ServiceState.STOPPING;
        mGeneration++;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mPauseAfterPrepare = false;
        mForceReprepare = false;
        mSkipLoopStartedElapsed = 0L;
        mCurrentIndex = -1;
        mPendingSongPath = null;

        mCachedPosition = 0;
        mCachedDuration = 0;
        mCachedAudioSessionId = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;
        mPositionEpoch++;

        mResolvedArtPath = null;
        mResolvedArt = null;
        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtCache != null) {
            mArtCache.evictAll();
        }

        mLastNotificationActionTime.clear();

        stopHealthMonitoring();

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentPlaylist = null;
        mIsPlaying = false;
        if (mShuffleHistory != null) mShuffleHistory.clear();

        // Full release rather than detach: the audio effects have no session
        // to drive. release() saves the user's settings to SharedPreferences
        // before tearing down, so a later reattach restores them.
        EqualizerManager.getInstance(this).release();

        sCurrentAudioSessionId = 0;

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        if (mNotificationController != null) {
            mNotificationController.demoteFromForeground();
        }

        updateMediaSessionMetadata(null, null);

        // Deactivate the session so the system media controls drop the app
        // from their "active sessions" list. Reactivated in
        // onPlaybackStarted() and in the READY branch of onPrepared().
        // Leaving it active would surface a stale "Llama Music Player" entry
        // in the shade's media carousel even though nothing is loaded.
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(false);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to deactivate MediaSession", exception);
            }
        }

        mState = ServiceState.IDLE;
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // MediaPlayer Callbacks
    // ========================================================================

    private void onPrepared(long generation, int duration, int audioSessionId,
                            @NonNull Song song, int committedIndex) {
        if (generation != mGeneration) return;
        if (mState != ServiceState.PREPARING) return;

        if (duration <= 0) {
            onPrepareFailed(generation, committedIndex);
            return;
        }

        int seekPosition = mPendingSeekPosition;
        mPendingSeekPosition = 0;

        mSkipLoopStartedElapsed = 0L;
        mCachedDuration = duration;
        mCachedAudioSessionId = audioSessionId;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        sCurrentAudioSessionId = audioSessionId;
        broadcastAudioSessionChanged(audioSessionId);
        EqualizerManager.getInstance(this).attachToAudioSession(audioSessionId);

        mCurrentIndex = committedIndex;

        if (mPauseAfterPrepare) {
            mPauseAfterPrepare = false;
            mAutoStartOnPrepared = false;
        }

        if (!mAutoStartOnPrepared) {
            if (seekPosition > 0 && seekPosition < duration - 500) {
                final int finalSeekPosition = seekPosition;
                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player != null) {
                        try {
                            player.seekTo(finalSeekPosition);
                        } catch (Exception ignored) {
                        }
                    }
                });
                mCachedPosition = seekPosition;
                mPlaybackBasePosition = seekPosition;
            }

            mState = ServiceState.READY;
            mRecoveryAttempts = 0;

            // A track is now bound, so the session must be active: the
            // READY state is visible to the system media controls and a
            // subsequent Play must resume without reactivating.
            if (mMediaSession != null) {
                try {
                    mMediaSession.setActive(true);
                } catch (Exception ignored) {
                }
            }

            updateMediaSessionMetadata(song, null);
            updateMediaSessionPlaybackState();
            saveCurrentPlayingIndex();
            broadcastUpdate();
            return;
        }

        final int doSeek = (seekPosition > 0 && seekPosition < duration - 500)
            ? seekPosition : 0;
        final long capturedGeneration = generation;
        final Song capturedSong = song;
        final int capturedIndex = committedIndex;
        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            if (doSeek > 0) {
                try {
                    player.seekTo(doSeek);
                } catch (Exception ignored) {
                }
            }
            try {
                player.start();
            } catch (Exception exception) {
                Log.e(TAG, "onPrepared: start() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            final long finalCapturedStartToken = capturedStartToken;
            mMachineHandler.post(() -> {
                if (finalCapturedStartToken != mStartToken) return;
                onPlaybackStarted(capturedGeneration, capturedIndex, capturedSong, doSeek);
            });
        });
    }

    private void onPlaybackStarted(long generation, int committedIndex,
                                   @NonNull Song song, int seekPosition) {
        if (generation != mGeneration) return;
        if (mState != ServiceState.PREPARING) return;

        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBasePosition = seekPosition;
        mPlaybackBaseElapsed = mPlaybackStartElapsed;
        mCachedPosition = seekPosition;
        mRecoveryAttempts = 0;

        acquireWakeLock();
        requestAudioFocus();

        // A track is bound and playing, so the session must be active.
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
            }
        }

        updatePlaybackParams();
        updateMediaSessionMetadata(song, null);
        updateMediaSessionPlaybackState();
        saveCurrentPlayingIndex();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }

        if (mTargetIndex != mCurrentIndex || mForceReprepare) {
            mMachineHandler.post(this::reconcile);
        }
    }

    private void onPrepareFailed(long generation, int committedIndex) {
        if (generation != mGeneration) return;
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        onPlayer(this::releaseMediaPlayer);
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }
        mTargetIndex = computeNext(committedIndex);
        mMachineHandler.post(this::reconcile);
    }

    private void onCompletion() {
        if (mState != ServiceState.PLAYING) return;

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }

        int fromIndex = mCurrentIndex;
        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mRepeatMode == 1) {
            nextIndex = computeNext(fromIndex);
        } else if (fromIndex + 1 < playlistSize()) {
            nextIndex = fromIndex + 1;
        } else {
            mState = ServiceState.PAUSED;
            mTargetIndex = fromIndex;
            mPendingSeekPosition = 0;
            mIsPlaying = false;
            mCachedPosition = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            onPlayer(() -> {
                final MediaPlayer player = mMediaPlayer;
                if (player == null) return;
                try {
                    player.pause();
                } catch (Exception ignored) {
                }
                try {
                    player.seekTo(0);
                } catch (Exception ignored) {
                }
            });

            releaseWakeLock();
            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            return;
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        mMachineHandler.post(this::reconcile);
    }

    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);

        mIsPlaying = false;
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }

        if (mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        mMachineHandler.post(this::reconcile);
    }

    private void onStall() {
        if (mState != ServiceState.PLAYING) return;

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) {
                transitionToIdle();
                return;
            }
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
        } else {
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
        }

        reconcile();
    }

    // ========================================================================
    // Health Monitoring
    // ========================================================================

    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mState == ServiceState.PLAYING) {
                    refreshPositionFromPlayer();
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    private void refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) return;

        final long epoch = mPositionEpoch;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;

            final int position;
            try {
                position = player.getCurrentPosition();
            } catch (Exception exception) {
                return;
            }

            mMachineHandler.post(() -> {
                if (epoch != mPositionEpoch) return;
                if (mState != ServiceState.PLAYING) return;

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime();

                long elapsedDuration = SystemClock.elapsedRealtime() - mPlaybackStartElapsed;
                if (position < 100 && elapsedDuration > MAX_STALL_TIME_MS) {
                    onStall();
                } else if (position >= 100) {
                    mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                }
            });
        });
    }

    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ========================================================================
    // Public Request API
    // ========================================================================

    public void playSong(int index) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) return;
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG, "playSongByPath: not in playlist, parked: " + filePath);
            }
        });
    }

    public void playNextSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computeNext(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    public void playPreviousSong() {
        onMain(() -> {
            if (playlistEmpty()) return;
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) baseIndex = 0;
            mTargetIndex = computePrevious(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    public void togglePlayPause() {
        onMain(() -> {
            switch (mState) {
                case PLAYING:
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY: {
                    final long capturedStartToken = ++mStartToken;
                    onPlayer(() -> {
                        final MediaPlayer player = mMediaPlayer;
                        boolean started = false;
                        if (player != null) {
                            try {
                                player.start();
                                started = true;
                            } catch (Exception exception) {
                                Log.e(TAG, "start() failed from READY", exception);
                            }
                        }
                        final boolean finalStarted = started;
                        mMachineHandler.post(() -> {
                            if (capturedStartToken != mStartToken) return;
                            if (!finalStarted) {
                                mState = ServiceState.IDLE;
                                onPlayer(this::releaseMediaPlayer);
                                broadcastUpdate();
                                return;
                            }
                            mState = ServiceState.PLAYING;
                            mIsPlaying = true;
                            mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                            mPlaybackBaseElapsed = mPlaybackStartElapsed;
                            acquireWakeLock();
                            requestAudioFocus();
                            if (mMediaSession != null) {
                                try {
                                    mMediaSession.setActive(true);
                                } catch (Exception ignored) {
                                }
                            }
                            updatePlaybackParams();
                            savePlayingState();
                            savePlayerState();
                            startHealthMonitoring();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();

                            if (mNotificationController != null) {
                                mNotificationController.startForegroundSync();
                            }
                        });
                    });
                    break;
                }
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        return;
                    }
                    mSkipLoopStartedElapsed = 0L;
                    if (mTargetIndex < 0) mTargetIndex = 0;
                    reconcile();
                    break;
                case PREPARING:
                    mPauseAfterPrepare = true;
                    break;
                case STOPPING:
                    break;
            }
        });
    }

    public void pause() {
        onMain(() -> {
            if (mState == ServiceState.PLAYING) {
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        });
    }

    public void resume() {
        onMain(() -> {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                mSkipLoopStartedElapsed = 0L;
                if (mTargetIndex < 0 && !playlistEmpty()) mTargetIndex = 0;
                reconcile();
            }
        });
    }

    public void stop() {
        onMain(() -> {
            if (mState != ServiceState.PLAYING && mState != ServiceState.PAUSED) return;

            int stoppedAtIndex = mCurrentIndex;

            onPlayer(this::releaseMediaPlayer);
            releaseWakeLock();

            mIsPlaying = false;
            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;
            mPendingSeekPosition = 0;
            mPauseAfterPrepare = false;
            mForceReprepare = false;
            mSkipLoopStartedElapsed = 0L;
            mState = ServiceState.IDLE;

            mCachedPosition = 0;
            mCachedDuration = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
        });
    }

    public void stopCompletely() {
        onMain(this::transitionToIdle);
    }

    private void doPause() {
        final int position = estimateCurrentPosition();

        mState = ServiceState.PAUSED;
        mIsPlaying = false;
        mCachedPosition = position;
        mPlaybackBasePosition = position;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;
            try {
                player.pause();
            } catch (Exception ignored) {
            }
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();

        if (mNotificationController != null) {
            mNotificationController.demoteFromForeground();
        }
    }

    private void doResume() {
        requestAudioFocus();
        updatePlaybackParams();

        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            boolean started = false;
            if (player != null) {
                try {
                    player.start();
                    started = true;
                } catch (Exception exception) {
                    Log.e(TAG, "resume: start() failed", exception);
                }
            }
            final boolean finalStarted = started;
            mMachineHandler.post(() -> {
                if (capturedStartToken != mStartToken) return;
                if (finalStarted) {
                    onPlaybackResumed();
                } else {
                    mState = ServiceState.IDLE;
                    onPlayer(this::releaseMediaPlayer);
                    broadcastUpdate();
                    reconcile();
                }
            });
        });
    }

    private void onPlaybackResumed() {
        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBaseElapsed = mPlaybackStartElapsed;

        acquireWakeLock();
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
            }
        }
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();
        updateMediaSessionPlaybackState();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }
    }

    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {

                mPositionEpoch++;

                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player == null) return;
                    try {
                        player.seekTo(position);
                    } catch (Exception ignored) {
                    }
                });

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed = SystemClock.elapsedRealtime();
                }

                savePlayerState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
            }
        });
    }

    // ========================================================================
    // Playlist
    // ========================================================================

    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) return;

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) {
                    broadcastUpdate();
                    return;
                }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));

            if (mCurrentPlaylist != null
                && mCurrentPlaylist.size() == sortedPlaylist.size()
                && sameOrder(mCurrentPlaylist, sortedPlaylist)) {
                broadcastUpdate();
                return;
            }

            String anchorPath = mPendingSongPath;
            if (anchorPath == null) anchorPath = pathOf(mCurrentIndex);
            if (anchorPath == null) anchorPath = getSavedSongPath();

            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null && anchorPath.equals(candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mCurrentPlaylist = sortedPlaylist;

            int resolvedIndex = (anchorPath != null) ? indexOfPath(anchorPath) : -1;

            if (resolvedIndex < 0 && anchorSong != null && anchorSong.getTitle() != null) {
                for (int index = 0; index < sortedPlaylist.size(); index++) {
                    Song candidateSong = sortedPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }
            if (resolvedIndex < 0) resolvedIndex = 0;

            mPendingSongPath = null;

            if (mState == ServiceState.PREPARING) {
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            final boolean coldStart = (mCurrentIndex == -1 && mState == ServiceState.IDLE);
            if (coldStart && anchorPath != null && anchorPath.equals(getSavedSongPath())) {
                final int savedPosition = getSavedPosition();
                if (savedPosition > 0) {
                    mPendingSeekPosition = savedPosition;
                }
                if (!wasPlayingBeforeRestart()) {
                    mPauseAfterPrepare = true;
                }
            }

            boolean sameSong = (resolvedIndex == mCurrentIndex)
                            && (mState == ServiceState.PLAYING
                                || mState == ServiceState.PAUSED
                                || mState == ServiceState.READY);

            mTargetIndex = resolvedIndex;

            if (sameSong) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) updateMediaSessionMetadata(currentSong, null);
                updateMediaSessionPlaybackState();
                broadcastUpdate();
            } else {
                reconcile();
            }
        });
    }

    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) return new ArrayList<Song>();
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) return false;
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null) ? firstSong.getPath() : null;
            String secondPath = (secondSong != null) ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ========================================================================
    // Pending Song Path
    // ========================================================================

    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            mPendingSongPath = path;
            if (path != null) {
                Log.d(TAG, "Pending song path set: " + path);
                playPendingSongIfExists();
            } else {
                Log.d(TAG, "Pending song path cleared");
            }
        });
    }

    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) return;
            int index = indexOfPath(mPendingSongPath);
            if (index >= 0) {
                mPendingSongPath = null;
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            }
        });
    }

    // ========================================================================
    // Getters and Mode Setters
    // ========================================================================

    public int getCurrentPosition() {
        return estimateCurrentPosition();
    }

    public int getDuration() {
        return mCachedDuration;
    }

    public boolean isPlaying() {
        return mState == ServiceState.PLAYING;
    }

    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return null;
        if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return null;
        return mCurrentPlaylist.get(mCurrentIndex);
    }

    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    public int getRepeatMode() { return mRepeatMode; }

    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            savePlayerState();
            broadcastUpdate();
        });
    }

    public boolean isShuffle() { return mIsShuffle; }

    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            savePlayerState();
            broadcastUpdate();
        });
    }

    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ========================================================================
    // Sort Mode
    // ========================================================================

    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ========================================================================
    // Persistence
    // ========================================================================

    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    private void saveFullState() {
        savePlayerState();
    }

    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }

    // ========================================================================
    // MediaPlayer Plumbing (player-thread only)
    // ========================================================================

    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
        }
    }

    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try {
                if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                mMediaPlayer.reset();
            } catch (Exception ignored) {
            }
            try {
                mMediaPlayer.release();
            } catch (Exception ignored) {
            }
            mMediaPlayer = null;
        }
    }

    @NonNull
    private MediaPlayer getOrCreatePlayerRaw() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    // ========================================================================
    // Playback Params
    // ========================================================================

    public void updatePlaybackParams() {
        EqualizerManager equalizerManager = EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        final float finalTempo = tempo;
        final float finalSemitones = semitones;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) return;
            try {
                float pitch = (float) Math.pow(2.0, finalSemitones / 12.0);
                android.media.PlaybackParams playbackParams = player.getPlaybackParams();
                playbackParams.setSpeed(finalTempo);
                playbackParams.setPitch(pitch);
                player.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + finalTempo + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params", exception);
            }
        });
    }

    // ========================================================================
    // MediaSession
    // ========================================================================

    private void setupMediaSession() {
        try {
            ComponentName mediaButtonReceiver = new ComponentName(
                this, androidx.media.session.MediaButtonReceiver.class);
            mMediaSession = new MediaSessionCompat(
                this, "LlamaMusicService", mediaButtonReceiver, null);

            mMediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> {
                        if (mState == ServiceState.PAUSED) {
                            doResume();
                        } else if (mState == ServiceState.IDLE) {
                            resume();
                        } else if (mState == ServiceState.READY) {
                            togglePlayPause();
                        }
                    });
                }

                @Override
                public void onPause() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> {
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        } else if (mState == ServiceState.PREPARING) {
                            mPauseAfterPrepare = true;
                        }
                    });
                }

                @Override
                public void onSkipToNext() {
                    if (isNotificationActionDebounced("ACTION_NEXT")) return;
                    playNextSong();
                }

                @Override
                public void onSkipToPrevious() {
                    if (isNotificationActionDebounced("ACTION_PREV")) return;
                    playPreviousSong();
                }

                @Override
                public void onStop() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) return;
                    onMain(() -> {
                        if (mState == ServiceState.PLAYING) doPause();
                    });
                }

                @Override
                public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId == null) return;
                    try {
                        playSong(Integer.parseInt(mediaId));
                    } catch (NumberFormatException ignored) {
                    }
                }
            });

            mMediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    @Nullable
    public MediaSessionCompat.Token getSessionToken() {
        return mMediaSession != null ? mMediaSession.getSessionToken() : null;
    }

    public void updateMediaSessionMetadata(@Nullable Song song, @Nullable Bitmap albumArt) {
        if (mMediaSession == null) return;
        try {
            MediaMetadataCompat.Builder builder = new MediaMetadataCompat.Builder();
            if (song != null) {
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, song.getTitle());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.getArtist());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, song.getAlbum());
                if (albumArt != null && !albumArt.isRecycled()) {
                    builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, albumArt);
                }
            } else {
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, "Llama Music Player");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "");
            }
            mMediaSession.setMetadata(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession metadata", exception);
        }
    }

    public void updateMediaSessionArt(@Nullable Bitmap albumArt) {
        updateMediaSessionMetadata(getCurrentSong(), albumArt);
    }

    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null) return;
        try {
            long actions = PlaybackStateCompat.ACTION_PLAY
                         | PlaybackStateCompat.ACTION_PAUSE
                         | PlaybackStateCompat.ACTION_PLAY_PAUSE
                         | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                         | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackStateCompat.ACTION_STOP;

            final int frameworkState;
            if (mState == ServiceState.PLAYING) {
                frameworkState = PlaybackStateCompat.STATE_PLAYING;
            } else if (mState == ServiceState.IDLE) {
                frameworkState = PlaybackStateCompat.STATE_STOPPED;
            } else {
                frameworkState = PlaybackStateCompat.STATE_PAUSED;
            }

            PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(frameworkState, getCurrentPosition(), 1.0f);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state", exception);
        }
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mState == ServiceState.PLAYING) doPause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
            case AudioManager.AUDIOFOCUS_GAIN:
            default:
                break;
        }
    }

    // ========================================================================
    // Media Button
    // ========================================================================

    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNextSong();
                return;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPreviousSong();
                return;
            }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mState == ServiceState.PAUSED) doResume();
                else if (mState == ServiceState.IDLE) resume();
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mState == ServiceState.PLAYING) doPause();
                else if (mState == ServiceState.PREPARING) mPauseAfterPrepare = true;
                break;
            default:
                break;
        }
    }

    // ========================================================================
    // Broadcasts
    // ========================================================================

    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", mGeneration);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", mState == ServiceState.PLAYING);
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());
        sendBroadcast(intent);
    }

    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    // ========================================================================
    // Receivers
    // ========================================================================

    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) stopCompletely();
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }

    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    // NotificationController observes theme changes on its
                    // own. Nothing to do here.
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response = new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", mState == ServiceState.PLAYING);
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
                        .apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }

    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) return;
                int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) return;
                mCurrentSortMode = newSortMode;
                saveSortMode();
                onMain(() -> {
                    if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
                    String anchorPath = pathOf(mCurrentIndex);
                    Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
                    if (anchorPath != null) {
                        int newIndex = indexOfPath(anchorPath);
                        if (newIndex >= 0) {
                            mCurrentIndex = newIndex;
                            saveCurrentPlayingIndex();
                        }
                    }
                    broadcastUpdate();
                });
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    /**
     * Registers the sync complete receiver.
     *
     * <p>{@code SYNC_COMPLETE} is a general "playlist changed" signal. Its
     * only effect in this service is to publish the new state.</p>
     *
     * <p>This receiver deliberately does not hide any persistent overlay.
     * Overlay ownership belongs to the operation that showed it, and every
     * such operation hides its own overlay by its own operation ID. A
     * force-hide here would race the {@code GENRE_UPDATE} overlay's show in
     * {@code FolderManager.performPlaylistUpdate()}.</p>
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) return;
                broadcastUpdate();
            }
        };
        registerReceiver(mSyncCompleteReceiver, new IntentFilter("SYNC_COMPLETE"));
    }

    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(intent.getAction())) return;
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    broadcastUpdate();
                }
            }
        };
        registerReceiver(mGenreUpdateReceiver, new IntentFilter(ACTION_GENRE_UPDATE));
    }

    private void registerSoftUpdatePlaylistReceiver() {
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    return;
                }

                if (mMusicLibrary == null) mMusicLibrary = new MusicLibrary(MusicService.this);
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiver(mSoftUpdatePlaylistReceiver, new IntentFilter("SOFT_UPDATE_PLAYLIST"));
    }

    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) setPendingSongPath(path);
                }
            }
        };
        registerReceiver(mSetPendingSongReceiver, new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    /**
     * Registers the reset player state receiver.
     *
     * <p>Reacts to the reset broadcast emitted by {@code FolderManager} when
     * the user removes the last folder and the last loose track, or when
     * the last folder is removed while loose tracks remain.</p>
     *
     * <p>When {@code preserve_settings} is false (the full-wipe case), the
     * service additionally clears its in-memory library, its playback
     * preferences (repeat mode, shuffle, sort mode). That is what makes a
     * full content removal leave nothing behind: the service has no cached
     * list and no stale preference once this receiver returns.</p>
     *
     * <p>The service owns its own teardown: this receiver is the single
     * point through which the service learns the library is now empty,
     * regardless of whether any activity is currently bound. It does not
     * depend on {@code MusicPlayer} being alive to run the reset.</p>
     *
     * <p>The equalizer preferences are intentionally not touched. The
     * user's equalizer settings must survive a full library wipe so that
     * adding folders back does not force them to reconfigure.</p>
     *
     * <p>{@link #stopCompletely()} is called first. It reaches
     * {@link #transitionToIdle()}, which writes the idle values to
     * {@code SharedPreferences} and clears the current index. The preference
     * writes below then persist the settings reset on top of an
     * already-idle state, so no stale intermediate state is observable
     * between the two.</p>
     */
    private void registerResetPlayerStateReceiver() {
        mResetPlayerStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_RESET_PLAYER_STATE.equals(intent.getAction())) {
                    return;
                }
                final boolean preserveSettings =
                    intent.getBooleanExtra("preserve_settings", false);
                Log.d(TAG, "RESET_PLAYER_STATE received (preserve_settings="
                    + preserveSettings + ")");
                onMain(() -> {
                    // Clear the state machine first. transitionToIdle()
                    // writes the idle values to SharedPreferences and
                    // clears the current index; the preference writes
                    // below then persist the settings reset on top of an
                    // already-idle state, so no stale intermediate state
                    // is observable between the two.
                    stopCompletely();

                    if (!preserveSettings) {
                        mRepeatMode = 0;
                        mIsShuffle = false;
                        mCurrentSortMode = SORT_TITLE_AZ;
                        if (mShuffleHistory != null) {
                            mShuffleHistory.clear();
                        }
                        if (mMusicLibrary != null) {
                            // Invalidate, not refresh: the folder set is now
                            // empty and this instance's cached copy of it
                            // must be dropped so a later scan does not
                            // rescan the removed folders.
                            mMusicLibrary.invalidate();
                        }
                        savePlayerState();
                        saveSortMode();
                    }
                });
            }
        };
        registerReceiver(mResetPlayerStateReceiver,
            new IntentFilter(ACTION_RESET_PLAYER_STATE));
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) return;
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }
    }

    // ========================================================================
    // Genre and Metadata Updates
    // ========================================================================

    private void updateGenreInPlaylist(@NonNull String songPath, @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath) || TextUtils.isEmpty(newGenre)) return;
        if (mCurrentPlaylist == null) return;

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                    broadcastUpdate();

                    Song currentSong = getCurrentSong();
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        updateMediaSessionMetadata(currentSong, null);
                    }
                }
                break;
            }
        }
    }

    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;

            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null || !songPath.equals(currentSong.getPath())) return;

            String finalTitle = (newTitle != null && !newTitle.isEmpty())
                ? newTitle : currentSong.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty())
                ? newArtist : currentSong.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty())
                ? newAlbum : currentSong.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty())
                ? newGenre : currentSong.getGenre();

            Song updatedSong = new Song(finalTitle, finalArtist, finalAlbum, finalGenre,
                songPath, currentSong.getDuration(), null);
            if (currentSong.getUri() != null) updatedSong.setUri(currentSong.getUri());

            mCurrentPlaylist.set(mCurrentIndex, updatedSong);
            SongDatabase.getInstance(this).insertSong(updatedSong);

            if (albumArtRemoved) {
                mArtCache.remove(songPath);
                mResolvedArtPath = songPath;
                mResolvedArt = null;
            } else if (albumArtBytes != null) {
                mArtCache.remove(songPath);
                final Bitmap newArt = BitmapFactory.decodeByteArray(
                    albumArtBytes, 0, albumArtBytes.length);
                if (newArt != null) {
                    mArtCache.put(songPath, newArt);
                    mResolvedArtPath = songPath;
                    mResolvedArt = newArt;
                }
            }

            broadcastUpdate();
            updateMediaSessionPlaybackState();
        });
    }
}