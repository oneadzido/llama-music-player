package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Owns the playback state machine, the MediaPlayer lifecycle, the media
 * session, and the persisted playback preferences.
 *
 * <p>The service runs in the background and continues playback when the
 * application is not visible. Playback orchestration is owned by a single
 * state machine: a {@link ServiceState} enum, two monotonic counters
 * ({@link #mGeneration} and {@link #mStartToken}), and a two-index model
 * ({@link #mCurrentIndex} and {@link #mTargetIndex}) hold every
 * transition-related value. State mutations happen on the main thread;
 * raw {@link MediaPlayer} calls run on a dedicated
 * {@link HandlerThread}. Only marshalled {@link Runnable}s cross between
 * them.</p>
 *
 * <p>{@link #mCurrentIndex} is the index the MediaPlayer is bound to.
 * {@link #mTargetIndex} is the index the state machine is driving toward.
 * While the state is PREPARING, {@code mCurrentIndex} still reflects the
 * outgoing song and {@code mTargetIndex} is the destination. Every
 * request method mutates {@code mTargetIndex} only;
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The service owns the playback state machine, the MediaPlayer, the
 * media session, the persisted playback preferences (repeat mode,
 * shuffle, sort mode, current index, current position, last playing flag,
 * and last song path), and the current playlist. The activity observes
 * the machine through {@code UPDATE_PLAYER} broadcasts and forwards
 * requests back to it. The notification surface is owned by
 * {@link NotificationController}: the service exposes a
 * {@link NotificationController.ServiceStateSource} that the controller
 * polls at a fixed cadence.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>{@link #onCreate()} installs the notification controller, loads the
 * persisted playback preferences, and registers every broadcast receiver
 * the service consumes. {@link #setPlaylist(ArrayList, boolean)} primes
 * the state machine with the persisted playback position and paused state
 * on the first call after process launch, so the prepared track parks in
 * READY at the retained position and a subsequent Play resumes from
 * there instead of restarting from zero. {@link #onDestroy()} saves the
 * full state, releases the MediaPlayer on its thread, tears down the
 * media session, and abandons audio focus.</p>
 *
 * <p>When the user removes every folder and every loose track, the
 * library becomes empty and the service tears itself down through its own
 * {@code RESET_PLAYER_STATE} receiver, independent of any activity.
 * {@link #transitionToIdle()} clears every field that describes "what was
 * playing", including the media session metadata, the resolved
 * notification art, the art cache, the static audio-session identifier
 * exposed to {@link EqualizerManager}, and the transport-action debounce
 * map. It also cancels the playback notification immediately through
 * {@link NotificationController#clearPlaybackNotification()}, so a full
 * wipe removes the notification without waiting for the awareness poll
 * to observe the idle state. When {@code preserve_settings} is false,
 * the receiver also clears the in-memory library, the persisted playback
 * preferences, and the released audio effects.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every state mutation runs on the main thread through
 * {@link #onMain(Runnable)}. Every raw MediaPlayer call runs on
 * {@link #mPlayerThread} through {@link #onPlayer(Runnable)}. Bitmap
 * decoding and metadata reads run on dedicated single-thread executors.
 * The audio effect manager releases and reattaches on the main thread.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — At most one {@code prepareAsync()} is in flight
 *       process-wide.</li>
 *   <li>I2 — {@link #releaseMediaPlayer()} runs only on the player
 *       thread.</li>
 *   <li>I3 — MediaPlayer callbacks whose captured generation differs from
 *       {@link #mGeneration} are inert.</li>
 *   <li>I4 — {@link #setShuffle(boolean)} and
 *       {@link #setRepeatMode(int)} touch only their own field; they
 *       never cause a transition.</li>
 *   <li>I5 — {@link #onStall()} mutates state and calls
 *       {@link #reconcile()}; it never invokes a request method.</li>
 *   <li>I6 — State fields are written only on the main thread.</li>
 *   <li>I7 — {@link #setPlaylist(ArrayList, boolean)} resolves an anchor
 *       and re-enters reconciliation; it never bypasses the gate.</li>
 *   <li>I8 — {@link #transitionToIdle()} is idempotent.</li>
 *   <li>I9 — Raw MediaPlayer calls execute only on
 *       {@link #mPlayerThread}.</li>
 *   <li>I10 — {@link #mGeneration} changes if and only if the state
 *       machine has moved on to a different song preparation.</li>
 *   <li>I11 — {@link #getCurrentSong()} reports
 *       {@link #mCurrentIndex}.</li>
 *   <li>I12 — {@link #playNextSong()} and {@link #playPreviousSong()}
 *       base their computation on {@link #mCurrentIndex}.</li>
 *   <li>I13 — The service is foreground while {@link #mState} is PLAYING
 *       and not foreground in every other state.</li>
 *   <li>I14 — The playback notification is produced by
 *       {@link NotificationController} only, from a snapshot the service
 *       has marked complete.</li>
 *   <li>I15 — Transport actions arriving through the active media session
 *       callback pass through
 *       {@link #isNotificationActionDebounced(String)}.</li>
 *   <li>I16 — {@link #mPauseAfterPrepare} is cleared by every path that
 *       ends a transition.</li>
 *   <li>I17 — {@link #mResolvedArtPath} and {@link #mResolvedArt} are
 *       written only on the main thread, after the decode callback
 *       returns, and only when the resolved path matches the state
 *       machine's authoritative song.</li>
 *   <li>I18 — {@code RESET_PLAYER_STATE} is received by this service's
 *       own receiver, independent of any activity.
 *       {@link #transitionToIdle()} leaves no field describing a song
 *       that is not in the library, and reports STATE_NONE to the
 *       media session.</li>
 *   <li>I19 — Equalizer preferences are never touched by the reset path.
 *       {@link EqualizerManager#release()} saves the settings to
 *       SharedPreferences and tears the effects down; it never removes
 *       those keys.</li>
 *   <li>I20 — The media session is active if and only if a track is
 *       bound (state is PLAYING, PAUSED, or READY). It is inactive in
 *       IDLE.</li>
 * </ul>
 *
 * <p>{@link #pause()} retains the MediaPlayer and its position;
 * {@link #resume()} restarts from that position. {@link #stop()} releases
 * the player but remembers the index in {@link #mTargetIndex}, so a
 * subsequent play re-prepares the same track from position zero.
 * {@link #stopCompletely()} tears down to IDLE and clears the playlist.</p>
 *
 * <p>The stall detector fires at {@code HEALTH_CHECK_INTERVAL_MS} and
 * treats a position below 100 ms lasting longer than
 * {@code MAX_STALL_TIME_MS} as a stall. The stall budget accrues only
 * while {@link #mState} is PLAYING. All elapsed-time math uses
 * {@link SystemClock#elapsedRealtime()}.</p>
 *
 * @see MediaPlayer
 * @see NotificationController
 * @see EqualizerManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for the persisted repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for the persisted shuffle flag. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for the persisted player-state-before-update flag. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for the persisted playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that carries a genre update. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action that sets a pending song path. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Broadcast action that carries a new audio session identifier. */
    private static final String ACTION_AUDIO_SESSION_CHANGED =
        "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Service action that resumes playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME";

    /** Broadcast action that asks the service to reset its state. */
    private static final String ACTION_RESET_PLAYER_STATE = "RESET_PLAYER_STATE";

    /** Debounce window for transport actions, in milliseconds. */
    private static final long NOTIFICATION_ACTION_DEBOUNCE_MS = 500;

    /** Interval between health checks, in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 500;

    /** Maximum position advance a healthy stream is allowed to sit idle, in milliseconds. */
    private static final int MAX_STALL_TIME_MS = 1500;

    /** Number of consecutive stalls before the service skips to the next track. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    /** Maximum duration of a continuous skip loop, in milliseconds. */
    private static final long SKIP_LOOP_BUDGET_MS = 2500L;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int NOTIFICATION_ART_MAX_PX = 300;

    /** Size of the notification album art cache, in megabytes. */
    private static final int NOTIFICATION_ART_CACHE_MB = 25;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Audio session identifier most recently attached to the equalizer. */
    private static int sCurrentAudioSessionId = 0;

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * Exhaustive states of the playback state machine.
     */
    private enum ServiceState {
        /** Nothing is bound to the MediaPlayer. */
        IDLE,

        /** A transition is in flight; the target is not yet bound. */
        PREPARING,

        /** A track is prepared but not started. */
        READY,

        /** A track is playing. */
        PLAYING,

        /** A track is prepared, paused, and retains its position. */
        PAUSED,

        /** The service is in the middle of tearing down. */
        STOPPING
    }

    /** Current state of the playback state machine. */
    private ServiceState mState = ServiceState.IDLE;

    /** Monotonic counter that identifies the current transition. */
    private long mGeneration = 0L;

    /** Monotonic counter that identifies the current start or resume continuation. */
    private long mStartToken = 0L;

    /** Index the MediaPlayer is bound to. */
    private int mCurrentIndex = -1;

    /** Index the state machine is driving toward. */
    private int mTargetIndex = -1;

    /** Position requested for the next prepare, in milliseconds. */
    private int mPendingSeekPosition = 0;

    /** True when the next reconciliation must re-prepare the current track. */
    private boolean mForceReprepare = false;

    /** True when a pause arrived during PREPARING and must be honoured at commit. */
    private boolean mPauseAfterPrepare = false;

    /** True when the prepare should start playback on completion. */
    private boolean mAutoStartOnPrepared = true;

    /** Timestamp at which the current PLAYING state began. */
    private long mPlaybackStartElapsed = 0L;

    /** Consecutive stall recovery attempts since the last healthy playback. */
    private int mRecoveryAttempts = 0;

    /** Timestamp at which the current skip loop began. */
    private long mSkipLoopStartedElapsed = 0L;

    /** Handler that runs every state mutation on the main thread. */
    private final Handler mMachineHandler = new Handler(Looper.getMainLooper());

    /** Handler for health checks; null when not monitoring. */
    private Handler mHealthHandler;

    /** Runnable for the periodic health check. */
    private Runnable mHealthCheckRunnable;

    /** Per-action timestamps used to debounce transport actions. */
    @NonNull
    private final HashMap<String, Long> mLastNotificationActionTime = new HashMap<>();

    // ========================================================================
    // MediaPlayer
    // ========================================================================

    /** MediaPlayer instance, or null when released. */
    private MediaPlayer mMediaPlayer;

    /** Thread on which every raw MediaPlayer call runs. */
    private HandlerThread mPlayerThread;

    /** Handler bound to {@link #mPlayerThread}. */
    private Handler mPlayerHandler;

    /** Wake lock held while playback is running. */
    private PowerManager.WakeLock mWakeLock;

    // ========================================================================
    // Notification Album Art
    // ========================================================================

    /** Executor that decodes notification album art. */
    private final ExecutorService mArtLoader = Executors.newSingleThreadExecutor();

    /** Cache of decoded notification album art keyed by song path. */
    private LruCache<String, Bitmap> mArtCache;

    /** Currently running notification art decode task. */
    private Future<?> mCurrentArtLoad = null;

    /** Path of the art currently resolved for the notification, or null. */
    @Nullable
    private String mResolvedArtPath = null;

    /** Bitmap currently resolved for the notification, or null. */
    @Nullable
    private Bitmap mResolvedArt = null;

    // ========================================================================
    // Notification State Source
    // ========================================================================

    /**
     * State source exposed to {@link NotificationController} for
     * rendering the playback notification.
     */
    private final NotificationController.ServiceStateSource mStateSource =
        new NotificationController.ServiceStateSource() {

            @Nullable
            @Override
            public NotificationController.RenderSnapshot snapshotForNotification() {
                if (mState == ServiceState.PREPARING || mState == ServiceState.IDLE) {
                    return null;
                }

                Song currentSong = getCurrentSong();
                if (currentSong == null) {
                    return null;
                }
                String currentPath = currentSong.getPath();
                if (currentPath == null) {
                    return null;
                }

                final boolean artResolved = currentPath.equals(mResolvedArtPath);
                final Bitmap resolvedArt = artResolved ? mResolvedArt : null;

                return new NotificationController.RenderSnapshot(
                    currentSong.getTitle(),
                    currentSong.getArtist(),
                    currentPath,
                    mState == ServiceState.PLAYING,
                    resolvedArt,
                    artResolved);
            }

            @Override
            public boolean isIdle() {
                return mState == ServiceState.IDLE;
            }
        };

    // ========================================================================
    // Cached Playback Facts
    // ========================================================================

    /** Duration of the currently prepared track, in milliseconds. */
    private int mCachedDuration = 0;

    /** Audio session identifier of the currently prepared track. */
    private int mCachedAudioSessionId = 0;

    /** Most recently observed playback position, in milliseconds. */
    private int mCachedPosition = 0;

    /** Playback position at the moment playback last started or resumed. */
    private int mPlaybackBasePosition = 0;

    /** Timestamp at which playback last started or resumed. */
    private long mPlaybackBaseElapsed = 0L;

    /** Counter incremented by every position invalidation. */
    private long mPositionEpoch = 0L;

    // ========================================================================
    // Playlist and Playback State
    // ========================================================================

    /** Current playlist, or null before the first assignment. */
    private ArrayList<Song> mCurrentPlaylist;

    /** True while the state machine is in PLAYING. */
    private volatile boolean mIsPlaying = false;

    /** Current repeat mode: 0 for off, 1 for all, 2 for one. */
    private volatile int mRepeatMode = 0;

    /** True while shuffle is enabled. */
    private volatile boolean mIsShuffle = false;

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** History of shuffle picks; used to implement previous under shuffle. */
    private ArrayList<Integer> mShuffleHistory;

    /** Source of randomness for shuffle selection. */
    private Random mRandom;

    /** Song path queued for playback once it enters the playlist, or null. */
    private volatile String mPendingSongPath = null;

    // ========================================================================
    // Binder, Library, Notification Controller
    // ========================================================================

    /** Binder returned to bound clients. */
    private final IBinder mBinder = new LocalBinder();

    /** In-memory library used to resolve songs on request. */
    private MusicLibrary mMusicLibrary;

    /** Controller that owns every notification surface, or null before onCreate. */
    @Nullable
    private NotificationController mNotificationController;

    // ========================================================================
    // Audio Focus and Session
    // ========================================================================

    /** System audio manager. */
    private AudioManager mAudioManager;

    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;

    /** Audio focus request used on API 26 and later. */
    private AudioFocusRequest mAudioFocusRequest;

    /** Active media session, or null before setup. */
    private MediaSessionCompat mMediaSession;

    /** True while a Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    /** Receiver for playback parameter update broadcasts. */
    private BroadcastReceiver mPlaybackParamsReceiver;

    /** Receiver for playlist clear broadcasts. */
    private BroadcastReceiver mClearPlaylistReceiver;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    /** Receiver for playing state query broadcasts. */
    private BroadcastReceiver mGetPlayingStateReceiver;

    /** Receiver for sort mode change broadcasts. */
    private BroadcastReceiver mSortModeReceiver;

    /** Receiver for sync completion broadcasts. */
    private BroadcastReceiver mSyncCompleteReceiver;

    /** Receiver for genre update broadcasts. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for soft playlist update broadcasts. */
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;

    /** Receiver for pending song path broadcasts. */
    private BroadcastReceiver mSetPendingSongReceiver;

    /** Receiver for player state reset broadcasts. */
    private BroadcastReceiver mResetPlayerStateReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Binder returned from {@link #onBind(Intent)}.
     */
    public class LocalBinder extends Binder {

        /**
         * Returns the service instance.
         *
         * @return The bound service
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Sort Comparators
    // ========================================================================

    /**
     * Orders songs by title, ascending.
     */
    private class TitleAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, ascending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong}'s title orders before, equal to, or
         *         after {@code secondSong}'s title
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    /**
     * Orders songs by title, descending.
     */
    private class TitleZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, descending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong}'s title orders after, equal to, or
         *         before {@code secondSong}'s title
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    /**
     * Orders songs by artist, ascending, with title as the tiebreaker.
     */
    private class ArtistAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, ascending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders before, equal to, or after
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by artist, descending, with title as the tiebreaker.
     */
    private class ArtistZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, descending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders after, equal to, or before
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null ? "" : secondSong.getArtist();
            int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, ascending, with title as the tiebreaker.
     */
    private class AlbumAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, ascending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders before, equal to, or after
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, descending, with title as the tiebreaker.
     */
    private class AlbumZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, descending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders after, equal to, or before
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null ? "" : secondSong.getAlbum();
            int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, ascending, with title as the tiebreaker.
     */
    private class GenreAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, ascending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders before, equal to, or after
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, descending, with title as the tiebreaker.
     */
    private class GenreZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, descending, ignoring case.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} orders after, equal to, or before
         *         {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null ? "" : secondSong.getGenre();
            int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, oldest first, with title as
     * the tiebreaker.
     */
    private class OldestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, oldest first.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} is older than, the same age as, or
         *         newer than {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, newest first, with title as
     * the tiebreaker.
     */
    private class NewestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, newest first.
         *
         * @param firstSong First song to compare
         * @param secondSong Second song to compare
         * @return A negative integer, zero, or a positive integer when
         *         {@code firstSong} is newer than, the same age as, or
         *         older than {@code secondSong}
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator().compare(firstSong, secondSong);
        }
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch, or 0
     *         when the path is null
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) {
            return 0;
        }
        return new File(song.getPath()).lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the given
     * sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ========================================================================
    // Static Helpers
    // ========================================================================

    /**
     * Persists the player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @param need New value of the flag
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    /**
     * Returns the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @return True when the flag is set
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the audio session identifier most recently attached to the
     * equalizer.
     *
     * @return The current audio session identifier, or 0 when none is
     *         attached
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ========================================================================
    // Service Lifecycle
    // ========================================================================

    /**
     * Initializes the service: installs the notification controller,
     * loads persisted preferences, sets up the media session and audio
     * focus, starts the player thread, and registers every receiver.
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        final int artCacheSize = NOTIFICATION_ART_CACHE_MB * 1024 * 1024;
        mArtCache = new LruCache<String, Bitmap>(artCacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mPlayerThread = new HandlerThread("MediaPlayerThread");
        mPlayerThread.start();
        mPlayerHandler = new Handler(mPlayerThread.getLooper());

        mNotificationController = NotificationController.getInstance(this);
        mNotificationController.attachService(this);
        mNotificationController.setStateSource(mStateSource);
        mNotificationController.setSessionTokenProvider(this::getSessionToken);

        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();
        setupMediaSession();
        setupAudioFocus();

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerSoftUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();
        registerResetPlayerStateReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    /**
     * Handles a start command from an intent, dispatching on its action
     * and starting foreground service synchronisation.
     *
     * @param intent The intent delivered to the service, or null
     * @param flags Additional data about the start request
     * @param startId Unique identifier for the start request
     * @return The sticky restart mode
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }

        if (intent != null && intent.getAction() != null) {
            final String action = intent.getAction();

            if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
                KeyEvent event;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent.class);
                } else {
                    @SuppressWarnings("deprecation")
                    KeyEvent deprecatedEvent =
                        intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                    event = deprecatedEvent;
                }
                if (event != null && event.getAction() == KeyEvent.ACTION_DOWN
                        && mMediaSession != null) {
                    mMediaSession.getController().dispatchMediaButtonEvent(event);
                }
                return START_STICKY;
            }

            if (isNotificationActionDebounced(action)) {
                return START_STICKY;
            }

            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNextSong();
            } else if (action.equals("ACTION_PREV")) {
                playPreviousSong();
            } else if (action.equals("ACTION_STOP")) {
                pause();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationController != null) {
                    mNotificationController.demoteFromForeground();
                }
            } else if (action.equals(ACTION_BLUETOOTH_RESUME)) {
                handleBluetoothResume();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    /**
     * Returns whether the given transport action arrived inside the
     * debounce window.
     *
     * @param action Transport action to test
     * @return True when the action is inside the debounce window and
     *         should be ignored
     */
    private boolean isNotificationActionDebounced(@NonNull String action) {
        if (!"ACTION_PLAY_PAUSE".equals(action)
                && !"ACTION_NEXT".equals(action)
                && !"ACTION_PREV".equals(action)) {
            return false;
        }
        final long now = SystemClock.elapsedRealtime();
        final Long last = mLastNotificationActionTime.get(action);
        if (last != null && now - last < NOTIFICATION_ACTION_DEBOUNCE_MS) {
            return true;
        }
        mLastNotificationActionTime.put(action, now);
        return false;
    }

    /**
     * Handles a Bluetooth resume request by preparing the last played
     * song, resuming playback, and reloading the full library in the
     * background.
     */
    private void handleBluetoothResume() {
        onMain(() -> {
            final String lastPath = getSavedSongPath();
            if (lastPath == null || !new File(lastPath).exists()) {
                transitionToIdle();
                stopSelf();
                return;
            }

            Song lastSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (lastSong == null) {
                lastSong = CharacterMapper.getSongFromFile(lastPath);
            }
            if (lastSong == null) {
                transitionToIdle();
                stopSelf();
                return;
            }

            final ArrayList<Song> singleSong = new ArrayList<>();
            singleSong.add(lastSong);
            setPlaylist(singleSong, true);
            resume();

            if (mMusicLibrary == null) {
                mMusicLibrary = new MusicLibrary(this);
            }
            mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
                @Override
                public void onSongsLoaded(ArrayList<Song> songs) {
                    onMain(() -> {
                        if (songs != null && !songs.isEmpty()) {
                            setPlaylist(songs, true);
                        }
                    });
                }

                @Override
                public void onLoadingError(String error) {
                    Log.w(TAG, "Full library load after BT resume failed: " + error);
                }
            });
        });
    }

    /**
     * Returns the binder that exposes this service to bound clients.
     *
     * @param intent The intent that triggered the bind
     * @return The local binder
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /**
     * Releases every resource held by the service: the player, the
     * player thread, the wake lock, the notification controller, the
     * media session, audio focus, handlers, and receivers.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtLoader != null && !mArtLoader.isShutdown()) {
            mArtLoader.shutdownNow();
        }

        if (mPlayerHandler != null) {
            mPlayerHandler.post(this::releaseMediaPlayer);
        }
        if (mPlayerThread != null) {
            mPlayerThread.quitSafely();
            try {
                mPlayerThread.join(2000);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            mPlayerThread = null;
            mPlayerHandler = null;
        }

        releaseWakeLock();
        mIsPlaying = false;
        mState = ServiceState.STOPPING;

        if (mNotificationController != null) {
            mNotificationController.detachService();
            mNotificationController = null;
        }

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMachineHandler != null) {
            mMachineHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);
        unregisterReceiverSafely(mResetPlayerStateReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    /**
     * Forwards the trim-memory signal to the current state machine.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(this::reconcile);
    }

    /**
     * Saves the full player state before the task is removed.
     *
     * @param rootIntent The root intent of the removed task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ========================================================================
    // Thread Marshalling and Small Helpers
    // ========================================================================

    /**
     * Runs the given action on the main thread.
     *
     * @param action Action to run
     */
    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action.run();
        } else {
            mMachineHandler.post(action);
        }
    }

    /**
     * Runs the given action on the player thread.
     *
     * @param action Action to run
     */
    private void onPlayer(@NonNull Runnable action) {
        if (mPlayerHandler == null) {
            return;
        }
        if (Looper.myLooper() == mPlayerHandler.getLooper()) {
            action.run();
        } else {
            mPlayerHandler.post(action);
        }
    }

    /**
     * Returns the size of the current playlist.
     *
     * @return The playlist size, or 0 when no playlist is loaded
     */
    private int playlistSize() {
        return mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0;
    }

    /**
     * Returns whether the current playlist is empty.
     *
     * @return True when the playlist is null or empty
     */
    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    /**
     * Returns the path of the song at the given index, or null when the
     * index is out of range.
     *
     * @param index Playlist index to inspect
     * @return The song path, or null
     */
    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) {
            return null;
        }
        if (index < 0 || index >= mCurrentPlaylist.size()) {
            return null;
        }
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    /**
     * Returns the playlist index of the song with the given path, or -1
     * when it is not in the playlist.
     *
     * @param path Song path to search for, or null
     * @return The playlist index, or -1
     */
    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Acquires the partial wake lock, ignoring any failure.
     */
    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try {
                mWakeLock.acquire();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    /**
     * Releases the partial wake lock, ignoring any failure.
     */
    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    /**
     * Estimates the current playback position from the cached base and
     * elapsed time.
     *
     * @return Estimated position in milliseconds
     */
    private int estimateCurrentPosition() {
        if (mState == ServiceState.PLAYING && mPlaybackBaseElapsed > 0L) {
            long elapsedDuration = SystemClock.elapsedRealtime() - mPlaybackBaseElapsed;
            long estimatedDuration = mPlaybackBasePosition + elapsedDuration;
            if (mCachedDuration > 0 && estimatedDuration > mCachedDuration) {
                return mCachedDuration;
            }
            return (int) estimatedDuration;
        }
        return mCachedPosition;
    }

    /**
     * Returns whether the current skip loop has exceeded its budget.
     *
     * @return True when the skip loop has run past
     *         {@link #SKIP_LOOP_BUDGET_MS}
     */
    private boolean skipBudgetExhausted() {
        long currentTime = SystemClock.elapsedRealtime();
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = currentTime;
            return false;
        }
        return (currentTime - mSkipLoopStartedElapsed) >= SKIP_LOOP_BUDGET_MS;
    }

    /**
     * Abandons the current skip loop, transitions to IDLE, and broadcasts
     * the resulting state.
     */
    private void abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after "
            + (SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed) + " ms");
        mSkipLoopStartedElapsed = 0L;
        mPauseAfterPrepare = false;
        mForceReprepare = false;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mIsPlaying = false;
        mCurrentIndex = -1;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // Notification Album Art Prefetch
    // ========================================================================

    /**
     * Loads the notification art for the given song, using the LRU cache
     * when available.
     *
     * @param song Song to prefetch art for, or null
     */
    private void prefetchNotificationArt(@Nullable Song song) {
        if (song == null || song.getPath() == null) {
            return;
        }

        final String path = song.getPath();

        if (mArtCache.get(path) != null) {
            mResolvedArtPath = path;
            mResolvedArt = mArtCache.get(path);
            return;
        }

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }

        mCurrentArtLoad = mArtLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap art = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    byte[] bytes = retriever.getEmbeddedPicture();
                    if (bytes != null && !Thread.currentThread().isInterrupted()) {
                        art = decodeNotificationArt(bytes);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Notification art prefetch failed for " + path, exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception ignored) {
                            // The retriever is not in a state that permits release.
                        }
                    }
                }

                if (art != null && !Thread.currentThread().isInterrupted()) {
                    mArtCache.put(path, art);
                }

                final Bitmap finalArt = art;
                onMain(() -> {
                    final String expectedPath;
                    if (mState == ServiceState.PREPARING) {
                        expectedPath = pathOf(mTargetIndex);
                    } else {
                        expectedPath = pathOf(mCurrentIndex);
                    }
                    if (expectedPath == null || !path.equals(expectedPath)) {
                        return;
                    }
                    mResolvedArtPath = path;
                    mResolvedArt = finalArt;
                });
            }
        });
    }

    /**
     * Decodes the given image bytes into a notification-sized bitmap.
     *
     * @param data Image bytes to decode
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeNotificationArt(@NonNull byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);

        int sampleSize = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) {
            sampleSize *= 2;
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sampleSize;
        return BitmapFactory.decodeByteArray(data, 0, data.length, decode);
    }

    // ========================================================================
    // Pure Functions
    // ========================================================================

    /**
     * Returns the index that follows the given index under the current
     * shuffle and repeat mode.
     *
     * @param fromIndex Index to advance from
     * @return The next index
     */
    private int computeNext(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return pickShuffleNext(fromIndex);
        }
        return (fromIndex + 1) % playlistSize();
    }

    /**
     * Returns the index that precedes the given index under the current
     * shuffle and repeat mode.
     *
     * @param fromIndex Index to retreat from
     * @return The previous index
     */
    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return popShuffleHistory(fromIndex);
        }
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    /**
     * Picks the next index under shuffle and pushes it onto the shuffle
     * history.
     *
     * @param fromIndex Index to advance from
     * @return The picked index
     */
    private int pickShuffleNext(int fromIndex) {
        int size = playlistSize();
        if (size <= 1) {
            return fromIndex;
        }

        if (mShuffleHistory == null) {
            mShuffleHistory = new ArrayList<Integer>();
        }
        if (mShuffleHistory.size() >= size * 2) {
            mShuffleHistory.clear();
        }
        if (mRandom == null) {
            mRandom = new Random();
        }

        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);

        mShuffleHistory.add(candidate);
        return candidate;
    }

    /**
     * Pops the previous index off the shuffle history, or picks a new one
     * when the history is empty.
     *
     * @param fromIndex Index to retreat from
     * @return The previous index
     */
    private int popShuffleHistory(int fromIndex) {
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int previousIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
            if (previousIndex >= 0 && previousIndex < playlistSize()) {
                return previousIndex;
            }
        }
        int size = playlistSize();
        if (size <= 1) {
            return fromIndex;
        }
        if (mRandom == null) {
            mRandom = new Random();
        }
        int candidate;
        int guard = 0;
        do {
            candidate = mRandom.nextInt(size);
            guard++;
        } while (candidate == fromIndex && guard < 8);
        return candidate;
    }

    // ========================================================================
    // Core: Reconcile and Transition
    // ========================================================================

    /**
     * Begins a transition when one is warranted by the current target and
     * state.
     *
     * <p>Returns immediately when the state machine is mid-transition, is
     * tearing down, or already bound to the target. Otherwise it clears
     * the reprepare flag and calls
     * {@link #beginTransition(int, int)}.</p>
     */
    private void reconcile() {
        if (mState == ServiceState.STOPPING) {
            return;
        }
        if (mState == ServiceState.PREPARING) {
            return;
        }
        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) {
            return;
        }

        boolean need = (mTargetIndex != mCurrentIndex) || mForceReprepare;
        if (!need) {
            return;
        }

        mForceReprepare = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    /**
     * Starts a new transition toward the given index, captures a fresh
     * generation, and dispatches {@code prepareAsync} on the player
     * thread.
     *
     * <p>A null or empty path advances to the next track under the skip
     * budget. A player error at any of the raw MediaPlayer calls is
     * handled by releasing the player, checking the skip budget, and
     * re-entering {@link #reconcile()} on the main thread. Every
     * callback installed on the player captures the generation value
     * {@link #mGeneration} held at the moment of this call, so a stale
     * callback is inert.</p>
     *
     * @param index Playlist index to prepare
     * @param seekPosition Position at which the prepared track must park,
     *        in milliseconds
     */
    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) {
            return;
        }
        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (index < 0 || index >= playlistSize()) {
            return;
        }

        final long generation = ++mGeneration;
        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            mState = ServiceState.IDLE;
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(index);
            mMachineHandler.post(this::reconcile);
            return;
        }

        prefetchNotificationArt(song);

        final String path = song.getPath();
        final int committedIndex = index;
        final long capturedGeneration = generation;

        onPlayer(() -> {
            releaseMediaPlayer();
            final MediaPlayer player = getOrCreatePlayerRaw();
            removeAllListeners(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            try {
                player.setDataSource(path);
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + path, exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
                return;
            }

            player.setOnPreparedListener(mediaPlayer -> {
                final int duration;
                final int audioSessionId;
                try {
                    duration = mediaPlayer.getDuration();
                    audioSessionId = mediaPlayer.getAudioSessionId();
                } catch (Exception exception) {
                    mMachineHandler.post(() ->
                        onPrepareFailed(capturedGeneration, committedIndex));
                    return;
                }
                mMachineHandler.post(() -> onPrepared(
                    capturedGeneration, duration, audioSessionId, song, committedIndex));
            });

            player.setOnCompletionListener(mediaPlayer ->
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onCompletion();
                }));

            player.setOnErrorListener((mediaPlayer, what, extra) -> {
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onPlayerError(what, extra);
                });
                return true;
            });

            try {
                player.prepareAsync();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "prepareAsync failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    mMachineHandler.post(this::reconcile);
                });
            }
        });
    }

    /**
     * Tears the state machine down to IDLE and clears every field that
     * describes "what was playing".
     *
     * <p>Idempotent. Captures a fresh generation so any in-flight prepare
     * callback is discarded. Clears the playlist, the shuffle history,
     * the resolved notification art, the transport debounce map, and the
     * static audio session identifier. Releases the MediaPlayer on its
     * thread, releases the wake lock, releases the audio effects, writes
     * the idle values to SharedPreferences, cancels the playback
     * notification immediately, clears the media session metadata, and
     * deactivates the media session.</p>
     */
    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) {
            return;
        }

        if (mState == ServiceState.IDLE
                && mCurrentPlaylist == null
                && mCurrentIndex == -1
                && mTargetIndex == -1) {
            return;
        }

        mState = ServiceState.STOPPING;
        mGeneration++;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mPauseAfterPrepare = false;
        mForceReprepare = false;
        mSkipLoopStartedElapsed = 0L;
        mCurrentIndex = -1;
        mPendingSongPath = null;

        mCachedPosition = 0;
        mCachedDuration = 0;
        mCachedAudioSessionId = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;
        mPositionEpoch++;

        mResolvedArtPath = null;
        mResolvedArt = null;
        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtCache != null) {
            mArtCache.evictAll();
        }

        mLastNotificationActionTime.clear();

        stopHealthMonitoring();

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentPlaylist = null;
        mIsPlaying = false;
        if (mShuffleHistory != null) {
            mShuffleHistory.clear();
        }

        // Full release rather than detach: the audio effects have no session
        // to drive. release() saves the user's settings to SharedPreferences
        // before tearing down, so a later reattach restores them.
        EqualizerManager.getInstance(this).release();

        sCurrentAudioSessionId = 0;

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        if (mNotificationController != null) {
            // Cancel the playback notification immediately. The awareness
            // poll in NotificationController would eventually observe the
            // idle state and clear the notification on its own, but a full
            // library wipe expects the notification gone at once rather
            // than on the next poll tick. clearPlaybackNotification also
            // resets the rendered state to resting so the next non-idle
            // snapshot renders from a clean baseline.
            mNotificationController.clearPlaybackNotification();
        }

        updateMediaSessionMetadata(null, null);

        // Deactivate the session so the system media controls drop the app
        // from their active sessions list. Reactivated in
        // onPlaybackStarted() and in the READY branch of onPrepared().
        // Leaving it active would surface a stale entry in the shade's
        // media carousel even though nothing is loaded.
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(false);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to deactivate MediaSession", exception);
            }
        }

        mState = ServiceState.IDLE;
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    // ========================================================================
    // MediaPlayer Callbacks
    // ========================================================================

    /**
     * Handles a successful {@code prepareAsync} callback on the main
     * thread.
     *
     * <p>Discards the callback when the generation has moved on or the
     * state is no longer PREPARING. Applies a pending seek when one is
     * set. When {@link #mPauseAfterPrepare} is set, the track parks in
     * READY without starting, so a subsequent Play resumes from the
     * retained position. Otherwise the track is started on the player
     * thread and {@link #onPlaybackStarted(long, int, Song, int)} is
     * called when the start completes.</p>
     *
     * @param generation Generation captured by the prepare callback
     * @param duration Duration of the prepared track, in milliseconds
     * @param audioSessionId Audio session identifier of the prepared
     *        track
     * @param song Song that was prepared
     * @param committedIndex Playlist index the track was prepared from
     */
    private void onPrepared(long generation, int duration, int audioSessionId,
                            @NonNull Song song, int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        if (duration <= 0) {
            onPrepareFailed(generation, committedIndex);
            return;
        }

        int seekPosition = mPendingSeekPosition;
        mPendingSeekPosition = 0;

        mSkipLoopStartedElapsed = 0L;
        mCachedDuration = duration;
        mCachedAudioSessionId = audioSessionId;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        sCurrentAudioSessionId = audioSessionId;
        broadcastAudioSessionChanged(audioSessionId);
        EqualizerManager.getInstance(this).attachToAudioSession(audioSessionId);

        mCurrentIndex = committedIndex;

        if (mPauseAfterPrepare) {
            mPauseAfterPrepare = false;
            mAutoStartOnPrepared = false;
        }

        if (!mAutoStartOnPrepared) {
            if (seekPosition > 0 && seekPosition < duration - 500) {
                final int finalSeekPosition = seekPosition;
                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player != null) {
                        try {
                            player.seekTo(finalSeekPosition);
                        } catch (Exception ignored) {
                            // The player is not in a state that permits seeking.
                        }
                    }
                });
                mCachedPosition = seekPosition;
                mPlaybackBasePosition = seekPosition;
            }

            mState = ServiceState.READY;
            mRecoveryAttempts = 0;

            // A track is now bound, so the session must be active: the
            // READY state is visible to the system media controls and a
            // subsequent Play must resume without reactivating.
            if (mMediaSession != null) {
                try {
                    mMediaSession.setActive(true);
                } catch (Exception ignored) {
                    // The session is not in a state that permits activation.
                }
            }

            updateMediaSessionMetadata(song, null);
            updateMediaSessionPlaybackState();
            saveCurrentPlayingIndex();
            broadcastUpdate();
            return;
        }

        final int doSeek = (seekPosition > 0 && seekPosition < duration - 500)
            ? seekPosition : 0;
        final long capturedGeneration = generation;
        final Song capturedSong = song;
        final int capturedIndex = committedIndex;
        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            if (doSeek > 0) {
                try {
                    player.seekTo(doSeek);
                } catch (Exception ignored) {
                    // The player is not in a state that permits seeking.
                }
            }
            try {
                player.start();
            } catch (Exception exception) {
                Log.e(TAG, "onPrepared: start() failed", exception);
                releaseMediaPlayer();
                mMachineHandler.post(() ->
                    onPrepareFailed(capturedGeneration, capturedIndex));
                return;
            }
            final long finalCapturedStartToken = capturedStartToken;
            mMachineHandler.post(() -> {
                if (finalCapturedStartToken != mStartToken) {
                    return;
                }
                onPlaybackStarted(capturedGeneration, capturedIndex, capturedSong, doSeek);
            });
        });
    }

    /**
     * Commits the transition to PLAYING and starts the notification, the
     * wake lock, audio focus, and the health monitor.
     *
     * @param generation Generation captured by the prepare callback
     * @param committedIndex Playlist index the track was prepared from
     * @param song Song that started playing
     * @param seekPosition Position at which playback began, in
     *        milliseconds
     */
    private void onPlaybackStarted(long generation, int committedIndex,
                                   @NonNull Song song, int seekPosition) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBasePosition = seekPosition;
        mPlaybackBaseElapsed = mPlaybackStartElapsed;
        mCachedPosition = seekPosition;
        mRecoveryAttempts = 0;

        acquireWakeLock();
        requestAudioFocus();

        // A track is bound and playing, so the session must be active.
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits activation.
            }
        }

        updatePlaybackParams();
        updateMediaSessionMetadata(song, null);
        updateMediaSessionPlaybackState();
        saveCurrentPlayingIndex();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }

        if (mTargetIndex != mCurrentIndex || mForceReprepare) {
            mMachineHandler.post(this::reconcile);
        }
    }

    /**
     * Handles a failed prepare by checking the skip budget and advancing
     * to the next track.
     *
     * @param generation Generation captured by the prepare callback
     * @param committedIndex Playlist index the failed prepare targeted
     */
    private void onPrepareFailed(long generation, int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        onPlayer(this::releaseMediaPlayer);
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }
        mTargetIndex = computeNext(committedIndex);
        mMachineHandler.post(this::reconcile);
    }

    /**
     * Advances to the next track when the current track completes.
     *
     * <p>Honours the repeat mode: repeat-one repeats the current track,
     * repeat-all advances through the list, and repeat-off parks on the
     * last track in PAUSED at position zero when the end of the list is
     * reached.</p>
     */
    private void onCompletion() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }

        int fromIndex = mCurrentIndex;
        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mRepeatMode == 1) {
            nextIndex = computeNext(fromIndex);
        } else if (fromIndex + 1 < playlistSize()) {
            nextIndex = fromIndex + 1;
        } else {
            mState = ServiceState.PAUSED;
            mTargetIndex = fromIndex;
            mPendingSeekPosition = 0;
            mIsPlaying = false;
            mCachedPosition = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            onPlayer(() -> {
                final MediaPlayer player = mMediaPlayer;
                if (player == null) {
                    return;
                }
                try {
                    player.pause();
                } catch (Exception ignored) {
                    // The player is not in a state that permits pausing.
                }
                try {
                    player.seekTo(0);
                } catch (Exception ignored) {
                    // The player is not in a state that permits seeking.
                }
            });

            releaseWakeLock();
            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            return;
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        mMachineHandler.post(this::reconcile);
    }

    /**
     * Handles a MediaPlayer error by checking the skip budget and
     * advancing to the next track.
     *
     * @param what The error type reported by the player
     * @param extra An additional error code reported by the player
     */
    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);

        mIsPlaying = false;
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }

        if (mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        mMachineHandler.post(this::reconcile);
    }

    /**
     * Reacts to a detected playback stall by either re-preparing the
     * current track from the persisted position or, after
     * {@link #MAX_RECOVERY_ATTEMPTS} attempts, advancing to the next
     * track.
     */
    private void onStall() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) {
                transitionToIdle();
                return;
            }
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
        } else {
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
        }

        reconcile();
    }

    // ========================================================================
    // Health Monitoring
    // ========================================================================

    /**
     * Installs the runnable used by {@link #startHealthMonitoring()}.
     */
    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mState == ServiceState.PLAYING) {
                    refreshPositionFromPlayer();
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    /**
     * Reads the current position from the player and detects stalls.
     *
     * <p>The read runs on the player thread. The result is applied on the
     * main thread only when the position epoch is unchanged and the state
     * is still PLAYING. A position below 100 ms that persists longer than
     * {@link #MAX_STALL_TIME_MS} is treated as a stall.</p>
     */
    private void refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        final long epoch = mPositionEpoch;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }

            final int position;
            try {
                position = player.getCurrentPosition();
            } catch (Exception exception) {
                return;
            }

            mMachineHandler.post(() -> {
                if (epoch != mPositionEpoch) {
                    return;
                }
                if (mState != ServiceState.PLAYING) {
                    return;
                }

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime();

                long elapsedDuration =
                    SystemClock.elapsedRealtime() - mPlaybackStartElapsed;
                if (position < 100 && elapsedDuration > MAX_STALL_TIME_MS) {
                    onStall();
                } else if (position >= 100) {
                    mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                }
            });
        });
    }

    /**
     * Starts the periodic health check.
     */
    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    /**
     * Cancels any pending health check.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ========================================================================
    // Public Request API
    // ========================================================================

    /**
     * Requests playback of the song at the given index.
     *
     * @param index Playlist index to play
     */
    public void playSong(int index) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given index, starting at the
     * given position.
     *
     * @param index Playlist index to play
     * @param position Position at which playback must begin, in
     *        milliseconds
     */
    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given path.
     *
     * <p>When the path is present in the playlist, the request proceeds
     * immediately. When it is not, the path is parked in
     * {@link #mPendingSongPath} and played once it enters the
     * playlist.</p>
     *
     * @param filePath Absolute path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG, "playSongByPath: not in playlist, parked: " + filePath);
            }
        });
    }

    /**
     * Requests playback of the next song.
     *
     * <p>The next index is computed from {@link #mCurrentIndex}, so a
     * rapid sequence of NEXT requests during a transition collapses to a
     * single advance.</p>
     */
    public void playNextSong() {
        onMain(() -> {
            if (playlistEmpty()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }
            mTargetIndex = computeNext(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests playback of the previous song.
     *
     * <p>The previous index is computed from {@link #mCurrentIndex}, so a
     * rapid sequence of PREV requests during a transition collapses to a
     * single retreat.</p>
     */
    public void playPreviousSong() {
        onMain(() -> {
            if (playlistEmpty()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }
            mTargetIndex = computePrevious(baseIndex);
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Toggles between playing and paused according to the current state.
     *
     * <p>In READY, starts playback and commits PLAYING. In IDLE, begins a
     * transition toward the current or first index. In PREPARING,
     * records the pause request in {@link #mPauseAfterPrepare} so it is
     * honoured when the transition commits.</p>
     */
    public void togglePlayPause() {
        onMain(() -> {
            switch (mState) {
                case PLAYING:
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY: {
                    final long capturedStartToken = ++mStartToken;
                    onPlayer(() -> {
                        final MediaPlayer player = mMediaPlayer;
                        boolean started = false;
                        if (player != null) {
                            try {
                                player.start();
                                started = true;
                            } catch (Exception exception) {
                                Log.e(TAG, "start() failed from READY", exception);
                            }
                        }
                        final boolean finalStarted = started;
                        mMachineHandler.post(() -> {
                            if (capturedStartToken != mStartToken) {
                                return;
                            }
                            if (!finalStarted) {
                                mState = ServiceState.IDLE;
                                onPlayer(this::releaseMediaPlayer);
                                broadcastUpdate();
                                return;
                            }
                            mState = ServiceState.PLAYING;
                            mIsPlaying = true;
                            mPlaybackStartElapsed = SystemClock.elapsedRealtime();
                            mPlaybackBaseElapsed = mPlaybackStartElapsed;
                            acquireWakeLock();
                            requestAudioFocus();
                            if (mMediaSession != null) {
                                try {
                                    mMediaSession.setActive(true);
                                } catch (Exception ignored) {
                                    // The session is not in a state that
                                    // permits activation.
                                }
                            }
                            updatePlaybackParams();
                            savePlayingState();
                            savePlayerState();
                            startHealthMonitoring();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();

                            if (mNotificationController != null) {
                                mNotificationController.startForegroundSync();
                            }
                        });
                    });
                    break;
                }
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        return;
                    }
                    mSkipLoopStartedElapsed = 0L;
                    if (mTargetIndex < 0) {
                        mTargetIndex = 0;
                    }
                    reconcile();
                    break;
                case PREPARING:
                    mPauseAfterPrepare = true;
                    break;
                case STOPPING:
                    break;
            }
        });
    }

    /**
     * Requests a pause.
     *
     * <p>In PLAYING, pauses playback. In PREPARING, records the pause
     * request so it is honoured when the transition commits. In every
     * other state, does nothing.</p>
     */
    public void pause() {
        onMain(() -> {
            if (mState == ServiceState.PLAYING) {
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        });
    }

    /**
     * Requests a resume.
     *
     * <p>In PAUSED, resumes playback. In READY, starts playback through
     * {@link #togglePlayPause()}. In IDLE, begins a transition toward the
     * current or first index.</p>
     */
    public void resume() {
        onMain(() -> {
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                mSkipLoopStartedElapsed = 0L;
                if (mTargetIndex < 0 && !playlistEmpty()) {
                    mTargetIndex = 0;
                }
                reconcile();
            }
        });
    }

    /**
     * Releases the player but remembers the current index so a subsequent
     * play re-prepares the same track from position zero.
     */
    public void stop() {
        onMain(() -> {
            if (mState != ServiceState.PLAYING && mState != ServiceState.PAUSED) {
                return;
            }

            int stoppedAtIndex = mCurrentIndex;

            onPlayer(this::releaseMediaPlayer);
            releaseWakeLock();

            mIsPlaying = false;
            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;
            mPendingSeekPosition = 0;
            mPauseAfterPrepare = false;
            mForceReprepare = false;
            mSkipLoopStartedElapsed = 0L;
            mState = ServiceState.IDLE;

            mCachedPosition = 0;
            mCachedDuration = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
        });
    }

    /**
     * Tears down to IDLE and clears the playlist.
     */
    public void stopCompletely() {
        onMain(this::transitionToIdle);
    }

    /**
     * Pauses the player, updates the cached position, saves state,
     * broadcasts the change, and demotes the notification from the
     * foreground.
     */
    private void doPause() {
        final int position = estimateCurrentPosition();

        mState = ServiceState.PAUSED;
        mIsPlaying = false;
        mCachedPosition = position;
        mPlaybackBasePosition = position;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                player.pause();
            } catch (Exception ignored) {
                // The player is not in a state that permits pausing.
            }
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();

        if (mNotificationController != null) {
            mNotificationController.demoteFromForeground();
        }
    }

    /**
     * Resumes the player, reacquires audio focus, and commits PLAYING on
     * success.
     */
    private void doResume() {
        requestAudioFocus();
        updatePlaybackParams();

        final long capturedStartToken = ++mStartToken;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            boolean started = false;
            if (player != null) {
                try {
                    player.start();
                    started = true;
                } catch (Exception exception) {
                    Log.e(TAG, "resume: start() failed", exception);
                }
            }
            final boolean finalStarted = started;
            mMachineHandler.post(() -> {
                if (capturedStartToken != mStartToken) {
                    return;
                }
                if (finalStarted) {
                    onPlaybackResumed();
                } else {
                    mState = ServiceState.IDLE;
                    onPlayer(this::releaseMediaPlayer);
                    broadcastUpdate();
                    reconcile();
                }
            });
        });
    }

    /**
     * Commits the resume: sets PLAYING, acquires the wake lock, reactivates
     * the media session, saves state, and starts the foreground
     * notification.
     */
    private void onPlaybackResumed() {
        mState = ServiceState.PLAYING;
        mIsPlaying = true;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBaseElapsed = mPlaybackStartElapsed;

        acquireWakeLock();
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits activation.
            }
        }
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();
        updateMediaSessionPlaybackState();

        if (mNotificationController != null) {
            mNotificationController.startForegroundSync();
        }
    }

    /**
     * Requests a seek to the given position.
     *
     * <p>In PREPARING, the request is stored and applied at the end of
     * the transition. In READY, PAUSED, or PLAYING, the request is
     * applied immediately and the position epoch is invalidated so any
     * in-flight health check reading is discarded.</p>
     *
     * @param position Target position in milliseconds
     */
    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {

                mPositionEpoch++;

                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player == null) {
                        return;
                    }
                    try {
                        player.seekTo(position);
                    } catch (Exception ignored) {
                        // The player is not in a state that permits seeking.
                    }
                });

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed = SystemClock.elapsedRealtime();
                }

                savePlayerState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
            }
        });
    }

    // ========================================================================
    // Playlist
    // ========================================================================

    /**
     * Replaces the current playlist, resolves an anchor song, and
     * re-enters reconciliation.
     *
     * <p>When the playlist is null or empty, transitions to IDLE.
     * Otherwise, sorts the playlist according to the current sort mode,
     * resolves the anchor from {@link #mPendingSongPath},
     * {@link #mCurrentIndex}, or the persisted last song path, and
     * primes the state machine with the persisted playback position on
     * cold start.</p>
     *
     * @param playlist New playlist, or null to clear
     * @param preserveCurrentSong True to keep the current song as the
     *        anchor when it is present in the new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) {
                return;
            }

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) {
                    broadcastUpdate();
                    return;
                }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));

            if (mCurrentPlaylist != null
                && mCurrentPlaylist.size() == sortedPlaylist.size()
                && sameOrder(mCurrentPlaylist, sortedPlaylist)) {
                broadcastUpdate();
                return;
            }

            String anchorPath = mPendingSongPath;
            if (anchorPath == null) {
                anchorPath = pathOf(mCurrentIndex);
            }
            if (anchorPath == null) {
                anchorPath = getSavedSongPath();
            }

            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null
                            && anchorPath.equals(candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mCurrentPlaylist = sortedPlaylist;

            int resolvedIndex = (anchorPath != null) ? indexOfPath(anchorPath) : -1;

            if (resolvedIndex < 0 && anchorSong != null && anchorSong.getTitle() != null) {
                for (int index = 0; index < sortedPlaylist.size(); index++) {
                    Song candidateSong = sortedPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }
            if (resolvedIndex < 0) {
                resolvedIndex = 0;
            }

            mPendingSongPath = null;

            if (mState == ServiceState.PREPARING) {
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            final boolean coldStart = (mCurrentIndex == -1 && mState == ServiceState.IDLE);
            if (coldStart && anchorPath != null && anchorPath.equals(getSavedSongPath())) {
                final int savedPosition = getSavedPosition();
                if (savedPosition > 0) {
                    mPendingSeekPosition = savedPosition;
                }
                if (!wasPlayingBeforeRestart()) {
                    mPauseAfterPrepare = true;
                }
            }

            boolean sameSong = (resolvedIndex == mCurrentIndex)
                            && (mState == ServiceState.PLAYING
                                || mState == ServiceState.PAUSED
                                || mState == ServiceState.READY);

            mTargetIndex = resolvedIndex;

            if (sameSong) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    updateMediaSessionMetadata(currentSong, null);
                }
                updateMediaSessionPlaybackState();
                broadcastUpdate();
            } else {
                reconcile();
            }
        });
    }

    /**
     * Replaces the current playlist without preserving the current
     * song.
     *
     * @param playlist New playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    /**
     * Replaces the current playlist, preserving the current song when it
     * is present in the new playlist.
     *
     * @param newPlaylist New playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    /**
     * Returns a copy of the current playlist.
     *
     * @return A new list containing the current playlist; empty when no
     *         playlist is loaded
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) {
            return new ArrayList<Song>();
        }
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    /**
     * Returns whether two playlists contain the same song paths in the
     * same order.
     *
     * @param firstPlaylist First playlist to compare
     * @param secondPlaylist Second playlist to compare
     * @return True when the two playlists have the same size and every
     *         song path matches position by position
     */
    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) {
            return false;
        }
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null) ? firstSong.getPath() : null;
            String secondPath = (secondSong != null) ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ========================================================================
    // Pending Song Path
    // ========================================================================

    /**
     * Sets the song path queued for playback once it enters the playlist.
     *
     * <p>When a non-null path is set, {@link #playPendingSongIfExists()}
     * runs immediately so a path that is already in the playlist plays
     * without a second call.</p>
     *
     * @param path Song path to queue, or null to clear
     */
    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            mPendingSongPath = path;
            if (path != null) {
                Log.d(TAG, "Pending song path set: " + path);
                playPendingSongIfExists();
            } else {
                Log.d(TAG, "Pending song path cleared");
            }
        });
    }

    /**
     * Returns the song path currently queued for playback.
     *
     * @return The queued path, or null when none is queued
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    /**
     * Clears the queued song path.
     */
    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    /**
     * Plays the queued song path when it is present in the current
     * playlist and clears the queue.
     */
    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) {
                return;
            }
            int index = indexOfPath(mPendingSongPath);
            if (index >= 0) {
                mPendingSongPath = null;
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            }
        });
    }

    // ========================================================================
    // Getters and Mode Setters
    // ========================================================================

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return The current position
     */
    public int getCurrentPosition() {
        return estimateCurrentPosition();
    }

    /**
     * Returns the duration of the currently prepared track in
     * milliseconds.
     *
     * @return The track duration, or 0 when no track is prepared
     */
    public int getDuration() {
        return mCachedDuration;
    }

    /**
     * Returns whether the state machine is in PLAYING.
     *
     * @return True when a track is playing
     */
    public boolean isPlaying() {
        return mState == ServiceState.PLAYING;
    }

    /**
     * Returns the song bound to {@link #mCurrentIndex}.
     *
     * @return The current song, or null when no song is bound
     */
    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return null;
        }
        if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
            return null;
        }
        return mCurrentPlaylist.get(mCurrentIndex);
    }

    /**
     * Returns the index the MediaPlayer is bound to.
     *
     * @return The current index, or -1 when nothing is bound
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Sets the index the MediaPlayer is bound to and persists it.
     *
     * @param index Index to record
     */
    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    /**
     * Returns the current repeat mode.
     *
     * @return 0 for off, 1 for all, or 2 for one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }

    /**
     * Sets the repeat mode, persists it, and broadcasts the new state.
     *
     * @param mode New repeat mode
     */
    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Returns whether shuffle is enabled.
     *
     * @return True when shuffle is enabled
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }

    /**
     * Sets the shuffle flag, persists it, and broadcasts the new state.
     *
     * @param shuffle New shuffle flag
     */
    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Records whether a Bluetooth headset is currently connected.
     *
     * @param connected True when a headset is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ========================================================================
    // Sort Mode
    // ========================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ========================================================================
    // Persistence
    // ========================================================================

    /**
     * Writes the current playback state to SharedPreferences.
     */
    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Writes the full playback state to SharedPreferences.
     */
    private void saveFullState() {
        savePlayerState();
    }

    /**
     * Returns the persisted playback position.
     *
     * @return The persisted position in milliseconds, or 0 when none is
     *         stored
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    /**
     * Returns whether the persisted state indicates that playback was
     * active before the last restart.
     *
     * @return True when the last persisted state was PLAYING
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    /**
     * Returns the persisted last song path.
     *
     * @return The last song path, or null when none is stored
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Persists the current playing index and last song path.
     */
    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Persists the last playing flag and current position.
     */
    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    /**
     * Reads the persisted repeat mode and shuffle flag into memory.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = preferences.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = preferences.getBoolean(KEY_SHUFFLE, false);
    }

    // ========================================================================
    // MediaPlayer Plumbing (player-thread only)
    // ========================================================================

    /**
     * Detaches every listener from the given player.
     *
     * @param player Player whose listeners are detached, or null
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) {
            return;
        }
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
            // The player is not in a state that permits listener changes.
        }
    }

    /**
     * Stops, resets, and releases the MediaPlayer, then clears the field.
     */
    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
            } catch (Exception ignored) {
                // The player is not in a state that permits stopping.
            }
            try {
                mMediaPlayer.reset();
            } catch (Exception ignored) {
                // The player is not in a state that permits resetting.
            }
            try {
                mMediaPlayer.release();
            } catch (Exception ignored) {
                // The player is already released.
            }
            mMediaPlayer = null;
        }
    }

    /**
     * Returns the MediaPlayer instance, creating one when none exists.
     *
     * @return The MediaPlayer instance
     */
    @NonNull
    private MediaPlayer getOrCreatePlayerRaw() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    // ========================================================================
    // Playback Params
    // ========================================================================

    /**
     * Applies the current tempo and pitch from {@link EqualizerManager}
     * to the MediaPlayer on the player thread.
     */
    public void updatePlaybackParams() {
        EqualizerManager equalizerManager = EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        final float finalTempo = tempo;
        final float finalSemitones = semitones;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                float pitch = (float) Math.pow(2.0, finalSemitones / 12.0);
                android.media.PlaybackParams playbackParams = player.getPlaybackParams();
                playbackParams.setSpeed(finalTempo);
                playbackParams.setPitch(pitch);
                player.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + finalTempo + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params", exception);
            }
        });
    }

    // ========================================================================
    // MediaSession
    // ========================================================================

    /**
     * Creates the media session, installs the callback, sets the flags,
     * and activates the session.
     */
    private void setupMediaSession() {
        try {
            ComponentName mediaButtonReceiver = new ComponentName(
                this, androidx.media.session.MediaButtonReceiver.class);
            mMediaSession = new MediaSessionCompat(
                this, "LlamaMusicService", mediaButtonReceiver, null);

            mMediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        if (mState == ServiceState.PAUSED) {
                            doResume();
                        } else if (mState == ServiceState.IDLE) {
                            resume();
                        } else if (mState == ServiceState.READY) {
                            togglePlayPause();
                        }
                    });
                }

                @Override
                public void onPause() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        } else if (mState == ServiceState.PREPARING) {
                            mPauseAfterPrepare = true;
                        }
                    });
                }

                @Override
                public void onSkipToNext() {
                    if (isNotificationActionDebounced("ACTION_NEXT")) {
                        return;
                    }
                    playNextSong();
                }

                @Override
                public void onSkipToPrevious() {
                    if (isNotificationActionDebounced("ACTION_PREV")) {
                        return;
                    }
                    playPreviousSong();
                }

                @Override
                public void onStop() {
                    if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        }
                    });
                }

                @Override
                public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId == null) {
                        return;
                    }
                    try {
                        playSong(Integer.parseInt(mediaId));
                    } catch (NumberFormatException ignored) {
                        // The media identifier is not a playlist index.
                    }
                }
            });

            mMediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    /**
     * Returns the current media session token, or null when no session
     * exists.
     *
     * @return The session token, or null
     */
    @Nullable
    public MediaSessionCompat.Token getSessionToken() {
        return mMediaSession != null ? mMediaSession.getSessionToken() : null;
    }

    /**
     * Updates the media session metadata from the given song and album
     * art.
     *
     * <p>When the song is null, installs an empty metadata block so the
     * system media controls present no stale title, artist, or album.
     * The idle state is not a song, and the media carousel should not
     * present one.</p>
     *
     * @param song Song to describe, or null for the idle metadata
     * @param albumArt Album art to include, or null
     */
    public void updateMediaSessionMetadata(@Nullable Song song, @Nullable Bitmap albumArt) {
        if (mMediaSession == null) {
            return;
        }
        try {
            MediaMetadataCompat.Builder builder = new MediaMetadataCompat.Builder();
            if (song != null) {
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, song.getTitle());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.getArtist());
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, song.getAlbum());
                if (albumArt != null && !albumArt.isRecycled()) {
                    builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, albumArt);
                }
            } else {
                // Empty metadata block. Nothing is playing, and the media
                // carousel should not present a placeholder title either:
                // the correct presentation of "no track" is no text.
                builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, "");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "");
                builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "");
            }
            mMediaSession.setMetadata(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession metadata", exception);
        }
    }

    /**
     * Updates the media session metadata for the current song with the
     * given album art.
     *
     * @param albumArt Album art to include, or null
     */
    public void updateMediaSessionArt(@Nullable Bitmap albumArt) {
        updateMediaSessionMetadata(getCurrentSong(), albumArt);
    }

    /**
     * Updates the media session playback state from the current service
     * state.
     *
     * <p>The IDLE state maps to {@link PlaybackStateCompat#STATE_NONE}
     * rather than STATE_STOPPED. STATE_STOPPED would still present a
     * stopped-but-present entry in the system media carousel; STATE_NONE
     * is the correct mapping for "there is no track", and it matches the
     * empty metadata block the idle path installs.</p>
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null) {
            return;
        }
        try {
            long actions = PlaybackStateCompat.ACTION_PLAY
                         | PlaybackStateCompat.ACTION_PAUSE
                         | PlaybackStateCompat.ACTION_PLAY_PAUSE
                         | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                         | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackStateCompat.ACTION_STOP;

            final int frameworkState;
            if (mState == ServiceState.PLAYING) {
                frameworkState = PlaybackStateCompat.STATE_PLAYING;
            } else if (mState == ServiceState.IDLE) {
                frameworkState = PlaybackStateCompat.STATE_NONE;
            } else {
                frameworkState = PlaybackStateCompat.STATE_PAUSED;
            }

            PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(frameworkState, getCurrentPosition(), 1.0f);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state", exception);
        }
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    /**
     * Creates the audio focus listener and, on API 26 and later, the
     * audio focus request.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    /**
     * Requests audio focus using the API-appropriate mechanism.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /**
     * Abandons audio focus using the API-appropriate mechanism.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    /**
     * Pauses playback when audio focus is lost or transiently lost.
     * Every other focus change is ignored.
     *
     * @param focusChange The focus change reported by the audio manager
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mState == ServiceState.PLAYING) {
                    doPause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
            case AudioManager.AUDIOFOCUS_GAIN:
            default:
                break;
        }
    }

    // ========================================================================
    // Media Button
    // ========================================================================

    /**
     * Handles a media key press.
     *
     * <p>When a Bluetooth headset is connected, the volume-up and
     * volume-down keys are interpreted as next and previous. Otherwise,
     * the standard media keys are interpreted.</p>
     *
     * @param keyCode Key code of the pressed key
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNextSong();
                return;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPreviousSong();
                return;
            }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mState == ServiceState.PAUSED) {
                    doResume();
                } else if (mState == ServiceState.IDLE) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mState == ServiceState.PLAYING) {
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPauseAfterPrepare = true;
                }
                break;
            default:
                break;
        }
    }

    // ========================================================================
    // Broadcasts
    // ========================================================================

    /**
     * Sends the current full playback snapshot as an
     * {@code UPDATE_PLAYER} broadcast.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", mGeneration);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", mState == ServiceState.PLAYING);
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());
        sendBroadcast(intent);
    }

    /**
     * Sends the current audio session identifier as an
     * {@code AUDIO_SESSION_CHANGED} broadcast.
     *
     * @param sessionId New audio session identifier
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    // ========================================================================
    // Receivers
    // ========================================================================

    /**
     * Registers the receiver for playback parameter update broadcasts.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver,
            new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    /**
     * Registers the receiver for playlist clear broadcasts.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     *
     * <p>The notification surface is owned by
     * {@link NotificationController}, which observes theme changes on its
     * own.</p>
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    // The notification surface observes theme changes on
                    // its own.
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    /**
     * Registers the receiver for playing state query broadcasts.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response = new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", mState == ServiceState.PLAYING);
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_LAST_PLAYING, mState == ServiceState.PLAYING)
                        .apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }

    /**
     * Registers the receiver for sort mode change broadcasts.
     *
     * <p>On a sort mode change, the current playlist is re-sorted and the
     * current index is re-resolved from the anchor path.</p>
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    return;
                }
                int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) {
                    return;
                }
                mCurrentSortMode = newSortMode;
                saveSortMode();
                onMain(() -> {
                    if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                        return;
                    }
                    String anchorPath = pathOf(mCurrentIndex);
                    Collections.sort(mCurrentPlaylist,
                        getComparatorForSortMode(mCurrentSortMode));
                    if (anchorPath != null) {
                        int newIndex = indexOfPath(anchorPath);
                        if (newIndex >= 0) {
                            mCurrentIndex = newIndex;
                            saveCurrentPlayingIndex();
                        }
                    }
                    broadcastUpdate();
                });
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    /**
     * Registers the receiver for sync completion broadcasts.
     *
     * <p>{@code SYNC_COMPLETE} is a general "playlist changed" signal.
     * Its only effect in this service is to publish the new state.</p>
     *
     * <p>The persistent overlay is left alone. Every operation hides its
     * own overlay by its own operation ID. A force-hide here would race
     * the {@code GENRE_UPDATE} overlay's show in
     * {@code FolderManager.performPlaylistUpdate()}.</p>
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                broadcastUpdate();
            }
        };
        registerReceiver(mSyncCompleteReceiver, new IntentFilter("SYNC_COMPLETE"));
    }

    /**
     * Registers the receiver for genre update broadcasts.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(intent.getAction())) {
                    return;
                }
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    broadcastUpdate();
                }
            }
        };
        registerReceiver(mGenreUpdateReceiver, new IntentFilter(ACTION_GENRE_UPDATE));
    }

    /**
     * Registers the receiver for soft playlist update broadcasts.
     */
    private void registerSoftUpdatePlaylistReceiver() {
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    return;
                }

                if (mMusicLibrary == null) {
                    mMusicLibrary = new MusicLibrary(MusicService.this);
                }
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiver(mSoftUpdatePlaylistReceiver,
            new IntentFilter("SOFT_UPDATE_PLAYLIST"));
    }

    /**
     * Registers the receiver for pending song path broadcasts.
     */
    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) {
                        setPendingSongPath(path);
                    }
                }
            }
        };
        registerReceiver(mSetPendingSongReceiver,
            new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    /**
     * Registers the receiver for player state reset broadcasts.
     *
     * <p>Reacts to the reset broadcast emitted by {@code FolderManager}
     * when the user removes the last folder and the last loose track, or
     * when the last folder is removed while loose tracks remain.</p>
     *
     * <p>When {@code preserve_settings} is false, the service also clears
     * its in-memory library and its playback preferences (repeat mode,
     * shuffle, sort mode). A full content removal leaves no cached list
     * and no stale preference once this receiver returns.</p>
     *
     * <p>The service owns its own teardown: this receiver is the single
     * point through which the service learns the library is empty,
     * independent of any activity.</p>
     *
     * <p>The equalizer preferences are preserved so a later reattach
     * restores the user's settings.</p>
     *
     * <p>{@link #stopCompletely()} runs first. It reaches
     * {@link #transitionToIdle()}, which writes the idle values to
     * {@code SharedPreferences} and clears the current index. The
     * preference writes below then persist the settings reset on top of
     * an already-idle state, so no stale intermediate state is observable
     * between the two.</p>
     *
     * <p>After the transition the receiver re-clears the resolved
     * notification art and its LRU cache. {@link #transitionToIdle()}
     * already clears both, but a decode that was in flight at the moment
     * of the transition could have committed its result on the main
     * thread after the transition's clear but before this receiver's
     * handler runs. Clearing here, on the same main-thread turn as the
     * transition, removes that window.</p>
     */
    private void registerResetPlayerStateReceiver() {
        mResetPlayerStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_RESET_PLAYER_STATE.equals(intent.getAction())) {
                    return;
                }
                final boolean preserveSettings =
                    intent.getBooleanExtra("preserve_settings", false);
                Log.d(TAG, "RESET_PLAYER_STATE received (preserve_settings="
                    + preserveSettings + ")");
                onMain(() -> {
                    // Clear the state machine first. transitionToIdle()
                    // writes the idle values to SharedPreferences and
                    // clears the current index; the preference writes
                    // below then persist the settings reset on top of an
                    // already-idle state, so no stale intermediate state
                    // is observable between the two.
                    stopCompletely();

                    // Belt-and-braces. transitionToIdle() already clears
                    // these fields, but a decode that was in flight when
                    // the transition ran could have committed its result
                    // after the transition's clear. Clear again here, on
                    // the same main-thread turn as the transition, so the
                    // notification source cannot hand a stale bitmap to
                    // the next render.
                    mResolvedArtPath = null;
                    mResolvedArt = null;
                    if (mCurrentArtLoad != null) {
                        mCurrentArtLoad.cancel(true);
                        mCurrentArtLoad = null;
                    }
                    if (mArtCache != null) {
                        mArtCache.evictAll();
                    }

                    if (!preserveSettings) {
                        mRepeatMode = 0;
                        mIsShuffle = false;
                        mCurrentSortMode = SORT_TITLE_AZ;
                        if (mShuffleHistory != null) {
                            mShuffleHistory.clear();
                        }
                        if (mMusicLibrary != null) {
                            // Invalidate, not refresh: the folder set is
                            // empty now and this instance's cached copy
                            // of it must be dropped so a later scan does
                            // not rescan the removed folders.
                            mMusicLibrary.invalidate();
                        }
                        savePlayerState();
                        saveSortMode();
                    }
                });
            }
        };
        registerReceiver(mResetPlayerStateReceiver,
            new IntentFilter(ACTION_RESET_PLAYER_STATE));
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) {
            return;
        }
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
            // The receiver was already unregistered.
        }
    }

    // ========================================================================
    // Genre and Metadata Updates
    // ========================================================================

    /**
     * Updates the in-memory genre of the given song and, when it is the
     * current song, refreshes the media session metadata.
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     */
    private void updateGenreInPlaylist(@NonNull String songPath, @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath) || TextUtils.isEmpty(newGenre)) {
            return;
        }
        if (mCurrentPlaylist == null) {
            return;
        }

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                    broadcastUpdate();

                    Song currentSong = getCurrentSong();
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        updateMediaSessionMetadata(currentSong, null);
                    }
                }
                break;
            }
        }
    }

    /**
     * Refreshes the current song's metadata from a change published by
     * {@link MetadataEditor}.
     *
     * <p>Rebuilds the current song entry from the supplied values, writes
     * it to the song database, updates the album art cache, broadcasts
     * the new state, and refreshes the media session.</p>
     *
     * @param songPath Path of the song that changed
     * @param newTitle New title, or null for no change
     * @param newArtist New artist, or null for no change
     * @param newAlbum New album, or null for no change
     * @param newGenre New genre, or null for no change
     * @param albumArtBytes New album art bytes, or null for no change
     * @param albumArtRemoved True when the album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            if (mCurrentPlaylist == null) {
                return;
            }
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                return;
            }

            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null || !songPath.equals(currentSong.getPath())) {
                return;
            }

            String finalTitle = (newTitle != null && !newTitle.isEmpty())
                ? newTitle : currentSong.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty())
                ? newArtist : currentSong.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty())
                ? newAlbum : currentSong.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty())
                ? newGenre : currentSong.getGenre();

            Song updatedSong = new Song(finalTitle, finalArtist, finalAlbum, finalGenre,
                songPath, currentSong.getDuration(), null);
            if (currentSong.getUri() != null) {
                updatedSong.setUri(currentSong.getUri());
            }

            mCurrentPlaylist.set(mCurrentIndex, updatedSong);
            SongDatabase.getInstance(this).insertSong(updatedSong);

            if (albumArtRemoved) {
                mArtCache.remove(songPath);
                mResolvedArtPath = songPath;
                mResolvedArt = null;
            } else if (albumArtBytes != null) {
                mArtCache.remove(songPath);
                final Bitmap newArt = BitmapFactory.decodeByteArray(
                    albumArtBytes, 0, albumArtBytes.length);
                if (newArt != null) {
                    mArtCache.put(songPath, newArt);
                    mResolvedArtPath = songPath;
                    mResolvedArt = newArt;
                }
            }

            broadcastUpdate();
            updateMediaSessionPlaybackState();
        });
    }
}