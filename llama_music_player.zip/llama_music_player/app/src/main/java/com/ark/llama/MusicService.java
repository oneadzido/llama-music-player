package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with battery optimization.
 * 
 * <p>This service is the SINGLE SOURCE OF TRUTH for:
 * <ul>
 *   <li>Current playlist</li>
 *   <li>Current playing index</li>
 *   <li>Playback state (playing/paused)</li>
 *   <li>Repeat mode (off/all/one)</li>
 *   <li>Shuffle mode</li>
 *   <li>Sort mode</li>
 * </ul>
 * </p>
 * 
 * <p>Battery Optimization Features:
 * <ul>
 *   <li>WakeLock with proper release on pause/stop</li>
 *   <li>Adaptive health check intervals</li>
 *   <li>CPU wakeup optimization</li>
 *   <li>Idle state detection</li>
 * </ul>
 * </p>
 * 
 * @author Richard Korbla Adzido
 * @version 2.0.0
 * @since 2.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";
    
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    // Battery-optimized intervals
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    private static final int HEALTH_CHECK_INTERVAL_IDLE_MS = 10000;  // Longer interval when idle
    private static final int MAX_STALL_TIME_MS = 5000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    private static final long WAKE_LOCK_TIMEOUT_MS = 30000;  // Auto-release after 30s idle
    
    // ========================================================================
    // Sort Mode Constants
    // ========================================================================
    
    public static final int SORT_TITLE_AZ = 0;
    public static final int SORT_TITLE_ZA = 1;
    public static final int SORT_ARTIST_AZ = 2;
    public static final int SORT_ARTIST_ZA = 3;
    public static final int SORT_ALBUM_AZ = 4;
    public static final int SORT_ALBUM_ZA = 5;
    public static final int SORT_GENRE_AZ = 6;
    public static final int SORT_GENRE_ZA = 7;
    public static final int SORT_OLDEST = 8;
    public static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // MediaPlayer
    // ========================================================================
    
    private MediaPlayer mMediaPlayer;
    
    // ========================================================================
    // Playback State (SINGLE SOURCE OF TRUTH)
    // ========================================================================
    
    private ArrayList<Song> mCurrentPlaylist;
    private volatile int mCurrentIndex = -1;
    private volatile boolean mIsPlaying = false;
    private volatile int mRepeatMode = 0;
    private volatile boolean mIsShuffle = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Health Check Components (Battery Optimized)
    // ========================================================================
    
    private Handler mHealthHandler;
    private Runnable mHealthCheckRunnable;
    private int mRecoveryAttempts = 0;
    private long mPlaybackStartTime = 0;
    private long mLastHealthCheckTime = 0;
    private boolean mIsHealthCheckActive = false;
    
    // ========================================================================
    // Wake Lock & Audio Focus (Battery Optimized)
    // ========================================================================
    
    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    private AudioFocusRequest mAudioFocusRequest;
    private final Object mWakeLockLock = new Object();
    private Handler mWakeLockTimeoutHandler;
    private Runnable mWakeLockTimeoutRunnable;
    
    // ========================================================================
    // Media Session (Full Integration)
    // ========================================================================
    
    private MediaSession mMediaSession;
    private MediaSessionCompat mMediaSessionCompat;
    
    // ========================================================================
    // Thread Safety
    // ========================================================================
    
    private final Object mPlayerLock = new Object();
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    private volatile int mCurrentPrepId = -1;
    
    // ========================================================================
    // Shuffle History
    // ========================================================================
    
    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Executor for background operations
    // ========================================================================
    
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Sort Comparators
    // ========================================================================
    
    private class TitleAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    private class TitleZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    private class ArtistAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    private class ArtistZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    private class AlbumAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    private class AlbumZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    private class GenreAZComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    private class GenreZAComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    private class OldestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    private class NewestFirstComparator implements Comparator<Song> {
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle
    // ========================================================================
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        loadRepeatAndShuffle();
        loadSortMode();
        
        setupMediaSession();
        setupMediaSessionCompat();
        EqualizerManager.getInstance(this);
        
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        setupAudioFocus();
        
        mHealthHandler = new Handler(Looper.getMainLooper());
        mWakeLockTimeoutHandler = new Handler(Looper.getMainLooper());
        
        // Setup battery-optimized wake lock
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }
        
        setupWakeLockTimeout();
        
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) mNotificationService.stopForeground();
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) playSong(position);
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            } else if (action.equals("ADD_FOLDER")) {
                String folderUri = intent.getStringExtra("folder_uri");
                if (folderUri != null) {
                    Log.d(TAG, "Folder addition requested: " + folderUri);
                }
            }
        }
        return START_STICKY;
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        cancelWakeLockTimeout();
        
        releaseWakeLock();
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        if (mMediaSessionCompat != null) {
            mMediaSessionCompat.setActive(false);
            mMediaSessionCompat.release();
            mMediaSessionCompat = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        if (mWakeLockTimeoutHandler != null) {
            mWakeLockTimeoutHandler.removeCallbacksAndMessages(null);
            mWakeLockTimeoutHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        mExecutor.shutdown();
        
        super.onDestroy();
    }
    
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        releaseWakeLock();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Battery-Optimized Wake Lock Management
    // ========================================================================
    
    private void setupWakeLockTimeout() {
        mWakeLockTimeoutRunnable = new Runnable() {
            @Override
            public void run() {
                synchronized (mWakeLockLock) {
                    if (mWakeLock != null && mWakeLock.isHeld() && !mIsPlaying) {
                        Log.d(TAG, "WakeLock timeout - releasing due to inactivity");
                        mWakeLock.release();
                    }
                }
            }
        };
    }
    
    private void acquireWakeLock() {
        synchronized (mWakeLockLock) {
            if (mWakeLock != null && !mWakeLock.isHeld()) {
                mWakeLock.acquire();
                Log.d(TAG, "WakeLock acquired");
            }
            // Reset timeout
            cancelWakeLockTimeout();
            if (!mIsPlaying) {
                mWakeLockTimeoutHandler.postDelayed(mWakeLockTimeoutRunnable, WAKE_LOCK_TIMEOUT_MS);
            }
        }
    }
    
    private void releaseWakeLock() {
        synchronized (mWakeLockLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released");
            }
            cancelWakeLockTimeout();
        }
    }
    
    private void cancelWakeLockTimeout() {
        if (mWakeLockTimeoutHandler != null && mWakeLockTimeoutRunnable != null) {
            mWakeLockTimeoutHandler.removeCallbacks(mWakeLockTimeoutRunnable);
        }
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
            }
        }
        
        broadcastUpdate();
        updateMediaSessionMetadata();
    }
    
    // ========================================================================
    // Public API for Activities
    // ========================================================================
    
    @NonNull
    public ArrayList<Song> getFullPlaylist() {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return new ArrayList<>();
            return new ArrayList<>(mCurrentPlaylist);
        }
    }
    
    public int getCurrentSortMode() {
        return mCurrentSortMode;
    }
    
    public void setSortMode(int sortMode) {
        if (mCurrentSortMode != sortMode) {
            mCurrentSortMode = sortMode;
            saveSortMode();
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                reorderPlaylistByCurrentSort();
            }
            broadcastUpdate();
            
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }
    }
    
    public int getCurrentPosition() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    public int getDuration() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    public boolean isPlaying() {
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    @Nullable
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
        updateMediaSessionMetadata();
    }
    
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
        updateMediaSessionMetadata();
        updateMediaSessionPlaybackState();
    }
    
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) mShuffleHistory.clear();
        savePlayerState();
        saveFullState();
        updateMediaSessionMetadata();
        updateMediaSessionPlaybackState();
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                        }
                        broadcastUpdate();
                        updateMediaSessionMetadata();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception e) {}
        }
    }
    
    // ========================================================================
    // MediaPlayer Management
    // ========================================================================
    
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }
    
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            }
            mIsPlaying = false;
        }
    }
    
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
                try { mMediaPlayer.release(); } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparing.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
    
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    // ========================================================================
    // Health Check Methods (Battery Optimized)
    // ========================================================================
    
    private void startHealthMonitoring() {
        if (mHealthHandler == null) mHealthHandler = new Handler(Looper.getMainLooper());
        
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = SystemClock.elapsedRealtime();
        mIsHealthCheckActive = true;
        
        scheduleHealthCheck();
    }
    
    private void scheduleHealthCheck() {
        if (!mIsHealthCheckActive) return;
        
        if (mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mIsHealthCheckActive) {
                    checkPlaybackHealth();
                    int interval = mIsPlaying ? HEALTH_CHECK_INTERVAL_MS : HEALTH_CHECK_INTERVAL_IDLE_MS;
                    if (mHealthHandler != null) {
                        mHealthHandler.postDelayed(mHealthCheckRunnable, interval);
                    }
                }
            }
        };
        int interval = mIsPlaying ? HEALTH_CHECK_INTERVAL_MS : HEALTH_CHECK_INTERVAL_IDLE_MS;
        mHealthHandler.postDelayed(mHealthCheckRunnable, interval);
    }
    
    private void stopHealthMonitoring() {
        mIsHealthCheckActive = false;
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        
        try {
            int currentPosition = getCurrentPosition();
            long now = SystemClock.elapsedRealtime();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = now - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected!");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = now;
                mRecoveryAttempts = 0; // Reset on successful playback
            }
            mLastHealthCheckTime = now;
        } catch (Exception e) {
            recoverFromStall();
        }
    }
    
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try { if (mIsPlaying) mMediaPlayer.pause(); } catch (Exception ignored) {}
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && 
                    currentIndex < mCurrentPlaylist.size()) {
                    prepareAndPlay(currentIndex, currentPosition);
                    
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }
    
    // ========================================================================
    // Async Operation Management
    // ========================================================================
    
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            if (art != null && !art.isRecycled()) safeArt = art;
            if (placeholder != null && !placeholder.isRecycled()) safePlaceholder = placeholder;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence
    // ========================================================================
    
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    private void saveFullState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Playlist Management (SINGLE SOURCE OF TRUTH)
    // ========================================================================
    
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                currentPosition = getCurrentPosition();
                wasPlaying = mIsPlaying;
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
            }
            
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                updateMediaSessionMetadata();
                return;
            }
            
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            if (!preserveCurrentSong) {
                resetPlayerSafely();
                mIsPlaying = false;
            }
            
            int newIndex = -1;
            if (preserveCurrentSong && currentSongPath != null) {
                for (int i = 0; i < sortedPlaylist.size(); i++) {
                    if (sortedPlaylist.get(i).getPath().equals(currentSongPath)) {
                        newIndex = i;
                        break;
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
            } else {
                mCurrentIndex = -1;
            }
            
            saveCurrentPlayingIndex();
            
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && 
                mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    prepareAndPlay(correctIndex, currentPosition);
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    prepareAndPlay(mCurrentIndex, currentPosition);
                }
            } else if (preserveCurrentSong && mCurrentIndex >= 0) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            }
            
            broadcastUpdate();
            updateMediaSessionMetadata();
        }
    }
    
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            releaseWakeLock();
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        updateMediaSessionMetadata();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    public synchronized void playSong(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        prepareAndPlay(index, 0);
    }
    
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try { player.reset(); } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            mIsPreparing.set(true);
            mCurrentIndex = index;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        
                        mIsPreparing.set(false);
                        
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                mIsPlaying = false;
                                broadcastUpdate();
                                return;
                            }
                            
                            if (seekPosition > 0 && seekPosition < duration - 500) {
                                mp.seekTo(seekPosition);
                            }
                            
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            saveCurrentPlayingIndex();
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = SystemClock.elapsedRealtime();
                            startHealthMonitoring();
                            updatePlaybackParams();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            
                            acquireWakeLock();
                            
                            updateMediaSessionPlaybackState();
                            updateMediaSessionMetadata();
                            broadcastUpdate();
                            createNotification();
                            
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying = false;
                            broadcastUpdate();
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        final int myPrepId = mGlobalPrepId.incrementAndGet();
        mCurrentPrepId = myPrepId;
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try { player.reset(); } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            mIsPreparing.set(true);
            mCurrentIndex = index;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        mIsPreparing.set(false);
                        
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    public synchronized void playSongAtPosition(int index, int position) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        prepareAndPlay(index, position);
        saveFullState();
    }
    
    public synchronized void playSongByPath(@NonNull String filePath) {
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    public synchronized void playNext() {
        if (!acquireTransitionLock()) return;
        
        try {
            if (mIsPreparing.get()) return;
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) mShuffleHistory.clear();
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    public synchronized void playPrevious() {
        if (!acquireTransitionLock()) return;
        
        try {
            if (mIsPreparing.get()) return;
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionMetadata();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    public void togglePlayPause() {
        if (mIsPlaying) {
            pause();
        } else if (mCurrentIndex >= 0) {
            resume();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            playSong(0);
        }
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    public void pause() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try {
                    mMediaPlayer.pause();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot pause - invalid state", e);
                }
                mIsPlaying = false;
                
                releaseWakeLock();
                
                savePlayingState();
                savePlayerState();
                saveFullState();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                createNotification();
            }
        }
    }
    
    public void resume() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    if (!mIsPlaying) {
                        requestAudioFocus();
                        updatePlaybackParams();
                        mMediaPlayer.start();
                        mIsPlaying = true;
                        mPlaybackStartTime = SystemClock.elapsedRealtime();
                        startHealthMonitoring();
                        
                        acquireWakeLock();
                        
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        createNotification();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Resume failed - invalid state", e);
                    mIsPlaying = false;
                    broadcastUpdate();
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                playSong(0);
            }
        }
    }
    
    public void stop() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                try {
                    mMediaPlayer.stop();
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot stop - invalid state", e);
                }
                mIsPlaying = false;
            }
        }
        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    public void seekTo(int position) {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    int duration = mMediaPlayer.getDuration();
                    if (position >= 0 && position < duration) {
                        mMediaPlayer.seekTo(position);
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        savePlayerState();
                        saveFullState();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Cannot seek - invalid state", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Playback Parameters (Pitch & Speed via PlaybackParams - API 23+)
    // ========================================================================
    
    public void updatePlaybackParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        float pitch = (float) Math.pow(2.0, semitones / 12.0);
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                    params.setSpeed(tempo);
                    params.setPitch(pitch);
                    mMediaPlayer.setPlaybackParams(params);
                    Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to set playback params", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            mIsPlaying = false;
            releaseWakeLock();
            return;
        }
        
        if (mRepeatMode == 2) {
            playSong(mCurrentIndex);
        } else if (mRepeatMode == 1) {
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            mIsPlaying = false;
            releaseWakeLock();
            
            if (mMediaPlayer != null) {
                try { mMediaPlayer.pause(); } catch (Exception ignored) {}
                try { mMediaPlayer.seekTo(0); } catch (Exception ignored) {}
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }
    
    // ========================================================================
    // MediaSession Methods (Full Integration)
    // ========================================================================
    
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) pause();
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        seekTo((int) pos);
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                    
                    @Override
                    public void onSetRepeatMode(int repeatMode) {
                        if (repeatMode == PlaybackState.REPEAT_MODE_NONE) {
                            setRepeatMode(0);
                        } else if (repeatMode == PlaybackState.REPEAT_MODE_ALL) {
                            setRepeatMode(1);
                        } else if (repeatMode == PlaybackState.REPEAT_MODE_ONE) {
                            setRepeatMode(2);
                        }
                    }
                    
                    @Override
                    public void onSetShuffleMode(int shuffleMode) {
                        setShuffle(shuffleMode == PlaybackState.SHUFFLE_MODE_ALL);
                    }
                });
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
                updateMediaSessionMetadata();
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    private void setupMediaSessionCompat() {
        try {
            mMediaSessionCompat = new MediaSessionCompat(this, "LlamaMusicService");
            mMediaSessionCompat.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    if (!mIsPlaying && mCurrentIndex >= 0) {
                        resume();
                    } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                        playSong(0);
                    }
                }
                
                @Override
                public void onPause() {
                    if (mIsPlaying) pause();
                }
                
                @Override
                public void onSkipToNext() {
                    playNext();
                }
                
                @Override
                public void onSkipToPrevious() {
                    playPrevious();
                }
                
                @Override
                public void onStop() {
                    pause();
                }
                
                @Override
                public void onSeekTo(long pos) {
                    seekTo((int) pos);
                }
                
                @Override
                public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId != null) {
                        try {
                            playSong(Integer.parseInt(mediaId));
                        } catch (NumberFormatException ignored) {}
                    }
                }
            });
            mMediaSessionCompat.setActive(true);
            updateMediaSessionCompatPlaybackState();
            updateMediaSessionCompatMetadata();
        } catch (Exception e) {
            Log.e(TAG, "Failed to setup MediaSessionCompat", e);
        }
    }
    
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO |
                              PlaybackState.ACTION_PLAY_FROM_MEDIA_ID;
                
                actions |= PlaybackState.ACTION_SET_REPEAT_MODE;
                actions |= PlaybackState.ACTION_SET_SHUFFLE_MODE;
                
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                long position = getCurrentPosition();
                float speed = 1.0f;
                
                stateBuilder.setState(state, position, speed);
                stateBuilder.setActions(actions);
                stateBuilder.setRepeatMode(convertRepeatModeToMediaSession());
                stateBuilder.setShuffleMode(mIsShuffle ? PlaybackState.SHUFFLE_MODE_ALL : PlaybackState.SHUFFLE_MODE_NONE);
                
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    private void updateMediaSessionCompatPlaybackState() {
        if (mMediaSessionCompat != null) {
            try {
                PlaybackStateCompat.Builder stateBuilder = new PlaybackStateCompat.Builder();
                long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE |
                              PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackStateCompat.ACTION_STOP | PlaybackStateCompat.ACTION_SEEK_TO |
                              PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID;
                
                actions |= PlaybackStateCompat.ACTION_SET_REPEAT_MODE;
                actions |= PlaybackStateCompat.ACTION_SET_SHUFFLE_MODE;
                
                int state = mIsPlaying ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
                long position = getCurrentPosition();
                float speed = 1.0f;
                
                stateBuilder.setState(state, position, speed);
                stateBuilder.setActions(actions);
                stateBuilder.setRepeatMode(convertRepeatModeToMediaSession());
                stateBuilder.setShuffleMode(mIsShuffle ? PlaybackStateCompat.SHUFFLE_MODE_ALL : PlaybackStateCompat.SHUFFLE_MODE_NONE);
                
                mMediaSessionCompat.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSessionCompat state", e);
            }
        }
    }
    
    private int convertRepeatModeToMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            switch (mRepeatMode) {
                case 0: return PlaybackState.REPEAT_MODE_NONE;
                case 1: return PlaybackState.REPEAT_MODE_ALL;
                case 2: return PlaybackState.REPEAT_MODE_ONE;
                default: return PlaybackState.REPEAT_MODE_NONE;
            }
        }
        return 0;
    }
    
    private void updateMediaSessionMetadata() {
        Song currentSong = getCurrentSong();
        if (currentSong == null) return;
        
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
                builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, currentSong.getTitle());
                builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, currentSong.getArtist());
                builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, currentSong.getAlbum());
                builder.putString(android.media.MediaMetadata.METADATA_KEY_GENRE, currentSong.getGenre());
                builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
                builder.putLong(android.media.MediaMetadata.METADATA_KEY_TRACK_NUMBER, mCurrentIndex + 1);
                
                if (mCurrentPlaylist != null) {
                    builder.putLong(android.media.MediaMetadata.METADATA_KEY_NUM_TRACKS, mCurrentPlaylist.size());
                }
                
                mMediaSession.setMetadata(builder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession metadata", e);
            }
        }
        
        updateMediaSessionCompatMetadata();
    }
    
    private void updateMediaSessionCompatMetadata() {
        Song currentSong = getCurrentSong();
        if (currentSong == null || mMediaSessionCompat == null) return;
        
        try {
            android.support.v4.media.MediaMetadataCompat.Builder builder = 
                new android.support.v4.media.MediaMetadataCompat.Builder();
            builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentSong.getTitle());
            builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, currentSong.getArtist());
            builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, currentSong.getAlbum());
            builder.putString(MediaMetadataCompat.METADATA_KEY_GENRE, currentSong.getGenre());
            builder.putLong(MediaMetadataCompat.METADATA_KEY_DURATION, currentSong.getDuration());
            
            mMediaSessionCompat.setMetadata(builder.build());
        } catch (Exception e) {
            Log.e(TAG, "Failed to update MediaSessionCompat metadata", e);
        }
    }
    
    // ========================================================================
    // Audio Focus Methods
    // ========================================================================
    
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // No special handling needed for MediaPlayer
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                // No action needed
                break;
        }
    }
    
    // ========================================================================
    // Broadcast Helpers
    // ========================================================================
    
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    // ========================================================================
    // Media Button Handling (Legacy support)
    // ========================================================================
    
    public void handleMediaButton(int keyCode) {
        // This is now mostly redundant with MediaSession
        // Keep for any direct calls from activities if needed
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) resume();
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) pause();
                break;
            case KeyEvent.KEYCODE_MEDIA_STOP:
                if (mIsPlaying) pause();
                break;
            default:
                break;
        }
    }
    
    // ========================================================================
    // Metadata Refresh for Activities
    // ========================================================================
    
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null || !songPath.equals(current.getPath())) return;
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) updated.setUri(current.getUri());
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            
            updateMediaSessionMetadata();
            broadcastUpdate();
            createNotification();
        }
    }
    
    // ========================================================================
    // Close Action Handler
    // ========================================================================
    
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        resetPlayerSafely();
        releaseWakeLock();
        
        if (mCurrentPlaylist != null) mCurrentPlaylist.clear();
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
}