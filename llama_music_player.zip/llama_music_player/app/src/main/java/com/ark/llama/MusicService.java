// MusicService.java
package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Owns the playback state machine, the MediaPlayer lifecycle, and the
 * persisted playback preferences.
 *
 * <p>The service runs in the background and continues playback when
 * the application is not visible. Playback orchestration is owned by a
 * single state machine: a {@link ServiceState} enum, two monotonic
 * counters ({@link #mGeneration} and {@link #mStartToken}), and a
 * two-index model ({@link #mCurrentIndex} and {@link #mTargetIndex})
 * hold every transition-related value. State mutations happen on the
 * main thread; raw {@link MediaPlayer} calls run on a dedicated
 * {@link HandlerThread}. Only marshalled {@link Runnable}s cross
 * between them.</p>
 *
 * <p>{@link #mCurrentIndex} is the index the MediaPlayer is bound to.
 * {@link #mTargetIndex} is the index the state machine is driving
 * toward. While the state is PREPARING, {@code mCurrentIndex} still
 * reflects the outgoing song and {@code mTargetIndex} is the
 * destination. Every request method mutates {@code mTargetIndex} only;
 * {@link #reconcile()} decides whether a transition begins.</p>
 *
 * <h3>Audio-Focus Interruptions</h3>
 * <p>An interruption that arrives while the state machine is live is
 * recorded once, as an {@link Interruption}. The record is cleared by
 * any user-initiated transition, by a successful resume, and by a
 * transition to idle. The record drives three decisions: whether a
 * gain resumes playback
 * ({@link #shouldResumeAfterInterruption()}), whether the playback
 * notification stays a foreground notification through the
 * interruption ({@link #shouldRemainForeground()}), and whether a
 * subsequent loss of a different kind is ignored rather than
 * overwriting the record ({@link #handleAudioFocusChange(int)}).</p>
 *
 * <p>Gain goes through {@link #resumeAfterInterruption()}, which
 * retries focus acquisition for a bounded window. The telephony
 * stack holds focus through its own teardown after a call ends, and
 * a single {@code requestAudioFocus} inside the gain callback fails
 * on a meaningful fraction of devices.</p>
 *
 * <h3>Bluetooth Disconnect</h3>
 * <p>A Bluetooth disconnect pauses playback only when the headset
 * was the active output, no other interruption is already handling
 * the pause, and playback was running. The pause is confirmed after
 * a short settling window, which distinguishes a disconnect from a
 * link flap. The pending confirmation is cancelled by any
 * user-initiated transition.</p>
 *
 * <h3>The Playback Window</h3>
 * <p>{@link #getWindowSnapshot()} returns the single source of truth
 * for the three-slot album-art carousel. The window names the
 * previous neighbour, the display song, and the next neighbour. It is
 * computed from two pure functions, {@link #peekPreviousIndex(int)}
 * and {@link #peekNextIndex(int)}, which return the positional or
 * shuffle-chosen neighbour under every repeat mode. The carousel
 * does not compute neighbours; it renders the window.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every state mutation runs on the main thread through
 * {@link #onMain(Runnable)}. Every raw MediaPlayer call runs on
 * {@link #mPlayerThread} through {@link #onPlayer(Runnable)}. Bitmap
 * decoding and playlist reorders run on dedicated single-thread
 * executors.</p>
 *
 * @see MusicPlayer
 * @see MediaPlayer
 * @see NotificationController
 * @see EqualizerManager
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.0.0
 */
public class MusicService extends Service {

    /**
     * True while this service holds audio focus; read by volume-resume paths.
     */
    private volatile boolean mHasAudioFocus = false;


    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for the persisted repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for the persisted shuffle flag. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for the persisted player-state-before-update flag. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE =
        "player_state_before_update";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for the persisted playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /**
     * Shared-preferences key under which the active playback scope
     * is persisted as a serialized {@link PlaybackScope}.
     */
    private static final String KEY_PLAYBACK_SCOPE = "playback_scope_json";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that carries a genre update. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action that sets a pending song path. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Broadcast action that carries a new audio session identifier. */
    private static final String ACTION_AUDIO_SESSION_CHANGED =
        "com.ark.llama.AUDIO_SESSION_CHANGED";

    /**
     * Broadcast action that applies a new playback scope. The intent
     * carries a serialized scope under
     * {@link #EXTRA_SCOPE_JSON}.
     */
    private static final String ACTION_APPLY_PLAYBACK_SCOPE =
        "APPLY_PLAYBACK_SCOPE";

    /** Broadcast action announcing that a song's metadata was written. */
    private static final String ACTION_METADATA_UPDATED =
        "METADATA_UPDATED";

    /**
     * Broadcast action emitted after a favorite commit. Consumers that
     * render hearts — {@link PlaylistAdapter},
     * {@link MusicPlayer} — listen for it to refresh their tint
     * without waiting for the next {@code UPDATE_PLAYER} turn.
     */
    private static final String ACTION_FAVORITE_CHANGED =
        "FAVORITE_CHANGED";

    /** Intent extra carrying a serialized {@link PlaybackScope}. */
    private static final String EXTRA_SCOPE_JSON = "scope_json";

    /** Service action that resumes playback after a headset connect. */
    private static final String ACTION_BLUETOOTH_RESUME =
        "ACTION_BLUETOOTH_RESUME";

    /**
     * Broadcast action that requests a pause after a Bluetooth
     * disconnect. Sent by {@link BluetoothReceiver} when the headset
     * or A2DP profile disconnects; received by the service so the
     * pause fires whether or not the player activity is alive.
     */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";

    /** Extra key carrying the disconnecting profile's action. */
    private static final String EXTRA_PROFILE_ACTION = "profile_action";

    /** Extra key carrying the disconnecting profile's state value. */
    private static final String EXTRA_PROFILE_STATE = "profile_state";

    /** Broadcast action sent by the system audio service when a stream's volume changes. */
    private static final String VOLUME_CHANGED_ACTION =
        "android.media.VOLUME_CHANGED_ACTION";

    /** Extra key carrying the type of stream whose volume changed. */
    private static final String EXTRA_VOLUME_STREAM_TYPE =
        "android.media.EXTRA_VOLUME_STREAM_TYPE";

    /** Extra key carrying the resolved stream type when the changed stream is aliased. */
    private static final String EXTRA_VOLUME_STREAM_TYPE_ALIAS =
        "android.media.EXTRA_VOLUME_STREAM_TYPE_ALIAS";

    /** Extra key carrying the new volume of the stream that changed. */
    private static final String EXTRA_VOLUME_STREAM_VALUE =
        "android.media.EXTRA_VOLUME_STREAM_VALUE";

    /**
     * Debounce window for transport actions, in milliseconds.
     *
     * <p>Matches the debounce the player screen applies to its own
     * buttons. A rapid double-tap on any transport surface — the
     * notification, the lockscreen, a headset, the player screen —
     * collapses to one action. The debounce is per action, so a
     * play/pause tap does not absorb a following next tap.</p>
     */
    private static final long NOTIFICATION_ACTION_DEBOUNCE_MS = 500L;

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500L;

    /** Maximum position advance a healthy stream is allowed to sit idle, in milliseconds. */
    private static final long MAX_STALL_TIME_MS = 1500L;

    /** Number of consecutive stalls before the service skips to the next track. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    /** Maximum duration of a continuous skip loop, in milliseconds. */
    private static final long SKIP_LOOP_BUDGET_MS = 2500L;

    /**
     * Output volume applied to the MediaPlayer while audio focus is
     * ducked.
     *
     * <p>A duck is a scale applied to the MediaPlayer's own output,
     * not a change to the system stream volume. The value is small
     * enough to be clearly audible as a duck and large enough that
     * the music remains legible underneath the interrupting app.</p>
     */
    private static final float DUCK_VOLUME_FRACTION = 0.2f;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int NOTIFICATION_ART_MAX_PX = 300;

    /** Size of the notification album art cache, in megabytes. */
    private static final int NOTIFICATION_ART_CACHE_MB = 25;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Number of health-check intervals between periodic position checkpoints. */
    private static final int POSITION_SAVE_INTERVAL_TICKS = 10;

    /** Audio session identifier most recently attached to the equalizer. */
    private static int sCurrentAudioSessionId = 0;

    // ============================================================================
    // State Machine
    // ============================================================================

    /**
     * Exhaustive states of the playback state machine.
     */
    private enum ServiceState {

        /** Nothing is bound to the MediaPlayer. */
        IDLE,

        /** A transition is in flight; the target is not yet bound. */
        PREPARING,

        /** A track is prepared but not started. */
        READY,

        /** A track is playing. */
        PLAYING,

        /** A track is prepared, paused, and retains its position. */
        PAUSED,

        /** The service is in the middle of tearing down. */
        STOPPING
    }

    /** Current state of the playback state machine. */
    private ServiceState mState = ServiceState.IDLE;

    /** Monotonic counter that identifies the current transition. */
    private long mGeneration = 0L;

    /**
     * Monotonic counter that identifies the current start or resume
     * continuation.
     *
     * <p>Incremented at the top of {@link #doResumeInternal()},
     * {@link #doPause()}, and
     * {@link #onPrepared(long, int, int, Song, int)}. The async
     * continuation a resume queues captures the value at the moment
     * it begins and compares it against this field before rolling
     * the state back: a mismatch means a later operation has
     * superseded the resume, and the rollback must not fire.</p>
     */
    private long mStartToken = 0L;

    /** Index the MediaPlayer is bound to. */
    private int mCurrentIndex = -1;

    /** Index the state machine is driving toward. */
    private int mTargetIndex = -1;

    /** Position requested for the next prepare, in milliseconds. */
    private int mPendingSeekPosition = 0;

    /** True when the next reconciliation must re-prepare the current track. */
    private boolean mForceReprepare = false;

    /** True when a pause arrived during PREPARING and must be honoured at commit. */
    private boolean mPauseAfterPrepare = false;

    /** True when the prepare should start playback on completion. */
    private boolean mAutoStartOnPrepared = true;

    /**
     * True when a transition request arrived while a transition was
     * already in flight.
     *
     * <p>Set by {@link #reconcile()} when it bails on a state of
     * {@link ServiceState#PREPARING}. Cleared by
     * {@link #reconcile()} before it calls
     * {@link #beginTransition(int, int)}, and by the completion of
     * the transition that first observed it.</p>
     */
    private boolean mDeferredReconcile = false;

    /**
     * Direction of the current generation's transition.
     *
     * <p>{@code +1} for a forward transition, {@code -1} for a
     * backward one, {@code 0} when the transition has no spatial
     * direction. Consumed from {@link #mNotedDirection} by
     * {@link #beginTransition(int, int)} and published by
     * {@link #broadcastUpdate()}.</p>
     */
    private int mGenerationDirection = 0;

    /**
     * True when the current generation's transition restarts the
     * current song.
     *
     * <p>Consumed from {@link #mNotedRestart} by
     * {@link #beginTransition(int, int)} and published by
     * {@link #broadcastUpdate()}.</p>
     */
    private boolean mGenerationRestart = false;

    /**
     * Direction noted for the next transition to begin.
     *
     * <p>Written by each transition entry point at the moment it
     * decides the target. Consumed by
     * {@link #beginTransition(int, int)} into
     * {@link #mGenerationDirection} and cleared.</p>
     */
    private int mNotedDirection = 0;

    /**
     * Restart flag noted for the next transition to begin.
     */
    private boolean mNotedRestart = false;

    /** Timestamp at which the current PLAYING state began. */
    private long mPlaybackStartElapsed = 0L;

    /** Consecutive stall recovery attempts since the last healthy playback. */
    private int mRecoveryAttempts = 0;

    /** Timestamp at which the current skip loop began. */
    private long mSkipLoopStartedElapsed = 0L;

    /** Ticks accumulated since the last periodic position checkpoint. */
    private int mPositionSaveTickCounter = 0;

    /** Handler that runs every state mutation on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Handler for health checks; null when not monitoring. */
    private Handler mHealthHandler;

    /** Runnable for the periodic health check. */
    private Runnable mHealthCheckRunnable;

    /**
     * Per-action timestamps used to debounce transport actions.
     */
    @NonNull
    private final HashMap<String, Long> mLastNotificationActionTime =
        new HashMap<>();

    // ============================================================================
    // Audio-Focus Interruption Record and Bluetooth Confirmation
    // ============================================================================

    /**
     * The kind of interruption that paused playback.
     *
     * <p>Mirrors the two audio-focus loss callbacks the framework
     * delivers: {@link #TRANSIENT_LOSS} corresponds to
     * {@code AUDIOFOCUS_LOSS_TRANSIENT}, and
     * {@link #PERMANENT_LOSS} corresponds to
     * {@code AUDIOFOCUS_LOSS}. The distinction is diagnostic and,
     * if the resume policy ever needs to branch on it, the branch
     * point.</p>
     */
    private enum InterruptionKind {
        /** A transient loss; the framework will deliver a gain. */
        TRANSIENT_LOSS,
        /** A permanent loss; a gain may or may not follow. */
        PERMANENT_LOSS
    }

    /**
     * The single record of "an interruption occurred and the user
     * has not overridden it."
     *
     * <p>Written by {@link #handleAudioFocusChange(int)} on the
     * first loss that interrupts a live transition. Cleared only by
     * a successful resume from
     * {@link #resumeAfterInterruption()}, by any user-initiated
     * transition, or by {@link #transitionToIdle()}.</p>
     */
    private static final class Interruption {
        @NonNull final InterruptionKind kind;
        final long startedAtElapsed;
        /** True when the state was PLAYING at the moment of the loss. */
        final boolean wasPlaying;
        /**
         * The generation that was current when the interruption
         * began. A later transition advances {@code mGeneration},
         * and the record no longer matches. That mismatch is what
         * prevents a gain that arrives after the user has moved
         * on from resurrecting playback.
         */
        final long generationAtStart;

        Interruption(@NonNull InterruptionKind kind,
                     long startedAtElapsed,
                     boolean wasPlaying,
                     long generationAtStart) {
            this.kind = kind;
            this.startedAtElapsed = startedAtElapsed;
            this.wasPlaying = wasPlaying;
            this.generationAtStart = generationAtStart;
        }
    }

    @Nullable private Interruption mInterruption;

    private static final int RESUME_RETRY_ATTEMPTS = 12;
    private static final long RESUME_RETRY_INTERVAL_MS = 500L;

    private int mResumeRetryCount = 0;
    @Nullable private Runnable mResumeRetryRunnable;

    /**
     * Settling window between a Bluetooth-disconnect broadcast and
     * the pause it requests.
     */
    private static final long BLUETOOTH_DISCONNECT_CONFIRM_MS = 400L;

    @Nullable private Runnable mBluetoothPauseConfirmRunnable;

    // ============================================================================
    // Shuffle Peek Memos and Window Cache
    // ============================================================================

    private boolean mShuffleNextPeekValid = false;
    private int mShuffleNextPeekFromIndex = -1;
    private int mShuffleNextPeekResult = -1;

    private boolean mShufflePrevPeekValid = false;
    private int mShufflePrevPeekFromIndex = -1;
    private int mShufflePrevPeekResult = -1;

    @Nullable private PlaybackWindow mCachedWindow = null;

    // ============================================================================
    // MediaPlayer
    // ============================================================================

    /** MediaPlayer instance, or null when released. */
    private MediaPlayer mMediaPlayer;

    /** Thread on which every raw MediaPlayer call runs. */
    private HandlerThread mPlayerThread;

    /** Handler bound to {@link #mPlayerThread}. */
    private Handler mPlayerHandler;

    /** Wake lock held while playback is running. */
    private PowerManager.WakeLock mWakeLock;

    // ============================================================================
    // Notification Album Art
    // ============================================================================

    private final ExecutorService mArtLoader =
        Executors.newSingleThreadExecutor();

    private final ExecutorService mSortExecutor =
        Executors.newSingleThreadExecutor();

    private LruCache<String, Bitmap> mArtCache;

    private Future<?> mCurrentArtLoad = null;

    @Nullable private String mResolvedArtPath = null;
    @Nullable private Bitmap mResolvedArt = null;

    // ============================================================================
    // Notification State Source
    // ============================================================================

    private final NotificationController.ServiceStateSource mStateSource =
        new NotificationController.ServiceStateSource() {

            @Nullable
            @Override
            public NotificationController.RenderSnapshot
                    snapshotForNotification() {
                // The display song is the same value broadcastUpdate
                // writes to the player screen for the same
                // generation. getDisplaySong returns the target during
                // PREPARING and the current-index song in every other
                // state, so a broadcast that fires during a transition
                // and the commit it triggers render the same song.
                final Song displaySong = getDisplaySong();

                if (displaySong == null) {
                    return null;
                }

                final String displayPath = displaySong.getPath();
                if (displayPath == null) {
                    return null;
                }

                final boolean artResolved =
                    displayPath.equals(mResolvedArtPath);
                final Bitmap resolvedArt =
                    artResolved ? mResolvedArt : null;
                final String album = displaySong.getAlbum() != null
                    ? displaySong.getAlbum() : "";

                return new NotificationController.RenderSnapshot(
                    displaySong.getTitle() != null
                        ? displaySong.getTitle() : "",
                    displaySong.getArtist() != null
                        ? displaySong.getArtist() : "",
                    album,
                    displayPath,
                    isPlaying(),
                    mCachedDuration,
                    resolvedArt,
                    artResolved);
            }

            @Override
            public boolean isIdle() {
                return mState == ServiceState.IDLE;
            }

            @Override
            public int sessionPlaybackState() {
                switch (mState) {
                    case PLAYING:
                        return PlaybackStateCompat.STATE_PLAYING;
                    case PAUSED:
                    case READY:
                        return PlaybackStateCompat.STATE_PAUSED;
                    case PREPARING:
                        return (mAutoStartOnPrepared
                            && !mPauseAfterPrepare)
                            ? PlaybackStateCompat.STATE_PLAYING
                            : PlaybackStateCompat.STATE_PAUSED;
                    case IDLE:
                    case STOPPING:
                    default:
                        return PlaybackStateCompat.STATE_NONE;
                }
            }

            @Override
            public void updateSessionPlaybackState() {
                updateMediaSessionPlaybackState();
            }

            @Override
            public long getGeneration() {
                return mGeneration;
            }

            @Override
            public boolean shouldRemainForeground() {
                return MusicService.this.shouldRemainForeground();
            }

            @Override
            public void applyToMediaSession(
                    @Nullable NotificationController.RenderSnapshot
                        snapshot) {
                if (mMediaSession == null) {
                    return;
                }
                try {
                    MediaMetadataCompat.Builder builder =
                        new MediaMetadataCompat.Builder();
                    if (snapshot != null) {
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_TITLE,
                            snapshot.title);
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ARTIST,
                            snapshot.artist);
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ALBUM,
                            snapshot.album);
                        builder.putLong(
                            MediaMetadataCompat.METADATA_KEY_DURATION,
                            snapshot.durationMs);

                        if (snapshot.artResolved
                                && snapshot.art != null
                                && !snapshot.art.isRecycled()) {
                            builder.putBitmap(
                                MediaMetadataCompat
                                    .METADATA_KEY_ALBUM_ART,
                                snapshot.art);
                        } else if (mNotificationController != null) {
                            Bitmap placeholder =
                                mNotificationController
                                    .getPlaceholderForMediaSession();
                            if (placeholder != null
                                    && !placeholder.isRecycled()) {
                                builder.putBitmap(
                                    MediaMetadataCompat
                                        .METADATA_KEY_ALBUM_ART,
                                    placeholder);
                            }
                        }
                    } else {
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_TITLE, "");
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ARTIST, "");
                        builder.putString(
                            MediaMetadataCompat.METADATA_KEY_ALBUM, "");
                    }
                    mMediaSession.setMetadata(builder.build());
                } catch (Exception exception) {
                    Log.e(TAG, "applyToMediaSession failed", exception);
                }
            }
        };

    // ============================================================================
    // Cached Playback Facts
    // ============================================================================

    private int mCachedDuration = 0;
    private int mCachedAudioSessionId = 0;
    private int mCachedPosition = 0;
    private int mPlaybackBasePosition = 0;
    private long mPlaybackBaseElapsed = 0L;
    private long mPositionEpoch = 0L;

    // ============================================================================
    // Playlist and Playback State
    // ============================================================================

    private ArrayList<Song> mCurrentPlaylist;
    @Nullable private ArrayList<Song> mFullPlaylist;
    @Nullable private ArrayList<Song> mScopedPlaylist;

    @NonNull
    private PlaybackScope mPlaybackScope = PlaybackScope.ALL_SONGS;

    @NonNull
    private Set<String> mLooseTrackPaths = new HashSet<>();

    private volatile int mRepeatMode = 0;
    private volatile boolean mIsShuffle = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;
    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;

    private volatile String mPendingSongPath = null;

    // ============================================================================
    // Binder, Library, Notification Controller
    // ============================================================================

    private final IBinder mBinder = new LocalBinder();
    private MusicLibrary mMusicLibrary;
    @Nullable private NotificationController mNotificationController;

    // ============================================================================
    // Audio Focus and Session
    // ============================================================================

    @Nullable private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    @Nullable private AudioFocusRequest mAudioFocusRequest;
    @Nullable private AudioFocusRequest mAudioFocusRequestTransient;
    @Nullable private MediaSessionCompat mMediaSession;
    private volatile boolean mIsBluetoothConnected = false;
    private volatile boolean mIsDucked = false;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mMetadataUpdatedReceiver;
    private BroadcastReceiver mUpdatePlaylistReceiver;
    private BroadcastReceiver mSetPendingSongReceiver;
    private BroadcastReceiver mLibraryResetReceiver;
    private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMusicVolumeReceiver;
    private BroadcastReceiver mApplyScopeReceiver;

    // ============================================================================
    // Inner Classes
    // ============================================================================

    /**
     * Binder returned from {@link #onBind(Intent)}.
     */
    public class LocalBinder extends Binder {

        /**
         * Returns the service instance.
         *
         * @return The bound service
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ============================================================================
    // Sort Comparators
    // ============================================================================

    /**
     * Orders songs by title, ascending.
     */
    private class TitleAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, ignoring case.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null
                ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null
                ? "" : secondSong.getTitle();
            return firstTitle.compareToIgnoreCase(secondTitle);
        }
    }

    /**
     * Orders songs by title, descending.
     */
    private class TitleZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by title, ignoring case, descending.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstTitle = firstSong.getTitle() == null
                ? "" : firstSong.getTitle();
            String secondTitle = secondSong.getTitle() == null
                ? "" : secondSong.getTitle();
            return secondTitle.compareToIgnoreCase(firstTitle);
        }
    }

    /**
     * Orders songs by artist, ascending, with title as the tiebreaker.
     */
    private class ArtistAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, ignoring case, with title
         * as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null
                ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null
                ? "" : secondSong.getArtist();
            int comparisonResult =
                firstArtist.compareToIgnoreCase(secondArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by artist, descending, with title as the tiebreaker.
     */
    private class ArtistZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by artist, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstArtist = firstSong.getArtist() == null
                ? "" : firstSong.getArtist();
            String secondArtist = secondSong.getArtist() == null
                ? "" : secondSong.getArtist();
            int comparisonResult =
                secondArtist.compareToIgnoreCase(firstArtist);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, ascending, with title as the tiebreaker.
     */
    private class AlbumAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, ignoring case, with title as
         * the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null
                ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null
                ? "" : secondSong.getAlbum();
            int comparisonResult =
                firstAlbum.compareToIgnoreCase(secondAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by album, descending, with title as the tiebreaker.
     */
    private class AlbumZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by album, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstAlbum = firstSong.getAlbum() == null
                ? "" : firstSong.getAlbum();
            String secondAlbum = secondSong.getAlbum() == null
                ? "" : secondSong.getAlbum();
            int comparisonResult =
                secondAlbum.compareToIgnoreCase(firstAlbum);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, ascending, with title as the tiebreaker.
     */
    private class GenreAZComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, ignoring case, with title as
         * the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null
                ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null
                ? "" : secondSong.getGenre();
            int comparisonResult =
                firstGenre.compareToIgnoreCase(secondGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by genre, descending, with title as the tiebreaker.
     */
    private class GenreZAComparator implements Comparator<Song> {

        /**
         * Compares two songs by genre, ignoring case, descending,
         * with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            String firstGenre = firstSong.getGenre() == null
                ? "" : firstSong.getGenre();
            String secondGenre = secondSong.getGenre() == null
                ? "" : secondSong.getGenre();
            int comparisonResult =
                secondGenre.compareToIgnoreCase(firstGenre);
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, oldest first, with
     * title as the tiebreaker.
     */
    private class OldestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, oldest
         * first, with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(firstSong), getSongDate(secondSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Orders songs by file modification time, newest first, with
     * title as the tiebreaker.
     */
    private class NewestFirstComparator implements Comparator<Song> {

        /**
         * Compares two songs by file modification time, newest
         * first, with title as the tiebreaker.
         *
         * @param firstSong First song
         * @param secondSong Second song
         * @return A negative integer, zero, or a positive integer
         */
        public int compare(Song firstSong, Song secondSong) {
            int comparisonResult = Long.compare(
                getSongDate(secondSong), getSongDate(firstSong));
            if (comparisonResult != 0) {
                return comparisonResult;
            }
            return new TitleAZComparator()
                .compare(firstSong, secondSong);
        }
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch,
     *         or 0 when the song or its path is null
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) {
            return 0;
        }
        return new File(song.getPath()).lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the
     * given sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:  return new TitleAZComparator();
            case SORT_TITLE_ZA:  return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ:  return new AlbumAZComparator();
            case SORT_ALBUM_ZA:  return new AlbumZAComparator();
            case SORT_GENRE_AZ:  return new GenreAZComparator();
            case SORT_GENRE_ZA:  return new GenreZAComparator();
            case SORT_OLDEST:    return new OldestFirstComparator();
            case SORT_NEWEST:    return new NewestFirstComparator();
            default:             return new TitleAZComparator();
        }
    }

    // ============================================================================
    // Static Helpers
    // ============================================================================

    /**
     * Persists the player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @param need New value of the flag
     */
    public static void setPlayerStateBeforeUpdate(
            @NonNull Context context, boolean need) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need)
            .apply();
    }

    /**
     * Returns the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     * @return The persisted flag value
     */
    public static boolean getPlayerStateBeforeUpdate(
            @NonNull Context context) {
        return context.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the persisted player-state-before-update flag.
     *
     * @param context Context used to access preferences
     */
    public static void clearPlayerStateBeforeUpdate(
            @NonNull Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the audio session identifier most recently attached to
     * the equalizer.
     *
     * @return The audio session identifier, or 0 when no session is
     *         attached
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ============================================================================
    // Private Helpers
    // ============================================================================

    /**
     * Returns whether the given list contains a song at the given
     * path.
     *
     * @param list List to search
     * @param path Path to look for
     * @return True when the list contains a song with the given path
     */
    private boolean containsPath(@NonNull ArrayList<Song> list,
                                 @Nullable String path) {
        if (path == null) {
            return false;
        }
        for (Song song : list) {
            if (song != null && path.equals(song.getPath())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the song with the given path from
     * {@link #mFullPlaylist}, or null when it is not present.
     *
     * @param path Path to look for
     * @return The song, or null
     */
    @Nullable
    private Song findSongInFull(@Nullable String path) {
        if (path == null || mFullPlaylist == null) {
            return null;
        }
        for (Song song : mFullPlaylist) {
            if (song != null && path.equals(song.getPath())) {
                return song;
            }
        }
        return null;
    }

    /**
     * Reloads {@link #mLooseTrackPaths} from the loose-songs table.
     *
     * <p>Called by {@link #rebuildPlaylists()} so the loose-tracks
     * scope can recognise which songs are loose without asking the
     * database on every {@link PlaybackScope#matches(Song, Set)}
     * call.</p>
     */
    private void refreshLooseTrackPaths() {
        mLooseTrackPaths.clear();
        try {
            ArrayList<Song> loose = SongDatabase.getInstance(this).getLooseSongs();
            if (loose != null) {
                for (Song song : loose) {
                    if (song != null && song.getPath() != null) {
                        mLooseTrackPaths.add(song.getPath());
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "Failed to refresh loose track paths", exception);
        }
    }

    // ============================================================================
    // Service Lifecycle
    // ============================================================================

    /**
     * Initializes the service: installs the notification controller,
     * loads persisted preferences, sets up the media session and
     * audio focus, starts the player thread, and registers the
     * service's long-lived receivers.
     *
     * <p>The music volume receiver is registered in
     * {@link #onBind(Intent)} and unregistered in
     * {@link #onDestroy()}, so its lifetime is the session's
     * lifetime rather than the service's. A service created without
     * the user opening the player has no bound client and therefore
     * does not treat a hardware volume press as a transport
     * control.</p>
     *
     * <p>The Bluetooth pause receiver is registered in
     * {@link #onCreate()} and unregistered in
     * {@link #onDestroy()}, so a headset disconnect pauses playback
     * for the service's whole lifetime, whether or not any activity
     * is alive to observe it.</p>
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "MusicService onCreate");

        final int artCacheSize =
            NOTIFICATION_ART_CACHE_MB * 1024 * 1024;
        mArtCache = new LruCache<String, Bitmap>(artCacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mPlayerThread = new HandlerThread("MediaPlayerThread");
        mPlayerThread.start();
        mPlayerHandler = new Handler(mPlayerThread.getLooper());

        mNotificationController =
            NotificationController.getInstance(this);
        mNotificationController.attachService(this);
        mNotificationController.setStateSource(mStateSource);
        mNotificationController.setSessionTokenProvider(
            this::getSessionToken);

        mAudioManager =
            (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();
        loadPlaybackScope();
        setupMediaSession();
        setupAudioFocus();

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        mHealthHandler = new Handler(Looper.getMainLooper());
        installHealthCheckRunnable();

        PowerManager powerManager =
            (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
        }

        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerSyncCompleteReceiver();
        registerGenreUpdateReceiver();
        registerMetadataUpdatedReceiver();
        registerUpdatePlaylistReceiver();
        registerSetPendingSongReceiver();
        registerLibraryResetReceiver();
        registerApplyScopeReceiver();
        registerBluetoothPauseReceiver();

        mMusicLibrary = new MusicLibrary(this);

        Log.d(TAG, "MusicService onCreate complete");
    }

    /**
     * Handles a start command from an intent, dispatching on its
     * action.
     *
     * <p>A command with a null intent is the sticky restart the
     * system performs after the process has been reclaimed. The
     * persisted playback state is read and the notification is
     * re-posted from it, so the user's shade is not left empty
     * after a process kill. A command with an intent is a normal
     * action dispatch.</p>
     *
     * @param intent The intent delivered to the service, or null
     *        on a sticky restart
     * @param flags Additional data about the start request
     * @param startId Unique identifier for the start request
     * @return The sticky restart mode
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) {
            onMain(this::restoreNotificationFromPersistedState);
            return START_STICKY;
        }

        final String action = intent.getAction();

        if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
            KeyEvent event;
            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.TIRAMISU) {
                event = intent.getParcelableExtra(
                    Intent.EXTRA_KEY_EVENT, KeyEvent.class);
            } else {
                @SuppressWarnings("deprecation")
                KeyEvent deprecatedEvent =
                    intent.getParcelableExtra(
                        Intent.EXTRA_KEY_EVENT);
                event = deprecatedEvent;
            }
            if (event != null
                    && event.getAction() == KeyEvent.ACTION_DOWN
                    && mMediaSession != null) {
                mMediaSession.getController()
                    .dispatchMediaButtonEvent(event);
            }
            return START_STICKY;
        }

        if (isNotificationActionDebounced(action)) {
            return START_STICKY;
        }

        if (action.equals("ACTION_PLAY_PAUSE")) {
            togglePlayPause();
        } else if (action.equals("ACTION_NEXT")) {
            playNextSong();
        } else if (action.equals("ACTION_PREV")) {
            playPreviousSong();
        } else if (action.equals("ACTION_STOP")) {
            pause();
        } else if (action.equals(ACTION_BLUETOOTH_RESUME)) {
            handleBluetoothResume();
        } else if (action.equals("PLAY_SONG")) {
            String songPath = intent.getStringExtra("song_path");
            if (songPath != null) {
                playSongByPath(songPath);
            } else {
                int position = intent.getIntExtra("position", -1);
                if (position >= 0) {
                    playSong(position);
                }
            }
        } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
            updatePlaybackParams();
        }
        return START_STICKY;
    }

    /**
     * Returns whether the given transport action arrived inside the
     * debounce window.
     *
     * <p>Matches the player screen's own debounce on its buttons. A
     * rapid double-tap on any surface — the notification's
     * play/pause, next, or previous buttons; a media session callback
     * invoked by a rapid physical media button; the notification's
     * close action — collapses to one action.</p>
     *
     * @param action Action to test
     * @return True when the action should be debounced
     */
    private boolean isNotificationActionDebounced(
            @NonNull String action) {
        if (!"ACTION_PLAY_PAUSE".equals(action)
                && !"ACTION_NEXT".equals(action)
                && !"ACTION_PREV".equals(action)) {
            return false;
        }
        final long now = SystemClock.elapsedRealtime();
        final Long last = mLastNotificationActionTime.get(action);
        if (last != null
                && now - last < NOTIFICATION_ACTION_DEBOUNCE_MS) {
            return true;
        }
        mLastNotificationActionTime.put(action, now);
        return false;
    }

    /**
     * Handles a Bluetooth resume request by preparing the last
     * played song, resuming playback, and reloading the full library
     * in the background.
     */
    private void handleBluetoothResume() {
        onMain(() -> {
            final String lastPath = getSavedSongPath();
            if (lastPath == null || !new File(lastPath).exists()) {
                transitionToIdle();
                stopSelf();
                return;
            }

            Song lastSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (lastSong == null) {
                lastSong = CharacterMapper.getSongFromFile(lastPath);
            }
            if (lastSong == null) {
                transitionToIdle();
                stopSelf();
                return;
            }

            final ArrayList<Song> singleSong = new ArrayList<>();
            singleSong.add(lastSong);
            setPlaylist(singleSong, true);
            resume();

            if (mMusicLibrary == null) {
                mMusicLibrary = new MusicLibrary(this);
            }
            mMusicLibrary.loadAllSongsAsync(
                new MusicLibrary.OnSongsLoadedListener() {

                    /**
                     * Replaces the single-song playlist with the
                     * full library once the background load
                     * completes.
                     *
                     * @param songs The loaded list of songs
                     */
                    @Override
                    public void onSongsLoaded(
                            ArrayList<Song> songs) {
                        onMain(() -> {
                            if (songs != null && !songs.isEmpty()) {
                                setPlaylist(songs, true);
                            }
                        });
                    }

                    /**
                     * Logs the failure; the single-song playlist
                     * remains active.
                     *
                     * @param error Description of the failure
                     */
                    @Override
                    public void onLoadingError(String error) {
                        Log.w(TAG,
                            "Full library load after BT resume failed: "
                                + error);
                    }
                });
        });
    }

    /**
     * Restores the playback notification from the persisted state
     * without starting playback.
     *
     * <p>Called from {@link #onStartCommand(Intent, int, int)} on a
     * sticky restart — a command with a null intent — so the user's
     * notification shade is not left empty after a process kill. The
     * persisted last song path is read, resolved against the
     * database, and committed to the notification through
     * {@link NotificationController#commitFromBroadcast(long,
     * NotificationController.RenderSnapshot)} as a paused snapshot.
     * No playback is started, and the state machine stays at IDLE
     * until the user acts.</p>
     */
    private void restoreNotificationFromPersistedState() {
        if (mNotificationController == null) {
            return;
        }
        final String lastPath = getSavedSongPath();
        if (lastPath == null || lastPath.isEmpty()) {
            return;
        }
        Song lastSong =
            SongDatabase.getInstance(this).getSong(lastPath);
        if (lastSong == null) {
            return;
        }
        final String title = lastSong.getTitle() != null
            ? lastSong.getTitle() : "";
        final String artist = lastSong.getArtist() != null
            ? lastSong.getArtist() : "";
        final String album = lastSong.getAlbum() != null
            ? lastSong.getAlbum() : "";

        final NotificationController.RenderSnapshot snapshot =
            new NotificationController.RenderSnapshot(
                title, artist, album, lastPath,
                false, mCachedDuration, null, false);

        mNotificationController.commitFromBroadcast(
            mGeneration, snapshot);
    }

    /**
     * Returns the binder that exposes this service to bound clients,
     * and registers the music volume receiver.
     *
     * <p>Binding is the "player opened" signal.
     * {@link MusicPlayer} starts the service and binds it in
     * {@code proceedWithInitialization()}; it is the only
     * {@link android.content.ServiceConnection} in the process. A
     * service created without a bind — a {@code START_STICKY}
     * restart, a Bluetooth connect via {@link BluetoothReceiver}, a
     * media button delivered by {@code MediaButtonReceiver} — has
     * no client and never reaches this method.</p>
     *
     * <p>The music volume receiver is registered here and nowhere
     * else. Its presence is the session state: there is no separate
     * flag to fall out of sync with it, and a registration failure
     * leaves {@code mMusicVolumeReceiver} null so the next bind
     * retries.</p>
     *
     * @param intent Intent that triggered the binding
     * @return The binder
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        registerMusicVolumeReceiver();
        return mBinder;
    }

    /**
     * Releases every resource held by the service.
     *
     * <p>The player release is queued on the player thread before
     * that thread is asked to quit safely. Teardown does not wait on
     * the service main thread for the player thread to finish.</p>
     *
     * <p>{@link #clearInterruption()} is called at the top so a
     * pending resume retry, a pending Bluetooth disconnect
     * confirmation, and the interruption record itself are all
     * released before the other teardown steps run.</p>
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");

        clearInterruption();
        stopHealthMonitoring();
        saveFullState();
        savePlayerState();

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtLoader != null && !mArtLoader.isShutdown()) {
            mArtLoader.shutdownNow();
        }
        if (mSortExecutor != null && !mSortExecutor.isShutdown()) {
            mSortExecutor.shutdownNow();
        }

        if (mPlayerHandler != null) {
            mPlayerHandler.post(this::releaseMediaPlayer);
        }
        if (mPlayerThread != null) {
            mPlayerThread.quitSafely();
            mPlayerThread = null;
            mPlayerHandler = null;
        }

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        releaseWakeLock();
        mState = ServiceState.STOPPING;

        if (mNotificationController != null) {
            mNotificationController.detachService();
            mNotificationController = null;
        }

        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }

        abandonAudioFocus();

        unregisterMusicVolumeReceiver();

        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mUpdatePlaylistReceiver);
        unregisterReceiverSafely(mSetPendingSongReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mApplyScopeReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);

        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    /**
     * Checkpoints the position when memory pressure rises, and
     * releases caches that can be rebuilt.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        onMain(() -> {
            if (mState == ServiceState.PLAYING) {
                savePlayingState();
            }
            if (level >= TRIM_MEMORY_BACKGROUND && mArtCache != null) {
                mArtCache.evictAll();
            }
            reconcile();
        });
    }

    /**
     * Saves the full player state before the task is removed.
     *
     * @param rootIntent The original root intent
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ============================================================================
    // Thread Marshalling and Small Helpers
    // ============================================================================

    /**
     * Runs the given action on the main thread.
     *
     * @param action Action to run
     */
    private void onMain(@NonNull Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action.run();
        } else {
            mMainHandler.post(action);
        }
    }

    /**
     * Runs the given action on the player thread.
     *
     * @param action Action to run
     */
    private void onPlayer(@NonNull Runnable action) {
        if (mPlayerHandler == null) {
            return;
        }
        if (Looper.myLooper() == mPlayerHandler.getLooper()) {
            action.run();
        } else {
            mPlayerHandler.post(action);
        }
    }

    /**
     * Returns the size of the current playlist.
     *
     * @return The playlist size
     */
    private int playlistSize() {
        return mCurrentPlaylist != null
            ? mCurrentPlaylist.size() : 0;
    }

    /**
     * Returns whether the current playlist is empty.
     *
     * @return True when the playlist is empty
     */
    private boolean playlistEmpty() {
        return playlistSize() == 0;
    }

    /**
     * Returns the path of the song at the given index, or null when
     * the index is out of range.
     *
     * @param index Playlist index
     * @return The path, or null
     */
    @Nullable
    private String pathOf(int index) {
        if (mCurrentPlaylist == null) {
            return null;
        }
        if (index < 0 || index >= mCurrentPlaylist.size()) {
            return null;
        }
        Song song = mCurrentPlaylist.get(index);
        return song != null ? song.getPath() : null;
    }

    /**
     * Returns the playlist index of the song with the given path, or
     * -1 when it is not in the playlist.
     *
     * @param path Path to search for
     * @return The index, or -1
     */
    private int indexOfPath(@Nullable String path) {
        if (path == null || mCurrentPlaylist == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Acquires the partial wake lock, ignoring any failure.
     */
    private void acquireWakeLock() {
        if (mWakeLock != null && !mWakeLock.isHeld()) {
            try {
                mWakeLock.acquire();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock acquire failed", exception);
            }
        }
    }

    /**
     * Releases the partial wake lock, ignoring any failure.
     */
    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Exception exception) {
                Log.w(TAG, "WakeLock release failed", exception);
            }
        }
    }

    /**
     * Estimates the current playback position from the cached base
     * and elapsed time.
     *
     * @return The estimated position in milliseconds
     */
    private int estimateCurrentPosition() {
        if (mState == ServiceState.PLAYING
                && mPlaybackBaseElapsed > 0L) {
            long elapsedDuration =
                SystemClock.elapsedRealtime() - mPlaybackBaseElapsed;
            long estimatedDuration =
                mPlaybackBasePosition + elapsedDuration;
            if (mCachedDuration > 0
                    && estimatedDuration > mCachedDuration) {
                return mCachedDuration;
            }
            return (int) estimatedDuration;
        }
        return mCachedPosition;
    }

    /**
     * Returns whether the current skip loop has exceeded its budget.
     *
     * @return True when the skip budget is exhausted
     */
    private boolean skipBudgetExhausted() {
        long currentTime = SystemClock.elapsedRealtime();
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = currentTime;
            return false;
        }
        return (currentTime - mSkipLoopStartedElapsed)
            >= SKIP_LOOP_BUDGET_MS;
    }

    /**
     * Abandons the current skip loop, transitions to IDLE, and
     * broadcasts the resulting state.
     */
    private void abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after "
            + (SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed)
            + " ms");
        mSkipLoopStartedElapsed = 0L;
        mPauseAfterPrepare = false;
        mForceReprepare = false;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentIndex = -1;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        savePlayingState();
        savePlayerState();
        broadcastUpdate();
    }

    // ============================================================================
    // Music Volume Receiver
    // ============================================================================

    /**
     * Registers the receiver for the music-volume-change broadcast.
     *
     * <p>Called from {@link #onBind(Intent)}. The receiver's lifetime
     * is tied to the session — the period during which a client has
     * the service bound — rather than to the service's own lifetime.
     * A service created without a bind never registers it, so a
     * hardware volume press on such a service is not treated as a
     * transport control.</p>
     *
     * <p>Idempotent. Returns immediately when a receiver is already
     * registered, so a repeat bind is safe.</p>
     *
     * <p>Registered with {@code RECEIVER_EXPORTED} because the
     * sender is the system process. The receiver filters by the
     * stream-type extra so only changes to the music stream are
     * acted on. On releases where the changed stream is aliased,
     * the primary stream-type extra may be absent; the alias extra
     * is checked as a fallback.</p>
     */
    private void registerMusicVolumeReceiver() {
        if (mMusicVolumeReceiver != null) {
            return;
        }
        mMusicVolumeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !VOLUME_CHANGED_ACTION.equals(
                            intent.getAction())) {
                    return;
                }
                int streamType = intent.getIntExtra(
                    EXTRA_VOLUME_STREAM_TYPE, -1);
                if (streamType == -1) {
                    streamType = intent.getIntExtra(
                        EXTRA_VOLUME_STREAM_TYPE_ALIAS, -1);
                }
                if (streamType != AudioManager.STREAM_MUSIC) {
                    return;
                }
                final int newVolume = intent.getIntExtra(
                    EXTRA_VOLUME_STREAM_VALUE, -1);
                if (newVolume < 0) {
                    return;
                }
                onMusicVolumeChanged(newVolume);
            }
        };
        try {
            ContextCompat.registerReceiver(
                this, mMusicVolumeReceiver,
                new IntentFilter(VOLUME_CHANGED_ACTION),
                ContextCompat.RECEIVER_EXPORTED);
            Log.d(TAG, "Music volume receiver registered");
        } catch (Exception exception) {
            Log.w(TAG, "Failed to register music volume receiver",
                exception);
            mMusicVolumeReceiver = null;
        }
    }

    /**
     * Unregisters the music-volume receiver. Idempotent.
     *
     * <p>Called from {@link #onDestroy()}. The receiver's field is
     * cleared on both paths — success and failure — so the next
     * bind sees a null field and re-registers.</p>
     */
    private void unregisterMusicVolumeReceiver() {
        if (mMusicVolumeReceiver != null) {
            try {
                unregisterReceiver(mMusicVolumeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mMusicVolumeReceiver = null;
        }
    }

    /**
     * Reacts to a change in the music stream volume.
     *
     * <p>The two rules are symmetric: zero is silence, non-zero is
     * play. A drop to zero pauses; a raise to non-zero resumes, or —
     * when the song is loaded and waiting in READY — starts playback.
     * This holds regardless of what caused the pause.</p>
     *
     * <p>The current system volume is read at the handling moment
     * and clamped to {@code [0, getStreamMaxVolume(STREAM_MUSIC)]}.
     * The broadcast value is used only as a fallback when the read
     * fails.</p>
     *
     * <p>A drop to zero while playing clears the interruption
     * record and cancels any pending Bluetooth disconnect
     * confirmation, because the user is asking for silence. The
     * raise path routes through {@link #doResume()} or
     * {@link #togglePlayPause()}, both of which are user-initiated
     * and clear the record as their first action.</p>
     *
     * @param broadcastVolume The music stream volume carried by the
     *        broadcast, used only as a fallback when the read fails
     */
    /**
     * Returns whether the service currently holds audio focus.
     *
     * @return True when the app holds audio focus
     */
    public boolean hasAudioFocus() {
        return mHasAudioFocus;
    }

    private void onMusicVolumeChanged(int broadcastVolume) {
        int target = broadcastVolume;
        if (mAudioManager != null) {
            try {
                final int maxVolume = mAudioManager.getStreamMaxVolume(
                    AudioManager.STREAM_MUSIC);
                if (maxVolume > 0) {
                    final int currentVolume =
                        mAudioManager.getStreamVolume(
                            AudioManager.STREAM_MUSIC);
                    if (currentVolume >= 0) {
                        target = currentVolume;
                    }
                    target = Math.max(0,
                        Math.min(maxVolume, target));
                }
            } catch (Exception exception) {
                Log.w(TAG, "Failed to read current music volume",
                    exception);
                target = broadcastVolume;
            }
        }
        if (target < 0) {
            target = 0;
        }

        if (target == 0) {
            if (mState == ServiceState.PLAYING) {
                clearInterruption();
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        } else {
            if (!mHasAudioFocus) {
                Log.d(TAG,
                    "Volume raised but focus not held; not resuming");
                return;
            }
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = false;
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            }
        }
    }

    // ============================================================================
    // Apply Scope Receiver
    // ============================================================================

    /**
     * Registers the receiver for the "apply playback scope"
     * broadcast.
     *
     * <p>The receiver accepts a serialized {@link PlaybackScope}
     * under {@link #EXTRA_SCOPE_JSON}. The application runs on the
     * main thread so the rebuild and broadcast it triggers are
     * ordered with the rest of the state machine.</p>
     */
    private void registerApplyScopeReceiver() {
        mApplyScopeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_APPLY_PLAYBACK_SCOPE.equals(
                            intent.getAction())) {
                    return;
                }
                String serialized = intent.getStringExtra(EXTRA_SCOPE_JSON);
                if (serialized == null) {
                    return;
                }
                PlaybackScope scope =
                    PlaybackScope.deserialize(serialized);
                onMain(() -> applyPlaybackScopeInternal(scope));
            }
        };
        registerReceiverSafely(mApplyScopeReceiver,
            new IntentFilter(ACTION_APPLY_PLAYBACK_SCOPE));
    }

    // ============================================================================
    // Notification Album Art Prefetch
    // ============================================================================

    /**
     * Loads the notification art for the current display song, using
     * the LRU cache when available.
     *
     * <p>When the decode resolves, the callback re-reads the display
     * song and installs the resolved art only when the display
     * song's path is still the path the decode was launched for. If
     * the state machine is past PREPARING, the callback pokes the
     * {@link NotificationController}'s awareness poll so the real
     * bitmap replaces the placeholder on the same main-thread turn
     * as the resolve.</p>
     */
    private void prefetchNotificationArt() {
        final Song displaySong = getDisplaySong();
        if (displaySong == null) {
            return;
        }
        final String path = displaySong.getPath();
        if (path == null) {
            return;
        }

        if (mArtCache.get(path) != null) {
            mResolvedArtPath = path;
            mResolvedArt = mArtCache.get(path);
            return;
        }

        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }

        mCurrentArtLoad = mArtLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap art = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    byte[] bytes = retriever.getEmbeddedPicture();
                    if (bytes != null
                            && !Thread.currentThread().isInterrupted()) {
                        art = decodeNotificationArt(bytes);
                    }
                } catch (Exception exception) {
                    Log.e(TAG,
                        "Notification art prefetch failed for " + path,
                        exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception ignored) {
                            // The retriever is not in a state that
                            // permits release.
                        }
                    }
                }

                if (art != null
                        && !Thread.currentThread().isInterrupted()) {
                    mArtCache.put(path, art);
                }

                final Bitmap finalArt = art;
                onMain(() -> {
                    final Song currentDisplaySong = getDisplaySong();
                    if (currentDisplaySong == null
                            || !path.equals(
                                currentDisplaySong.getPath())) {
                        return;
                    }
                    mResolvedArtPath = path;
                    mResolvedArt = finalArt;

                    if (mNotificationController != null
                            && mState != ServiceState.PREPARING) {
                        mNotificationController.pokeAwareness();
                    }
                });
            }
        });
    }

    /**
     * Decodes the given image bytes into a notification-sized
     * bitmap.
     *
     * @param data Image bytes to decode
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeNotificationArt(@NonNull byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);

        int sampleSize = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) {
            sampleSize *= 2;
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sampleSize;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, decode);
    }

    // ============================================================================
    // Shuffle Peek Memos and Window Cache
    // ============================================================================

    /**
     * Invalidates the shuffle peek memos and the cached window.
     *
     * <p>Called whenever a change makes the memoised results or the
     * cached window stale: a playlist replacement, a sort reorder, a
     * shuffle toggle, a repeat-mode change, a transition to idle, or
     * the consumption of a peek by a commit.</p>
     */
    private void clearShufflePeek() {
        mShuffleNextPeekValid = false;
        mShuffleNextPeekFromIndex = -1;
        mShuffleNextPeekResult = -1;
        mShufflePrevPeekValid = false;
        mShufflePrevPeekFromIndex = -1;
        mShufflePrevPeekResult = -1;
        mCachedWindow = null;
    }

    // ============================================================================
    // Pure Functions
    // ============================================================================

    /**
     * Returns the positional or shuffle-chosen next index, without
     * committing.
     *
     * @param fromIndex Index to peek from
     * @return The next index, or -1 when the playlist is empty
     */
    private int peekNextIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize == 0) {
            return -1;
        }
        if (mIsShuffle) {
            return peekShuffleNextIndex(fromIndex);
        }
        return (fromIndex + 1) % playlistSize;
    }

    /**
     * Returns the positional or shuffle-chosen previous index,
     * without committing.
     *
     * @param fromIndex Index to peek from
     * @return The previous index, or -1 when the playlist is empty
     */
    private int peekPreviousIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize == 0) {
            return -1;
        }
        if (mIsShuffle) {
            return peekShufflePreviousIndex(fromIndex);
        }
        return (fromIndex - 1 + playlistSize) % playlistSize;
    }

    /**
     * Returns the shuffle-chosen next index, memoising the result so
     * a subsequent commit returns the same index.
     *
     * @param fromIndex Index to peek from
     * @return The shuffle-chosen next index
     */
    private int peekShuffleNextIndex(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        if (mShuffleNextPeekValid
                && mShuffleNextPeekFromIndex == fromIndex) {
            return mShuffleNextPeekResult;
        }
        if (mRandom == null) {
            mRandom = new Random();
        }
        int candidateIndex;
        int guardCount = 0;
        do {
            candidateIndex = mRandom.nextInt(playlistSize);
            guardCount++;
        } while (candidateIndex == fromIndex && guardCount < 8);

        mShuffleNextPeekValid = true;
        mShuffleNextPeekFromIndex = fromIndex;
        mShuffleNextPeekResult = candidateIndex;
        return candidateIndex;
    }

    /**
     * Returns the shuffle-chosen previous index, memoising the result
     * so a subsequent commit returns the same index.
     *
     * @param fromIndex Index to peek from
     * @return The shuffle-chosen previous index
     */
    private int peekShufflePreviousIndex(int fromIndex) {
        if (mShufflePrevPeekValid
                && mShufflePrevPeekFromIndex == fromIndex) {
            return mShufflePrevPeekResult;
        }
        int previousIndex;
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            int candidateIndex =
                mShuffleHistory.get(mShuffleHistory.size() - 2);
            if (candidateIndex >= 0
                    && candidateIndex < playlistSize()) {
                previousIndex = candidateIndex;
            } else {
                previousIndex = freshShufflePick(fromIndex);
            }
        } else {
            previousIndex = freshShufflePick(fromIndex);
        }
        mShufflePrevPeekValid = true;
        mShufflePrevPeekFromIndex = fromIndex;
        mShufflePrevPeekResult = previousIndex;
        return previousIndex;
    }

    /**
     * Returns a fresh shuffle pick that differs from the given index.
     *
     * @param fromIndex Index to avoid
     * @return The pick
     */
    private int freshShufflePick(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        if (mRandom == null) {
            mRandom = new Random();
        }
        int candidateIndex;
        int guardCount = 0;
        do {
            candidateIndex = mRandom.nextInt(playlistSize);
            guardCount++;
        } while (candidateIndex == fromIndex && guardCount < 8);
        return candidateIndex;
    }

    /**
     * Returns the index that follows the given index under the
     * current shuffle and repeat mode, and commits the choice.
     *
     * @param fromIndex Starting index
     * @return The next index, or -1 when the playlist is empty
     */
    private int computeNext(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return pickShuffleNext(fromIndex);
        }
        return (fromIndex + 1) % playlistSize();
    }

    /**
     * Returns the index that precedes the given index under the
     * current shuffle and repeat mode, and commits the choice.
     *
     * @param fromIndex Starting index
     * @return The previous index, or -1 when the playlist is empty
     */
    private int computePrevious(int fromIndex) {
        if (playlistEmpty()) {
            return -1;
        }
        if (mIsShuffle) {
            return popShuffleHistory(fromIndex);
        }
        return (fromIndex - 1 + playlistSize()) % playlistSize();
    }

    /**
     * Picks the next index under shuffle, pushes it onto the shuffle
     * history, and returns it.
     *
     * @param fromIndex Starting index
     * @return The shuffled next index
     */
    private int pickShuffleNext(int fromIndex) {
        int playlistSize = playlistSize();
        if (playlistSize <= 1) {
            return fromIndex;
        }
        int nextIndex = peekShuffleNextIndex(fromIndex);

        if (mShuffleHistory == null) {
            mShuffleHistory = new ArrayList<Integer>();
        }
        if (mShuffleHistory.size() >= playlistSize * 2) {
            mShuffleHistory.clear();
        }
        mShuffleHistory.add(nextIndex);
        clearShufflePeek();
        return nextIndex;
    }

    /**
     * Picks a random song from the scoped playlist, different from
     * the current song when the scope holds more than one song.
     *
     * @param fromIndex The current song's index in the current
     *        playlist
     * @return The playlist index of the picked song, or -1 when the
     *         pick cannot be resolved
     */
    private int pickShuffleNextInScope(int fromIndex) {
        if (mScopedPlaylist == null || mScopedPlaylist.isEmpty()) {
            return -1;
        }

        if (mScopedPlaylist.size() == 1) {
            Song onlySong = mScopedPlaylist.get(0);
            return (onlySong != null)
                ? indexOfPath(onlySong.getPath()) : -1;
        }

        final String currentPath = pathOf(fromIndex);
        int currentScopedIndex = -1;
        if (currentPath != null) {
            for (int i = 0; i < mScopedPlaylist.size(); i++) {
                Song scopedSong = mScopedPlaylist.get(i);
                if (scopedSong != null
                        && currentPath.equals(scopedSong.getPath())) {
                    currentScopedIndex = i;
                    break;
                }
            }
        }

        if (mRandom == null) {
            mRandom = new Random();
        }

        int candidateScopedIndex;
        int guardCount = 0;
        do {
            candidateScopedIndex = mRandom.nextInt(
                mScopedPlaylist.size());
            guardCount++;
        } while (candidateScopedIndex == currentScopedIndex
                && guardCount < 8);

        Song picked = mScopedPlaylist.get(candidateScopedIndex);
        if (picked == null) {
            return -1;
        }

        int pickedIndex = indexOfPath(picked.getPath());

        if (mShuffleHistory == null) {
            mShuffleHistory = new ArrayList<Integer>();
        }
        if (mShuffleHistory.size() >= mScopedPlaylist.size() * 2) {
            mShuffleHistory.clear();
        }
        if (pickedIndex >= 0) {
            mShuffleHistory.add(pickedIndex);
        }
        clearShufflePeek();
        return pickedIndex;
    }

    /**
     * Pops the previous index off the shuffle history, or picks a new
     * one when the history is empty.
     *
     * @param fromIndex Starting index
     * @return The previous index under shuffle
     */
    private int popShuffleHistory(int fromIndex) {
        int previousIndex = peekShufflePreviousIndex(fromIndex);
        if (mShuffleHistory != null && mShuffleHistory.size() >= 2) {
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
        }
        clearShufflePeek();
        return previousIndex;
    }

    // ============================================================================
    // Display Song and Window Snapshot
    // ============================================================================

    /**
     * Returns the display song for the current state of the state
     * machine.
     *
     * <p>During PREPARING the display song is the target; every other
     * state uses the current index. This is the rule the carousel and
     * the {@code UPDATE_PLAYER} broadcast read. The notification's
     * {@code snapshotForNotification} does not use this method
     * during PREPARING; it uses {@link #getCurrentSong()} so the
     * notification matches the player screen.</p>
     *
     * @return The display song, or null when no song is bound
     */
    @Nullable
    private Song getDisplaySong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return null;
        }
        if (mState == ServiceState.PREPARING) {
            if (mTargetIndex < 0
                    || mTargetIndex >= mCurrentPlaylist.size()) {
                return null;
            }
            Song targetSong = mCurrentPlaylist.get(mTargetIndex);
            if (targetSong == null
                    || TextUtils.isEmpty(targetSong.getPath())) {
                return null;
            }
            return targetSong;
        }
        if (mCurrentIndex >= 0
                && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong == null
                    || TextUtils.isEmpty(currentSong.getPath())) {
                return null;
            }
            return currentSong;
        }
        return null;
    }

    /**
     * Returns the window the carousel should render.
     *
     * <p>The window names the previous neighbour, the display song,
     * and the next neighbour. Neighbours are always positional or
     * shuffle-chosen; they are not nulled out for a repeat mode.</p>
     *
     * <p>The window is memoised for the current state. The two peek
     * functions are not idempotent on their own, so the cache keyed
     * on the generation and the display path holds the window the
     * last call produced, and every consumer in the same state sees
     * the same three paths.</p>
     *
     * @return The window, or {@link PlaybackWindow#EMPTY} when idle
     */
    @NonNull
    public PlaybackWindow getWindowSnapshot() {
        Song displaySong = getDisplaySong();
        if (displaySong == null) {
            mCachedWindow = null;
            return PlaybackWindow.EMPTY;
        }
        int displayIndex = indexOfPath(displaySong.getPath());
        if (displayIndex < 0) {
            mCachedWindow = null;
            return PlaybackWindow.EMPTY;
        }

        PlaybackWindow cached = mCachedWindow;
        if (cached != null
                && cached.generation == mGeneration
                && displaySong.getPath().equals(cached.currentPath)) {
            return cached;
        }

        int previousIndex = peekPreviousIndex(displayIndex);
        int nextIndex = peekNextIndex(displayIndex);

        String previousPath = (previousIndex >= 0)
            ? pathOf(previousIndex) : null;
        String nextPath = (nextIndex >= 0)
            ? pathOf(nextIndex) : null;

        PlaybackWindow window = new PlaybackWindow(
            previousPath, displaySong.getPath(), nextPath, mGeneration);
        mCachedWindow = window;
        return window;
    }

    // ============================================================================
    // Core: Reconcile and Transition
    // ============================================================================

    /**
     * Notes the direction and restart for the next transition to
     * begin.
     *
     * @param direction +1 for a forward transition, -1 for a backward
     *        one, 0 for a transition with no spatial direction
     * @param restart True when the transition restarts the current
     *        song
     */
    private void noteTransition(int direction, boolean restart) {
        mNotedDirection = direction;
        mNotedRestart = restart;
    }

    /**
     * Clears any note that no transition will consume.
     */
    private void clearNotedTransition() {
        mNotedDirection = 0;
        mNotedRestart = false;
    }

    /**
     * Begins a transition when one is warranted by the current
     * target and state.
     *
     * <p>A request that arrives while a transition is in flight does
     * not act immediately — the state is
     * {@link ServiceState#PREPARING} and the player is already
     * preparing a track. The target is still updated, and the flag
     * {@link #mDeferredReconcile} is set so the prepare callbacks
     * re-enter reconciliation with the newest target when the
     * current prepare completes.</p>
     *
     * <p>When no transition is warranted — the target equals the
     * current song and no reprepare is forced, or the target is out
     * of range — the noted direction and restart are cleared.</p>
     */
    private void reconcile() {
        if (mState == ServiceState.STOPPING) {
            clearNotedTransition();
            return;
        }
        if (mState == ServiceState.PREPARING) {
            mDeferredReconcile = true;
            return;
        }

        if (mPendingSongPath != null) {
            final int pendingIndex = indexOfPath(mPendingSongPath);
            if (pendingIndex >= 0) {
                mTargetIndex = pendingIndex;
                if (pendingIndex == mCurrentIndex
                        && !mForceReprepare) {
                    mPendingSongPath = null;
                }
            }
        }

        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) {
            clearNotedTransition();
            return;
        }

        boolean need = (mTargetIndex != mCurrentIndex)
            || mForceReprepare;
        if (!need) {
            mDeferredReconcile = false;
            clearNotedTransition();
            return;
        }

        mForceReprepare = false;
        mDeferredReconcile = false;
        beginTransition(mTargetIndex, mPendingSeekPosition);
    }

    /**
     * Starts a new transition toward the given index, captures a
     * fresh generation along with the noted direction and restart,
     * and dispatches {@code prepareAsync} on the player thread.
     *
     * <p>Every new MediaPlayer is created here. Its output volume is
     * applied from the current duck state through
     * {@link #applyDuckVolume(MediaPlayer)} before the player is
     * prepared, so a track change that happens while audio focus is
     * ducked does not momentarily play the new track at full
     * volume.</p>
     *
     * @param index Target playlist index
     * @param seekPosition Position to seek to after prepare
     */
    private void beginTransition(int index, int seekPosition) {
        if (mState == ServiceState.STOPPING) {
            return;
        }
        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (index < 0 || index >= playlistSize()) {
            return;
        }

        if (mPendingSongPath != null
                && mPendingSongPath.equals(pathOf(index))) {
            mPendingSongPath = null;
        }

        final long generation = ++mGeneration;
        mGenerationDirection = mNotedDirection;
        mGenerationRestart = mNotedRestart;
        mNotedDirection = 0;
        mNotedRestart = false;

        mState = ServiceState.PREPARING;
        mTargetIndex = index;
        mPendingSeekPosition = seekPosition;
        mAutoStartOnPrepared = true;

        final Song song = mCurrentPlaylist.get(index);
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            mState = ServiceState.IDLE;
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(index);
            noteTransition(+1, false);
            mMainHandler.post(this::reconcile);
            return;
        }

        prefetchNotificationArt();

        final String path = song.getPath();
        final int committedIndex = index;
        final long capturedGeneration = generation;

        onPlayer(() -> {
            releaseMediaPlayer();
            final MediaPlayer player = getOrCreatePlayerRaw();
            removeAllListeners(player);
            applyDuckVolume(player);

            try {
                player.reset();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "player.reset() failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
                return;
            }

            try {
                player.setDataSource(path);
            } catch (IOException | IllegalStateException exception) {
                Log.e(TAG, "setDataSource failed: " + path,
                    exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
                return;
            }

            player.setOnPreparedListener(mediaPlayer -> {
                final int duration;
                final int audioSessionId;
                try {
                    duration = mediaPlayer.getDuration();
                    audioSessionId = mediaPlayer.getAudioSessionId();
                } catch (Exception exception) {
                    mMainHandler.post(() ->
                        onPrepareFailed(
                            capturedGeneration, committedIndex));
                    return;
                }
                mMainHandler.post(() -> onPrepared(
                    capturedGeneration, duration, audioSessionId, song,
                    committedIndex));
            });

            player.setOnCompletionListener(mediaPlayer ->
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onCompletion();
                }));

            player.setOnErrorListener((mediaPlayer, what, extra) -> {
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    onPlayerError(what, extra);
                });
                return true;
            });

            try {
                player.prepareAsync();
            } catch (IllegalStateException exception) {
                Log.e(TAG, "prepareAsync failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() -> {
                    if (capturedGeneration != mGeneration) {
                        return;
                    }
                    mState = ServiceState.IDLE;
                    if (skipBudgetExhausted()) {
                        abandonSkipLoop();
                        return;
                    }
                    mTargetIndex = computeNext(committedIndex);
                    noteTransition(+1, false);
                    mMainHandler.post(this::reconcile);
                });
            }
        });
    }

    /**
     * Tears the state machine down to IDLE and clears every field
     * that describes "what was playing".
     *
     * <p>Idempotent. Captures a fresh generation so any in-flight
     * prepare callback is discarded. Clears the playlist, the
     * shuffle history, the cached window, the resolved notification
     * art, the transport debounce map, the noted transition values,
     * the interruption record, and the static audio session
     * identifier.</p>
     */
    private void transitionToIdle() {
        if (mState == ServiceState.STOPPING) {
            return;
        }

        if (mState == ServiceState.IDLE
                && mCurrentPlaylist == null
                && mCurrentIndex == -1
                && mTargetIndex == -1) {
            return;
        }

        clearInterruption();

        mState = ServiceState.STOPPING;
        mGeneration++;
        mGenerationDirection = 0;
        mGenerationRestart = false;
        clearNotedTransition();
        mCachedWindow = null;
        mTargetIndex = -1;
        mPendingSeekPosition = 0;
        mPauseAfterPrepare = false;
        mForceReprepare = false;
        mDeferredReconcile = false;
        mSkipLoopStartedElapsed = 0L;
        mCurrentIndex = -1;
        mPendingSongPath = null;

        mPositionSaveTickCounter = 0;

        mCachedPosition = 0;
        mCachedDuration = 0;
        mCachedAudioSessionId = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;
        mPositionEpoch++;

        mResolvedArtPath = null;
        mResolvedArt = null;
        if (mCurrentArtLoad != null) {
            mCurrentArtLoad.cancel(true);
            mCurrentArtLoad = null;
        }
        if (mArtCache != null) {
            mArtCache.evictAll();
        }

        mLastNotificationActionTime.clear();

        stopHealthMonitoring();

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        mCurrentPlaylist = null;
        if (mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        clearShufflePeek();

        EqualizerManager.getInstance(this).release();

        sCurrentAudioSessionId = 0;

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();

        if (mNotificationController != null) {
            mNotificationController.clearPlaybackNotification();
        }

        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(false);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to deactivate MediaSession",
                    exception);
            }
        }

        mState = ServiceState.IDLE;
        broadcastUpdate();
    }

    // ============================================================================
    // MediaPlayer Callbacks
    // ============================================================================

    /**
     * Handles a successful {@code prepareAsync} callback on the main
     * thread.
     *
     * <p>When the transition is bound to {@code READY} — a
     * cold-start restore, a pause that arrived during PREPARING —
     * the method re-enters reconciliation after publishing the
     * READY state, because a different target may have arrived
     * while the track was preparing.</p>
     *
     * @param generation Generation of the transition
     * @param duration Duration of the prepared track in milliseconds
     * @param audioSessionId Audio session identifier of the prepared
     *        track
     * @param song The song that was prepared
     * @param committedIndex The index the track was bound to
     */
    private void onPrepared(long generation, int duration,
                            int audioSessionId, @NonNull Song song,
                            int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        if (duration <= 0) {
            onPrepareFailed(generation, committedIndex);
            return;
        }

        int seekPosition = mPendingSeekPosition;
        mPendingSeekPosition = 0;

        mSkipLoopStartedElapsed = 0L;
        mCachedDuration = duration;
        mCachedAudioSessionId = audioSessionId;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        sCurrentAudioSessionId = audioSessionId;
        broadcastAudioSessionChanged(audioSessionId);
        EqualizerManager.getInstance(this)
            .attachToAudioSession(audioSessionId);

        mCurrentIndex = committedIndex;

        rebuildPlaylists();

        if (mPauseAfterPrepare) {
            mPauseAfterPrepare = false;
            mAutoStartOnPrepared = false;
        }

        if (!mAutoStartOnPrepared) {
            if (seekPosition > 0 && seekPosition < duration - 500) {
                final int finalSeekPosition = seekPosition;
                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player != null) {
                        try {
                            player.seekTo(finalSeekPosition);
                        } catch (Exception ignored) {
                            // The player is not in a state that
                            // permits seeking.
                        }
                    }
                });
                mCachedPosition = seekPosition;
                mPlaybackBasePosition = seekPosition;
            }

            mState = ServiceState.READY;
            mRecoveryAttempts = 0;

            if (mMediaSession != null) {
                try {
                    mMediaSession.setActive(true);
                } catch (Exception ignored) {
                    // The session is not in a state that permits
                    // activation.
                }
            }

            saveCurrentPlayingIndex();
            broadcastUpdate();

            if (mDeferredReconcile
                    || mPendingSongPath != null
                    || mTargetIndex != mCurrentIndex
                    || mForceReprepare) {
                mMainHandler.post(this::reconcile);
            }
            return;
        }

        final int doSeek = (seekPosition > 0
            && seekPosition < duration - 500) ? seekPosition : 0;
        final long capturedGeneration = generation;
        final Song capturedSong = song;
        final int capturedIndex = committedIndex;
        final long capturedStartToken = ++mStartToken;

        // The transition is about to start the player. If the
        // music stream is at zero, raise it so the start is
        // audible. The raise runs on the main thread, before the
        // player's start is dispatched, so the first sample the
        // user hears is at the raised volume.
        raiseVolumeIfSilentForResume();

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                mMainHandler.post(() ->
                    onPrepareFailed(
                        capturedGeneration, capturedIndex));
                return;
            }
            if (doSeek > 0) {
                try {
                    player.seekTo(doSeek);
                } catch (Exception ignored) {
                    // The player is not in a state that permits
                    // seeking.
                }
            }
            try {
                player.start();
            } catch (Exception exception) {
                Log.e(TAG, "onPrepared: start() failed", exception);
                releaseMediaPlayer();
                mMainHandler.post(() ->
                    onPrepareFailed(
                        capturedGeneration, capturedIndex));
                return;
            }
            final long finalCapturedStartToken = capturedStartToken;
            mMainHandler.post(() -> {
                if (finalCapturedStartToken != mStartToken) {
                    return;
                }
                onPlaybackStarted(capturedGeneration, capturedIndex,
                    capturedSong, doSeek);
            });
        });
    }

    /**
     * Commits the transition to PLAYING and starts the notification,
     * the wake lock, audio focus, and the health monitor.
     *
     * @param generation Generation of the transition
     * @param committedIndex Index the track was bound to
     * @param song The song that started playing
     * @param seekPosition Position the track started at
     */
    private void onPlaybackStarted(long generation, int committedIndex,
                                   @NonNull Song song, int seekPosition) {
        if (generation != mGeneration) {
            return;
        }
        if (mState != ServiceState.PREPARING) {
            return;
        }

        mState = ServiceState.PLAYING;
        mPositionSaveTickCounter = 0;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBasePosition = seekPosition;
        mPlaybackBaseElapsed = mPlaybackStartElapsed;
        mCachedPosition = seekPosition;
        mRecoveryAttempts = 0;

        acquireWakeLock();
        requestAudioFocus();

        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits
                // activation.
            }
        }

        updatePlaybackParams();
        saveCurrentPlayingIndex();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();

        if (mDeferredReconcile
                || mPendingSongPath != null
                || mTargetIndex != mCurrentIndex
                || mForceReprepare) {
            mMainHandler.post(this::reconcile);
        }
    }

    /**
     * Handles a failed prepare by checking the skip budget and
     * advancing to the next track.
     *
     * <p>A request that arrived while the failed transition was in
     * flight is preserved. The failure-recovery heuristic — advance
     * to the positional successor — does not overwrite a target the
     * user asked for. When {@link #mDeferredReconcile} is set, the
     * target is left alone and reconciliation is re-entered.</p>
     *
     * @param generation Generation of the transition
     * @param committedIndex Index the track was bound to
     */
    private void onPrepareFailed(long generation, int committedIndex) {
        if (generation != mGeneration) {
            return;
        }
        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        onPlayer(this::releaseMediaPlayer);
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }
        if (mDeferredReconcile) {
            mMainHandler.post(this::reconcile);
            return;
        }
        mTargetIndex = computeNext(committedIndex);
        noteTransition(+1, false);
        mDeferredReconcile = true;
        mMainHandler.post(this::reconcile);
    }

    /**
     * Advances to the next track when the current track completes,
     * or pauses at the end of the queue under repeat off.
     *
     * <p>The destination is chosen from {@link #mScopedPlaylist} —
     * the set of songs the user actually asked to hear — rather
     * than from {@link #mCurrentPlaylist}. The current playlist may
     * carry a grace-period song appended to its end; that song is
     * not a song the user asked for, so its position must not
     * decide whether there is a next song.</p>
     */
    private void onCompletion() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }

        final int fromIndex = mCurrentIndex;
        final String currentPath = pathOf(fromIndex);

        final boolean scopeEmpty = (mScopedPlaylist == null
            || mScopedPlaylist.isEmpty());

        int currentScopedIndex = -1;
        if (!scopeEmpty && currentPath != null) {
            for (int i = 0; i < mScopedPlaylist.size(); i++) {
                Song scopedSong = mScopedPlaylist.get(i);
                if (scopedSong != null
                        && currentPath.equals(scopedSong.getPath())) {
                    currentScopedIndex = i;
                    break;
                }
            }
        }

        int nextIndex;

        if (mRepeatMode == 2) {
            nextIndex = fromIndex;
        } else if (mIsShuffle) {
            if (scopeEmpty) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
            nextIndex = pickShuffleNextInScope(fromIndex);
            if (nextIndex < 0) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
        } else if (mRepeatMode == 1) {
            if (scopeEmpty) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
            final int nextScopedIndex = (currentScopedIndex < 0)
                ? 0
                : (currentScopedIndex + 1) % mScopedPlaylist.size();
            Song nextScopedSong = mScopedPlaylist.get(nextScopedIndex);
            nextIndex = (nextScopedSong != null)
                ? indexOfPath(nextScopedSong.getPath()) : -1;
            if (nextIndex < 0) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
        } else {
            if (scopeEmpty) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
            final int nextScopedIndex;
            if (currentScopedIndex < 0) {
                nextScopedIndex = 0;
            } else if (currentScopedIndex + 1
                    < mScopedPlaylist.size()) {
                nextScopedIndex = currentScopedIndex + 1;
            } else {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
            Song nextScopedSong = mScopedPlaylist.get(nextScopedIndex);
            nextIndex = (nextScopedSong != null)
                ? indexOfPath(nextScopedSong.getPath()) : -1;
            if (nextIndex < 0) {
                pauseAtEndOfQueue(fromIndex);
                return;
            }
        }

        mTargetIndex = nextIndex;
        mPendingSeekPosition = 0;

        if (nextIndex == fromIndex) {
            mForceReprepare = true;
        }

        noteTransition(+1, nextIndex == fromIndex);
        mMainHandler.post(this::reconcile);
    }

    /**
     * Pauses the player at the end of the queue, keeping the current
     * song loaded and bound.
     *
     * @param fromIndex The current song's index
     */
    private void pauseAtEndOfQueue(int fromIndex) {
        mState = ServiceState.PAUSED;
        mTargetIndex = fromIndex;
        mPendingSeekPosition = 0;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                player.pause();
            } catch (Exception ignored) {
                // The player is not in a state that permits
                // pausing.
            }
            try {
                player.seekTo(0);
            } catch (Exception ignored) {
                // The player is not in a state that permits
                // seeking.
            }
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();
    }

    /**
     * Handles a MediaPlayer error by checking the skip budget and
     * advancing to the next track.
     *
     * @param what The error type
     * @param extra The extra error code
     */
    private void onPlayerError(int what, int extra) {
        Log.e(TAG, "MediaPlayer error: what=" + what
            + " extra=" + extra);

        mPauseAfterPrepare = false;
        mState = ServiceState.IDLE;
        mCachedPosition = 0;
        mPlaybackBasePosition = 0;
        mPlaybackBaseElapsed = 0L;

        onPlayer(this::releaseMediaPlayer);
        releaseWakeLock();

        if (playlistEmpty()) {
            transitionToIdle();
            return;
        }
        if (skipBudgetExhausted()) {
            abandonSkipLoop();
            return;
        }

        if (mTargetIndex >= 0) {
            mTargetIndex = computeNext(mTargetIndex);
        }
        noteTransition(+1, false);
        mDeferredReconcile = true;
        mMainHandler.post(this::reconcile);
    }

    /**
     * Reacts to a detected playback stall by either re-preparing
     * the current track from the persisted position or, after
     * {@link #MAX_RECOVERY_ATTEMPTS} attempts, advancing to the
     * next track.
     */
    private void onStall() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        mRecoveryAttempts++;

        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            if (playlistEmpty()) {
                transitionToIdle();
                return;
            }
            if (skipBudgetExhausted()) {
                abandonSkipLoop();
                return;
            }
            mTargetIndex = computeNext(mCurrentIndex);
            mPendingSeekPosition = 0;
            noteTransition(+1, false);
        } else {
            mTargetIndex = mCurrentIndex;
            mPendingSeekPosition = getSavedPosition();
            mForceReprepare = true;
            noteTransition(0, false);
        }

        reconcile();
    }

    // ============================================================================
    // Health Monitoring
    // ============================================================================

    /**
     * Installs the runnable used by
     * {@link #startHealthMonitoring()}.
     */
    private void installHealthCheckRunnable() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (mState == ServiceState.PLAYING) {
                    refreshPositionFromPlayer();
                }
                if (mState == ServiceState.PLAYING
                    || mState == ServiceState.PREPARING
                    || mState == ServiceState.PAUSED) {
                    if (mHealthHandler != null
                            && mHealthCheckRunnable != null) {
                        mHealthHandler.postDelayed(
                            this, HEALTH_CHECK_INTERVAL_MS);
                    }
                }
            }
        };
    }

    /**
     * Reads the current position from the player, detects stalls,
     * and checkpoints the persisted position on a fixed interval.
     */
    private void refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) {
            return;
        }

        final long epoch = mPositionEpoch;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }

            final int position;
            try {
                position = player.getCurrentPosition();
            } catch (Exception exception) {
                return;
            }

            mMainHandler.post(() -> {
                if (epoch != mPositionEpoch) {
                    return;
                }
                if (mState != ServiceState.PLAYING) {
                    return;
                }

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime();

                long elapsedDuration = SystemClock.elapsedRealtime()
                    - mPlaybackStartElapsed;
                if (position < 100
                        && elapsedDuration > MAX_STALL_TIME_MS) {
                    onStall();
                } else if (position >= 100) {
                    mPlaybackStartElapsed =
                        SystemClock.elapsedRealtime();
                }

                mPositionSaveTickCounter++;
                if (mPositionSaveTickCounter
                        >= POSITION_SAVE_INTERVAL_TICKS) {
                    mPositionSaveTickCounter = 0;
                    savePlayingState();
                }
            });
        });
    }

    /**
     * Starts the periodic health check.
     */
    private void startHealthMonitoring() {
        stopHealthMonitoring();
        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.postDelayed(
                mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        }
    }

    /**
     * Cancels any pending health check.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
        }
    }

    // ============================================================================
    // Public Request API
    // ============================================================================

    /**
     * Requests playback of the song at the given index.
     *
     * <p>An explicit selection, so no direction is noted; the
     * transition that begins carries direction 0 and the carousel
     * runs its reveal when the song changes.</p>
     *
     * <p>User-initiated: clears the interruption record and any
     * pending Bluetooth disconnect confirmation.</p>
     *
     * @param index Playlist index to play
     */
    public void playSong(int index) {
        onMain(() -> {
            clearInterruption();
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = 0;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given index, starting at
     * the given position.
     *
     * @param index Playlist index to play
     * @param position Start position in milliseconds
     */
    public void playSongAtPosition(int index, int position) {
        onMain(() -> {
            clearInterruption();
            if (index < 0 || index >= playlistSize()) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            mTargetIndex = index;
            mPendingSeekPosition = position;
            reconcile();
        });
    }

    /**
     * Requests playback of the song at the given path.
     *
     * @param filePath Path of the song to play
     */
    public void playSongByPath(@NonNull String filePath) {
        onMain(() -> {
            clearInterruption();
            int index = indexOfPath(filePath);
            if (index >= 0) {
                mSkipLoopStartedElapsed = 0L;
                mTargetIndex = index;
                mPendingSeekPosition = 0;
                reconcile();
            } else {
                mPendingSongPath = filePath;
                Log.d(TAG,
                    "playSongByPath: not in playlist, parked: "
                        + filePath);
            }
        });
    }

    /**
     * Records the given path as the newest incoming-file request and,
     * when the playlist already contains it, asks the state machine
     * to transition to it on the same turn.
     *
     * @param filePath Absolute path of the incoming file
     */
    public void requestIncomingFile(@NonNull String filePath) {
        onMain(() -> {
            clearInterruption();
            mPendingSongPath = filePath;
            reconcile();
        });
    }

    /**
     * Requests the next song.
     *
     * <p>The transport entry point. The direction is noted as
     * {@code +1} and the restart flag is set when the request
     * resolves to a restart. The generation that begins carries both
     * values, and the service's committing broadcast publishes them
     * alongside the window.</p>
     */
    public void playNextSong() {
        onMain(() -> {
            clearInterruption();
            if (playlistEmpty()
                    || mState == ServiceState.STOPPING) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = (mState == ServiceState.PREPARING
                    && mTargetIndex >= 0)
                ? mTargetIndex
                : mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }
            final boolean restart;
            if (mRepeatMode == 2) {
                mTargetIndex = baseIndex;
                mForceReprepare = true;
                restart = true;
            } else {
                mTargetIndex = computeNext(baseIndex);
                restart = (mTargetIndex == baseIndex);
                if (restart) {
                    mForceReprepare = true;
                }
            }
            mPendingSeekPosition = 0;
            noteTransition(+1, restart);
            reconcile();
        });
    }

    /**
     * Requests the previous song.
     *
     * <p>Symmetric to {@link #playNextSong()}. The direction is
     * noted as {@code -1}; the restart flag is set when the request
     * resolves to a restart.</p>
     */
    public void playPreviousSong() {
        onMain(() -> {
            clearInterruption();
            if (playlistEmpty()
                    || mState == ServiceState.STOPPING) {
                return;
            }
            mSkipLoopStartedElapsed = 0L;
            int baseIndex = (mState == ServiceState.PREPARING
                    && mTargetIndex >= 0)
                ? mTargetIndex
                : mCurrentIndex;
            if (baseIndex < 0) {
                baseIndex = 0;
            }
            final boolean restart;
            if (mRepeatMode == 2) {
                mTargetIndex = baseIndex;
                mForceReprepare = true;
                restart = true;
            } else {
                mTargetIndex = computePrevious(baseIndex);
                restart = (mTargetIndex == baseIndex);
                if (restart) {
                    mForceReprepare = true;
                }
            }
            mPendingSeekPosition = 0;
            noteTransition(-1, restart);
            reconcile();
        });
    }

    /**
     * Toggles between playing and paused according to the current
     * state.
     *
     * <p>A user-initiated pause clears the interruption record. The
     * user is asking for silence; the record's claim on playback is
     * gone.</p>
     */
    public void togglePlayPause() {
        onMain(() -> {
            clearInterruption();
            switch (mState) {
                case PLAYING:
                    doPause();
                    break;
                case PAUSED:
                    doResume();
                    break;
                case READY:
                    doResume();
                    break;
                case IDLE:
                    if (playlistEmpty()) {
                        broadcastUpdate();
                        return;
                    }
                    mSkipLoopStartedElapsed = 0L;
                    if (mTargetIndex < 0) {
                        mTargetIndex = 0;
                    }
                    reconcile();
                    break;
                case PREPARING: {
                    final boolean currentlyHeadsToPlay =
                        mAutoStartOnPrepared && !mPauseAfterPrepare;
                    if (currentlyHeadsToPlay) {
                        mPauseAfterPrepare = true;
                    } else {
                        mPauseAfterPrepare = false;
                        mAutoStartOnPrepared = true;
                    }
                    break;
                }
                case STOPPING:
                    break;
            }
        });
    }

    /**
     * Requests a pause. Clears the interruption record first: a
     * user-initiated pause supersedes any pending resume.
     */
    public void pause() {
        onMain(() -> {
            clearInterruption();
            if (mState == ServiceState.PLAYING) {
                doPause();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true;
            }
        });
    }

    /**
     * Requests a resume.
     */
    public void resume() {
        onMain(() -> {
            clearInterruption();
            if (mState == ServiceState.PAUSED) {
                doResume();
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            } else if (mState == ServiceState.IDLE) {
                mSkipLoopStartedElapsed = 0L;
                if (mTargetIndex < 0 && !playlistEmpty()) {
                    mTargetIndex = 0;
                }
                reconcile();
            } else if (mState == ServiceState.PREPARING) {
                if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                    mPauseAfterPrepare = false;
                    mAutoStartOnPrepared = true;
                }
            }
        });
    }

    /**
     * Releases the player but remembers the current index so a
     * subsequent play re-prepares the same track from position
     * zero.
     */
    public void stop() {
        onMain(() -> {
            clearInterruption();
            if (mState != ServiceState.PLAYING
                    && mState != ServiceState.PAUSED) {
                return;
            }

            int stoppedAtIndex = mCurrentIndex;

            onPlayer(this::releaseMediaPlayer);
            releaseWakeLock();

            mCurrentIndex = -1;
            mTargetIndex = stoppedAtIndex;
            mPendingSeekPosition = 0;
            mPauseAfterPrepare = false;
            mForceReprepare = false;
            mDeferredReconcile = false;
            mSkipLoopStartedElapsed = 0L;
            clearNotedTransition();
            mCachedWindow = null;
            mState = ServiceState.IDLE;

            mPositionSaveTickCounter = 0;

            mCachedPosition = 0;
            mCachedDuration = 0;
            mPlaybackBasePosition = 0;
            mPlaybackBaseElapsed = 0L;

            savePlayingState();
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Tears down to IDLE and clears the playlist.
     */
    public void stopCompletely() {
        onMain(() -> {
            clearInterruption();
            transitionToIdle();
        });
    }

    /**
     * Pauses the player, updates the cached position, saves state,
     * broadcasts the change, and demotes the notification from the
     * foreground.
     *
     * <p>Bumps {@link #mStartToken} at entry. A resume whose
     * {@code player.start()} is still on the player thread captures
     * {@code mStartToken} when it begins; the pause's bump makes
     * the resume's continuation skip its rollback, so the pause's
     * committed {@code PAUSED} state is not clobbered by a start
     * that began before it.</p>
     */
    private void doPause() {
        mStartToken++;

        mPositionSaveTickCounter = 0;

        final int position = estimateCurrentPosition();

        mState = ServiceState.PAUSED;
        mCachedPosition = position;
        mPlaybackBasePosition = position;
        mPlaybackBaseElapsed = 0L;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                player.pause();
            } catch (Exception ignored) {
                // The player is not in a state that permits
                // pausing.
            }
        });

        releaseWakeLock();
        savePlayingState();
        savePlayerState();
        broadcastUpdate();

        if (mNotificationController != null) {
            mNotificationController.demoteFromForeground();
        }
    }

    /**
     * Requests a resume. Handles audio-focus acquisition and, when
     * focus is not immediately granted, leaves the interruption
     * record in place so a later gain or a volume raise can
     * complete the resume.
     *
     * <p>When this method is called from the audio-focus gain
     * callback, use {@link #resumeAfterInterruption()} instead — it
     * retries focus acquisition for a bounded window, which is what
     * guarantees the resume after a call on devices where the
     * telephony stack releases focus late.</p>
     */
    private void doResume() {
        if (!requestAudioFocus(true)) {
            Log.d(TAG, "doResume refused: audio focus not granted");
            return;
        }
        doResumeInternal();
    }

    /**
     * Performs the resume assuming audio focus is held.
     *
     * <p>State is committed synchronously, before
     * {@link MediaPlayer#start()} is dispatched to the player
     * thread. The async continuation exists only to roll the state
     * back if {@code start()} actually fails, and its rollback is
     * guarded by both {@link #mStartToken} and the state machine's
     * state.</p>
     *
     * <p>After the state is committed to {@code PLAYING}, the
     * method raises the music stream if it is at zero, so the
     * resume is audible rather than silent. The raise is placed
     * after {@link #onPlaybackResumed()} on purpose: the
     * {@code VOLUME_CHANGED_ACTION} broadcast that the write fires
     * reaches {@link #onMusicVolumeChanged(int)} with the state
     * already at {@code PLAYING}, where the volume rule's raise
     * branch falls through and does not re-enter the resume path.</p>
     */
    private void doResumeInternal() {
        updatePlaybackParams();

        final long capturedStartToken = ++mStartToken;

        onPlaybackResumed();

        raiseVolumeIfSilentForResume();

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            boolean started = false;
            if (player != null) {
                try {
                    player.start();
                    started = true;
                } catch (Exception exception) {
                    Log.e(TAG, "resume: start() failed", exception);
                }
            }
            if (started) {
                return;
            }
            mMainHandler.post(() -> {
                if (capturedStartToken != mStartToken) {
                    return;
                }
                if (mState != ServiceState.PLAYING) {
                    return;
                }
                mState = ServiceState.IDLE;
                onPlayer(this::releaseMediaPlayer);
                releaseWakeLock();
                savePlayerState();
                broadcastUpdate();
                reconcile();
            });
        });
    }

    /**
     * Commits the resume: sets PLAYING, acquires the wake lock,
     * reactivates the media session, saves state, and commits the
     * notification.
     */
    private void onPlaybackResumed() {
        mState = ServiceState.PLAYING;
        mPositionSaveTickCounter = 0;

        mPlaybackStartElapsed = SystemClock.elapsedRealtime();
        mPlaybackBaseElapsed = mPlaybackStartElapsed;

        acquireWakeLock();
        if (mMediaSession != null) {
            try {
                mMediaSession.setActive(true);
            } catch (Exception ignored) {
                // The session is not in a state that permits
                // activation.
            }
        }
        clearInterruption();
        savePlayingState();
        savePlayerState();
        startHealthMonitoring();
        broadcastUpdate();
    }

    /**
     * Requests a seek to the given position.
     *
     * @param position Target position in milliseconds
     */
    public void seekTo(int position) {
        onMain(() -> {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position;
                return;
            }
            if (mState == ServiceState.PLAYING
                || mState == ServiceState.PAUSED
                || mState == ServiceState.READY) {

                mPositionEpoch++;

                onPlayer(() -> {
                    final MediaPlayer player = mMediaPlayer;
                    if (player == null) {
                        return;
                    }
                    try {
                        player.seekTo(position);
                    } catch (Exception ignored) {
                        // The player is not in a state that
                        // permits seeking.
                    }
                });

                mCachedPosition = position;
                mPlaybackBasePosition = position;
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed =
                        SystemClock.elapsedRealtime();
                }

                mPositionSaveTickCounter = 0;

                savePlayerState();
                broadcastUpdate();
            }
        });
    }

    // ============================================================================
    // Playlist
    // ============================================================================

    /**
     * Replaces the full playlist, rebuilds the scoped and current
     * playlists, resolves an anchor, and re-enters reconciliation
     * when the anchor changed.
     *
     * <p>The full playlist is the immutable database reflection.
     * {@link #rebuildPlaylists()} derives the scoped playlist from
     * it and the current playlist from the scoped playlist plus the
     * songs at {@code mCurrentIndex} and {@code mTargetIndex} — the
     * grace period that keeps a currently-playing song and its
     * pending target alive in the queue even when they no longer
     * match the scope.</p>
     *
     * @param playlist New playlist to install
     * @param preserveCurrentSong True to preserve the current song
     *        when present in the new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist,
                            boolean preserveCurrentSong) {
        onMain(() -> {
            if (mState == ServiceState.STOPPING) {
                return;
            }

            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) {
                    broadcastUpdate();
                    return;
                }
                transitionToIdle();
                return;
            }

            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist,
                getComparatorForSortMode(mCurrentSortMode));

            if (mFullPlaylist != null
                    && mFullPlaylist.size() == sortedPlaylist.size()
                    && sameOrder(mFullPlaylist, sortedPlaylist)) {
                rebuildPlaylists();
                broadcastUpdate();
                return;
            }

            final String playingPath = pathOf(mCurrentIndex);
            final String targetPath = pathOf(mTargetIndex);
            final boolean hasPendingSong = (mPendingSongPath != null);

            String anchorPath = mPendingSongPath;
            if (anchorPath == null) {
                anchorPath = playingPath;
            }
            if (anchorPath == null) {
                anchorPath = getSavedSongPath();
            }

            Song anchorSong = null;
            if (anchorPath != null) {
                for (Song candidateSong : sortedPlaylist) {
                    if (candidateSong != null
                            && anchorPath.equals(candidateSong.getPath())) {
                        anchorSong = candidateSong;
                        break;
                    }
                }
            }

            mFullPlaylist = sortedPlaylist;
            rebuildPlaylists();

            int resolvedIndex = (anchorPath != null)
                ? indexOfPath(anchorPath) : -1;

            if (resolvedIndex < 0 && anchorSong != null
                    && anchorSong.getTitle() != null) {
                for (int index = 0; index < playlistSize(); index++) {
                    Song candidateSong = mCurrentPlaylist.get(index);
                    if (candidateSong != null
                        && anchorSong.getTitle().equals(
                            candidateSong.getTitle())) {
                        resolvedIndex = index;
                        break;
                    }
                }
            }

            if (hasPendingSong
                    && resolvedIndex < 0
                    && mState != ServiceState.PREPARING) {
                broadcastUpdate();
                return;
            }

            if (resolvedIndex < 0) {
                resolvedIndex = 0;
            }

            if (mState == ServiceState.PREPARING) {
                if (targetPath != null) {
                    final int newTargetIndex = indexOfPath(targetPath);
                    if (newTargetIndex >= 0) {
                        mTargetIndex = newTargetIndex;
                    }
                }
                reconcile();
                broadcastUpdate();
                return;
            }

            final String resolvedPath = pathOf(resolvedIndex);
            final boolean sameSong = (playingPath != null)
                                  && !hasPendingSong
                                  && playingPath.equals(resolvedPath)
                                  && (mState == ServiceState.PLAYING
                                      || mState == ServiceState.PAUSED
                                      || mState == ServiceState.READY);

            if (sameSong) {
                mCurrentIndex = resolvedIndex;
                mTargetIndex = resolvedIndex;
                broadcastUpdate();
                return;
            }

            final boolean coldStart = (mCurrentIndex == -1
                                    && mState == ServiceState.IDLE);
            if (coldStart) {
                if (anchorPath != null
                        && anchorPath.equals(getSavedSongPath())) {
                    final int savedPosition = getSavedPosition();
                    if (savedPosition > 0) {
                        mPendingSeekPosition = savedPosition;
                    }
                }
                if (!wasPlayingBeforeRestart() && !hasPendingSong) {
                    mPauseAfterPrepare = true;
                }
            }

            mTargetIndex = resolvedIndex;
            reconcile();
        });
    }

    /**
     * Replaces the current playlist without preserving the current
     * song.
     *
     * @param playlist New playlist to install
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    /**
     * Replaces the current playlist, preserving the current song
     * when it is present in the new playlist.
     *
     * @param newPlaylist New playlist to install
     */
    public void updatePlaylist(ArrayList<Song> newPlaylist) {
        setPlaylist(newPlaylist, true);
    }

    /**
     * Sets the favorite flag of every song in the given list whose
     * path matches.
     *
     * @param list List to update, or null
     * @param path Path to match
     * @param favorite Flag to apply
     */
    private void applyFavoriteInList(@Nullable ArrayList<Song> list,
                                     @NonNull String path,
                                     boolean favorite) {
        if (list == null) {
            return;
        }
        for (Song song : list) {
            if (song != null && path.equals(song.getPath())) {
                song.setFavorite(favorite);
            }
        }
    }

    /**
     * Toggles the favorite flag of the current song.
     *
     * <p>Convenience wrapper around
     * {@link #commitFavorites(Map)} for the transport heart and the
     * album-art double-tap.</p>
     */
    public void toggleFavorite() {
        onMain(() -> {
            Song current = getCurrentSong();
            if (current == null || current.getPath() == null) {
                return;
            }
            boolean newValue = !current.isFavorite();
            Map<String, Boolean> single =
                new java.util.HashMap<>(1);
            single.put(current.getPath(), newValue);
            commitFavorites(single);
        });
    }

    /**
     * Rebuilds {@link #mScopedPlaylist} from {@link #mFullPlaylist}
     * and the current {@link #mPlaybackScope}, and
     * {@link #mCurrentPlaylist} from {@link #mScopedPlaylist} plus
     * the songs at {@code mCurrentIndex} and {@code mTargetIndex}.
     *
     * <p>The grace period keeps the current and target songs in
     * {@link #mCurrentPlaylist} even when the active scope no longer
     * includes them. Without it, unfavoriting the playing song in
     * the Favorites scope would silence it on the next rebuild.</p>
     */
    private void rebuildPlaylists() {
        refreshLooseTrackPaths();

        mScopedPlaylist = new ArrayList<>();
        if (mFullPlaylist != null) {
            for (Song song : mFullPlaylist) {
                if (song != null
                        && mPlaybackScope.matches(song, mLooseTrackPaths)) {
                    mScopedPlaylist.add(song);
                }
            }
        }

        final String currentPath = pathOf(mCurrentIndex);
        final String targetPath = pathOf(mTargetIndex);

        ArrayList<Song> nextCurrent = new ArrayList<>(mScopedPlaylist);
        if (currentPath != null && !containsPath(nextCurrent, currentPath)) {
            Song currentSong = findSongInFull(currentPath);
            if (currentSong != null) {
                nextCurrent.add(currentSong);
            }
        }
        if (targetPath != null
                && !targetPath.equals(currentPath)
                && !containsPath(nextCurrent, targetPath)) {
            Song targetSong = findSongInFull(targetPath);
            if (targetSong != null) {
                nextCurrent.add(targetSong);
            }
        }
        mCurrentPlaylist = nextCurrent;

        if (currentPath != null) {
            int newCurrent = indexOfPath(currentPath);
            if (newCurrent >= 0) {
                mCurrentIndex = newCurrent;
            }
        }
        if (targetPath != null) {
            int newTarget = indexOfPath(targetPath);
            if (newTarget >= 0) {
                mTargetIndex = newTarget;
            }
        }

        mCachedWindow = null;
        clearShufflePeek();
        if (mShuffleHistory != null) {
            mShuffleHistory.clear();
        }

        Log.d(TAG, "rebuildPlaylists: full="
            + (mFullPlaylist != null ? mFullPlaylist.size() : 0)
            + ", scoped=" + mScopedPlaylist.size()
            + ", current=" + playlistSize()
            + ", kind=" + mPlaybackScope.kind);
    }

    /**
     * Returns a copy of the current playlist.
     *
     * @return A copy of the current playlist
     */
    @NonNull
    public synchronized ArrayList<Song> getCurrentPlaylist() {
        if (mCurrentPlaylist == null) {
            return new ArrayList<Song>();
        }
        return new ArrayList<Song>(mCurrentPlaylist);
    }

    /**
     * Returns whether two playlists contain the same song paths in
     * the same order.
     *
     * @param firstPlaylist First playlist
     * @param secondPlaylist Second playlist
     * @return True when the two are in the same order
     */
    private boolean sameOrder(@NonNull ArrayList<Song> firstPlaylist,
                              @NonNull ArrayList<Song> secondPlaylist) {
        if (firstPlaylist.size() != secondPlaylist.size()) {
            return false;
        }
        for (int index = 0; index < firstPlaylist.size(); index++) {
            Song firstSong = firstPlaylist.get(index);
            Song secondSong = secondPlaylist.get(index);
            String firstPath = (firstSong != null)
                ? firstSong.getPath() : null;
            String secondPath = (secondSong != null)
                ? secondSong.getPath() : null;
            if (firstPath == null ? secondPath != null
                    : !firstPath.equals(secondPath)) {
                return false;
            }
        }
        return true;
    }

    // ============================================================================
    // Pending Song Path
    // ============================================================================

    /**
     * Sets the song path queued for playback once it enters the
     * playlist.
     *
     * @param path Path to queue, or null to clear
     */
    public void setPendingSongPath(@Nullable String path) {
        onMain(() -> {
            if (path == null) {
                mPendingSongPath = null;
                Log.d(TAG, "Pending song path cleared");
                return;
            }
            requestIncomingFile(path);
        });
    }

    /**
     * Returns the song path currently queued for playback.
     *
     * @return The queued path, or null
     */
    public String getPendingSongPath() {
        return mPendingSongPath;
    }

    /**
     * Clears the queued song path.
     */
    public void clearPendingSongPath() {
        onMain(() -> {
            mPendingSongPath = null;
            Log.d(TAG, "Pending song path cleared");
        });
    }

    /**
     * Plays the queued song path when it is present in the current
     * playlist.
     */
    public void playPendingSongIfExists() {
        onMain(() -> {
            if (mPendingSongPath == null) {
                return;
            }
            reconcile();
        });
    }

    // ============================================================================
    // Getters and Setters
    // ============================================================================

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return The current position
     */
    public int getCurrentPosition() {
        return estimateCurrentPosition();
    }

    /**
     * Returns the duration of the currently prepared track in
     * milliseconds.
     *
     * @return The duration
     */
    public int getDuration() {
        return mCachedDuration;
    }

    /**
     * Returns whether playback is running, or is on a transition
     * that will settle in PLAYING.
     *
     * <p>During PREPARING the destination is determined by both
     * {@link #mAutoStartOnPrepared} and
     * {@link #mPauseAfterPrepare}: the first is the intent the
     * transition was started with, the second is a pause that
     * arrived while the transition was in flight.</p>
     *
     * @return True when playback is running or will be running
     */
    public boolean isPlaying() {
        switch (mState) {
            case PLAYING:
                return true;
            case PREPARING:
                return mAutoStartOnPrepared && !mPauseAfterPrepare;
            default:
                return false;
        }
    }

    /**
     * Returns whether a transition is pending or about to begin.
     *
     * <p>True when the state machine is in
     * {@link ServiceState#PREPARING}, when a deferred reconcile is
     * queued, when the target index no longer matches the current
     * index, or when a forced reprepare is pending. Read by
     * {@link NotificationController}'s cancel branch: a state of
     * IDLE with a transition pending is not a state in which the
     * playback notification should be cancelled.</p>
     *
     * @return True when a transition is pending or in flight
     */
    public boolean isTransitionPending() {
        if (mState == ServiceState.PREPARING) {
            return true;
        }
        if (mDeferredReconcile) {
            return true;
        }
        if (mForceReprepare) {
            return true;
        }
        return mTargetIndex >= 0 && mTargetIndex != mCurrentIndex;
    }

    /**
     * Returns whether the state machine holds a song that is loaded
     * but not currently playing.
     *
     * <p>This is the case a volume-key press starts playback from:
     * the song is bound, either paused at a position or prepared at
     * its start and waiting for the play button.</p>
     *
     * @return True when the state is PAUSED or READY
     */
    public boolean isPausedOrReady() {
        return mState == ServiceState.PAUSED
            || mState == ServiceState.READY;
    }

    /**
     * Returns the song bound to {@link #mCurrentIndex}.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return null;
        }
        if (mCurrentIndex < 0
                || mCurrentIndex >= mCurrentPlaylist.size()) {
            return null;
        }
        return mCurrentPlaylist.get(mCurrentIndex);
    }

    /**
     * Returns the index the MediaPlayer is bound to.
     *
     * @return The current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Sets the index the MediaPlayer is bound to and persists it.
     *
     * @param index New current index
     */
    public void setCurrentIndex(int index) {
        onMain(() -> {
            mCurrentIndex = index;
            saveCurrentPlayingIndex();
        });
    }

    /**
     * Returns the current repeat mode.
     *
     * @return The repeat mode
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }

    /**
     * Sets the repeat mode, persists it, and broadcasts the new
     * state.
     *
     * <p>The repeat mode changes what "next" and "previous" mean,
     * so any memoised shuffle peek and any cached window were
     * computed under the previous mode and no longer describe the
     * next commit.</p>
     *
     * @param mode New repeat mode
     */
    public void setRepeatMode(int mode) {
        onMain(() -> {
            mRepeatMode = mode;
            clearShufflePeek();
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Returns whether shuffle is enabled.
     *
     * @return True when shuffle is enabled
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }

    /**
     * Sets the shuffle flag, persists it, and broadcasts the new
     * state.
     *
     * @param shuffle New shuffle flag
     */
    public void setShuffle(boolean shuffle) {
        onMain(() -> {
            mIsShuffle = shuffle;
            clearShufflePeek();
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            savePlayerState();
            broadcastUpdate();
        });
    }

    /**
     * Records whether a Bluetooth headset is currently connected.
     *
     * @param connected True when connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    /**
     * Returns the active playback scope.
     *
     * @return The current scope; never null
     */
    @NonNull
    public PlaybackScope getPlaybackScope() {
        return mPlaybackScope;
    }

    /**
     * Returns a copy of the playlist filtered by the active
     * {@link #mPlaybackScope}.
     *
     * @return A copy of the scoped playlist; empty when none
     */
    @NonNull
    public ArrayList<Song> getScopedPlaylist() {
        if (mScopedPlaylist == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(mScopedPlaylist);
    }

    /**
     * Returns the number of songs in the scoped playlist.
     *
     * @return The scoped playlist size
     */
    public int getScopedPlaylistSize() {
        return mScopedPlaylist != null ? mScopedPlaylist.size() : 0;
    }

    /**
     * Applies a new playback scope.
     *
     * <p>The change is committed through
     * {@link #rebuildPlaylists()} and announced on the next
     * {@code UPDATE_PLAYER} broadcast. The currently playing song
     * and any pending target survive the rebuild through the grace
     * period.</p>
     *
     * @param scope New scope; a no-op when null or equal to the
     *        current one
     */
    public void setPlaybackScope(@Nullable PlaybackScope scope) {
        if (scope == null) {
            return;
        }
        onMain(() -> applyPlaybackScopeInternal(scope));
    }

    /**
     * Applies the given scope on the main thread: stores it,
     * persists it, rebuilds the playlists, and broadcasts.
     *
     * @param scope Scope to apply
     */
    private void applyPlaybackScopeInternal(@NonNull PlaybackScope scope) {
        if (scope.equals(mPlaybackScope)) {
            return;
        }
        mPlaybackScope = scope;
        savePlaybackScope();
        rebuildPlaylists();
        broadcastUpdate();
    }

    /**
     * Persists the active scope under {@link #KEY_PLAYBACK_SCOPE}.
     */
    private void savePlaybackScope() {
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(KEY_PLAYBACK_SCOPE, mPlaybackScope.serialize())
                .apply();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to persist playback scope", exception);
        }
    }

    /**
     * Reads the persisted scope into memory.
     */
    private void loadPlaybackScope() {
        String serialized = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_PLAYBACK_SCOPE, null);
        mPlaybackScope = PlaybackScope.deserialize(serialized);
    }

    /**
     * Commits a batch of favorite-flag changes atomically.
     *
     * @param changes Map of song path to desired favorite flag
     */
    public void commitFavorites(@Nullable Map<String, Boolean> changes) {
        if (changes == null || changes.isEmpty()) {
            return;
        }
        onMain(() -> {
            SongDatabase database = SongDatabase.getInstance(this);
            boolean anyChanged = false;
            for (Map.Entry<String, Boolean> entry : changes.entrySet()) {
                final String path = entry.getKey();
                final Boolean favorite = entry.getValue();
                if (path == null || favorite == null) {
                    continue;
                }
                applyFavoriteInList(mFullPlaylist, path, favorite);
                applyFavoriteInList(mScopedPlaylist, path, favorite);
                applyFavoriteInList(mCurrentPlaylist, path, favorite);
                try {
                    database.setFavorite(path, favorite);
                } catch (Exception exception) {
                    Log.e(TAG,
                        "Failed to persist favorite for " + path,
                        exception);
                }
                anyChanged = true;
            }
            if (!anyChanged) {
                return;
            }
            rebuildPlaylists();
            broadcastUpdate();
            sendBroadcast(new Intent(ACTION_FAVORITE_CHANGED));
        });
    }

    // ============================================================================
    // Sort Mode
    // ============================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        mCurrentSortMode = getSharedPreferences(
                PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    // ============================================================================
    // Persistence
    // ============================================================================

    /**
     * Writes the current playback state to SharedPreferences.
     */
    public void savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, isPlaying())
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Writes the full playback state to SharedPreferences.
     */
    private void saveFullState() {
        savePlayerState();
    }

    /**
     * Returns the persisted playback position.
     *
     * @return The persisted position
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0);
    }

    /**
     * Returns whether the persisted state indicates that playback
     * was active before the last restart.
     *
     * @return True when playback was active
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false);
    }

    /**
     * Returns the persisted last song path.
     *
     * @return The last song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Persists the current playing index and last song path.
     */
    private void saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply();
    }

    /**
     * Persists the last playing flag and current position.
     */
    private void savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LAST_PLAYING, isPlaying())
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }

    /**
     * Reads the persisted repeat mode and shuffle flag into memory.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = preferences.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = preferences.getBoolean(KEY_SHUFFLE, false);
    }

    // ============================================================================
    // MediaPlayer Plumbing (player-thread only)
    // ============================================================================

    /**
     * Detaches every listener from the given player.
     *
     * @param player Player to detach listeners from, or null
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) {
            return;
        }
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
            // The player is not in a state that permits listener
            // changes.
        }
    }

    /**
     * Stops, resets, and releases the MediaPlayer, then clears the
     * field.
     */
    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            removeAllListeners(mMediaPlayer);
            try {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
            } catch (Exception ignored) {
                // The player is not in a state that permits stopping.
            }
            try {
                mMediaPlayer.reset();
            } catch (Exception ignored) {
                // The player is not in a state that permits resetting.
            }
            try {
                mMediaPlayer.release();
            } catch (Exception ignored) {
                // The player is already released.
            }
            mMediaPlayer = null;
        }
    }

    /**
     * Returns the MediaPlayer instance, creating one when none
     * exists.
     *
     * @return The MediaPlayer
     */
    @NonNull
    private MediaPlayer getOrCreatePlayerRaw() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    // ============================================================================
    // Playback Params
    // ============================================================================

    /**
     * Applies the current tempo and pitch from
     * {@link EqualizerManager} to the MediaPlayer on the player
     * thread.
     */
    public void updatePlaybackParams() {
        EqualizerManager equalizerManager =
            EqualizerManager.getInstance(this);
        int speedLevel = equalizerManager.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = equalizerManager.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        final float finalTempo = tempo;
        final float finalSemitones = semitones;

        onPlayer(() -> {
            final MediaPlayer player = mMediaPlayer;
            if (player == null) {
                return;
            }
            try {
                float pitch =
                    (float) Math.pow(2.0, finalSemitones / 12.0);
                android.media.PlaybackParams playbackParams =
                    player.getPlaybackParams();
                playbackParams.setSpeed(finalTempo);
                playbackParams.setPitch(pitch);
                player.setPlaybackParams(playbackParams);
                Log.d(TAG, "PlaybackParams: tempo=" + finalTempo
                    + ", pitch=" + pitch);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to set playback params",
                    exception);
            }
        });
    }

    // ============================================================================
    // MediaSession
    // ============================================================================

    /**
     * Creates the media session, installs the callback, and sets
     * the flags.
     *
     * <p>Each callback is debounced at
     * {@link #NOTIFICATION_ACTION_DEBOUNCE_MS}, matching the player
     * screen's own debounce on its buttons. Each callback clears
     * the interruption record as its first action inside
     * {@code onMain}: a user action through the media session is a
     * deliberate transition that supersedes a pending
     * interruption.</p>
     */
    private void setupMediaSession() {
        try {
            ComponentName mediaButtonReceiver = new ComponentName(
                this,
                androidx.media.session.MediaButtonReceiver.class);
            mMediaSession = new MediaSessionCompat(
                this, "LlamaMusicService", mediaButtonReceiver, null);

            mMediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    if (isNotificationActionDebounced(
                            "ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        if (!mHasAudioFocus
                                && mState != ServiceState.IDLE
                                && mState != ServiceState.PREPARING) {
                            return;
                        }
                        clearInterruption();
                        if (mState == ServiceState.PAUSED) {
                            doResume();
                        } else if (mState == ServiceState.IDLE) {
                            resume();
                        } else if (mState == ServiceState.READY) {
                            togglePlayPause();
                        } else if (mState
                                == ServiceState.PREPARING) {
                            if (mPauseAfterPrepare
                                    || !mAutoStartOnPrepared) {
                                mPauseAfterPrepare = false;
                                mAutoStartOnPrepared = true;
                            }
                        }
                    });
                }

                @Override
                public void onPause() {
                    if (isNotificationActionDebounced(
                            "ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        clearInterruption();
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        } else if (mState
                                == ServiceState.PREPARING) {
                            mPauseAfterPrepare = true;
                        }
                    });
                }

                @Override
                public void onSkipToNext() {
                    if (isNotificationActionDebounced("ACTION_NEXT")) {
                        return;
                    }
                    playNextSong();
                }

                @Override
                public void onSkipToPrevious() {
                    if (isNotificationActionDebounced("ACTION_PREV")) {
                        return;
                    }
                    playPreviousSong();
                }

                @Override
                public void onStop() {
                    if (isNotificationActionDebounced(
                            "ACTION_PLAY_PAUSE")) {
                        return;
                    }
                    onMain(() -> {
                        clearInterruption();
                        if (mState == ServiceState.PLAYING) {
                            doPause();
                        }
                    });
                }

                @Override
                public void onPlayFromMediaId(String mediaId,
                                              Bundle extras) {
                    if (mediaId == null) {
                        return;
                    }
                    try {
                        playSong(Integer.parseInt(mediaId));
                    } catch (NumberFormatException ignored) {
                        // The media identifier is not a playlist
                        // index.
                    }
                }
            });

            mMediaSession.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception);
        }
    }

    /**
     * Returns the current media session token, or null when no
     * session exists.
     *
     * @return The session token, or null
     */
    @Nullable
    public MediaSessionCompat.Token getSessionToken() {
        return mMediaSession != null
            ? mMediaSession.getSessionToken() : null;
    }

    /**
     * Writes the current playback state to the media session.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession == null) {
            return;
        }
        try {
            long actions = PlaybackStateCompat.ACTION_PLAY
                         | PlaybackStateCompat.ACTION_PAUSE
                         | PlaybackStateCompat.ACTION_PLAY_PAUSE
                         | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                         | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                         | PlaybackStateCompat.ACTION_STOP;

            PlaybackStateCompat.Builder builder =
                new PlaybackStateCompat.Builder()
                    .setActions(actions)
                    .setState(mStateSource.sessionPlaybackState(),
                        getCurrentPosition(), 1.0f);
            mMediaSession.setPlaybackState(builder.build());
        } catch (Exception exception) {
            Log.e(TAG, "Failed to update MediaSession state",
                exception);
        }
    }

    // ============================================================================
    // Audio Focus
    // ============================================================================

    /**
     * Creates the audio focus listener and, on API 26 and later,
     * the audio focus requests.
     */
    private void setupAudioFocus() {
        mAudioFocusListener =
            focusChange -> handleAudioFocusChange(focusChange);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(
                        AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(
                AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
            mAudioFocusRequestTransient =
                new AudioFocusRequest.Builder(
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }

    /**
     * Requests audio focus using the API-appropriate mechanism.
     *
     * @param transientFocus True to request transient focus, false
     *        to request permanent focus
     * @return True when focus was granted, false otherwise
     */
    @SuppressWarnings("deprecation")
    private boolean requestAudioFocus(boolean transientFocus) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            final AudioFocusRequest request = transientFocus
                ? mAudioFocusRequestTransient : mAudioFocusRequest;
            if (request != null && mAudioManager != null) {
                return mAudioManager.requestAudioFocus(request)
                    == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        } else if (mAudioManager != null
                && mAudioFocusListener != null) {
            return mAudioManager.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC,
                transientFocus
                    ? AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                    : AudioManager.AUDIOFOCUS_GAIN)
                == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return false;
    }

    /**
     * Requests permanent audio focus using the API-appropriate
     * mechanism.
     *
     * @return True when focus was granted, false otherwise
     */
    private boolean requestAudioFocus() {
        return requestAudioFocus(false);
    }

    /**
     * Abandons audio focus using the API-appropriate mechanism.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(
                    mAudioFocusRequest);
            }
        } else if (mAudioManager != null
                && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    /**
     * Raises the music stream to an audible level when the current
     * volume is exactly zero and the caller is about to start
     * playback.
     *
     * <p>This helper is the single implementation of the
     * audible-resume rule. It is invoked at both and only both
     * sites in this file where {@code MediaPlayer.start()} is
     * dispatched: the auto-start branch of
     * {@link #onPrepared(long, int, int, Song, int)} and the start
     * continuation of {@link #doResumeInternal()}. A future third
     * start site must pair with this helper on the same
     * main-thread turn, or it becomes a resume path that can start
     * the player silently.</p>
     *
     * <p>Raises the stream to {@code Math.min(3, maxVolume)}. On
     * devices whose music stream range is one or two steps, the
     * write clamps to the device maximum. The user can raise or
     * lower from there with the edge drag or a hardware key. The
     * write fires {@code VOLUME_CHANGED_ACTION}, which reaches
     * {@link #onMusicVolumeChanged(int)} after the state machine
     * has already reached {@code PLAYING}; the volume rule's
     * raise branch therefore falls through and does not re-enter
     * the resume path.</p>
     *
     * <p>A resume requested while the state machine is idle, or
     * while the playlist is empty, is not a promise of sound and
     * does not raise the volume.</p>
     */
    private void raiseVolumeIfSilentForResume() {
        if (mAudioManager == null) {
            return;
        }
        try {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume <= 0) {
                return;
            }
            final int currentVolume = mAudioManager.getStreamVolume(
                AudioManager.STREAM_MUSIC);
            if (currentVolume != 0) {
                return;
            }
            final int targetVolume = Math.min(3, maxVolume);
            mAudioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC, targetVolume, 0);
            Log.d(TAG, "Raised music volume to "
                + targetVolume + "/" + maxVolume
                + " for resume");
        } catch (Exception exception) {
            Log.w(TAG,
                "Failed to raise volume for resume", exception);
        }
    }

    /**
     * Returns true when the current audio output is the Bluetooth
     * A2DP route.
     *
     * <p>The check answers "was the user listening through the
     * headset at the moment the disconnect was reported." A link
     * loss on a paired-but-inactive device is not about the user's
     * listening, and must not pause playback that was going to the
     * phone's speaker or a wired headset.</p>
     *
     * @return True when A2DP is the active output
     */
    private boolean isBluetoothChosenOutput() {
        if (mAudioManager == null) {
            return false;
        }
        //noinspection deprecation
        return mAudioManager.isBluetoothA2dpOn();
    }

    /**
     * Handles a Bluetooth-disconnect pause request.
     *
     * <p>Three gates, all required:</p>
     * <ol>
     *   <li>No interruption is already handling the pause.</li>
     *   <li>The Bluetooth device is the active output.</li>
     *   <li>The state is PLAYING.</li>
     * </ol>
     *
     * <p>When all three pass, the pause is confirmed after
     * {@link #BLUETOOTH_DISCONNECT_CONFIRM_MS} to distinguish a
     * disconnect from a link flap. If the active route is restored
     * within that window, the pause is suppressed. A
     * user-initiated transition during the window cancels the
     * confirmation through {@link #clearInterruption()}.</p>
     *
     * <p>The profile action and state carried by the broadcast are
     * logged on each gate the request passes through. Neither value
     * gates the pause.</p>
     *
     * @param intent The pause intent, carrying the disconnecting
     *        profile and state, or null
     */
    private void onBluetoothDisconnect(@Nullable Intent intent) {
        final String profileAction = intent != null
            ? intent.getStringExtra(EXTRA_PROFILE_ACTION) : null;
        final int profileState = intent != null
            ? intent.getIntExtra(EXTRA_PROFILE_STATE, -1) : -1;

        if (mInterruption != null) {
            Log.d(TAG,
                "Bluetooth disconnect ignored: interruption in progress"
                    + " profile=" + profileAction
                    + " state=" + profileState);
            return;
        }
        if (!isBluetoothChosenOutput()) {
            Log.d(TAG,
                "Bluetooth disconnect ignored: not the active output"
                    + " profile=" + profileAction
                    + " state=" + profileState);
            return;
        }
        if (mState != ServiceState.PLAYING) {
            Log.d(TAG,
                "Bluetooth disconnect ignored: state=" + mState
                    + " profile=" + profileAction
                    + " state=" + profileState);
            return;
        }

        cancelBluetoothPauseConfirmation();
        mBluetoothPauseConfirmRunnable = () -> {
            mBluetoothPauseConfirmRunnable = null;
            if (mState != ServiceState.PLAYING) {
                return;
            }
            if (isBluetoothChosenOutput()) {
                Log.d(TAG,
                    "Bluetooth disconnect suppressed: route restored");
                return;
            }
            Log.d(TAG,
                "Bluetooth disconnect confirmed: pausing"
                    + " profile=" + profileAction);
            pause();
        };
        mMainHandler.postDelayed(mBluetoothPauseConfirmRunnable,
            BLUETOOTH_DISCONNECT_CONFIRM_MS);
    }

    /**
     * Cancels a pending Bluetooth-disconnect pause confirmation.
     * Idempotent.
     */
    private void cancelBluetoothPauseConfirmation() {
        if (mBluetoothPauseConfirmRunnable != null) {
            mMainHandler.removeCallbacks(mBluetoothPauseConfirmRunnable);
            mBluetoothPauseConfirmRunnable = null;
        }
    }

    /**
     * Returns true when the service should resume after the
     * current interruption.
     *
     * <p>Three conditions, all required: the state was PLAYING when
     * the interruption began, the generation has not advanced since
     * the interruption began, and the state machine is in a state a
     * resume can act on.</p>
     *
     * @return True when a gain should resume playback
     */
    private boolean shouldResumeAfterInterruption() {
        Interruption interruption = mInterruption;
        if (interruption == null || !interruption.wasPlaying) {
            return false;
        }
        if (interruption.generationAtStart != mGeneration) {
            return false;
        }
        return mState == ServiceState.PAUSED
            || mState == ServiceState.PREPARING
            || mState == ServiceState.READY;
    }

    /**
     * Returns true when the playback notification should remain a
     * foreground notification through the current interruption.
     *
     * <p>Read by {@link #mStateSource}'s
     * {@code shouldRemainForeground()} projection and surfaced to
     * the controller. True while an interruption is in progress and
     * the service still holds a bound, resumable song. Idle,
     * stopping, and an empty playlist all return false.</p>
     *
     * @return True when the notification must stay foreground
     */
    private boolean shouldRemainForeground() {
        Interruption interruption = mInterruption;
        if (interruption == null || !interruption.wasPlaying) {
            return false;
        }
        if (interruption.generationAtStart != mGeneration) {
            return false;
        }
        if (mState == ServiceState.IDLE
                || mState == ServiceState.STOPPING) {
            return false;
        }
        return !playlistEmpty();
    }

    /**
     * Clears the interruption record, any pending resume retry,
     * and any pending Bluetooth-disconnect confirmation.
     *
     * <p>Called by every user-initiated transition. The record
     * names an interruption the user has not overridden; the
     * moment the user acts, that is no longer true. A pending
     * Bluetooth confirmation is cancelled for the same reason.</p>
     */
    private void clearInterruption() {
        mInterruption = null;
        mResumeRetryCount = 0;
        if (mResumeRetryRunnable != null) {
            mMainHandler.removeCallbacks(mResumeRetryRunnable);
            mResumeRetryRunnable = null;
        }
        cancelBluetoothPauseConfirmation();
    }

    /**
     * Attempts to resume after the current interruption, retrying
     * on a bounded cadence when audio focus is not immediately
     * available.
     *
     * <p>The telephony stack holds audio focus through its own
     * teardown window, which is unbounded from the app's side. A
     * single {@code requestAudioFocus} inside the gain callback
     * therefore fails on a meaningful fraction of devices and,
     * absent a retry, leaves the service paused forever with no
     * further gain to wake it. The retry budget of
     * {@link #RESUME_RETRY_ATTEMPTS} times
     * {@link #RESUME_RETRY_INTERVAL_MS} — six seconds — outlasts
     * any observed teardown and is short enough that music does not
     * start into a call the user has already hung up and moved on
     * from.</p>
     *
     * <p>When the budget is exhausted, the record is left in
     * place. The notification stays foreground, the shade entry
     * and lockscreen controls survive, and the play button resumes
     * playback through the ordinary
     * {@link #togglePlayPause} path.</p>
     */
    private void resumeAfterInterruption() {
        if (!shouldResumeAfterInterruption()) {
            clearInterruption();
            return;
        }

        if (requestAudioFocus(true)) {
            clearInterruption();
            if (mState == ServiceState.PAUSED) {
                doResumeInternal();
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = false;
                mAutoStartOnPrepared = true;
            } else if (mState == ServiceState.READY) {
                togglePlayPause();
            }
            return;
        }

        if (mResumeRetryCount < RESUME_RETRY_ATTEMPTS) {
            mResumeRetryCount++;
            if (mResumeRetryRunnable != null) {
                mMainHandler.removeCallbacks(mResumeRetryRunnable);
            }
            mResumeRetryRunnable = this::resumeAfterInterruption;
            mMainHandler.postDelayed(mResumeRetryRunnable,
                RESUME_RETRY_INTERVAL_MS);
            return;
        }

        Log.w(TAG,
            "resumeAfterInterruption: focus unavailable after "
                + RESUME_RETRY_ATTEMPTS
                + " attempts; leaving resumable");
        mResumeRetryCount = 0;
        mResumeRetryRunnable = null;
    }

    /**
     * Reacts to a change in audio focus.
     *
     * <p>The interruption record is set on the first loss that
     * interrupts a live transition and is not overwritten by a
     * subsequent loss of a different kind. A dialer that sends
     * {@code AUDIOFOCUS_LOSS} for the ringtone and
     * {@code AUDIOFOCUS_LOSS_TRANSIENT} for the call produces one
     * record, and the gain that follows resumes from it.</p>
     *
     * <p>Gain goes through {@link #resumeAfterInterruption()},
     * which retries focus acquisition for a bounded window. When
     * {@code AudioManager.getMode()} reports a call mode at the
     * moment of the gain, the first focus attempt is skipped and
     * the retry path is entered directly.</p>
     *
     * <p>The duck path is unchanged: a duck lowers the
     * MediaPlayer's own output volume and does not touch the
     * interruption record or the system stream volume.</p>
     *
     * @param focusChange The audio focus change code
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT: {
                mHasAudioFocus = false;

                final InterruptionKind kind =
                    (focusChange == AudioManager.AUDIOFOCUS_LOSS)
                        ? InterruptionKind.PERMANENT_LOSS
                        : InterruptionKind.TRANSIENT_LOSS;

                if (mInterruption == null
                        && (mState == ServiceState.PLAYING
                            || mState == ServiceState.PREPARING
                            || mState == ServiceState.READY)) {
                    final boolean wasPlaying =
                        (mState == ServiceState.PLAYING
                            || (mState == ServiceState.PREPARING
                                && mAutoStartOnPrepared
                                && !mPauseAfterPrepare));
                    if (wasPlaying) {
                        mInterruption = new Interruption(
                            kind,
                            SystemClock.elapsedRealtime(),
                            true,
                            mGeneration);
                    }
                } else if (mInterruption != null
                        && mInterruption.kind
                            == InterruptionKind.TRANSIENT_LOSS
                        && kind
                            == InterruptionKind.PERMANENT_LOSS) {
                    mInterruption = new Interruption(
                        kind,
                        SystemClock.elapsedRealtime(),
                        mInterruption.wasPlaying,
                        mGeneration);
                }

                if (mState == ServiceState.PLAYING) {
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPauseAfterPrepare = true;
                    mAutoStartOnPrepared = false;
                }
                break;
            }

            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                mHasAudioFocus = false;
                mIsDucked = true;
                onPlayer(() -> applyDuckVolume(mMediaPlayer));
                break;

            case AudioManager.AUDIOFOCUS_GAIN:
                mHasAudioFocus = true;
                if (mIsDucked) {
                    mIsDucked = false;
                    onPlayer(() -> applyDuckVolume(mMediaPlayer));
                }
                if (mInterruption == null) {
                    return;
                }
                if (mAudioManager != null
                        && mAudioManager.getMode()
                            != AudioManager.MODE_NORMAL) {
                    if (mResumeRetryCount
                            < RESUME_RETRY_ATTEMPTS) {
                        mResumeRetryCount++;
                        if (mResumeRetryRunnable != null) {
                            mMainHandler.removeCallbacks(
                                mResumeRetryRunnable);
                        }
                        mResumeRetryRunnable =
                            this::resumeAfterInterruption;
                        mMainHandler.postDelayed(
                            mResumeRetryRunnable,
                            RESUME_RETRY_INTERVAL_MS);
                    }
                    return;
                }
                resumeAfterInterruption();
                break;

            default:
                break;
        }
    }

    /**
     * Applies the current duck state to the given player's output
     * volume.
     *
     * <p>Called on the player thread. The system stream volume is
     * not touched: the duck is a scale applied to the MediaPlayer's
     * own output.</p>
     *
     * @param player The player to adjust, or null when none exists
     */
    private void applyDuckVolume(@Nullable MediaPlayer player) {
        if (player == null) {
            return;
        }
        final float volume = mIsDucked ? DUCK_VOLUME_FRACTION : 1.0f;
        try {
            player.setVolume(volume, volume);
        } catch (Exception ignored) {
            // The player is not in a state that permits volume
            // changes.
        }
    }

    // ============================================================================
    // Media Button
    // ============================================================================

    /**
     * Handles a media key press.
     *
     * <p>Debounced at {@link #NOTIFICATION_ACTION_DEBOUNCE_MS},
     * matching the player screen's own debounce and the media
     * session callbacks.</p>
     *
     * <p>Clears the interruption record as its first action: a
     * user action through a hardware key is a deliberate transition
     * that supersedes a pending interruption.</p>
     *
     * @param keyCode The key code to handle
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected
                && (keyCode == KeyEvent.KEYCODE_VOLUME_UP
                    || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && !mHasAudioFocus) {
            return;
        }

        clearInterruption();

        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                if (!isNotificationActionDebounced("ACTION_NEXT")) {
                    playNextSong();
                }
                return;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                if (!isNotificationActionDebounced("ACTION_PREV")) {
                    playPreviousSong();
                }
                return;
            }
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (!isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                    togglePlayPause();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                if (!isNotificationActionDebounced("ACTION_NEXT")) {
                    playNextSong();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                if (!isNotificationActionDebounced("ACTION_PREV")) {
                    playPreviousSong();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                    break;
                }
                if (mState == ServiceState.PAUSED) {
                    doResume();
                } else if (mState == ServiceState.IDLE) {
                    resume();
                } else if (mState == ServiceState.READY) {
                    togglePlayPause();
                } else if (mState == ServiceState.PREPARING) {
                    if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                        mPauseAfterPrepare = false;
                        mAutoStartOnPrepared = true;
                    }
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (isNotificationActionDebounced("ACTION_PLAY_PAUSE")) {
                    break;
                }
                if (mState == ServiceState.PLAYING) {
                    doPause();
                } else if (mState == ServiceState.PREPARING) {
                    mPauseAfterPrepare = true;
                }
                break;
            default:
                break;
        }
    }

    // ============================================================================
    // Broadcasts
    // ============================================================================

    /**
     * Sends the current full playback snapshot as an
     * {@code UPDATE_PLAYER} broadcast, and commits the same snapshot
     * to the notification synchronously with the broadcast.
     *
     * <p>The broadcast carries the window the carousel should
     * render, the direction and restart of the transition that
     * produced it, the display title and artist the player UI
     * should show, the favorite flag of the currently bound song,
     * and the kind and size of the active playback scope. The
     * notification and the media session are committed through
     * {@link NotificationController#commitFromBroadcast(long,
     * NotificationController.RenderSnapshot)} on the same
     * main-thread turn.</p>
     */
    private void broadcastUpdate() {
        PlaybackWindow windowSnapshot = getWindowSnapshot();
        Song displaySong = getDisplaySong();
        Song currentSong = getCurrentSong();
        final long generation = mGeneration;

        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("generation", generation);
        intent.putExtra("state", mState.name());
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("target_index", mTargetIndex);
        intent.putExtra("song_path", pathOf(mCurrentIndex));
        intent.putExtra("target_song_path", pathOf(mTargetIndex));
        intent.putExtra("is_playing", isPlaying());
        intent.putExtra("position_ms", getCurrentPosition());
        intent.putExtra("duration_ms", getDuration());

        intent.putExtra("window_previous_path",
            windowSnapshot.previousPath);
        intent.putExtra("window_current_path",
            windowSnapshot.currentPath);
        intent.putExtra("window_next_path",
            windowSnapshot.nextPath);

        intent.putExtra("transition_direction", mGenerationDirection);
        intent.putExtra("transition_restart", mGenerationRestart);

        if (displaySong != null) {
            intent.putExtra("display_title", displaySong.getTitle());
            intent.putExtra("display_artist",
                displaySong.getArtist());
        }

        intent.putExtra("is_favorite",
            currentSong != null && currentSong.isFavorite());
        intent.putExtra("scope_kind", mPlaybackScope.kind.name());
        intent.putExtra("scope_count",
            mScopedPlaylist != null ? mScopedPlaylist.size() : 0);

        sendBroadcast(intent);

        if (mNotificationController != null) {
            final NotificationController.RenderSnapshot snapshot =
                mStateSource.snapshotForNotification();
            mNotificationController.commitFromBroadcast(
                generation, snapshot);
        }
    }

    /**
     * Sends the current audio session identifier as an
     * {@code AUDIO_SESSION_CHANGED} broadcast.
     *
     * @param sessionId The audio session identifier
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the editor
     * knows it. When the editor only knows the URI — a SAF-only
     * write where the content provider does not expose a filesystem
     * path — the path is resolved against the song database by URI
     * match.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }

    // ============================================================================
    // Receivers
    // ============================================================================

    /**
     * Registers the receiver for playback parameter update
     * broadcasts.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(
                        intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiverSafely(mPlaybackParamsReceiver,
            new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    /**
     * Registers the receiver for playlist clear broadcasts.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiverSafely(mClearPlaylistReceiver,
            new IntentFilter("CLEAR_PLAYLIST"));
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(
                        intent.getAction())) {
                    // The notification surface observes theme
                    // changes on its own.
                }
            }
        };
        registerReceiverSafely(mThemeReceiver,
            new IntentFilter("THEME_COLOR_CHANGED"));
    }

    /**
     * Registers the receiver for playing state query broadcasts.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent response =
                        new Intent("PLAYING_STATE_RESPONSE");
                    response.putExtra("is_playing", isPlaying());
                    sendBroadcast(response);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_LAST_PLAYING, isPlaying())
                        .apply();
                }
            }
        };
        registerReceiverSafely(mGetPlayingStateReceiver,
            new IntentFilter("GET_PLAYING_STATE"));
    }

    /**
     * Registers the receiver for sort mode change broadcasts.
     *
     * <p>The reorder runs on {@link #mSortExecutor}, not on the
     * main thread. A newer sort-mode change that arrives while an
     * older one is still sorting sets
     * {@link #mCurrentSortMode} to the newer value; the older
     * task's commit step compares that field against the mode it
     * captured, and a mismatch means the newer task is responsible
     * for the reorder.</p>
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_UPDATE_SORT_MODE.equals(
                        intent.getAction())) {
                    return;
                }
                final int newSortMode = intent.getIntExtra(
                    EXTRA_SORT_MODE, SORT_TITLE_AZ);
                if (mCurrentSortMode == newSortMode) {
                    return;
                }
                mCurrentSortMode = newSortMode;
                saveSortMode();

                if (mCurrentPlaylist == null
                        || mCurrentPlaylist.isEmpty()) {
                    return;
                }

                final ArrayList<Song> snapshot =
                    new ArrayList<>(mCurrentPlaylist);
                final String anchorPath = pathOf(mCurrentIndex);
                final int sortMode = newSortMode;

                mSortExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Collections.sort(snapshot,
                            getComparatorForSortMode(sortMode));

                        onMain(new Runnable() {
                            @Override
                            public void run() {
                                if (mCurrentSortMode != sortMode) {
                                    return;
                                }
                                if (mCurrentPlaylist == null
                                        || mCurrentPlaylist
                                            .isEmpty()) {
                                    return;
                                }

                                mCurrentPlaylist = snapshot;

                                clearShufflePeek();
                                if (mShuffleHistory != null) {
                                    mShuffleHistory.clear();
                                }

                                if (anchorPath != null) {
                                    int newIndex =
                                        indexOfPath(anchorPath);
                                    if (newIndex >= 0) {
                                        mCurrentIndex = newIndex;
                                        mTargetIndex = newIndex;
                                        saveCurrentPlayingIndex();
                                    }
                                }
                                broadcastUpdate();
                            }
                        });
                    }
                });
            }
        };
        registerReceiverSafely(mSortModeReceiver,
            new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }

    /**
     * Registers the receiver for sync completion broadcasts.
     */
    private void registerSyncCompleteReceiver() {
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                broadcastUpdate();
            }
        };
        registerReceiverSafely(mSyncCompleteReceiver,
            new IntentFilter("SYNC_COMPLETE"));
    }

    /**
     * Registers the receiver for genre update broadcasts.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_GENRE_UPDATE.equals(
                        intent.getAction())) {
                    return;
                }
                String status = intent.getStringExtra("status");
                if ("UPDATE".equals(status)) {
                    updateGenreInPlaylist(
                        intent.getStringExtra("song_path"),
                        intent.getStringExtra("genre"));
                } else if ("COMPLETE".equals(status)) {
                    broadcastUpdate();
                }
            }
        };
        registerReceiverSafely(mGenreUpdateReceiver,
            new IntentFilter(ACTION_GENRE_UPDATE));
    }

    /**
     * Registers the receiver for {@code METADATA_UPDATED}
     * broadcasts.
     */
    private void registerMetadataUpdatedReceiver() {
        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null) {
                    return;
                }

                final String title =
                    intent.getStringExtra("title");
                final String artist =
                    intent.getStringExtra("artist");
                final String album =
                    intent.getStringExtra("album");
                final String genre =
                    intent.getStringExtra("genre");
                final String uriString =
                    intent.getStringExtra("song_uri");
                final boolean albumArtRemoved =
                    intent.getBooleanExtra(
                        "album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                refreshMetadataForSong(songPath, title, artist,
                    album, genre, uriString, albumArtBytes,
                    albumArtRemoved);
            }
        };
        registerReceiverSafely(mMetadataUpdatedReceiver,
            new IntentFilter(ACTION_METADATA_UPDATED));
    }

    /**
     * Registers the receiver for soft playlist update broadcasts.
     */
    private void registerUpdatePlaylistReceiver() {
        mUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYLIST".equals(
                            intent.getAction())) {
                    return;
                }

                if (mMusicLibrary == null) {
                    mMusicLibrary =
                        new MusicLibrary(MusicService.this);
                }
                mMusicLibrary.refreshCache();

                ArrayList<Song> allSongs =
                    mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    setPlaylist(allSongs, true);
                }
            }
        };
        registerReceiverSafely(mUpdatePlaylistReceiver,
            new IntentFilter("UPDATE_PLAYLIST"));
    }

    /**
     * Registers the receiver for pending song path broadcasts.
     */
    private void registerSetPendingSongReceiver() {
        mSetPendingSongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SET_PENDING_SONG.equals(
                        intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (path != null) {
                        setPendingSongPath(path);
                    }
                }
            }
        };
        registerReceiverSafely(mSetPendingSongReceiver,
            new IntentFilter(ACTION_SET_PENDING_SONG));
    }

    /**
     * Registers the receiver for library reset broadcasts emitted
     * by {@link PlaylistManager}.
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!PlaylistManager.ACTION_LIBRARY_RESET.equals(
                        intent.getAction())) {
                    return;
                }
                final boolean preserveSettings =
                    intent.getBooleanExtra(
                        PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);
                Log.d(TAG,
                    "LIBRARY_RESET received (preserve_settings="
                        + preserveSettings + ")");
                onMain(() -> {
                    stopCompletely();

                    mResolvedArtPath = null;
                    mResolvedArt = null;
                    if (mCurrentArtLoad != null) {
                        mCurrentArtLoad.cancel(true);
                        mCurrentArtLoad = null;
                    }
                    if (mArtCache != null) {
                        mArtCache.evictAll();
                    }

                    if (mMusicLibrary != null) {
                        mMusicLibrary.invalidate();
                    }

                    if (!preserveSettings) {
                        mRepeatMode = 0;
                        mIsShuffle = false;
                        mCurrentSortMode = SORT_TITLE_AZ;
                        if (mShuffleHistory != null) {
                            mShuffleHistory.clear();
                        }
                        clearShufflePeek();
                        savePlayerState();
                        saveSortMode();
                    }
                });
            }
        };
        registerReceiverSafely(mLibraryResetReceiver,
            new IntentFilter(PlaylistManager.ACTION_LIBRARY_RESET));
    }

    /**
     * Registers the receiver for the Bluetooth-disconnect pause
     * request.
     *
     * <p>Called from {@link #onCreate()} and unregistered in
     * {@link #onDestroy()}. The service owns this pause because
     * the service owns the audio. The receiver is live for the
     * service's whole lifetime, so a disconnect that arrives while
     * no activity is showing still pauses the music.</p>
     *
     * <p>The pause is gated by {@link #onBluetoothDisconnect} on
     * three conditions: the Bluetooth device must be the active
     * route, no interruption may already be handling the pause,
     * and the state must be PLAYING.</p>
     */
    private void registerBluetoothPauseReceiver() {
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_BLUETOOTH_PAUSE.equals(
                            intent.getAction())) {
                    return;
                }
                onMain(() -> onBluetoothDisconnect(intent));
            }
        };
        registerReceiverSafely(mBluetoothPauseReceiver,
            new IntentFilter(ACTION_BLUETOOTH_PAUSE));
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG,
                "Failed to register receiver", exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver == null) {
            return;
        }
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
            // The receiver was already unregistered.
        }
    }

    // ============================================================================
    // Genre and Metadata Updates
    // ============================================================================

    /**
     * Updates the in-memory genre of the given song.
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     */
    private void updateGenreInPlaylist(@NonNull String songPath,
                                       @NonNull String newGenre) {
        if (TextUtils.isEmpty(songPath)
                || TextUtils.isEmpty(newGenre)) {
            return;
        }
        if (mCurrentPlaylist == null) {
            return;
        }

        for (int index = 0; index < mCurrentPlaylist.size(); index++) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                String previousGenre = song.getGenre();
                if (!newGenre.equals(previousGenre)) {
                    song.setGenre(newGenre);
                }
                break;
            }
        }
    }

    /**
     * Refreshes every playlist entry that carries the given path
     * from a change published by {@link MetadataEditor}.
     *
     * @param songPath Path of the edited song
     * @param newTitle New title, or null for no change
     * @param newArtist New artist, or null for no change
     * @param newAlbum New album, or null for no change
     * @param newGenre New genre, or null for no change
     * @param uriString New URI string, or null for no change
     * @param albumArtBytes New album art bytes, or null for no
     *        change
     * @param albumArtRemoved True when the album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable String uriString,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        onMain(() -> {
            boolean playlistChanged = false;
            String resolvedUri = (uriString != null
                && !uriString.isEmpty()) ? uriString : null;
            String knownTitle = newTitle;
            String knownArtist = newArtist;
            String knownAlbum = newAlbum;
            String knownGenre = newGenre;
            long knownDuration = 0L;

            if (mCurrentPlaylist != null) {
                for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                    Song song = mCurrentPlaylist.get(i);
                    if (song == null
                            || !songPath.equals(song.getPath())) {
                        continue;
                    }
                    if (knownTitle == null) {
                        knownTitle = song.getTitle();
                    }
                    if (knownArtist == null) {
                        knownArtist = song.getArtist();
                    }
                    if (knownAlbum == null) {
                        knownAlbum = song.getAlbum();
                    }
                    if (knownGenre == null) {
                        knownGenre = song.getGenre();
                    }
                    if (resolvedUri == null) {
                        resolvedUri = song.getUri();
                    }
                    if (knownDuration == 0L) {
                        knownDuration = song.getDuration();
                    }

                    Song updated = new Song(
                        newTitle != null && !newTitle.isEmpty()
                            ? newTitle : song.getTitle(),
                        newArtist != null && !newArtist.isEmpty()
                            ? newArtist : song.getArtist(),
                        newAlbum != null && !newAlbum.isEmpty()
                            ? newAlbum : song.getAlbum(),
                        newGenre != null && !newGenre.isEmpty()
                            ? newGenre : song.getGenre(),
                        songPath,
                        song.getDuration(),
                        resolvedUri != null
                            ? resolvedUri : song.getUri());
                    mCurrentPlaylist.set(i, updated);
                    playlistChanged = true;
                }
            }

            if (playlistChanged) {
                Song persisted = new Song(
                    knownTitle != null ? knownTitle
                        : CharacterMapper.getUnknownTitle(),
                    knownArtist != null ? knownArtist
                        : CharacterMapper.getUnknownArtist(),
                    knownAlbum != null ? knownAlbum
                        : CharacterMapper.getUnknownAlbum(),
                    knownGenre != null ? knownGenre
                        : CharacterMapper.getUnknownGenre(),
                    songPath, knownDuration, resolvedUri);
                SongDatabase.getInstance(this).insertSong(persisted);
            }

            android.util.LruCache<String, Bitmap> sharedCache =
                AlbumArtCache.getInstance(this).asLruCache();
            if (sharedCache != null) {
                sharedCache.remove(songPath);
                if (resolvedUri != null) {
                    sharedCache.remove(resolvedUri);
                }
            }
            if (mArtCache != null) {
                mArtCache.remove(songPath);
            }

            Bitmap newArt = null;
            if (albumArtRemoved) {
                mResolvedArtPath = songPath;
                mResolvedArt = null;
                if (mCurrentArtLoad != null) {
                    mCurrentArtLoad.cancel(true);
                    mCurrentArtLoad = null;
                }
            } else if (albumArtBytes != null) {
                newArt = BitmapFactory.decodeByteArray(
                    albumArtBytes, 0, albumArtBytes.length);
                if (newArt != null) {
                    if (sharedCache != null) {
                        sharedCache.put(songPath, newArt);
                    }
                    if (mArtCache != null) {
                        mArtCache.put(songPath, newArt);
                    }
                    mResolvedArtPath = songPath;
                    mResolvedArt = newArt;
                }
            }

            broadcastUpdate();
        });
    }
}