package com.ark.llama;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Reads ID3 tags and other metadata from audio files.
 *
 * <p>Supports MP3, FLAC, OGG, M4A, and MP4 formats. Reads can be
 * performed against a filesystem path or against a document URI from the
 * Storage Access Framework. Every write operation is handled by
 * {@link MetadataWriter}.</p>
 *
 * <h3>Result Contract</h3>
 * <p>A read produces a {@link MetadataBundle} whose string fields are all
 * non-null, using the empty string as the "not present" value, and whose
 * {@link MetadataBundle#status} field distinguishes the three outcomes
 * the reader can produce. Callers branch on the status for control flow
 * and use the string fields for display. The {@link
 * MetadataBundle#hasAlbumArt()} method is a convenience for the common
 * check against {@code albumArt}.</p>
 *
 * <p>When a read is performed from a document URI, the source file's
 * extension is determined from the {@link DocumentFile}'s name, and the
 * reported {@link MetadataBundle#format} reflects that source extension.
 * The {@link MetadataBundle#isWriteSupported} flag is derived from the
 * same extension.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>This class holds no mutable static state. Every method is static
 * and uses only local variables. Callers that run reads concurrently are
 * responsible for the thread safety of any shared dependency the reads
 * touch.</p>
 *
 * @see MetadataWriter
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class MetadataReader {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "MetadataReader";

    /** Buffer size for file copy operations, in bytes. */
    private static final int COPY_BUFFER_SIZE = 8192;

    /** Extensions for which jaudiotagger's write path is supported. */
    private static final Set<String> WRITABLE_EXTENSIONS = new HashSet<>(Arrays.asList(
        "mp3", "flac", "ogg", "m4a", "mp4"
    ));

    /** Fallback extension used when the source format cannot be determined. */
    private static final String DEFAULT_EXTENSION = "mp3";

    // ========================================================================
    // Private Constructor
    // ========================================================================

    /**
     * Prevents instantiation of this utility class.
     */
    private MetadataReader() {
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Holds the result of a metadata read.
     *
     * <p>All string fields are non-null. A field carries the empty string
     * when the corresponding tag was absent. The {@link #status} field
     * distinguishes the three outcomes of a read.</p>
     */
    public static final class MetadataBundle {

        /** Exhaustive outcomes of a metadata read. */
        public enum Status {
            /** The file was read and jaudiotagger extracted whatever tags it found. */
            SUCCESS,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        /** The outcome of the read. */
        @NonNull public Status status = Status.SUCCESS;

        /** Song title; empty string when absent. */
        @NonNull public String title = "";

        /** Artist name; empty string when absent. */
        @NonNull public String artist = "";

        /** Album name; empty string when absent. */
        @NonNull public String album = "";

        /** Release year; empty string when absent. */
        @NonNull public String year = "";

        /** Music genre; empty string when absent. */
        @NonNull public String genre = "";

        /** Track number; empty string when absent. */
        @NonNull public String trackNumber = "";

        /** Lyrics; empty string when absent. */
        @NonNull public String lyrics = "";

        /** Album art bytes, or null when absent. */
        @Nullable public byte[] albumArt;

        /** Audio file format, uppercase. */
        @NonNull public String format = "Unknown";

        /** True when the format supports metadata writing. */
        public boolean isWriteSupported = false;

        /** File size in bytes. */
        public long fileSize = 0;

        /** Track duration in milliseconds. */
        public long duration = 0;

        /**
         * Constructs an empty bundle.
         */
        public MetadataBundle() {
        }

        /**
         * Returns whether at least one metadata value is present.
         *
         * <p>A field that carries the empty string and an album art value
         * that is null or empty both count as absent.</p>
         *
         * @return True when a title, artist, album, year, genre, track
         *         number, lyrics, or album art value is present
         */
        public boolean hasMetadata() {
            return !TextUtils.isEmpty(title) || !TextUtils.isEmpty(artist)
                || !TextUtils.isEmpty(album) || !TextUtils.isEmpty(year)
                || !TextUtils.isEmpty(genre) || !TextUtils.isEmpty(trackNumber)
                || !TextUtils.isEmpty(lyrics) || hasAlbumArt();
        }

        /**
         * Returns whether this bundle carries album art bytes.
         *
         * @return True when {@link #albumArt} is non-null and non-empty
         */
        public boolean hasAlbumArt() {
            return albumArt != null && albumArt.length > 0;
        }

        /**
         * Returns a debug representation of this bundle.
         *
         * @return A string containing every field's value, with the album
         *         art reduced to a boolean
         */
        @NonNull
        @Override
        public String toString() {
            return "MetadataBundle{" +
                    "status=" + status +
                    ", title='" + title + '\'' +
                    ", artist='" + artist + '\'' +
                    ", album='" + album + '\'' +
                    ", year='" + year + '\'' +
                    ", genre='" + genre + '\'' +
                    ", trackNumber='" + trackNumber + '\'' +
                    ", format='" + format + '\'' +
                    ", isWriteSupported=" + isWriteSupported +
                    ", fileSize=" + fileSize +
                    ", duration=" + duration +
                    ", hasAlbumArt=" + hasAlbumArt() +
                    '}';
        }
    }

    // ========================================================================
    // Public Read Methods
    // ========================================================================

    /**
     * Reads the metadata of the audio file at the given path.
     *
     * <p>File size and format are always populated from the file itself.
     * Title, artist, album, year, genre, track number, lyrics, and album
     * art are populated from the file's tags, using the empty string or
     * null for absent values. Duration is read through
     * {@link MediaMetadataRetriever} and falls back to jaudiotagger when
     * the retriever reports no duration.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return A bundle containing the metadata and the outcome of the read
     */
    @NonNull
    public static MetadataBundle readMetadata(@NonNull final String filePath) {
        final MetadataBundle bundle = new MetadataBundle();

        if (TextUtils.isEmpty(filePath)) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            return bundle;
        }

        final File file = new File(filePath);
        if (!file.exists() || !file.canRead()) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            Log.w(TAG, "File does not exist or cannot be read: " + filePath);
            return bundle;
        }

        bundle.fileSize = file.length();
        bundle.format = getFileExtension(filePath).toUpperCase();
        bundle.isWriteSupported = isWriteSupportedFormat(bundle.format);

        AudioFile audioFile = null;
        MediaMetadataRetriever retriever = null;

        try {
            audioFile = AudioFileIO.read(file);
            if (audioFile != null) {
                final Tag tag = audioFile.getTag();
                if (tag != null) {
                    bundle.title = cleanString(tag.getFirst(FieldKey.TITLE));
                    bundle.artist = cleanString(tag.getFirst(FieldKey.ARTIST));
                    bundle.album = cleanString(tag.getFirst(FieldKey.ALBUM));
                    bundle.year = cleanString(tag.getFirst(FieldKey.YEAR));
                    bundle.genre = cleanString(tag.getFirst(FieldKey.GENRE));
                    bundle.trackNumber = cleanString(tag.getFirst(FieldKey.TRACK));
                    bundle.lyrics = cleanString(tag.getFirst(FieldKey.LYRICS));

                    try {
                        final Artwork artwork = tag.getFirstArtwork();
                        if (artwork != null && artwork.getBinaryData() != null) {
                            bundle.albumArt = artwork.getBinaryData();
                            Log.d(TAG, "Read album art: " + bundle.albumArt.length + " bytes");
                        }
                    } catch (Exception exception) {
                        Log.w(TAG, "Failed to read album art: " + exception.getMessage());
                    }
                }
            } else {
                bundle.status = MetadataBundle.Status.PARSE_FAILED;
            }

            try {
                retriever = new MediaMetadataRetriever();
                retriever.setDataSource(filePath);
                String durationString = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION);
                if (durationString != null) {
                    bundle.duration = Long.parseLong(durationString);
                    Log.d(TAG, "Duration from MediaMetadataRetriever: "
                        + bundle.duration + " ms");
                } else if (audioFile != null && audioFile.getAudioHeader() != null) {
                    bundle.duration = audioFile.getAudioHeader().getTrackLength() * 1000L;
                    Log.d(TAG, "Duration from jaudiotagger (fallback): "
                        + bundle.duration + " ms");
                }
            } catch (Exception exception) {
                Log.w(TAG, "MediaMetadataRetriever failed, using jaudiotagger fallback",
                    exception);
                if (audioFile != null && audioFile.getAudioHeader() != null) {
                    bundle.duration = audioFile.getAudioHeader().getTrackLength() * 1000L;
                }
            }

        } catch (Exception exception) {
            Log.e(TAG, "Failed to read metadata from: " + filePath, exception);
            bundle.status = MetadataBundle.Status.PARSE_FAILED;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception ignored) {
                    // The retriever is not in a state that permits release.
                }
            }
        }

        return bundle;
    }

    /**
     * Reads the metadata of the audio file referenced by the given
     * document URI.
     *
     * <p>The file is copied to the application cache, its metadata is
     * read through {@link #readMetadata(String)}, and the cache file is
     * deleted before the method returns. The source extension reported
     * by {@link DocumentFile} determines the extension used for the
     * cache file, so jaudiotagger invokes the reader that matches the
     * source format.</p>
     *
     * @param context Context used to open the URI
     * @param documentUri Document URI from the Storage Access Framework
     * @return A bundle containing the metadata and the outcome of the read
     */
    @NonNull
    public static MetadataBundle readMetadataFromUri(@NonNull final Context context,
                                                      @NonNull final Uri documentUri) {
        String sourceExtension = determineSourceExtension(context, documentUri);

        final File cacheFile = copyUriToCache(context, documentUri, sourceExtension);
        if (cacheFile == null) {
            final MetadataBundle bundle = new MetadataBundle();
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            Log.w(TAG, "Failed to copy URI to cache: " + documentUri);
            return bundle;
        }
        final MetadataBundle bundle = readMetadata(cacheFile.getAbsolutePath());
        deleteFileSafely(cacheFile);
        return bundle;
    }

    /**
     * Returns whether the given file's format supports metadata writing.
     *
     * @param filePath Path to the audio file
     * @return True when the file's extension is writable
     */
    public static boolean isWriteSupported(@NonNull final String filePath) {
        return isWriteSupportedFormat(getFileExtension(filePath));
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Returns the extension to use for the cache file created from the
     * given document URI.
     *
     * <p>Prefers the {@link DocumentFile}'s name, falls back to the URI's
     * last path segment, and finally falls back to
     * {@link #DEFAULT_EXTENSION}.</p>
     *
     * @param context Context used to build the document file
     * @param documentUri Document URI to inspect
     * @return The extension to use, without a leading dot
     */
    @NonNull
    private static String determineSourceExtension(@NonNull final Context context,
                                                   @NonNull final Uri documentUri) {
        try {
            final DocumentFile doc = DocumentFile.fromSingleUri(context, documentUri);
            if (doc != null && doc.getName() != null) {
                String ext = getFileExtension(doc.getName());
                if (!ext.isEmpty()) {
                    return ext;
                }
            }
        } catch (Exception ignored) {
            // Fall through to the next strategy.
        }

        final String lastSegment = documentUri.getLastPathSegment();
        if (lastSegment != null) {
            String ext = getFileExtension(lastSegment);
            if (!ext.isEmpty()) {
                return ext;
            }
        }

        return DEFAULT_EXTENSION;
    }

    /**
     * Returns whether the given extension belongs to a format that
     * jaudiotagger can write.
     *
     * @param extension The extension to test, without a leading dot
     * @return True when the extension is writable
     */
    private static boolean isWriteSupportedFormat(@NonNull final String extension) {
        return WRITABLE_EXTENSIONS.contains(extension.toLowerCase());
    }

    /**
     * Returns the input trimmed of surrounding whitespace.
     *
     * @param input The string to clean, or null
     * @return The trimmed string, or the empty string when the input is
     *         null or empty
     */
    @NonNull
    private static String cleanString(@Nullable final String input) {
        if (TextUtils.isEmpty(input)) {
            return "";
        }
        final String trimmed = input.trim();
        return trimmed.isEmpty() ? "" : trimmed;
    }

    /**
     * Returns the last extension of the given path.
     *
     * @param filePath The path to inspect
     * @return The extension without a leading dot, or the empty string
     *         when the path has none
     */
    @NonNull
    private static String getFileExtension(@NonNull final String filePath) {
        final int dotIndex = filePath.lastIndexOf(".");
        if (dotIndex > 0 && dotIndex < filePath.length() - 1) {
            return filePath.substring(dotIndex + 1);
        }
        return "";
    }

    /**
     * Copies the file referenced by the given URI into the application
     * cache directory, using the given extension for the cache file's
     * name.
     *
     * @param context Context used to open the URI and access the cache
     * @param uri URI of the file to copy
     * @param extension Extension to use for the cache file, without a
     *        leading dot
     * @return The cache file, or null when the copy fails
     */
    @Nullable
    private static File copyUriToCache(@NonNull final Context context,
                                       @NonNull final Uri uri,
                                       @NonNull final String extension) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: " + uri);
                return null;
            }
            final File outFile = new File(context.getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + "." + extension);
            outputStream = new FileOutputStream(outFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Copied " + totalBytes + " bytes from URI to cache: "
                + outFile.getName());
            return outFile;
        } catch (IOException exception) {
            Log.e(TAG, "copyUriToCache failed: " + exception.getMessage());
            return null;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Deletes the given file, logging any failure.
     *
     * @param file The file to delete, or null
     */
    private static void deleteFileSafely(@Nullable final File file) {
        if (file != null && file.exists()) {
            try {
                final boolean deleted = file.delete();
                Log.d(TAG, "Deleted " + file.getName() + ": " + deleted);
            } catch (SecurityException exception) {
                Log.w(TAG, "delete failed for " + file.getName() + ": "
                    + exception.getMessage());
            }
        }
    }

    /**
     * Closes the given {@link java.io.Closeable}, ignoring any exception.
     *
     * @param closeable The closeable to close, or null
     */
    private static void closeQuietly(@Nullable final java.io.Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException exception) {
                // The closeable is already closed.
            }
        }
    }
}