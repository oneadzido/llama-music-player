package com.ark.llama;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Utility class for reading audio file metadata.
 *
 * <p>This class provides read-only operations for extracting ID3 tags and
 * other metadata from audio files. It supports MP3, FLAC, OGG, M4A, and MP4
 * formats.</p>
 *
 * <p>This class is read-only to prevent accidental data loss. All write
 * operations are handled by {@link MetadataWriter}.</p>
 *
 * <h3>MetadataBundle Contract</h3>
 * <p>A read produces a {@link MetadataBundle} whose fields are all non-null
 * with {@code ""} as the "not present" value, and whose {@link
 * MetadataBundle#status} distinguishes the three outcomes the reader can
 * produce. Callers branch on the status for control flow and use the
 * string fields for display. The {@link MetadataBundle#hasAlbumArt()}
 * method is a convenience for the common check against {@code albumArt}.</p>
 *
 * <h3>Format Detection</h3>
 * <p>When reading from a document URI, the reader determines the source
 * file's extension from the {@link DocumentFile}'s name and uses it for the
 * cache file's name. This ensures jaudiotagger invokes the correct reader
 * for the format. The reported {@link MetadataBundle#format} and the
 * derived {@link MetadataBundle#isWriteSupported} reflect the source
 * format, not the cache file's synthetic name.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>This class is thread-safe. All methods are static and use only local
 * variables or thread-safe utilities.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class MetadataReader {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MetadataReader";

    /** Buffer size for file copy operations (8KB). */
    private static final int COPY_BUFFER_SIZE = 8192;

    /** Extensions for which jaudiotagger's write path is supported. */
    private static final Set<String> WRITABLE_EXTENSIONS = new HashSet<>(Arrays.asList(
        "mp3", "flac", "ogg", "m4a", "mp4"
    ));

    /** Fallback extension when the source format cannot be determined. */
    private static final String DEFAULT_EXTENSION = "mp3";

    // ========================================================================
    // Private Constructor
    // ========================================================================

    private MetadataReader() {
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Container class for audio file metadata.
     *
     * <p>All string fields are non-null. A field carries {@code ""} when the
     * corresponding tag was absent. The {@link #status} field distinguishes
     * the three outcomes of a read.</p>
     */
    public static final class MetadataBundle {

        /** Exhaustive outcomes of a metadata read. */
        public enum Status {
            /** The file was read and jaudiotagger extracted whatever tags it found. */
            SUCCESS,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        /** The outcome of the read. */
        @NonNull public Status status = Status.SUCCESS;

        /** Song title. Empty string if not present. */
        @NonNull public String title = "";

        /** Artist name. Empty string if not present. */
        @NonNull public String artist = "";

        /** Album name. Empty string if not present. */
        @NonNull public String album = "";

        /** Release year. Empty string if not present. */
        @NonNull public String year = "";

        /** Music genre. Empty string if not present. */
        @NonNull public String genre = "";

        /** Track number. Empty string if not present. */
        @NonNull public String trackNumber = "";

        /** Song lyrics. Empty string if not present. */
        @NonNull public String lyrics = "";

        /** Album art as JPEG byte array. Null if not present. */
        @Nullable public byte[] albumArt;

        /** Audio file format (e.g., "MP3", "FLAC"), uppercase. */
        @NonNull public String format = "Unknown";

        /** True if the format supports metadata writing. */
        public boolean isWriteSupported = false;

        /** File size in bytes. */
        public long fileSize = 0;

        /** Track duration in milliseconds. */
        public long duration = 0;

        /**
         * Creates an empty MetadataBundle.
         */
        public MetadataBundle() {
        }

        /**
         * True when at least one metadata field carries an actual value.
         *
         * <p>Fields holding the {@code ""} placeholder or the {@code null}
         * album art do not count.</p>
         *
         * @return true if any tag value is present
         */
        public boolean hasMetadata() {
            return !TextUtils.isEmpty(title) || !TextUtils.isEmpty(artist) ||
                   !TextUtils.isEmpty(album) || !TextUtils.isEmpty(year) ||
                   !TextUtils.isEmpty(genre) || !TextUtils.isEmpty(trackNumber) ||
                   !TextUtils.isEmpty(lyrics) || hasAlbumArt();
        }

        /**
         * True when the bundle carries album art bytes.
         *
         * @return true if albumArt is non-null and non-empty
         */
        public boolean hasAlbumArt() {
            return albumArt != null && albumArt.length > 0;
        }

        /**
         * Returns a string representation of the metadata bundle for debugging.
         *
         * @return Debug string
         */
        @NonNull
        @Override
        public String toString() {
            return "MetadataBundle{" +
                    "status=" + status +
                    ", title='" + title + '\'' +
                    ", artist='" + artist + '\'' +
                    ", album='" + album + '\'' +
                    ", year='" + year + '\'' +
                    ", genre='" + genre + '\'' +
                    ", trackNumber='" + trackNumber + '\'' +
                    ", format='" + format + '\'' +
                    ", isWriteSupported=" + isWriteSupported +
                    ", fileSize=" + fileSize +
                    ", duration=" + duration +
                    ", hasAlbumArt=" + hasAlbumArt() +
                    '}';
        }
    }

    // ========================================================================
    // Public Read Methods
    // ========================================================================

    /**
     * Reads metadata from an audio file.
     *
     * @param filePath Absolute path to the audio file
     * @return MetadataBundle containing all extracted metadata
     */
    @NonNull
    public static MetadataBundle readMetadata(@NonNull final String filePath) {
        final MetadataBundle bundle = new MetadataBundle();

        if (TextUtils.isEmpty(filePath)) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            return bundle;
        }

        final File file = new File(filePath);
        if (!file.exists() || !file.canRead()) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            Log.w(TAG, "File does not exist or cannot be read: " + filePath);
            return bundle;
        }

        bundle.fileSize = file.length();
        bundle.format = getFileExtension(filePath).toUpperCase();
        bundle.isWriteSupported = isWriteSupportedFormat(bundle.format);

        AudioFile audioFile = null;
        MediaMetadataRetriever retriever = null;

        try {
            audioFile = AudioFileIO.read(file);
            if (audioFile != null) {
                final Tag tag = audioFile.getTag();
                if (tag != null) {
                    bundle.title = cleanString(tag.getFirst(FieldKey.TITLE));
                    bundle.artist = cleanString(tag.getFirst(FieldKey.ARTIST));
                    bundle.album = cleanString(tag.getFirst(FieldKey.ALBUM));
                    bundle.year = cleanString(tag.getFirst(FieldKey.YEAR));
                    bundle.genre = cleanString(tag.getFirst(FieldKey.GENRE));
                    bundle.trackNumber = cleanString(tag.getFirst(FieldKey.TRACK));
                    bundle.lyrics = cleanString(tag.getFirst(FieldKey.LYRICS));

                    try {
                        final Artwork artwork = tag.getFirstArtwork();
                        if (artwork != null && artwork.getBinaryData() != null) {
                            bundle.albumArt = artwork.getBinaryData();
                            Log.d(TAG, "Read album art: " + bundle.albumArt.length + " bytes");
                        }
                    } catch (Exception exception) {
                        Log.w(TAG, "Failed to read album art: " + exception.getMessage());
                    }
                }
            } else {
                bundle.status = MetadataBundle.Status.PARSE_FAILED;
            }

            try {
                retriever = new MediaMetadataRetriever();
                retriever.setDataSource(filePath);
                String durationString = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION);
                if (durationString != null) {
                    bundle.duration = Long.parseLong(durationString);
                    Log.d(TAG, "Duration from MediaMetadataRetriever: " + bundle.duration + " ms");
                } else if (audioFile != null && audioFile.getAudioHeader() != null) {
                    bundle.duration = audioFile.getAudioHeader().getTrackLength() * 1000L;
                    Log.d(TAG, "Duration from jaudiotagger (fallback): " + bundle.duration + " ms");
                }
            } catch (Exception exception) {
                Log.w(TAG, "MediaMetadataRetriever failed, using jaudiotagger fallback", exception);
                if (audioFile != null && audioFile.getAudioHeader() != null) {
                    bundle.duration = audioFile.getAudioHeader().getTrackLength() * 1000L;
                }
            }

        } catch (Exception exception) {
            Log.e(TAG, "Failed to read metadata from: " + filePath, exception);
            bundle.status = MetadataBundle.Status.PARSE_FAILED;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception ignored) {
                }
            }
        }

        return bundle;
    }

    /**
     * Reads metadata from an audio file accessed via a document URI (SAF).
     *
     * <p>The source file's extension is determined from the {@link
     * DocumentFile}'s name and used for the cache file's name so
     * jaudiotagger invokes the correct reader for the format. The cache
     * file is deleted after reading.</p>
     *
     * @param context Application context
     * @param documentUri Document URI from Storage Access Framework
     * @return MetadataBundle containing all extracted metadata
     */
    @NonNull
    public static MetadataBundle readMetadataFromUri(@NonNull final Context context,
                                                      @NonNull final Uri documentUri) {
        // Determine the source file's extension. The DocumentFile name is the
        // authoritative source; the URI's last path segment is a fallback.
        String sourceExtension = determineSourceExtension(context, documentUri);

        final File cacheFile = copyUriToCache(context, documentUri, sourceExtension);
        if (cacheFile == null) {
            final MetadataBundle bundle = new MetadataBundle();
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE;
            Log.w(TAG, "Failed to copy URI to cache: " + documentUri);
            return bundle;
        }
        final MetadataBundle bundle = readMetadata(cacheFile.getAbsolutePath());
        deleteFileSafely(cacheFile);
        return bundle;
    }

    /**
     * Checks if the file format supports metadata writing.
     *
     * @param filePath Path to the audio file
     * @return True if the format is writable
     */
    public static boolean isWriteSupported(@NonNull final String filePath) {
        return isWriteSupportedFormat(getFileExtension(filePath));
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Determines the source file's extension, preferring the
     * {@link DocumentFile}'s name and falling back to the URI's last path
     * segment.
     */
    @NonNull
    private static String determineSourceExtension(@NonNull final Context context,
                                                   @NonNull final Uri documentUri) {
        try {
            final DocumentFile doc = DocumentFile.fromSingleUri(context, documentUri);
            if (doc != null && doc.getName() != null) {
                String ext = getFileExtension(doc.getName());
                if (!ext.isEmpty()) return ext;
            }
        } catch (Exception ignored) {
        }

        final String lastSegment = documentUri.getLastPathSegment();
        if (lastSegment != null) {
            String ext = getFileExtension(lastSegment);
            if (!ext.isEmpty()) return ext;
        }

        return DEFAULT_EXTENSION;
    }

    /**
     * True when the given extension belongs to a format jaudiotagger can
     * write.
     */
    private static boolean isWriteSupportedFormat(@NonNull final String extension) {
        return WRITABLE_EXTENSIONS.contains(extension.toLowerCase());
    }

    /**
     * Cleans a string by trimming and converting empty to null.
     *
     * @param input The input string (can be null)
     * @return Trimmed string, or empty string if null or empty
     */
    @NonNull
    private static String cleanString(@Nullable final String input) {
        if (TextUtils.isEmpty(input)) {
            return "";
        }
        final String trimmed = input.trim();
        return trimmed.isEmpty() ? "" : trimmed;
    }

    /**
     * Extracts the file extension from a file path.
     *
     * @param filePath The file path
     * @return The file extension (e.g., "mp3"), or empty string if none
     */
    @NonNull
    private static String getFileExtension(@NonNull final String filePath) {
        final int dotIndex = filePath.lastIndexOf(".");
        if (dotIndex > 0 && dotIndex < filePath.length() - 1) {
            return filePath.substring(dotIndex + 1);
        }
        return "";
    }

    /**
     * Copies a file from a document URI to the cache directory, preserving
     * the source's extension so jaudiotagger invokes the correct reader.
     *
     * @param context Application context
     * @param uri The document URI to copy from
     * @param extension The source file's extension
     * @return The cached file, or null if copy fails
     */
    @Nullable
    private static File copyUriToCache(@NonNull final Context context,
                                       @NonNull final Uri uri,
                                       @NonNull final String extension) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: " + uri);
                return null;
            }
            final File outFile = new File(context.getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + "." + extension);
            outputStream = new FileOutputStream(outFile);
            final byte[] buffer = new byte[COPY_BUFFER_SIZE];
            int length;
            long totalBytes = 0;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }
            outputStream.flush();
            Log.d(TAG, "Copied " + totalBytes + " bytes from URI to cache: " + outFile.getName());
            return outFile;
        } catch (IOException exception) {
            Log.e(TAG, "copyUriToCache failed: " + exception.getMessage());
            return null;
        } finally {
            closeQuietly(inputStream);
            closeQuietly(outputStream);
        }
    }

    /**
     * Safely deletes a file, logging any errors.
     *
     * @param file The file to delete (can be null)
     */
    private static void deleteFileSafely(@Nullable final File file) {
        if (file != null && file.exists()) {
            try {
                final boolean deleted = file.delete();
                Log.d(TAG, "Deleted " + file.getName() + ": " + deleted);
            } catch (SecurityException exception) {
                Log.w(TAG, "delete failed for " + file.getName() + ": " + exception.getMessage());
            }
        }
    }

    /**
     * Closes a Closeable quietly, ignoring any exceptions.
     *
     * @param closeable The Closeable to close (can be null)
     */
    private static void closeQuietly(@Nullable final java.io.Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException exception) {
                // Ignore
            }
        }
    }
}