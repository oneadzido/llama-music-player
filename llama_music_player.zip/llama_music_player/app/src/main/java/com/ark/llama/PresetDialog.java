// PresetDialog.java
package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Presents the equalizer presets in a scrollable list and reports the
 * user's selection through {@link OnPresetSelectedListener}.
 *
 * <p>The dialog shows every preset in a scrollable list, marks the
 * current one with a "CURRENT" indicator, and scrolls the current
 * preset into the vertical center of the list when the dialog opens.
 * Each row uses a pressed highlight for touch feedback and a
 * debounced tap handler so a rapid double tap selects only once. After
 * a selection, the dialog animates the tapped row and then notifies the
 * listener before dismissing itself.</p>
 *
 * <h3>Top Bar Geometry</h3>
 * <p>The top bar is a horizontal {@link LinearLayout}. The Cancel
 * button sits at the start with its natural width, the title takes the
 * leftover width with a weight of 1, and a trailing placeholder
 * reserves no width. The title is the only element that can yield, so
 * a long Cancel label and a long title truncate rather than overlap.
 * The geometry matches every other dialog's top bar.</p>
 *
 * <h3>Localization</h3>
 * <p>Every visible label resolves from a string resource. The preset
 * names themselves are supplied by the caller, from
 * {@link EqualizerManager#getPresetNames()}, and are proper names that
 * are not translated. The dialog's own chrome — the title, the header,
 * the count, the current indicator, the cancel button — reads from
 * {@code R.string} and {@code R.plurals}.</p>
 *
 * <h3>Theme Application</h3>
 * <p>This dialog does not react to {@code THEME_COLOR_CHANGED}. It is
 * hosted by {@link EqualizerActivity}, whose recreation dismisses
 * the dialog; the next open constructs a new {@code PresetDialog}
 * against the new theme.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. Delayed work is scheduled on
 * {@link #mMainHandler}.</p>
 *
 * @see ThemeManager
 * @see ThemeHelper
 * @see EqualizerManager
 *
 * @author Richard Korbla Adzido
 * @version 1.6.2
 * @since 1.0.0
 */
public class PresetDialog extends Dialog {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PresetDialog";

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Header background color, slightly lighter than the main background. */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";

    /** Background color of the currently selected preset row. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";

    /** Touch highlight color applied to a pressed list row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for headers and secondary text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Delay before dismissing the dialog after a selection, in milliseconds. */
    private static final long DISMISS_DELAY_MS = 500L;

    /** Duration of button press and selection animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Height of the top action bar, in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of the header bar, in density-independent pixels. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;

    /** Height of action buttons, in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Standard padding for the top bar, in density-independent pixels. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Horizontal padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;

    /** Horizontal padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_VERTICAL_DP = 12;

    /** Padding around the "CURRENT" indicator text, in density-independent pixels. */
    private static final int INDICATOR_PADDING_DP = 8;

    /** Bottom padding of the dialog, in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 8;

    /** Thickness of dividers between rows, in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;

    /**
     * Start margin applied to the preset count, in dp.
     *
     * <p>This is the gap between the list header and the count.</p>
     */
    private static final int HEADER_COUNT_MARGIN_START_DP = 8;

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Context used to resolve resources and construct views. */
    private final Context mContext;

    /** Names of the presets displayed in the list. */
    private final String[] mPresetNames;

    /** Index of the preset currently applied. */
    private final int mCurrentPreset;

    /** Listener notified when a preset is selected, or null. */
    @Nullable
    private final OnPresetSelectedListener mListener;

    /** Scroll view that contains the preset list. */
    private ScrollView mScrollView;

    /** Container that holds every preset row. */
    private LinearLayout mPresetList;

    /** Manager that supplies the current theme color. */
    private final ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    private final ThemeHelper mThemeHelper;

    /** Timestamp of the last selection, used for debouncing. */
    private long mLastSelectionTime = 0L;

    /** Timestamp of the last cancel click, used for debouncing. */
    private long mLastCancelClickTime = 0L;

    /** Handler for delayed tasks on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ============================================================================
    // Listener Interface
    // ============================================================================

    /**
     * Receives preset selection events.
     */
    public interface OnPresetSelectedListener {

        /**
         * Called when the user selects a preset.
         *
         * @param presetIndex Index of the selected preset in the presets
         *        array
         * @param presetName Name of the selected preset
         */
        void onPresetSelected(int presetIndex, @NonNull String presetName);
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the dialog.
     *
     * @param context Context used to resolve resources and construct
     *        views
     * @param presetNames Preset names displayed in the list
     * @param currentPreset Index of the preset currently applied
     * @param listener Listener notified when a preset is selected, or
     *        null
     */
    public PresetDialog(@NonNull Context context, @NonNull String[] presetNames,
                        int currentPreset, @Nullable OnPresetSelectedListener listener) {
        super(context,
            android.R.style.Theme_Black_NoTitleBar);
        mContext = LanguageManager.getInstance(context).wrap(context);
        mPresetNames = presetNames;
        mCurrentPreset = currentPreset;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ============================================================================
    // Dialog Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the dialog's window, content view, and preset list.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());

        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }

        scrollToCurrentPreset();
        applyThemeToButtons();
    }

    /**
     * Dismisses the dialog and removes every pending handler callback.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    /** Returns a context that resolves resources using the currently selected app language. */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext).getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context", exception);
            return mContext;
        }
    }

    // ============================================================================
    // Window Configuration Methods
    // ============================================================================

    /**
     * Configures the dialog window for full-screen display.
     *
     * @param window Window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }

        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PresetDialogAnimation);
    }

    // ============================================================================
    // Theme Management Methods
    // ============================================================================

    /**
     * Applies the current theme color to every button in the dialog.
     */
    private void applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            findAndThemeButtons((ViewGroup) rootView);
        }
        forceRedraw();
    }

    /**
     * Recursively applies the current theme to every button in the given
     * view hierarchy.
     *
     * @param group View group to traverse
     */
    private void findAndThemeButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                findAndThemeButtons((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the selection styling to the given preset row and clears
     * the styling from every other row.
     *
     * @param newSelectedIndex Index of the newly selected preset
     */
    private void updateSelectedPreset(int newSelectedIndex) {
        int themeColorInt = mThemeManager.getCurrentColorInt();

        for (int index = 0; index < mPresetList.getChildCount(); index++) {
            View child = mPresetList.getChildAt(index);

            if (child instanceof LinearLayout) {
                LinearLayout item = (LinearLayout) child;
                if (item.getTag() instanceof Integer) {
                    int presetIndex = (Integer) item.getTag();
                    boolean isSelected = (presetIndex == newSelectedIndex);

                    item.setBackgroundColor(isSelected
                        ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                        : Color.TRANSPARENT);

                    if (item.getChildCount() > 0) {
                        TextView name = (TextView) item.getChildAt(0);
                        if (name != null) {
                            name.setTextColor(isSelected
                                ? themeColorInt
                                : Color.parseColor(TEXT_COLOR_LIGHT));
                        }
                    }

                    if (item.getChildCount() > 1) {
                        TextView indicator = (TextView) item.getChildAt(1);
                        if (indicator != null) {
                            if (isSelected) {
                                indicator.setText(
                                    getLocaleContext().getString(
                                        R.string.preset_dialog_current));
                                indicator.setTextSize(12);
                                indicator.setLetterSpacing(0.1f);
                                indicator.setTextColor(themeColorInt);
                                indicator.setVisibility(View.VISIBLE);
                            } else {
                                indicator.setVisibility(View.GONE);
                            }
                        }
                    }
                }
            }
        }
    }

    // ============================================================================
    // Animation Methods
    // ============================================================================

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Applies the selection styling, plays a bounce animation on the
     * given row, then notifies the listener and dismisses the dialog.
     *
     * @param view Selected preset row
     * @param presetIndex Index of the selected preset
     * @param presetName Name of the selected preset
     */
    private void animatePresetSelection(@NonNull final View view, final int presetIndex,
                                        @NonNull final String presetName) {
        updateSelectedPreset(presetIndex);

        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                      .scaleY(ANIMATION_SCALE_DOWN)
                      .setDuration(ANIMATION_DURATION_MS)
                      .withEndAction(new Runnable() {
                          @Override
                          public void run() {
                              view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                            .scaleY(ANIMATION_SCALE_NORMAL)
                                            .setDuration(ANIMATION_DURATION_MS)
                                            .start();
                          }
                      })
                      .start();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    mListener.onPresetSelected(presetIndex, presetName);
                }
                dismiss();
            }
        }, DISMISS_DELAY_MS);
    }

    // ============================================================================
    // Scrolling Methods
    // ============================================================================

    /**
     * Scrolls the list so the current preset appears in the vertical
     * center of the scroll view.
     */
    private void scrollToCurrentPreset() {
        if (mScrollView == null || mPresetList == null || mCurrentPreset < 0) {
            return;
        }

        mScrollView.post(new Runnable() {
            @Override
            public void run() {
                int targetIndex = findPresetIndex();
                if (targetIndex >= 0) {
                    final View target = mPresetList.getChildAt(targetIndex);
                    if (target != null) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int scrollViewHeight = mScrollView.getHeight();
                                int targetTop = target.getTop();
                                int targetHeight = target.getHeight();
                                int scrollY = targetTop
                                    - (scrollViewHeight / 2) + (targetHeight / 2);
                                mScrollView.smoothScrollTo(0, Math.max(0, scrollY));
                            }
                        }, 0);
                    }
                }
            }
        });
    }

    /**
     * Returns the index of the current preset within the list view.
     *
     * @return Index of the current preset in the list, or -1 when it is
     *         not present
     */
    private int findPresetIndex() {
        for (int index = 0; index < mPresetList.getChildCount(); index++) {
            View child = mPresetList.getChildAt(index);
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                if ((Integer) child.getTag() == mCurrentPreset) {
                    return index;
                }
            }
        }
        return -1;
    }

    // ============================================================================
    // UI Construction Methods
    // ============================================================================

    /**
     * Creates the root content view of the dialog.
     *
     * @return The root view
     */
    @NonNull
    private View createContentView() {
        LinearLayout main = new LinearLayout(mContext);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[] {20, 20, 20, 20, 0, 0, 0, 0});
        main.setBackground(background);

        main.addView(createTopBar());
        main.addView(createHeader());
        main.addView(createScrollableList());
        main.addView(createBottomPadding());

        return main;
    }

    /**
     * Creates the top action bar.
     *
     * <p>A horizontal {@link LinearLayout}: the Cancel button at the
     * start with its natural width, the title in the middle with a
     * weight of 1, and an invisible trailing Themes-width spacer.
     * The title is the only element that can yield, so a long Cancel
     * label — Dutch {@code ANNULEREN}, German {@code ABBRECHEN} — and
     * a long title — Dutch {@code VOORINSTELLINGEN}, German
     * {@code VOREINSTELLUNGEN} — cannot overlap. The title takes the
     * leftover width and truncates if that is not enough.</p>
     *
     * @return The top bar layout
     */
    @NonNull
    private LinearLayout createTopBar() {
        LinearLayout topBar = new LinearLayout(mContext);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createPlaceholder());

        return topBar;
    }

    /**
     * Creates the Cancel button.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText(getLocaleContext().getString(R.string.action_cancel));
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3),
            dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);
        button.setSingleLine(true);
        button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        button.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });

        animateButton(button);
        return button;
    }

    /**
     * Creates the title text.
     *
     * <p>Takes the leftover width between the two edge slots with a
     * weight of 1, so a long translation truncates rather than
     * overlaps. Centred within the space it occupies. The 8dp gutter
     * between the title and each edge button is a logical start/end
     * margin on the layout params, so it sits outside the title's
     * text bounds and mirrors with the layout direction.</p>
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(getLocaleContext());
        textView.setText(getLocaleContext().getString(R.string.preset_dialog_title));
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);
        textView.setSingleLine(true);
        textView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textView.setPadding(0, 0, 0, 0);
        final LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(
                0, dpToPx(BUTTON_HEIGHT_DP), 1f);
        params.setMarginStart(dpToPx(8));
        params.setMarginEnd(dpToPx(8));
        textView.setLayoutParams(params);

        return textView;
    }

    /**
     * Creates an invisible trailing spacer matching the localized Themes button width.
     *
     * @return The width-reserving spacer
     */
    @NonNull
    private View createPlaceholder() {
        // Match the localized Themes action's measured width so the title
        // stays centered exactly like CreditsDialog, without adding an action.
        Button placeholder = new Button(mContext);
        placeholder.setText(getLocaleContext().getString(R.string.action_themes));
        placeholder.setTextSize(14);
        placeholder.setLetterSpacing(0.1f);
        placeholder.setBackgroundResource(R.drawable.button_border_selector);
        placeholder.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        placeholder.setMinHeight(0);
        placeholder.setMinWidth(0);
        placeholder.setIncludeFontPadding(false);
        placeholder.setSingleLine(true);
        placeholder.setEllipsize(android.text.TextUtils.TruncateAt.END);
        placeholder.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));
        placeholder.setVisibility(View.INVISIBLE);
        placeholder.setEnabled(false);
        placeholder.setFocusable(false);
        return placeholder;
    }

    /**
     * Creates the header bar showing the list label and the preset count.
     *
     * <p>The count carries an 8dp start margin, which supplies the
     * gap between the list header and the count.</p>
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP),
            dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));

        TextView headerTitle = new TextView(mContext);
        headerTitle.setText(getLocaleContext().getString(R.string.preset_dialog_list_header));
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setSingleLine(true);
        headerTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView headerCount = new TextView(mContext);
        headerCount.setText(getLocaleContext().getResources().getQuantityString(
            R.plurals.preset_dialog_count,
            mPresetNames.length,
            mPresetNames.length));
        headerCount.setTextSize(12);
        headerCount.setLetterSpacing(0.1f);
        headerCount.setSingleLine(true);
        headerCount.setEllipsize(android.text.TextUtils.TruncateAt.END);
        headerCount.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        final LinearLayout.LayoutParams countParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        countParams.setMarginStart(
            dpToPx(HEADER_COUNT_MARGIN_START_DP));
        headerCount.setLayoutParams(countParams);

        header.addView(headerTitle);
        header.addView(headerCount);

        return header;
    }

    /**
     * Creates the scrollable list that contains every preset row.
     *
     * @return The scroll view containing the preset list
     */
    @NonNull
    private ScrollView createScrollableList() {
        mScrollView = new ScrollView(mContext);
        mScrollView.setVerticalScrollBarEnabled(false);
        mScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        mScrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        mPresetList = new LinearLayout(mContext);
        mPresetList.setOrientation(LinearLayout.VERTICAL);
        mPresetList.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        for (int presetIndex = 0; presetIndex < mPresetNames.length; presetIndex++) {
            final int index = presetIndex;
            final String name = mPresetNames[presetIndex];
            final boolean selected = (presetIndex == mCurrentPreset);

            final LinearLayout item = createPresetItem(index, name, selected);
            mPresetList.addView(item);

            if (presetIndex < mPresetNames.length - 1) {
                mPresetList.addView(createDivider());
            }
        }

        mScrollView.addView(mPresetList);
        return mScrollView;
    }

    /**
     * Creates a single preset row with a name and a current indicator.
     *
     * @param presetIndex Index of the preset in the presets array
     * @param name Display name of the preset
     * @param selected True when this preset is the current one
     * @return The preset row layout
     */
    @NonNull
    private LinearLayout createPresetItem(final int presetIndex,
                                          @NonNull final String name,
                                          final boolean selected) {
        final LinearLayout item = new LinearLayout(mContext);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setPaddingRelative(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP),
            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        item.setTag(presetIndex);
        item.setBackgroundColor(selected
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
            : Color.TRANSPARENT);

        item.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setBackgroundColor(selected
                            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                            : Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        TextView nameView = new TextView(mContext);
        nameView.setText(name);
        nameView.setTextSize(14);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setTextColor(selected
            ? mThemeManager.getCurrentColorInt()
            : Color.parseColor(TEXT_COLOR_LIGHT));
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView indicator = new TextView(mContext);
        if (selected) {
            indicator.setText(getLocaleContext().getString(R.string.preset_dialog_current));
            indicator.setTextSize(12);
            indicator.setLetterSpacing(0.1f);
            indicator.setTextColor(mThemeManager.getCurrentColorInt());
            indicator.setVisibility(View.VISIBLE);
        } else {
            indicator.setVisibility(View.GONE);
        }

        // A single logical start margin. The gap between the preset
        // name and the CURRENT indicator is inter-sibling spacing
        // inside a horizontal LinearLayout, which is a margin rather
        // than the TextView's own padding. The trailing inset is
        // supplied by the row's own end padding.
        LinearLayout.LayoutParams indicatorParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        indicatorParams.setMarginStart(dpToPx(INDICATOR_PADDING_DP));
        indicator.setLayoutParams(indicatorParams);

        item.addView(nameView);
        item.addView(indicator);

        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSelectionTime = currentTime;
                    animatePresetSelection(item, presetIndex, name);
                }
            }
        });

        return item;
    }

    /**
     * Creates a divider view that separates two preset rows.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates the bottom padding view.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Forces the dialog content to re-measure, re-layout, and re-draw.
     */
    private void forceRedraw() {
        Window window = getWindow();
        if (window == null) {
            return;
        }
        View root = window.getDecorView().findViewById(
            android.R.id.content);
        if (root == null) {
            return;
        }
        root.requestLayout();
        root.invalidate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation();
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}