package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Dialog for selecting an equalizer preset.
 * 
 * <p>This dialog displays a scrollable list of available equalizer presets.
 * The currently active preset is highlighted with a "CURRENT" indicator.
 * When a user selects a preset, the dialog animates and notifies the listener
 * to apply the preset to the equalizer.</p>
 * 
 * <p>Features:
 * <ul>
 *   <li>Scrollable list of 60 equalizer presets</li>
 *   <li>Visual highlight for the currently selected preset</li>
 *   <li>Smooth scrolling to the current preset on dialog open</li>
 *   <li>Touch feedback animations for list items</li>
 *   <li>Debounced click handling to prevent rapid selections</li>
 *   <li>Theme color integration for consistent styling</li>
 *   <li>Slide-up animation for dialog entrance/exit</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>Dismiss delay uses Handler.postDelayed().
 * All UI operations are on the main thread.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class PresetDialog extends Dialog {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";
    
    /** Header background color (slightly lighter than main background). */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";
    
    /** Background color for the currently selected preset item. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";
    
    /** Highlight color for touch feedback when pressing a list item. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    /** Light gray text color for secondary and header text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Debounce delay for button clicks to prevent rapid multiple presses. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before dialog dismiss after preset selection (allows animation to complete). */
    private static final long DISMISS_DELAY_MS = 500;
    
    /** Duration of button press and selection animations in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Height of the top action bar in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;
    
    /** Height of the header bar (with "PRESET LIST" and count) in dp. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;
    
    /** Height of action buttons in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;
    
    /** Header padding horizontal in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;
    
    /** Header padding vertical in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;
    
    /** List item padding horizontal in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_HORIZONTAL_DP = 16;
    
    /** List item padding vertical in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_VERTICAL_DP = 12;
    
    /** Padding for the "CURRENT" indicator text in dp. */
    private static final int INDICATOR_PADDING_DP = 8;
    
    /** Bottom padding for the dialog in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 8;
    
    /** Thickness of dividers between list items in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for accessing resources and services. */
    private final Context mContext;
    
    /** Array of preset names to display in the list. */
    private final String[] mPresetNames;
    
    /** Index of the currently selected preset. */
    private final int mCurrentPreset;
    
    /** Listener for preset selection events (can be null). */
    @Nullable
    private final OnPresetSelectedListener mListener;
    
    /** ScrollView containing the preset list. */
    private ScrollView mScrollView;
    
    /** LinearLayout containing all preset items. */
    private LinearLayout mPresetList;
    
    /** Theme manager for accessing current theme color. */
    private final ThemeManager mThemeManager;
    
    /** Theme helper for applying theme to UI components. */
    private final ThemeHelper mThemeHelper;
    
    /** Timestamp of the last selection (for debouncing). */
    private long mLastSelectionTime = 0;
    
    /** Timestamp of the last cancel click (for debouncing). */
    private long mLastCancelClickTime = 0;
    
    /** Handler for posting delayed tasks on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for preset selection events.
     */
    public interface OnPresetSelectedListener {
        
        /**
         * Called when a preset is selected from the dialog.
         *
         * @param presetIndex The index of the selected preset in the presets array
         * @param presetName The name of the selected preset
         */
        void onPresetSelected(int presetIndex, @NonNull String presetName);
    }

    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PresetDialog.
     *
     * @param context The application context
     * @param presetNames Array of preset names to display
     * @param currentPreset The index of the currently selected preset
     * @param listener Listener for preset selection events (can be null)
     */
    public PresetDialog(@NonNull Context context, @NonNull String[] presetNames, 
                        int currentPreset, @Nullable OnPresetSelectedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mPresetNames = presetNames;
        mCurrentPreset = currentPreset;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ========================================================================
    // Dialog Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the dialog is being created.
     * Sets up the UI, configures the window, and initializes the preset list.
     *
     * @param savedInstanceState Saved instance state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());
        
        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }
        
        scrollToCurrentPreset();
        applyThemeToButtons();
    }
    
    /**
     * Called when the dialog is dismissed.
     * Cleans up handler callbacks.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Window Configuration Methods
    // ========================================================================
    
    /**
     * Configures the dialog window properties for full-screen display.
     * Sets status bar color, navigation bar color, and window animations.
     *
     * @param window The dialog window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }
        
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PresetDialogAnimation);
    }

    // ========================================================================
    // Theme Management Methods
    // ========================================================================
    
    /**
     * Applies theme colors to all buttons in the dialog.
     * Recursively traverses the view hierarchy to find and theme buttons.
     */
    private void applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            findAndThemeButtons((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively finds and themes all buttons in a view hierarchy.
     *
     * @param group The ViewGroup to process
     */
    private void findAndThemeButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                findAndThemeButtons((ViewGroup) child);
            }
        }
    }

    /**
     * Updates the visual selection state of preset items.
     * Highlights the newly selected preset and clears the previous selection.
     *
     * @param newSelectedIndex The index of the newly selected preset
     */
    private void updateSelectedPreset(int newSelectedIndex) {
        int themeColorInt = mThemeManager.getCurrentColorInt();
        
        for (int index = 0; index < mPresetList.getChildCount(); index++) {
            View child = mPresetList.getChildAt(index);
            
            if (child instanceof LinearLayout) {
                LinearLayout item = (LinearLayout) child;
                if (item.getTag() instanceof Integer) {
                    int presetIndex = (Integer) item.getTag();
                    boolean isSelected = (presetIndex == newSelectedIndex);
                    
                    item.setBackgroundColor(isSelected 
                        ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
                        : Color.TRANSPARENT);
                    
                    if (item.getChildCount() > 0) {
                        TextView name = (TextView) item.getChildAt(0);
                        if (name != null) {
                            name.setTextColor(isSelected ? themeColorInt : Color.parseColor(TEXT_COLOR_LIGHT));
                        }
                    }
                    
                    if (item.getChildCount() > 1) {
                        TextView indicator = (TextView) item.getChildAt(1);
                        if (indicator != null) {
                            if (isSelected) {
                                indicator.setText("CURRENT");
                                indicator.setTextColor(themeColorInt);
                            } else {
                                indicator.setText("");
                            }
                        }
                    }
                }
            }
        }
    }

    // ========================================================================
    // Animation Methods
    // ========================================================================
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% on touch and returns to normal on release.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Animates the preset selection and dismisses the dialog.
     * Plays a bounce animation on the selected item, then notifies the listener.
     *
     * @param view The selected preset item view
     * @param presetIndex The index of the selected preset
     * @param presetName The name of the selected preset
     */
    private void animatePresetSelection(@NonNull final View view, final int presetIndex, 
                                        @NonNull final String presetName) {
        updateSelectedPreset(presetIndex);
        
        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                      .scaleY(ANIMATION_SCALE_DOWN)
                      .setDuration(ANIMATION_DURATION_MS)
                      .withEndAction(new Runnable() {
                          @Override
                          public void run() {
                              view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                            .scaleY(ANIMATION_SCALE_NORMAL)
                                            .setDuration(ANIMATION_DURATION_MS)
                                            .start();
                          }
                      })
                      .start();
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    mListener.onPresetSelected(presetIndex, presetName);
                }
                dismiss();
            }
        }, DISMISS_DELAY_MS);
    }

    // ========================================================================
    // Scrolling Methods
    // ========================================================================
    
    /**
     * Scrolls the list to show the currently selected preset.
     * Centers the selected preset vertically within the ScrollView.
     */
    private void scrollToCurrentPreset() {
        if (mScrollView == null || mPresetList == null || mCurrentPreset < 0) return;
        
        mScrollView.post(new Runnable() {
            @Override
            public void run() {
                int targetIndex = findPresetIndex();
                if (targetIndex >= 0) {
                    final View target = mPresetList.getChildAt(targetIndex);
                    if (target != null) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int scrollViewHeight = mScrollView.getHeight();
                                int targetTop = target.getTop();
                                int targetHeight = target.getHeight();
                                int scrollY = targetTop - (scrollViewHeight / 2) + (targetHeight / 2);
                                mScrollView.smoothScrollTo(0, Math.max(0, scrollY));
                            }
                        }, 0);
                    }
                }
            }
        });
    }

    /**
     * Finds the index of the currently selected preset in the list view.
     *
     * @return The index in the list, or -1 if not found
     */
    private int findPresetIndex() {
        for (int index = 0; index < mPresetList.getChildCount(); index++) {
            View child = mPresetList.getChildAt(index);
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                if ((Integer) child.getTag() == mCurrentPreset) {
                    return index;
                }
            }
        }
        return -1;
    }

    // ========================================================================
    // UI Construction Methods
    // ========================================================================
    
    /**
     * Creates the main content view for the dialog.
     * Builds the complete dialog layout programmatically.
     *
     * @return The root view of the dialog
     */
    @NonNull
    private View createContentView() {
        LinearLayout main = new LinearLayout(mContext);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[]{20, 20, 20, 20, 0, 0, 0, 0});
        main.setBackground(background);
        
        main.addView(createTopBar());
        main.addView(createHeader());
        main.addView(createScrollableList());
        main.addView(createBottomPadding());
        
        return main;
    }

    /**
     * Creates the top action bar with Cancel button and title.
     *
     * @return The top bar RelativeLayout
     */
    @NonNull
    private RelativeLayout createTopBar() {
        RelativeLayout topBar = new RelativeLayout(mContext);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP), 
            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createPlaceholder());
        
        return topBar;
    }

    /**
     * Creates the Cancel button for closing the dialog.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText("CANCEL");
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3), 
            dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);
        
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.ALIGN_PARENT_START);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        button.setLayoutParams(params);
        
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });
        
        animateButton(button);
        return button;
    }

    /**
     * Creates the title text view for the top bar.
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(mContext);
        textView.setText("PRESETS");
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);
        
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        textView.setLayoutParams(params);
        
        return textView;
    }

    /**
     * Creates a placeholder view for layout balance on the right side.
     *
     * @return The placeholder view
     */
    @NonNull
    private View createPlaceholder() {
        View placeholder = new View(mContext);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_END);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        placeholder.setLayoutParams(params);
        return placeholder;
    }

    /**
     * Creates the header bar showing "PRESET LIST" and preset count.
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP), 
            dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        
        TextView headerTitle = new TextView(mContext);
        headerTitle.setText("PRESET LIST");
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        
        TextView headerCount = new TextView(mContext);
        headerCount.setText(mPresetNames.length + " presets");
        headerCount.setTextSize(12);
        headerCount.setLetterSpacing(0.1f);
        headerCount.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        
        header.addView(headerTitle);
        header.addView(headerCount);
        
        return header;
    }

    /**
     * Creates the scrollable preset list container.
     *
     * @return The ScrollView containing all preset items
     */
    @NonNull
    private ScrollView createScrollableList() {
        mScrollView = new ScrollView(mContext);
        mScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        mScrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        mPresetList = new LinearLayout(mContext);
        mPresetList.setOrientation(LinearLayout.VERTICAL);
        mPresetList.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        for (int presetIndex = 0; presetIndex < mPresetNames.length; presetIndex++) {
            final int index = presetIndex;
            final String name = mPresetNames[presetIndex];
            final boolean selected = (presetIndex == mCurrentPreset);
            
            final LinearLayout item = createPresetItem(index, name, selected);
            mPresetList.addView(item);
            
            if (presetIndex < mPresetNames.length - 1) {
                mPresetList.addView(createDivider());
            }
        }
        
        mScrollView.addView(mPresetList);
        return mScrollView;
    }

    /**
     * Creates a single preset item for the list.
     *
     * @param presetIndex The preset index in the presets array
     * @param name The display name of the preset
     * @param selected True if this preset is currently selected
     * @return The preset item layout
     */
    @NonNull
    private LinearLayout createPresetItem(final int presetIndex, @NonNull final String name, 
                                           final boolean selected) {
        final LinearLayout item = new LinearLayout(mContext);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setPadding(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP), 
            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        item.setTag(presetIndex);
        item.setBackgroundColor(selected 
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
            : Color.TRANSPARENT);
        
        item.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setBackgroundColor(selected 
                            ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
                            : Color.TRANSPARENT);
                        break;
                }
                return false;
            }
        });
        
        TextView nameView = new TextView(mContext);
        nameView.setText(name);
        nameView.setTextSize(14);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setTextColor(selected 
            ? mThemeManager.getCurrentColorInt() 
            : Color.parseColor(TEXT_COLOR_LIGHT));
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        
        TextView indicator = new TextView(mContext);
        if (selected) {
            indicator.setText("CURRENT");
            indicator.setTextSize(10);
            indicator.setLetterSpacing(0.1f);
            indicator.setTextColor(mThemeManager.getCurrentColorInt());
            indicator.setPadding(dpToPx(INDICATOR_PADDING_DP), 0, 0, 0);
        }
        indicator.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        item.addView(nameView);
        item.addView(indicator);
        
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSelectionTime = currentTime;
                    animatePresetSelection(item, presetIndex, name);
                }
            }
        });
        
        return item;
    }

    /**
     * Creates a divider view to separate list items.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates bottom padding to ensure comfortable scrolling at the end of the list.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}