package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.EnumSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Centralized controller for managing button states across all activities.
 * 
 * <p>This controller tracks active operations and manages which button groups
 * should be disabled. It does NOT persist state to SharedPreferences - on app
 * restart, all buttons start enabled. This is the single source of truth for
 * button states during playlist synchronization.</p>
 * 
 * <p><b>Button Groups:</b></p>
 * <ul>
 *   <li>{@link ButtonGroup#DATABASE_ACTIONS} - PLAYLIST, METADATA buttons (MusicPlayer)</li>
 *   <li>{@link ButtonGroup#FOLDER_ACTIONS} - UPDATE, IMPORT, REMOVE buttons (FolderManager)</li>
 *   <li>{@link ButtonGroup#METADATA_ACTIONS} - MODIFY, UPDATE buttons (MetadataEditor)</li>
 * </ul>
 * 
 * <p><b>Note:</b> The MANAGER button in MusicPlayer is NOT controlled by this
 * system. It remains enabled during sync so users can view progress in
 * FolderManager, but destructive actions there are disabled via FOLDER_ACTIONS.</p>
 * 
 * <h3>Watchdog Protection (Like ToastManager)</h3>
 * <p>Each operation has a watchdog timer. If an operation's endOperation()
 * is not called within OPERATION_WATCHDOG_TIMEOUT_MS (30 seconds), the operation
 * will be forcibly ended to prevent buttons from staying disabled indefinitely.
 * This provides a safety net for unhandled exceptions or bugs that would
 * otherwise leave the UI in a disabled state.</p>
 * 
 * <p>The watchdog system includes:</p>
 * <ul>
 *   <li><b>Per-operation tracking</b> - Each operation has its own watchdog</li>
 *   <li><b>Automatic recovery</b> - Stuck operations are automatically ended</li>
 *   <li><b>Graceful cleanup</b> - Watchdogs are cancelled on successful completion</li>
 *   <li><b>Force reset capability</b> - All operations can be reset at once</li>
 *   <li><b>Periodic checker</b> - Runs every 5 seconds to catch stuck operations</li>
 *   <li><b>Heartbeat mechanism</b> - Long operations can send heartbeats to keep watchdog alive</li>
 *   <li><b>Absolute timeout</b> - Operations cannot exceed MAX_OPERATION_DURATION_MS (2 minutes)</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All operations are thread-safe using ConcurrentHashMap and CopyOnWriteArrayList.
 * Watchdog operations are protected by a dedicated lock. All delays use Handler.postDelayed().</p>
 * 
 * <p><b>Usage Example:</b></p>
 * <pre>
 * // Start a playlist sync operation
 * NavigationController.getInstance().beginPlaylistSync();
 * 
 * // Send heartbeat during long operation
 * NavigationController.getInstance().heartbeat(Operation.PLAYLIST_SYNC);
 * 
 * // End a playlist sync operation
 * NavigationController.getInstance().endPlaylistSync();
 * 
 * // Register as a listener (in Activity.onCreate)
 * NavigationController.getInstance().registerListener(this);
 * 
 * // Unregister as a listener (in Activity.onDestroy)
 * NavigationController.getInstance().unregisterListener(this);
 * 
 * // Implement the listener interface
 * &#64;Override
 * public void onButtonStateChanged(ButtonGroup group, boolean disabled) {
 *     if (group == ButtonGroup.DATABASE_ACTIONS) {
 *         final boolean finalDisabled = disabled;
 *         runOnUiThread(new Runnable() {
 *             &#64;Override
 *             public void run() {
 *                 if (finalDisabled) {
 *                     disableMyButtons();
 *                 } else {
 *                     enableMyButtons();
 *                 }
 *             }
 *         });
 *     }
 * }
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NavigationController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "NavigationController";
    
    /**
     * Timeout in milliseconds for watchdog timer. If an operation's endOperation()
     * is not called within this time, the operation will be forcibly ended to
     * prevent buttons from staying disabled indefinitely. Value: 30 seconds.
     */
    private static final long OPERATION_WATCHDOG_TIMEOUT_MS = 30000;
    
    /**
     * Absolute maximum duration for any operation (2 minutes).
     * Even with heartbeats, operations will be forcibly ended after this time.
     */
    private static final long MAX_OPERATION_DURATION_MS = 120000;
    
    /**
     * Watchdog check interval in milliseconds. The watchdog checks for stuck
     * operations at this interval. Value: 5 seconds.
     */
    private static final long WATCHDOG_CHECK_INTERVAL_MS = 5000;
    
    /**
     * Heartbeat timeout - if no heartbeat received within this time,
     * the operation is considered stale and will be terminated.
     */
    private static final long HEARTBEAT_TIMEOUT_MS = 45000;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Button groups that can be independently disabled.
     * 
     * <p>Each group represents a set of buttons that should be disabled
     * together during specific operations.</p>
     */
    public enum ButtonGroup {
        
        /**
         * PLAYLIST and METADATA buttons in MusicPlayer.
         * The MANAGER button is excluded from this group.
         */
        DATABASE_ACTIONS,
        
        /**
         * UPDATE, IMPORT, and REMOVE (X) buttons in FolderManager.
         * These buttons modify the folder list and playlist.
         */
        FOLDER_ACTIONS,
        
        /**
         * MODIFY and UPDATE buttons in MetadataEditor.
         * These buttons modify audio file metadata.
         */
        METADATA_ACTIONS
    }
    
    /**
     * Operation types that affect button groups.
     * 
     * <p>Each operation defines which button groups should be disabled
     * while the operation is in progress.</p>
     */
    public enum Operation {
        
        /**
         * Playlist synchronization operation.
         * Affects DATABASE_ACTIONS and FOLDER_ACTIONS button groups.
         */
        PLAYLIST_SYNC(EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS)),
        
        /**
         * Metadata save operation.
         * Affects METADATA_ACTIONS button group.
         */
        METADATA_SAVE(EnumSet.of(ButtonGroup.METADATA_ACTIONS)),
        
        /**
         * Folder management operation (add/remove folders).
         * Affects FOLDER_ACTIONS button group.
         */
        FOLDER_UPDATE(EnumSet.of(ButtonGroup.FOLDER_ACTIONS));
        
        /** The button groups affected by this operation. */
        private final EnumSet<ButtonGroup> mAffectedGroups;
        
        /**
         * Constructs an Operation with the specified affected button groups.
         *
         * @param affectedGroups The button groups affected by this operation
         */
        Operation(EnumSet<ButtonGroup> affectedGroups) {
            this.mAffectedGroups = affectedGroups;
        }
        
        /**
         * Returns the button groups affected by this operation.
         *
         * @return The affected button groups
         */
        @NonNull
        public EnumSet<ButtonGroup> getAffectedGroups() {
            return mAffectedGroups;
        }
    }
    
    /**
     * Listener interface for button state changes.
     * 
     * <p>Activities that have buttons controlled by this manager should
     * implement this interface and register as listeners.</p>
     */
    public interface ButtonStateListener {
        
        /**
         * Called when a button group's disabled state changes.
         *
         * @param group The button group that changed
         * @param disabled True if buttons in this group should be disabled,
         *                 false if they should be enabled
         */
        void onButtonStateChanged(@NonNull ButtonGroup group, boolean disabled);
    }
    
    /**
     * Tracks an active operation with its watchdog information.
     */
    private static class OperationWatchdog {
        
        /** The operation being tracked. */
        final Operation operation;
        
        /** Timestamp when the operation started. */
        final long startTime;
        
        /** Last heartbeat timestamp. */
        long lastHeartbeatTime;
        
        /** Handler for the watchdog timer. */
        final Handler handler;
        
        /** Runnable that ends the operation on timeout. */
        final Runnable timeoutRunnable;
        
        /** Flag indicating if the watchdog has been cancelled. */
        final AtomicBoolean isCancelled = new AtomicBoolean(false);
        
        /**
         * Constructs a new OperationWatchdog.
         *
         * @param operation The operation to track
         * @param handler The handler for posting timeout runnable
         * @param timeoutRunnable The runnable to execute on timeout
         */
        OperationWatchdog(@NonNull Operation operation, @NonNull Handler handler, 
                          @NonNull Runnable timeoutRunnable) {
            this.operation = operation;
            this.startTime = SystemClock.elapsedRealtime();
            this.lastHeartbeatTime = this.startTime;
            this.handler = handler;
            this.timeoutRunnable = timeoutRunnable;
        }
        
        /**
         * Sends a heartbeat for this operation, resetting the watchdog timer.
         */
        void heartbeat() {
            lastHeartbeatTime = SystemClock.elapsedRealtime();
        }
        
        /**
         * Returns the age of this operation in milliseconds.
         *
         * @return Age in milliseconds
         */
        long getAgeMs() {
            return SystemClock.elapsedRealtime() - startTime;
        }
        
        /**
         * Returns the time since last heartbeat in milliseconds.
         *
         * @return Time since last heartbeat
         */
        long getTimeSinceHeartbeat() {
            return SystemClock.elapsedRealtime() - lastHeartbeatTime;
        }
        
        /**
         * Cancels the watchdog timer.
         */
        void cancel() {
            isCancelled.set(true);
            handler.removeCallbacks(timeoutRunnable);
        }
    }
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static NavigationController sInstance;
    
    /** Handler for main thread operations. */
    @NonNull
    private final Handler mMainHandler;
    
    /** Handler for watchdog operations. */
    @NonNull
    private final Handler mWatchdogHandler;
    
    /** Periodic watchdog checker runnable. */
    @Nullable
    private Runnable mWatchdogCheckerRunnable;
    
    /** Flag indicating if the periodic watchdog is running. */
    private final AtomicBoolean mWatchdogRunning = new AtomicBoolean(false);
    
    /** Lock for watchdog operations. */
    private final Object mWatchdogLock = new Object();
    
    /**
     * Private constructor for singleton pattern.
     * No persistence is loaded - all buttons start enabled.
     */
    private NavigationController() {
        mMainHandler = new Handler(Looper.getMainLooper());
        mWatchdogHandler = new Handler(Looper.getMainLooper());
    }
    
    /**
     * Returns the singleton instance of NavigationController.
     * No context parameter is needed as there is no persistence.
     *
     * @return The singleton instance
     */
    @NonNull
    public static synchronized NavigationController getInstance() {
        if (sInstance == null) {
            sInstance = new NavigationController();
        }
        return sInstance;
    }
    
    // ========================================================================
    // Operation Tracking
    // ========================================================================
    
    /** Count of active operations for each button group. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, AtomicInteger> mGroupOperationCounts = 
        new ConcurrentHashMap<ButtonGroup, AtomicInteger>();
    
    /** Current disabled state for each button group (cached for performance). */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Boolean> mGroupDisabledState = 
        new ConcurrentHashMap<ButtonGroup, Boolean>();
    
    /** Registered listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ButtonStateListener> mListeners = 
        new CopyOnWriteArrayList<ButtonStateListener>();
    
    /** Active operation watchdogs. */
    @NonNull
    private final ConcurrentHashMap<Operation, OperationWatchdog> mActiveOperations = 
        new ConcurrentHashMap<Operation, OperationWatchdog>();
    
    // ========================================================================
    // Watchdog Management (Thread-Safe with Lock)
    // ========================================================================
    
    /**
     * Starts the periodic watchdog checker.
     * This ensures that even if an operation's individual watchdog fails,
     * the periodic checker will catch and clean up stuck operations.
     */
    private void startPeriodicWatchdog() {
        if (mWatchdogRunning.getAndSet(true)) {
            return;
        }
        
        mWatchdogCheckerRunnable = new Runnable() {
            @Override
            public void run() {
                checkStuckOperations();
                if (mWatchdogRunning.get() && mWatchdogCheckerRunnable != null) {
                    mWatchdogHandler.postDelayed(this, WATCHDOG_CHECK_INTERVAL_MS);
                }
            }
        };
        
        mWatchdogHandler.postDelayed(mWatchdogCheckerRunnable, WATCHDOG_CHECK_INTERVAL_MS);
        android.util.Log.d(TAG, "Periodic watchdog started (interval: " + WATCHDOG_CHECK_INTERVAL_MS + "ms)");
    }
    
    /**
     * Stops the periodic watchdog checker.
     */
    private void stopPeriodicWatchdog() {
        if (!mWatchdogRunning.getAndSet(false)) {
            return;
        }
        
        if (mWatchdogCheckerRunnable != null) {
            mWatchdogHandler.removeCallbacks(mWatchdogCheckerRunnable);
            mWatchdogCheckerRunnable = null;
        }
        android.util.Log.d(TAG, "Periodic watchdog stopped");
    }
    
    /**
     * Checks for stuck operations and forcibly ends them.
     * This is called periodically by the watchdog.
     */
    private void checkStuckOperations() {
        synchronized (mWatchdogLock) {
            boolean hasActiveOperations = !mActiveOperations.isEmpty();
            
            for (OperationWatchdog watchdog : mActiveOperations.values()) {
                if (!watchdog.isCancelled.get()) {
                    long ageMs = watchdog.getAgeMs();
                    long timeSinceHeartbeat = watchdog.getTimeSinceHeartbeat();
                    
                    // Check 1: Absolute maximum duration exceeded
                    if (ageMs > MAX_OPERATION_DURATION_MS) {
                        android.util.Log.w(TAG, "Stuck operation detected: " + watchdog.operation.name() + 
                            " exceeded max duration (age: " + ageMs + "ms), forcing end");
                        endOperation(watchdog.operation);
                    }
                    // Check 2: No heartbeat for too long
                    else if (timeSinceHeartbeat > HEARTBEAT_TIMEOUT_MS) {
                        android.util.Log.w(TAG, "Stuck operation detected: " + watchdog.operation.name() + 
                            " no heartbeat for " + timeSinceHeartbeat + "ms (age: " + ageMs + "ms), forcing end");
                        endOperation(watchdog.operation);
                    }
                    // Check 3: Normal timeout without completion
                    else if (ageMs > OPERATION_WATCHDOG_TIMEOUT_MS) {
                        android.util.Log.w(TAG, "Stuck operation detected: " + watchdog.operation.name() + 
                            " (age: " + ageMs + "ms, heartbeat: " + timeSinceHeartbeat + "ms ago), forcing end");
                        endOperation(watchdog.operation);
                    }
                }
            }
            
            // Stop periodic watchdog if no active operations
            if (!hasActiveOperations && mWatchdogRunning.get()) {
                stopPeriodicWatchdog();
            }
        }
    }
    
    /**
     * Sends a heartbeat for an operation, resetting its watchdog timer.
     * Call this periodically during long-running operations to prevent
     * the watchdog from prematurely terminating them.
     *
     * @param operation The operation to send a heartbeat for
     * @return True if the operation is active and heartbeat was sent
     */
    public boolean heartbeat(@NonNull Operation operation) {
        synchronized (mWatchdogLock) {
            OperationWatchdog watchdog = mActiveOperations.get(operation);
            if (watchdog != null && !watchdog.isCancelled.get()) {
                watchdog.heartbeat();
                android.util.Log.d(TAG, "Heartbeat received for " + operation.name());
                return true;
            }
            return false;
        }
    }
    
    /**
     * Starts a watchdog timer for the specified operation.
     *
     * @param operation The operation to monitor
     */
    private void startWatchdog(@NonNull final Operation operation) {
        synchronized (mWatchdogLock) {
            // Ensure periodic watchdog is running
            startPeriodicWatchdog();
            
            // Cancel any existing watchdog for this operation
            cancelWatchdogLocked(operation);
            
            final Handler handler = new Handler(Looper.getMainLooper());
            final Runnable timeoutRunnable = new Runnable() {
                @Override
                public void run() {
                    synchronized (mWatchdogLock) {
                        OperationWatchdog watchdog = mActiveOperations.get(operation);
                        if (watchdog != null && !watchdog.isCancelled.get()) {
                            long ageMs = watchdog.getAgeMs();
                            long timeSinceHeartbeat = watchdog.getTimeSinceHeartbeat();
                            
                            // Only force end if no heartbeat received recently
                            if (timeSinceHeartbeat > HEARTBEAT_TIMEOUT_MS) {
                                android.util.Log.w(TAG, "Watchdog triggered for " + operation.name() + 
                                    " - no heartbeat for " + timeSinceHeartbeat + "ms, age=" + ageMs + "ms");
                                endOperation(operation);
                            } else if (ageMs > OPERATION_WATCHDOG_TIMEOUT_MS) {
                                android.util.Log.w(TAG, "Watchdog triggered for " + operation.name() + 
                                    " - timeout after " + OPERATION_WATCHDOG_TIMEOUT_MS + "ms, age=" + ageMs + "ms");
                                endOperation(operation);
                            } else {
                                // Reschedule if operation is still active but hasn't timed out yet
                                handler.postDelayed(this, OPERATION_WATCHDOG_TIMEOUT_MS);
                            }
                        }
                    }
                }
            };
            
            OperationWatchdog watchdog = new OperationWatchdog(operation, handler, timeoutRunnable);
            mActiveOperations.put(operation, watchdog);
            handler.postDelayed(timeoutRunnable, OPERATION_WATCHDOG_TIMEOUT_MS);
            
            android.util.Log.d(TAG, "Watchdog started for " + operation.name() + 
                " (timeout: " + OPERATION_WATCHDOG_TIMEOUT_MS + "ms, max: " + MAX_OPERATION_DURATION_MS + "ms)");
        }
    }
    
    /**
     * Cancels the watchdog timer for the specified operation (must be called with lock held).
     *
     * @param operation The operation to stop monitoring
     */
    private void cancelWatchdogLocked(@NonNull Operation operation) {
        OperationWatchdog watchdog = mActiveOperations.remove(operation);
        if (watchdog != null) {
            watchdog.cancel();
            android.util.Log.d(TAG, "Watchdog cancelled for " + operation.name() + 
                " (age: " + watchdog.getAgeMs() + "ms)");
        }
    }
    
    /**
     * Cancels the watchdog timer for the specified operation.
     *
     * @param operation The operation to stop monitoring
     */
    private void cancelWatchdog(@NonNull Operation operation) {
        synchronized (mWatchdogLock) {
            cancelWatchdogLocked(operation);
        }
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Begins an operation. Increments counters for all affected button groups.
     * If a group's counter goes from 0 to 1, that group becomes disabled.
     * 
     * <p><b>Watchdog Protection:</b> A watchdog timer is started for this
     * operation. If endOperation() is not called within OPERATION_WATCHDOG_TIMEOUT_MS,
     * the operation is forcibly ended to prevent buttons from staying disabled
     * indefinitely due to unhandled exceptions or bugs.</p>
     *
     * @param operation The operation to begin
     */
    public void beginOperation(@NonNull final Operation operation) {
        android.util.Log.d(TAG, "beginOperation: " + operation.name());
        
        final EnumSet<ButtonGroup> affectedGroups = operation.getAffectedGroups();
        for (final ButtonGroup group : affectedGroups) {
            final int newCount = incrementGroupCount(group);
            android.util.Log.d(TAG, "  Group " + group.name() + " count = " + newCount);
            
            if (newCount == 1) {
                setGroupDisabled(group, true);
            }
        }
        
        // Start watchdog timer for this operation
        startWatchdog(operation);
    }
    
    /**
     * Ends an operation. Decrements counters for all affected button groups.
     * If a group's counter goes from 1 to 0, that group becomes enabled.
     * 
     * <p>The watchdog timer for this operation is cancelled upon successful
     * completion.</p>
     *
     * @param operation The operation to end
     */
    public void endOperation(@NonNull final Operation operation) {
        android.util.Log.d(TAG, "endOperation: " + operation.name());
        
        synchronized (mWatchdogLock) {
            // Cancel watchdog timer for this operation
            cancelWatchdogLocked(operation);
        }
        
        final EnumSet<ButtonGroup> affectedGroups = operation.getAffectedGroups();
        for (final ButtonGroup group : affectedGroups) {
            final int newCount = decrementGroupCount(group);
            android.util.Log.d(TAG, "  Group " + group.name() + " count = " + newCount);
            
            if (newCount == 0) {
                setGroupDisabled(group, false);
            } else if (newCount < 0) {
                android.util.Log.w(TAG, "Group " + group.name() + " count below zero, resetting");
                mGroupOperationCounts.put(group, new AtomicInteger(0));
                setGroupDisabled(group, false);
            }
        }
        
        // Stop periodic watchdog if no active operations
        if (mActiveOperations.isEmpty()) {
            stopPeriodicWatchdog();
        }
    }
    
    /**
     * Checks if a button group is currently disabled.
     *
     * @param group The button group to check
     * @return True if the group should be disabled
     */
    public boolean isGroupDisabled(@NonNull ButtonGroup group) {
        final Boolean cached = mGroupDisabledState.get(group);
        if (cached != null) {
            return cached;
        }
        return false;
    }
    
    /**
     * Returns the current operation count for a button group.
     *
     * @param group The button group
     * @return The current operation count
     */
    public int getGroupOperationCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        return counter != null ? counter.get() : 0;
    }
    
    /**
     * Returns the number of active operations.
     *
     * @return The number of active operations
     */
    public int getActiveOperationCount() {
        return mActiveOperations.size();
    }
    
    /**
     * Returns whether any operation is currently active.
     *
     * @return True if any operation is active
     */
    public boolean hasActiveOperations() {
        return !mActiveOperations.isEmpty();
    }
    
    /**
     * Returns debug information about active operations.
     * Useful for troubleshooting stuck states.
     *
     * @return A string containing debug information
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("NavigationController Debug Info:\n");
        sb.append("  Active operations: ").append(mActiveOperations.size()).append("\n");
        
        for (OperationWatchdog watchdog : mActiveOperations.values()) {
            sb.append("    - ").append(watchdog.operation.name())
              .append(" (age: ").append(watchdog.getAgeMs()).append("ms")
              .append(", heartbeat: ").append(watchdog.getTimeSinceHeartbeat()).append("ms ago")
              .append(", cancelled: ").append(watchdog.isCancelled.get()).append(")\n");
        }
        
        sb.append("  Group states:\n");
        for (ButtonGroup group : ButtonGroup.values()) {
            int count = getGroupOperationCount(group);
            boolean disabled = isGroupDisabled(group);
            sb.append("    - ").append(group.name())
              .append(": count=").append(count)
              .append(", disabled=").append(disabled).append("\n");
        }
        
        sb.append("  Listeners: ").append(mListeners.size()).append("\n");
        sb.append("  Watchdog running: ").append(mWatchdogRunning.get()).append("\n");
        
        return sb.toString();
    }
    
    // ========================================================================
    // Private State Management Methods
    // ========================================================================
    
    /**
     * Increments the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after increment
     */
    private int incrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            counter = new AtomicInteger(0);
            mGroupOperationCounts.put(group, counter);
        }
        return counter.incrementAndGet();
    }
    
    /**
     * Decrements the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after decrement
     */
    private int decrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            android.util.Log.w(TAG, "No counter found for group: " + group.name());
            return -1;
        }
        return counter.decrementAndGet();
    }
    
    /**
     * Sets the disabled state for a button group and notifies all listeners.
     * State is NOT persisted to SharedPreferences.
     *
     * @param group The button group
     * @param disabled True to disable, false to enable
     */
    private void setGroupDisabled(@NonNull final ButtonGroup group, final boolean disabled) {
        final Boolean current = mGroupDisabledState.get(group);
        if (current != null && current == disabled) {
            return;
        }
        
        mGroupDisabledState.put(group, disabled);
        android.util.Log.d(TAG, "Group " + group.name() + " " + (disabled ? "DISABLED" : "ENABLED"));
        
        notifyListeners(group, disabled);
    }
    
    /**
     * Notifies all registered listeners of a button state change.
     *
     * @param group The button group that changed
     * @param disabled The new disabled state
     */
    private void notifyListeners(final ButtonGroup group, final boolean disabled) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (final ButtonStateListener listener : mListeners) {
                    try {
                        listener.onButtonStateChanged(group, disabled);
                    } catch (Exception e) {
                        android.util.Log.e(TAG, "Error notifying listener", e);
                    }
                }
            }
        });
    }
    
    // ========================================================================
    // Listener Management Methods
    // ========================================================================
    
    /**
     * Registers a listener to receive button state notifications.
     * 
     * <p>The listener will immediately receive the current state for all
     * button groups upon registration.</p>
     *
     * @param listener The listener to register
     */
    public void registerListener(@NonNull final ButtonStateListener listener) {
        if (!mListeners.contains(listener)) {
            mListeners.add(listener);
            
            // Send current state immediately
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    for (final ButtonGroup group : ButtonGroup.values()) {
                        final boolean disabled = isGroupDisabled(group);
                        listener.onButtonStateChanged(group, disabled);
                    }
                }
            });
        }
    }
    
    /**
     * Unregisters a listener.
     *
     * @param listener The listener to unregister
     */
    public void unregisterListener(@NonNull final ButtonStateListener listener) {
        mListeners.remove(listener);
    }
    
    // ========================================================================
    // Convenience Methods for Specific Operations
    // ========================================================================
    
    /**
     * Convenience method to begin a playlist sync operation.
     * 
     * <p>Disables DATABASE_ACTIONS (PLAYLIST, METADATA) and
     * FOLDER_ACTIONS (UPDATE, IMPORT, REMOVE) button groups.</p>
     * 
     * <p>A watchdog timer is started. If endPlaylistSync() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginPlaylistSync() {
        beginOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to end a playlist sync operation.
     * 
     * <p>Re-enables DATABASE_ACTIONS and FOLDER_ACTIONS button groups
     * if no other operations are affecting them.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endPlaylistSync() {
        endOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to begin a metadata save operation.
     * 
     * <p>Disables METADATA_ACTIONS (MODIFY, UPDATE) button group.</p>
     * 
     * <p>A watchdog timer is started. If endMetadataSave() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginMetadataSave() {
        beginOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to end a metadata save operation.
     * 
     * <p>Re-enables METADATA_ACTIONS button group if no other operations
     * are affecting it.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endMetadataSave() {
        endOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to begin a folder update operation.
     * 
     * <p>Disables FOLDER_ACTIONS (UPDATE, IMPORT, REMOVE) button group.</p>
     * 
     * <p>A watchdog timer is started. If endFolderUpdate() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginFolderUpdate() {
        beginOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Convenience method to end a folder update operation.
     * 
     * <p>Re-enables FOLDER_ACTIONS button group if no other operations
     * are affecting it.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endFolderUpdate() {
        endOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Forces end of all active operations and clears all state.
     * 
     * <p>This method should be used as a last resort when operations are stuck.
     * It cancels all watchdog timers, resets all operation counts to zero,
     * re-enables all button groups, and notifies all listeners of the state change.</p>
     * 
     * <p>This is called automatically by the watchdog system but can also be
     * called manually if needed (e.g., on app shutdown or catastrophic error recovery).</p>
     */
    public void forceEndAllOperations() {
        android.util.Log.w(TAG, "forceEndAllOperations - resetting all button states");
        
        synchronized (mWatchdogLock) {
            // Cancel all watchdog timers
            for (Operation op : Operation.values()) {
                cancelWatchdogLocked(op);
            }
            
            // Clear active operations map
            mActiveOperations.clear();
            
            // Stop periodic watchdog
            stopPeriodicWatchdog();
        }
        
        // Reset all operation counts to zero
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupOperationCounts.put(group, new AtomicInteger(0));
            if (isGroupDisabled(group)) {
                setGroupDisabled(group, false);
            }
        }
        
        android.util.Log.d(TAG, "forceEndAllOperations completed - all groups enabled");
    }
    
    /**
     * Resets a specific operation if it appears to be stuck.
     * 
     * @param operation The operation to check and potentially reset
     * @return True if the operation was reset, false if it was not stuck
     */
    public boolean resetStuckOperation(@NonNull Operation operation) {
        synchronized (mWatchdogLock) {
            OperationWatchdog watchdog = mActiveOperations.get(operation);
            if (watchdog != null && !watchdog.isCancelled.get()) {
                long ageMs = watchdog.getAgeMs();
                long timeSinceHeartbeat = watchdog.getTimeSinceHeartbeat();
                
                if (ageMs > MAX_OPERATION_DURATION_MS || timeSinceHeartbeat > HEARTBEAT_TIMEOUT_MS) {
                    android.util.Log.w(TAG, "Manually resetting stuck operation: " + operation.name() +
                        " (age: " + ageMs + "ms, heartbeat: " + timeSinceHeartbeat + "ms ago)");
                    endOperation(operation);
                    return true;
                }
            }
            return false;
        }
    }
}