package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.EnumSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Centralized controller for managing button states across all activities.
 * 
 * <p>This controller tracks active operations and manages which button groups
 * should be disabled. It uses PROGRESS-BASED staleness detection - operations
 * can run for hours as long as they report progress every 5 seconds.</p>
 * 
 * <p><b>Button Groups:</b></p>
 * <ul>
 *   <li>{@link ButtonGroup#DATABASE_ACTIONS} - PLAYLIST, METADATA buttons (MusicPlayer)</li>
 *   <li>{@link ButtonGroup#FOLDER_ACTIONS} - UPDATE, IMPORT, REMOVE buttons (FolderManager)</li>
 *   <li>{@link ButtonGroup#METADATA_ACTIONS} - MODIFY, UPDATE buttons (MetadataEditor)</li>
 * </ul>
 * 
 * <h3>Staleness Detection - Progress Based (No Duration Limit)</h3>
 * <p>Operations are considered "stuck" ONLY when they stop reporting progress.
 * There is NO maximum duration limit - operations can run for hours as long
 * as they send heartbeats or progress updates every 5 seconds.</p>
 * 
 * <ul>
 *   <li><b>5 Second Health Check:</b> Runs every 5 seconds to monitor operations</li>
 *   <li><b>Heartbeat Required:</b> Operations MUST call heartbeat() every 5 seconds</li>
 *   <li><b>Progress Tracking:</b> recordProgress() also resets the inactivity timer</li>
 *   <li><b>No Max Duration:</b> Operations can run indefinitely with activity</li>
 *   <li><b>Automatic Cleanup:</b> Only stuck operations (no activity for 5+ seconds) are terminated</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All operations are thread-safe using ConcurrentHashMap and CopyOnWriteArrayList.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Start a playlist sync operation
 * NavigationController.getInstance().beginPlaylistSync();
 * 
 * // IMPORTANT: Send heartbeat every 5 seconds during long operations
 * NavigationController.getInstance().heartbeat(Operation.PLAYLIST_SYNC);
 * 
 * // Or report progress (also resets inactivity timer)
 * NavigationController.getInstance().recordProgress(Operation.PLAYLIST_SYNC, current, total);
 * 
 * // End when complete
 * NavigationController.getInstance().endPlaylistSync();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NavigationController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "NavigationController";
    
    /** 
     * Health check interval in milliseconds (5 seconds).
     * The health checker runs at this frequency to detect stuck operations.
     */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000;
    
    /** 
     * Stuck detection timeout (5 seconds).
     * If an operation receives NO heartbeat or progress update for 5 seconds,
     * it is considered stuck and will be automatically terminated.
     * 
     * <p>There is NO maximum duration limit - operations can run for hours
     * as long as they send heartbeats every 5 seconds.</p>
     */
    private static final long STUCK_TIMEOUT_MS = 5000;
    
    /** Recovery delay after detecting a stuck operation. */
    private static final long RECOVERY_DELAY_MS = 1000;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Button groups that can be independently disabled.
     */
    public enum ButtonGroup {
        
        /**
         * PLAYLIST and METADATA buttons in MusicPlayer.
         * The MANAGER button is excluded from this group.
         */
        DATABASE_ACTIONS,
        
        /**
         * UPDATE, IMPORT, and REMOVE (X) buttons in FolderManager.
         * These buttons modify the folder list and playlist.
         */
        FOLDER_ACTIONS,
        
        /**
         * MODIFY and UPDATE buttons in MetadataEditor.
         * These buttons modify audio file metadata.
         */
        METADATA_ACTIONS
    }
    
    /**
     * Operation types that affect button groups.
     */
    public enum Operation {
        
        /**
         * Playlist synchronization operation.
         * Affects DATABASE_ACTIONS and FOLDER_ACTIONS button groups.
         */
        PLAYLIST_SYNC(EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS)),
        
        /**
         * Metadata save operation.
         * Affects METADATA_ACTIONS button group.
         */
        METADATA_SAVE(EnumSet.of(ButtonGroup.METADATA_ACTIONS)),
        
        /**
         * Folder management operation (add/remove folders).
         * Affects FOLDER_ACTIONS button group.
         */
        FOLDER_UPDATE(EnumSet.of(ButtonGroup.FOLDER_ACTIONS));
        
        private final EnumSet<ButtonGroup> mAffectedGroups;
        
        Operation(EnumSet<ButtonGroup> affectedGroups) {
            this.mAffectedGroups = affectedGroups;
        }
        
        @NonNull
        public EnumSet<ButtonGroup> getAffectedGroups() {
            return mAffectedGroups;
        }
    }
    
    /**
     * Internal state of the state machine.
     */
    private enum State {
        /** No operation in progress, all buttons enabled. */
        IDLE,
        
        /** A sync operation is in progress, buttons disabled. */
        SYNCING,
        
        /** Sync completed successfully, transitioning to IDLE. */
        COMPLETED,
        
        /** Sync failed, transitioning to RECOVERING. */
        ERROR,
        
        /** Auto-recovery in progress. */
        RECOVERING,
        
        /** Recovery completed, transitioning to IDLE. */
        RECOVERED,
        
        /** Force reset in progress. */
        RESETTING
    }
    
    // ========================================================================
    // Listener Interfaces
    // ========================================================================
    
    /**
     * Listener interface for button state changes.
     */
    public interface ButtonStateListener {
        
        /**
         * Called when a button group's disabled state changes.
         *
         * @param group The button group that changed
         * @param disabled True if buttons in this group should be disabled,
         *                 false if they should be enabled
         */
        void onButtonStateChanged(@NonNull ButtonGroup group, boolean disabled);
    }
    
    /**
     * Extended listener for state changes and stuck detection.
     */
    public interface StateListener extends ButtonStateListener {
        
        /**
         * Called when the state changes.
         *
         * @param oldState Previous state
         * @param newState New state
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);
        
        /**
         * Called when a stuck operation is detected and auto-recovery starts.
         *
         * @param operation The operation that was stuck
         * @param stuckDurationMs How long it was stuck in milliseconds
         */
        void onStuckDetected(@NonNull Operation operation, long stuckDurationMs);
    }
    
    /**
     * Listener for progress updates.
     */
    public interface ProgressListener {
        
        /**
         * Called when progress is reported.
         *
         * @param operation The operation making progress
         * @param current Current progress count
         * @param total Total expected (0 if unknown)
         */
        void onProgress(@NonNull Operation operation, int current, int total);
    }
    
    // ========================================================================
    // Singleton
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static volatile NavigationController sInstance;
    
    /**
     * Returns the singleton instance of NavigationController.
     *
     * @return The singleton instance
     */
    @NonNull
    public static NavigationController getInstance() {
        if (sInstance == null) {
            synchronized (NavigationController.class) {
                if (sInstance == null) {
                    sInstance = new NavigationController();
                }
            }
        }
        return sInstance;
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Handler for main thread operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for health check operations. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());
    
    /** Current state of the state machine. */
    private final AtomicReference<State> mCurrentState = new AtomicReference<>(State.IDLE);
    
    /** Current operation in progress. */
    private final AtomicReference<Operation> mCurrentOperation = new AtomicReference<>(null);
    
    /** Timestamp when the current state started. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);
    
    /** Timestamp of the last activity (heartbeat or progress). */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);
    
    /** Flag indicating if recovery is in progress. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);
    
    /** Health check runnable. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;
    
    /** Recovery runnable. */
    @Nullable
    private Runnable mRecoveryRunnable = null;
    
    /** Lock for health check operations. */
    private final Object mHealthLock = new Object();
    
    /** Count of active operations for each button group. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, AtomicInteger> mGroupOperationCounts = 
        new ConcurrentHashMap<>();
    
    /** Current disabled state for each button group (cached for performance). */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Boolean> mGroupDisabledState = 
        new ConcurrentHashMap<>();
    
    /** Registered button state listeners (legacy). */
    @NonNull
    private final CopyOnWriteArrayList<ButtonStateListener> mButtonListeners = 
        new CopyOnWriteArrayList<>();
    
    /** Registered state listeners (extended). */
    @NonNull
    private final CopyOnWriteArrayList<StateListener> mStateListeners = 
        new CopyOnWriteArrayList<>();
    
    /** Registered progress listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ProgressListener> mProgressListeners = 
        new CopyOnWriteArrayList<>();
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Private constructor - automatically starts continuous health check.
     */
    private NavigationController() {
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupDisabledState.put(group, false);
            mGroupOperationCounts.put(group, new AtomicInteger(0));
        }
        startContinuousHealthCheck();
        Log.d(TAG, "NavigationController initialized with " + STUCK_TIMEOUT_MS + "ms stuck timeout");
    }
    
    // ========================================================================
    // Continuous Health Check
    // ========================================================================
    
    /**
     * Starts the continuous health check thread.
     * This runs FOREVER from app start to app shutdown, checking every 5 seconds.
     */
    private void startContinuousHealthCheck() {
        if (mHealthCheckRunnable != null) {
            return;
        }
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        
        mHealthHandler.post(mHealthCheckRunnable);
        Log.d(TAG, "Continuous health check started (interval: " + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }
    
    /**
     * Stops the continuous health check (called during shutdown).
     */
    private void stopContinuousHealthCheck() {
        if (mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
        Log.d(TAG, "Continuous health check stopped");
    }
    
    /**
     * Performs health check on all active operations.
     * Automatically terminates any stuck operation (no activity for 5+ seconds).
     * Also checks for orphaned disabled states.
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            // Check if we're in SYNCING state but no activity
            if (mCurrentState.get() == State.SYNCING) {
                long inactiveTime = SystemClock.elapsedRealtime() - mLastActivityTime.get();
                
                if (inactiveTime > STUCK_TIMEOUT_MS) {
                    Operation operation = mCurrentOperation.get();
                    Log.w(TAG, "STUCK DETECTED: " + operation + " inactive for " + inactiveTime + "ms");
                    
                    // Notify state listeners about stuck state
                    for (StateListener listener : mStateListeners) {
                        try {
                            listener.onStuckDetected(operation, inactiveTime);
                        } catch (Exception e) {
                            Log.e(TAG, "Error notifying stuck listener", e);
                        }
                    }
                    
                    // Auto-recover
                    startAutoRecovery();
                }
            }
            
            // Check for orphaned disabled states (legacy counter-based recovery)
            for (ButtonGroup group : ButtonGroup.values()) {
                boolean isDisabled = isGroupDisabled(group);
                int operationCount = getGroupOperationCount(group);
                
                // If group is disabled but no operations are active, recover
                if (isDisabled && operationCount == 0 && mCurrentState.get() != State.SYNCING) {
                    Log.w(TAG, "Orphaned disabled state detected for " + group.name() + " - recovering");
                    setGroupDisabled(group, false);
                }
            }
        }
    }
    
    // ========================================================================
    // Auto-Recovery
    // ========================================================================
    
    /**
     * Starts auto-recovery from an error state.
     */
    private void startAutoRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        
        Log.d(TAG, "Starting auto-recovery");
        transitionTo(State.RECOVERING);
        
        // Cancel any existing recovery
        cancelRecovery();
        
        // Schedule recovery
        mRecoveryRunnable = new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.RECOVERING) {
                    Log.d(TAG, "Auto-recovery completed");
                    transitionTo(State.RECOVERED);
                    mIsRecovering.set(false);
                    mCurrentOperation.set(null);
                    
                    // Enable all buttons
                    enableAllButtons();
                    
                    // Transition to IDLE after a short delay
                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mCurrentState.get() == State.RECOVERED) {
                                transitionTo(State.IDLE);
                            }
                        }
                    }, 100);
                }
            }
        };
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }
    
    /**
     * Cancels any pending recovery.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }
    
    // ========================================================================
    // State Machine Transitions
    // ========================================================================
    
    /**
     * Transitions to a new state and notifies listeners.
     *
     * @param newState The new state
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);
        
        if (oldState == newState) {
            return;
        }
        
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
        
        mStateStartTime.set(SystemClock.elapsedRealtime());
        
        // Notify state listeners
        for (StateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying state listener", e);
            }
        }
    }
    
    /**
     * Enables all button groups.
     */
    private void enableAllButtons() {
        for (ButtonGroup group : ButtonGroup.values()) {
            setGroupDisabled(group, false);
        }
    }
    
    /**
     * Forces a reset of all states.
     * Use this as a last resort for manual recovery.
     */
    public void forceReset() {
        Log.w(TAG, "forceReset - Manual reset triggered");
        
        // Cancel any pending recoveries
        cancelRecovery();
        
        // Clear operation state
        mCurrentOperation.set(null);
        mIsRecovering.set(false);
        
        transitionTo(State.RESETTING);
        
        // Enable all buttons
        enableAllButtons();
        
        // Reset counters
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupOperationCounts.put(group, new AtomicInteger(0));
        }
        
        // Transition to IDLE
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.RESETTING) {
                    transitionTo(State.IDLE);
                }
            }
        }, 100);
    }
    
    // ========================================================================
    // Public API - Operation Management
    // ========================================================================
    
    /**
     * Begins an operation. Automatically tracked for progress-based staleness detection.
     *
     * @param operation The operation to begin
     */
    public void beginOperation(@NonNull Operation operation) {
        State currentState = mCurrentState.get();
        
        // If already in SYNCING state, reject
        if (currentState == State.SYNCING) {
            Log.w(TAG, "Already syncing, cannot begin " + operation);
            return;
        }
        
        // Force reset if in ERROR or RECOVERING state
        if (currentState == State.ERROR || currentState == State.RECOVERING) {
            Log.w(TAG, "In " + currentState + ", forcing reset before beginning");
            forceReset();
            // Re-check state after reset
            if (mCurrentState.get() != State.IDLE) {
                Log.w(TAG, "State not IDLE after reset, aborting");
                return;
            }
        }
        
        Log.d(TAG, "beginOperation: " + operation + " from " + currentState);
        
        mCurrentOperation.set(operation);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastActivityTime.set(SystemClock.elapsedRealtime());
        
        transitionTo(State.SYNCING);
        
        // Disable affected button groups
        for (ButtonGroup group : operation.getAffectedGroups()) {
            incrementGroupCount(group);
            setGroupDisabled(group, true);
        }
    }
    
    /**
     * Ends an operation normally.
     *
     * @param operation The operation to end
     */
    public void endOperation(@NonNull Operation operation) {
        State currentState = mCurrentState.get();
        
        if (currentState != State.SYNCING) {
            Log.w(TAG, "endOperation called but not in SYNCING state: " + currentState);
            // If already IDLE, just ensure buttons are enabled
            if (currentState == State.IDLE) {
                enableAllButtons();
            }
            return;
        }
        
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "endOperation called for wrong operation: expected " + 
                  mCurrentOperation.get() + " but got " + operation);
            return;
        }
        
        Log.d(TAG, "endOperation: " + operation);
        transitionTo(State.COMPLETED);
        
        // Enable affected button groups
        for (ButtonGroup group : operation.getAffectedGroups()) {
            decrementGroupCount(group);
            if (getGroupOperationCount(group) <= 0) {
                setGroupDisabled(group, false);
            }
        }
        
        // Auto-transition to IDLE after a short delay
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.COMPLETED) {
                    transitionTo(State.IDLE);
                    mCurrentOperation.set(null);
                }
            }
        }, 100);
    }
    
    /**
     * Records a heartbeat for an operation, resetting its inactivity timer.
     * 
     * <p><b>IMPORTANT:</b> Long-running operations MUST call this method every
     * 5 seconds to prevent being considered stuck. Operations can run for
     * hours as long as heartbeats are sent.</p>
     *
     * @param operation The operation to send a heartbeat for
     * @return True if the operation is active and heartbeat was recorded
     */
    public boolean heartbeat(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING) {
            Log.w(TAG, "Heartbeat called but not in SYNCING state");
            return false;
        }
        
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Heartbeat called for wrong operation");
            return false;
        }
        
        mLastActivityTime.set(SystemClock.elapsedRealtime());
        Log.v(TAG, "Heartbeat received for " + operation.name());
        return true;
    }
    
    /**
     * Records progress for an operation, resetting its inactivity timer.
     *
     * @param operation The operation making progress
     * @param current Current progress count
     * @param total Total expected (0 if unknown)
     */
    public void recordProgress(@NonNull Operation operation, int current, int total) {
        if (mCurrentState.get() != State.SYNCING) {
            Log.w(TAG, "Progress reported but not in SYNCING state");
            return;
        }
        
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Progress reported for wrong operation");
            return;
        }
        
        mLastActivityTime.set(SystemClock.elapsedRealtime());
        
        // Notify progress listeners
        for (ProgressListener listener : mProgressListeners) {
            try {
                listener.onProgress(operation, current, total);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying progress listener", e);
            }
        }
    }
    
    /**
     * Checks if an operation is currently active.
     *
     * @param operation The operation to check
     * @return True if the operation is active
     */
    public boolean isOperationActive(@NonNull Operation operation) {
        return mCurrentState.get() == State.SYNCING && 
               mCurrentOperation.get() == operation;
    }
    
    /**
     * Checks if an operation is stuck (no activity for 5+ seconds).
     *
     * @param operation The operation to check
     * @return True if the operation is stuck
     */
    public boolean isOperationStuck(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING || mCurrentOperation.get() != operation) {
            return false;
        }
        return getInactiveTimeMs() > STUCK_TIMEOUT_MS;
    }
    
    /**
     * Returns the time since last activity for an operation in milliseconds.
     *
     * @param operation The operation to check
     * @return Time since last activity, or -1 if operation not active
     */
    public long getInactiveTimeMs(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING || mCurrentOperation.get() != operation) {
            return -1;
        }
        return SystemClock.elapsedRealtime() - mLastActivityTime.get();
    }
    
    /**
     * Gets the current progress of an operation.
     *
     * @param operation The operation to check
     * @return Array of [current, total], or null if operation not active
     */
    @Nullable
    public int[] getOperationProgress(@NonNull Operation operation) {
        // This is a placeholder - progress tracking is done via listeners
        // We don't store progress values internally
        return null;
    }
    
    /**
     * Gets the current state of the state machine.
     *
     * @return The current state
     */
    @NonNull
    public String getCurrentState() {
        return mCurrentState.get().name();
    }
    
    /**
     * Checks if a button group is currently disabled.
     *
     * @param group The button group to check
     * @return True if the group should be disabled
     */
    public boolean isGroupDisabled(@NonNull ButtonGroup group) {
        Boolean cached = mGroupDisabledState.get(group);
        return cached != null && cached;
    }
    
    /**
     * Returns the current operation count for a button group.
     *
     * @param group The button group
     * @return The current operation count
     */
    public int getGroupOperationCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        return counter != null ? counter.get() : 0;
    }
    
    /**
     * Forces end of all active operations and clears all state.
     * Use as last resort when operations are stuck.
     */
    public void forceEndAllOperations() {
        forceReset();
    }
    
    // ========================================================================
    // Private State Management
    // ========================================================================
    
    /**
     * Increments the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after increment
     */
    private int incrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            counter = new AtomicInteger(0);
            mGroupOperationCounts.put(group, counter);
        }
        return counter.incrementAndGet();
    }
    
    /**
     * Decrements the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after decrement
     */
    private int decrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            Log.w(TAG, "No counter found for group: " + group.name());
            return -1;
        }
        return counter.decrementAndGet();
    }
    
    /**
     * Sets the disabled state for a button group and notifies all listeners.
     *
     * @param group The button group
     * @param disabled True to disable, false to enable
     */
    private void setGroupDisabled(@NonNull ButtonGroup group, boolean disabled) {
        Boolean current = mGroupDisabledState.get(group);
        if (current != null && current == disabled) {
            return;
        }
        
        mGroupDisabledState.put(group, disabled);
        Log.d(TAG, "Group " + group.name() + " " + (disabled ? "DISABLED" : "ENABLED"));
        
        // Notify state listeners
        for (StateListener listener : mStateListeners) {
            try {
                listener.onButtonStateChanged(group, disabled);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying state listener", e);
            }
        }
        
        // Notify legacy button listeners
        for (ButtonStateListener listener : mButtonListeners) {
            try {
                listener.onButtonStateChanged(group, disabled);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying button listener", e);
            }
        }
    }
    
    // ========================================================================
    // Listener Management
    // ========================================================================
    
    /**
     * Registers a button state listener.
     * Immediately receives current state for all button groups.
     *
     * @param listener The listener to register
     */
    public void registerListener(@NonNull ButtonStateListener listener) {
        if (!mButtonListeners.contains(listener)) {
            mButtonListeners.add(listener);
            // Immediately notify current state
            for (ButtonGroup group : ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group));
            }
        }
    }
    
    /**
     * Unregisters a button state listener.
     *
     * @param listener The listener to unregister
     */
    public void unregisterListener(@NonNull ButtonStateListener listener) {
        mButtonListeners.remove(listener);
    }
    
    /**
     * Registers a state listener (extended interface).
     * Immediately receives current state for all button groups.
     *
     * @param listener The listener to register
     */
    public void registerStateListener(@NonNull StateListener listener) {
        if (!mStateListeners.contains(listener)) {
            mStateListeners.add(listener);
            // Immediately notify current state
            listener.onStateChanged(State.IDLE, mCurrentState.get());
            for (ButtonGroup group : ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group));
            }
        }
    }
    
    /**
     * Unregisters a state listener.
     *
     * @param listener The listener to unregister
     */
    public void unregisterStateListener(@NonNull StateListener listener) {
        mStateListeners.remove(listener);
    }
    
    /**
     * Adds a progress listener.
     *
     * @param listener The listener to add
     */
    public void addProgressListener(@NonNull ProgressListener listener) {
        if (!mProgressListeners.contains(listener)) {
            mProgressListeners.add(listener);
        }
    }
    
    /**
     * Removes a progress listener.
     *
     * @param listener The listener to remove
     */
    public void removeProgressListener(@NonNull ProgressListener listener) {
        mProgressListeners.remove(listener);
    }
    
    // ========================================================================
    // Convenience Methods
    // ========================================================================
    
    /**
     * Convenience method to begin a playlist sync operation.
     */
    public void beginPlaylistSync() {
        beginOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to end a playlist sync operation.
     */
    public void endPlaylistSync() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.PLAYLIST_SYNC) {
            endOperation(current);
        } else {
            Log.w(TAG, "endPlaylistSync called but current operation is " + current);
            // Force reset if mismatch
            forceReset();
        }
    }
    
    /**
     * Convenience method to begin a metadata save operation.
     */
    public void beginMetadataSave() {
        beginOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to end a metadata save operation.
     */
    public void endMetadataSave() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.METADATA_SAVE) {
            endOperation(current);
        } else {
            Log.w(TAG, "endMetadataSave called but current operation is " + current);
            forceReset();
        }
    }
    
    /**
     * Convenience method to begin a folder update operation.
     */
    public void beginFolderUpdate() {
        beginOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Convenience method to end a folder update operation.
     */
    public void endFolderUpdate() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.FOLDER_UPDATE) {
            endOperation(current);
        } else {
            Log.w(TAG, "endFolderUpdate called but current operation is " + current);
            forceReset();
        }
    }
    
    /**
     * Convenience method to record progress for playlist sync.
     *
     * @param current Current progress
     * @param total Total expected
     */
    public void progressPlaylistSync(int current, int total) {
        Operation currentOp = mCurrentOperation.get();
        if (currentOp == Operation.PLAYLIST_SYNC) {
            recordProgress(currentOp, current, total);
        }
    }
    
    // ========================================================================
    // Debug
    // ========================================================================
    
    /**
     * Returns debug information about all active operations.
     *
     * @return Debug information string
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("NavigationController Debug Info:\n");
        sb.append("  State: ").append(mCurrentState.get()).append("\n");
        sb.append("  Operation: ").append(mCurrentOperation.get()).append("\n");
        sb.append("  State duration: ").append(getStateDurationMs()).append("ms\n");
        sb.append("  Inactive time: ").append(getInactiveTimeMs()).append("ms\n");
        sb.append("  Is recovering: ").append(mIsRecovering.get()).append("\n");
        sb.append("  Stuck timeout: ").append(STUCK_TIMEOUT_MS).append("ms\n");
        sb.append("  Group states:\n");
        for (ButtonGroup group : ButtonGroup.values()) {
            int count = getGroupOperationCount(group);
            boolean disabled = isGroupDisabled(group);
            sb.append("    - ").append(group.name())
              .append(": count=").append(count)
              .append(", disabled=").append(disabled).append("\n");
        }
        sb.append("  State listeners: ").append(mStateListeners.size()).append("\n");
        sb.append("  Button listeners: ").append(mButtonListeners.size()).append("\n");
        sb.append("  Progress listeners: ").append(mProgressListeners.size()).append("\n");
        return sb.toString();
    }
    
    /**
     * Gets the state duration in milliseconds.
     *
     * @return State duration in milliseconds
     */
    private long getStateDurationMs() {
        return SystemClock.elapsedRealtime() - mStateStartTime.get();
    }
    
    /**
     * Gets the inactive time in milliseconds.
     *
     * @return Inactive time in milliseconds, or -1 if not in SYNCING state
     */
    private long getInactiveTimeMs() {
        if (mCurrentState.get() != State.SYNCING) {
            return -1;
        }
        return SystemClock.elapsedRealtime() - mLastActivityTime.get();
    }
    
    /**
     * Shuts down the NavigationController and releases resources.
     */
    public void shutdown() {
        Log.d(TAG, "Shutting down NavigationController");
        stopContinuousHealthCheck();
        cancelRecovery();
        forceReset();
        sInstance = null;
    }
}