package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.EnumSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Tracks active operations and disables the button groups each operation
 * affects.
 *
 * <p>An operation begins with a declaration of how often it will
 * heartbeat through {@link Operation#getHeartbeatIntervalMs()} and how
 * many consecutive missed heartbeats the state machine tolerates through
 * {@link Operation#getMissedHeartbeatTolerance()}. The controller
 * enforces that declaration. An operation runs for as long as it honours
 * its own contract.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The controller owns the per-group disabled state, the per-group
 * operation count, the current operation, and the liveness window of the
 * current operation. Components that need to know whether an operation
 * is running query {@link #isGroupDisabled(ButtonGroup)}. Components
 * that need to know whether a specific operation has exceeded its window
 * query {@link #isOperationStuck(Operation)}.</p>
 *
 * <p>Button groups partition the components that participate in the
 * controller:</p>
 * <ul>
 *   <li>{@link ButtonGroup#DATABASE_ACTIONS} — the PLAYLIST and METADATA
 *       buttons in {@link MusicPlayer}.</li>
 *   <li>{@link ButtonGroup#FOLDER_ACTIONS} — the UPDATE, IMPORT, and
 *       REMOVE buttons in {@link FolderManager}.</li>
 *   <li>{@link ButtonGroup#METADATA_ACTIONS} — the MODIFY and UPDATE
 *       buttons in {@link MetadataEditor}.</li>
 * </ul>
 *
 * <h3>Ordering</h3>
 * <p>The health check runs every {@link #HEALTH_CHECK_INTERVAL_MS}
 * milliseconds regardless of the declared heartbeat of any individual
 * operation. When an operation's inactivity exceeds
 * {@code heartbeatIntervalMs * missedHeartbeatTolerance}, the controller
 * treats it as abandoned, notifies every registered listener, and runs
 * its recovery pass. Recovery re-enables every button group and clears
 * the current operation.</p>
 *
 * <p>Callers begin an operation with {@link #beginOperation(Operation)}.
 * While the operation runs, it calls
 * {@link #heartbeat(Operation)} within its declared window or reports
 * progress through {@link #recordProgress(Operation, int, int)}.
 * Callers end the operation with {@link #endOperation(Operation)}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All state is stored in {@link ConcurrentHashMap},
 * {@link CopyOnWriteArrayList}, and atomic references. Listener
 * notification iterates a snapshot of each listener collection. Health
 * checks and recovery run on the main thread through {@link #mMainHandler}
 * and {@link #mHealthHandler}, and the health check acquires
 * {@link #mHealthLock} before inspecting or mutating shared state.</p>
 *
 * <h3>Usage</h3>
 * <pre>
 * NavigationController controller = NavigationController.getInstance();
 * controller.beginPlaylistSync();
 *
 * controller.heartbeat(Operation.PLAYLIST_SYNC);
 * controller.recordProgress(Operation.PLAYLIST_SYNC, current, total);
 *
 * int[] progress = controller.getOperationProgress(Operation.PLAYLIST_SYNC);
 *
 * controller.endPlaylistSync();
 * </pre>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class NavigationController {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "NavigationController";

    /**
     * Health check interval in milliseconds.
     *
     * <p>The controller runs its stuck detector at this frequency
     * regardless of the declared heartbeat of any individual operation,
     * so detection latency is bounded by this constant.</p>
     */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500;

    /** Delay after detecting a stuck operation before recovery runs, in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 1000;

    // ========================================================================
    // Enums
    // ========================================================================

    /**
     * Button groups the controller can disable independently.
     */
    public enum ButtonGroup {

        /**
         * The PLAYLIST and METADATA buttons in {@link MusicPlayer}.
         *
         * <p>The MANAGER button is excluded from this group.</p>
         */
        DATABASE_ACTIONS,

        /**
         * The UPDATE, IMPORT, and REMOVE buttons in {@link FolderManager}.
         *
         * <p>These buttons modify the folder list and the playlist.</p>
         */
        FOLDER_ACTIONS,

        /**
         * The MODIFY and UPDATE buttons in {@link MetadataEditor}.
         *
         * <p>These buttons modify the metadata of an audio file.</p>
         */
        METADATA_ACTIONS
    }

    /**
     * Operations whose liveness the controller enforces.
     *
     * <p>Each operation declares how often it promises to heartbeat and
     * how many consecutive missed heartbeats the controller tolerates
     * before treating the operation as abandoned.</p>
     */
    public enum Operation {

        /**
         * Playlist synchronisation.
         *
         * <p>Affects {@link ButtonGroup#DATABASE_ACTIONS} and
         * {@link ButtonGroup#FOLDER_ACTIONS}.</p>
         */
        PLAYLIST_SYNC(
            EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS),
            500L,
            3),

        /**
         * Metadata save.
         *
         * <p>Affects {@link ButtonGroup#METADATA_ACTIONS}.</p>
         */
        METADATA_SAVE(
            EnumSet.of(ButtonGroup.METADATA_ACTIONS),
            500L,
            3),

        /**
         * Folder management.
         *
         * <p>Affects {@link ButtonGroup#FOLDER_ACTIONS}.</p>
         */
        FOLDER_UPDATE(
            EnumSet.of(ButtonGroup.FOLDER_ACTIONS),
            500L,
            3);

        /** Button groups this operation disables while it runs. */
        private final EnumSet<ButtonGroup> mAffectedGroups;

        /** Interval at which this operation promises to heartbeat, in milliseconds. */
        private final long mHeartbeatIntervalMs;

        /** Consecutive missed heartbeats tolerated before recovery, as a count. */
        private final int mMissedHeartbeatTolerance;

        /**
         * Constructs an operation with the given liveness contract.
         *
         * @param affectedGroups Button groups this operation disables
         * @param heartbeatIntervalMs Interval at which the operation
         *        promises to heartbeat, in milliseconds
         * @param missedHeartbeatTolerance Consecutive missed heartbeats
         *        tolerated before recovery
         */
        Operation(EnumSet<ButtonGroup> affectedGroups,
                  long heartbeatIntervalMs,
                  int missedHeartbeatTolerance) {
            this.mAffectedGroups = affectedGroups;
            this.mHeartbeatIntervalMs = heartbeatIntervalMs;
            this.mMissedHeartbeatTolerance = missedHeartbeatTolerance;
        }

        /**
         * Returns the button groups this operation disables while it
         * runs.
         *
         * @return The affected button groups
         */
        @NonNull
        public EnumSet<ButtonGroup> getAffectedGroups() {
            return mAffectedGroups;
        }

        /**
         * Returns the interval at which this operation promises to
         * heartbeat.
         *
         * @return The heartbeat interval in milliseconds
         */
        public long getHeartbeatIntervalMs() {
            return mHeartbeatIntervalMs;
        }

        /**
         * Returns the number of consecutive missed heartbeats this
         * operation tolerates before the controller treats it as
         * abandoned.
         *
         * @return The missed-heartbeat tolerance
         */
        public int getMissedHeartbeatTolerance() {
            return mMissedHeartbeatTolerance;
        }

        /**
         * Returns the wall-clock window within which this operation must
         * produce a heartbeat or progress update.
         *
         * @return The liveness window in milliseconds
         */
        public long getLivenessWindowMs() {
            return mHeartbeatIntervalMs * mMissedHeartbeatTolerance;
        }
    }

    /**
     * Internal states of the controller's own state machine.
     */
    private enum State {

        /** No operation is in progress and every button group is enabled. */
        IDLE,

        /** An operation is in progress and its affected groups are disabled. */
        SYNCING,

        /** An operation has ended normally; the controller is transitioning back to idle. */
        COMPLETED,

        /** An operation has failed; the controller is transitioning to recovery. */
        ERROR,

        /** Recovery from a stuck or failed operation is in progress. */
        RECOVERING,

        /** Recovery completed; the controller is transitioning back to idle. */
        RECOVERED,

        /** A forced reset is in progress. */
        RESETTING
    }

    // ========================================================================
    // Listener Interfaces
    // ========================================================================

    /**
     * Receives notifications when a button group's disabled state
     * changes.
     */
    public interface ButtonStateListener {

        /**
         * Called when a button group's disabled state changes.
         *
         * @param group Button group whose state changed
         * @param disabled True when the buttons in the group are disabled
         */
        void onButtonStateChanged(@NonNull ButtonGroup group, boolean disabled);
    }

    /**
     * Receives state transitions and stuck detection events.
     */
    public interface StateListener extends ButtonStateListener {

        /**
         * Called when the controller's internal state changes.
         *
         * @param oldState Previous state
         * @param newState New state
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);

        /**
         * Called when a stuck operation is detected and recovery begins.
         *
         * @param operation The operation that was stuck
         * @param stuckDurationMs Duration for which the operation had
         *        been inactive, in milliseconds
         */
        void onStuckDetected(@NonNull Operation operation, long stuckDurationMs);
    }

    /**
     * Receives progress updates from an operation.
     */
    public interface ProgressListener {

        /**
         * Called when an operation reports progress.
         *
         * @param operation The operation that made progress
         * @param current Current progress count
         * @param total Total expected count, or 0 when unknown
         */
        void onProgress(@NonNull Operation operation, int current, int total);
    }

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile NavigationController sInstance;

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @return The singleton instance
     */
    @NonNull
    public static NavigationController getInstance() {
        if (sInstance == null) {
            synchronized (NavigationController.class) {
                if (sInstance == null) {
                    sInstance = new NavigationController();
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Handler for main-thread state transitions and recovery. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for the continuous health check. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    /** Current state of the controller's state machine. */
    private final AtomicReference<State> mCurrentState =
        new AtomicReference<>(State.IDLE);

    /** Operation currently in progress, or null. */
    private final AtomicReference<Operation> mCurrentOperation =
        new AtomicReference<>(null);

    /** Timestamp at which the current state began. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);

    /** Timestamp of the last heartbeat or progress report. */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);

    /** True while recovery is running. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);

    /** Runnable for the continuous health check, or null when stopped. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Runnable for the current recovery, or null when none is pending. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock that serialises health checks. */
    private final Object mHealthLock = new Object();

    /** Per-group operation count. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, AtomicInteger> mGroupOperationCounts =
        new ConcurrentHashMap<>();

    /** Per-group disabled state. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Boolean> mGroupDisabledState =
        new ConcurrentHashMap<>();

    /**
     * Last reported progress per operation, stored as
     * {@code {current, total}}. Populated by
     * {@link #recordProgress(Operation, int, int)} and cleared by
     * {@link #beginOperation(Operation)},
     * {@link #endOperation(Operation)}, {@link #forceReset()}, and
     * recovery. Backs {@link #getOperationProgress(Operation)}.
     */
    @NonNull
    private final ConcurrentHashMap<Operation, int[]> mOperationProgress =
        new ConcurrentHashMap<>();

    /** Registered button state listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ButtonStateListener> mButtonListeners =
        new CopyOnWriteArrayList<>();

    /** Registered state listeners. */
    @NonNull
    private final CopyOnWriteArrayList<StateListener> mStateListeners =
        new CopyOnWriteArrayList<>();

    /** Registered progress listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ProgressListener> mProgressListeners =
        new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the singleton and starts the continuous health check.
     */
    private NavigationController() {
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupDisabledState.put(group, false);
            mGroupOperationCounts.put(group, new AtomicInteger(0));
        }
        startContinuousHealthCheck();
        Log.d(TAG, "NavigationController initialized with declared-liveness enforcement");
    }

    // ========================================================================
    // Continuous Health Check
    // ========================================================================

    /**
     * Starts the continuous health check. A second call while the check
     * is already running does nothing.
     */
    private void startContinuousHealthCheck() {
        if (mHealthCheckRunnable != null) {
            return;
        }

        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };

        mHealthHandler.post(mHealthCheckRunnable);
        Log.d(TAG, "Continuous health check started (interval: "
            + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Stops the continuous health check. Idempotent.
     */
    private void stopContinuousHealthCheck() {
        if (mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
        Log.d(TAG, "Continuous health check stopped");
    }

    /**
     * Runs the health check.
     *
     * <p>Treats the current operation as stuck when its inactivity
     * exceeds the liveness window the operation declared. Cleans up
     * orphaned disabled states by re-enabling any group that is disabled
     * with no active operation count.</p>
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            if (mCurrentState.get() == State.SYNCING) {
                Operation operation = mCurrentOperation.get();
                if (operation != null) {
                    long inactiveTime =
                        SystemClock.elapsedRealtime() - mLastActivityTime.get();
                    long window = operation.getLivenessWindowMs();

                    if (inactiveTime > window) {
                        Log.w(TAG, "STUCK DETECTED: " + operation
                            + " inactive for " + inactiveTime + "ms"
                            + " (declared window: " + window + "ms,"
                            + " interval: " + operation.getHeartbeatIntervalMs() + "ms,"
                            + " tolerance: " + operation.getMissedHeartbeatTolerance() + ")");

                        for (StateListener listener : mStateListeners) {
                            try {
                                listener.onStuckDetected(operation, inactiveTime);
                            } catch (Exception exception) {
                                Log.e(TAG, "Error notifying stuck listener", exception);
                            }
                        }

                        startAutoRecovery();
                    }
                }
            }

            for (ButtonGroup group : ButtonGroup.values()) {
                boolean isDisabled = isGroupDisabled(group);
                int operationCount = getGroupOperationCount(group);

                if (isDisabled && operationCount == 0
                        && mCurrentState.get() != State.SYNCING) {
                    Log.w(TAG, "Orphaned disabled state detected for "
                        + group.name() + " - recovering");
                    setGroupDisabled(group, false);
                }
            }
        }
    }

    // ========================================================================
    // Auto-Recovery
    // ========================================================================

    /**
     * Starts the recovery pass. A second call while recovery is already
     * running does nothing.
     */
    private void startAutoRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }

        Log.d(TAG, "Starting auto-recovery");
        transitionTo(State.RECOVERING);

        cancelRecovery();

        mRecoveryRunnable = new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.RECOVERING) {
                    Log.d(TAG, "Auto-recovery completed");
                    transitionTo(State.RECOVERED);
                    mIsRecovering.set(false);
                    mCurrentOperation.set(null);
                    mOperationProgress.clear();

                    enableAllButtons();

                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mCurrentState.get() == State.RECOVERED) {
                                transitionTo(State.IDLE);
                            }
                        }
                    }, 100);
                }
            }
        };
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Cancels any pending recovery. Idempotent.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // State Machine Transitions
    // ========================================================================

    /**
     * Transitions to the given state and notifies every registered state
     * listener.
     *
     * <p>A transition to the current state does nothing.</p>
     *
     * @param newState State to transition to
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);

        if (oldState == newState) {
            return;
        }

        Log.d(TAG, "State transition: " + oldState + " \u2192 " + newState);

        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (StateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener", exception);
            }
        }
    }

    /**
     * Enables every button group.
     */
    private void enableAllButtons() {
        for (ButtonGroup group : ButtonGroup.values()) {
            setGroupDisabled(group, false);
        }
    }

    /**
     * Resets every state field to its initial value, transitions to
     * IDLE, and re-enables every button group.
     */
    public void forceReset() {
        Log.w(TAG, "forceReset - Manual reset triggered");

        cancelRecovery();

        mCurrentOperation.set(null);
        mIsRecovering.set(false);
        mOperationProgress.clear();

        transitionTo(State.RESETTING);

        enableAllButtons();

        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupOperationCounts.put(group, new AtomicInteger(0));
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.RESETTING) {
                    transitionTo(State.IDLE);
                }
            }
        }, 100);
    }

    // ========================================================================
    // Public API - Operation Management
    // ========================================================================

    /**
     * Begins the given operation. The operation's declared liveness
     * contract becomes the controller's enforcement window for the
     * duration of the run.
     *
     * <p>A second call while another operation is in SYNCING does
     * nothing. When the controller is in ERROR or RECOVERING, it resets
     * first and refuses to begin the new operation if the reset does not
     * reach IDLE.</p>
     *
     * @param operation Operation to begin
     */
    public void beginOperation(@NonNull Operation operation) {
        State currentState = mCurrentState.get();

        if (currentState == State.SYNCING) {
            Log.w(TAG, "Already syncing, cannot begin " + operation);
            return;
        }

        if (currentState == State.ERROR || currentState == State.RECOVERING) {
            Log.w(TAG, "In " + currentState + ", forcing reset before beginning");
            forceReset();
            if (mCurrentState.get() != State.IDLE) {
                Log.w(TAG, "State not IDLE after reset, aborting");
                return;
            }
        }

        Log.d(TAG, "beginOperation: " + operation + " from " + currentState
            + " (declared liveness: heartbeat every "
            + operation.getHeartbeatIntervalMs()
            + "ms, tolerance " + operation.getMissedHeartbeatTolerance()
            + ", window " + operation.getLivenessWindowMs() + "ms)");

        mCurrentOperation.set(operation);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastActivityTime.set(SystemClock.elapsedRealtime());
        mOperationProgress.remove(operation);

        transitionTo(State.SYNCING);

        for (ButtonGroup group : operation.getAffectedGroups()) {
            incrementGroupCount(group);
            setGroupDisabled(group, true);
        }
    }

    /**
     * Ends the given operation and re-enables the button groups it
     * affected.
     *
     * <p>When the controller is not in SYNCING or the given operation is
     * not the current one, the call is logged and has no effect on the
     * state machine.</p>
     *
     * @param operation Operation to end
     */
    public void endOperation(@NonNull Operation operation) {
        State currentState = mCurrentState.get();

        if (currentState != State.SYNCING) {
            Log.w(TAG, "endOperation called but not in SYNCING state: " + currentState);
            if (currentState == State.IDLE) {
                enableAllButtons();
            }
            return;
        }

        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "endOperation called for wrong operation: expected "
                + mCurrentOperation.get() + " but got " + operation);
            return;
        }

        Log.d(TAG, "endOperation: " + operation);
        transitionTo(State.COMPLETED);
        mOperationProgress.remove(operation);

        for (ButtonGroup group : operation.getAffectedGroups()) {
            decrementGroupCount(group);
            if (getGroupOperationCount(group) <= 0) {
                setGroupDisabled(group, false);
            }
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mCurrentState.get() == State.COMPLETED) {
                    transitionTo(State.IDLE);
                    mCurrentOperation.set(null);
                }
            }
        }, 100);
    }

    /**
     * Records a heartbeat for the given operation, resetting its
     * inactivity timer.
     *
     * <p>Long-running operations call this method within the interval
     * they declared for their {@link Operation}. An operation can run
     * for hours while it honours its own declaration.</p>
     *
     * @param operation Operation whose heartbeat is being recorded
     * @return True when the heartbeat was recorded against an active
     *         matching operation
     */
    public boolean heartbeat(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING) {
            Log.w(TAG, "Heartbeat called but not in SYNCING state");
            return false;
        }

        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Heartbeat called for wrong operation");
            return false;
        }

        mLastActivityTime.set(SystemClock.elapsedRealtime());
        Log.v(TAG, "Heartbeat received for " + operation.name());
        return true;
    }

    /**
     * Records progress for the given operation, resetting its inactivity
     * timer and storing the latest counts for retrieval through
     * {@link #getOperationProgress(Operation)}.
     *
     * @param operation Operation that made progress
     * @param current Current progress count
     * @param total Total expected count, or 0 when unknown
     */
    public void recordProgress(@NonNull Operation operation, int current, int total) {
        if (mCurrentState.get() != State.SYNCING) {
            Log.w(TAG, "Progress reported but not in SYNCING state");
            return;
        }

        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Progress reported for wrong operation");
            return;
        }

        mLastActivityTime.set(SystemClock.elapsedRealtime());
        mOperationProgress.put(operation, new int[] {current, total});

        for (ProgressListener listener : mProgressListeners) {
            try {
                listener.onProgress(operation, current, total);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying progress listener", exception);
            }
        }
    }

    /**
     * Returns whether the given operation is currently active.
     *
     * @param operation Operation to test
     * @return True when the operation is the current one and the
     *         controller is in SYNCING
     */
    public boolean isOperationActive(@NonNull Operation operation) {
        return mCurrentState.get() == State.SYNCING
            && mCurrentOperation.get() == operation;
    }

    /**
     * Returns whether the given operation has exceeded its declared
     * liveness window.
     *
     * @param operation Operation to test
     * @return True when the operation is active and its inactivity
     *         exceeds its liveness window
     */
    public boolean isOperationStuck(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING
                || mCurrentOperation.get() != operation) {
            return false;
        }
        return getInactiveTimeMs() > operation.getLivenessWindowMs();
    }

    /**
     * Returns the time since the last heartbeat or progress report for
     * the given operation.
     *
     * @param operation Operation to inspect
     * @return Inactive time in milliseconds, or -1 when the operation is
     *         not active
     */
    public long getInactiveTimeMs(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING
                || mCurrentOperation.get() != operation) {
            return -1;
        }
        return SystemClock.elapsedRealtime() - mLastActivityTime.get();
    }

    /**
     * Returns the last reported progress of the given operation.
     *
     * <p>The returned array is a defensive copy; callers may mutate it
     * without affecting internal state.</p>
     *
     * @param operation Operation to inspect
     * @return An array whose first element is the current count and whose
     *         second element is the total, or null when the operation is
     *         not active or has not yet reported progress
     */
    @Nullable
    public int[] getOperationProgress(@NonNull Operation operation) {
        if (mCurrentState.get() != State.SYNCING
                || mCurrentOperation.get() != operation) {
            return null;
        }
        int[] progress = mOperationProgress.get(operation);
        return progress != null ? progress.clone() : null;
    }

    /**
     * Returns the name of the controller's current state.
     *
     * @return The current state's name
     */
    @NonNull
    public String getCurrentState() {
        return mCurrentState.get().name();
    }

    /**
     * Returns whether the given button group is currently disabled.
     *
     * @param group Button group to test
     * @return True when the group is disabled
     */
    public boolean isGroupDisabled(@NonNull ButtonGroup group) {
        Boolean cached = mGroupDisabledState.get(group);
        return cached != null && cached;
    }

    /**
     * Returns the current operation count for the given button group.
     *
     * @param group Button group to inspect
     * @return The current operation count
     */
    public int getGroupOperationCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        return counter != null ? counter.get() : 0;
    }

    /**
     * Ends every active operation and clears all state.
     */
    public void forceEndAllOperations() {
        forceReset();
    }

    // ========================================================================
    // Private State Management
    // ========================================================================

    /**
     * Increments the operation count for the given button group.
     *
     * @param group Button group to increment
     * @return The new count after increment
     */
    private int incrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            counter = new AtomicInteger(0);
            mGroupOperationCounts.put(group, counter);
        }
        return counter.incrementAndGet();
    }

    /**
     * Decrements the operation count for the given button group.
     *
     * @param group Button group to decrement
     * @return The new count after decrement, or -1 when no counter exists
     */
    private int decrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            Log.w(TAG, "No counter found for group: " + group.name());
            return -1;
        }
        return counter.decrementAndGet();
    }

    /**
     * Sets the disabled state of the given button group and notifies
     * every registered listener when the value changes.
     *
     * @param group Button group to modify
     * @param disabled New disabled state
     */
    private void setGroupDisabled(@NonNull ButtonGroup group, boolean disabled) {
        Boolean current = mGroupDisabledState.get(group);
        if (current != null && current == disabled) {
            return;
        }

        mGroupDisabledState.put(group, disabled);
        Log.d(TAG, "Group " + group.name()
            + " " + (disabled ? "DISABLED" : "ENABLED"));

        for (StateListener listener : mStateListeners) {
            try {
                listener.onButtonStateChanged(group, disabled);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener", exception);
            }
        }

        for (ButtonStateListener listener : mButtonListeners) {
            try {
                listener.onButtonStateChanged(group, disabled);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying button listener", exception);
            }
        }
    }

    // ========================================================================
    // Listener Management
    // ========================================================================

    /**
     * Registers a button state listener.
     *
     * <p>The listener receives the current state of every button group
     * immediately after registration.</p>
     *
     * @param listener Listener to register
     */
    public void registerListener(@NonNull ButtonStateListener listener) {
        if (!mButtonListeners.contains(listener)) {
            mButtonListeners.add(listener);
            for (ButtonGroup group : ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group));
            }
        }
    }

    /**
     * Unregisters a button state listener.
     *
     * @param listener Listener to unregister
     */
    public void unregisterListener(@NonNull ButtonStateListener listener) {
        mButtonListeners.remove(listener);
    }

    /**
     * Registers a state listener.
     *
     * <p>The listener receives the current state and the current state
     * of every button group immediately after registration.</p>
     *
     * @param listener Listener to register
     */
    public void registerStateListener(@NonNull StateListener listener) {
        if (!mStateListeners.contains(listener)) {
            mStateListeners.add(listener);
            listener.onStateChanged(State.IDLE, mCurrentState.get());
            for (ButtonGroup group : ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group));
            }
        }
    }

    /**
     * Unregisters a state listener.
     *
     * @param listener Listener to unregister
     */
    public void unregisterStateListener(@NonNull StateListener listener) {
        mStateListeners.remove(listener);
    }

    /**
     * Adds a progress listener.
     *
     * @param listener Listener to add
     */
    public void addProgressListener(@NonNull ProgressListener listener) {
        if (!mProgressListeners.contains(listener)) {
            mProgressListeners.add(listener);
        }
    }

    /**
     * Removes a progress listener.
     *
     * @param listener Listener to remove
     */
    public void removeProgressListener(@NonNull ProgressListener listener) {
        mProgressListeners.remove(listener);
    }

    // ========================================================================
    // Convenience Methods
    // ========================================================================

    /**
     * Begins a playlist sync operation.
     */
    public void beginPlaylistSync() {
        beginOperation(Operation.PLAYLIST_SYNC);
    }

    /**
     * Ends the current playlist sync operation, or forces a reset when
     * the current operation is not {@link Operation#PLAYLIST_SYNC}.
     */
    public void endPlaylistSync() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.PLAYLIST_SYNC) {
            endOperation(current);
        } else {
            Log.w(TAG, "endPlaylistSync called but current operation is " + current);
            forceReset();
        }
    }

    /**
     * Begins a metadata save operation.
     */
    public void beginMetadataSave() {
        beginOperation(Operation.METADATA_SAVE);
    }

    /**
     * Ends the current metadata save operation, or forces a reset when
     * the current operation is not {@link Operation#METADATA_SAVE}.
     */
    public void endMetadataSave() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.METADATA_SAVE) {
            endOperation(current);
        } else {
            Log.w(TAG, "endMetadataSave called but current operation is " + current);
            forceReset();
        }
    }

    /**
     * Begins a folder update operation.
     */
    public void beginFolderUpdate() {
        beginOperation(Operation.FOLDER_UPDATE);
    }

    /**
     * Ends the current folder update operation, or forces a reset when
     * the current operation is not {@link Operation#FOLDER_UPDATE}.
     */
    public void endFolderUpdate() {
        Operation current = mCurrentOperation.get();
        if (current == Operation.FOLDER_UPDATE) {
            endOperation(current);
        } else {
            Log.w(TAG, "endFolderUpdate called but current operation is " + current);
            forceReset();
        }
    }

    /**
     * Records progress for the current playlist sync operation when one
     * is active.
     *
     * @param current Current progress count
     * @param total Total expected count, or 0 when unknown
     */
    public void progressPlaylistSync(int current, int total) {
        Operation currentOperation = mCurrentOperation.get();
        if (currentOperation == Operation.PLAYLIST_SYNC) {
            recordProgress(currentOperation, current, total);
        }
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns a human-readable snapshot of the controller's current
     * state.
     *
     * @return A multi-line string describing the current state, the
     *         current operation and its declared liveness, the per-group
     *         operation counts and disabled states, and the listener
     *         counts
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append("NavigationController Debug Info:\n");
        builder.append("  State: ").append(mCurrentState.get()).append("\n");
        builder.append("  Operation: ").append(mCurrentOperation.get()).append("\n");
        builder.append("  State duration: ").append(getStateDurationMs()).append("ms\n");
        builder.append("  Inactive time: ").append(getInactiveTimeMs()).append("ms\n");
        builder.append("  Is recovering: ").append(mIsRecovering.get()).append("\n");

        Operation currentOperation = mCurrentOperation.get();
        if (currentOperation != null) {
            builder.append("  Declared heartbeat interval: ")
                   .append(currentOperation.getHeartbeatIntervalMs()).append("ms\n");
            builder.append("  Declared tolerance: ")
                   .append(currentOperation.getMissedHeartbeatTolerance()).append("\n");
            builder.append("  Declared liveness window: ")
                   .append(currentOperation.getLivenessWindowMs()).append("ms\n");

            int[] progress = getOperationProgress(currentOperation);
            if (progress != null) {
                builder.append("  Progress: ").append(progress[0])
                       .append("/").append(progress[1]).append("\n");
            }
        }

        builder.append("  Group states:\n");
        for (ButtonGroup group : ButtonGroup.values()) {
            int count = getGroupOperationCount(group);
            boolean disabled = isGroupDisabled(group);
            builder.append("    - ").append(group.name())
              .append(": count=").append(count)
              .append(", disabled=").append(disabled).append("\n");
        }
        builder.append("  State listeners: ").append(mStateListeners.size()).append("\n");
        builder.append("  Button listeners: ").append(mButtonListeners.size()).append("\n");
        builder.append("  Progress listeners: ").append(mProgressListeners.size()).append("\n");
        return builder.toString();
    }

    /**
     * Returns the duration of the current state in milliseconds.
     *
     * @return The duration since the last state transition, in
     *         milliseconds
     */
    private long getStateDurationMs() {
        return SystemClock.elapsedRealtime() - mStateStartTime.get();
    }

    /**
     * Returns the time since the last heartbeat or progress report.
     *
     * @return The inactive time in milliseconds, or -1 when the
     *         controller is not in SYNCING
     */
    private long getInactiveTimeMs() {
        if (mCurrentState.get() != State.SYNCING) {
            return -1;
        }
        return SystemClock.elapsedRealtime() - mLastActivityTime.get();
    }

    /**
     * Stops the health check, cancels any pending recovery, resets every
     * state field, and clears the singleton reference.
     */
    public void shutdown() {
        Log.d(TAG, "Shutting down NavigationController");
        stopContinuousHealthCheck();
        cancelRecovery();
        forceReset();
        sInstance = null;
    }
}