package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.EnumSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Centralized controller for managing button states across all activities.
 * 
 * <p>This controller tracks active operations and manages which button groups
 * should be disabled. It uses PROGRESS-BASED staleness detection - operations
 * can run for hours as long as they report progress every 5 seconds.</p>
 * 
 * <p><b>Button Groups:</b></p>
 * <ul>
 *   <li>{@link ButtonGroup#DATABASE_ACTIONS} - PLAYLIST, METADATA buttons (MusicPlayer)</li>
 *   <li>{@link ButtonGroup#FOLDER_ACTIONS} - UPDATE, IMPORT, REMOVE buttons (FolderManager)</li>
 *   <li>{@link ButtonGroup#METADATA_ACTIONS} - MODIFY, UPDATE buttons (MetadataEditor)</li>
 * </ul>
 * 
 * <h3>Staleness Detection - Progress Based (No Duration Limit)</h3>
 * <p>Operations are considered "stuck" ONLY when they stop reporting progress.
 * There is NO maximum duration limit - operations can run for hours as long
 * as they send heartbeats or progress updates every 5 seconds.</p>
 * 
 * <ul>
 *   <li><b>5 Second Health Check:</b> Runs every 5 seconds to monitor operations</li>
 *   <li><b>Heartbeat Required:</b> Operations MUST call heartbeat() every 5 seconds</li>
 *   <li><b>Progress Tracking:</b> recordProgress() also resets the inactivity timer</li>
 *   <li><b>No Max Duration:</b> Operations can run indefinitely with activity</li>
 *   <li><b>Automatic Cleanup:</b> Only stuck operations (no activity for 5+ seconds) are terminated</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All operations are thread-safe using ConcurrentHashMap and CopyOnWriteArrayList.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Start a playlist sync operation
 * NavigationController.getInstance().beginPlaylistSync();
 * 
 * // IMPORTANT: Send heartbeat every 5 seconds during long operations
 * NavigationController.getInstance().heartbeat(Operation.PLAYLIST_SYNC);
 * 
 * // Or report progress (also resets inactivity timer)
 * NavigationController.getInstance().recordProgress(Operation.PLAYLIST_SYNC, current, total);
 * 
 * // End when complete
 * NavigationController.getInstance().endPlaylistSync();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NavigationController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "NavigationController";
    
    /** 
     * Health check interval in milliseconds (5 seconds).
     * The health checker runs at this frequency to detect stuck operations.
     */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000;
    
    /** 
     * Stuck detection timeout (5 seconds).
     * If an operation receives NO heartbeat or progress update for 5 seconds,
     * it is considered stuck and will be automatically terminated.
     * 
     * <p>There is NO maximum duration limit - operations can run for hours
     * as long as they send heartbeats every 5 seconds.</p>
     */
    private static final long STUCK_TIMEOUT_MS = 5000;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Button groups that can be independently disabled.
     */
    public enum ButtonGroup {
        
        /**
         * PLAYLIST and METADATA buttons in MusicPlayer.
         * The MANAGER button is excluded from this group.
         */
        DATABASE_ACTIONS,
        
        /**
         * UPDATE, IMPORT, and REMOVE (X) buttons in FolderManager.
         * These buttons modify the folder list and playlist.
         */
        FOLDER_ACTIONS,
        
        /**
         * MODIFY and UPDATE buttons in MetadataEditor.
         * These buttons modify audio file metadata.
         */
        METADATA_ACTIONS
    }
    
    /**
     * Operation types that affect button groups.
     */
    public enum Operation {
        
        /**
         * Playlist synchronization operation.
         * Affects DATABASE_ACTIONS and FOLDER_ACTIONS button groups.
         */
        PLAYLIST_SYNC(EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS)),
        
        /**
         * Metadata save operation.
         * Affects METADATA_ACTIONS button group.
         */
        METADATA_SAVE(EnumSet.of(ButtonGroup.METADATA_ACTIONS)),
        
        /**
         * Folder management operation (add/remove folders).
         * Affects FOLDER_ACTIONS button group.
         */
        FOLDER_UPDATE(EnumSet.of(ButtonGroup.FOLDER_ACTIONS));
        
        private final EnumSet<ButtonGroup> mAffectedGroups;
        
        Operation(EnumSet<ButtonGroup> affectedGroups) {
            this.mAffectedGroups = affectedGroups;
        }
        
        @NonNull
        public EnumSet<ButtonGroup> getAffectedGroups() {
            return mAffectedGroups;
        }
    }
    
    /**
     * Listener interface for button state changes.
     */
    public interface ButtonStateListener {
        
        /**
         * Called when a button group's disabled state changes.
         *
         * @param group The button group that changed
         * @param disabled True if buttons in this group should be disabled,
         *                 false if they should be enabled
         */
        void onButtonStateChanged(@NonNull ButtonGroup group, boolean disabled);
    }
    
    /**
     * Listener for operation staleness events.
     */
    public interface OperationListener {
        
        /**
         * Called when a stuck operation is detected and terminated.
         *
         * @param operation The operation that was stuck
         * @param inactiveTimeMs How long since last activity
         */
        void onOperationStuck(@NonNull Operation operation, long inactiveTimeMs);
        
        /**
         * Called when an operation completes normally.
         *
         * @param operation The operation that completed
         */
        void onOperationComplete(@NonNull Operation operation);
    }
    
    // ========================================================================
    // Operation Tracker (Progress-Based)
    // ========================================================================
    
    private static class OperationTracker {
        
        /** The operation being tracked. */
        final Operation operation;
        
        /** Timestamp when the operation started (for debugging only). */
        final long startTime;
        
        /** Last activity timestamp (heartbeat or progress update). */
        final AtomicLong lastActivityTime;
        
        /** Flag indicating if the operation is still active. */
        final AtomicBoolean isActive = new AtomicBoolean(true);
        
        /** Current progress value (for debugging). */
        volatile int currentProgress = 0;
        
        /** Total progress value (for debugging). */
        volatile int totalProgress = 0;
        
        /**
         * Constructs a new OperationTracker.
         *
         * @param operation The operation to track
         */
        OperationTracker(@NonNull Operation operation) {
            this.operation = operation;
            this.startTime = SystemClock.elapsedRealtime();
            this.lastActivityTime = new AtomicLong(this.startTime);
        }
        
        /**
         * Records activity for this operation, resetting the stuck timer.
         */
        void recordActivity() {
            lastActivityTime.set(SystemClock.elapsedRealtime());
        }
        
        /**
         * Records progress for this operation.
         *
         * @param current Current progress count
         * @param total Total expected (0 if unknown)
         */
        void recordProgress(int current, int total) {
            this.currentProgress = current;
            this.totalProgress = total;
            recordActivity();
        }
        
        /**
         * Returns the age of this operation in milliseconds (debugging only).
         *
         * @return Age in milliseconds
         */
        long getAgeMs() {
            return SystemClock.elapsedRealtime() - startTime;
        }
        
        /**
         * Returns the time since last activity in milliseconds.
         *
         * @return Time since last activity
         */
        long getInactiveTimeMs() {
            return SystemClock.elapsedRealtime() - lastActivityTime.get();
        }
        
        /**
         * Checks if this operation is stuck (no activity for 5+ seconds).
         *
         * @return True if the operation is stuck
         */
        boolean isStuck() {
            if (!isActive.get()) return false;
            return getInactiveTimeMs() > STUCK_TIMEOUT_MS;
        }
        
        /**
         * Returns the reason why this operation is stuck.
         *
         * @return The stuck reason, or null if not stuck
         */
        @Nullable
        String getStuckReason() {
            if (!isActive.get()) return null;
            if (isStuck()) {
                return "No activity for " + getInactiveTimeMs() + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
            }
            return null;
        }
        
        /**
         * Cancels this operation tracker.
         */
        void cancel() {
            isActive.set(false);
        }
    }
    
    // ========================================================================
    // Singleton - Continuous Health Check
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static NavigationController sInstance;
    
    /** Handler for main thread operations. */
    @NonNull
    private final Handler mMainHandler;
    
    /** Handler for health check operations. */
    @NonNull
    private final Handler mHealthHandler;
    
    /** Health check runnable. */
    @Nullable
    private Runnable mHealthCheckRunnable;
    
    /** Flag indicating if the health check is running. */
    private final AtomicBoolean mHealthCheckRunning = new AtomicBoolean(false);
    
    /** Lock for health check operations. */
    private final Object mHealthCheckLock = new Object();
    
    /** Count of active operations for each button group. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, AtomicInteger> mGroupOperationCounts = 
        new ConcurrentHashMap<>();
    
    /** Current disabled state for each button group (cached for performance). */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Boolean> mGroupDisabledState = 
        new ConcurrentHashMap<>();
    
    /** Registered button state listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ButtonStateListener> mButtonListeners = 
        new CopyOnWriteArrayList<>();
    
    /** Registered operation listeners. */
    @NonNull
    private final CopyOnWriteArrayList<OperationListener> mOperationListeners = 
        new CopyOnWriteArrayList<>();
    
    /** Active operation trackers. */
    @NonNull
    private final ConcurrentHashMap<Operation, OperationTracker> mActiveOperations = 
        new ConcurrentHashMap<>();
    
    /**
     * Private constructor - automatically starts continuous health check.
     */
    private NavigationController() {
        mMainHandler = new Handler(Looper.getMainLooper());
        mHealthHandler = new Handler(Looper.getMainLooper());
        startContinuousHealthCheck();
        Log.d(TAG, "NavigationController initialized with " + STUCK_TIMEOUT_MS + "ms stuck timeout");
    }
    
    /**
     * Returns the singleton instance of NavigationController.
     *
     * @return The singleton instance
     */
    @NonNull
    public static synchronized NavigationController getInstance() {
        if (sInstance == null) {
            sInstance = new NavigationController();
        }
        return sInstance;
    }
    
    // ========================================================================
    // Continuous Health Check (Runs Forever)
    // ========================================================================
    
    /**
     * Starts the continuous health check thread.
     * This runs FOREVER from app start to app shutdown, checking every 5 seconds.
     */
    private void startContinuousHealthCheck() {
        if (mHealthCheckRunning.getAndSet(true)) {
            return;
        }
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        
        mHealthHandler.post(mHealthCheckRunnable);
        Log.d(TAG, "Continuous health check started (interval: " + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }
    
    /**
     * Stops the continuous health check (called during shutdown).
     */
    private void stopContinuousHealthCheck() {
        if (!mHealthCheckRunning.getAndSet(false)) {
            return;
        }
        
        if (mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
        Log.d(TAG, "Continuous health check stopped");
    }
    
    /**
     * Performs health check on all active operations.
     * Automatically terminates any stuck operation (no activity for 5+ seconds).
     */
    private void performHealthCheck() {
        synchronized (mHealthCheckLock) {
            for (OperationTracker tracker : mActiveOperations.values()) {
                if (tracker.isActive.get() && tracker.isStuck()) {
                    String reason = tracker.getStuckReason();
                    Log.w(TAG, "Stuck operation detected: " + tracker.operation.name() + " - " + reason);
                    
                    notifyOperationStuck(tracker.operation, tracker.getInactiveTimeMs());
                    endOperation(tracker.operation);
                }
            }
        }
    }
    
    // ========================================================================
    // Public API - Operation Management
    // ========================================================================
    
    /**
     * Begins an operation. Automatically tracked for progress-based staleness detection.
     *
     * @param operation The operation to begin
     */
    public void beginOperation(@NonNull Operation operation) {
        Log.d(TAG, "beginOperation: " + operation.name());
        
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = new OperationTracker(operation);
            mActiveOperations.put(operation, tracker);
        }
        
        for (ButtonGroup group : operation.getAffectedGroups()) {
            int newCount = incrementGroupCount(group);
            if (newCount == 1) {
                setGroupDisabled(group, true);
            }
        }
    }
    
    /**
     * Ends an operation normally.
     *
     * @param operation The operation to end
     */
    public void endOperation(@NonNull Operation operation) {
        Log.d(TAG, "endOperation: " + operation.name());
        
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.remove(operation);
            if (tracker != null) {
                tracker.cancel();
            }
        }
        
        for (ButtonGroup group : operation.getAffectedGroups()) {
            int newCount = decrementGroupCount(group);
            if (newCount == 0) {
                setGroupDisabled(group, false);
            } else if (newCount < 0) {
                Log.w(TAG, "Group " + group.name() + " count below zero, resetting");
                mGroupOperationCounts.put(group, new AtomicInteger(0));
                setGroupDisabled(group, false);
            }
        }
        
        notifyOperationComplete(operation);
    }
    
    /**
     * Records a heartbeat for an operation, resetting its inactivity timer.
     * 
     * <p><b>IMPORTANT:</b> Long-running operations MUST call this method every
     * 5 seconds to prevent being considered stuck. Operations can run for
     * hours as long as heartbeats are sent.</p>
     *
     * @param operation The operation to send a heartbeat for
     * @return True if the operation is active and heartbeat was recorded
     */
    public boolean heartbeat(@NonNull Operation operation) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            if (tracker != null && tracker.isActive.get()) {
                tracker.recordActivity();
                Log.v(TAG, "Heartbeat received for " + operation.name());
                return true;
            }
            return false;
        }
    }
    
    /**
     * Records progress for an operation, resetting its inactivity timer.
     *
     * @param operation The operation making progress
     * @param current Current progress count
     * @param total Total expected (0 if unknown)
     */
    public void recordProgress(@NonNull Operation operation, int current, int total) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            if (tracker != null && tracker.isActive.get()) {
                tracker.recordProgress(current, total);
                Log.v(TAG, "Progress recorded for " + operation.name() + ": " + current + "/" + total);
            }
        }
    }
    
    /**
     * Checks if an operation is currently active.
     *
     * @param operation The operation to check
     * @return True if the operation is active
     */
    public boolean isOperationActive(@NonNull Operation operation) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            return tracker != null && tracker.isActive.get();
        }
    }
    
    /**
     * Checks if an operation is stuck (no activity for 5+ seconds).
     *
     * @param operation The operation to check
     * @return True if the operation is stuck
     */
    public boolean isOperationStuck(@NonNull Operation operation) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            return tracker != null && tracker.isActive.get() && tracker.isStuck();
        }
    }
    
    /**
     * Returns the time since last activity for an operation in milliseconds.
     *
     * @param operation The operation to check
     * @return Time since last activity, or -1 if operation not active
     */
    public long getInactiveTimeMs(@NonNull Operation operation) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            return tracker != null ? tracker.getInactiveTimeMs() : -1;
        }
    }
    
    /**
     * Gets the current progress of an operation.
     *
     * @param operation The operation to check
     * @return Array of [current, total], or null if operation not active
     */
    @Nullable
    public int[] getOperationProgress(@NonNull Operation operation) {
        synchronized (mHealthCheckLock) {
            OperationTracker tracker = mActiveOperations.get(operation);
            if (tracker != null && tracker.isActive.get()) {
                return new int[]{tracker.currentProgress, tracker.totalProgress};
            }
            return null;
        }
    }
    
    /**
     * Checks if a button group is currently disabled.
     *
     * @param group The button group to check
     * @return True if the group should be disabled
     */
    public boolean isGroupDisabled(@NonNull ButtonGroup group) {
        Boolean cached = mGroupDisabledState.get(group);
        return cached != null && cached;
    }
    
    /**
     * Returns the current operation count for a button group.
     *
     * @param group The button group
     * @return The current operation count
     */
    public int getGroupOperationCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        return counter != null ? counter.get() : 0;
    }
    
    /**
     * Returns debug information about all active operations.
     *
     * @return Debug information string
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("NavigationController Debug Info:\n");
        sb.append("  Stuck timeout: ").append(STUCK_TIMEOUT_MS).append("ms\n");
        sb.append("  Active operations: ").append(mActiveOperations.size()).append("\n");
        
        for (OperationTracker tracker : mActiveOperations.values()) {
            sb.append("    - ").append(tracker.operation.name())
              .append(" (age: ").append(tracker.getAgeMs()).append("ms")
              .append(", inactive: ").append(tracker.getInactiveTimeMs()).append("ms")
              .append(", progress: ").append(tracker.currentProgress).append("/").append(tracker.totalProgress)
              .append(", stuck: ").append(tracker.isStuck()).append(")\n");
        }
        
        sb.append("  Group states:\n");
        for (ButtonGroup group : ButtonGroup.values()) {
            int count = getGroupOperationCount(group);
            boolean disabled = isGroupDisabled(group);
            sb.append("    - ").append(group.name())
              .append(": count=").append(count)
              .append(", disabled=").append(disabled).append("\n");
        }
        
        sb.append("  Button listeners: ").append(mButtonListeners.size()).append("\n");
        sb.append("  Operation listeners: ").append(mOperationListeners.size()).append("\n");
        
        return sb.toString();
    }
    
    // ========================================================================
    // Private State Management
    // ========================================================================
    
    /**
     * Increments the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after increment
     */
    private int incrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            counter = new AtomicInteger(0);
            mGroupOperationCounts.put(group, counter);
        }
        return counter.incrementAndGet();
    }
    
    /**
     * Decrements the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after decrement
     */
    private int decrementGroupCount(@NonNull ButtonGroup group) {
        AtomicInteger counter = mGroupOperationCounts.get(group);
        if (counter == null) {
            Log.w(TAG, "No counter found for group: " + group.name());
            return -1;
        }
        return counter.decrementAndGet();
    }
    
    /**
     * Sets the disabled state for a button group and notifies all listeners.
     *
     * @param group The button group
     * @param disabled True to disable, false to enable
     */
    private void setGroupDisabled(@NonNull ButtonGroup group, boolean disabled) {
        Boolean current = mGroupDisabledState.get(group);
        if (current != null && current == disabled) {
            return;
        }
        
        mGroupDisabledState.put(group, disabled);
        Log.d(TAG, "Group " + group.name() + " " + (disabled ? "DISABLED" : "ENABLED"));
        
        for (ButtonStateListener listener : mButtonListeners) {
            try {
                listener.onButtonStateChanged(group, disabled);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying button listener", e);
            }
        }
    }
    
    // ========================================================================
    // Listener Management
    // ========================================================================
    
    /**
     * Registers a button state listener.
     * Immediately receives current state for all button groups.
     *
     * @param listener The listener to register
     */
    public void registerListener(@NonNull ButtonStateListener listener) {
        if (!mButtonListeners.contains(listener)) {
            mButtonListeners.add(listener);
            // Immediately notify current state
            for (ButtonGroup group : ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group));
            }
        }
    }
    
    /**
     * Unregisters a button state listener.
     *
     * @param listener The listener to unregister
     */
    public void unregisterListener(@NonNull ButtonStateListener listener) {
        mButtonListeners.remove(listener);
    }
    
    /**
     * Adds an operation listener for staleness events.
     *
     * @param listener The listener to add
     */
    public void addOperationListener(@NonNull OperationListener listener) {
        mOperationListeners.add(listener);
    }
    
    /**
     * Removes an operation listener.
     *
     * @param listener The listener to remove
     */
    public void removeOperationListener(@NonNull OperationListener listener) {
        mOperationListeners.remove(listener);
    }
    
    /**
     * Notifies all operation listeners that an operation is stuck.
     *
     * @param operation The stuck operation
     * @param inactiveTimeMs How long since last activity
     */
    private void notifyOperationStuck(@NonNull Operation operation, long inactiveTimeMs) {
        for (OperationListener listener : mOperationListeners) {
            try {
                listener.onOperationStuck(operation, inactiveTimeMs);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying operation listener", e);
            }
        }
    }
    
    /**
     * Notifies all operation listeners that an operation completed.
     *
     * @param operation The completed operation
     */
    private void notifyOperationComplete(@NonNull Operation operation) {
        for (OperationListener listener : mOperationListeners) {
            try {
                listener.onOperationComplete(operation);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying operation listener", e);
            }
        }
    }
    
    // ========================================================================
    // Convenience Methods
    // ========================================================================
    
    /**
     * Convenience method to begin a playlist sync operation.
     */
    public void beginPlaylistSync() {
        beginOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to end a playlist sync operation.
     */
    public void endPlaylistSync() {
        endOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to begin a metadata save operation.
     */
    public void beginMetadataSave() {
        beginOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to end a metadata save operation.
     */
    public void endMetadataSave() {
        endOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to begin a folder update operation.
     */
    public void beginFolderUpdate() {
        beginOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Convenience method to end a folder update operation.
     */
    public void endFolderUpdate() {
        endOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Forces end of all active operations and clears all state.
     * Use as last resort when operations are stuck.
     */
    public void forceEndAllOperations() {
        Log.w(TAG, "forceEndAllOperations - resetting all button states");
        
        synchronized (mHealthCheckLock) {
            for (OperationTracker tracker : mActiveOperations.values()) {
                tracker.cancel();
            }
            mActiveOperations.clear();
        }
        
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupOperationCounts.put(group, new AtomicInteger(0));
            if (isGroupDisabled(group)) {
                setGroupDisabled(group, false);
            }
        }
        
        Log.d(TAG, "forceEndAllOperations completed - all groups enabled");
    }
    
    /**
     * Shuts down the NavigationController and releases resources.
     */
    public void shutdown() {
        Log.d(TAG, "Shutting down NavigationController");
        stopContinuousHealthCheck();
        forceEndAllOperations();
        sInstance = null;
    }
}