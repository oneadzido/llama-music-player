package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Dialog for selecting a theme color.
 * 
 * <p>This dialog displays a scrollable list of available theme colors with
 * color preview circles. The current theme is highlighted with a "CURRENT"
 * indicator and the color circle becomes invisible for the selected theme.
 * When a user selects a theme, the dialog animates and notifies the listener.</p>
 * 
 * <p>Features:
 * <ul>
 *   <li>Scrollable list of 30 theme colors across multiple color families</li>
 *   <li>Color preview circles for each theme</li>
 *   <li>Visual highlight for the currently selected theme</li>
 *   <li>Smooth scrolling to the current theme on dialog open</li>
 *   <li>Touch feedback animations for list items</li>
 *   <li>Debounced click handling to prevent rapid selections</li>
 *   <li>Slide-up animation for dialog entrance/exit</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>Dismiss delay uses Handler.postDelayed().
 * All UI operations are on the main thread.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class ThemeDialog extends Dialog {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";
    
    /** Header background color (slightly lighter than main background). */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";
    
    /** Background color for the currently selected theme item. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";
    
    /** Highlight color for touch feedback when pressing a list item. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    /** Light gray text color for secondary and header text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Debounce delay for button clicks to prevent rapid multiple presses. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before dialog dismiss after theme selection (allows animation to complete). */
    private static final long DISMISS_DELAY_MS = 500;
    
    /** Duration of button press and selection animations in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Size of color preview circles in density-independent pixels. */
    private static final int COLOR_CIRCLE_SIZE_DP = 24;
    
    /** Stroke width for color preview circles in density-independent pixels. */
    private static final int COLOR_CIRCLE_STROKE_WIDTH_DP = 1;
    
    /** Height of the top action bar in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;
    
    /** Height of the header bar (with "THEME LIST" and count) in dp. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;
    
    /** Height of action buttons in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;
    
    /** Header padding horizontal in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;
    
    /** Header padding vertical in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;
    
    /** List item padding horizontal in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_HORIZONTAL_DP = 16;
    
    /** List item padding vertical in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_VERTICAL_DP = 12;
    
    /** Padding for the "CURRENT" indicator text in dp. */
    private static final int INDICATOR_PADDING_DP = 8;
    
    /** Bottom padding for the dialog in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 8;
    
    /** Thickness of dividers between list items in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;
    
    /** Left margin for color preview circles in density-independent pixels. */
    private static final int COLOR_CIRCLE_MARGIN_LEFT_DP = 8;
    
    /** Right margin for color preview circles in density-independent pixels. */
    private static final int COLOR_CIRCLE_MARGIN_RIGHT_DP = 16;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for accessing resources and services. */
    private final Context mContext;
    
    /** Array of theme color names to display in the list. */
    private final String[] mColorNames;
    
    /** Array of theme color hex values corresponding to the names. */
    private final String[] mColorValues;
    
    /** Index of the currently selected theme. */
    private final int mCurrentColorIndex;
    
    /** Listener for theme selection events (can be null). */
    @Nullable
    private final OnThemeSelectedListener mListener;
    
    /** ScrollView containing the theme list. */
    private ScrollView mScrollView;
    
    /** LinearLayout containing all theme items. */
    private LinearLayout mThemeList;
    
    /** Theme manager for accessing current theme color. */
    private final ThemeManager mThemeManager;
    
    /** Theme helper for applying theme to UI components. */
    private final ThemeHelper mThemeHelper;
    
    /** Timestamp of the last selection (for debouncing). */
    private long mLastSelectionTime = 0;
    
    /** Timestamp of the last cancel click (for debouncing). */
    private long mLastCancelClickTime = 0;
    
    /** Handler for posting delayed tasks on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for theme selection events.
     */
    public interface OnThemeSelectedListener {
        
        /**
         * Called when a theme is selected from the dialog.
         *
         * @param colorIndex The index of the selected theme in the colors arrays
         * @param colorName The name of the selected theme
         * @param colorValue The hex color value of the selected theme
         */
        void onThemeSelected(int colorIndex, @NonNull String colorName, @NonNull String colorValue);
    }

    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new ThemeDialog.
     *
     * @param context The application context
     * @param colorNames Array of theme color names to display
     * @param colorValues Array of theme color hex values
     * @param currentColorIndex The index of the currently selected theme
     * @param listener Listener for theme selection events (can be null)
     */
    public ThemeDialog(@NonNull Context context, @NonNull String[] colorNames, 
                       @NonNull String[] colorValues, int currentColorIndex, 
                       @Nullable OnThemeSelectedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mColorNames = colorNames;
        mColorValues = colorValues;
        mCurrentColorIndex = currentColorIndex;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ========================================================================
    // Dialog Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the dialog is being created.
     * Sets up the UI, configures the window, and initializes the theme list.
     *
     * @param savedInstanceState Saved instance state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());
        
        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }
        
        scrollToCurrentTheme();
        applyThemeToButtons();
    }
    
    /**
     * Called when the dialog is dismissed.
     * Cleans up handler callbacks.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Window Configuration Methods
    // ========================================================================
    
    /**
     * Configures the dialog window properties for full-screen display.
     * Sets status bar color, navigation bar color, and window animations.
     *
     * @param window The dialog window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }
        
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PresetDialogAnimation);
    }

    // ========================================================================
    // Theme Management Methods
    // ========================================================================
    
    /**
     * Applies theme colors to all buttons in the dialog.
     * Recursively traverses the view hierarchy to find and theme buttons.
     */
    private void applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            findAndThemeButtons((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively finds and themes all buttons in a view hierarchy.
     *
     * @param group The ViewGroup to process
     */
    private void findAndThemeButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                findAndThemeButtons((ViewGroup) child);
            }
        }
    }

    /**
     * Updates the visual selection state of theme items.
     * Highlights the newly selected theme and clears the previous selection.
     *
     * @param newSelectedIndex The index of the newly selected theme
     */
    private void updateSelectedTheme(int newSelectedIndex) {
        for (int index = 0; index < mThemeList.getChildCount(); index++) {
            View child = mThemeList.getChildAt(index);
            
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                LinearLayout item = (LinearLayout) child;
                int themeIndex = (Integer) item.getTag();
                boolean isSelected = (themeIndex == newSelectedIndex);
                
                item.setBackgroundColor(isSelected 
                    ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
                    : Color.TRANSPARENT);
                
                TextView name = null;
                View colorCircle = null;
                TextView indicator = null;
                
                for (int childIndex = 0; childIndex < item.getChildCount(); childIndex++) {
                    View childView = item.getChildAt(childIndex);
                    if (childView instanceof TextView) {
                        if (name == null) {
                            name = (TextView) childView;
                        } else {
                            indicator = (TextView) childView;
                        }
                    } else {
                        colorCircle = childView;
                    }
                }
                
                if (name != null && themeIndex < mColorValues.length) {
                    name.setTextColor(isSelected 
                        ? Color.parseColor(mColorValues[themeIndex]) 
                        : Color.parseColor(TEXT_COLOR_LIGHT));
                }
                
                if (indicator != null) {
                    if (isSelected && themeIndex < mColorValues.length) {
                        indicator.setText("CURRENT");
                        indicator.setTextColor(Color.parseColor(mColorValues[themeIndex]));
                        indicator.setPadding(dpToPx(INDICATOR_PADDING_DP), 0, dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), 0);
                    } else {
                        indicator.setText("");
                        indicator.setPadding(0, 0, 0, 0);
                    }
                }
                
                if (colorCircle != null) {
                    colorCircle.setVisibility(isSelected ? View.INVISIBLE : View.VISIBLE);
                }
            }
        }
    }

    // ========================================================================
    // Animation Methods
    // ========================================================================
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% on touch and returns to normal on release.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Animates the theme selection and dismisses the dialog.
     * Plays a bounce animation on the selected item, then notifies the listener.
     *
     * @param view The selected theme item view
     * @param colorIndex The index of the selected theme
     * @param colorName The name of the selected theme
     * @param colorValue The hex value of the selected theme
     */
    private void animateThemeSelection(@NonNull final View view, final int colorIndex, 
                                       @NonNull final String colorName, 
                                       @NonNull final String colorValue) {
        updateSelectedTheme(colorIndex);
        
        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                      .scaleY(ANIMATION_SCALE_DOWN)
                      .setDuration(ANIMATION_DURATION_MS)
                      .withEndAction(new Runnable() {
                          @Override
                          public void run() {
                              view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                            .scaleY(ANIMATION_SCALE_NORMAL)
                                            .setDuration(ANIMATION_DURATION_MS)
                                            .start();
                          }
                      })
                      .start();
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    mListener.onThemeSelected(colorIndex, colorName, colorValue);
                }
                dismiss();
            }
        }, DISMISS_DELAY_MS);
    }

    // ========================================================================
    // Scrolling Methods
    // ========================================================================
    
    /**
     * Scrolls the list to show the currently selected theme.
     * Centers the selected theme vertically within the ScrollView.
     */
    private void scrollToCurrentTheme() {
        if (mScrollView == null || mThemeList == null || mCurrentColorIndex < 0) return;
        
        mScrollView.post(new Runnable() {
            @Override
            public void run() {
                int targetIndex = findThemeIndex();
                if (targetIndex >= 0) {
                    final View target = mThemeList.getChildAt(targetIndex);
                    if (target != null) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int scrollViewHeight = mScrollView.getHeight();
                                int targetTop = target.getTop();
                                int targetHeight = target.getHeight();
                                int scrollY = targetTop - (scrollViewHeight / 2) + (targetHeight / 2);
                                mScrollView.smoothScrollTo(0, Math.max(0, scrollY));
                            }
                        }, 0);
                    }
                }
            }
        });
    }

    /**
     * Finds the index of the currently selected theme in the list view.
     *
     * @return The index in the list, or -1 if not found
     */
    private int findThemeIndex() {
        for (int index = 0; index < mThemeList.getChildCount(); index++) {
            View child = mThemeList.getChildAt(index);
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                if ((Integer) child.getTag() == mCurrentColorIndex) {
                    return index;
                }
            }
        }
        return -1;
    }

    // ========================================================================
    // UI Construction Methods
    // ========================================================================
    
    /**
     * Creates the main content view for the dialog.
     * Builds the complete dialog layout programmatically.
     *
     * @return The root view of the dialog
     */
    @NonNull
    private View createContentView() {
        LinearLayout main = new LinearLayout(mContext);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[]{20, 20, 20, 20, 0, 0, 0, 0});
        main.setBackground(background);
        
        main.addView(createTopBar());
        main.addView(createHeader());
        main.addView(createScrollableList());
        main.addView(createBottomPadding());
        
        return main;
    }

    /**
     * Creates the top action bar with Cancel button and title.
     *
     * @return The top bar RelativeLayout
     */
    @NonNull
    private RelativeLayout createTopBar() {
        RelativeLayout topBar = new RelativeLayout(mContext);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP), 
            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createPlaceholder());
        
        return topBar;
    }

    /**
     * Creates the Cancel button for closing the dialog.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText("CANCEL");
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3), 
            dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);
        
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.ALIGN_PARENT_START);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        button.setLayoutParams(params);
        
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });
        
        animateButton(button);
        return button;
    }

    /**
     * Creates the title text view for the top bar.
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(mContext);
        textView.setText("THEMES");
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);
        
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        textView.setLayoutParams(params);
        
        return textView;
    }

    /**
     * Creates a placeholder view for layout balance on the right side.
     *
     * @return The placeholder view
     */
    @NonNull
    private View createPlaceholder() {
        View placeholder = new View(mContext);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_END);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        placeholder.setLayoutParams(params);
        return placeholder;
    }

    /**
     * Creates the header bar showing "THEME LIST" and theme count.
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP), 
            dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        
        TextView headerTitle = new TextView(mContext);
        headerTitle.setText("THEME LIST");
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        
        TextView headerCount = new TextView(mContext);
        headerCount.setText(mColorNames.length + " themes");
        headerCount.setTextSize(12);
        headerCount.setLetterSpacing(0.1f);
        headerCount.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        
        header.addView(headerTitle);
        header.addView(headerCount);
        
        return header;
    }

    /**
     * Creates the scrollable theme list container.
     *
     * @return The ScrollView containing all theme items
     */
    @NonNull
    private ScrollView createScrollableList() {
        mScrollView = new ScrollView(mContext);
        mScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        mScrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        mThemeList = new LinearLayout(mContext);
        mThemeList.setOrientation(LinearLayout.VERTICAL);
        mThemeList.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        
        for (int themeIndex = 0; themeIndex < mColorNames.length; themeIndex++) {
            final int index = themeIndex;
            final String name = mColorNames[themeIndex];
            final String value = mColorValues[themeIndex];
            final boolean selected = (themeIndex == mCurrentColorIndex);
            
            final LinearLayout item = createThemeItem(index, name, value, selected);
            mThemeList.addView(item);
            
            if (themeIndex < mColorNames.length - 1) {
                mThemeList.addView(createDivider());
            }
        }
        
        mScrollView.addView(mThemeList);
        return mScrollView;
    }

    /**
     * Creates a single theme item for the list.
     *
     * @param themeIndex The theme index in the colors arrays
     * @param name The display name of the theme
     * @param value The hex color value of the theme
     * @param selected True if this theme is currently selected
     * @return The theme item layout
     */
    @NonNull
    private LinearLayout createThemeItem(final int themeIndex, @NonNull final String name, 
                                          @NonNull final String value, final boolean selected) {
        final LinearLayout item = new LinearLayout(mContext);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setPadding(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP), 
            dpToPx(0), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        item.setTag(themeIndex);
        item.setBackgroundColor(selected 
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
            : Color.TRANSPARENT);
        
        item.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        int tagIndex = (Integer) item.getTag();
                        view.setBackgroundColor(tagIndex == mCurrentColorIndex 
                            ? Color.parseColor(SELECTED_BACKGROUND_COLOR) 
                            : Color.TRANSPARENT);
                        break;
                }
                return false;
            }
        });
        
        TextView nameView = new TextView(mContext);
        nameView.setText(name);
        nameView.setTextSize(14);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setTextColor(selected 
            ? Color.parseColor(value) 
            : Color.parseColor(TEXT_COLOR_LIGHT));
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        
        View colorCircle = createColorCircle(value, selected);
        
        TextView indicator = new TextView(mContext);
        if (selected) {
            indicator.setText("CURRENT");
            indicator.setTextSize(10);
            indicator.setLetterSpacing(0.1f);
            indicator.setTextColor(Color.parseColor(value));
            indicator.setPadding(dpToPx(INDICATOR_PADDING_DP), 0, dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), 0);
        }
        indicator.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        item.addView(nameView);
        item.addView(colorCircle);
        item.addView(indicator);
        
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSelectionTime = currentTime;
                    animateThemeSelection(item, themeIndex, name, value);
                }
            }
        });
        
        return item;
    }

    /**
     * Creates a color preview circle view.
     *
     * @param colorHex The hex color value for the circle
     * @param isSelected True if this theme is selected (circle becomes invisible)
     * @return The color circle view
     */
    @NonNull
    private View createColorCircle(@NonNull String colorHex, boolean isSelected) {
        View circle = new View(mContext);
        int size = dpToPx(COLOR_CIRCLE_SIZE_DP);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        params.leftMargin = dpToPx(COLOR_CIRCLE_MARGIN_LEFT_DP);
        params.rightMargin = dpToPx(COLOR_CIRCLE_MARGIN_RIGHT_DP);
        circle.setLayoutParams(params);
        
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(Color.parseColor(colorHex));
        drawable.setStroke(dpToPx(COLOR_CIRCLE_STROKE_WIDTH_DP), 
            Color.parseColor(TEXT_COLOR_LIGHT));
        circle.setBackground(drawable);
        
        if (isSelected) {
            circle.setVisibility(View.INVISIBLE);
        }
        
        return circle;
    }

    /**
     * Creates a divider view to separate list items.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates bottom padding to ensure comfortable scrolling at the end of the list.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}