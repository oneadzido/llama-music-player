package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Presents the available theme colors in a scrollable list and reports
 * the user's selection through {@link OnThemeSelectedListener}.
 *
 * <p>Each row shows the theme's display name, a color preview circle,
 * and a "CURRENT" indicator on the row of the currently applied theme.
 * The preview circle for the current theme is hidden, and the color of
 * the row's text matches the theme the row represents. When the dialog
 * opens, the current theme is scrolled into the vertical center of the
 * list. Tapping a row animates the row and then notifies the listener
 * before dismissing the dialog.</p>
 *
 * <h3>Top Bar Geometry</h3>
 * <p>The top bar uses {@link #PADDING_STANDARD_DP} on all four sides, the
 * same as {@code CreditsDialog} and {@code PresetDialog}. Every dialog in
 * the app uses the same top-bar geometry so the CANCEL button measures
 * and positions identically across all of them.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. Delayed work is scheduled on
 * {@link #mMainHandler}.</p>
 *
 * @see ThemeManager
 * @see ThemeHelper
 * @see PresetDialog
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class ThemeDialog extends Dialog {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Header background color, slightly lighter than the main background. */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";

    /** Background color of the currently selected theme row. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";

    /** Touch highlight color applied to a pressed list row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for headers and secondary text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before dismissing the dialog after a selection, in milliseconds. */
    private static final long DISMISS_DELAY_MS = 500;

    /** Duration of button press and selection animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Diameter of the color preview circle, in density-independent pixels. */
    private static final int COLOR_CIRCLE_SIZE_DP = 24;

    /** Stroke width of the color preview circle, in density-independent pixels. */
    private static final int COLOR_CIRCLE_STROKE_WIDTH_DP = 1;

    /** Height of the top action bar, in density-independent pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of the header bar, in density-independent pixels. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;

    /** Height of action buttons, in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Standard padding for the top bar, in density-independent pixels. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Horizontal padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of the header, in density-independent pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;

    /** Horizontal padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of a list row, in density-independent pixels. */
    private static final int LIST_ITEM_PADDING_VERTICAL_DP = 12;

    /** Padding around the "CURRENT" indicator text, in density-independent pixels. */
    private static final int INDICATOR_PADDING_DP = 8;

    /** Bottom padding of the dialog, in density-independent pixels. */
    private static final int BOTTOM_PADDING_DP = 8;

    /** Thickness of dividers between rows, in density-independent pixels. */
    private static final int DIVIDER_THICKNESS_DP = 1;

    /** Left margin of the color preview circle, in density-independent pixels. */
    private static final int COLOR_CIRCLE_MARGIN_LEFT_DP = 8;

    /** Right margin of the color preview circle, in density-independent pixels. */
    private static final int COLOR_CIRCLE_MARGIN_RIGHT_DP = 16;

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Context used to resolve resources and construct views. */
    private final Context mContext;

    /** Display names of the themes shown in the list. */
    private final String[] mColorNames;

    /** Hex color values of the themes, index-aligned with {@link #mColorNames}. */
    private final String[] mColorValues;

    /** Index of the theme currently applied. */
    private final int mCurrentColorIndex;

    /** Listener notified when a theme is selected, or null. */
    @Nullable
    private final OnThemeSelectedListener mListener;

    /** Scroll view that contains the theme list. */
    private ScrollView mScrollView;

    /** Container that holds every theme row. */
    private LinearLayout mThemeList;

    /** Manager that supplies the current theme color. */
    private final ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    private final ThemeHelper mThemeHelper;

    /** Timestamp of the last selection, used for debouncing. */
    private long mLastSelectionTime = 0;

    /** Timestamp of the last cancel click, used for debouncing. */
    private long mLastCancelClickTime = 0;

    /** Handler for delayed tasks on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Receives theme selection events.
     */
    public interface OnThemeSelectedListener {

        /**
         * Called when the user selects a theme.
         *
         * @param colorIndex Index of the selected theme in the color
         *        arrays
         * @param colorName Name of the selected theme
         * @param colorValue Hex color value of the selected theme
         */
        void onThemeSelected(int colorIndex, @NonNull String colorName,
                             @NonNull String colorValue);
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the dialog.
     *
     * @param context Context used to resolve resources and construct
     *        views
     * @param colorNames Theme display names shown in the list
     * @param colorValues Theme hex color values, index-aligned with
     *        {@code colorNames}
     * @param currentColorIndex Index of the theme currently applied
     * @param listener Listener notified when a theme is selected, or
     *        null
     */
    public ThemeDialog(@NonNull Context context, @NonNull String[] colorNames,
                       @NonNull String[] colorValues, int currentColorIndex,
                       @Nullable OnThemeSelectedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mColorNames = colorNames;
        mColorValues = colorValues;
        mCurrentColorIndex = currentColorIndex;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
    }

    // ========================================================================
    // Dialog Lifecycle Methods
    // ========================================================================

    /**
     * Initializes the dialog's window, content view, and theme list.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createContentView());

        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }

        scrollToCurrentTheme();
        applyThemeToButtons();
    }

    /**
     * Dismisses the dialog and removes every pending handler callback.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMainHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Window Configuration Methods
    // ========================================================================

    /**
     * Configures the dialog window for full-screen display.
     *
     * @param window Window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }

        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PresetDialogAnimation);
    }

    // ========================================================================
    // Theme Management Methods
    // ========================================================================

    /**
     * Applies the current theme color to every button in the dialog.
     */
    private void applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            findAndThemeButtons((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the current theme to every button in the given
     * view hierarchy.
     *
     * @param group View group to traverse
     */
    private void findAndThemeButtons(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child instanceof Button) {
                mThemeHelper.updateButton((Button) child, true);
            } else if (child instanceof ViewGroup) {
                findAndThemeButtons((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the selection styling to the given theme row and clears
     * the styling from every other row.
     *
     * <p>The selected row receives the current theme's color for its
     * name and indicator, and its preview circle is hidden. Every other
     * row receives the light text color and a visible preview
     * circle.</p>
     *
     * @param newSelectedIndex Index of the newly selected theme
     */
    private void updateSelectedTheme(int newSelectedIndex) {
        for (int index = 0; index < mThemeList.getChildCount(); index++) {
            View child = mThemeList.getChildAt(index);

            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                LinearLayout item = (LinearLayout) child;
                int themeIndex = (Integer) item.getTag();
                boolean isSelected = (themeIndex == newSelectedIndex);

                item.setBackgroundColor(isSelected
                    ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                    : Color.TRANSPARENT);

                TextView name = null;
                View colorCircle = null;
                TextView indicator = null;

                for (int childIndex = 0; childIndex < item.getChildCount(); childIndex++) {
                    View childView = item.getChildAt(childIndex);
                    if (childView instanceof TextView) {
                        if (name == null) {
                            name = (TextView) childView;
                        } else {
                            indicator = (TextView) childView;
                        }
                    } else {
                        colorCircle = childView;
                    }
                }

                if (name != null && themeIndex < mColorValues.length) {
                    name.setTextColor(isSelected
                        ? Color.parseColor(mColorValues[themeIndex])
                        : Color.parseColor(TEXT_COLOR_LIGHT));
                }

                if (indicator != null) {
                    if (isSelected && themeIndex < mColorValues.length) {
                        indicator.setText("CURRENT");
                        indicator.setTextColor(Color.parseColor(mColorValues[themeIndex]));
                        indicator.setPadding(dpToPx(INDICATOR_PADDING_DP), 0,
                            dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), 0);
                    } else {
                        indicator.setText("");
                        indicator.setPadding(0, 0, 0, 0);
                    }
                }

                if (colorCircle != null) {
                    colorCircle.setVisibility(isSelected ? View.INVISIBLE : View.VISIBLE);
                }
            }
        }
    }

    // ========================================================================
    // Animation Methods
    // ========================================================================

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Applies the selection styling, plays a bounce animation on the
     * given row, then notifies the listener and dismisses the dialog.
     *
     * @param view Selected theme row
     * @param colorIndex Index of the selected theme
     * @param colorName Name of the selected theme
     * @param colorValue Hex value of the selected theme
     */
    private void animateThemeSelection(@NonNull final View view, final int colorIndex,
                                       @NonNull final String colorName,
                                       @NonNull final String colorValue) {
        updateSelectedTheme(colorIndex);

        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                      .scaleY(ANIMATION_SCALE_DOWN)
                      .setDuration(ANIMATION_DURATION_MS)
                      .withEndAction(new Runnable() {
                          @Override
                          public void run() {
                              view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                            .scaleY(ANIMATION_SCALE_NORMAL)
                                            .setDuration(ANIMATION_DURATION_MS)
                                            .start();
                          }
                      })
                      .start();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    mListener.onThemeSelected(colorIndex, colorName, colorValue);
                }
                dismiss();
            }
        }, DISMISS_DELAY_MS);
    }

    // ========================================================================
    // Scrolling Methods
    // ========================================================================

    /**
     * Scrolls the list so the current theme appears in the vertical
     * center of the scroll view.
     */
    private void scrollToCurrentTheme() {
        if (mScrollView == null || mThemeList == null || mCurrentColorIndex < 0) {
            return;
        }

        mScrollView.post(new Runnable() {
            @Override
            public void run() {
                int targetIndex = findThemeIndex();
                if (targetIndex >= 0) {
                    final View target = mThemeList.getChildAt(targetIndex);
                    if (target != null) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int scrollViewHeight = mScrollView.getHeight();
                                int targetTop = target.getTop();
                                int targetHeight = target.getHeight();
                                int scrollY = targetTop
                                    - (scrollViewHeight / 2) + (targetHeight / 2);
                                mScrollView.smoothScrollTo(0, Math.max(0, scrollY));
                            }
                        }, 0);
                    }
                }
            }
        });
    }

    /**
     * Returns the index of the current theme within the list view.
     *
     * @return Index of the current theme in the list, or -1 when it is
     *         not present
     */
    private int findThemeIndex() {
        for (int index = 0; index < mThemeList.getChildCount(); index++) {
            View child = mThemeList.getChildAt(index);
            if (child instanceof LinearLayout && child.getTag() instanceof Integer) {
                if ((Integer) child.getTag() == mCurrentColorIndex) {
                    return index;
                }
            }
        }
        return -1;
    }

    // ========================================================================
    // UI Construction Methods
    // ========================================================================

    /**
     * Creates the root content view of the dialog.
     *
     * @return The root view
     */
    @NonNull
    private View createContentView() {
        LinearLayout main = new LinearLayout(mContext);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(new float[] {20, 20, 20, 20, 0, 0, 0, 0});
        main.setBackground(background);

        main.addView(createTopBar());
        main.addView(createHeader());
        main.addView(createScrollableList());
        main.addView(createBottomPadding());

        return main;
    }

    /**
     * Creates the top action bar with a Cancel button and a title.
     *
     * <p>Uses {@link #PADDING_STANDARD_DP} on all four sides, matching
     * the top bar geometry of {@code CreditsDialog} and
     * {@code PresetDialog} so the CANCEL button measures and positions
     * identically across the three.</p>
     *
     * @return The top bar layout
     */
    @NonNull
    private RelativeLayout createTopBar() {
        RelativeLayout topBar = new RelativeLayout(mContext);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP)));
        topBar.setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP));
        topBar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        topBar.addView(createCancelButton());
        topBar.addView(createTitleText());
        topBar.addView(createPlaceholder());

        return topBar;
    }

    /**
     * Creates the Cancel button that closes the dialog.
     *
     * @return The Cancel button
     */
    @NonNull
    private Button createCancelButton() {
        Button button = new Button(mContext);
        button.setText("CANCEL");
        button.setTextSize(14);
        button.setLetterSpacing(0.1f);
        button.setBackgroundResource(R.drawable.button_border_selector);
        button.setPadding(dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3),
            dpToPx(INDICATOR_PADDING_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3));
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.ALIGN_PARENT_START);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        button.setLayoutParams(params);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastCancelClickTime = currentTime;
                    dismiss();
                }
            }
        });

        animateButton(button);
        return button;
    }

    /**
     * Creates the title text view for the top bar.
     *
     * @return The title text view
     */
    @NonNull
    private TextView createTitleText() {
        TextView textView = new TextView(mContext);
        textView.setText("THEMES");
        textView.setTextSize(14);
        textView.setLetterSpacing(0.1f);
        textView.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        textView.setGravity(Gravity.CENTER);
        textView.setIncludeFontPadding(false);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP));
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        textView.setLayoutParams(params);

        return textView;
    }

    /**
     * Creates an empty placeholder view that balances the layout on the
     * right side of the top bar.
     *
     * @return The placeholder view
     */
    @NonNull
    private View createPlaceholder() {
        View placeholder = new View(mContext);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_END);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        placeholder.setLayoutParams(params);
        return placeholder;
    }

    /**
     * Creates the header bar showing "THEME LIST" and the theme count.
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP),
            dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));

        TextView headerTitle = new TextView(mContext);
        headerTitle.setText("THEME LIST");
        headerTitle.setTextSize(12);
        headerTitle.setLetterSpacing(0.1f);
        headerTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        headerTitle.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView headerCount = new TextView(mContext);
        headerCount.setText(mColorNames.length + " themes");
        headerCount.setTextSize(12);
        headerCount.setLetterSpacing(0.1f);
        headerCount.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));

        header.addView(headerTitle);
        header.addView(headerCount);

        return header;
    }

    /**
     * Creates the scrollable list that contains every theme row.
     *
     * @return The scroll view containing the theme list
     */
    @NonNull
    private ScrollView createScrollableList() {
        mScrollView = new ScrollView(mContext);
        mScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        mScrollView.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        mThemeList = new LinearLayout(mContext);
        mThemeList.setOrientation(LinearLayout.VERTICAL);
        mThemeList.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        for (int themeIndex = 0; themeIndex < mColorNames.length; themeIndex++) {
            final int index = themeIndex;
            final String name = mColorNames[themeIndex];
            final String value = mColorValues[themeIndex];
            final boolean selected = (themeIndex == mCurrentColorIndex);

            final LinearLayout item = createThemeItem(index, name, value, selected);
            mThemeList.addView(item);

            if (themeIndex < mColorNames.length - 1) {
                mThemeList.addView(createDivider());
            }
        }

        mScrollView.addView(mThemeList);
        return mScrollView;
    }

    /**
     * Creates a single theme row with a name, a color preview circle, and
     * a current indicator.
     *
     * @param themeIndex Index of the theme in the color arrays
     * @param name Display name of the theme
     * @param value Hex color value of the theme
     * @param selected True when this theme is the current one
     * @return The theme row layout
     */
    @NonNull
    private LinearLayout createThemeItem(final int themeIndex,
                                          @NonNull final String name,
                                          @NonNull final String value,
                                          final boolean selected) {
        final LinearLayout item = new LinearLayout(mContext);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setPadding(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP),
            dpToPx(0),
            dpToPx(LIST_ITEM_PADDING_VERTICAL_DP));
        item.setTag(themeIndex);
        item.setBackgroundColor(selected
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
            : Color.TRANSPARENT);

        item.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        int tagIndex = (Integer) item.getTag();
                        view.setBackgroundColor(tagIndex == mCurrentColorIndex
                            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
                            : Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        TextView nameView = new TextView(mContext);
        nameView.setText(name);
        nameView.setTextSize(14);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setTextColor(selected
            ? Color.parseColor(value)
            : Color.parseColor(TEXT_COLOR_LIGHT));
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        View colorCircle = createColorCircle(value, selected);

        TextView indicator = new TextView(mContext);
        if (selected) {
            indicator.setText("CURRENT");
            indicator.setTextSize(10);
            indicator.setLetterSpacing(0.1f);
            indicator.setTextColor(Color.parseColor(value));
            indicator.setPadding(dpToPx(INDICATOR_PADDING_DP), 0,
                dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP), 0);
        }
        indicator.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        item.addView(nameView);
        item.addView(colorCircle);
        item.addView(indicator);

        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSelectionTime = currentTime;
                    animateThemeSelection(item, themeIndex, name, value);
                }
            }
        });

        return item;
    }

    /**
     * Creates a color preview circle for a theme row.
     *
     * @param colorHex Hex color value of the theme
     * @param isSelected True when the row is the current one, which hides
     *        the circle
     * @return The color preview view
     */
    @NonNull
    private View createColorCircle(@NonNull String colorHex, boolean isSelected) {
        View circle = new View(mContext);
        int size = dpToPx(COLOR_CIRCLE_SIZE_DP);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        params.leftMargin = dpToPx(COLOR_CIRCLE_MARGIN_LEFT_DP);
        params.rightMargin = dpToPx(COLOR_CIRCLE_MARGIN_RIGHT_DP);
        circle.setLayoutParams(params);

        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(Color.parseColor(colorHex));
        drawable.setStroke(dpToPx(COLOR_CIRCLE_STROKE_WIDTH_DP),
            Color.parseColor(TEXT_COLOR_LIGHT));
        circle.setBackground(drawable);

        if (isSelected) {
            circle.setVisibility(View.INVISIBLE);
        }

        return circle;
    }

    /**
     * Creates a divider view that separates two theme rows.
     *
     * @return The divider view
     */
    @NonNull
    private View createDivider() {
        View divider = new View(mContext);
        divider.setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP)));
        return divider;
    }

    /**
     * Creates the bottom padding view.
     *
     * @return The bottom padding view
     */
    @NonNull
    private View createBottomPadding() {
        View padding = new View(mContext);
        padding.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP)));
        return padding;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}