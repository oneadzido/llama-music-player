package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>MusicPlayer follows the Model-View-Controller pattern where:</p>
 * <ul>
 *   <li><b>Activity</b> serves as the View, displaying UI and capturing user input</li>
 *   <li><b>MusicService</b> acts as the Controller, managing playback in background</li>
 *   <li><b>PlaybackController</b> provides the single source of truth for state</li>
 *   <li><b>MusicLibrary</b> manages the data model (songs, playlists)</li>
 *   <li><b>DisplayManager</b> handles all UI display logic (album art, placeholders, overlays)</li>
 * </ul>
 * 
 * <h3>DisplayManager Integration</h3>
 * <p>All display-related logic has been extracted to {@link DisplayManager}:
 * <ul>
 *   <li>Album art loading, caching, and display with fade animations</li>
 *   <li>Placeholder bitmap generation with theme color tinting</li>
 *   <li>Loading overlays for long operations with automatic timeout</li>
 *   <li>Time formatting and text truncation utilities</li>
 *   <li>Album art container clipping for rounded corners</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>The activity uses a multi-threaded architecture:</p>
 * <ul>
 *   <li><b>UI Thread:</b> All View operations and user interaction handling</li>
 *   <li><b>Handler Thread:</b> Background operations and service communication</li>
 *   <li><b>ExecutorService:</b> Album art loading and metadata extraction</li>
 *   <li><b>Separate Executor:</b> Placeholder bitmap generation (managed by DisplayManager)</li>
 * </ul>
 * 
 * <h3>State Management</h3>
 * <p>UI state is synchronized with MusicService through:</p>
 * <ul>
 *   <li>Broadcast receivers for service events</li>
 *   <li>PlaybackController for centralized state</li>
 *   <li>ServiceConnection callbacks for binding events</li>
 *   <li>SharedPreferences for persistence across app restarts</li>
 * </ul>
 * 
 * <h3>Control Button Management</h3>
 * <p><b>IMPORTANT:</b> All control buttons start DISABLED and only become
 * enabled when the player is prepared (song loaded and ready to play). This
 * prevents crashes and no-ops when users click buttons before the player is ready.</p>
 * 
 * @see MusicService
 * @see PlaybackController
 * @see DisplayManager
 * @see MusicLibrary
 * @see ThemeManager
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for permission requests. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for tracking first run of the application. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing the last played song's file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Action for restarting the application after updates. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action indicating a song has been prepared for playback. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Action indicating the player is ready for playback. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks to prevent rapid firing (milliseconds). */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before showing loading overlay (milliseconds). */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Delay for next/previous button UI updates (milliseconds). */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus operations and scrolling (milliseconds). */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Delay before resetting seek state after user stops seeking. */
    private static final int SEEK_RESET_DELAY_MS = 150;
    
    /** Buffer size for file copying operations (8KB). */
    private static final int BUFFER_SIZE = 8192;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Minimum time between position UI updates (50ms = 20fps, owner's throttle). */
    private static final long POSITION_UPDATE_THROTTLE_MS = 50;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Button for play/pause toggling. */
    @Nullable private Button mPlayButton;
    
    /** Button for previous song navigation. */
    @Nullable private Button mPrevButton;
    
    /** Button for next song navigation. */
    @Nullable private Button mNextButton;
    
    /** Button for repeat mode cycling (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Button for shuffle mode toggling. */
    @Nullable private Button mShuffleButton;
    
    /** Button for opening folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button for showing credits/about dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button for opening playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button for opening equalizer settings. */
    @Nullable private Button mEqualizerButton;
    
    /** Button for opening metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Container for album art with rounded corners. */
    @Nullable private FrameLayout mAlbumArtContainer;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Library manager for accessing song data and playlists. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Background service for music playback. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for storage access framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Display manager for album art, placeholders, and overlays. */
    @Nullable private DisplayManager mDisplayManager;
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable private PlaybackController mPlaybackController;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if the service is bound. */
    private volatile boolean mIsServiceBound = false;
    
    /** Flag indicating if user is actively seeking (dragging seek bar). */
    private volatile boolean mIsUserSeeking = false;
    
    /** Last time we updated the position UI (for throttling, owner's decision). */
    private long mLastPositionUpdateTime = 0;
    
    /** Target position for pending seek operations. */
    private int mSeekTargetPosition = -1;
    
    /** Handler for seek operation timeouts. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Atomic flag for UI update synchronization. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable for debounced updates. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for service synchronization. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Flag indicating if activity is restarting after an update. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transition synchronization. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    /** Atomic flag to prevent multiple concurrent play button updates. */
    @NonNull private final AtomicBoolean mPlayButtonUpdateQueued = new AtomicBoolean(false);
    
    /** Flag indicating if any player has been prepared. */
    private final AtomicBoolean mIsPlayerPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if playlist has songs. */
    private volatile boolean mHasSongs = false;
    
    /** Runnable to enable controls when prepared. */
    private Runnable mEnableControlsRunnable = null;
    
    /** Handler for delayed enable operations. */
    private final Handler mEnableHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick access. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    /** Single-thread executor for metadata extraction operations. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    /** Path of the currently displayed album art (used by DisplayManager). */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    @Nullable private BroadcastReceiver mPlayerReadyReceiver;
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // PlaybackController Listener
    // ========================================================================
    
    /** Listener for PlaybackController callbacks. */
    @Nullable private PlaybackController.PlaybackControllerListener mPlaybackControllerListener;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Connection to the MusicService for playback control.
     * 
     * <p>This ServiceConnection handles binding to MusicService and initializing
     * the UI once the service is connected. It includes automatic reconnection
     * logic if the service disconnects unexpectedly.</p>
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            // Enable controls immediately when service connects
            if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                updateRepeatButton();
                updateShuffleButton();
                
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(true);
                    mThemeHelper.updateSeekBar(mSeekBar, true);
                }
                
                if (mPlayButton != null && mThemeHelper != null) {
                    boolean isPlayingNow = (mPlaybackController != null) 
                        ? mPlaybackController.isPlaying()
                        : (mMusicService != null && mMusicService.isAnyPlayerPlaying());
                    mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
                
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(true);
                    mThemeHelper.updateControlButton(mPrevButton, true, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(true);
                    mThemeHelper.updateControlButton(mNextButton, true, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(true);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(true);
                    updateShuffleButton();
                }
                
                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                if (currentSong != null) {
                    updateUIForSong(currentSong);
                    if (mDisplayManager != null) {
                        mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                    }
                }
            } else {
                applyNoSongState();
            }
            
            setupSeekBar();
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                    Log.d(TAG, "Attempting to reconnect to MusicService");
                    Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>This method performs the following initialization steps:</p>
     * <ol>
     *   <li>Sets full-screen immersive mode</li>
     *   <li>Inflates the layout from activity_music_player.xml</li>
     *   <li>Initializes ToastManager for user feedback</li>
     *   <li>Checks for close_app intent flag</li>
     *   <li>Initializes FontAwesome icon library</li>
     *   <li>Creates DisplayManager for album art and UI display</li>
     *   <li>Initializes managers (Theme, Storage, MusicLibrary)</li>
     *   <li>Initializes UI views and sets up listeners</li>
     *   <li>Registers broadcast receivers for service communication</li>
     *   <li>Sets up theme change receiver</li>
     *   <li>Registers restart receiver for app updates</li>
     *   <li>Sets up media button receiver for headset controls</li>
     *   <li>Checks permissions and initializes further</li>
     *   <li>Starts StorageObserver for external storage monitoring</li>
     *   <li>Applies theme colors to UI elements</li>
     *   <li>Registers with NavigationController for button state</li>
     *   <li>Sets up PlaybackController listener</li>
     * </ol>
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        // Initialize DisplayManager for album art and UI display
        mDisplayManager = new DisplayManager(this, mThemeManager, mThemeHelper);
        mDisplayManager.setAlbumArtUpdateListener((art, placeholder, artPath) -> {
            if (mMusicService != null) {
                mMusicService.setNotificationAlbumArt(art, placeholder, artPath);
            }
        });
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        NavigationController.getInstance().registerListener(this);
        
        mPlaybackController = PlaybackController.getInstance();
        setupPlaybackControllerListener();
    }
    
    /**
     * Called when the activity becomes visible to the user.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity is no longer visible to the user.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes and comes to the foreground.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            }
        }
        
        // Restore position from PlaybackController on resume
        if (mPlaybackController != null) {
            long savedPosition = mPlaybackController.getCurrentPosition();
            if (savedPosition > 0 && mSeekBar != null) {
                mSeekBar.setProgress((int) savedPosition);
                if (mSeekTime != null) {
                    mSeekTime.setText(DisplayManager.formatTime((int) savedPosition));
                }
                Log.d(TAG, "onResume - restored position: " + savedPosition + "ms");
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0 && mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called before the activity is destroyed.
     * 
     * <p>This method performs comprehensive cleanup including releasing
     * the DisplayManager resources.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        unregisterReceiverSafely(mPlayerReadyReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        if (mEnableHandler != null) {
            mEnableHandler.removeCallbacksAndMessages(null);
        }
        mEnableControlsRunnable = null;
        
        unregisterMediaButtonReceiver();
        
        // Cleanup DisplayManager resources
        if (mDisplayManager != null) {
            mDisplayManager.release();
        }
        
        ToastManager.hidePersistentOverlay();
        
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    /**
     * Called when the system requests memory trimming.
     * 
     * <p>Forwards the memory trim event to MusicService and clears album art
     * cache when memory pressure is moderate or higher.</p>
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
        
        // Clear album art cache on memory pressure
        if (level >= TRIM_MEMORY_RUNNING_MODERATE && mDisplayManager != null) {
            mDisplayManager.clearAlbumArtCache();
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     * 
     * <p>Handles file opening intents (ACTION_VIEW) and close_app commands.</p>
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     * 
     * <p>Sets the immersive sticky mode when the window has focus,
     * ensuring full-screen experience with system UI hidden.</p>
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        // Refresh control buttons when window regains focus
        if (hasFocus && mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            }
        }
    }
    
    /**
     * Called when a key is pressed down.
     * 
     * <p>Consumes media button events to prevent default handling
     * and allows custom processing in onKeyUp.</p>
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) {
            return super.onKeyDown(keyCode, event);
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /**
     * Called when a key is released.
     * 
     * <p>Processes media button events to control playback.</p>
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mMusicService != null && !mMusicService.isAnyPlayerPlaying()) {
                    if (mMusicService.isAnyPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
    /**
     * Called when an activity launched with startActivityForResult completes.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Called when permission request results are available.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
        }
    }
    
    // =========================================================================
    // PlaybackController Setup
    // =========================================================================
    
    /**
     * Sets up the PlaybackController listener for state change callbacks.
     * 
     * <p>This method configures a listener that receives position updates,
     * play state changes, song changes, and prepared state changes.
     * MusicPlayer is the OWNER of UI decisions - it decides when to throttle,
     * when to skip updates, and when to update the UI.</p>
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        
        if (mPlaybackControllerListener != null) {
            mPlaybackController.setListener(null);
        }
        
        mPlaybackControllerListener = new PlaybackController.PlaybackControllerListener() {
            @Override
            public void onPositionChanged(long positionMs, long durationMs) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    if (mIsUserSeeking) return;
                    
                    long now = SystemClock.elapsedRealtime();
                    if (now - mLastPositionUpdateTime < POSITION_UPDATE_THROTTLE_MS) return;
                    mLastPositionUpdateTime = now;
                    
                    if (mSeekBar != null) {
                        if (durationMs > 0 && mSeekBar.getMax() != (int) durationMs) {
                            mSeekBar.setMax((int) durationMs);
                        }
                        mSeekBar.setProgress((int) positionMs);
                    }
                    
                    if (mSeekTime != null) {
                        mSeekTime.setText(DisplayManager.formatTime((int) positionMs));
                    }
                    if (mTotalTime != null && durationMs > 0) {
                        mTotalTime.setText(DisplayManager.formatTime((int) durationMs));
                    }
                });
            }
            
            @Override
            public void onPlayStateChanged(boolean isPlaying) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    safeUpdatePlayButton();
                });
            }
            
            @Override
            public void onSongChanged(String title, String artist, String path, long duration) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    mHasSongs = true;
                    
                    if (mSongTitle != null) {
                        String t = DisplayManager.formatSongTitle(title);
                        mSongTitle.setText(t);
                        if (mThemeHelper != null) {
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                    }
                    
                    if (mSongArtist != null) {
                        String a = DisplayManager.formatArtistName(artist);
                        mSongArtist.setText(a);
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                    }
                    
                    if (mSeekBar != null && duration > 0) {
                        mSeekBar.setMax((int) duration);
                        mSeekBar.setProgress(0);
                    }
                    
                    if (mTotalTime != null && duration > 0) {
                        mTotalTime.setText(DisplayManager.formatTime((int) duration));
                    }
                    if (mSeekTime != null) {
                        mSeekTime.setText("00:00");
                    }
                    
                    if (mDisplayManager != null) {
                        mDisplayManager.updateAlbumArt(mAlbumArtView, path);
                    }
                    safeUpdatePlayButton();
                });
            }
            
            @Override
            public void onPreparedStateChanged(boolean isPrepared) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    Log.d(TAG, "onPreparedStateChanged: isPrepared=" + isPrepared);
                    mIsPlayerPrepared.set(isPrepared);
                    
                    if (isPrepared) {
                        enableControlsWhenReady();
                    } else {
                        disableAllControls();
                    }
                    
                    safeUpdatePlayButton();
                    
                    if (isPrepared && mPlaybackController != null) {
                        long duration = mPlaybackController.getDuration();
                        if (mTotalTime != null && duration > 0) {
                            mTotalTime.setText(DisplayManager.formatTime((int) duration));
                        }
                        if (mSeekBar != null && duration > 0) {
                            mSeekBar.setMax((int) duration);
                            if (mIsPlayerPrepared.get() && mHasSongs) {
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                            }
                        }
                        Log.d(TAG, "Player prepared - duration: " + duration + "ms");
                    }
                });
            }
            
            @Override
            public void onOperationFailed(String operation, String reason) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        String message = "Cannot " + operation;
                        if (reason != null && !reason.isEmpty()) {
                            message += ": " + reason;
                        }
                        ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                        Log.w(TAG, "Operation failed: " + operation + " - " + reason);
                    }
                });
            }
        };
        
        mPlaybackController.setListener(mPlaybackControllerListener);
        Log.d(TAG, "PlaybackController listener configured - MusicPlayer is owner");
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes.
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(() -> {
                if (mPlaylistButton != null) {
                    mPlaylistButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                    }
                }
                
                if (mMetadataButton != null) {
                    mMetadataButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI views and sets up visual properties.
     * 
     * <p><b>IMPORTANT:</b> ALL control buttons start DISABLED and only become
     * enabled when the player is prepared (song loaded and ready to play).</p>
     */
    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        final Typeface faTypeface = FontAwesome.getTypeface();
        
        // ALL CONTROL BUTTONS START DISABLED
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }

        // Apply button backgrounds
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Set letter spacing for text buttons
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Add touch animations
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        // Load placeholder album art
        if (mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
        }
        
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
        
        // Ensure seek bar is disabled initially
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }

    /**
     * Adds touch animation to a button for visual feedback.
     * 
     * <p>When the button is pressed, it scales down to 97% of its size.
     * When released, it scales back to 100% with a smooth animation.</p>
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
            }
            return false;
        });
    }
    
    // ========================================================================
    // Control Enable Methods
    // ========================================================================
    
    /**
     * Enables all playback controls when any player is prepared.
     * 
     * <p>This method is called when the prepared state is reported via PlaybackController.
     * It ensures that buttons are only enabled when a song is actually ready to play,
     * preventing the unresponsive button issue on initial startup.</p>
     */
    private void enableControlsWhenReady() {
        if (mEnableControlsRunnable != null) {
            mEnableHandler.removeCallbacks(mEnableControlsRunnable);
        }
        
        mEnableControlsRunnable = () -> {
            if (isFinishing() || isDestroyed()) return;
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
            
            Log.d(TAG, "enableControlsWhenReady: hasSongs=" + hasSongs + ", isPrepared=" + isPrepared);
            
            if (hasSongs && isPrepared) {
                // Enable play button
                if (mPlayButton != null && !mPlayButton.isEnabled()) {
                    mPlayButton.setEnabled(true);
                    mPlayButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
                        mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                    }
                    Log.d(TAG, "Play button ENABLED - player prepared");
                }
                
                // Enable prev/next buttons
                if (mPrevButton != null && !mPrevButton.isEnabled()) {
                    mPrevButton.setEnabled(true);
                    mPrevButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateControlButton(mPrevButton, true, false);
                    }
                }
                
                if (mNextButton != null && !mNextButton.isEnabled()) {
                    mNextButton.setEnabled(true);
                    mNextButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateControlButton(mNextButton, true, false);
                    }
                }
                
                // Enable repeat/shuffle buttons
                if (mRepeatButton != null && !mRepeatButton.isEnabled()) {
                    mRepeatButton.setEnabled(true);
                    mRepeatButton.setAlpha(1.0f);
                    updateRepeatButton();
                }
                
                if (mShuffleButton != null && !mShuffleButton.isEnabled()) {
                    mShuffleButton.setEnabled(true);
                    mShuffleButton.setAlpha(1.0f);
                    updateShuffleButton();
                }
                
                // Enable seekbar
                if (mSeekBar != null && !mSeekBar.isEnabled()) {
                    mSeekBar.setEnabled(true);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateSeekBar(mSeekBar, true);
                    }
                }
            } else if (hasSongs && !isPrepared) {
                // Retry after 500ms - player might still be preparing
                mEnableHandler.postDelayed(this, 500);
                Log.d(TAG, "enableControlsWhenReady: waiting for player preparation...");
            }
        };
        
        mEnableHandler.post(mEnableControlsRunnable);
        
        // Safety timeout - don't keep retrying forever
        mEnableHandler.postDelayed(() -> {
            if (mEnableControlsRunnable != null) {
                mEnableHandler.removeCallbacks(mEnableControlsRunnable);
                mEnableControlsRunnable = null;
                Log.d(TAG, "Enable controls timeout - giving up");
            }
        }, 10000);
    }
    
    /**
     * Disables all playback controls.
     * Called when player enters error state or playlist is cleared.
     */
    private void disableAllControls() {
        Log.d(TAG, "disableAllControls - disabling all controls");
        
        if (mPlayButton != null) {
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        if (mPrevButton != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        if (mNextButton != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests necessary runtime permissions.
     * 
     * <p>This method requests different permissions based on Android version:
     * <ul>
     *   <li>Android 13+ (API 33): READ_MEDIA_AUDIO and POST_NOTIFICATIONS</li>
     *   <li>Android 12+ (API 31): Also requests BLUETOOTH_CONNECT</li>
     *   <li>Older versions: READ_EXTERNAL_STORAGE</li>
     * </ul>
     * </p>
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * 
     * <p>For first run, shows a loading message, starts the MusicService,
     * and binds to it. For subsequent runs, loads the last played song's
     * metadata and restores playback state.</p>
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks and requests battery optimization exemption for background playback.
     * 
     * <p>This is required for reliable background playback on Android 6.0+.
     * The request is only shown once to avoid bothering the user repeatedly.</p>
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers a media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters the media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles incoming files from other apps via ACTION_VIEW intent.
     * 
     * <p>When a user opens an audio file from a file manager or another app,
     * this method imports it as a loose song and starts playback.</p>
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming file using the already-bound MusicService.
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(() -> {
                enableAllControls();
                updateUIForSong(newSong);
            });
            
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                setupSeekBar();
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to MusicService and plays an incoming file.
     * 
     * <p>Used when the service is not yet bound. Creates a one-time
     * ServiceConnection that plays the file once connected.</p>
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(() -> {
                        enableAllControls();
                        updateUIForSong(newSong);
                        if (mDisplayManager != null && mAlbumArtContainer != null) {
                            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(() -> setupSeekBar(), FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     * 
     * <p>Handles both file:// and content:// URIs. For content URIs,
     * queries MediaStore.DATA column or copies to temp file if needed.</p>
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file.
     * 
     * <p>Used when the MediaStore doesn't have a file path for the URI,
     * such as when opening files from Google Drive or other cloud storage.</p>
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that are inside an imported folder.
     * 
     * <p>When a user imports a folder, any loose songs that are actually
     * inside that folder are removed from the loose songs list to avoid
     * duplication.</p>
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist in the background asynchronously.
     * 
     * <p>Uses MusicLibrary.loadAllSongsAsync to load all songs without
     * blocking the UI thread. Once loaded, the playlist is set on MusicService
     * and the UI is updated.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(() -> {
                        Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                            if (mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(mAlbumArtView, current.getPath());
                            }
                        }
                        setupSeekBar();
                    });
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                runOnUiThread(() -> ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG));
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Safely updates UI with thread-safe queuing.
     * 
     * <p>This method prevents overlapping UI updates by queueing pending
     * updates if an update is already in progress.</p>
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(() -> {
            try {
                if (!isFinishing() && !isDestroyed()) {
                    update.run();
                }
            } finally {
                mIsUpdatingUI.set(false);
                if (mPendingUIUpdate != null) {
                    final Runnable pending = mPendingUIUpdate;
                    mPendingUIUpdate = null;
                    safeUpdateUI(pending);
                }
            }
        });
    }
    
    /**
     * Updates the UI with current position from PlaybackController.
     * Used on pause/resume to ensure UI shows correct position.
     */
    private void updatePositionFromController() {
        if (mPlaybackController == null) return;
        
        long position = mPlaybackController.getCurrentPosition();
        long duration = mPlaybackController.getDuration();
        
        if (mSeekBar != null && duration > 0) {
            if (mSeekBar.getMax() != (int) duration) {
                mSeekBar.setMax((int) duration);
            }
            mSeekBar.setProgress((int) position);
        }
        if (mSeekTime != null) {
            mSeekTime.setText(DisplayManager.formatTime((int) position));
        }
        if (mTotalTime != null && duration > 0) {
            mTotalTime.setText(DisplayManager.formatTime((int) duration));
        }
    }
    
    /**
     * Updates the UI to display information for a given song.
     * 
     * <p>Updates title, artist, total time, and play/pause button state.
     * Does NOT update album art or playback position.</p>
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(finalSong.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            if (mSongArtist != null) {
                String artistText = DisplayManager.formatArtistName(finalSong.getArtist());
                mSongArtist.setText(artistText);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && finalSong.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) finalSong.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    /**
     * Updates the UI for a song that is currently playing.
     * 
     * <p>Similar to updateUIForSong but also updates album art.</p>
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForPlayingSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(finalSong.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            if (mSongArtist != null) {
                String artistText = DisplayManager.formatArtistName(finalSong.getArtist());
                mSongArtist.setText(artistText);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && finalSong.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) finalSong.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.updateAlbumArt(mAlbumArtView, finalSong.getPath());
                mDisplayManager.hideLoadingOverlay();
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    /**
     * Enables or disables all playback controls based on song availability.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        
        safeUpdateUI(() -> {
            if (mPlayButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPlayButton, enabled, true);
            }
            if (mPrevButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPrevButton, enabled, false);
            }
            if (mNextButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mNextButton, enabled, false);
            }
            if (mRepeatButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateRepeatButton();
            }
            if (mShuffleButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateShuffleButton();
            }
            if (mSeekBar != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mSeekBar.setEnabled(enabled);
                mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
        });
    }
    
    /**
     * Updates the enabled state of prev, next, repeat, and shuffle buttons.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        final boolean enabled = hasSongs && isPrepared;
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(enabled);
            mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mPrevButton, enabled, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(enabled);
            mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mNextButton, enabled, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(enabled);
            mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(enabled);
            mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateShuffleButton();
        }
    }
    
    /**
     * Applies the "no song" state to all UI components.
     * 
     * <p>Shows placeholder text and disables all controls when
     * no songs are available in the library.</p>
     */
    private void applyNoSongState() {
        int totalSongs = (mMusicLibrary != null ? mMusicLibrary.getSongCount() : 0);
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        int looseCount = (looseSongs != null ? looseSongs.size() : 0);
        if (totalSongs + looseCount > 0) return;
        
        if (mIsSyncInProgress) return;
        
        mHasSongs = false;
        mIsPlayerPrepared.set(false);
        
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null && mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
            mDisplayManager.clearAlbumArtCache();
        }

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        // Disable ALL controls when no songs
        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on MusicService with synchronization.
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method reads current state from PlaybackController
     * (single source of truth) and calls the appropriate MusicService method.</p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        boolean isPlaying = false;
        boolean isPrepared = false;
        
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
            isPrepared = mPlaybackController.isPrepared();
        }
        
        if (isPlaying) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
            updatePositionFromController();
        } else if (isPrepared) {
            Log.d(TAG, "togglePlayPause: Resuming playback");
            mMusicService.resume();
            updatePositionFromController();
        } else {
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playNext();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playPrevious();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button icon based on current repeat mode.
     * 
     * <p>Repeat modes:</p>
     * <ul>
     *   <li>0 = Off (no repeat) - shows standard repeat icon, not active</li>
     *   <li>1 = All (repeat playlist) - shows standard repeat icon, active</li>
     *   <li>2 = One (repeat single song) - shows repeat-one icon, active</li>
     * </ul>
     */
    private void updateRepeatButton() {
        if (mRepeatButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mRepeatButton.setText(FontAwesome.REPEAT);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isActive = (repeatMode != 0);
        final boolean isEnabled = mRepeatButton.isEnabled();
        
        if (repeatMode == 2) {
            mRepeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
        }
        
        mThemeHelper.updateControlButton(mRepeatButton, isEnabled, isActive);
    }
    
    /**
     * Updates the shuffle button icon based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mShuffleButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        final boolean isEnabled = mShuffleButton.isEnabled();
        
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(mShuffleButton, isEnabled, isShuffleOn);
    }
    
    // ========================================================================
    // Centralized Play Button Update
    // ========================================================================
    
    /**
     * Safely updates the play/pause button state using a centralized, debounced approach.
     * 
     * <p><b>IMPORTANT:</b> PlaybackController is the exclusive source of truth for play state.
     * This method only READS from PlaybackController and never writes to it.</p>
     */
    private void safeUpdatePlayButton() {
        if (mPlayButtonUpdateQueued.getAndSet(true)) {
            return;
        }
        
        mHandler.post(() -> {
            mPlayButtonUpdateQueued.set(false);
            
            if (isFinishing() || isDestroyed() || mThemeHelper == null || mPlayButton == null) {
                return;
            }
            
            boolean isPlaying = false;
            boolean isPrepared = false;
            
            if (mPlaybackController != null) {
                isPlaying = mPlaybackController.isPlaying();
                isPrepared = mPlaybackController.isPrepared();
            }
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            
            if (!hasSongs) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                mPlayButton.setAlpha(0.5f);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                }
                Log.d(TAG, "Play button: DISABLED (no songs)");
                return;
            }
            
            boolean shouldEnable = isPrepared;
            
            if (mPlayButton.isEnabled() != shouldEnable) {
                mPlayButton.setEnabled(shouldEnable);
                mPlayButton.setAlpha(shouldEnable ? 1.0f : 0.5f);
                Log.d(TAG, "Play button enabled state: " + shouldEnable);
            }
            
            String newText = isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY;
            
            if (!newText.equals(mPlayButton.getText())) {
                mPlayButton.setText(newText);
                if (mThemeHelper != null && shouldEnable) {
                    mThemeHelper.updateControlButton(mPlayButton, shouldEnable, true);
                }
                Log.d(TAG, "Play button updated: " + (isPlaying ? "PAUSE" : "PLAY") + 
                      " (prepared=" + isPrepared + ", hasSongs=" + hasSongs + ")");
            }
        });
    }
    
    // ========================================================================
    // SeekBar Setup
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position tracking and seeking.
     * 
     * <p>The seek bar behavior:</p>
     * <ul>
     *   <li>During dragging, only the time display updates (not the player position)</li>
     *   <li>When dragging stops, seeks to the selected position</li>
     *   <li>A timeout resets the seeking flag to prevent stuck states</li>
     * </ul>
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mPlaybackController != null) mPlaybackController.onSeekStart();
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekPos);
                    if (mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(seekPos));
                }
                mSeekTargetPosition = -1;
                
                mSeekHandler.removeCallbacksAndMessages(null);
                
                mSeekHandler.postDelayed(() -> {
                    mIsUserSeeking = false;
                    if (mPlaybackController != null) {
                        mPlaybackController.forceResetSeeking();
                    }
                    if (mMusicService != null) {
                        int currentPos = mMusicService.getCurrentPosition();
                        int duration = mMusicService.getDuration();
                        if (mSeekBar != null) {
                            if (duration > 0 && mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPos);
                        }
                        if (mSeekTime != null) {
                            mSeekTime.setText(DisplayManager.formatTime(currentPos));
                        }
                    }
                    Log.d(TAG, "Seek flag reset - UI updates resumed");
                }, SEEK_RESET_DELAY_MS);
            }
        });
    }
    
    // ========================================================================
    // Album Art Methods (Delegated to DisplayManager)
    // ========================================================================
    
    /**
     * Updates the album art for the current song.
     * Delegated to DisplayManager.
     */
    private void updateAlbumArt(@Nullable String filePath) {
        if (mDisplayManager != null) {
            mDisplayManager.updateAlbumArt(mAlbumArtView, filePath);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods (Delegated to DisplayManager)
    // ========================================================================
    
    /**
     * Shows a dim overlay with a loading spinner.
     * Delegated to DisplayManager.
     */
    private void showLoadingOverlay() {
        if (mDisplayManager != null) {
            ViewGroup rootView = findViewById(android.R.id.content);
            mDisplayManager.showLoadingOverlay(rootView);
        }
    }
    
    /**
     * Hides the loading overlay if it is visible.
     * Delegated to DisplayManager.
     */
    private void hideLoadingOverlay() {
        if (mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the folder manager activity for importing music folders.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the playlist activity to view and manage playlists.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the metadata editor for editing song tags.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song from MusicService.
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song's metadata from storage.
     * 
     * <p>This method is called on app startup to restore the last playback state.
     * It loads metadata asynchronously to avoid blocking the UI thread.</p>
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(this::hideLoadingOverlay, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(() -> {
                Song song = null;
                try {
                    Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                    
                    if (cachedSong != null && cachedSong.getTitle() != null && 
                        !cachedSong.getTitle().isEmpty() && 
                        !"Unknown Title".equals(cachedSong.getTitle())) {
                        song = cachedSong;
                    } else {
                        final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                        mmr.setDataSource(lastPath);
                        String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        final byte[] art = mmr.getEmbeddedPicture();
                        mmr.release();
                        
                        if (title == null || title.isEmpty()) {
                            final File file = new File(lastPath);
                            String name = file.getName();
                            final int dot = name.lastIndexOf('.');
                            if (dot > 0) name = name.substring(0, dot);
                            title = name;
                        }
                        if (artist == null) artist = "Unknown Artist";
                        if (album == null) album = "Unknown Album";
                        
                        String genre = "Unknown Genre";
                        Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        if (dbSong != null && dbSong.getGenre() != null && 
                            !"Unknown Genre".equals(dbSong.getGenre())) {
                            genre = dbSong.getGenre();
                            Log.d(TAG, "Found genre in database: " + genre);
                        } else {
                            String fileGenre = CharacterMapper.getGenre(lastPath);
                            if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                genre = fileGenre;
                                Log.d(TAG, "Read genre from file: " + genre);
                            }
                        }
                        
                        song = new Song(title, artist, album, genre, lastPath, 0, null);
                        if (art != null && mDisplayManager != null) {
                            final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                            if (bmp != null && mDisplayManager.getCachedAlbumArt(lastPath) == null) {
                                // Cache will be handled by DisplayManager
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                }
                
                final Song finalSong = song;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (finalSong != null && mThemeHelper != null) {
                        mCachedLastSong = finalSong;
                        if (mSongTitle != null) {
                            mSongTitle.setText(finalSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(finalSong.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        if (mDisplayManager != null) {
                            Bitmap cachedArt = mDisplayManager.getCachedAlbumArt(lastPath);
                            if (cachedArt != null) {
                                // Album art will be displayed via DisplayManager
                            } else {
                                mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                    if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                        updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                    }
                                }, FOCUS_SCROLL_DELAY_MS);
                            }
                        }
                        startServiceWithCachedSong();
                    } else {
                        applyNoSongState();
                        loadSongsAndStartService();
                    }
                });
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Decodes a byte array into a sampled bitmap to save memory.
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Calculates the sample size for efficient bitmap decoding.
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Starts the MusicService with the cached last song.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs and starts the MusicService.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(this::hideLoadingOverlay, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    setupSeekBar();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers a receiver for app restart commands.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers a receiver for theme color change events.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    if (mDisplayManager != null) {
                        mDisplayManager.refreshPlaceholder(mAlbumArtView);
                    }
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies the current theme color to all UI elements.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mDisplayManager != null) {
            mDisplayManager.refreshPlaceholder(mAlbumArtView);
        }
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs an app update by restarting the activity.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for service communication.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final boolean isPlaying = intent.getBooleanExtra("is_playing", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    safeUpdateUI(() -> {
                        if (songCompleted && !isPlaying) {
                            if (mSeekBar != null) {
                                mSeekBar.setProgress(0);
                            }
                            if (mSeekTime != null) {
                                mSeekTime.setText("00:00");
                            }
                            Log.d(TAG, "Song completed - seekbar reset to 0");
                        } else if (songCompleted && completedPosition > 0) {
                            if (mSeekBar != null) {
                                mSeekBar.setMax(completedPosition);
                                mSeekBar.setProgress(completedPosition);
                            }
                            if (mSeekTime != null) {
                                mSeekTime.setText(DisplayManager.formatTime(completedPosition));
                            }
                            if (mTotalTime != null) {
                                mTotalTime.setText(DisplayManager.formatTime(completedPosition));
                            }
                            Log.d(TAG, "Song completed - seekbar filled to 100%");
                        }
                        
                        if (mMusicService != null) {
                            if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                final int duration = mMusicService.getDuration();
                                final int position = mMusicService.getCurrentPosition();
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(position);
                            }
                            
                            final Song song = mMusicService.getCurrentSong();
                            if (song != null) {
                                if (mMusicService.isAnyPlayerPlaying()) {
                                    updateUIForPlayingSong(song);
                                } else {
                                    updateUIForSong(song);
                                }
                            }
                        }
                        setupSeekBar();
                    });
                }
            }
        };
        
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    // Play button state will be updated via PlaybackController listener
                }
            }
        };
        
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                        // Play button state will be updated via PlaybackController listener
                    }
                }
            }
        };
        
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    // Play button state will be updated via PlaybackController listener
                }
            }
        };
        
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mShuffleButton.setAlpha(0.5f);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mRepeatButton.setAlpha(0.5f);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mPlayButton.setAlpha(0.5f);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mPrevButton.setAlpha(0.5f);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mNextButton.setAlpha(0.5f);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            // Play button state will be updated via PlaybackController listener
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        // Play button state will be updated via PlaybackController listener
                        setupSeekBar();
                    }
                }
            }
        };
        
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    // Play button state will be updated via PlaybackController listener
                                    setupSeekBar();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    // Play button state will be updated via PlaybackController listener
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) {
                        return;
                    }
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.showToast(MusicPlayer.this, playerType + " is active...", ToastManager.LENGTH_NORMAL);
                            }
                        });
                    }
                }
            }
        };
        
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra("duration", 0);
                    final int audioSessionId = intent.getIntExtra("audio_session_id", -1);
                    final String songPath = intent.getStringExtra("song_path");
                    
                    Log.d(TAG, "SONG_PREPARED received: duration=" + duration + "ms, session=" + audioSessionId + ", path=" + songPath);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime(duration));
                                Log.d(TAG, "Updated total time to: " + formatTime(duration));
                            }
                            
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(0);
                                if (mIsPlayerPrepared.get()) {
                                    mSeekBar.setEnabled(true);
                                    if (mThemeHelper != null) {
                                        mThemeHelper.updateSeekBar(mSeekBar, true);
                                    }
                                }
                                Log.d(TAG, "Updated seekbar max to: " + duration + "ms");
                            }
                            
                            if (mPlayButton != null && !mPlayButton.isEnabled()) {
                                // Don't auto-enable - wait for prepared state from PlaybackController
                            }
                            
                            if (mEqualizerButton != null) {
                                mEqualizerButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateButton(mEqualizerButton, true);
                                }
                            }
                            
                            if (songPath != null && mMusicService != null) {
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                    if (duration > 0) {
                                        currentSong.setDuration(duration);
                                    }
                                    updateUIForSong(currentSong);
                                }
                            }
                        }
                    });
                }
            }
        };
        
        mPlayerReadyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_READY.equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mPlayButton != null && mMusicLibrary != null && 
                                mMusicLibrary.getSongCount() > 0) {
                                // Don't auto-enable - wait for prepared state from PlaybackController
                                // The PlaybackController will trigger enableControlsWhenReady()
                                Log.d(TAG, "PLAYER_READY broadcast received - controls will be enabled when prepared");
                            }
                        }
                    });
                }
            }
        };
        
        // Register all receivers
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
        registerReceiverSafely(mPlayerStatusReceiver, ACTION_PLAYER_STATUS_UPDATE);
        registerReceiverSafely(mSongPreparedReceiver, ACTION_SONG_PREPARED);
        registerReceiverSafely(mPlayerReadyReceiver, ACTION_PLAYER_READY);
    }
    
    /**
     * Safely registers a broadcast receiver.
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all UI buttons with debouncing.
     */
    private void setupListeners() {
        // Play button
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlayPauseClickTime = currentTime;
                    togglePlayPause();
                }
            });
        }
        
        // Next button
        if (mNextButton != null) {
            mNextButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastNextClickTime = currentTime;
                    playNextSong();
                }
            });
        }
        
        // Previous button
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPrevClickTime = currentTime;
                    playPreviousSong();
                }
            });
        }
        
        // Repeat button
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastRepeatClickTime = currentTime;
                    if (mMusicService != null && mRepeatButton.isEnabled()) {
                        final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButton();
                        final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        // Shuffle button
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastShuffleClickTime = currentTime;
                    if (mMusicService != null && mShuffleButton.isEnabled()) {
                        final boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButton();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        // Manager button
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastManagerClickTime = currentTime;
                    openFolderManager();
                }
            });
        }
        
        // Llama/Credits button
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastLlamaClickTime = currentTime;
                    final View mainContent = findViewById(android.R.id.content);
                    mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(d -> {
                        final View content = findViewById(android.R.id.content);
                        content.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                    });
                    dialog.show();
                }
            });
        }
    
        // Playlist button
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlaylistClickTime = currentTime;
                    openPlaylist();
                }
            });
        }
        
        // Equalizer button
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastEqualizerClickTime = currentTime;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        
        // Metadata button
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastMetadataClickTime = currentTime;
                    openMetadataEditor();
                }
            });
        }
    }
    
    /**
     * Checks if the activity is destroyed (Android 4.3+).
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }
}