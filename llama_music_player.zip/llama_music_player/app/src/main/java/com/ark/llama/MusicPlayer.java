package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Renders the main playback screen and forwards user input to
 * {@link MusicService}.
 *
 * <p>The activity is a view over {@link MusicService}'s authoritative
 * playback state machine. User input is forwarded to the service, and
 * the resulting state is reflected from {@code UPDATE_PLAYER}
 * broadcasts. The activity does not own a transition state of its own;
 * the service owns every transition and the activity follows the
 * broadcasts.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The playback state machine is owned by {@link MusicService}. This
 * activity owns the render state derived from that machine: the text
 * and color of the current song's title and artist, the seek bar
 * position and duration, the enabled state of the transport controls,
 * and the album-art carousel's placeholder bitmap. Service calls are
 * serialised by {@link #mServiceLock}, and UI updates are coalesced by
 * {@link #safeUpdateUI(Runnable)}.</p>
 *
 * <p>The album-art carousel is a pure renderer of the
 * {@link PlaybackWindow} that the service publishes on every
 * {@code UPDATE_PLAYER} broadcast, together with the transition
 * direction and the restart flag the service names alongside it. The
 * activity forwards all three to the carousel and installs a listener
 * that turns a committed swipe into a next or previous request. The
 * activity does not compute neighbours, does not compute the
 * direction of a transition, and does not mutate the carousel's
 * window by any path other than the broadcast and the cold-start
 * handoff. This is what keeps the carousel in sync with the service
 * unconditionally.</p>
 *
 * <p>The media session metadata and the playback notification are
 * owned by {@link NotificationController}. This activity does not push
 * art to the session. The service's prefetch resolves the art, pokes
 * the controller, and the controller writes both the notification and
 * the session metadata from one snapshot in one main-thread turn.</p>
 *
 * <h3>Transport Requests</h3>
 * <p>A next or previous request from the UI is dispatched to the
 * service and answered by the service's own {@code UPDATE_PLAYER}
 * broadcast. {@link #playNextSong()} and {@link #playPreviousSong()}
 * call {@link MusicService#playNextSong()} or
 * {@link MusicService#playPreviousSong()}, which assign the target,
 * bump the transition generation, note the direction and restart for
 * that generation, and start the MediaPlayer work in the same
 * main-thread turn. The activity does not consume a resolved window
 * and does not start an animation on the tap. The animation begins
 * when the service's committing broadcast reaches the carousel's
 * receiver, in the same turn the window is committed and the
 * direction and restart are delivered. The transition the user sees
 * is the service's own answer, rendered at the point the service has
 * committed to it, exactly as an automatic song change is.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every transition the user can cause — a transport tap, a
 * committed swipe, a headset key, an automatic song change, an
 * incoming file — arrives at the activity as an {@code UPDATE_PLAYER}
 * broadcast. The {@code UPDATE_PLAYER} receiver builds one commit
 * runnable that writes every surface the transition touches: the
 * carousel's strip, the notification, the media session, the title,
 * the artist, the seek bar's range, the transport glyph. The carousel
 * reports through
 * {@link AlbumArtCarousel#setWindow(PlaybackWindow, int, boolean)}
 * whether the window landed synchronously. When it did — a
 * re-publication, a cold-start window, anything the carousel adopts
 * without an animation — the runnable runs in the receiver's own turn.
 * When an animation is running, the runnable is queued on the carousel
 * through {@link AlbumArtCarousel#postOnSettle(Runnable)} and runs on
 * the frame the strip snaps to rest and re-renders with the incoming
 * window. The two branches converge on the same main-thread turn, so
 * the strip's new bitmaps, the title, the artist, the seek bar's new
 * range, the transport glyph, the notification, and the media session
 * all reach their surfaces from one frame. Nothing lands ahead of
 * anything else, and no measure-and-layout pass is triggered while the
 * slide is animating.</p>
 *
 * <p>A transition started from a UI transport button enters the same
 * commit turn at the same point as an automatic transition. The tap
 * dispatches the request; the service resolves it; the broadcast
 * carries the window, the direction, and the restart; the receiver
 * adopts all three; the strip starts moving on that turn. The service
 * has finished every main-thread turn of the transition — the
 * prepare, the start, the notification, the media session — before the
 * carousel sees the window, so the strip animates against an idle main
 * thread.</p>
 *
 * <h3>Ordering</h3>
 * <p>Media buttons from headsets, hardware keys, and notification
 * action buttons are routed through
 * {@code androidx.media.session.MediaButtonReceiver} and dispatched to
 * the active
 * {@link android.support.v4.media.session.MediaSessionCompat} held by
 * {@link MusicService}. This activity keeps a fallback
 * {@link #onKeyDown(int, KeyEvent)} for hardware keys delivered to a
 * focused activity.</p>
 *
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic
 * {@code generation} alongside the full playback snapshot and the
 * transition direction and restart of that generation. The activity
 * tracks the highest generation it has seen and drops any broadcast
 * with a strictly lower one. Equal-generation broadcasts are accepted
 * because position and duration advance within a generation. When the
 * service is rebound, the high-water mark resets to {@code -1},
 * because a new service instance restarts its counter at zero. The
 * same generation is carried on the {@link PlaybackWindow} the
 * activity builds, so the carousel can distinguish a fresh transition
 * from a re-publication.</p>
 *
 * <h3>Volume-Key Observation</h3>
 * <p>The activity overrides {@link #dispatchKeyEvent(KeyEvent)} to
 * observe the volume-up key before the window system consumes it.
 * The event is not consumed. In one specific case — the music volume
 * is already at the device maximum and the song is bound but paused —
 * the activity resumes the song directly, because the framework emits
 * no {@code VOLUME_CHANGED_ACTION} when no value changes, and the
 * service's receiver never runs. See
 * {@link #resumeIfPausedAtMaxVolume()}.</p>
 *
 * <h3>Album-Art Gestures</h3>
 * <p>The album-art container owns every gesture that operates on the
 * album art. The container is divided into three horizontal zones:</p>
 * <ul>
 *   <li><b>Left edge</b> — {@link #VOLUME_GESTURE_EDGE_DP} wide.</li>
 *   <li><b>Middle</b> — the remainder.</li>
 *   <li><b>Right edge</b> — {@link #VOLUME_GESTURE_EDGE_DP} wide.</li>
 * </ul>
 *
 * <p>A single touch listener classifies each gesture on the first
 * significant move:</p>
 * <ul>
 *   <li><b>Horizontal</b> — the finger travels left or right.
 *       Anywhere on the art, this is the carousel's. The strip
 *       follows the finger, revealing the previous or next song's
 *       art. On release, the carousel either commits to the
 *       neighbour or springs back. Committing dispatches through the
 *       swipe commit listener installed in
 *       {@link #initializeViews()}, which calls
 *       {@link MusicService#playNextSong()} or
 *       {@link MusicService#playPreviousSong()} through
 *       {@link #playNextSong()} and {@link #playPreviousSong()}. The
 *       swipe's own slide continues under the finger as the
 *       continuation of the gesture; the service's confirming
 *       broadcast arrives during it and is absorbed.</li>
 *   <li><b>Vertical at edge</b> — the touch started in an edge zone
 *       and the finger travels up or down. The music stream volume
 *       is raised or lowered.</li>
 *   <li><b>Vertical at centre</b> — the touch started away from both
 *       edge zones and the finger travels vertically. The gesture is
 *       a no-op.</li>
 * </ul>
 *
 * <p>When the volume gesture reaches the device maximum or zero and
 * the finger continues to travel in the same direction, the volume
 * toast echoes at a fixed rhythm until the finger lifts or reverses
 * back inside the range. The echo is the same toast; its rhythm is
 * what tells the user the gesture is still being tracked even though
 * the device volume cannot change further.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>{@link #applyAlbumArtSize(Configuration)} decides the
 * album-art container's size and visibility from
 * {@code Configuration.screenHeightDp}. In tall windows the art is
 * shown at full size; in medium windows it shrinks; in short windows
 * it hides so the title, controls, and seek bar take the space.
 * Nothing else in the view hierarchy is touched: the top bar, seek
 * bar, transport controls, and the metadata/equalizer row are
 * fixed-height and fit comfortably at 400dp.</p>
 *
 * <p>When the album art is hidden, the wrapper that supplies its
 * padding is hidden with it, the title-and-artist group is pinned to
 * the top of its weight slot at the album-art top's Y offset, and the
 * transport row's bottom padding is reduced so the group's slot gains
 * the height the artist line needs. Every view below the group keeps
 * its position relative to the window bottom because the group's
 * weight slot absorbs the difference. See
 * {@link #applySongInfoLayout(boolean)}.</p>
 *
 * <h3>Permissions</h3>
 * <p>The set of runtime permissions the app needs is defined once, in
 * {@link PermissionChecker}. This activity reads that set through two
 * of the checker's methods. {@link #checkPermissionsAndInitialize()}
 * asks {@link PermissionChecker#getMissing(Context)} for the array it
 * requests, and {@link #onResume()} asks
 * {@link PermissionChecker#allGranted(Context)} for the yes-or-no answer
 * it acts on. There is no second definition of the set in this file;
 * a change to the version gates lives in the checker and is seen by
 * every reader at once.</p>
 *
 * <p>The outcome of a request is recorded but not acted on by the
 * permission callback itself. The single owner of "has initialization
 * run" is {@link #onResume()}, which reads the outcome and either
 * advances the initialization flow or applies the empty state.</p>
 *
 * <p>Two guards prevent the flow from running more than once per
 * activity instance and from being stranded when the user grants a
 * permission after a prior denial:</p>
 * <ul>
 *   <li>{@link #mInitializationAttempted} is set the moment
 *       {@link #proceedWithInitialization()} is entered and is not
 *       cleared while the activity lives. The resume-time retry
 *       checks it so the flow runs at most once, whether the bind
 *       succeeded, failed synchronously, or was never reached
 *       because the permissions were not granted.</li>
 *   <li>{@link #mPermissionsDenied} latches the moment the
 *       permission check first fails. When it is still set on a
 *       later resume and the permissions are now granted, the flag is
 *       cleared and the initialization attempt is reset, so the
 *       flow runs again from a clean slate. This is the path that
 *       recovers a launch where the user denied the request and
 *       later granted it in the system settings.</li>
 * </ul>
 *
 * <h3>Cold-Start Overlay</h3>
 * <p>The cold-start library load shows a "Just a moment..." toast and
 * a dim-and-spinner overlay under
 * {@link OverlayManager#REASON_COLD_START}. The overlay is shown from
 * {@link #onResume()} and from
 * {@link #loadFullPlaylistInBackground()}, and is cleared by every
 * exit path from those two methods: the load's completion callback,
 * the load's error callback, and the permission request's denial
 * branch.</p>
 *
 * <p>The overlay's operation is kept alive by a heartbeat runnable
 * that re-posts itself every {@link #LIBRARY_HEARTBEAT_INTERVAL_MS}
 * milliseconds while the operation is on the stack. The heartbeat is
 * bounded by {@link #LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS}: after that
 * much time has passed since the first heartbeat, the runnable stops
 * and calls {@link #abandonLibraryLoadOverlay(String)}. The overlay
 * is torn down and the user is told the library could not be loaded.
 * Without this deadline, a load that never completes — a bind that is
 * accepted but whose callback never arrives — would keep the overlay
 * up forever, because the heartbeat signal the stuck detector relies
 * on would itself never stop.</p>
 *
 * <p>The bind itself is checked for its synchronous return value in
 * {@link #proceedWithInitialization()}. A refused bind is reported
 * the same way as an abandoned load, without waiting for the
 * deadline.</p>
 *
 * <h3>Automatic Folder Update</h3>
 * <p>The cold-start load runs a MediaStore query that returns what
 * the index has catalogued. A file that has been copied to the device
 * but not yet scanned by MediaStore — a fresh download, a transfer
 * after a factory reset, an SD card inserted minutes earlier — is not
 * returned by that query. When the query returns no songs but the
 * user has folders configured, the empty result is not the truth of
 * the library; it is a gap in the index.</p>
 *
 * <p>The activity therefore runs the same folder-update scan the
 * UPDATE button runs, through
 * {@link PlaylistManager#updatePlaylist(PlaylistManager.UpdateCallback)}.
 * The scan is the definitive reconciliation of the songs table
 * against the paths it finds under every kept folder, and it
 * broadcasts {@code UPDATE_PLAYLIST_FROM_FOLDERS} on completion,
 * which the activity's own receiver handles as the reload signal.
 * The overlay stays up across both stages — the cold-start load and
 * the automatic update — so the user sees one continuous load rather
 * than a load followed by a correction.</p>
 *
 * <h3>Incoming File Requests</h3>
 * <p>An incoming file from another app travels through two paths that
 * converge on one destination. The path is parked in the service as
 * a pending path and dispatched as a {@code SET_PENDING_SONG}
 * broadcast; the service's receiver stores it in the pending slot.
 * When the file is not already in the library, a loose-track insert
 * runs in parallel with an art pre-decode; the insert's completion
 * announces the playlist change with {@code UPDATE_PLAYLIST}, and the
 * service's rebuild resolves the pending path as the anchor of the
 * next transition.</p>
 *
 * <p>The pending slot is written once, by the initial hand-off in
 * {@link #handleIncomingFile}. The insert's completion callback does
 * not re-fire the hand-off, because doing so would overwrite a newer
 * request with an older one when a second file is opened before the
 * first insert completes. The rebuild that follows each insert
 * preserves the pending slot until the path it names is actually
 * found in the playlist; a rebuild that finds the pending path
 * absent returns without touching the target, so the transition
 * already in flight is not silently redirected to an unrelated song.</p>
 *
 * <p>The activity's {@code UPDATE_PLAYLIST} receiver does not refresh
 * the carousel from the service's window. The carousel is updated by
 * the service's own {@code UPDATE_PLAYER} broadcast, which carries
 * the window, the direction, and the restart the service is committed
 * to. Refreshing the carousel from a second path would show the
 * target song's art while the previous song was still playing, and
 * would compete with the commit turn the carousel uses to keep every
 * surface in sync.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Cold start shows {@link OverlayManager} under
 * {@link OverlayManager#REASON_COLD_START} while the library loads.
 * The overlay is hidden by the load's completion or error callback,
 * or by the automatic folder update when it runs. When the library is
 * reset, {@link PlaylistManager}'s reset operation sends a
 * {@code LIBRARY_RESET} broadcast that this activity receives through
 * its own receiver.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialised by {@link #mServiceLock}. UI updates
 * are coalesced by {@link #safeUpdateUI(Runnable)}. The main handler
 * is drained in {@link #onDestroy()} so no post is left after the
 * activity is gone.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see PermissionChecker
 * @see OverlayManager
 * @see AlbumArtCarousel
 * @see PlaybackWindow
 * @see NotificationController
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.9
 * @since 1.0.0
 */
public class MusicPlayer extends Activity
        implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for the folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for the battery optimization request. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action that restarts the app after an update. */
    private static final String ACTION_RESTART_APP =
        "com.ark.llama.RESTART_APP";

    /** Broadcast action that updates the sort mode from the playlist. */
    private static final String ACTION_UPDATE_SORT_MODE =
        "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that sets a pending song path in the service. */
    private static final String ACTION_SET_PENDING_SONG =
        "SET_PENDING_SONG";

    /** Broadcast action that asks the activity to rebuild from folders. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS =
        "UPDATE_PLAYLIST_FROM_FOLDERS";

    /** Operation ID for the library-load overlay mirror. */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Message shown during the cold-start library load. */
    private static final String MESSAGE_LIBRARY_LOAD = "Just a moment...";

    /** Message shown when the cold-start library load is abandoned. */
    private static final String MESSAGE_LIBRARY_LOAD_FAILED =
        "Couldn't load library; try again";

    /** Message shown when the playback service refuses the bind. */
    private static final String MESSAGE_SERVICE_BIND_FAILED =
        "Couldn't start playback service";

    /** Message shown when the runtime permissions are denied. */
    private static final String MESSAGE_PERMISSIONS_REQUIRED =
        "Permissions required to read and play songs";

    /** Interval for the library-load heartbeat, in milliseconds. */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500;

    /**
     * Maximum time the library-load heartbeat runs before the load
     * is considered abandoned, in milliseconds.
     *
     * <p>The heartbeat runnable re-posts itself while the
     * {@link #OPERATION_LIBRARY_LOAD} operation is on the stack, and
     * stops after this much time has passed since the first
     * heartbeat. When it stops, {@link #abandonLibraryLoadOverlay}
     * hides the overlay and tells the user the library could not be
     * loaded.</p>
     *
     * <p>The deadline exists because the heartbeat is what
     * {@link ToastManager}'s stuck detector watches. A heartbeat
     * that never stops keeps the detector from ever firing,
     * regardless of whether the operation beneath it is making
     * progress. Bounding the heartbeat is what lets the detector do
     * its job for the case the load never completes.</p>
     *
     * <p>Sixty seconds is deliberately generous: a real load on a
     * large library completes well within it, and the deadline is
     * only reached when no completion callback is coming.</p>
     */
    private static final long LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS =
        60000L;

    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay for the service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000;

    /** Delay before performing focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;

    /** Delay before updating the repeat and shuffle buttons. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250;

    /** Buffer size for file copy operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of the button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /**
     * Width of the volume-gesture edge zone on each side of the
     * album-art container, in density-independent pixels.
     *
     * <p>At the full album-art width of
     * {@link #ALBUM_ART_FULL_DP}, the two edge zones plus the middle
     * zone are {@code 30 + 240 + 30}. The middle zone is the
     * carousel's; the two edge zones are the volume gesture's. A
     * horizontal swipe anywhere on the container is the carousel's;
     * a vertical swipe is a volume gesture only when it started
     * inside an edge zone.</p>
     */
    private static final int VOLUME_GESTURE_EDGE_DP = 30;

    /**
     * Fraction of the device's volume range the finger must travel
     * past a limit before the volume toast echoes a second time.
     *
     * <p>Once the target volume is clamped to the device maximum or
     * to zero, further finger travel in the same direction changes
     * nothing on the device. The echo gives the user rhythmic
     * confirmation that the gesture is still being tracked. The
     * rhythm is expressed on the volume axis rather than the pixel
     * axis, so it is the same on every device regardless of how many
     * volume steps the platform reports.</p>
     */
    private static final float VOLUME_LIMIT_ECHO_STEP_FRACTION = 0.15f;

    /** The gesture is not currently clamped to either volume limit. */
    private static final int VOLUME_LIMIT_SIDE_NONE = 0;

    /** The gesture is clamped to the device's maximum music volume. */
    private static final int VOLUME_LIMIT_SIDE_MAXIMUM = +1;

    /** The gesture is clamped to zero music volume. */
    private static final int VOLUME_LIMIT_SIDE_MINIMUM = -1;

    /**
     * Window height above which the album art is shown at its full
     * size.
     */
    private static final int SPLIT_SCREEN_FULL_HEIGHT_DP = 600;

    /**
     * Window height below which the album art is hidden entirely.
     */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    /** Album-art size at full screen, in dp. */
    private static final int ALBUM_ART_FULL_DP = 300;

    /** Album-art size in a shrunk split-screen window, in dp. */
    private static final int ALBUM_ART_SHRUNK_DP = 180;

    /**
     * Bottom padding of the transport row in split-screen mode, in dp.
     *
     * <p>Sixteen dp less than the layout-declared {@code 64dp}. The
     * reduction passes sixteen dp of slot height to the title-and-artist
     * group, which is what the artist line needs in a short split
     * window. The value keeps the transport buttons clear of the
     * temporary toast, which sits at a fixed offset from the window
     * bottom.</p>
     */
    private static final int TRANSPORT_ROW_SPLIT_BOTTOM_DP = 48;

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Text view showing the current song title. */
    @Nullable private TextView mSongTitle;

    /** Text view showing the current song artist. */
    @Nullable private TextView mSongArtist;

    /** Text view showing the elapsed playback time. */
    @Nullable private TextView mSeekTime;

    /** Text view showing the total playback duration. */
    @Nullable private TextView mTotalTime;

    /** Seek bar for scrubbing through the current song. */
    @Nullable private SeekBar mSeekBar;

    /** Play or pause button. */
    @Nullable private Button mPlayButton;

    /** Previous-track button. */
    @Nullable private Button mPrevButton;

    /** Next-track button. */
    @Nullable private Button mNextButton;

    /** Repeat-mode button. */
    @Nullable private Button mRepeatButton;

    /** Shuffle button. */
    @Nullable private Button mShuffleButton;

    /** Button that opens the folder manager. */
    @Nullable private Button mManagerButton;

    /** Button that opens the credits dialog. */
    @Nullable private Button mLlamaButton;

    /** Button that opens the playlist activity. */
    @Nullable private Button mPlaylistButton;

    /** Button that opens the equalizer activity. */
    @Nullable private Button mEqualizerButton;

    /** Button that opens the metadata editor. */
    @Nullable private Button mMetadataButton;

    /** Container that hosts the album-art carousel. */
    @Nullable private FrameLayout mAlbumArtContainer;

    /**
     * Wrapper around the album-art container.
     *
     * <p>The wrapper's only job is to place padding above and below
     * the viewport. When the viewport is hidden in split-screen mode
     * the padding has no purpose, so the wrapper is taken out of the
     * layout with it. Otherwise the padding would survive as a
     * visible band above the song info.</p>
     */
    @Nullable private LinearLayout mAlbumArtWrapper;

    /**
     * Group that contains the title and artist TextViews.
     *
     * <p>Pinned to the top of its weight slot in split-screen mode so
     * the title lands where the album-art top begins in full-screen
     * mode. Returns to its layout-declared gravity and padding when
     * the album art is visible.</p>
     */
    @Nullable private LinearLayout mSongInfoGroup;

    /**
     * Row that holds the shuffle, previous, play, next, and repeat
     * buttons.
     *
     * <p>The row's bottom padding separates the transport controls
     * from the volume toast at the bottom of the window. In
     * split-screen mode the padding is reduced so that the
     * title-and-artist group gains the slot height the artist line
     * needs. See {@link #applySongInfoLayout(boolean)}.</p>
     */
    @Nullable private LinearLayout mTransportRow;

    /** Gravity of {@link #mSongInfoGroup} as declared by the layout. */
    private int mDefaultSongInfoGravity = Gravity.CENTER;

    /** Top padding of {@link #mSongInfoGroup} as declared by the layout. */
    private int mDefaultSongInfoPaddingTop = 0;

    /** Bottom padding of {@link #mTransportRow} as declared by the layout. */
    private int mDefaultTransportPaddingBottom = 0;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    /** In-memory library used to read the current song list. */
    @Nullable private MusicLibrary mMusicLibrary;

    /** Bound service that owns the playback state machine. */
    @Nullable private MusicService mMusicService;

    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageAccessHelper;

    /**
     * Controller that owns every notification surface and the media
     * session. Resolved in {@link #onCreate(Bundle)}. The activity
     * drives it from the commit runnable in the
     * {@code UPDATE_PLAYER} receiver through
     * {@link NotificationController#commitNow()}, so the notification
     * and the media session land on the same frame as the strip, the
     * title, the artist, and the transport glyph.
     */
    @Nullable private NotificationController mNotificationController;

    /** Handler for UI operations. */
    @NonNull private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Handler for delayed service operations. */
    @NonNull private final Handler mServiceHandler =
        new Handler(Looper.getMainLooper());

    /** Handler used to schedule time-display updates; null when idle. */
    @Nullable private Handler mTimeHandler = null;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** True while the user is dragging the seek bar. */
    private boolean mIsUserSeeking = false;

    /** Guard that serialises concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI =
        new AtomicBoolean(false);

    /** Deferred UI update posted while another update is running. */
    @Nullable private Runnable mPendingUIUpdate = null;

    /** Song path queued for playback once the service is bound. */
    private volatile String mPendingIncomingPath = null;

    /** Lock that serialises service calls. */
    @NonNull private final Object mServiceLock = new Object();

    /** Highest generation seen in an {@code UPDATE_PLAYER} broadcast. */
    private long mLastSeenGeneration = -1L;

    // ============================================================================
    // State Flags
    // ============================================================================

    /** True when the activity was started as part of a post-update restart. */
    private boolean mIsPostUpdateRestart = false;

    /** True once the cold-start library load has been requested. */
    private boolean isLoadingComplete = false;

    /**
     * True once {@link #proceedWithInitialization()} has been entered.
     *
     * <p>Set at the entry to that method and never cleared by the
     * activity's own flow. The resume-time retry checks it so the
     * initialization flow runs at most once per activity instance,
     * whether the bind succeeded, failed synchronously, or was
     * never reached because the permission check denied. The one
     * path that clears it is a permission restore after a prior
     * revocation, which resets the whole initialization attempt.</p>
     */
    private boolean mInitializationAttempted = false;

    /**
     * True while a runtime permission the app needs has been denied
     * and not yet re-granted.
     *
     * <p>Set the moment the permission check first fails and cleared
     * the moment it succeeds. When it is cleared after having been
     * set, the initialization attempt is also reset, so the flow
     * runs again from a clean slate. This is what recovers a launch
     * where the user denied the request and later granted it.</p>
     */
    private boolean mPermissionsDenied = false;

    /** Runnable that heartbeats the library-load overlay. */
    @Nullable private Runnable mLibraryHeartbeatRunnable;

    // ============================================================================
    // Click Debounce Timestamps
    // ============================================================================

    /** Timestamp of the last play or pause click. */
    private long mLastPlayPauseClickTime = 0;

    /** Timestamp of the last next-track click. */
    private long mLastNextClickTime = 0;

    /** Timestamp of the last previous-track click. */
    private long mLastPrevClickTime = 0;

    /** Timestamp of the last repeat-mode click. */
    private long mLastRepeatClickTime = 0;

    /** Timestamp of the last shuffle click. */
    private long mLastShuffleClickTime = 0;

    /** Timestamp of the last equalizer button click. */
    private long mLastEqualizerClickTime = 0;

    /** Timestamp of the last manager button click. */
    private long mLastManagerClickTime = 0;

    /** Timestamp of the last llama button click. */
    private long mLastLlamaClickTime = 0;

    /** Timestamp of the last playlist button click. */
    private long mLastPlaylistClickTime = 0;

    /** Timestamp of the last metadata button click. */
    private long mLastMetadataClickTime = 0;

    // ============================================================================
    // Album Art Components
    // ============================================================================

    /** Cache of decoded album art bitmaps keyed by song path. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    /** Executor for album art decoding. */
    @NonNull private final ExecutorService mAlbumArtExecutor =
        Executors.newSingleThreadExecutor();

    /** Executor for metadata loading. */
    @NonNull private final ExecutorService mMetadataLoader =
        Executors.newSingleThreadExecutor();

    /** Currently running metadata load task. */
    @Nullable private Future<?> mCurrentMetadataFuture = null;

    /** Currently displayed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Untinted placeholder bitmap used to regenerate the tinted copy. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    /** Executor for placeholder rendering. */
    @NonNull private final ExecutorService mPlaceholderExecutor =
        Executors.newSingleThreadExecutor();

    /** Currently running placeholder render task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    /** Lock guarding the placeholder bitmaps. */
    @NonNull private final Object mPlaceholderLock = new Object();

    /**
     * Three-slot carousel that owns the album-art strip.
     *
     * <p>Constructed in {@link #onCreate(Bundle)} and attached to
     * {@link #mAlbumArtContainer} by {@link #initializeViews()}. The
     * carousel owns the strip, the three ImageViews, and the rolling
     * window of decoded bitmaps. The activity supplies the window the
     * carousel renders, along with the transition direction and
     * restart the service named, through the {@code UPDATE_PLAYER}
     * broadcast receiver and through
     * {@link #refreshCarouselFromService()} on service connect and on
     * resume.</p>
     */
    @Nullable private AlbumArtCarousel mAlbumArtCarousel;

    /** Manager for the current theme color. */
    @Nullable private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    @Nullable private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    @Nullable private BroadcastReceiver mThemeReceiver;

    /** Observer for MediaStore changes. */
    @Nullable private StorageObserver mStorageObserver;

    /** Song loaded from the persisted last path at startup. */
    @Nullable private Song mCachedLastSong = null;

    // ============================================================================
    // Gesture State
    // ============================================================================

    /** System audio manager, resolved in onCreate; null on devices without one. */
    @Nullable private AudioManager mAudioManager;

    /**
     * Modes a touch sequence on the album-art container can settle
     * into.
     */
    private enum GestureMode {

        /** No classification yet; the sequence is still in its slop window. */
        UNDECIDED,

        /** The gesture is a horizontal swipe on the album-art carousel. */
        CAROUSEL,

        /** The gesture is a vertical volume swipe in an edge zone. */
        VOLUME,

        /** The gesture has been classified but is not consumed. */
        CANCELLED
    }

    /** Current gesture mode. */
    @NonNull private GestureMode mGestureMode = GestureMode.UNDECIDED;

    /** X coordinate of the gesture's starting touch, in view-local pixels. */
    private float mGestureStartX = 0f;

    /** Y coordinate of the gesture's starting touch, in view-local pixels. */
    private float mGestureStartY = 0f;

    /** Container width sampled at gesture start, in pixels. */
    private int mGestureContainerWidth = 1;

    /** Container height sampled at gesture start, in pixels. */
    private int mGestureContainerHeight = 1;

    /** Music-stream volume at the start of a volume gesture. */
    private int mVolumeGestureStartVolume = 0;

    /** Maximum music-stream volume on this device, sampled at gesture start. */
    private int mVolumeGestureMaxVolume = 0;

    /**
     * Sign of the volume limit the gesture is currently riding: one
     * of {@link #VOLUME_LIMIT_SIDE_MAXIMUM},
     * {@link #VOLUME_LIMIT_SIDE_MINIMUM}, or
     * {@link #VOLUME_LIMIT_SIDE_NONE}.
     */
    private int mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;

    /**
     * Finger overshoot past the current limit at which the last
     * limit-echo toast fired, measured in volume steps.
     *
     * <p>Acts as the baseline from which the next echo step is
     * measured: the next echo fires when the current overshoot
     * reaches this value plus one echo step.
     * {@link Float#NaN} means no toast has fired at this limit yet
     * during the current gesture; the first overshoot past the limit
     * will fire immediately.</p>
     */
    private float mVolumeGestureLimitEchoBaseline = Float.NaN;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mLibraryResetReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mMetadataUpdatedReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;

    // ============================================================================
    // Service Connection
    // ============================================================================

    @NonNull
    private final ServiceConnection mServiceConnection =
            new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG,
                    "Handing off parked incoming path: " + pendingPath);
                handOffIncomingPath(pendingPath);
            }

            if (mPlayButton != null && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                }
            }

            loadFullPlaylistInBackground();
            updateRepeatButton();
            updateShuffleButton();
            refreshCarouselFromService();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }
                    if (mMusicLibrary != null
                            && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow =
                            (mMusicService != null
                                && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow
                                ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(
                                mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(
                                mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(
                                mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        refreshCarouselFromService();
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing()
                            && !isDestroyed()) {
                        Log.d(TAG,
                            "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(
                            MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection,
                            BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, the view hierarchy, the receivers,
     * and the service binding, and starts the permission check.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);
        OverlayManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache =
            new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageAccessHelper = StorageAccessHelper.getInstance(this);
        mNotificationController =
            NotificationController.getInstance(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        mIsPostUpdateRestart = getIntent()
            .getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Registers the theme receiver if it is not already registered.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the playback display from the service, reapplies the theme,
     * and drives the permission and initialization gates.
     *
     * <p>This method is the single owner of "has initialization run."
     * The permission outcome recorded by
     * {@link #onRequestPermissionsResult(int, String[], int[])} is
     * read here and turned into one of three actions: run the
     * initialization flow, apply the empty state, or do nothing. The
     * callback that produced the outcome does not advance the flow
     * itself, so the flow cannot run twice for one permission
     * decision.</p>
     *
     * <p>Two flags decide the branch: {@link #mInitializationAttempted},
     * which is set the first time the flow is entered and prevents
     * re-entry, and {@link #mPermissionsDenied}, which latches when
     * the permissions are first missing and clears when they are
     * restored. A restore after a prior denial resets
     * {@code mInitializationAttempted} so the flow runs again from
     * a clean slate. The permission question itself is asked of
     * {@link PermissionChecker}, which owns the set.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        final boolean permissionsGranted =
            PermissionChecker.allGranted(this);

        if (permissionsGranted && mMusicService != null
                && mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();
            refreshCarouselFromService();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(
                this, MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();

        if (!permissionsGranted) {
            if (!mPermissionsDenied) {
                mPermissionsDenied = true;
                applyNoSongState();
            }
            return;
        }

        if (mPermissionsDenied) {
            mPermissionsDenied = false;
            if (mInitializationAttempted) {
                // The permission was restored after the app had
                // already been running. The library's in-memory
                // state is stale against the filesystem, and the
                // service (if bound) holds a playlist that cannot
                // be played. Reset both so the initialization flow
                // runs again from a clean slate.
                mInitializationAttempted = false;
                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }
            }
        }

        if (!mInitializationAttempted) {
            proceedWithInitialization();
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Releases every resource held by the activity.
     *
     * <p>Does not tear down any persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; this
     * activity may be destroying itself while {@link FolderManager}
     * still owns the {@code "FOLDER_SYNC"} overlay or
     * {@link PlaylistManager} still owns the
     * {@code "GENRE_UPDATE"} or {@code "LIBRARY_RESET"} overlays.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null
                && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.clear();
            mAlbumArtCarousel = null;
        }

        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            mAlbumArtCache = null;
        }

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        final Intent stopNotifIntent =
            new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();
    }

    /**
     * Forwards the trim-memory signal to the bound service when one
     * is available, and evicts the album art cache under sustained
     * pressure.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG,
                    "Failed to forward onTrimMemory to service",
                    exception);
            }
        }
        if (level >= TRIM_MEMORY_BACKGROUND && mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
    }

    /**
     * Updates the intent and either closes the app or processes a
     * new incoming file.
     *
     * @param intent The new intent delivered to the activity
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Applies the album-art size and visibility for the new window
     * height.
     *
     * <p>The activity declares {@code configChanges} for
     * {@code orientation}, {@code screenSize},
     * {@code smallestScreenSize}, {@code screenLayout}, and
     * {@code keyboardHidden}, so a resize does not recreate the
     * activity. Nothing else in the view hierarchy is touched: the
     * top bar, song info, seek bar, transport controls, and the
     * metadata/equalizer row are fixed-height and fit comfortably
     * inside the shortest window the app supports.</p>
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applyAlbumArtSize(config);
    }

    /**
     * Intercepts the volume-up key before the window handles it.
     *
     * <p>The framework does not deliver {@code KEYCODE_VOLUME_UP} to
     * {@link #onKeyDown(int, KeyEvent)}; the window system consumes it
     * first. {@code dispatchKeyEvent} is the only method that sees the
     * key before the window does.</p>
     *
     * <p>The event is not consumed. The system still processes the
     * volume key as it normally would; this override only observes the
     * key and, in one specific case, performs a side effect. That case
     * is the one the broadcast path cannot cover: the volume is
     * already at the device maximum, the song is bound but paused,
     * and the user pressed volume up. No volume change occurs, so the
     * system emits no {@code VOLUME_CHANGED_ACTION}, and the receiver
     * in {@link MusicService} never fires. Resuming from here closes
     * that gap.</p>
     *
     * @param event The key event delivered to the activity
     * @return Whatever {@code super.dispatchKeyEvent} returns
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            resumeIfPausedAtMaxVolume();
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * Handles media keys delivered to a focused activity.
     *
     * @param keyCode Code of the pressed key
     * @param event Full key event
     * @return True when the key was consumed
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Resumes playback when the volume is already at the device
     * maximum and the user pressed volume up while a song was bound
     * but paused.
     *
     * <p>Does nothing in every other case. A volume change below the
     * maximum is handled by the receiver in {@link MusicService}, which
     * fires on the broadcast the system emits when the value changes.
     * This method exists solely for the at-maximum case, where no
     * broadcast is emitted because no change occurred.</p>
     */
    private void resumeIfPausedAtMaxVolume() {
        if (mAudioManager == null
                || mMusicService == null
                || !mIsServiceBound) {
            return;
        }
        try {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume <= 0) {
                return;
            }
            final int currentVolume = mAudioManager.getStreamVolume(
                AudioManager.STREAM_MUSIC);
            if (currentVolume < maxVolume) {
                return;
            }
            if (!mMusicService.isPausedOrReady()) {
                return;
            }
            mMusicService.resume();
        } catch (Exception exception) {
            Log.w(TAG,
                "Failed to resume on volume-up at max", exception);
        }
    }

    /**
     * Handles the folder selection result and the battery
     * optimization result.
     *
     * @param requestCode The request code passed to the launcher
     * @param resultCode The result code returned by the target
     *        activity
     * @param data The intent carrying the result, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE
                && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageAccessHelper != null) {
                final String folderPath =
                    mStorageAccessHelper.getFolderPathFromUri(treeUri);
                mStorageAccessHelper.storeFolderPermission(
                    treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName =
                    mStorageAccessHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this,
                    "Imported: " + folderName,
                    ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager =
                    (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized =
                        powerManager.isIgnoringBatteryOptimizations(
                            getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows a battery optimization result toast after a short delay.
     *
     * @param optimized True when the app is exempt from battery
     *        optimizations
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    String message = optimized
                        ? "Background playback optimized"
                        : "Background playback restricted";
                    ToastManager.showToast(MusicPlayer.this, message,
                        ToastManager.LENGTH_SHORT);
                }
            }
        }, 150);
    }

    /**
     * Handles the runtime permission result.
     *
     * <p>The result is recorded, not acted on. A grant clears the
     * permission-blocked latch and lets the next resume advance the
     * initialization flow. A denial shows the reason as a short toast
     * and applies the empty state. The division keeps the
     * initialization flow's single entry point at
     * {@link #onResume()}.</p>
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions,
            grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult
                        != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                // The initialization flow's single entry point is
                // onResume. Clearing the latch here lets the next
                // resume run it. Nothing else is done — the resume
                // owns the state transitions.
                mPermissionsDenied = false;
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    MESSAGE_PERMISSIONS_REQUIRED,
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                mPermissionsDenied = true;
                applyNoSongState();
            }
        }
    }

    // ============================================================================
    // NavigationController Listener Implementation
    // ============================================================================

    /**
     * Enables or disables the playlist and metadata buttons
     * according to the current database-actions state.
     *
     * @param group Button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(
            NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches typefaces and touch animations,
     * constructs the album-art carousel with its swipe commit
     * listener, and primes the initial control state.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        mAlbumArtWrapper =
            (LinearLayout) findViewById(R.id.albumArtWrapper);
        mSongInfoGroup =
            (LinearLayout) findViewById(R.id.songInfoGroup);
        mTransportRow =
            (LinearLayout) findViewById(R.id.transportRow);

        if (mSongInfoGroup != null) {
            mDefaultSongInfoGravity = mSongInfoGroup.getGravity();
            mDefaultSongInfoPaddingTop =
                mSongInfoGroup.getPaddingTop();
        }

        if (mTransportRow != null) {
            mDefaultTransportPaddingBottom =
                mTransportRow.getPaddingBottom();
        }

        if (mAlbumArtContainer != null && mAlbumArtCache != null) {
            mAlbumArtCarousel = new AlbumArtCarousel(
                this, mAlbumArtContainer, mAlbumArtCache,
                mAlbumArtExecutor);
            mAlbumArtCarousel.setEdgeZonePx(
                dpToPx(VOLUME_GESTURE_EDGE_DP));
            mAlbumArtCarousel.setSwipeCommitListener(direction -> {
                if (direction > 0) {
                    playNextSong();
                } else if (direction < 0) {
                    playPreviousSong();
                }
            });
            mAlbumArtCarousel.attach();
        }

        applyAlbumArtClipping();
        setupAlbumArtGestures();

        final Typeface fontAwesomeTypeface =
            FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) {
            mPlayButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mPrevButton != null) {
            mPrevButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mNextButton != null) {
            mNextButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }

        if (mManagerButton != null) {
            mManagerButton.setLetterSpacing(0.1f);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setLetterSpacing(0.1f);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setLetterSpacing(0.1f);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setLetterSpacing(0.1f);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setLetterSpacing(0.1f);
        }

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        applyAlbumArtSize(getResources().getConfiguration());

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Refreshes the carousel's window from the bound service.
     *
     * <p>Called after the service is bound and on every resume. The
     * ordinary update path goes through the {@code UPDATE_PLAYER}
     * broadcast; this method exists for the reconnect and cold-start
     * cases, where the broadcast may have fired before the activity
     * was listening. A re-publication is not a fresh transition, so
     * the direction is {@code 0} and the restart flag is false.</p>
     */
    private void refreshCarouselFromService() {
        if (mMusicService == null || mAlbumArtCarousel == null) {
            return;
        }
        mAlbumArtCarousel.setWindow(
            mMusicService.getWindowSnapshot(), 0, false);
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN)
                            .scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL)
                            .scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Split-Screen Layout
    // ============================================================================

    /**
     * Applies the album-art size and visibility for the current
     * window height.
     *
     * <p>The decision is a pure function of
     * {@code config.screenHeightDp}, which in multi-window mode is
     * the height of this app's window, not the device screen.</p>
     *
     * <ul>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_FULL_HEIGHT_DP}: album art visible
     *       at {@link #ALBUM_ART_FULL_DP} dp.</li>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}: album art visible
     *       at {@link #ALBUM_ART_SHRUNK_DP} dp. The gestures remain
     *       available.</li>
     *   <li>Height below {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}:
     *       album art hidden. The wrapper is hidden with it, the
     *       title-and-artist group moves up to fill the vacated
     *       space, and the transport row's bottom padding is reduced
     *       so the artist line fits. See
     *       {@link #applySongInfoLayout(boolean)}.</li>
     * </ul>
     *
     * @param config Configuration carrying the current window height
     */
    private void applyAlbumArtSize(@NonNull Configuration config) {
        if (mAlbumArtContainer == null) {
            return;
        }

        final int heightDp = config.screenHeightDp;
        final int sizeDp;
        final int visibility;

        if (heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP) {
            sizeDp = ALBUM_ART_FULL_DP;
            visibility = View.VISIBLE;
        } else if (heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP) {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.VISIBLE;
        } else {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.GONE;
        }

        final int sizePx = dpToPx(sizeDp);
        final ViewGroup.LayoutParams params =
            mAlbumArtContainer.getLayoutParams();
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx;
            params.height = sizePx;
            mAlbumArtContainer.setLayoutParams(params);
        }
        if (mAlbumArtContainer.getVisibility() != visibility) {
            mAlbumArtContainer.setVisibility(visibility);
        }

        applySongInfoLayout(visibility == View.GONE);

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.onContainerResized();
        }
    }

    /**
     * Positions the title-and-artist group and the transport row for
     * the current album-art visibility.
     *
     * <p>When the album art is hidden, the wrapper is taken out of
     * the layout so its padding no longer contributes a visible band
     * above the song info. The title-and-artist group is pinned to
     * the top of its weight slot and given a top offset equal to the
     * wrapper's declared top padding — which is exactly the offset
     * the album-art top carries in full-screen mode. The title
     * therefore lands where the album-art top used to begin.</p>
     *
     * <p>The transport row's bottom padding is reduced at the same
     * time. The reduction passes sixteen dp of slot height to the
     * title-and-artist group, which is what the artist line needs in
     * a short split window; without it the artist extends past the
     * group's bottom and is clipped. The reduced value keeps the
     * transport buttons clear of the temporary toast, which sits at
     * a fixed offset from the window bottom.</p>
     *
     * <p>When the album art is visible, the wrapper is restored and
     * the group and the transport row return to their layout-declared
     * gravity, padding, and margins. Every other view in the
     * hierarchy is untouched.</p>
     *
     * @param albumArtHidden True when the album art is
     *        {@link View#GONE}
     */
    private void applySongInfoLayout(boolean albumArtHidden) {
        if (mAlbumArtWrapper != null) {
            final int wrapperVisibility =
                albumArtHidden ? View.GONE : View.VISIBLE;
            if (mAlbumArtWrapper.getVisibility()
                    != wrapperVisibility) {
                mAlbumArtWrapper.setVisibility(wrapperVisibility);
            }
        }

        if (mSongInfoGroup != null) {
            if (albumArtHidden) {
                final int albumArtTopOffset =
                    (mAlbumArtWrapper != null)
                        ? mAlbumArtWrapper.getPaddingTop()
                        : 0;
                mSongInfoGroup.setGravity(
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                mSongInfoGroup.setPadding(
                    mSongInfoGroup.getPaddingLeft(),
                    albumArtTopOffset,
                    mSongInfoGroup.getPaddingRight(),
                    mSongInfoGroup.getPaddingBottom());
            } else {
                mSongInfoGroup.setGravity(mDefaultSongInfoGravity);
                mSongInfoGroup.setPadding(
                    mSongInfoGroup.getPaddingLeft(),
                    mDefaultSongInfoPaddingTop,
                    mSongInfoGroup.getPaddingRight(),
                    mSongInfoGroup.getPaddingBottom());
            }
        }

        if (mTransportRow != null) {
            final int desiredBottomPadding = albumArtHidden
                ? dpToPx(TRANSPORT_ROW_SPLIT_BOTTOM_DP)
                : mDefaultTransportPaddingBottom;
            if (mTransportRow.getPaddingBottom()
                    != desiredBottomPadding) {
                mTransportRow.setPadding(
                    mTransportRow.getPaddingLeft(),
                    mTransportRow.getPaddingTop(),
                    mTransportRow.getPaddingRight(),
                    desiredBottomPadding);
            }
        }
    }

    // ============================================================================
    // Album-Art Gestures
    // ============================================================================

    /**
     * Attaches the gesture listener to the album-art container.
     *
     * <p>The listener classifies the gesture on the first
     * significant move. Horizontal moves become carousel swipes;
     * vertical moves that start in an edge zone become volume
     * changes; vertical moves that start at the centre are
     * cancelled. See {@link GestureMode} for the classification.</p>
     *
     * <p>While a gesture is active, the container requests its
     * parent to disallow intercepting the touch. That keeps a swipe
     * from being consumed by a scroll container above the album
     * art.</p>
     */
    private void setupAlbumArtGestures() {
        if (mAlbumArtContainer == null) {
            return;
        }
        mAlbumArtContainer.setOnTouchListener(
            new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                return handleAlbumArtGesture(view, event);
            }
        });
    }

    /**
     * Dispatches a touch event on the album-art container through
     * the gesture classifier and the selected mode's handler.
     *
     * @param view Album-art container
     * @param event Touch event
     * @return True when the gesture is being consumed
     */
    private boolean handleAlbumArtGesture(@NonNull View view,
                                          @NonNull MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return handleGestureDown(view, event);
            case MotionEvent.ACTION_MOVE:
                return handleGestureMove(view, event);
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return handleGestureUp(view, event);
            default:
                return false;
        }
    }

    /**
     * Handles the start of a touch sequence on the album-art
     * container.
     *
     * <p>Every touch is consumed at this point; the classification
     * happens on the first significant move. Both start coordinates
     * are recorded in the container's own coordinate space, the
     * same space the moves that will be compared against them
     * arrive in. The container's dimensions are sampled so the
     * volume mapping and the carousel threshold use the size the
     * container had at the moment the finger went down.</p>
     *
     * <p>The volume limit-echo state is reset here, so the first
     * move of every gesture establishes the limit side afresh.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_DOWN} event
     * @return Always true; the sequence is consumed from this point
     */
    private boolean handleGestureDown(@NonNull View view,
                                      @NonNull MotionEvent event) {
        mGestureMode = GestureMode.UNDECIDED;
        mGestureStartX = event.getX();
        mGestureStartY = event.getY();
        mGestureContainerWidth = Math.max(1, view.getWidth());
        mGestureContainerHeight = Math.max(1, view.getHeight());

        if (mAudioManager != null) {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume > 0) {
                mVolumeGestureMaxVolume = maxVolume;
                mVolumeGestureStartVolume =
                    mAudioManager.getStreamVolume(
                        AudioManager.STREAM_MUSIC);
            } else {
                mVolumeGestureMaxVolume = 0;
                mVolumeGestureStartVolume = 0;
            }
        } else {
            mVolumeGestureMaxVolume = 0;
            mVolumeGestureStartVolume = 0;
        }

        mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
        mVolumeGestureLimitEchoBaseline = Float.NaN;

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    /**
     * Handles a move event on the album-art container, classifying
     * the gesture on the first significant move and then dispatching
     * to the selected mode's handler.
     *
     * @param view Album-art container
     * @param event {@code ACTION_MOVE} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureMove(@NonNull View view,
                                      @NonNull MotionEvent event) {
        if (mGestureMode == GestureMode.UNDECIDED) {
            classifyGesture(event);
        }

        switch (mGestureMode) {
            case CAROUSEL:
                if (mAlbumArtCarousel != null) {
                    final float horizontalDisplacement =
                        event.getX() - mGestureStartX;
                    mAlbumArtCarousel.updateSwipe(
                        horizontalDisplacement);
                }
                return true;
            case VOLUME:
                handleVolumeDrag(event);
                return true;
            case CANCELLED:
            case UNDECIDED:
            default:
                return true;
        }
    }

    /**
     * Handles the release of a touch sequence on the album-art
     * container, committing the carousel swipe when it passed its
     * threshold and releasing the parent's touch interception.
     *
     * <p>A committed swipe is dispatched by the carousel through the
     * listener installed in {@link #initializeViews()}. This method
     * does not inspect the commit result; the carousel and the
     * service settle their agreement through the playback
     * broadcast.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_UP} or {@code ACTION_CANCEL} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureUp(@NonNull View view,
                                    @NonNull MotionEvent event) {
        if (mGestureMode == GestureMode.CAROUSEL
                && mAlbumArtCarousel != null) {
            final float horizontalDisplacement =
                event.getX() - mGestureStartX;
            mAlbumArtCarousel.endSwipe(horizontalDisplacement);
        }

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }

        mGestureMode = GestureMode.UNDECIDED;
        return true;
    }

    /**
     * Classifies a gesture on the first significant move.
     *
     * <p>The touch slop is read from the container's configuration.
     * Anything inside the slop leaves the mode at
     * {@link GestureMode#UNDECIDED}. A move whose horizontal
     * component dominates becomes a carousel swipe regardless of
     * where it started. A move whose vertical component dominates
     * becomes a volume gesture only when the touch started inside
     * one of the two edge zones; otherwise it is cancelled.</p>
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void classifyGesture(@NonNull MotionEvent event) {
        final float horizontalDisplacement =
            event.getX() - mGestureStartX;
        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float absoluteHorizontal =
            Math.abs(horizontalDisplacement);
        final float absoluteVertical =
            Math.abs(verticalDisplacement);
        final int touchSlop = ViewConfiguration.get(this)
            .getScaledTouchSlop();

        if (absoluteHorizontal < touchSlop
                && absoluteVertical < touchSlop) {
            return;
        }

        if (absoluteHorizontal > absoluteVertical) {
            mGestureMode = GestureMode.CAROUSEL;
            if (mAlbumArtCarousel != null) {
                mAlbumArtCarousel.beginSwipe();
            }
            return;
        }

        final int edgeZone = dpToPx(VOLUME_GESTURE_EDGE_DP);
        final boolean startedInEdge =
            mGestureStartX <= edgeZone
                || mGestureStartX >= mGestureContainerWidth - edgeZone;
        if (startedInEdge && mVolumeGestureMaxVolume > 0) {
            mGestureMode = GestureMode.VOLUME;
            return;
        }

        mGestureMode = GestureMode.CANCELLED;
    }

    /**
     * Applies a vertical drag to the music stream volume.
     *
     * <p>The finger's vertical displacement is mapped linearly onto
     * the volume range: a full container height of travel moves
     * through every step. Upward travel raises the volume; downward
     * travel lowers it. The target is clamped to the range the
     * platform reports.</p>
     *
     * <p>When the target is clamped to a limit and the user continues
     * dragging past it, the volume toast echoes every
     * {@link #VOLUME_LIMIT_ECHO_STEP_FRACTION} of the range the
     * finger travels beyond the limit. The echo gives the user
     * rhythmic confirmation that the gesture is still being tracked
     * even though the device volume cannot change further. The
     * rhythm is measured on the volume axis, so it is the same on
     * every device regardless of how many volume steps the platform
     * reports.</p>
     *
     * <p>The first arrival at a limit fires the ordinary toast
     * through the volume-change path; the echo path is used only for
     * the additional travel past a limit whose toast has already
     * fired at that limit during this gesture.</p>
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void handleVolumeDrag(@NonNull MotionEvent event) {
        if (mAudioManager == null || mVolumeGestureMaxVolume <= 0) {
            return;
        }

        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float fraction =
            -verticalDisplacement / mGestureContainerHeight;
        final float unclampedTarget = mVolumeGestureStartVolume
            + fraction * mVolumeGestureMaxVolume;
        int targetVolume = Math.round(unclampedTarget);
        targetVolume = Math.max(0,
            Math.min(mVolumeGestureMaxVolume, targetVolume));

        final int currentVolume = mAudioManager.getStreamVolume(
            AudioManager.STREAM_MUSIC);

        // Establish which limit, if any, the gesture is currently riding.
        // The side is recorded the first time the target reaches a limit
        // and cleared the moment the target moves back inside the range.
        if (targetVolume == mVolumeGestureMaxVolume) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MAXIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MAXIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else if (targetVolume == 0) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MINIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MINIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else {
            mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
            mVolumeGestureLimitEchoBaseline = Float.NaN;
        }

        if (targetVolume != currentVolume) {
            try {
                mAudioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC, targetVolume, 0);
                showVolumeToast(targetVolume);
            } catch (SecurityException exception) {
                Log.w(TAG, "setStreamVolume refused", exception);
            }
            // The change was the arrival toast for this limit, if the
            // target is now at one. Record the baseline so the echo
            // rhythm starts from here.
            if (targetVolume == mVolumeGestureMaxVolume) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f,
                        unclampedTarget - mVolumeGestureMaxVolume);
            } else if (targetVolume == 0) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f, -unclampedTarget);
            }
            return;
        }

        // No change in device volume. If the gesture is riding a limit,
        // echo the toast each time the finger has travelled an additional
        // echo step past the limit since the last toast.
        final float echoStep = Math.max(1f,
            mVolumeGestureMaxVolume * VOLUME_LIMIT_ECHO_STEP_FRACTION);

        if (targetVolume == mVolumeGestureMaxVolume
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MAXIMUM) {
            final float overshoot =
                unclampedTarget - mVolumeGestureMaxVolume;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        } else if (targetVolume == 0
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MINIMUM) {
            final float overshoot = -unclampedTarget;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        }
    }

    /**
     * Shows a transient toast reporting the current volume as a
     * percentage.
     *
     * <p>Uses the normal duration so the reading is legible at a
     * glance and matches the duration used by the repeat and shuffle
     * confirmations. A gesture that moves through several steps
     * replaces the previous toast each time, so the duration applies
     * to the last value in the sequence.</p>
     *
     * @param volumeLevel Current stream volume
     */
    private void showVolumeToast(int volumeLevel) {
        if (mVolumeGestureMaxVolume <= 0) {
            return;
        }
        final int percent = Math.round(
            100f * volumeLevel / mVolumeGestureMaxVolume);
        ToastManager.showToast(this, "Volume: " + percent + "%",
            ToastManager.LENGTH_NORMAL);
    }

    // ============================================================================
    // Permission and Initialization Methods
    // ============================================================================

    /**
     * Requests the runtime permissions the app needs and proceeds
     * with initialization once they have been decided.
     *
     * <p>The set of permissions is owned by {@link PermissionChecker};
     * this method asks for the array the checker reports as missing
     * and requests it. It builds no list of its own, so a change to
     * the version gates in the checker is seen here without a second
     * edit.</p>
     *
     * <p>When every permission is already granted, the initialization
     * flow is entered immediately. Otherwise the missing permissions
     * are requested and the method returns; the outcome is read by
     * {@link #onResume()} on the same turn the permission dialog
     * dismisses, and the initialization flow runs from there.</p>
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            proceedWithInitialization();
            return;
        }

        final String[] permissionsToRequest =
            PermissionChecker.getMissing(this);

        if (permissionsToRequest.length > 0) {
            requestPermissions(
                permissionsToRequest, PERMISSION_REQUEST_CODE);
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Runs the initialization path once permissions have been
     * decided.
     *
     * <p>Sets {@link #mInitializationAttempted} at entry so the
     * resume-time retry never runs this method twice for one
     * activity instance.</p>
     *
     * <p>Starts and binds the playback service. The bind's
     * synchronous return value is checked: a refused bind is
     * reported to the user through the same exit path as an
     * abandoned load, without waiting for the library-load heartbeat
     * deadline to fire.</p>
     *
     * <p>When the service is already bound, the initialization path
     * skips the bind and proceeds directly to the load. This is the
     * recovery path for a runtime permission restore, where the
     * service was bound before the revocation and is still bound
     * when the permission is restored.</p>
     *
     * <p>The incoming-file hand-off is dispatched only when the bind
     * was accepted, or when the service was already bound. A refused
     * bind means the service cannot be reached and no path will
     * reach the incoming file's target, so the hand-off would only
     * park a path that nothing would ever resolve.</p>
     */
    private void proceedWithInitialization() {
        mInitializationAttempted = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        preloadLastSongDisplay();

        if (mMusicService != null && mIsServiceBound) {
            // The service is already bound. This is the recovery
            // path after a runtime permission restore: the bind was
            // performed before the revocation, and re-binding would
            // be a no-op that never re-fires the connection
            // callback. Trigger the load directly so the library is
            // refreshed against the newly readable filesystem.
            loadFullPlaylistInBackground();
            handleIncomingFile(getIntent());
            return;
        }

        final Intent serviceIntent = new Intent(
            MusicPlayer.this, MusicService.class);
        startService(serviceIntent);

        final boolean bound = bindService(
            serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        if (!bound) {
            Log.e(TAG, "bindService refused; abandoning library load");
            abandonLibraryLoadOverlay(MESSAGE_SERVICE_BIND_FAILED);
            return;
        }

        handleIncomingFile(getIntent());
    }

    /**
     * Requests an exemption from battery optimizations when the app
     * is not yet exempt.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager =
                (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null
                    && !powerManager.isIgnoringBatteryOptimizations(
                        getPackageName())) {
                try {
                    Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(
                        Uri.parse("package:" + getPackageName()));
                    startActivityForResult(
                        intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG,
                        "Failed to request battery optimization",
                        exception);
                }
            }
        }
    }

    // ============================================================================
    // Incoming File Handling
    // ============================================================================

    /**
     * Handles an incoming audio file reference.
     *
     * <p>The single entry point for a file opened from another app.
     * The method resolves the file path once, decides once whether
     * the song is already known to the library, and dispatches to one
     * of two branches. Both branches converge on
     * {@link #handOffIncomingPath(String)}, which is the only method
     * in this activity that writes the service's pending slot.</p>
     *
     * <p>The service is the authority for playback. The activity does
     * not decide when a song plays; it declares that a path should
     * become the target, and the state machine resolves the request
     * against its current state. Every state the machine can be in —
     * idle, preparing, ready, playing, paused, stopping — is reached
     * through the same public request the transport buttons use, and
     * the machine handles it through the same code paths it already
     * runs for every other playlist change. In every case the
     * MediaPlayer bound to the outgoing song is released by
     * {@code beginTransition} before the incoming song is prepared;
     * the activity does not touch the player.</p>
     *
     * <p>For a file not yet known to the library, the new-song branch
     * also schedules a pre-decode of the incoming file's art on
     * {@link #mMetadataLoader}. The decode runs in parallel with the
     * loose-track insert and the playlist rebuild; the carousel's
     * shared cache is therefore usually warm by the time the
     * service's first window reaches it. See
     * {@link #preDecodeIncomingArt(String)}.</p>
     *
     * @param intent The intent that triggered the activity, or null
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        if (isSongInLibrary(filePath)) {
            Log.d(TAG, "Song is already in the library");
            handOffIncomingPath(filePath);
            return;
        }

        Log.d(TAG, "New song detected; adding as a loose track");

        // Park the path in the service before the insertion runs.
        // The insertion's completion announces the playlist change
        // with UPDATE_PLAYLIST, and that broadcast must not reach
        // the service while its pending-path slot is still empty —
        // an empty slot at rebuild time means the service falls
        // back to the persisted last-played path and applies the
        // cold-start pause to it, which is the state the incoming
        // path then has to correct. Parking first makes the
        // incoming path the anchor of the rebuild from the start.
        handOffIncomingPath(filePath);

        // Decode the incoming file's art now, in parallel with the
        // insert and the playlist rebuild, so the shared album-art
        // cache is warm by the time the service's first window
        // reaches the carousel. The reveal's cross-fade begins only
        // once the incoming path's art has resolved; a decode
        // started here is the resolve the reveal waits for, so the
        // reveal presents the real art on its first frame rather
        // than holding the outgoing art on screen while the decode
        // finishes.
        preDecodeIncomingArt(filePath);

        final Song newSong = parseIncomingSong(filePath);
        insertLooseTrackAndHandOff(newSong);
    }

    /**
     * Returns whether the given path is already known to the library,
     * either as a song in an imported folder or as a loose track.
     *
     * <p>Checks the main songs table first; that is the common case
     * for a file that lives in a folder the user has imported. Falls
     * back to a scan of the loose-tracks table, which is typically
     * small.</p>
     *
     * @param filePath Absolute path of the file
     * @return True when the path is already in the library
     */
    private boolean isSongInLibrary(@NonNull String filePath) {
        if (SongDatabase.getInstance(this).hasSong(filePath)) {
            return true;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (looseSong != null
                        && filePath.equals(looseSong.getPath())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Parses the metadata for an incoming file, falling back to the
     * file name when {@link CharacterMapper} cannot read the embedded
     * tags.
     *
     * @param filePath Absolute path of the file
     * @return The parsed song; never null
     */
    @NonNull
    private Song parseIncomingSong(@NonNull String filePath) {
        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        if (parsedSong != null) {
            return parsedSong;
        }
        String fileName = new File(filePath).getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            fileName = fileName.substring(0, dotIndex);
        }
        return new Song(
            fileName,
            "Unknown Artist",
            "Unknown Album",
            "Unknown Genre",
            filePath,
            0,
            null);
    }

    /**
     * Inserts the given song as a loose track and hands the path to
     * the service once the insertion completes.
     *
     * <p>The insertion and the playlist rebuild are owned by
     * {@link PlaylistManager#addLooseTrackAndUpdate(Song,
     * PlaylistManager.UpdateCallback)}. When the insertion completes,
     * the manager announces the change with {@code UPDATE_PLAYLIST},
     * which every actor in the process listens for; the service's
     * rebuild picks up the path the initial hand-off already parked.</p>
     *
     * <p>The completion callback does not re-fire the hand-off. Doing
     * so would overwrite the pending slot with the older request's
     * path when a newer request has arrived in the meantime, and the
     * newer request would then be lost. The hand-off in
     * {@link #handleIncomingFile} is the only writer of the pending
     * slot, and each request writes it once, in the order the user
     * made the request.</p>
     *
     * @param newSong The song to insert
     */
    private void insertLooseTrackAndHandOff(
            @NonNull final Song newSong) {
        final String filePath = newSong.getPath();

        PlaylistManager.getInstance(this).addLooseTrackAndUpdate(
            newSong,
            new PlaylistManager.UpdateCallback() {

            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track inserted: " + filePath);
                // addLooseTrackAndUpdate has already broadcast
                // UPDATE_PLAYLIST. The pending slot already holds
                // this path from the initial hand-off; the rebuild
                // will find and play it. No second hand-off.
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG,
                    "Failed to insert loose track: " + error);
                mPendingIncomingPath = null;
                ToastManager.showToast(MusicPlayer.this,
                    "Failed to open file: " + error,
                    ToastManager.LENGTH_NORMAL);
            }
        });
    }

    /**
     * Hands the given path to the service as the target of the next
     * transition.
     *
     * <p>Two mechanisms carry the path, and they cover complementary
     * cases.</p>
     *
     * <ul>
     *   <li>{@code SET_PENDING_SONG} broadcast — reaches the service
     *       whether the activity is bound to it or not, as long as
     *       the service is running. The service's receiver parks the
     *       path; if the path is already in the service's playlist,
     *       the park becomes a transition request through
     *       {@code playPendingSongIfExists}. If not, the path remains
     *       parked until the next playlist rebuild resolves it as
     *       the anchor.</li>
     *   <li>{@link #mPendingIncomingPath} — the activity-side parking
     *       spot. Read by {@link #mServiceConnection}'s
     *       {@code onServiceConnected} when the service was not yet
     *       running or bound at the moment the intent arrived. Once
     *       the service binds, the connection hands the path over
     *       the same way.</li>
     * </ul>
     *
     * <p>The activity-side parking is cleared as soon as the fast
     * path confirms the service is bound, so a broadcast that has
     * already been dispatched is the sole remaining owner of the
     * request. When the service is not bound, the parking stays set
     * until the connection callback consumes it.</p>
     *
     * <p>The playlist change itself is announced by
     * {@link PlaylistManager} when a new song was inserted, so this
     * method does not broadcast {@code UPDATE_PLAYLIST}. The service
     * rebuilds its playlist from the announcement, resolves the
     * parked path as the anchor, and drives the state machine to the
     * new song. When the song was already in the library, no
     * playlist change occurred, so the park alone is enough: the
     * service's {@code playPendingSongIfExists} resolves the path
     * against its current playlist and begins the transition.</p>
     *
     * @param filePath Absolute path of the file
     */
    private void handOffIncomingPath(@NonNull String filePath) {
        Log.d(TAG, "Handing off incoming path: " + filePath);

        // Park the path in the activity first. If the service is not
        // running or not yet bound, the connection callback reads
        // this field and hands the path over when the service binds.
        mPendingIncomingPath = filePath;

        // Broadcast the pending path. The service's receiver parks
        // it in the service's pending slot; if the path is already
        // in the service's playlist, the park becomes a transition
        // request.
        final Intent pendingIntent =
            new Intent(ACTION_SET_PENDING_SONG);
        pendingIntent.putExtra("song_path", filePath);
        sendBroadcast(pendingIntent);

        // If the service is bound, the broadcast is guaranteed to
        // reach it, so the activity-side parking is no longer needed.
        // The connection callback only reads it when the service was
        // not bound at the moment of the hand-off.
        if (mMusicService != null && mIsServiceBound) {
            mPendingIncomingPath = null;
        }
    }

    /**
     * Decodes the given file's embedded art on the metadata loader
     * and hands the bitmap to the carousel when it resolves.
     *
     * <p>Reuses the same decode path {@link #loadSongMetadata} uses
     * for the persisted last song: {@link MediaMetadataRetriever}
     * reads the embedded picture, the picture is downsampled to the
     * album-art maximum, and the result lands in
     * {@link #mAlbumArtCache}. The carousel reads from that same
     * cache through its own reference, so no transfer is needed;
     * {@link AlbumArtCarousel#onArtReady} is called to publish the
     * resolved art to the carousel, where it resolves any reveal
     * that is waiting on the path and re-renders the slots.</p>
     *
     * <p>Runs on {@link #mMetadataLoader}, the same single-thread
     * executor the cold-start preload uses. The returned
     * {@link Song} from {@link #loadSongMetadata} is discarded:
     * the playlist rebuild owns the song's identity, and this
     * method's only purpose is to warm the art cache before the
     * carousel needs it.</p>
     *
     * @param filePath Absolute path of the incoming file
     */
    private void preDecodeIncomingArt(@NonNull final String filePath) {
        if (mMetadataLoader == null || mMetadataLoader.isShutdown()) {
            return;
        }
        mMetadataLoader.execute(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                // Decodes into mAlbumArtCache as a side effect.
                loadSongMetadata(filePath);

                final Bitmap decoded = (mAlbumArtCache != null)
                    ? mAlbumArtCache.get(filePath)
                    : null;
                if (decoded == null || decoded.isRecycled()) {
                    return;
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.onArtReady(
                                filePath, decoded);
                        }
                    }
                });
            }
        });
    }

    // ============================================================================
    // URI Helper Methods
    // ============================================================================

    /**
     * Resolves the filesystem path of the given content URI, copying
     * the content to a temporary file when the media store path is
     * not available.
     *
     * @param uri Content URI to resolve
     * @return The filesystem path, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {
                    android.provider.MediaStore.Audio.Media.DATA
                };
                cursor = getContentResolver().query(uri, projection,
                    null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex =
                        cursor.getColumnIndexOrThrow(
                            android.provider.MediaStore.Audio.Media
                                .DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    /**
     * Copies the content of the given URI to a temporary cache file.
     *
     * @param uri Content URI to copy
     * @return The path of the temporary file, or null on failure
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream =
                getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_"
                    + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream =
                new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies
     * inside the given folder.
     *
     * @param folderUri Folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageAccessHelper == null) {
            return;
        }

        final String folderPath =
            mStorageAccessHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this)
                    .removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ============================================================================
    // Playlist Loading Methods
    // ============================================================================

    /**
     * Loads the full playlist on a background thread and hands it
     * to the bound service when the load completes.
     *
     * <p>When the load returns no songs but the user has folders
     * configured, the load is not the truth of the library — it is a
     * gap in MediaStore's index. The automatic folder update is run
     * in that case, and the cold-start overlay stays up across both
     * stages, hiding on the automatic update's completion or error
     * callback instead. The user sees one continuous load rather
     * than a load followed by a correction.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) {
            return;
        }

        OverlayManager.show(OverlayManager.REASON_COLD_START);

        mMusicLibrary.loadAllSongsWithProgress(
            new MusicLibrary.LoadProgressListener() {

            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(
                        MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(
                    @NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                }
                refreshCarouselFromService();
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();

                // When the cold-start load returns no songs but the
                // user has folders configured, the empty result is
                // a gap in MediaStore's index rather than an empty
                // library. Run the same folder-update scan the
                // UPDATE button runs, which reconciles the songs
                // table against the paths found under every kept
                // folder. The overlay stays up through the update,
                // so the user sees one continuous load.
                if (songs.isEmpty()
                        && mMusicLibrary != null
                        && !mMusicLibrary.getSelectedFolders().isEmpty()
                        && !isFinishing()
                        && !isDestroyed()) {
                    triggerAutomaticFolderUpdate();
                    return;
                }

                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Runs the folder-update scan automatically when the cold-start
     * load returns no songs but folders are configured.
     *
     * <p>The scan is the same one {@link FolderManager}'s UPDATE
     * button runs through
     * {@link PlaylistManager#updatePlaylist(PlaylistManager.UpdateCallback)}.
     * It reconciles the songs table against the paths found under
     * every kept folder, so a file the initial MediaStore query
     * missed is picked up here. The service's rebuild follows
     * automatically: the scan's completion broadcast is handled by
     * this activity's own receiver, which refreshes the library,
     * hands the songs to the service, and triggers genre loading.</p>
     *
     * <p>The cold-start overlay stays up across the update so the
     * user sees one continuous load. It is hidden by this method's
     * own completion or error callback, not by the load that
     * triggered it.</p>
     */
    private void triggerAutomaticFolderUpdate() {
        PlaylistManager.getInstance(this).updatePlaylist(
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Automatic folder update complete: "
                    + songCount + " songs");
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                sendBroadcast(new Intent(
                    ACTION_UPDATE_PLAYLIST_FROM_FOLDERS));
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Automatic folder update failed: "
                    + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is scheduled. A
     * second call while a heartbeat is already scheduled does
     * nothing.
     *
     * <p>The heartbeat runnable re-posts itself every
     * {@link #LIBRARY_HEARTBEAT_INTERVAL_MS} milliseconds while the
     * {@link #OPERATION_LIBRARY_LOAD} operation is on top of the
     * stack, and stops when the operation is gone. It also stops
     * when {@link #LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS} has passed
     * since the first heartbeat: the operation is considered
     * abandoned, and {@link #abandonLibraryLoadOverlay(String)} is
     * called to tear the overlay down and tell the user.</p>
     *
     * <p>The deadline is what keeps the heartbeat honest. The
     * heartbeat is the signal {@link ToastManager}'s stuck detector
     * watches, so a heartbeat that never stops prevents the detector
     * from ever firing, no matter how long the operation has been
     * running. Bounding the heartbeat is what lets the detector do
     * its job for the case the load never completes — a bind that
     * was accepted but whose callback never arrives, for
     * instance.</p>
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        final long startedAt = SystemClock.elapsedRealtime();
        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                if (SystemClock.elapsedRealtime() - startedAt
                        > LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS) {
                    Log.w(TAG,
                        "Library load heartbeat deadline exceeded; "
                            + "abandoning overlay");
                    mLibraryHeartbeatRunnable = null;
                    abandonLibraryLoadOverlay(
                        MESSAGE_LIBRARY_LOAD_FAILED);
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(
                    this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(
            mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    /**
     * Abandons the library-load overlay and tells the user the
     * library could not be loaded.
     *
     * <p>Called by the heartbeat runnable when
     * {@link #LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS} has passed, and by
     * {@link #proceedWithInitialization()} when the service bind is
     * refused synchronously. Both cases share the same problem: the
     * load will never complete, and no other callback will clear the
     * overlay.</p>
     *
     * <p>The overlay and the dim spinner are hidden under the same
     * operation ID the overlay was shown under, and a short toast
     * carries the failure message. The activity remains usable: no
     * operation is left on the {@link ToastManager} stack, and the
     * next cold-start attempt starts from a clean state.</p>
     *
     * @param message Text to display in the failure toast
     */
    private void abandonLibraryLoadOverlay(@NonNull String message) {
        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
        OverlayManager.hide(OverlayManager.REASON_COLD_START);
        if (!isFinishing() && !isDestroyed()) {
            ToastManager.showToast(
                this, message, ToastManager.LENGTH_NORMAL);
        }
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Runs the given UI update on the main thread, coalescing
     * requests that arrive while another update is in flight.
     *
     * @param update The update to run
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }

        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate =
                            mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Writes the given song's title and artist to the UI.
     *
     * @param song Song to display, or null
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Writes the given playing song's title and artist to the UI
     * and refreshes the album art.
     *
     * @param song Song that started playing, or null
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshCarouselFromService();
                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Enables every transport control when the library contains
     * songs.
     *
     * <p>Called only from receivers that require a bound service, so
     * the enabled state it writes is always consistent with a
     * service being available.</p>
     */
    private void enableAllControls() {
        final boolean hasSongs =
            (mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0);

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }

    /**
     * Applies the current library state to the previous, next,
     * repeat, and shuffle controls.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs =
            (mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0);

        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(
                mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(
                mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }

    /**
     * Shows the empty state: placeholder title, placeholder artist,
     * placeholder album art, and disabled transport controls.
     *
     * <p>The same state is used when the library is empty and when
     * the runtime permissions the app needs are not granted. The two
     * conditions are indistinguishable from the user's seat: in
     * both cases the app cannot play anything. The permission case
     * is disambiguated by the toast shown at the moment of the
     * denial, not by a difference in the screen itself.</p>
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.setWindow(PlaybackWindow.EMPTY, 0, false);
        }

        if (mAlbumArtContainer != null) {
            if (mPlaceholderBitmap != null
                    && !mPlaceholderBitmap.isRecycled()) {
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.setPlaceholder(
                        mPlaceholderBitmap);
                }
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
        }

        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(
                mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(
                mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(
                mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(
                mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(
                mShuffleButton, false, false);
        }

        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }

        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    // ============================================================================
    // Playback Control Methods
    // ============================================================================

    /**
     * Runs the given service action on the main thread while holding
     * the service lock, when the service is bound.
     *
     * @param action The service action to run
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays the song at the given index and updates the UI.
     *
     * @param index Index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0
            && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles playback through the service when the library contains
     * songs.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null
                && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        safeCallService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    /**
     * Asks the service to advance.
     *
     * <p>The request is dispatched in one main-thread turn. The
     * service assigns the target, bumps the generation, notes the
     * direction and restart for that generation, and starts the
     * transition. The carousel's animation begins when the service's
     * committing broadcast reaches the activity — the same signal
     * the automatic advance produces — so the strip moves against an
     * idle main thread and in step with the transition the service
     * is already running.</p>
     *
     * <p>The request is dropped when the activity is not bound,
     * matching every other transport action the activity dispatches
     * while unbound.</p>
     */
    private void playNextSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playNextSong();
        }
    }

    /**
     * Asks the service to go back.
     *
     * <p>Symmetric to {@link #playNextSong()}. The service notes the
     * backward direction and, when the request resolves to a restart
     * — repeat-one, a single-song playlist, or a wrap that lands on
     * the current index — the restart flag with it. The carousel
     * reads both from the service's broadcast and runs the matching
     * animation, the same visual the automatic advance produces.</p>
     */
    private void playPreviousSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playPreviousSong();
        }
    }

    // ============================================================================
    // Button State Update Methods
    // ============================================================================

    /**
     * Updates the repeat button's label and active state from the
     * service's current repeat mode.
     */
    private void updateRepeatButton() {
        if (mMusicService != null && mRepeatButton != null
                && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled =
                hasSongs && mRepeatButton.isEnabled();

            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);

                if (repeatMode == 2) {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                }

                mThemeHelper.updateControlButton(
                    mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(
                    mRepeatButton, false, false);
            }
        }
    }

    /**
     * Updates the shuffle button's active state from the service's
     * current shuffle flag.
     */
    private void updateShuffleButton() {
        if (mMusicService != null && mShuffleButton != null
                && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled =
                hasSongs && mShuffleButton.isEnabled();

            mShuffleButton.setText(FontAwesome.SHUFFLE);

            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(
                    mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(
                    mShuffleButton, false, false);
            }
        }
    }

    /**
     * Updates the play/pause button's label and enabled state from
     * the service's current playback state.
     *
     * <p>The button is enabled only when the library holds songs
     * <em>and</em> the service is bound. Every tap on the button
     * resolves to a service call; while the service is not bound,
     * the call is a no-op, and a button that looks live but does
     * nothing is the wrong state to show. The disabled state is the
     * honest one for both the empty library and the missing
     * service.</p>
     *
     * <p>{@link MusicService#isPlaying()} reports the destination
     * of the current transition, so the button never flashes a
     * pause icon during a next/previous switch. The play icon
     * appears only when the state machine is genuinely paused and
     * will not auto-start.</p>
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing()
                        || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                final boolean hasSongs =
                    (mMusicLibrary != null
                        && mMusicLibrary.getSongCount() > 0);
                final boolean serviceReady =
                    (mMusicService != null && mIsServiceBound);

                if (!hasSongs || !serviceReady) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(
                        mPlayButton, false, false);
                    return;
                }

                try {
                    final Song currentSong =
                        mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mPlayButton.setEnabled(true);
                        mThemeHelper.updateControlButton(
                            mPlayButton, true, true);
                        return;
                    }

                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying
                        ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mPlayButton.setEnabled(true);
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                } catch (Exception exception) {
                    Log.e(TAG,
                        "Error updating play/pause button",
                        exception);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(
                        mPlayButton, false, false);
                }
            }
        });
    }

    // ============================================================================
    // Seek Bar Methods
    // ============================================================================

    /**
     * Attaches the seek-bar change listener.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser && mMusicService != null
                        && seekBar.isEnabled()
                        && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts the periodic time-display update runnable.
     *
     * <p>Each tick is a candidate for a layout pass: the seek bar's
     * maximum may change when a new song's duration becomes known, and
     * both clock texts may change. While the carousel is animating,
     * the tick is skipped and rescheduled for the next interval, so
     * the layout pass does not land on a frame the animation is
     * drawing. The clock and the seek bar are updated on the first
     * tick after the animation settles.</p>
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                // Skip the update while the carousel is animating.
                // A song transition changes the seek bar's maximum
                // and both clock texts in the same tick, and the
                // resulting layout pass lands mid-slide and is drawn
                // on the next frame. The tick that would have fired
                // during the animation is not missed: the seek bar
                // and the two clocks update on the first tick after
                // the animation settles.
                if (mAlbumArtCarousel != null
                        && mAlbumArtCarousel.isAnimating()) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition =
                        service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong =
                            service.getCurrentSong();
                        if (currentSong != null
                                && currentSong.getDuration() > 0) {
                            duration =
                                (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(
                                formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(
                                formatTime(duration));
                        }

                        if (mSeekBar != null
                                && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display",
                        exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(
                        this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Returns the given duration formatted as {@code mm:ss} or
     * {@code hh:mm:ss}.
     *
     * @param milliseconds Duration in milliseconds
     * @return The formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d",
                hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ============================================================================
    // Album Art Methods
    // ============================================================================

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested size.
     *
     * @param options Options whose bounds have been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateInSampleSize(
            @NonNull BitmapFactory.Options options,
            int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes the given image bytes with downsampling to the
     * requested size.
     *
     * @param data Image bytes to decode
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth,
                                       int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(
            data, 0, data.length, options);

        options.inSampleSize =
            calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, options);
    }

    /**
     * Returns the path of the current song, or null when no song is
     * playing.
     *
     * @return The current song's path, or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null
                && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Loads and displays the current themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    // ============================================================================
    // Placeholder Methods
    // ============================================================================

    /**
     * Rebuilds the themed placeholder bitmap from the source image
     * and applies the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task =
            mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null
                                && !mOriginalPlaceholderBitmap
                                    .isRecycled()) {
                            tintedBitmap =
                                mOriginalPlaceholderBitmap.copy(
                                    Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options =
                            new BitmapFactory.Options();
                        options.inPreferredConfig =
                            Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap =
                            BitmapFactory.decodeResource(
                                getResources(),
                                R.drawable.album_art_placeholder,
                                options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null
                                        && !mOriginalPlaceholderBitmap
                                            .isRecycled()) {
                                    mOriginalPlaceholderBitmap
                                        .recycle();
                                }
                                mOriginalPlaceholderBitmap =
                                    tintedBitmap.copy(
                                        Bitmap.Config.ARGB_8888,
                                        true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(
                        themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null
                                        && !mPlaceholderBitmap
                                            .isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            if (mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.setPlaceholder(
                                    mPlaceholderBitmap);
                            }
                            applyAlbumArtClipping();
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG,
                        "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cancels any in-flight placeholder render task and recycles
     * the placeholder bitmaps.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Recycles the given bitmap, ignoring any exception.
     *
     * @param bitmap Bitmap to recycle, or null
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ============================================================================
    // Album Art Clipping Methods
    // ============================================================================

    /**
     * Applies rounded-corner clipping and the container background
     * to the album art container.
     *
     * <p>The outline provider reads the view's current width and
     * height at outline time, and the framework invalidates the
     * outline when the view's size changes. A resize from the
     * split-screen layout is therefore reflected in the clipped
     * corners without any coordination here.</p>
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(
                new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(
                        View view,
                        android.graphics.Outline outline) {
                    final int radius =
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0,
                        view.getWidth(), view.getHeight(), radius);
                }
            });
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        } else {
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        }
    }

    // ============================================================================
    // Navigation Methods
    // ============================================================================

    /**
     * Opens the folder manager activity with the slide-left
     * transition.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the playlist activity with the slide-right transition.
     */
    private void openPlaylist() {
        final Intent intent =
            new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the metadata editor for the current song, or in the
     * awaiting state when no song is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent =
            new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path",
                currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra(
                    "song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Returns the current song from the service, or null when the
     * service is not bound.
     *
     * @return The current song, or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ============================================================================
    // Cold-Start Preload
    // ============================================================================

    /**
     * Paints the previous song's title, artist, and art before the
     * playlist loads.
     */
    private void preloadLastSongDisplay() {
        final SharedPreferences preferences = getSharedPreferences(
            PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(
            KEY_LAST_SONG_PATH, null);

        if (lastPath == null || !new File(lastPath).exists()) {
            applyNoSongState();
            return;
        }

        if (mSongTitle != null) {
            mSongTitle.setText("Loading...");
        }
        if (mSongArtist != null) {
            mSongArtist.setText("Loading...");
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
        }

        mCurrentMetadataFuture =
            mMetadataLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                final Song loadedSong = loadSongMetadata(lastPath);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (loadedSong != null
                                && mThemeHelper != null) {
                            mCachedLastSong = loadedSong;
                            if (mSongTitle != null) {
                                mSongTitle.setText(
                                    loadedSong.getTitle());
                                mSongTitle.setTextColor(
                                    mThemeHelper
                                        .getThemeColorInt());
                            }
                            if (mSongArtist != null) {
                                mSongArtist.setText(
                                    loadedSong.getArtist());
                                mSongArtist.setTextColor(
                                    Color.parseColor("#C0C0C0"));
                            }

                            final Bitmap cachedArt =
                                mAlbumArtCache != null
                                    ? mAlbumArtCache.get(lastPath)
                                    : null;
                            if (cachedArt != null
                                    && mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.onArtReady(
                                    lastPath, cachedArt);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                        } else {
                            applyNoSongState();
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the metadata for the given path from the database when
     * a usable cached entry exists, and from the file otherwise.
     *
     * @param lastPath Absolute path of the song
     * @return The song, or null when the file cannot be read
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong =
            SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null
                && !cachedSong.getTitle().isEmpty()
                && !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: "
                + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = "Unknown Artist";
            }
            if (album == null) {
                album = "Unknown Album";
            }

            String genre = "Unknown Genre";
            Song databaseSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null
                    && databaseSong.getGenre() != null
                    && !"Unknown Genre".equals(
                        databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
            } else {
                String fileGenre =
                    CharacterMapper.getGenre(lastPath);
                if (fileGenre != null
                        && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                }
            }

            Song resultSong = new Song(
                title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(
                    albumArt, MAX_ALBUM_ART_SIZE_PX,
                    MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: "
                + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Registers the receiver for app-restart broadcasts.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        ContextCompat.registerReceiver(
            this, mRestartReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(
                        intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter =
            new IntentFilter("THEME_COLOR_CHANGED");
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Applies the current theme color to every control in the
     * activity and rebuilds the placeholder bitmap.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed()
                || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        OverlayManager.setColor(mThemeHelper.getThemeColorInt());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(
                mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(
                mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(
                mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(
                mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(
                mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(
                mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(
                mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(
                mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn =
                mMusicService != null
                    && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(
                mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn =
                mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(
                mShuffleButton, mShuffleButton.isEnabled(),
                isShuffleOn);
        }

        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(
                mSeekBar, mSeekBar.isEnabled());
        }

        if (mSongTitle != null) {
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    /**
     * Restarts the activity with the no-animation flag.
     */
    private void performUpdate() {
        final Intent restartIntent =
            new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     *
     * <p>The {@code UPDATE_PLAYER} receiver is the single commit
     * driver. Every surface the transition touches — the carousel's
     * strip, the notification, the media session, the title, the
     * artist, the seek bar's range, the transport glyph — is written
     * from one runnable that runs on one main-thread turn. The
     * receiver reads the window, the transition direction, and the
     * restart flag from the broadcast and forwards all three to the
     * carousel; the carousel's animation is the one the service named,
     * started on the turn the service's broadcast reaches the
     * activity. The carousel reports through
     * {@link AlbumArtCarousel#setWindow(PlaybackWindow, int, boolean)}
     * whether the window landed synchronously; when it did, the
     * runnable runs in the receiver's turn; when an animation is
     * running, the runnable is queued on the carousel and runs on the
     * settle frame. The two branches converge on the same frame the
     * transition is meant to be seen on.</p>
     *
     * <p>The playlist-update receivers do not refresh the carousel.
     * The carousel is updated by the service's own
     * {@code UPDATE_PLAYER} broadcast, which carries the window and
     * the transition the service is committed to. Refreshing the
     * carousel from a second path would show the target song's art
     * while the previous song was still playing, and would compete
     * with the commit turn the carousel uses to keep every surface in
     * sync.</p>
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYER".equals(
                            intent.getAction())) {
                    return;
                }

                final long generation =
                    intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    if (generation > mLastSeenGeneration) {
                        mLastSeenGeneration = generation;
                    }
                }

                final String displayTitle =
                    intent.getStringExtra("display_title");
                final String displayArtist =
                    intent.getStringExtra("display_artist");
                final int positionMs =
                    intent.getIntExtra("position_ms", 0);
                final int durationMs =
                    intent.getIntExtra("duration_ms", 0);
                final int transitionDirection =
                    intent.getIntExtra("transition_direction", 0);
                final boolean transitionRestart =
                    intent.getBooleanExtra("transition_restart", false);

                final PlaybackWindow windowSnapshot =
                    new PlaybackWindow(
                        intent.getStringExtra(
                            "window_previous_path"),
                        intent.getStringExtra(
                            "window_current_path"),
                        intent.getStringExtra(
                            "window_next_path"),
                        generation);

                safeUpdateUI(new Runnable() {
                    @Override
                    public void run() {
                        if (mAlbumArtCarousel == null) {
                            return;
                        }

                        // Adopt the window and the transition the
                        // service named. The return value is the
                        // commit contract: true when the window
                        // landed synchronously and the strip is at
                        // rest; false when an animation is running.
                        final boolean committedSynchronously =
                            mAlbumArtCarousel.setWindow(
                                windowSnapshot,
                                transitionDirection,
                                transitionRestart);

                        final int finalPositionMs = positionMs;
                        final int finalDurationMs = durationMs;
                        final String finalTitle = displayTitle;
                        final String finalArtist = displayArtist;

                        // One commit runnable writes every remaining
                        // surface. On the synchronous branch it runs
                        // in this receiver's turn. On the animating
                        // branch it runs on the carousel's settle
                        // frame — the same turn the strip's new
                        // bitmaps are installed. Either way, the
                        // framework's next traversal folds the strip's
                        // invalidation, the text invalidation, the
                        // seek-bar invalidation, and the transport
                        // glyph invalidation into one layout pass,
                        // and the notification and media session
                        // IPCs leave the app in that same turn.
                        final Runnable commit = new Runnable() {
                            @Override
                            public void run() {
                                if (isFinishing() || isDestroyed()) {
                                    return;
                                }

                                if (mNotificationController != null) {
                                    mNotificationController
                                        .commitNow();
                                }

                                updatePlayPauseButton();

                                if (mSeekBar != null
                                        && mSeekBar.isEnabled()
                                        && finalDurationMs > 0) {
                                    if (mSeekBar.getMax()
                                            != finalDurationMs) {
                                        mSeekBar.setMax(
                                            finalDurationMs);
                                    }
                                    mSeekBar.setProgress(
                                        finalPositionMs);
                                }

                                if (mSongTitle != null
                                        && finalTitle != null) {
                                    mSongTitle.setText(finalTitle);
                                    if (mThemeHelper != null) {
                                        mSongTitle.setTextColor(
                                            mThemeHelper
                                                .getThemeColorInt());
                                    }
                                }
                                if (mSongArtist != null
                                        && finalArtist != null) {
                                    mSongArtist.setText(finalArtist);
                                    mSongArtist.setTextColor(
                                        Color.parseColor(
                                            "#C0C0C0"));
                                }

                                setupSeekBar();
                            }
                        };

                        if (committedSynchronously) {
                            commit.run();
                        } else {
                            mAlbumArtCarousel.postOnSettle(commit);
                        }
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath =
                        intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "BLUETOOTH_PLAY".equals(
                            intent.getAction())) {
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        final int currentIndex =
                            mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0
                                && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET
                            .equals(intent.getAction())) {
                    return;
                }

                final boolean preserveSettings =
                    intent.getBooleanExtra(
                        PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);

                mPendingIncomingPath = null;
                mIsUserSeeking = false;
                mLastSeenGeneration = -1L;

                if (mCurrentMetadataFuture != null) {
                    mCurrentMetadataFuture.cancel(true);
                    mCurrentMetadataFuture = null;
                }

                mCachedLastSong = null;

                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();

                        if (!preserveSettings
                                && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }

                        if (mShuffleButton != null
                                && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null
                                && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mRepeatButton, false, false);
                        }
                        if (mPlayButton != null
                                && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPlayButton, false, false);
                        }
                        if (mPrevButton != null
                                && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPrevButton, false, false);
                        }
                        if (mNextButton != null
                                && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mNextButton, false, false);
                        }
                        if (mSeekBar != null
                                && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(
                                mSeekBar, false);
                        }

                        updatePlayPauseButton();
                    }
                });
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "SAVE_PLAYER_STATE_NOW".equals(
                            intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "BLUETOOTH_CONNECTED".equals(
                            intent.getAction())) {
                    final boolean connected =
                        intent.getBooleanExtra(
                            "connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(
                            connected);
                    }
                }
            }
        };

        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_STARTED".equals(intent.getAction())) {
                    return;
                }
                final String text =
                    intent.getStringExtra("custom_text");
                final String operationId =
                    intent.getStringExtra("operation_id");
                if (text == null) {
                    return;
                }

                if (ToastManager.hasPersistentToast()) {
                    final String currentOwner =
                        ToastManager.getCurrentOperationId();
                    if (currentOwner != null) {
                        ToastManager.updatePersistentOverlay(
                            text, currentOwner);
                    }
                    return;
                }

                if (operationId == null || operationId.isEmpty()) {
                    Log.w(TAG,
                        "SYNC_STARTED without operation_id; ignoring");
                    return;
                }
                ToastManager.showPersistentOverlay(
                    MusicPlayer.this, text, operationId);
            }
        };

        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                Log.d(TAG, "SYNC_COMPLETE received");
            }
        };

        mUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "UPDATE_PLAYLIST".equals(
                            intent.getAction())) {
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (allSongs != null
                                && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(
                                allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    // The carousel is not refreshed
                                    // here. The service's own
                                    // setPlaylist produces the state
                                    // changes the carousel renders,
                                    // and those reach the carousel
                                    // through UPDATE_PLAYER on the
                                    // commit turn. Refreshing from
                                    // this second path would show the
                                    // target song's art while the
                                    // previous song was still
                                    // playing.
                                }
                            });
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            mMusicLibrary.refreshCache();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager
                                        .hidePersistentOverlay();
                                }
                            });
                        }
                    }
                }
            }
        };

        mUpdatePlaylistFromFoldersReceiver =
            new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_UPDATE_PLAYLIST_FROM_FOLDERS.equals(
                            intent.getAction())) {
                    return;
                }
                if (mMusicLibrary == null) {
                    mMusicLibrary =
                        new MusicLibrary(MusicPlayer.this);
                }

                final MusicLibrary library = mMusicLibrary;
                final MusicService service = mMusicService;

                mMetadataLoader.execute(new Runnable() {
                    @Override
                    public void run() {
                        library.refreshCache();
                        final ArrayList<Song> allSongs =
                            library.getAllSongs();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()
                                        && service != null) {
                                    if (!allSongs.isEmpty()) {
                                        service.setPlaylist(
                                            allSongs, true);
                                        enableAllControls();
                                        updatePlayPauseButton();
                                        setupSeekBar();
                                        updateTimeDisplay();
                                        // The carousel is not
                                        // refreshed here. See the
                                        // note in the playlist
                                        // receiver above.
                                    } else {
                                        service.setPlaylist(
                                            null, false);
                                        applyNoSongState();
                                    }
                                    sendBroadcast(new Intent(
                                        "DISPLAY_PLAYLIST"));
                                }

                                sendBroadcast(new Intent(
                                    PlaylistManager
                                        .ACTION_TRIGGER_GENRE_LOADING));
                            }
                        });
                    }
                });
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"METADATA_UPDATED".equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    intent.getStringExtra("song_path");
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist =
                    intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final boolean hasAlbumArt =
                    intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved =
                    intent.getBooleanExtra(
                        "album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                mMusicService.refreshMetadataForSong(songPath, title,
                    artist, album, genre, albumArtBytes,
                    albumArtRemoved);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                final Song currentSong = (mMusicService != null)
                    ? mMusicService.getCurrentSong() : null;
                if (currentSong != null
                        && songPath.equals(currentSong.getPath())) {
                    if (albumArtRemoved && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.invalidatePath(
                                songPath);
                        }
                        loadAndDisplayPlaceholder();
                    } else if (hasAlbumArt
                            && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.invalidatePath(
                                songPath);
                        }
                        refreshCarouselFromService();
                    }

                    if (mMusicService.isPlaying()) {
                        updateUIForPlayingSong(currentSong);
                    } else {
                        updateUIForSong(currentSong);
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        "Playback recovered",
                        ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(
                        intent.getAction())) {
                    final int newSortMode =
                        intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong =
                                    (mMusicService != null)
                                        ? mMusicService
                                            .getCurrentSong()
                                        : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                                refreshCarouselFromService();
                            }
                        });
                        Log.d(TAG,
                            "Sort mode update received, refreshed UI: "
                                + newSortMode);
                    }
                }
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(
            mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(
            mLibraryResetReceiver,
            PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(
            mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(
            mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(
            mUpdatePlaylistReceiver, "UPDATE_PLAYLIST");
        registerReceiverSafely(
            mUpdatePlaylistFromFoldersReceiver,
            ACTION_UPDATE_PLAYLIST_FROM_FOLDERS);
        registerReceiverSafely(
            mMetadataUpdatedReceiver, "METADATA_UPDATED");
        registerReceiverSafely(
            mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(
            mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    /**
     * Registers the given receiver for the given action with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to register, or null
     * @param action Broadcast action to subscribe to
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG,
                "Failed to register receiver for " + action,
                exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every button click listener used by the activity,
     * each guarded by a debounce.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null
                                && mRepeatButton.isEnabled()) {
                            final int newMode =
                                (mMusicService.getRepeatMode() + 1)
                                    % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String message = newMode == 0
                                ? "Repeat: OFF"
                                : (newMode == 1
                                    ? "Repeat: ALL"
                                    : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this,
                                message, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null
                                && mShuffleButton.isEnabled()) {
                            final boolean newShuffle =
                                !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this,
                                newShuffle
                                    ? "Shuffle: ON"
                                    : "Shuffle: OFF",
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent =
                            findViewById(android.R.id.content);
                        mainContent.startAnimation(
                            AnimationUtils.loadAnimation(
                                MusicPlayer.this,
                                R.anim.slide_out_down));
                        final CreditsDialog dialog =
                            new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(
                            new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(
                                    DialogInterface
                                        dismissedDialog) {
                                final View contentView =
                                    findViewById(
                                        android.R.id.content);
                                contentView.startAnimation(
                                    AnimationUtils.loadAnimation(
                                        MusicPlayer.this,
                                        R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(
                            MusicPlayer.this,
                            EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Returns whether the activity has been destroyed, using the
     * API-appropriate check.
     *
     * @return True when the activity has been destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp
            * getResources().getDisplayMetrics().density);
    }
}