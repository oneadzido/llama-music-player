package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Playback stall recovery with user feedback</li>
 *   <li>Sort mode synchronization with PlaylistActivity</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>MusicPlayer follows the Model-View-Controller pattern where:</p>
 * <ul>
 *   <li><b>Activity</b> serves as the View, displaying UI and capturing user input</li>
 *   <li><b>MusicService</b> acts as the Controller, managing playback in background</li>
 *   <li><b>PlaybackController</b> provides the single source of truth for state</li>
 *   <li><b>DisplayManager</b> handles all UI display components (album art, placeholders, overlays)</li>
 *   <li><b>MusicLibrary</b> manages the data model (songs, playlists)</li>
 * </ul>
 * 
 * <h3>Threading Model</h3>
 * <p>The activity uses a multi-threaded architecture:</p>
 * <ul>
 *   <li><b>UI Thread:</b> All View operations and user interaction handling</li>
 *   <li><b>Handler Thread:</b> Background operations and service communication</li>
 *   <li><b>ExecutorService:</b> Album art loading and metadata extraction (replaces AsyncTask)</li>
 *   <li><b>Separate Executor:</b> Placeholder bitmap generation (via DisplayManager)</li>
 * </ul>
 * 
 * <h3>State Management</h3>
 * <p>UI state is synchronized with MusicService through:</p>
 * <ul>
 *   <li>PlaybackController for centralized state (single source of truth)</li>
 *   <li>Broadcast receivers for service events (backward compatibility)</li>
 *   <li>ServiceConnection callbacks for binding events</li>
 *   <li>SharedPreferences for persistence across app restarts</li>
 * </ul>
 * 
 * <h3>Control Button Management</h3>
 * <p><b>IMPORTANT:</b> All control buttons start DISABLED and only become
 * enabled when the player is prepared (song loaded and ready to play). This
 * prevents crashes and no-ops when users click buttons before the player is ready.</p>
 * 
 * <h3>Permission Handling</h3>
 * <p>The activity requests necessary permissions at runtime:</p>
 * <ul>
 *   <li>READ_MEDIA_AUDIO (Android 13+) or READ_EXTERNAL_STORAGE (older)</li>
 *   <li>POST_NOTIFICATIONS (Android 13+)</li>
 *   <li>BLUETOOTH_CONNECT (Android 12+)</li>
 *   <li>Battery optimization exemption for background playback (requested once)</li>
 * </ul>
 * 
 * <h3>Timing Utilities</h3>
 * <p>All timing operations use {@link SystemClock#elapsedRealtime()} which is
 * unaffected by system time changes, ensuring consistent debouncing and timeout behavior.</p>
 * 
 * @see MusicService
 * @see PlaybackController
 * @see DisplayManager
 * @see MusicLibrary
 * @see ThemeManager
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener,
        PlaybackController.PlaybackControllerListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Tag for logging messages from this class. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for permission requests. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for tracking first run of the application. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing the last played song's file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for tracking if battery optimization has been asked. */
    private static final String KEY_ASKED_BATTERY_OPTIMIZATION = "asked_battery_optimization";
    
    /** Action for restarting the application after updates. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks to prevent rapid firing (milliseconds). */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay for next/previous button UI updates (milliseconds). */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus operations and scrolling (milliseconds). */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Delay before resetting seek state after user stops seeking. */
    private static final int SEEK_RESET_DELAY_MS = 150;
    
    /** Buffer size for file copying operations (8KB). */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum album art dimension in pixels for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Minimum time between position UI updates (50ms = 20fps, owner's throttle). */
    private static final long POSITION_UPDATE_THROTTLE_MS = 50;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Button for play/pause toggling. */
    @Nullable private Button mPlayButton;
    
    /** Button for previous song navigation. */
    @Nullable private Button mPrevButton;
    
    /** Button for next song navigation. */
    @Nullable private Button mNextButton;
    
    /** Button for repeat mode cycling (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Button for shuffle mode toggling. */
    @Nullable private Button mShuffleButton;
    
    /** Button for opening folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button for showing credits/about dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button for opening playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button for opening equalizer settings. */
    @Nullable private Button mEqualizerButton;
    
    /** Button for opening metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Container for album art with rounded corners. */
    @Nullable private FrameLayout mAlbumArtContainer;
    
    /** Path of the currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Library manager for accessing song data and playlists. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Background service for music playback. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for storage access framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Manager for UI display components (album art, placeholders, overlays). */
    @Nullable private DisplayManager mDisplayManager;
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable private PlaybackController mPlaybackController;
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for seek operation timeouts. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if the service is bound. */
    private volatile boolean mIsServiceBound = false;
    
    /** Flag indicating if user is actively seeking (dragging seek bar). */
    private volatile boolean mIsUserSeeking = false;
    
    /** Last time we updated the position UI (for throttling, owner's decision). */
    private long mLastPositionUpdateTime = 0;
    
    /** Atomic flag for UI update synchronization. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable for debounced updates. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for service synchronization. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Flag indicating if activity is restarting after an update. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transition synchronization. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    /** Atomic flag to prevent multiple concurrent play button updates. */
    @NonNull private final AtomicBoolean mPlayButtonUpdateQueued = new AtomicBoolean(false);
    
    // ========================================================================
    // Executor for Metadata Loading (Replaces AsyncTask)
    // ========================================================================
    
    /** Single-thread executor for metadata extraction operations. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    /** Future for the current metadata loading task. */
    @Nullable private Future<?> mCurrentMetadataTask = null;
    
    // ========================================================================
    // Click Debounce Timestamps (using SystemClock.elapsedRealtime)
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    private long mLastCancelClickTime = 0;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Connection to the MusicService for playback control.
     * 
     * <p>This ServiceConnection handles binding to MusicService and initializing
     * the UI once the service is connected. It includes automatic reconnection
     * logic if the service disconnects unexpectedly.</p>
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            // Enable controls immediately when service connects
            if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                updateRepeatButton();
                updateShuffleButton();
                
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(true);
                    mThemeHelper.updateSeekBar(mSeekBar, true);
                }
                
                // Play button state will be updated via PlaybackController
                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                if (currentSong != null) {
                    updateUIForSong(currentSong);
                    if (mDisplayManager != null) {
                        mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                    }
                }
            } else {
                applyNoSongState();
            }
            
            setupSeekBar();
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            // Attempt to reconnect after a delay
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>Initializes all components, sets up UI, and binds to MusicService.</p>
     *
     * @param savedInstanceState Saved instance state bundle, or null if new instance
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        // Handle app closure intent
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        
        // Initialize DisplayManager
        mDisplayManager = new DisplayManager(this, mThemeManager, mThemeHelper);
        mDisplayManager.setAlbumArtUpdateListener(new DisplayManager.OnAlbumArtUpdateListener() {
            @Override
            public void onAlbumArtUpdated(@Nullable Bitmap art, @Nullable Bitmap placeholder, @Nullable String artPath) {
                if (mMusicService != null) {
                    mMusicService.setNotificationAlbumArt(art, placeholder, artPath);
                }
            }
        });
        
        // Initialize PlaybackController
        mPlaybackController = PlaybackController.getInstance();
        mPlaybackController.setListener(this);
        
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        NavigationController.getInstance().registerListener(this);
    }
    
    /**
     * Called when the activity becomes visible to the user.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity is no longer visible to the user.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes and comes to the foreground.
     * 
     * <p>Reattaches ToastManager, updates button states, and refreshes UI.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Reattach ToastManager persistent overlay if exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        // Update StorageObserver activity reference for toasts
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        // Sync button state with NavigationController
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();
            
            // Always use the service's current song directly
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
        
        // Restore position from PlaybackController on resume
        if (mPlaybackController != null) {
            long savedPosition = mPlaybackController.getCurrentPosition();
            if (savedPosition > 0 && mSeekBar != null) {
                mSeekBar.setProgress((int) savedPosition);
                if (mSeekTime != null) {
                    mSeekTime.setText(DisplayManager.formatTime((int) savedPosition));
                }
                Log.d(TAG, "onResume - restored position: " + savedPosition + "ms");
            }
        }
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called before the activity is destroyed.
     * 
     * <p>Performs comprehensive cleanup of all resources.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // Unregister from navigation button state changes
        NavigationController.getInstance().unregisterListener(this);
        
        // Clear PlaybackController listener
        if (mPlaybackController != null) {
            mPlaybackController.setListener(null);
        }
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore - service may already be unbound
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        unregisterMediaButtonReceiver();
        
        // Clean up DisplayManager
        if (mDisplayManager != null) {
            mDisplayManager.release();
        }
        
        // Shutdown metadata executor
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
        
        ToastManager.hidePersistentOverlay();
    }
    
    /**
     * Called when the system requests memory trimming.
     * 
     * <p>Forwards the memory trim event to MusicService to allow
     * it to release caches and reduce memory footprint.</p>
     *
     * @param level The memory trim level (e.g., TRIM_MEMORY_RUNNING_MODERATE)
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     * 
     * <p>Handles file opening intents (ACTION_VIEW) and close_app commands.</p>
     *
     * @param intent The new intent that was delivered
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     * 
     * <p>Sets the immersive sticky mode when the window has focus.</p>
     *
     * @param hasFocus True if the window has focus, false otherwise
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        // Refresh control buttons when window regains focus
        if (hasFocus && mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            // Also refresh song info and album art
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            }
        }
    }
    
    /**
     * Called when a key is pressed down.
     * 
     * <p>Consumes media button events to prevent default handling.</p>
     *
     * @param keyCode The key code of the pressed key
     * @param event The KeyEvent object
     * @return True if the event was handled, false otherwise
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) {
            return super.onKeyDown(keyCode, event);
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /**
     * Called when a key is released.
     * 
     * <p>Processes media button events to control playback.</p>
     *
     * @param keyCode The key code of the released key
     * @param event The KeyEvent object
     * @return True if the event was handled, false otherwise
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mMusicService != null && !mMusicService.isPlaying()) {
                    if (mMusicService.isPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mMusicService != null && mMusicService.isPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
    /**
     * Called when an activity launched with startActivityForResult completes.
     * 
     * <p>Handles results from battery optimization request and folder selection.</p>
     *
     * @param requestCode The request code from startActivityForResult
     * @param resultCode The result code (RESULT_OK or RESULT_CANCELED)
     * @param data The intent containing result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        // Handle battery optimization request result
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        // Handle folder selection result
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Called when permission request results are available.
     * 
     * <p>Processes permission results and requests battery optimization if granted.</p>
     *
     * @param requestCode The request code from requestPermissions
     * @param permissions The array of requested permissions
     * @param grantResults The array of grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
        }
    }
    
    // ========================================================================
    // PlaybackController.PlaybackControllerListener Implementation
    // ========================================================================
    
    /**
     * Called when playback position changes.
     * MusicPlayer decides throttle (50ms) and when to update UI.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Total duration of current song in milliseconds
     */
    @Override
    public void onPositionChanged(long positionMs, long durationMs) {
        if (isFinishing() || isDestroyed()) return;
        
        // DECISION 1: Skip if user is dragging (owner's decision)
        if (mIsUserSeeking) {
            return;
        }
        
        // DECISION 2: Throttle UI updates (owner's throttle - 50ms = 20fps)
        long now = SystemClock.elapsedRealtime();
        if (now - mLastPositionUpdateTime < POSITION_UPDATE_THROTTLE_MS) {
            return;
        }
        mLastPositionUpdateTime = now;
        
        runOnUiThread(() -> {
            // DECISION 3: Update seek bar max if duration changed
            if (mSeekBar != null) {
                if (durationMs > 0 && mSeekBar.getMax() != (int) durationMs) {
                    mSeekBar.setMax((int) durationMs);
                }
                mSeekBar.setProgress((int) positionMs);
            }
            
            // DECISION 4: Update time labels
            if (mSeekTime != null) {
                mSeekTime.setText(DisplayManager.formatTime((int) positionMs));
            }
            if (mTotalTime != null && durationMs > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) durationMs));
            }
        });
    }
    
    /**
     * Called when play/pause state changes.
     * Updates play/pause button via the centralized updatePlayPauseButton().
     *
     * @param isPlaying True if playing, false if paused
     */
    @Override
    public void onPlayStateChanged(boolean isPlaying) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            updatePlayPauseButton();
        });
    }
    
    /**
     * Called when a new song is loaded (complete metadata).
     *
     * @param title Song title (never null, may be empty)
     * @param artist Artist name (never null, may be empty)
     * @param path File path (for album art loading)
     * @param duration Duration in milliseconds
     */
    @Override
    public void onSongChanged(@NonNull String title, @NonNull String artist, 
                              @NonNull String path, long duration) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            
            // Update title display
            String displayTitle = DisplayManager.formatSongTitle(title);
            if (mSongTitle != null) {
                mSongTitle.setText(displayTitle);
                if (mThemeHelper != null) {
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
            }
            
            // Update artist display
            String displayArtist = DisplayManager.formatArtistName(artist);
            if (mSongArtist != null) {
                mSongArtist.setText(displayArtist);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            // Update seek bar max
            if (mSeekBar != null && duration > 0) {
                mSeekBar.setMax((int) duration);
                mSeekBar.setProgress(0);
            }
            
            // Update total time
            if (mTotalTime != null && duration > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) duration));
            }
            if (mSeekTime != null) {
                mSeekTime.setText("00:00");
            }
            
            // Update album art
            if (mDisplayManager != null) {
                mDisplayManager.updateAlbumArt(mAlbumArtView, path);
            }
            
            updatePlayPauseButton();
        });
    }
    
    /**
     * Called when prepared state changes (song loaded and ready to play).
     * This callback controls button enable/disable state.
     *
     * @param isPrepared True if a song is loaded and ready to play
     */
    @Override
    public void onPreparedStateChanged(boolean isPrepared) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            
            Log.d(TAG, "onPreparedStateChanged: isPrepared=" + isPrepared);
            
            if (isPrepared) {
                enableControlsWhenReady();
            } else {
                disableAllControls();
            }
            
            updatePlayPauseButton();
            
            if (isPrepared && mPlaybackController != null) {
                long duration = mPlaybackController.getDuration();
                if (mTotalTime != null && duration > 0) {
                    mTotalTime.setText(DisplayManager.formatTime((int) duration));
                }
                if (mSeekBar != null && duration > 0) {
                    mSeekBar.setMax((int) duration);
                    if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mSeekBar.setEnabled(true);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                    }
                }
                Log.d(TAG, "Player prepared - duration: " + duration + "ms");
            }
        });
    }
    
    /**
     * Called when a playback operation fails.
     *
     * @param operation The operation that failed (e.g., "play", "pause", "resume", "seek")
     * @param reason Human-readable reason for failure (can be null)
     */
    @Override
    public void onOperationFailed(@NonNull String operation, @Nullable String reason) {
        runOnUiThread(() -> {
            if (!isFinishing() && !isDestroyed()) {
                String message = "Cannot " + operation;
                if (reason != null && !reason.isEmpty()) {
                    message += ": " + reason;
                }
                ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                Log.w(TAG, "Operation failed: " + operation + " - " + reason);
            }
        });
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes.
     * 
     * <p>Updates playlist and metadata buttons based on whether
     * database actions are disabled (e.g., during sync operations).</p>
     *
     * @param group The button group that changed
     * @param disabled True if buttons in this group should be disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            runOnUiThread(() -> {
                if (mPlaylistButton != null) {
                    mPlaylistButton.setEnabled(!disabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mPlaylistButton, !disabled);
                    }
                }
                
                if (mMetadataButton != null) {
                    mMetadataButton.setEnabled(!disabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mMetadataButton, !disabled);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI views and sets up visual properties.
     * 
     * <p><b>IMPORTANT:</b> ALL control buttons start DISABLED and only become
     * enabled when the player is prepared.</p>
     */
    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        final Typeface faTypeface = FontAwesome.getTypeface();
        
        // ================================================================
        // IMPORTANT: ALL CONTROL BUTTONS START DISABLED
        // Only enabled when PlaybackController says isPrepared() = true
        // ================================================================
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }

        // Set button backgrounds
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Set letter spacing for action buttons
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Apply animations to all buttons
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        // Load placeholder via DisplayManager
        if (mDisplayManager != null && mAlbumArtView != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
        }
        
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
        
        // Ensure seek bar is disabled initially
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }

    /**
     * Adds touch animation to a button for visual feedback.
     * 
     * <p>When the button is pressed, it scales down to 97% of its size.
     * When released, it scales back to 100% with a smooth animation.</p>
     *
     * @param button The button to animate, or null to skip
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN)
                                  .scaleY(BUTTON_SCALE_DOWN)
                                  .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                  .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL)
                                  .scaleY(BUTTON_SCALE_NORMAL)
                                  .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                  .start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Control Enable/Disable Methods
    // ========================================================================
    
    /**
     * Enables all playback controls when the player is prepared.
     * 
     * <p>Uses a retry mechanism: if the player is prepared but the service
     * hasn't fully initialized the playlist yet, it will retry after 500ms.</p>
     */
    private void enableControlsWhenReady() {
        boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        
        Log.d(TAG, "enableControlsWhenReady: hasSongs=" + hasSongs + ", isPrepared=" + isPrepared);
        
        if (hasSongs && isPrepared) {
            // Enable play button
            if (mPlayButton != null && !mPlayButton.isEnabled()) {
                mPlayButton.setEnabled(true);
                mPlayButton.setAlpha(1.0f);
                if (mThemeHelper != null) {
                    boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
                Log.d(TAG, "Play button ENABLED - player prepared");
            }
            
            // Enable prev/next buttons
            if (mPrevButton != null && !mPrevButton.isEnabled()) {
                mPrevButton.setEnabled(true);
                mPrevButton.setAlpha(1.0f);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPrevButton, true, false);
                }
            }
            
            if (mNextButton != null && !mNextButton.isEnabled()) {
                mNextButton.setEnabled(true);
                mNextButton.setAlpha(1.0f);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mNextButton, true, false);
                }
            }
            
            // Enable repeat/shuffle buttons
            if (mRepeatButton != null && !mRepeatButton.isEnabled()) {
                mRepeatButton.setEnabled(true);
                mRepeatButton.setAlpha(1.0f);
                updateRepeatButton();
            }
            
            if (mShuffleButton != null && !mShuffleButton.isEnabled()) {
                mShuffleButton.setEnabled(true);
                mShuffleButton.setAlpha(1.0f);
                updateShuffleButton();
            }
            
            // Enable seekbar
            if (mSeekBar != null && !mSeekBar.isEnabled()) {
                mSeekBar.setEnabled(true);
                if (mThemeHelper != null) {
                    mThemeHelper.updateSeekBar(mSeekBar, true);
                }
            }
        } else if (hasSongs && !isPrepared) {
            // Retry after 500ms - player might still be preparing
            mHandler.postDelayed(this::enableControlsWhenReady, 500);
            Log.d(TAG, "enableControlsWhenReady: waiting for player preparation...");
        }
    }
    
    /**
     * Disables all playback controls.
     * Called when player enters error state or playlist is cleared.
     */
    private void disableAllControls() {
        Log.d(TAG, "disableAllControls - disabling all controls");
        
        if (mPlayButton != null) {
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        if (mPrevButton != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        if (mNextButton != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }
    
    /**
     * Enables or disables all playback controls based on song availability.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        final boolean enabled = hasSongs && isPrepared;
        
        safeUpdateUI(() -> {
            if (mPlayButton != null && mThemeHelper != null) {
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPlayButton, enabled, true);
            }
            if (mPrevButton != null && mThemeHelper != null) {
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPrevButton, enabled, false);
            }
            if (mNextButton != null && mThemeHelper != null) {
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mNextButton, enabled, false);
            }
            if (mRepeatButton != null) {
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateRepeatButton();
            }
            if (mShuffleButton != null) {
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateShuffleButton();
            }
            if (mSeekBar != null && mThemeHelper != null) {
                mSeekBar.setEnabled(enabled);
                mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
        });
    }
    
    /**
     * Updates the enabled state of prev, next, repeat, and shuffle buttons.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        final boolean enabled = hasSongs && isPrepared;
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(enabled);
            mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mPrevButton, enabled, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(enabled);
            mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mNextButton, enabled, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(enabled);
            mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(enabled);
            mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateShuffleButton();
        }
    }
    
    /**
     * Applies the "no song" state to all UI components.
     * 
     * <p>Shows placeholder text and disables all controls when
     * no songs are available in the library.</p>
     */
    private void applyNoSongState() {
        int totalSongs = (mMusicLibrary != null ? mMusicLibrary.getSongCount() : 0);
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        int looseCount = (looseSongs != null ? looseSongs.size() : 0);
        if (totalSongs + looseCount > 0) return;
        
        if (mIsSyncInProgress) return;
        
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null && mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
            mDisplayManager.clearAlbumArtCache();
        }
        
        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        // Disable ALL controls when no songs
        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests necessary runtime permissions.
     * 
     * <p>Requests different permissions based on Android version.</p>
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * 
     * <p>For first run, shows a loading message, starts the MusicService,
     * and binds to it. For subsequent runs, loads the last played song's
     * metadata and restores playback state.</p>
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks and requests battery optimization exemption for background playback.
     * 
     * <p>This is required for reliable background playback on Android 6.0+.
     * The request is only shown once to avoid bothering the user repeatedly.</p>
     *
     * @requires ApiLevel = 23 (Android M)
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean(KEY_ASKED_BATTERY_OPTIMIZATION, false);
            
            // Only ask once to avoid annoying the user repeatedly
            if (!hasAsked) {
                prefs.edit().putBoolean(KEY_ASKED_BATTERY_OPTIMIZATION, true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers a media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters the media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles incoming files from other apps via ACTION_VIEW intent.
     *
     * @param intent The intent containing the file URI
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<Song>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<Song>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming file using the already-bound MusicService.
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath The file path of the song to play
     * @param newSong The Song object for the incoming file
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(() -> {
                enableAllControls();
                updateUIForSong(newSong);
            });
            
            mMusicService.playSongByPath(filePath);
            
            mHandler.postDelayed(() -> {
                // Play button state will be updated via PlaybackController listener
                setupSeekBar();
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to MusicService and plays an incoming file.
     * 
     * <p>Used when the service is not yet bound. Creates a one-time
     * ServiceConnection that plays the file once connected.</p>
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath The file path of the song to play
     * @param newSong The Song object for the incoming file
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(() -> {
                        enableAllControls();
                        updateUIForSong(newSong);
                        if (mDisplayManager != null && mAlbumArtContainer != null) {
                            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    mHandler.postDelayed(() -> {
                        // Play button state will be updated via PlaybackController listener
                        setupSeekBar();
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     *
     * @param uri The URI to convert
     * @return The file system path, or null if conversion fails
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file.
     *
     * @param uri The content URI to copy
     * @return The path to the temporary file, or null if copying fails
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that are inside an imported folder.
     *
     * @param folderUri The URI of the imported folder
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist in the background asynchronously.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(() -> {
                        Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                            if (mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(mAlbumArtView, current.getPath());
                            }
                        }
                        
                        // Play button state will be updated via PlaybackController listener
                        setupSeekBar();
                    });
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                runOnUiThread(() -> {
                    ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG);
                });
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Safely updates UI with thread-safe queuing.
     *
     * @param update The UI update runnable to execute
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pending = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pending);
                    }
                }
            }
        });
    }
    
    /**
     * Updates the UI with current position from PlaybackController.
     * Used on pause/resume to ensure UI shows correct position.
     */
    private void updatePositionFromController() {
        if (mPlaybackController == null) return;
        
        long position = mPlaybackController.getCurrentPosition();
        long duration = mPlaybackController.getDuration();
        
        if (mSeekBar != null && duration > 0) {
            if (mSeekBar.getMax() != (int) duration) {
                mSeekBar.setMax((int) duration);
            }
            mSeekBar.setProgress((int) position);
        }
        if (mSeekTime != null) {
            mSeekTime.setText(DisplayManager.formatTime((int) position));
        }
        if (mTotalTime != null && duration > 0) {
            mTotalTime.setText(DisplayManager.formatTime((int) duration));
        }
    }
    
    /**
     * Updates the UI to display information for a given song.
     *
     * @param song The song to display, or null to clear
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        // Update PlaybackController with song metadata
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForSong");
        }
        
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(song.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            String displayArtist = DisplayManager.formatArtistName(song.getArtist());
            if (mSongArtist != null) {
                mSongArtist.setText(displayArtist);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && song.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) song.getDuration()));
            }
            
            // Play button state will be updated via PlaybackController listener
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
            if (mDisplayManager != null && mAlbumArtContainer != null) {
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on MusicService with synchronization.
     *
     * @param action The action to execute
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     *
     * @param index The playlist index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method uses PlaybackController as the single source of truth.</p>
     */
    private void togglePlayPause() {
        // Safety checks
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        // Check if we have any songs at all
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() == 0) {
            ToastManager.showToast(this, "No songs found", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        safeCallService(() -> {
            if (mMusicService == null) return;
            
            // Read state from PlaybackController (single source of truth)
            boolean isPlaying = (mPlaybackController != null && mPlaybackController.isPlaying());
            boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
            
            // Get current playlist state
            ArrayList<Song> allSongs = mMusicLibrary != null ? mMusicLibrary.getAllSongs() : null;
            boolean hasSongs = (allSongs != null && !allSongs.isEmpty());
            int currentIndex = mMusicService.getCurrentIndex();
            boolean hasValidSong = (currentIndex >= 0 && currentIndex < (allSongs != null ? allSongs.size() : 0));
            
            Log.d(TAG, "togglePlayPause: isPlaying=" + isPlaying + 
                  ", isPrepared=" + isPrepared + 
                  ", hasSongs=" + hasSongs + 
                  ", currentIndex=" + currentIndex);
            
            if (isPlaying) {
                // Currently playing → Pause
                Log.d(TAG, "togglePlayPause: Pausing playback");
                mMusicService.pause();
                updatePositionFromController();
                
            } else if (isPrepared && hasValidSong) {
                // Paused and player is prepared → Resume
                Log.d(TAG, "togglePlayPause: Resuming playback");
                mMusicService.resume();
                updatePositionFromController();
                
            } else if (hasSongs) {
                // Not prepared or no current song → Start playback
                int startIndex = (hasValidSong) ? currentIndex : 0;
                Log.d(TAG, "togglePlayPause: Starting new playback at index " + startIndex);
                
                mMusicService.playSong(startIndex);
                ToastManager.showToast(MusicPlayer.this, "Loading...", ToastManager.LENGTH_SHORT);
            }
        });
    }
    
    /**
     * Plays the next song in the playlist.
     * Uses a transition lock to prevent rapid successive calls.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playNext();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * Uses a transition lock to prevent rapid successive calls.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playPrevious();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button based on current repeat mode.
     */
    private void updateRepeatButton() {
        if (mRepeatButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mRepeatButton.setText(FontAwesome.REPEAT);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isActive = (repeatMode != 0);
        final boolean isEnabled = mRepeatButton.isEnabled();
        
        if (repeatMode == 2) {
            mRepeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
        }
        
        mThemeHelper.updateControlButton(mRepeatButton, isEnabled, isActive);
    }
    
    /**
     * Updates the shuffle button based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mShuffleButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        final boolean isEnabled = mShuffleButton.isEnabled();
        
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(mShuffleButton, isEnabled, isShuffleOn);
    }
    
    /**
     * Updates the play/pause button state using a centralized, debounced approach.
     * 
     * <p><b>IMPORTANT:</b> PlaybackController is the exclusive source of truth for play state.</p>
     */
    private void updatePlayPauseButton() {
        if (mPlayButtonUpdateQueued.getAndSet(true)) {
            return;
        }
        
        mHandler.post(() -> {
            mPlayButtonUpdateQueued.set(false);
            
            if (isFinishing() || isDestroyed() || mThemeHelper == null || mPlayButton == null) {
                return;
            }
            
            // SOURCE OF TRUTH: PlaybackController
            boolean isPlaying = false;
            boolean isPrepared = false;
            
            if (mPlaybackController != null) {
                isPlaying = mPlaybackController.isPlaying();
                isPrepared = mPlaybackController.isPrepared();
            }
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            
            if (!hasSongs) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                mPlayButton.setAlpha(0.5f);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                }
                Log.d(TAG, "Play button: DISABLED (no songs)");
                return;
            }
            
            boolean shouldEnable = isPrepared;
            
            if (mPlayButton.isEnabled() != shouldEnable) {
                mPlayButton.setEnabled(shouldEnable);
                mPlayButton.setAlpha(shouldEnable ? 1.0f : 0.5f);
                Log.d(TAG, "Play button enabled state: " + shouldEnable);
            }
            
            String newText = isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY;
            
            if (!newText.equals(mPlayButton.getText())) {
                mPlayButton.setText(newText);
                if (mThemeHelper != null && shouldEnable) {
                    mThemeHelper.updateControlButton(mPlayButton, shouldEnable, true);
                }
                Log.d(TAG, "Play button updated: " + (isPlaying ? "PAUSE" : "PLAY") + 
                      " (prepared=" + isPrepared + ", hasSongs=" + hasSongs + ")");
            }
        });
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position tracking and seeking.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) {
                    mSeekTime.setText(DisplayManager.formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mPlaybackController != null) mPlaybackController.onSeekStart();
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekPos);
                    if (mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(seekPos));
                }
                
                mSeekHandler.removeCallbacksAndMessages(null);
                
                mSeekHandler.postDelayed(() -> {
                    mIsUserSeeking = false;
                    if (mPlaybackController != null) {
                        mPlaybackController.forceResetSeeking();
                    }
                    if (mMusicService != null) {
                        int currentPos = mMusicService.getCurrentPosition();
                        int duration = mMusicService.getDuration();
                        if (mSeekBar != null) {
                            if (duration > 0 && mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPos);
                        }
                        if (mSeekTime != null) {
                            mSeekTime.setText(DisplayManager.formatTime(currentPos));
                        }
                    }
                    Log.d(TAG, "Seek flag reset - UI updates resumed");
                }, SEEK_RESET_DELAY_MS);
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the folder manager activity for importing music folders.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the playlist activity to view and manage playlists.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the metadata editor for editing song tags.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song from MusicService.
     *
     * @return The current Song, or null if no song is playing
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song's metadata from storage.
     * 
     * <p>Uses ExecutorService to load metadata asynchronously.</p>
     */
    private void loadLastSongMetadata() {
        if (mDisplayManager != null) {
            ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
            mDisplayManager.showDelayedLoadingOverlay(rootView);
        }
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            // Cancel any existing metadata task
            if (mCurrentMetadataTask != null && !mCurrentMetadataTask.isDone()) {
                mCurrentMetadataTask.cancel(true);
            }
            
            mCurrentMetadataTask = mMetadataExecutor.submit(() -> {
                Song song = null;
                try {
                    Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                    
                    if (cachedSong != null && cachedSong.getTitle() != null && 
                        !cachedSong.getTitle().isEmpty() && 
                        !"Unknown Title".equals(cachedSong.getTitle())) {
                        song = cachedSong;
                    } else {
                        final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                        mmr.setDataSource(lastPath);
                        String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        final byte[] art = mmr.getEmbeddedPicture();
                        mmr.release();
                        
                        if (title == null || title.isEmpty()) {
                            final File file = new File(lastPath);
                            String name = file.getName();
                            final int dot = name.lastIndexOf('.');
                            if (dot > 0) name = name.substring(0, dot);
                            title = name;
                        }
                        if (artist == null) artist = "Unknown Artist";
                        if (album == null) album = "Unknown Album";
                        
                        String genre = "Unknown Genre";
                        Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        if (dbSong != null && dbSong.getGenre() != null && 
                            !"Unknown Genre".equals(dbSong.getGenre())) {
                            genre = dbSong.getGenre();
                            Log.d(TAG, "Found genre in database: " + genre);
                        } else {
                            String fileGenre = CharacterMapper.getGenre(lastPath);
                            if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                genre = fileGenre;
                                Log.d(TAG, "Read genre from file: " + genre);
                            }
                        }
                        
                        song = new Song(title, artist, album, genre, lastPath, 0, null);
                        if (art != null && mDisplayManager != null) {
                            final Bitmap bmp = decodeSampledBitmap(art);
                            if (bmp != null && mDisplayManager.getCachedAlbumArt(lastPath) == null) {
                                // DisplayManager handles caching internally
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                }
                
                final Song finalSong = song;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (finalSong != null && mThemeHelper != null) {
                        mCachedLastSong = finalSong;
                        if (mSongTitle != null) {
                            mSongTitle.setText(finalSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(finalSong.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        final Bitmap cachedArt = mDisplayManager != null ? mDisplayManager.getCachedAlbumArt(lastPath) : null;
                        if (cachedArt != null && mDisplayManager != null && mAlbumArtView != null) {
                            mDisplayManager.updateAlbumArt(mAlbumArtView, lastPath);
                        } else {
                            if (mDisplayManager != null && mAlbumArtView != null) {
                                mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                            }
                            mHandler.postDelayed(() -> {
                                if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                    if (mDisplayManager != null) {
                                        mDisplayManager.updateAlbumArt(mAlbumArtView, mMusicService.getCurrentSong().getPath());
                                    }
                                }
                            }, FOCUS_SCROLL_DELAY_MS);
                        }
                        startServiceWithCachedSong();
                    } else {
                        applyNoSongState();
                        loadSongsAndStartService();
                    }
                });
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Decodes a byte array into a sampled bitmap.
     *
     * @param data The byte array containing image data
     * @return The sampled bitmap, or null if decoding fails
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Calculates the sample size for efficient bitmap decoding.
     *
     * @param options The BitmapFactory.Options with out dimensions
     * @param reqWidth The requested width
     * @param reqHeight The requested height
     * @return The sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Starts the MusicService with the cached last song.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<Song>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs and starts the MusicService.
     */
    private void loadSongsAndStartService() {
        if (mDisplayManager != null) {
            ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
            mDisplayManager.showDelayedLoadingOverlay(rootView);
        }
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        if (mDisplayManager != null) {
                            mDisplayManager.updateAlbumArt(mAlbumArtView, current.getPath());
                        }
                    }
                    // Play button state will be updated via PlaybackController listener
                    setupSeekBar();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers a receiver for app restart commands.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers a receiver for theme color change events.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies the current theme color to all UI elements.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        // Update buttons
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        // Update control buttons
        if (mPlayButton != null) {
            boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        // Update seek bar
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        // Update text colors
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        // Refresh placeholder via DisplayManager
        if (mDisplayManager != null && mAlbumArtView != null) {
            mDisplayManager.refreshPlaceholder(mAlbumArtView);
        }
        
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs an app update by restarting the activity.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for service communication.
     */
    private void registerReceivers() {
        // Update player receiver
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final boolean isPlaying = intent.getBooleanExtra("is_playing", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    safeUpdateUI(() -> {
                        if (songCompleted && !isPlaying) {
                            if (mSeekBar != null) {
                                mSeekBar.setProgress(0);
                            }
                            if (mSeekTime != null) {
                                mSeekTime.setText("00:00");
                            }
                            Log.d(TAG, "Song completed - seekbar reset to 0");
                        } else if (songCompleted && completedPosition > 0) {
                            if (mSeekBar != null) {
                                mSeekBar.setMax(completedPosition);
                                mSeekBar.setProgress(completedPosition);
                            }
                            if (mSeekTime != null) {
                                mSeekTime.setText(DisplayManager.formatTime(completedPosition));
                            }
                            if (mTotalTime != null) {
                                mTotalTime.setText(DisplayManager.formatTime(completedPosition));
                            }
                            Log.d(TAG, "Song completed - seekbar filled to 100%");
                        }
                        
                        if (mMusicService != null) {
                            if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                final int duration = mMusicService.getDuration();
                                final int position = mMusicService.getCurrentPosition();
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(position);
                            }
                            
                            final Song song = mMusicService.getCurrentSong();
                            if (song != null) {
                                if (mMusicService.isPlaying()) {
                                    updateUIForPlayingSong(song);
                                } else {
                                    updateUIForSong(song);
                                }
                            }
                        }
                        setupSeekBar();
                    });
                }
            }
        };
        
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                }
            }
        };
        
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                    }
                }
            }
        };
        
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                }
            }
        };
        
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };
        
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(() -> {
                        applyNoSongState();
                        
                        if (!preserveSettings && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }
                        
                        if (mShuffleButton != null && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mThemeHelper.updateControlButton(mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mThemeHelper.updateControlButton(mRepeatButton, false, false);
                        }
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mPlayButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mPlayButton, false, false);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mThemeHelper.updateControlButton(mPrevButton, false, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mThemeHelper.updateControlButton(mNextButton, false, false);
                        }
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(mSeekBar, false);
                        }
                        
                        ToastManager.hidePersistentOverlay();
                        if (mDisplayManager != null) {
                            mDisplayManager.hideLoadingOverlay();
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mDisplayManager != null && targetPath != null) {
                            mDisplayManager.removeFromCache(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                if (mDisplayManager != null && mAlbumArtView != null) {
                                    mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                                }
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mDisplayManager != null) {
                                mDisplayManager.removeFromCache(targetPath);
                                mCurrentAlbumArtPath = null;
                                if (mDisplayManager != null) {
                                    mDisplayManager.updateAlbumArt(mAlbumArtView, targetPath);
                                }
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        setupSeekBar();
                    }
                }
            }
        };
        
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    if (mDisplayManager != null) {
                        mDisplayManager.setSyncInProgress(true);
                    }
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    if (mDisplayManager != null) {
                        mDisplayManager.setSyncInProgress(false);
                    }
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                setupSeekBar();
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                    if (mDisplayManager != null) {
                                        mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(() -> {
                                applyNoSongState();
                                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            });
                        }
                    }
                }
            }
        };
        
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                setupSeekBar();
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    if (mDisplayManager != null) {
                                        mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(() -> {
                                applyNoSongState();
                                ToastManager.hidePersistentOverlay();
                                if (mDisplayManager != null) {
                                    mDisplayManager.hideLoadingOverlay();
                                }
                                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            });
                        }
                    }
                }
            }
        };
        
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) {
                        return;
                    }
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mDisplayManager != null) {
                            mDisplayManager.removeFromCache(songPath);
                            mCurrentAlbumArtPath = null;
                            if (mDisplayManager != null && mAlbumArtView != null) {
                                mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                            }
                        } else if (hasAlbumArt && mDisplayManager != null) {
                            mDisplayManager.removeFromCache(songPath);
                            mCurrentAlbumArtPath = null;
                            if (mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(mAlbumArtView, songPath);
                            }
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(() -> {
                            Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (currentSong != null) {
                                updateUIForSong(currentSong);
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        // Register all receivers
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }
    
    /**
     * Safely registers a broadcast receiver with the given action.
     *
     * @param receiver The receiver to register
     * @param action The intent action to listen for
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
        }
    }
    
    /**
     * Updates the UI for a song that is currently playing.
     *
     * @param song The currently playing song
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForPlayingSong");
        }
        
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(song.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            String displayArtist = DisplayManager.formatArtistName(song.getArtist());
            if (mSongArtist != null) {
                mSongArtist.setText(displayArtist);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && song.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) song.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.updateAlbumArt(mAlbumArtView, song.getPath());
            }
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
            if (mDisplayManager != null && mAlbumArtContainer != null) {
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all UI buttons with debouncing.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlayPauseClickTime = currentTime;
                    togglePlayPause();
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastNextClickTime = currentTime;
                    playNextSong();
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPrevClickTime = currentTime;
                    playPreviousSong();
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastRepeatClickTime = currentTime;
                    if (mMusicService != null && mRepeatButton.isEnabled()) {
                        final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButton();
                        final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastShuffleClickTime = currentTime;
                    if (mMusicService != null && mShuffleButton.isEnabled()) {
                        final boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButton();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastManagerClickTime = currentTime;
                    openFolderManager();
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastLlamaClickTime = currentTime;
                    final View mainContent = findViewById(android.R.id.content);
                    mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(d -> {
                        final View content = findViewById(android.R.id.content);
                        content.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                    });
                    dialog.show();
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlaylistClickTime = currentTime;
                    openPlaylist();
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastEqualizerClickTime = currentTime;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastMetadataClickTime = currentTime;
                    openMetadataEditor();
                }
            });
        }
    }
    
    /**
     * Checks if the activity is destroyed (Android 4.3+).
     *
     * @return True if the activity is destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to absolute pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The value in absolute pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    /** Cached last song for quick access. */
    @Nullable private Song mCachedLastSong = null;
}