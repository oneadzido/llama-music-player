package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity ONLY DISPLAYS state from MusicService. It does NOT store
 * its own copy of the playlist or make playback decisions independently.</p>
 * 
 * <p>State flows: MusicService → Broadcast → MusicPlayer (display only)</p>
 * <p>Commands flow: MusicPlayer → MusicService (via bound methods)</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicPlayer";
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int FOLDER_SELECT_CODE = 200;
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    private static final int MAX_CACHE_SIZE_MB = 50;
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long PLAY_PAUSE_UPDATE_DELAY_MS = 50;
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final int BUFFER_SIZE = 8192;
    private static final int MAX_TITLE_LENGTH = 40;
    private static final int MAX_ARTIST_LENGTH = 35;
    private static final String ELLIPSIS = "...";
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    private static final int DIM_ALPHA = 180;
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    private static final int LOADING_OVERLAY_DELAY_MS = 5000;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    @Nullable private TextView mSongTitle;
    @Nullable private TextView mSongArtist;
    @Nullable private TextView mSeekTime;
    @Nullable private TextView mTotalTime;
    @Nullable private SeekBar mSeekBar;
    @Nullable private Button mPlayButton;
    @Nullable private Button mPrevButton;
    @Nullable private Button mNextButton;
    @Nullable private Button mRepeatButton;
    @Nullable private Button mShuffleButton;
    @Nullable private Button mManagerButton;
    @Nullable private Button mLlamaButton;
    @Nullable private Button mPlaylistButton;
    @Nullable private Button mEqualizerButton;
    @Nullable private Button mMetadataButton;
    @Nullable private ImageView mAlbumArtView;
    
    // ========================================================================
    // Service Connection (SINGLE SOURCE OF TRUTH)
    // ========================================================================
    
    @Nullable private MusicService mMusicService;
    private boolean mIsServiceBound = false;
    private final Object mServiceLock = new Object();
    
    // ========================================================================
    // UI State (Display Only - NO LOCAL PLAYLIST COPY)
    // ========================================================================
    
    private boolean mIsPlaying = false;
    private int mCurrentIndex = -1;
    private String mCurrentSongPath = null;
    private String mCurrentTitle = "";
    private String mCurrentArtist = "";
    private boolean mIsUserSeeking = false;
    private boolean mIsPostUpdateRestart = false;
    
    // ========================================================================
    // Managers and Executors
    // ========================================================================
    
    @Nullable private ThemeManager mThemeManager;
    @Nullable private ThemeHelper mThemeHelper;
    @Nullable private StorageAccessHelper mStorageHelper;
    
    // ExecutorService for background operations (replaces AsyncTask)
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    @Nullable private String mCurrentLoadingArtPath = null;
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    @Nullable private Bitmap mPlaceholderBitmap = null;
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components
    // ========================================================================
    
    @Nullable private View mDimOverlay = null;
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Timestamps (Using SystemClock.elapsedRealtime)
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Handlers
    // ========================================================================
    
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private Handler mTimeHandler = null;
    private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    // ========================================================================
    // Broadcast Receivers (Receiving state FROM service)
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mMusicService != null) {
                        updateRepeatButtonIcon();
                        updateShuffleButtonIcon();
                        updatePlayPauseButton();
                        
                        Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                        
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                    hideLoadingOverlay();
                }
            }, FOCUS_SCROLL_DELAY_MS);
        }
        
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle
    // ========================================================================
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }
        
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }
    
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) registerThemeReceiver();
    }
    
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try { unregisterReceiver(mThemeReceiver); } catch (Exception e) {}
            mThemeReceiver = null;
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null) {
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
            updatePlayPauseButton();
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);
        
        if (mIsServiceBound) {
            try { unbindService(mServiceConnection); } catch (Exception e) {}
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        
        if (mHandler != null) mHandler.removeCallbacksAndMessages(null);
        
        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();
        ToastManager.hidePersistentOverlay();
        hideLoadingOverlay();
        
        // Shutdown executors
        mExecutor.shutdown();
        mPlaceholderExecutor.shutdown();
    }
    
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try { mMusicService.onTrimMemory(level); } catch (Exception e) {}
        }
    }
    
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                
                Intent intent = new Intent(this, MusicService.class);
                intent.setAction("ADD_FOLDER");
                intent.putExtra("folder_uri", folderUriString);
                startService(intent);
                
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }
    
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!disabled);
                        if (mThemeHelper != null) mThemeHelper.updateButton(mPlaylistButton, !disabled);
                    }
                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!disabled);
                        if (mThemeHelper != null) mThemeHelper.updateButton(mMetadataButton, !disabled);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization
    // ========================================================================
    
    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        
        applyAlbumArtClipping();
        
        Typeface faTypeface = FontAwesome.getTypeface();
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }
        
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);
        
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);
        
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);
        
        loadAndDisplayPlaceholder();
        updateRepeatButtonIcon();
        updateShuffleButtonIcon();
        updateControlButtonsState();
    }
    
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN)
                                   .scaleY(BUTTON_SCALE_DOWN)
                                   .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL)
                                   .scaleY(BUTTON_SCALE_NORMAL)
                                   .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Permission and Initialization
    // ========================================================================
    
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();
            
            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }
            
            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }
            
            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }
    
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);
        
        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);
            
            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    // ========================================================================
    // Media Button Receiver
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling
    // ========================================================================
    
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                // Start service to handle playback
                Intent serviceIntent = new Intent(this, MusicService.class);
                serviceIntent.setAction("PLAY_SONG");
                serviceIntent.putExtra("song_path", filePath);
                startService(serviceIntent);
                
                if (!mIsServiceBound) {
                    bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
                }
                
                ToastManager.showToast(this, "Playing: " + new File(filePath).getName(), ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) cursor.close();
            }
        }
        return path;
    }
    
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    // ========================================================================
    // Last Song Metadata Loading (Using ExecutorService)
    // ========================================================================
    
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);
        
        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) mSongTitle.setText("Loading...");
            if (mSongArtist != null) mSongArtist.setText("Loading...");
            
            mExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final Song song = loadSongMetadataInBackground(lastPath);
                    
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            
                            if (song != null && mThemeHelper != null) {
                                if (mSongTitle != null) {
                                    mSongTitle.setText(song.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(song.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                } else {
                                    loadAndDisplayPlaceholder();
                                    mHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    private Song loadSongMetadataInBackground(@NonNull String lastPath) {
        Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
        
        if (cachedSong != null && cachedSong.getTitle() != null && 
            !cachedSong.getTitle().isEmpty() && !"Unknown Title".equals(cachedSong.getTitle())) {
            return cachedSong;
        }
        
        try {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(lastPath);
            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] art = mmr.getEmbeddedPicture();
            mmr.release();
            
            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dot = name.lastIndexOf('.');
                if (dot > 0) name = name.substring(0, dot);
                title = name;
            }
            if (artist == null) artist = "Unknown Artist";
            if (album == null) album = "Unknown Album";
            
            String genre = "Unknown Genre";
            Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
            if (dbSong != null && dbSong.getGenre() != null && !"Unknown Genre".equals(dbSong.getGenre())) {
                genre = dbSong.getGenre();
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) genre = fileGenre;
            }
            
            final Song song = new Song(title, artist, album, genre, lastPath, 0, null);
            if (art != null && mAlbumArtCache != null) {
                final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                if (bmp != null) mAlbumArtCache.put(lastPath, bmp);
            }
            return song;
        } catch (Exception e) {
            Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
            return null;
        }
    }
    
    private void startServiceWithCachedSong() {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // UI Update Methods (Display Only)
    // ========================================================================
    
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    safeUpdateUI(update);
                }
            }, 50);
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                }
            }
        });
    }
    
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
                
                String displayText = song.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = song.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                mCurrentSongPath = song.getPath();
                mCurrentTitle = song.getTitle();
                mCurrentArtist = song.getArtist();
                
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    private void updateUIForPlayingSong(@Nullable Song song) {
        updateUIForSong(song);
        if (song != null) {
            updateAlbumArt(song.getPath());
        }
    }
    
    private void enableAllControls() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                boolean hasSongs = (mMusicService != null && mMusicService.getCurrentSong() != null);
                
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButtonIcon();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButtonIcon();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }
    
    private void updateControlButtonsState() {
        boolean hasSongs = (mMusicService != null && mMusicService.getCurrentSong() != null);
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButtonIcon();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButtonIcon();
        }
    }
    
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) mAlbumArtCache.evictAll();
            mCurrentAlbumArtPath = null;
        }
        
        applyAlbumArtClipping();
        
        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) mSeekTime.setText("00:00");
        if (mTotalTime != null) mTotalTime.setText("00:00");
    }
    
    // ========================================================================
    // Playback Control Methods (Sending Commands TO Service)
    // ========================================================================
    
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    private void togglePlayPause() {
        long currentTime = SystemClock.elapsedRealtime();
        if (currentTime - mLastPlayPauseClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
        mLastPlayPauseClickTime = currentTime;
        
        if (mPlayButton != null && mPlayButton.isEnabled()) {
            safeCallService(new Runnable() {
                @Override
                public void run() {
                    mMusicService.togglePlayPause();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                        }
                    }, PLAY_PAUSE_UPDATE_DELAY_MS);
                }
            });
        }
    }
    
    private void playNextSong() {
        long currentTime = SystemClock.elapsedRealtime();
        if (currentTime - mLastNextClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
        mLastNextClickTime = currentTime;
        
        if (mNextButton != null && mNextButton.isEnabled()) {
            safeCallService(new Runnable() {
                @Override
                public void run() {
                    mMusicService.playNext();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!isFinishing() && !isDestroyed()) {
                                updatePlayPauseButton();
                            }
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                }
            });
        }
    }
    
    private void playPreviousSong() {
        long currentTime = SystemClock.elapsedRealtime();
        if (currentTime - mLastPrevClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
        mLastPrevClickTime = currentTime;
        
        if (mPrevButton != null && mPrevButton.isEnabled()) {
            safeCallService(new Runnable() {
                @Override
                public void run() {
                    mMusicService.playPrevious();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!isFinishing() && !isDestroyed()) {
                                updatePlayPauseButton();
                            }
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                }
            });
        }
    }
    
    // ========================================================================
    // Button State Updates
    // ========================================================================
    
    private void updateRepeatButtonIcon() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final int repeatMode = mMusicService.getRepeatMode();
            final boolean isActive = (repeatMode != 0);
            
            if (repeatMode == 0) {
                mRepeatButton.setText(FontAwesome.REPEAT);
            } else if (repeatMode == 1) {
                mRepeatButton.setText(FontAwesome.REPEAT);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT_ONE);
            }
            
            mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
        }
    }
    
    private void updateShuffleButtonIcon() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean isShuffleOn = mMusicService.isShuffle();
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
        }
    }
    
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
                
                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }
                
                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                        return;
                    }
                    
                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    mIsPlaying = isPlaying;
                } catch (Exception e) {
                    Log.e(TAG, "Error updating play/pause button", e);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) mIsUserSeeking = true;
            }
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }
    
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }
        
        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                
                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) mTimeHandler.postDelayed(this, 500);
                    return;
                }
                
                if (mIsUserSeeking) {
                    if (mTimeHandler != null) mTimeHandler.postDelayed(this, 500);
                    return;
                }
                
                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();
                    
                    if (duration > 0) {
                        if (mSeekTime != null) mSeekTime.setText(formatTime(currentPosition));
                        if (mTotalTime != null) mTotalTime.setText(formatTime(duration));
                        
                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) mSeekBar.setMax(duration);
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error updating time display", e);
                }
                
                if (mTimeHandler != null) mTimeHandler.postDelayed(this, 500);
            }
        };
        mTimeHandler.post(timeRunnable);
    }
    
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        if (mCurrentAlbumArtTask != null) {
            mCurrentAlbumArtTask.cancel(true);
            mCurrentAlbumArtTask = null;
        }
        
        mCurrentLoadingArtPath = filePath;
        mCurrentAlbumArtTask = mExecutor.submit(new Runnable() {
            @Override
            public void run() {
                final Bitmap bitmap = extractAlbumArtFromFile(filePath);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        if (filePath.equals(mCurrentLoadingArtPath) && filePath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(filePath, bitmap);
                                applyAlbumArtWithFade(bitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        mCurrentAlbumArtTask = null;
                        mCurrentLoadingArtPath = null;
                    }
                });
            }
        });
    }
    
    @Nullable
    private Bitmap extractAlbumArtFromFile(@NonNull String filePath) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(filePath);
            final byte[] artBytes = retriever.getEmbeddedPicture();
            if (artBytes != null) {
                return decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to extract album art for: " + filePath, e);
        } finally {
            if (retriever != null) retriever.release();
        }
        return null;
    }
    
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }
        
        if (isFinishing() || isDestroyed() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        mAlbumArtView.animate().alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        
        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }
    
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(currentPath);
            if (cached != null && !cached.isRecycled()) art = cached;
        }
        
        mMusicService.setNotificationAlbumArt(art, placeholder, currentPath);
    }
    
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return mCurrentSongPath;
    }
    
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) mCurrentPlaceholderTask.cancel(true);
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        mCurrentPlaceholderTask = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
    }
    
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try { bitmap.recycle(); } catch (Exception e) {}
        }
    }
    
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) return;
                
                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
                
                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                
                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);
                
                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) editorIntent.putExtra("song_uri", currentSong.getUri());
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) return mMusicService.getCurrentSong();
        return null;
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;
        
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        if (mLlamaButton != null) mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        if (mPlaylistButton != null) mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        if (mEqualizerButton != null) mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        if (mMetadataButton != null) mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        
        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicService != null && mMusicService.getCurrentSong() != null) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        if (mNextButton != null) mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        
        if (mLoadingSpinner != null) mThemeHelper.updateProgressBar(mLoadingSpinner);
        
        if (mSongTitle != null) mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        
        if (mSeekTime != null) mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        if (mTotalTime != null) mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        if (mSongArtist != null) mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        
        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }
    
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup (Receiving state FROM service)
    // ========================================================================
    
    private void registerReceivers() {
        // Update player receiver - receives state from MusicService
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    safeUpdateUI(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            
                            if (mMusicService != null && mSeekBar != null && mSeekBar.isEnabled()) {
                                final int duration = mMusicService.getDuration();
                                final int position = mMusicService.getCurrentPosition();
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(position);
                            }
                            
                            final Song song = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (song != null) {
                                if (mIsPlaying) {
                                    updateUIForPlayingSong(song);
                                } else {
                                    updateUIForSong(song);
                                }
                            }
                            setupSeekBar();
                        }
                    });
                }
            }
        };
        
        // Play song receiver
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        // Bluetooth play receiver
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.resume();
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Bluetooth pause receiver
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        
        // Media button receiver
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Get playing state receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };
        
        // Reset player receiver
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) mMusicService.stop();
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };
        
        // Force update player receiver
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null) {
                        if (refreshAlbumArt && targetPath != null && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(targetPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(targetPath);
                        }
                        
                        if (refreshMetadata && targetPath != null) {
                            final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (freshSong != null) {
                                updateUIForSong(freshSong);
                            }
                        }
                        
                        final Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null) {
                            if (mMusicService.isPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };
        
        // Save player state now receiver
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) mMusicService.savePlayerState();
                }
            }
        };
        
        // Bluetooth connection receiver
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    // Bluetooth state handled by service internally
                }
            }
        };
        
        // Sync started receiver
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        // Sync complete receiver
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        // Update playlist from folders receiver
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            enableAllControls();
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                            if (mMusicService != null) {
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                    updateAlbumArt(currentSong.getPath());
                                }
                            }
                        }
                    });
                }
            }
        };
        
        // Soft update playlist receiver
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mMusicService != null) {
                                enableAllControls();
                                setupSeekBar();
                                updateTimeDisplay();
                                updatePlayPauseButton();
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null) {
                                    updateAlbumArt(currentSong.getPath());
                                }
                            }
                        }
                    });
                }
            }
        };
        
        // Update song in playlist receiver
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    
                    if (songPath != null && mMusicService != null) {
                        mMusicService.refreshMetadataForSong(songPath, title, artist, null, null, albumArtBytes, albumArtRemoved);
                        
                        final Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null && songPath.equals(currentSong.getPath())) {
                            if (albumArtRemoved && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(songPath);
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            } else if (hasAlbumArt && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(songPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(songPath);
                            }
                            updateUIForSong(currentSong);
                        }
                    }
                }
            }
        };
        
        // Playback recovery receiver
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        // Register all receivers
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
    }
    
    private void requestCurrentStateFromService() {
        if (mMusicService != null) {
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
            updatePlayPauseButton();
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();
        }
    }
    
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception e) {}
        }
    }
    
    // ========================================================================
    // Listener Setup
    // ========================================================================
    
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    togglePlayPause();
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    playNextSong();
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    playPreviousSong();
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastRepeatClickTime = currentTime;
                    
                    if (mMusicService != null && mRepeatButton.isEnabled()) {
                        final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButtonIcon();
                        final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastShuffleClickTime = currentTime;
                    
                    if (mMusicService != null && mShuffleButton.isEnabled()) {
                        final boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButtonIcon();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastManagerClickTime = currentTime;
                    openFolderManager();
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastLlamaClickTime = currentTime;
                    
                    final View mainContent = findViewById(android.R.id.content);
                    mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(android.content.DialogInterface d) {
                            final View mainContent = findViewById(android.R.id.content);
                            mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                        }
                    });
                    dialog.show();
                }
            });
        }
        
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastPlaylistClickTime = currentTime;
                    openPlaylist();
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastEqualizerClickTime = currentTime;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    mLastMetadataClickTime = currentTime;
                    openMetadataEditor();
                }
            });
        }
    }
    
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }
    
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}