package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Renders the main playback screen and forwards user input to
 * {@link MusicService}.
 *
 * <p>The activity is a view over {@link MusicService}'s authoritative
 * playback state machine. User input is forwarded to the service, and
 * the resulting state is reflected from {@code UPDATE_PLAYER}
 * broadcasts. The activity does not own a transition state of its own;
 * the service owns every transition and the activity follows the
 * broadcasts.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The playback state machine is owned by {@link MusicService}. This
 * activity owns the render state derived from that machine: the text and
 * color of the current song's title and artist, the seek bar position
 * and duration, the enabled state of the transport controls, and the
 * album art bitmap currently displayed. Service calls are serialised by
 * {@link #mServiceLock}, and UI updates are coalesced by
 * {@link #safeUpdateUI(Runnable)}.</p>
 *
 * <p>The media session metadata and the playback notification are
 * owned by {@link NotificationController}. This activity does not push
 * art to the session. The service's prefetch resolves the art, pokes
 * the controller, and the controller writes both the notification and
 * the session metadata from one snapshot in one main-thread turn.
 * Because the two surfaces are committed from one value, they cannot
 * diverge on a rapid song switch.</p>
 *
 * <h3>Ordering</h3>
 * <p>Media buttons from headsets, hardware keys, and notification action
 * buttons are routed through
 * {@code androidx.media.session.MediaButtonReceiver} and dispatched to
 * the active
 * {@link android.support.v4.media.session.MediaSessionCompat} held by
 * {@link MusicService}. This activity keeps a fallback
 * {@link #onKeyDown(int, KeyEvent)} for hardware keys delivered to a
 * focused activity.</p>
 *
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic {@code generation}
 * alongside the full playback snapshot. The activity tracks the highest
 * generation it has seen and drops any broadcast with a strictly lower
 * one. Equal-generation broadcasts are accepted because position and
 * duration advance within a generation. When the service is rebound, the
 * high-water mark resets to {@code -1}, because a new service instance
 * restarts its counter at zero.</p>
 *
 * <p>The {@code UPDATE_PLAYLIST_FROM_FOLDERS} receiver refreshes the
 * existing {@link MusicLibrary} instance on the metadata loader, then
 * installs the refreshed playlist on the service from the main thread.
 * The database read is the largest main-thread cost in the folder-update
 * cycle; moving it off the main thread removes that cost from the
 * user-perceived block. The load runs on
 * {@link #mMetadataLoader}, the same single-thread executor the cold-start
 * metadata load uses, so playlist refreshes and metadata loads are
 * serialised with each other and never overlap.</p>
 *
 * <h3>Playlist Rebuild Ownership</h3>
 * <p>{@code UPDATE_PLAYLIST_FROM_FOLDERS} is emitted by
 * {@link FolderManager} after its scan completes. This activity's
 * receiver owns the rebuild that follows: it shows the
 * {@link LoadingOverlay} under {@code REASON_PLAYLIST_REBUILD}, runs
 * the library refresh on {@link #mMetadataLoader}, hands the new list
 * to the service, hides the overlay, and then broadcasts
 * {@link PlaylistManager#ACTION_TRIGGER_GENRE_LOADING}. Genre loading
 * owns the surface from that point until it finishes.</p>
 *
 * <p>Both overlays this activity owns — the cold-start
 * {@link #REASON_COLD_START} and the rebuild
 * {@link #REASON_PLAYLIST_REBUILD} — are keyed by their own reason
 * tokens, so one can hide without tearing down the other. See
 * {@link LoadingOverlay} for the ownership contract.</p>
 *
 * <h3>Cold Start</h3>
 * <p>Cold start paints the previous song for display before the
 * playlist arrives, then starts and binds the service. The preload is a
 * display optimization — it reads {@code last_song_path} and resolves
 * the song's metadata for the title, artist, and art — and does not
 * decide whether the song is restored. Restoration is decided by
 * {@link MusicService#setPlaylist(ArrayList, boolean)} when the library
 * load completes.</p>
 *
 * <h3>Album-Art Volume Gesture</h3>
 * <p>A vertical swipe beginning in the left or right edge zone of the
 * album-art container changes the music stream volume. The gesture is
 * scoped to the container: a touch that starts outside both edge zones
 * returns {@code false} from the touch listener and reaches whatever
 * sits behind the album art. See
 * {@link #handleVolumeGesture(View, MotionEvent)}.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>The album-art container's size and visibility are a pure function
 * of {@code Configuration.screenHeightDp}, recomputed in
 * {@link #onConfigurationChanged(Configuration)}. In tall windows the
 * art is shown at full size; in medium windows it shrinks; in short
 * windows it hides so the title, controls, and seek bar take the
 * space. The gesture is unavailable when the art is hidden, and the
 * album-art clipping follows the container's current size on its own
 * through the existing {@link android.view.ViewOutlineProvider}.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Cold start shows the {@link LoadingOverlay} under
 * {@link #REASON_COLD_START} while the library loads. The overlay is
 * hidden by the load's completion or error callback. When the library
 * is reset, {@link PlaylistManager}'s reset operation sends a
 * {@code LIBRARY_RESET} broadcast that this activity receives through
 * its own receiver. The receiver clears the cached last song, cancels
 * in-flight album art and metadata loads, invalidates its own
 * {@link MusicLibrary} instance, applies the empty state, and disables
 * every control. The activity does not own the reset; it reacts to
 * it.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialised by {@link #mServiceLock}. UI updates
 * are coalesced by {@link #safeUpdateUI(Runnable)}. The main handler is
 * drained in {@link #onDestroy()} so no post is left after the activity
 * is gone.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see LoadingOverlay
 * @see NotificationController
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.0.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for the folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for the battery optimization request. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action that restarts the app after an update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";

    /** Broadcast action that updates the sort mode from the playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that sets a pending song path in the service. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /**
     * Reason token held while the cold-start library load is in
     * flight.
     */
    private static final String REASON_COLD_START = "COLD_START";

    /**
     * Reason token held while the post-scan playlist rebuild is in
     * flight.
     *
     * <p>Distinct from {@link #REASON_COLD_START} so that a rebuild
     * that overlaps the tail of a cold start does not tear down the
     * cold start's overlay, and vice versa. See {@link LoadingOverlay}
     * for the ownership contract.</p>
     */
    private static final String REASON_PLAYLIST_REBUILD = "PLAYLIST_REBUILD";

    /**
     * Operation ID for the library-load overlay mirror, passed
     * through {@link ToastManager} to the library notification as an
     * ownership token.
     */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Message shown during the cold-start library load. */
    private static final String MESSAGE_LIBRARY_LOAD = "Just a moment...";

    /**
     * Interval for the library-load heartbeat, safely below
     * {@link ToastManager}'s stuck timeout so a gap between load
     * progress callbacks cannot trip the stuck detector.
     */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500;

    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay for the service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000;

    /** Delay before updating the next and previous buttons. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;

    /** Delay before updating the repeat and shuffle buttons. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250;

    /** Delay before playing loose tracks. */
    private static final long PLAY_LOOSE_TRACKS_DELAY_MS = 500;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;

    /** Delay before performing focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Buffer size for file copy operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of the album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 500;

    /** Duration of the button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /**
     * Fraction of the album-art container's width occupied by each
     * edge zone, expressed as a float in the range {@code [0, 0.5)}.
     *
     * <p>The edge zone is where a vertical swipe is interpreted as a
     * volume gesture. A touch that starts outside both zones is not
     * consumed by the listener and reaches whatever sits behind the
     * album art.</p>
     */
    private static final float VOLUME_GESTURE_EDGE_FRACTION = 0.20f;

    /**
     * Window height above which the album art is shown at its full
     * size.
     */
    private static final int SPLIT_SCREEN_FULL_HEIGHT_DP = 600;

    /**
     * Window height below which the album art is hidden entirely.
     * Below this height there is not enough vertical room for the art
     * to be useful, and the space is given to the title, controls,
     * and seek bar instead.
     */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    /** Album-art size at full screen, in dp. */
    private static final int ALBUM_ART_FULL_DP = 300;

    /** Album-art size in a shrunk split-screen window, in dp. */
    private static final int ALBUM_ART_SHRUNK_DP = 180;

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Text view showing the current song title. */
    @Nullable private TextView mSongTitle;

    /** Text view showing the current song artist. */
    @Nullable private TextView mSongArtist;

    /** Text view showing the elapsed playback time. */
    @Nullable private TextView mSeekTime;

    /** Text view showing the total playback duration. */
    @Nullable private TextView mTotalTime;

    /** Seek bar for scrubbing through the current song. */
    @Nullable private SeekBar mSeekBar;

    /** Play or pause button. */
    @Nullable private Button mPlayButton;

    /** Previous-track button. */
    @Nullable private Button mPrevButton;

    /** Next-track button. */
    @Nullable private Button mNextButton;

    /** Repeat-mode button. */
    @Nullable private Button mRepeatButton;

    /** Shuffle button. */
    @Nullable private Button mShuffleButton;

    /** Button that opens the folder manager. */
    @Nullable private Button mManagerButton;

    /** Button that opens the credits dialog. */
    @Nullable private Button mLlamaButton;

    /** Button that opens the playlist activity. */
    @Nullable private Button mPlaylistButton;

    /** Button that opens the equalizer activity. */
    @Nullable private Button mEqualizerButton;

    /** Button that opens the metadata editor. */
    @Nullable private Button mMetadataButton;

    /** Image view showing the current song's album art. */
    @Nullable private ImageView mAlbumArtView;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    /** In-memory library used to read the current song list. */
    @Nullable private MusicLibrary mMusicLibrary;

    /** Bound service that owns the playback state machine. */
    @Nullable private MusicService mMusicService;

    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageAccessHelper;

    /** Handler for UI operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for delayed service operations. */
    @NonNull private final Handler mServiceHandler = new Handler(Looper.getMainLooper());

    /** Handler used to schedule time-display updates; null when idle. */
    @Nullable private Handler mTimeHandler = null;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** True while the user is dragging the seek bar. */
    private boolean mIsUserSeeking = false;

    /** Guard that serialises concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);

    /** Deferred UI update posted while another update is running. */
    @Nullable private Runnable mPendingUIUpdate = null;

    /** Song path queued for playback once the service is bound. */
    private volatile String mPendingIncomingPath = null;

    /** Lock that serialises service calls. */
    @NonNull private final Object mServiceLock = new Object();

    /** Highest generation seen in an {@code UPDATE_PLAYER} broadcast. */
    private long mLastSeenGeneration = -1L;

    // ============================================================================
    // State Flags
    // ============================================================================

    /** True when the activity was started as part of a post-update restart. */
    private boolean mIsPostUpdateRestart = false;

    /** True once the cold-start library load has been requested. */
    private boolean isLoadingComplete = false;

    /** Runnable that heartbeats the library-load overlay. */
    @Nullable private Runnable mLibraryHeartbeatRunnable;

    // ============================================================================
    // Click Debounce Timestamps
    // ============================================================================

    /** Timestamp of the last play or pause click. */
    private long mLastPlayPauseClickTime = 0;

    /** Timestamp of the last next-track click. */
    private long mLastNextClickTime = 0;

    /** Timestamp of the last previous-track click. */
    private long mLastPrevClickTime = 0;

    /** Timestamp of the last repeat-mode click. */
    private long mLastRepeatClickTime = 0;

    /** Timestamp of the last shuffle click. */
    private long mLastShuffleClickTime = 0;

    /** Timestamp of the last equalizer button click. */
    private long mLastEqualizerClickTime = 0;

    /** Timestamp of the last manager button click. */
    private long mLastManagerClickTime = 0;

    /** Timestamp of the last llama button click. */
    private long mLastLlamaClickTime = 0;

    /** Timestamp of the last playlist button click. */
    private long mLastPlaylistClickTime = 0;

    /** Timestamp of the last metadata button click. */
    private long mLastMetadataClickTime = 0;

    // ============================================================================
    // Album Art Components
    // ============================================================================

    /** Cache of decoded album art bitmaps keyed by song path. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    /** Executor for album art decoding. */
    @NonNull private final ExecutorService mAlbumArtExecutor = Executors.newSingleThreadExecutor();

    /** Currently running album art decode task. */
    @Nullable private Future<?> mCurrentAlbumArtFuture = null;

    /** Song path whose album art is currently being loaded. */
    @Nullable private String mCurrentLoadingArtPath = null;

    /** Song path whose album art is currently displayed. */
    @Nullable private String mCurrentAlbumArtPath = null;

    /** Executor for metadata loading. */
    @NonNull private final ExecutorService mMetadataLoader = Executors.newSingleThreadExecutor();

    /** Currently running metadata load task. */
    @Nullable private Future<?> mCurrentMetadataFuture = null;

    /** Currently displayed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Untinted placeholder bitmap used to regenerate the tinted copy. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    /** Executor for placeholder rendering. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();

    /** Currently running placeholder render task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    /** Lock guarding the placeholder bitmaps. */
    @NonNull private final Object mPlaceholderLock = new Object();

    /** Loading overlay shown during cold-start and playlist rebuild. */
    @NonNull private LoadingOverlay mLoadingOverlay;

    /** Manager for the current theme color. */
    @Nullable private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    @Nullable private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    @Nullable private BroadcastReceiver mThemeReceiver;

    /** Observer for MediaStore changes. */
    @Nullable private StorageObserver mStorageObserver;

    /** Song loaded from the persisted last path at startup. */
    @Nullable private Song mCachedLastSong = null;

    // ============================================================================
    // Volume Gesture Components
    // ============================================================================

    /** System audio manager, resolved in onCreate; null on devices without one. */
    @Nullable private AudioManager mAudioManager;

    /** True while a volume gesture is in progress. */
    private boolean mVolumeGestureActive = false;

    /** Y coordinate of the gesture's starting touch, in raw screen pixels. */
    private float mVolumeGestureStartY = 0f;

    /** Music-stream volume at the start of the gesture. */
    private int mVolumeGestureStartVolume = 0;

    /** Maximum music-stream volume on this device, sampled at gesture start. */
    private int mVolumeGestureMaxVolume = 0;

    /** Container height sampled at gesture start, in pixels. */
    private int mVolumeGestureContainerHeight = 1;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    /** Receiver for {@code UPDATE_PLAYER} broadcasts. */
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;

    /** Receiver for {@code PLAY_SONG} broadcasts. */
    @Nullable private BroadcastReceiver mPlaySongReceiver;

    /** Receiver for {@code BLUETOOTH_PLAY} broadcasts. */
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;

    /** Receiver for {@code BLUETOOTH_PAUSE} broadcasts. */
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;

    /** Receiver for {@code GET_PLAYING_STATE} broadcasts. */
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;

    /** Receiver for {@code LIBRARY_RESET} broadcasts emitted by {@link PlaylistManager}. */
    @Nullable private BroadcastReceiver mLibraryResetReceiver;

    /** Receiver for {@code RESTART_APP} broadcasts. */
    @Nullable private BroadcastReceiver mRestartReceiver;

    /** Receiver for {@code SAVE_PLAYER_STATE_NOW} broadcasts. */
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;

    /** Receiver for {@code BLUETOOTH_CONNECTED} broadcasts. */
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;

    /** Receiver for {@code SYNC_STARTED} broadcasts. */
    @Nullable private BroadcastReceiver mSyncStartedReceiver;

    /** Receiver for {@code SYNC_COMPLETE} broadcasts. */
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;

    /** Receiver for {@code UPDATE_PLAYLIST_FROM_FOLDERS} broadcasts. */
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;

    /** Receiver for {@code SOFT_UPDATE_PLAYLIST} broadcasts. */
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;

    /** Receiver for {@code METADATA_UPDATED} broadcasts. */
    @Nullable private BroadcastReceiver mMetadataUpdatedReceiver;

    /** Receiver for {@code PLAYBACK_RECOVERED} broadcasts. */
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;

    /** Receiver for {@code UPDATE_SORT_MODE} broadcasts. */
    @Nullable private BroadcastReceiver mSortModeReceiver;

    // ============================================================================
    // Service Connection
    // ============================================================================

    /**
     * Connection to {@link MusicService} that loads the playlist once the
     * service is bound and resets the generation high-water mark on every
     * (re)connection.
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG, "Processing pending incoming file on service connect: "
                    + pendingPath);
                mMusicService.setPendingSongPath(pendingPath);
                sendBroadcast(new Intent("SOFT_UPDATE_PLAYLIST"));
            }

            if (mPlayButton != null && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }

            loadFullPlaylistInBackground();
            updateRepeatButton();
            updateShuffleButton();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow =
                            (mMusicService != null && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow
                                ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        Song currentSong = (mMusicService != null)
                            ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(
                            MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, the view hierarchy, the receivers, and
     * the service binding, and starts the permission check.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageAccessHelper = StorageAccessHelper.getInstance(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        mLoadingOverlay = new LoadingOverlay(
            this, mThemeHelper.getThemeColorInt());

        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Registers the theme receiver if it is not already registered.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes the
     * playback display from the service, and reapplies the theme.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (mMusicService != null && mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();

            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(
                this, MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Releases every resource held by the activity: handlers, executors,
     * futures, caches, the library, the storage observer, the service
     * binding, and every receiver.
     *
     * <p>Does not tear down any persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; this activity
     * may be destroying itself while {@link FolderManager} still owns
     * the {@code "FOLDER_SYNC"} overlay or {@link PlaylistManager} still
     * owns the {@code "GENRE_UPDATE"} or {@code "LIBRARY_RESET"}
     * overlays, and the ownership contract on {@link ToastManager}
     * exists precisely so this activity cannot strand those operations'
     * progress. Overlays are hidden by their owners through
     * {@link ToastManager#hidePersistentOverlay(String)}.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }

        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }
        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            mAlbumArtCache = null;
        }

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();

        // The loading overlay's container is removed from the view
        // hierarchy by the framework as part of the activity's
        // teardown. No explicit detach is required.
    }

    /**
     * Forwards the trim-memory signal to the bound service when one is
     * available.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", exception);
            }
        }
    }

    /**
     * Updates the intent and either closes the app or processes a new
     * incoming file.
     *
     * @param intent The new intent delivered to the activity
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Reapplies the split-screen layout when the window configuration
     * changes.
     *
     * <p>The activity declares {@code configChanges} for
     * {@code orientation}, {@code screenSize}, {@code smallestScreenSize},
     * and {@code screenLayout}, so a resize does not recreate the
     * activity. The album art's size and visibility are recomputed in
     * place.</p>
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applySplitScreenLayout(config);
    }

    /**
     * Handles media keys delivered to a focused activity.
     *
     * @param keyCode Code of the pressed key
     * @param event Full key event
     * @return True when the key was consumed
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Handles the folder selection result and the battery optimization
     * result.
     *
     * @param requestCode The request code passed to the launcher
     * @param resultCode The result code returned by the target activity
     * @param data The intent carrying the result, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageAccessHelper != null) {
                final String folderPath = mStorageAccessHelper.getFolderPathFromUri(treeUri);
                mStorageAccessHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageAccessHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName,
                    ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized =
                        powerManager.isIgnoringBatteryOptimizations(getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows a battery optimization result toast after a short delay.
     *
     * @param optimized True when the app is exempt from battery
     *        optimizations
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    String message = optimized
                        ? "Background playback optimized"
                        : "Background playback restricted";
                    ToastManager.showToast(MusicPlayer.this, message,
                        ToastManager.LENGTH_SHORT);
                }
            }
        }, 150);
    }

    /**
     * Handles the runtime permission result, proceeding with
     * initialization when every permission was granted.
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    "Permissions required to read and play songs in background",
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                mLoadingOverlay.hide(REASON_COLD_START);
            }
        }
    }

    // ============================================================================
    // NavigationController Listener Implementation
    // ============================================================================

    /**
     * Enables or disables the playlist and metadata buttons according to
     * the current database-actions state.
     *
     * @param group Button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches typefaces and touch animations, and
     * primes the initial control state.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();
        setupVolumeGesture();

        final Typeface fontAwesomeTypeface = FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) {
            mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        if (mPrevButton != null) {
            mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        if (mNextButton != null) {
            mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);
        }

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        applySplitScreenLayout(getResources().getConfiguration());

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN)
                            .scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL)
                            .scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Split-Screen Layout
    // ============================================================================

    /**
     * Applies the album-art size and visibility for the current window
     * height.
     *
     * <p>The decision is a pure function of
     * {@code config.screenHeightDp}, which in multi-window mode is the
     * height of this app's window, not the device screen.</p>
     *
     * <ul>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_FULL_HEIGHT_DP}: album art visible at
     *       {@link #ALBUM_ART_FULL_DP} dp.</li>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}: album art visible at
     *       {@link #ALBUM_ART_SHRUNK_DP} dp. The volume gesture remains
     *       available.</li>
     *   <li>Height below {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}: album art
     *       hidden. The volume gesture is unavailable, and the title,
     *       controls, and seek bar take the space.</li>
     * </ul>
     *
     * @param config Configuration carrying the current window height
     */
    private void applySplitScreenLayout(@NonNull Configuration config) {
        final FrameLayout albumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) {
            return;
        }

        final int heightDp = config.screenHeightDp;
        final int sizeDp;
        final int visibility;

        if (heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP) {
            sizeDp = ALBUM_ART_FULL_DP;
            visibility = View.VISIBLE;
        } else if (heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP) {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.VISIBLE;
        } else {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.GONE;
        }

        final int sizePx = dpToPx(sizeDp);
        final ViewGroup.LayoutParams params =
            albumArtContainer.getLayoutParams();
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx;
            params.height = sizePx;
            albumArtContainer.setLayoutParams(params);
        }
        if (albumArtContainer.getVisibility() != visibility) {
            albumArtContainer.setVisibility(visibility);
        }
    }

    // ============================================================================
    // Volume Gesture
    // ============================================================================

    /**
     * Attaches the volume gesture listener to the album-art container.
     *
     * <p>The listener decides on {@link MotionEvent#ACTION_DOWN} whether
     * the gesture belongs to the album art. A touch that starts in the
     * left or right edge zone begins a volume gesture; a touch that
     * starts anywhere else returns {@code false} from the listener, so
     * the container is not the touch target for the gesture and the
     * touch passes through.</p>
     *
     * <p>While the gesture is active, the container requests its parent
     * to disallow intercepting the touch. That keeps a vertical swipe
     * from being consumed by a scroll container above the album art,
     * and it is the mechanism the codebase uses everywhere a child
     * needs uninterrupted ownership of a sequence of move events.</p>
     */
    private void setupVolumeGesture() {
        final FrameLayout albumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) {
            return;
        }
        albumArtContainer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                return handleVolumeGesture(view, event);
            }
        });
    }

    /**
     * Dispatches a touch event on the album-art container.
     *
     * @param view Album-art container
     * @param event Touch event
     * @return True when the gesture is being consumed by the volume
     *         handler
     */
    private boolean handleVolumeGesture(@NonNull View view,
                                        @NonNull MotionEvent event) {
        if (mAudioManager == null) {
            return false;
        }

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                final int width = view.getWidth();
                if (width <= 0) {
                    return false;
                }
                final float x = event.getX();
                final float edgeZone = width * VOLUME_GESTURE_EDGE_FRACTION;
                if (x > edgeZone && x < width - edgeZone) {
                    return false;
                }

                final int maxVolume = mAudioManager.getStreamMaxVolume(
                    AudioManager.STREAM_MUSIC);
                if (maxVolume <= 0) {
                    return false;
                }

                mVolumeGestureActive = true;
                mVolumeGestureStartY = event.getRawY();
                mVolumeGestureStartVolume = mAudioManager.getStreamVolume(
                    AudioManager.STREAM_MUSIC);
                mVolumeGestureMaxVolume = maxVolume;
                mVolumeGestureContainerHeight = Math.max(1, view.getHeight());

                final ViewParent parent = view.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                return true;
            }

            case MotionEvent.ACTION_MOVE: {
                if (!mVolumeGestureActive) {
                    return false;
                }
                final float dy = event.getRawY() - mVolumeGestureStartY;
                final float fraction = -dy / mVolumeGestureContainerHeight;
                int target = Math.round(
                    mVolumeGestureStartVolume
                        + fraction * mVolumeGestureMaxVolume);
                target = Math.max(0,
                    Math.min(mVolumeGestureMaxVolume, target));

                final int current = mAudioManager.getStreamVolume(
                    AudioManager.STREAM_MUSIC);
                if (target != current) {
                    try {
                        mAudioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC, target, 0);
                        showVolumeToast(target);
                    } catch (SecurityException exception) {
                        Log.w(TAG, "setStreamVolume refused", exception);
                    }
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                mVolumeGestureActive = false;
                final ViewParent parent = view.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(false);
                }
                return true;
            }

            default:
                return false;
        }
    }

    /**
     * Shows a transient toast reporting the current volume as a
     * percentage.
     *
     * @param level Current stream volume
     */
    private void showVolumeToast(int level) {
        if (mVolumeGestureMaxVolume <= 0) {
            return;
        }
        final int percent = Math.round(
            100f * level / mVolumeGestureMaxVolume);
        ToastManager.showToast(this, "Volume " + percent + "%",
            ToastManager.LENGTH_SHORT);
    }

    // ============================================================================
    // Permission and Initialization Methods
    // ============================================================================

    /**
     * Requests the runtime permissions the app needs and proceeds with
     * initialization once they have been decided.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 34) {
                if (checkSelfPermission(
                        "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK");
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Runs the initialization path once permissions have been decided.
     *
     * <p>The path is linear: paint the previous song for display, then
     * start and bind the service. The service decides what to restore
     * from the same persisted facts when {@code setPlaylist} arrives.
     * The activity's preload is a display optimization — it puts the
     * previous song's title, artist, and art on screen while the
     * playlist is still loading — and it does not change what the
     * service does.</p>
     */
    private void proceedWithInitialization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        preloadLastSongDisplay();

        final Intent serviceIntent = new Intent(
            MusicPlayer.this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);

        handleIncomingFile(getIntent());
    }

    /**
     * Requests an exemption from battery optimizations when the app is
     * not yet exempt.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null
                    && !powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to request battery optimization", exception);
                }
            }
        }
    }

    // ============================================================================
    // Incoming File Handling
    // ============================================================================

    /**
     * Plays, queues, or imports the audio file referenced by the given
     * {@code ACTION_VIEW} intent.
     *
     * <p>When the file is already in the library or already a loose
     * track, it is played immediately if the service is bound, or queued
     * if the service is not yet bound. Otherwise the file is added to the
     * loose-tracks table and played once the addition completes.</p>
     *
     * @param intent The intent that triggered the activity, or null
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }

        final String action = intent.getAction();
        if (!Intent.ACTION_VIEW.equals(action)) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        Song existingSong = SongDatabase.getInstance(this).getSong(filePath);
        if (existingSong != null) {
            Log.d(TAG, "Song already in library, playing: " + filePath);
            if (mMusicService != null && mIsServiceBound) {
                mMusicService.playSongByPath(filePath);
                updateUIForPlayingSong(existingSong);
                updateAlbumArt(filePath);
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();
            } else {
                mPendingIncomingPath = filePath;
                Log.d(TAG, "Service not ready, queued existing song: " + filePath);
            }
            return;
        }

        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (filePath.equals(looseSong.getPath())) {
                    Log.d(TAG, "Already a loose track, playing: " + filePath);
                    if (mMusicService != null && mIsServiceBound) {
                        mMusicService.playSongByPath(filePath);
                        updateUIForPlayingSong(looseSong);
                        updateAlbumArt(filePath);
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    } else {
                        mPendingIncomingPath = filePath;
                        Log.d(TAG, "Service not ready, queued loose track: " + filePath);
                    }
                    return;
                }
            }
        }

        Log.d(TAG, "New song detected, adding to library: " + filePath);

        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        final Song newSong;
        if (parsedSong == null) {
            String fileName = new File(filePath).getName();
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > 0) {
                fileName = fileName.substring(0, dotIndex);
            }
            newSong = new Song(
                fileName,
                "Unknown Artist",
                "Unknown Album",
                "Unknown Genre",
                filePath,
                0,
                null
            );
        } else {
            newSong = parsedSong;
        }

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setPendingSongPath(filePath);
            Log.d(TAG, "Pending song path set in MusicService: " + filePath);
        } else {
            mPendingIncomingPath = filePath;
            Log.d(TAG, "Service not ready, queued pending path: " + filePath);
        }

        Intent setPendingIntent = new Intent(ACTION_SET_PENDING_SONG);
        setPendingIntent.putExtra("song_path", filePath);
        sendBroadcast(setPendingIntent);

        final String finalFilePath = filePath;
        PlaylistManager playlistManager = PlaylistManager.getInstance(this);
        playlistManager.addLooseTrackAndUpdate(newSong,
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track added successfully: " + finalFilePath);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mMusicService != null && mIsServiceBound) {
                            mMusicService.playPendingSongIfExists();

                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null
                                    && finalFilePath.equals(currentSong.getPath())) {
                                updateUIForPlayingSong(currentSong);
                                updateAlbumArt(currentSong.getPath());
                            }
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        } else {
                            Log.d(TAG, "Service not ready after loose track addition, "
                                + "will retry");
                            mPendingIncomingPath = finalFilePath;
                            if (!mIsServiceBound) {
                                Intent serviceIntent = new Intent(
                                    MusicPlayer.this, MusicService.class);
                                startService(serviceIntent);
                                bindService(serviceIntent, mServiceConnection,
                                    BIND_AUTO_CREATE);
                            }
                        }
                    }
                }, PLAY_LOOSE_TRACKS_DELAY_MS);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Failed to add loose track: " + error);
                if (mMusicService != null) {
                    mMusicService.clearPendingSongPath();
                }
                mPendingIncomingPath = null;
                ToastManager.showToast(MusicPlayer.this,
                    "Failed to open file: " + error, ToastManager.LENGTH_NORMAL);
            }
        });
    }

    // ============================================================================
    // URI Helper Methods
    // ============================================================================

    /**
     * Resolves the filesystem path of the given content URI, copying the
     * content to a temporary file when the media store path is not
     * available.
     *
     * @param uri Content URI to resolve
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {
                    android.provider.MediaStore.Audio.Media.DATA
                };
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    /**
     * Copies the content of the given URI to a temporary cache file.
     *
     * @param uri Content URI to copy
     * @return The path of the temporary file, or null on failure
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies inside
     * the given folder.
     *
     * @param folderUri Folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageAccessHelper == null) {
            return;
        }

        final String folderPath = mStorageAccessHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ============================================================================
    // Playlist Loading Methods
    // ============================================================================

    /**
     * Loads the full playlist on a background thread and hands it to the
     * bound service when the load completes.
     *
     * <p>Shows the {@link LoadingOverlay} under
     * {@link #REASON_COLD_START} for the duration of the load. The
     * overlay's reason token is removed by the load's completion and
     * error callbacks, and by the permission-denied path in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) {
            return;
        }

        mLoadingOverlay.show(REASON_COLD_START);

        mMusicLibrary.loadAllSongsWithProgress(new MusicLibrary.LoadProgressListener() {
            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(
                        MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(@NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong != null && mSongTitle != null
                        && mSongArtist != null && mThemeHelper != null) {
                        mSongTitle.setText(currentSong.getTitle());
                        mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        mSongArtist.setText(currentSong.getArtist());
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        updateAlbumArt(currentSong.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                mLoadingOverlay.hide(REASON_COLD_START);
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                mLoadingOverlay.hide(REASON_COLD_START);
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is scheduled. A
     * second call while a heartbeat is already scheduled does nothing.
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Runs the given UI update on the main thread, coalescing requests
     * that arrive while another update is in flight.
     *
     * @param update The update to run
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }

        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Writes the given song's title and artist to the UI.
     *
     * <p>The media session metadata is not written here. The service is
     * the sole source of the session metadata, and the controller is the
     * sole writer, so this activity does not push to the session.</p>
     *
     * @param song Song to display, or null
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3)
                            + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Writes the given playing song's title and artist to the UI and
     * refreshes the album art.
     *
     * <p>The media session metadata is not written here. The service is
     * the sole source of the session metadata, and the controller is the
     * sole writer, so this activity does not push to the session.</p>
     *
     * @param song Song that started playing, or null
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3)
                            + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Enables every transport control when the library contains songs.
     */
    private void enableAllControls() {
        final boolean hasSongs =
            (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }

    /**
     * Applies the current library state to the previous, next, repeat,
     * and shuffle controls.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs =
            (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }

    /**
     * Shows the empty state: placeholder title, placeholder artist,
     * placeholder album art, and disabled transport controls.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }

        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }

        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }

        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    // ============================================================================
    // Playback Control Methods
    // ============================================================================

    /**
     * Runs the given service action on the main thread while holding the
     * service lock, when the service is bound.
     *
     * @param action The service action to run
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays the song at the given index and updates the UI.
     *
     * @param index Index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles playback through the service when the library contains
     * songs.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        safeCallService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    /**
     * Asks the service to play the next song and refreshes the play
     * button.
     */
    private void playNextSong() {
        if (mNextButton == null || !mNextButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playNextSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    /**
     * Asks the service to play the previous song and refreshes the play
     * button.
     */
    private void playPreviousSong() {
        if (mPrevButton == null || !mPrevButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playPreviousSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    // ============================================================================
    // Button State Update Methods
    // ============================================================================

    /**
     * Updates the repeat button's label and active state from the
     * service's current repeat mode.
     */
    private void updateRepeatButton() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mRepeatButton.isEnabled();

            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);

                if (repeatMode == 2) {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                }

                mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(mRepeatButton, false, false);
            }
        }
    }

    /**
     * Updates the shuffle button's active state from the service's
     * current shuffle flag.
     */
    private void updateShuffleButton() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mShuffleButton.isEnabled();

            mShuffleButton.setText(FontAwesome.SHUFFLE);

            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(mShuffleButton, false, false);
            }
        }
    }

    /**
     * Updates the play/pause button's label and enabled state from the
     * service's current playback state.
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                final boolean hasSongs =
                    (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                    return;
                }

                mPlayButton.setEnabled(true);

                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }

                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                        return;
                    }

                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating play/pause button", exception);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }

    // ============================================================================
    // Seek Bar Methods
    // ============================================================================

    /**
     * Attaches the seek-bar change listener.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null
                        && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts the periodic time-display update runnable.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong = service.getCurrentSong();
                        if (currentSong != null && currentSong.getDuration() > 0) {
                            duration = (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(formatTime(duration));
                        }

                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display", exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Returns the given duration formatted as {@code mm:ss} or
     * {@code hh:mm:ss}.
     *
     * @param milliseconds Duration in milliseconds
     * @return The formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ============================================================================
    // Album Art Methods
    // ============================================================================

    /**
     * Returns the sample size needed to decode an image at or above the
     * requested size.
     *
     * @param options Options whose bounds have been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options,
                                      int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes the given image bytes with downsampling to the requested
     * size.
     *
     * @param data Image bytes to decode
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }

    /**
     * Loads and displays the album art for the given song path.
     *
     * <p>Consults the LRU cache first; on a miss, decodes the art on the
     * album art executor and dispatches the result to the main thread.
     * The decoded bitmap is placed on the album art view only; the media
     * session's art is written by the service's own prefetch through
     * the controller.</p>
     *
     * @param filePath Path of the song, or null to display the placeholder
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            return;
        }

        if (filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }

        mCurrentAlbumArtPath = filePath;

        if (mAlbumArtCache != null) {
            final Bitmap cachedBitmap = mAlbumArtCache.get(filePath);
            if (cachedBitmap != null) {
                applyAlbumArtWithFade(cachedBitmap);
                return;
            }
        }

        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }

        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;

        mCurrentAlbumArtFuture = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap albumArtBitmap = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        albumArtBitmap = decodeSampledBitmap(artBytes,
                            MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception exception) {
                            // The retriever is not in a state that permits release.
                        }
                    }
                }

                final Bitmap resultBitmap = albumArtBitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (taskPath.equals(mCurrentLoadingArtPath)
                                && taskPath.equals(mCurrentAlbumArtPath)) {
                            if (resultBitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, resultBitmap);
                                applyAlbumArtWithFade(resultBitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtFuture != null
                                && mCurrentAlbumArtFuture.isDone()) {
                            mCurrentAlbumArtFuture = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }

    /**
     * Sets the given bitmap on the album art view with a fade-in, or the
     * placeholder when the bitmap is not usable.
     *
     * @param bitmap Bitmap to display, or null
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            return;
        }

        if (isFinishing() || isDestroyed() || mAlbumArtView == null) {
            return;
        }

        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);

        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }

        applyAlbumArtClipping();
    }

    /**
     * Loads and displays the current themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    /**
     * Returns the path of the current song, or null when no song is
     * playing.
     *
     * @return The current song's path, or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Returns whether the given bitmap is non-null, unrecycled, and
     * non-empty.
     *
     * @param bitmap Bitmap to test, or null
     * @return True when the bitmap can be displayed
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled()
            && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }

    // ============================================================================
    // Placeholder Methods
    // ============================================================================

    /**
     * Rebuilds the themed placeholder bitmap from the source image and
     * applies the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null
                                && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tintedBitmap = mOriginalPlaceholderBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap = BitmapFactory.decodeResource(
                            getResources(), R.drawable.album_art_placeholder, options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null
                                        && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tintedBitmap.copy(
                                    Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(
                        themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null
                                        && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null
                                    || (mAlbumArtCache != null
                                        && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                }
                            }
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG, "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cancels any in-flight placeholder render task and recycles the
     * placeholder bitmaps.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Recycles the given bitmap, ignoring any exception.
     *
     * @param bitmap Bitmap to recycle, or null
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ============================================================================
    // Album Art Clipping Methods
    // ============================================================================

    /**
     * Applies rounded-corner clipping and the container background to the
     * album art container.
     *
     * <p>The outline provider reads the view's current width and height
     * at outline time, and the framework invalidates the outline when
     * the view's size changes. A resize from the split-screen layout is
     * therefore reflected in the clipped corners without any
     * coordination here.</p>
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }

    // ============================================================================
    // Navigation Methods
    // ============================================================================

    /**
     * Opens the folder manager activity with the slide-left transition.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the playlist activity with the slide-right transition.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the metadata editor for the current song, or in the awaiting
     * state when no song is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Returns the current song from the service, or null when the
     * service is not bound.
     *
     * @return The current song, or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ============================================================================
    // Cold-Start Preload
    // ============================================================================

    /**
     * Paints the previous song's title, artist, and art before the
     * playlist loads.
     *
     * <p>This is a display-only preload. It reads
     * {@code last_song_path} from preferences, resolves the song's
     * metadata on the metadata loader, and dispatches the result to the
     * main thread. It does not start the service, does not play
     * anything, and does not decide whether the song is restored.
     * Restoration is decided by
     * {@link MusicService#setPlaylist(ArrayList, boolean)} when the
     * library load completes.</p>
     *
     * <p>When no last song is stored, or the stored path no longer
     * exists, the empty state is applied and this method returns
     * immediately.</p>
     */
    private void preloadLastSongDisplay() {
        final SharedPreferences preferences = getSharedPreferences(
            PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath == null || !new File(lastPath).exists()) {
            applyNoSongState();
            return;
        }

        if (mSongTitle != null) {
            mSongTitle.setText("Loading...");
        }
        if (mSongArtist != null) {
            mSongArtist.setText("Loading...");
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
        }

        mCurrentMetadataFuture = mMetadataLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                final Song loadedSong = loadSongMetadata(lastPath);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (loadedSong != null && mThemeHelper != null) {
                            mCachedLastSong = loadedSong;
                            if (mSongTitle != null) {
                                mSongTitle.setText(loadedSong.getTitle());
                                mSongTitle.setTextColor(
                                    mThemeHelper.getThemeColorInt());
                            }
                            if (mSongArtist != null) {
                                mSongArtist.setText(loadedSong.getArtist());
                                mSongArtist.setTextColor(
                                    Color.parseColor("#C0C0C0"));
                            }
                            final Bitmap cachedArt = mAlbumArtCache != null
                                ? mAlbumArtCache.get(lastPath) : null;
                            if (cachedArt != null) {
                                applyAlbumArtWithFade(cachedArt);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                        } else {
                            applyNoSongState();
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the metadata for the given path from the database when a
     * usable cached entry exists, and from the file otherwise.
     *
     * @param lastPath Absolute path of the song
     * @return The song, or null when the file cannot be read
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong = SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null
                && !cachedSong.getTitle().isEmpty()
                && !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: " + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = "Unknown Artist";
            }
            if (album == null) {
                album = "Unknown Album";
            }

            String genre = "Unknown Genre";
            Song databaseSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null && databaseSong.getGenre() != null
                    && !"Unknown Genre".equals(databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
                Log.d(TAG, "Found genre in database: " + genre);
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                    Log.d(TAG, "Read genre from file: " + genre);
                }
            }

            Song resultSong = new Song(title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(albumArt,
                    MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: " + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits release.
                }
            }
        }
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Registers the receiver for app-restart broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        ContextCompat.registerReceiver(
            this, mRestartReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Applies the current theme color to every control in the activity
     * and rebuilds the placeholder bitmap.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed()
                || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        if (mLoadingOverlay != null) {
            mLoadingOverlay.setColor(mThemeHelper.getThemeColorInt());
        }

        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(
                mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(
                mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(
                mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn =
                mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(
                mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn =
                mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(
                mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }

        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }

        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    /**
     * Restarts the activity with the no-animation flag.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                final long generation = intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    if (generation > mLastSeenGeneration) {
                        mLastSeenGeneration = generation;
                    }
                }

                final String state = intent.getStringExtra("state");
                final String songPath = intent.getStringExtra("song_path");
                final String targetPath = intent.getStringExtra("target_song_path");
                final boolean playing = intent.getBooleanExtra("is_playing", false);
                final int positionMs = intent.getIntExtra("position_ms", 0);
                final int durationMs = intent.getIntExtra("duration_ms", 0);

                safeUpdateUI(new Runnable() {
                    @Override
                    public void run() {
                        updatePlayPauseButton();

                        if (mSeekBar != null && mSeekBar.isEnabled() && durationMs > 0) {
                            if (mSeekBar.getMax() != durationMs) {
                                mSeekBar.setMax(durationMs);
                            }
                            mSeekBar.setProgress(positionMs);
                        }

                        if (mMusicService != null && mIsServiceBound) {
                            final boolean isPreparing = "PREPARING".equals(state);
                            final String verifyPath = (isPreparing && targetPath != null)
                                ? targetPath : songPath;
                            if (verifyPath != null) {
                                final Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null
                                        && verifyPath.equals(currentSong.getPath())) {
                                    if (playing) {
                                        updateUIForPlayingSong(currentSong);
                                    } else {
                                        updateUIForSong(currentSong);
                                        if (isPreparing) {
                                            updateAlbumArt(currentSong.getPath());
                                        }
                                    }
                                }
                            }
                        }

                        setupSeekBar();
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };

        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences preferences = getSharedPreferences(
                            PREFS_NAME, MODE_PRIVATE);
                        preferences.edit().putBoolean(
                            KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };

        /**
         * Reacts to the {@link PlaylistManager#ACTION_LIBRARY_RESET}
         * broadcast that the reset operation sends after its write
         * barrier commits.
         *
         * <p>Service-side teardown is owned by {@link MusicService}'s own
         * {@code LIBRARY_RESET} receiver, which runs whether or not this
         * activity is alive. This activity's job is its own UI: clear the
         * cached last song, cancel in-flight album art and metadata
         * loads, invalidate its own {@link MusicLibrary} instance, apply
         * the empty state, and disable every control.</p>
         *
         * <p>When {@code preserve_settings} is false, the activity also
         * asks the service to clear its repeat and shuffle preferences.
         * When it is true — the {@code LIBRARY} case used by the
         * folder-manager wipe — those preferences are preserved.</p>
         *
         * <p>The persistent overlay is left alone. The overlay on screen
         * during a reset is owned by {@link PlaylistManager}'s reset
         * operation and is hidden by that operation when its work
         * completes.</p>
         */
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(intent.getAction())) {
                    return;
                }

                final boolean preserveSettings = intent.getBooleanExtra(
                    PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);

                mPendingIncomingPath = null;
                mIsUserSeeking = false;
                mLastSeenGeneration = -1L;

                if (mCurrentAlbumArtFuture != null) {
                    mCurrentAlbumArtFuture.cancel(true);
                    mCurrentAlbumArtFuture = null;
                }
                if (mCurrentMetadataFuture != null) {
                    mCurrentMetadataFuture.cancel(true);
                    mCurrentMetadataFuture = null;
                }
                mCurrentLoadingArtPath = null;

                mCachedLastSong = null;

                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();

                        if (!preserveSettings && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }

                        if (mShuffleButton != null && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mRepeatButton, false, false);
                        }
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPlayButton, false, false);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPrevButton, false, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mNextButton, false, false);
                        }
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(mSeekBar, false);
                        }

                        updatePlayPauseButton();
                    }
                });
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected =
                        intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };

        /**
         * Receiver for the folder-sync progress broadcast emitted by
         * {@link FolderManager}'s update cycle.
         *
         * <p>This receiver is a relay, not an owner. When an overlay is
         * already on screen, the incoming message is applied under the
         * operation ID that currently owns the overlay. Substituting the
         * sender's operation ID here would be refused by the ownership
         * check, and the message on screen would keep showing the
         * previous operation's text while a different operation ran.</p>
         *
         * <p>When no overlay is on screen, one is shown only when the
         * sender named an owner. An invented operation ID creates an
         * overlay that no operation can later hide.</p>
         */
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_STARTED".equals(intent.getAction())) {
                    return;
                }
                final String text = intent.getStringExtra("custom_text");
                final String operationId = intent.getStringExtra("operation_id");
                if (text == null) {
                    return;
                }

                if (ToastManager.hasPersistentToast()) {
                    final String currentOwner = ToastManager.getCurrentOperationId();
                    if (currentOwner != null) {
                        ToastManager.updatePersistentOverlay(text, currentOwner);
                    }
                    return;
                }

                if (operationId == null || operationId.isEmpty()) {
                    Log.w(TAG, "SYNC_STARTED without operation_id; ignoring");
                    return;
                }
                ToastManager.showPersistentOverlay(MusicPlayer.this, text, operationId);
            }
        };

        /**
         * Observes the general "playlist changed" broadcast.
         *
         * <p>The persistent overlay is left alone. Every operation hides
         * its own overlay by its own operation ID when its work finishes.
         * A force-hide here would race the rebuild overlay's own show in
         * {@code mUpdatePlaylistFromFoldersReceiver}: the overlay is
         * posted to the main looper in the same tick that emits this
         * broadcast, and the broadcast's delivery can land on the looper
         * after the overlay show but before the first progress tick,
         * tearing the overlay down before it ever renders.</p>
         */
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                Log.d(TAG, "SYNC_COMPLETE received");
            }
        };

        /**
         * Owns the playlist-rebuild overlay for the folder-update cycle.
         *
         * <p>Shows the {@link LoadingOverlay} under
         * {@link #REASON_PLAYLIST_REBUILD}, runs the library refresh on
         * {@link #mMetadataLoader}, hands the new list to the service on
         * the main thread, hides the overlay, and broadcasts
         * {@link PlaylistManager#ACTION_TRIGGER_GENRE_LOADING}. Genre
         * loading owns the surface from the hide onward.</p>
         *
         * <p>The show happens before the executor work; the hide happens
         * in the main-thread continuation, on every exit path. Both are
         * keyed by {@link #REASON_PLAYLIST_REBUILD}, so the operation is
         * shown and hidden by the same component. The rebuild and the
         * genre-loading trigger run whether or not the activity is still
         * alive when the continuation fires.</p>
         */
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    return;
                }
                if (mMusicLibrary == null) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                }

                mLoadingOverlay.show(REASON_PLAYLIST_REBUILD);

                final MusicLibrary library = mMusicLibrary;
                final MusicService service = mMusicService;

                mMetadataLoader.execute(new Runnable() {
                    @Override
                    public void run() {
                        library.refreshCache();
                        final ArrayList<Song> allSongs = library.getAllSongs();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed() && service != null) {
                                    if (!allSongs.isEmpty()) {
                                        service.setPlaylist(allSongs, true);
                                        enableAllControls();
                                        updatePlayPauseButton();
                                        setupSeekBar();
                                        updateTimeDisplay();
                                        Song currentSong = service.getCurrentSong();
                                        if (currentSong != null) {
                                            updateUIForSong(currentSong);
                                            updateAlbumArt(currentSong.getPath());
                                        }
                                    } else {
                                        service.setPlaylist(null, false);
                                        applyNoSongState();
                                    }
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                                }

                                // The rebuild has been handed off. Hide
                                // the overlay before triggering genre
                                // loading, so the genre overlay opens
                                // onto an empty stack and tears down
                                // cleanly when its own work finishes.
                                mLoadingOverlay.hide(REASON_PLAYLIST_REBUILD);
                                sendBroadcast(new Intent(
                                    PlaylistManager.ACTION_TRIGGER_GENRE_LOADING));
                            }
                        });
                    }
                });
            }
        };

        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null)
                                        ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            mMusicLibrary.refreshCache();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"METADATA_UPDATED".equals(intent.getAction())) {
                    return;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist = intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final boolean hasAlbumArt =
                    intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved =
                    intent.getBooleanExtra("album_art_removed", false);
                final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");

                mMusicService.refreshMetadataForSong(songPath, title, artist,
                    album, genre, albumArtBytes, albumArtRemoved);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                final Song currentSong = (mMusicService != null)
                    ? mMusicService.getCurrentSong() : null;
                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                    if (albumArtRemoved && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        mCurrentAlbumArtPath = null;
                        loadAndDisplayPlaceholder();
                    } else if (hasAlbumArt && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        mCurrentAlbumArtPath = null;
                        updateAlbumArt(songPath);
                    }

                    if (mMusicService.isPlaying()) {
                        updateUIForPlayingSong(currentSong);
                    } else {
                        updateUIForSong(currentSong);
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        "Playback recovered", ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null)
                                    ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: "
                            + newSortMode);
                    }
                }
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mLibraryResetReceiver, PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mMetadataUpdatedReceiver, "METADATA_UPDATED");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    /**
     * Registers the given receiver for the given action with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any failure raised by the
     * framework.
     *
     * @param receiver The receiver to register, or null
     * @param action Broadcast action to subscribe to
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver,
                                        @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            ContextCompat.registerReceiver(
                this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver for " + action, exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any failure raised by the
     * framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every button click listener used by the activity, each
     * guarded by a debounce.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String message = newMode == 0 ? "Repeat: OFF"
                                : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, message,
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this,
                                newShuffle ? "Shuffle: ON" : "Shuffle: OFF",
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(
                            MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dismissedDialog) {
                                final View contentView = findViewById(android.R.id.content);
                                contentView.startAnimation(AnimationUtils.loadAnimation(
                                    MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(
                            MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Returns whether the activity has been destroyed, using the
     * API-appropriate check.
     *
     * @return True when the activity has been destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}