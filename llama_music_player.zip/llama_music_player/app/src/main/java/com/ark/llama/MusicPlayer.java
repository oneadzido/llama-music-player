package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.Manifest;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MusicPlayer - Main activity for music playback and control.
 *
 * <p>This activity is the main entry point of the Llama Music Player
 * application. It is a renderer over {@link MusicService}'s authoritative
 * playback state machine: user input is forwarded to the service, and the
 * resulting state is reflected from {@code UPDATE_PLAYER} broadcasts.</p>
 *
 * <h3>Architecture Overview</h3>
 * <p>The activity delegates all orchestration to {@link MusicService}. It
 * does not serialize user input; rapid button presses are forwarded to the
 * service, which owns the transition state. The activity's job is to
 * reflect the current state as it arrives via {@code UPDATE_PLAYER}
 * broadcasts.</p>
 *
 * <h3>Generation-Gated Broadcasts</h3>
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic {@code generation}
 * alongside the full playback snapshot ({@code state}, {@code current_index},
 * {@code target_index}, {@code song_path}, {@code target_song_path},
 * {@code is_playing}, {@code position_ms}, {@code duration_ms}). The
 * activity tracks the highest generation it has seen and drops any
 * broadcast with a strictly lower one. Equal-generation broadcasts are
 * accepted because position and duration advance within a generation.
 * This makes out-of-order delivery harmless.</p>
 *
 * <p>Two song paths are carried. {@code song_path} is the bound player's
 * song; during PREPARING it is still the outgoing song.
 * {@code target_song_path} is the destination and is equal to
 * {@code song_path} outside PREPARING. The activity renders
 * {@code target_song_path} during PREPARING so the title bar aligns with
 * {@link MusicService#getCurrentSong()}, which returns the destination
 * during the same window.</p>
 *
 * <h3>Service Reconnection</h3>
 * <p>When the service is (re)bound, the high-water generation mark is reset
 * to -1: a new service instance restarts its counter at 0, and a stale high
 * mark would silently drop every broadcast from the new instance.</p>
 *
 * <h3>Album Art</h3>
 * <p>Album art loading uses a single-threaded executor with LRU caching.
 * Downsampling is applied via {@code BitmapFactory.Options.inSampleSize} to
 * prevent OOM on large embedded images. Placeholder bitmaps are themed and
 * regenerated whenever the theme color changes.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialized by {@code mServiceLock}. UI updates go
 * through {@code safeUpdateUI} which coalesces concurrent requests. The
 * main handler is drained on {@code onDestroy} to prevent leaks.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for battery optimization. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing first run flag. */
    private static final String KEY_FIRST_RUN = "first_run";

    /** Key for storing last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action for restarting the app after update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";

    /** Broadcast action for updating sort mode from playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action for setting pending song path in MusicService. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;

    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Timeout for loading overlay display in milliseconds. */
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;

    /** Delay for service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000;

    /** Delay for next/prev button updates in milliseconds. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;

    /** Delay for repeat/shuffle button updates in milliseconds. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250;

    /** Delay for playing loose tracks in milliseconds. */
    private static final long PLAY_LOOSE_TRACKS_DELAY_MS = 500;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;

    /** Delay for focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Buffer size for file copying operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 500;

    /** Duration of button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation (97% of normal size). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;

    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;

    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    // ========================================================================
    // UI Components
    // ========================================================================

    /** TextView for displaying song title. */
    @Nullable private TextView mSongTitle;

    /** TextView for displaying artist name. */
    @Nullable private TextView mSongArtist;

    /** TextView for current seek position. */
    @Nullable private TextView mSeekTime;

    /** TextView for total track duration. */
    @Nullable private TextView mTotalTime;

    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;

    /** Play/Pause control button. */
    @Nullable private Button mPlayButton;

    /** Previous track button. */
    @Nullable private Button mPrevButton;

    /** Next track button. */
    @Nullable private Button mNextButton;

    /** Repeat mode button (off/all/one). */
    @Nullable private Button mRepeatButton;

    /** Shuffle mode button. */
    @Nullable private Button mShuffleButton;

    /** Button to open folder manager. */
    @Nullable private Button mManagerButton;

    /** Button to open credits dialog. */
    @Nullable private Button mLlamaButton;

    /** Button to open playlist view. */
    @Nullable private Button mPlaylistButton;

    /** Button to open equalizer. */
    @Nullable private Button mEqualizerButton;

    /** Button to open metadata editor. */
    @Nullable private Button mMetadataButton;

    /** ImageView for album art display. */
    @Nullable private ImageView mAlbumArtView;

    // ========================================================================
    // Managers and Services
    // ========================================================================

    /** Music library manager for song data. */
    @Nullable private MusicLibrary mMusicLibrary;

    /** Bound music service instance. */
    @Nullable private MusicService mMusicService;

    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;

    /** Main thread handler for UI operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for service connection delayed operations. */
    @NonNull private final Handler mServiceHandler = new Handler(Looper.getMainLooper());

    /** Thread handler for time display updates. */
    @Nullable private Handler mTimeHandler = null;

    /** Flag indicating service binding state. */
    private boolean mIsServiceBound = false;

    /** Flag indicating user is currently seeking. */
    private boolean mIsUserSeeking = false;

    /** Atomic flag to prevent concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);

    /** Pending UI update runnable. */
    @Nullable private Runnable mPendingUIUpdate = null;

    /** Pending incoming song path for tracking file operations. */
    private volatile String mPendingIncomingPath = null;

    /** Lock object for thread-safe service access. */
    @NonNull private final Object mServiceLock = new Object();

    /**
     * Highest generation seen from UPDATE_PLAYER. Broadcasts with a strictly
     * lower generation are stale and dropped. Reset to -1 whenever the
     * service connection is (re)established: a new service instance restarts
     * its generation counter at 0, and a stale high-water mark would
     * otherwise reject every broadcast from the new instance.
     */
    private long mLastSeenGeneration = -1L;

    // ========================================================================
    // State Flags
    // ========================================================================

    /** Flag indicating post-update restart. */
    private boolean mIsPostUpdateRestart = false;

    /** Tracks if app initialization is complete. */
    private boolean isLoadingComplete = false;

    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================

    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;

    // ========================================================================
    // Album Art Components
    // ========================================================================

    /** LRU cache for album art bitmaps. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    /** Executor service for album art loading. */
    @NonNull private final ExecutorService mAlbumArtExecutor = Executors.newSingleThreadExecutor();

    /** Future representing the current album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtFuture = null;

    /** Path of currently loading album art. */
    @Nullable private String mCurrentLoadingArtPath = null;

    /** Path of currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;

    // ========================================================================
    // Metadata Loading
    // ========================================================================

    /** Executor service for loading last song metadata. */
    @NonNull private final ExecutorService mMetadataLoader = Executors.newSingleThreadExecutor();

    /** Future for metadata loading task. */
    @Nullable private Future<?> mCurrentMetadataFuture = null;

    // ========================================================================
    // Placeholder Components
    // ========================================================================

    /** Themed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Original untinted placeholder bitmap. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    /** Executor for placeholder generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();

    /** Current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    /** Lock object for placeholder synchronization. */
    @NonNull private final Object mPlaceholderLock = new Object();

    // ========================================================================
    // Overlay Components
    // ========================================================================

    /** Dim overlay for loading state. */
    @Nullable private View mDimOverlay = null;

    /** Loading spinner inside dim overlay. */
    @Nullable private ProgressBar mLoadingSpinner = null;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Theme manager for color management. */
    @Nullable private ThemeManager mThemeManager;

    /** Theme helper for UI color application. */
    @Nullable private ThemeHelper mThemeHelper;

    /** Broadcast receiver for theme changes. */
    @Nullable private BroadcastReceiver mThemeReceiver;

    // ========================================================================
    // Storage Observer
    // ========================================================================

    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;

    // ========================================================================
    // Cached Data
    // ========================================================================

    /** Cached last song for quick loading. */
    @Nullable private Song mCachedLastSong = null;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;

    // ========================================================================
    // Service Connection
    // ========================================================================

    /**
     * Service connection for binding to MusicService. Handles initial UI
     * setup, generation-counter reset, pending incoming file dispatch, and
     * automatic reconnection.
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            // A new MusicService instance restarts mGeneration at 0, so the
            // high-water mark from the previous instance must be discarded
            // to avoid rejecting every broadcast from the new one.
            mLastSeenGeneration = -1L;

            // Dispatch any file that was opened while the service wasn't
            // bound yet.
            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG, "Processing pending incoming file on service connect: " + pendingPath);
                mMusicService.forceClearTransitionState();
                mMusicService.setPendingSongPath(pendingPath);
                sendBroadcast(new Intent("SOFT_UPDATE_PLAYLIST"));
            }

            // Eagerly enable controls when we already know about songs.
            if (mPlayButton != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, true, true);
            }

            loadFullPlaylistInBackground();
            updateRepeatButton();
            updateShuffleButton();

            // Second-phase setup once the service has settled its initial
            // playlist. Delayed because setPlaylist on the service is async.
            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) return;
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow = (mMusicService != null && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            // Auto-reconnect after a short delay. Keeps the UI functional
            // across service restarts without requiring user interaction.
            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    /**
     * Called when the activity is created. Initializes all components, sets
     * up UI, and binds to MusicService.
     *
     * @param savedInstanceState Previously saved state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);

        // Early-exit path used by the notification's close action: this
        // instance was launched solely to tear down the app.
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        // Album art cache: LRU with byte-count sizing.
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);

        // Post-update restart clears stale player state so the upgrade
        // doesn't resume a track that was removed during the update.
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Called when the activity starts.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    /**
     * Called when the activity stops.
     */
    @Override
    protected void onStop() {
        super.onStop();
        // Theme receiver only needs to be active while visible.
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Called when the activity resumes. Reattaches ToastManager persistent
     * overlay and updates UI with current playback state.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        // Re-sync button enabled state with the NavigationController group
        // state, since the group may have been toggled in another activity.
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));

        // Refresh UI from the live service if a song is playing.
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();

            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        // First-time "Just a moment..." greeting. Skipped if a persistent
        // overlay is already showing.
        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_SHORT);
        }
    }

    /**
     * Called when the activity restarts after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Called when the activity is destroyed. Cleans up all resources,
     * unregisters receivers, unbinds the service, and drains handlers.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }

        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }
        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            mAlbumArtCache = null;
        }

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        // Persist state before teardown so the next launch restores position.
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }

        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // Ignore
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();

        ToastManager.hidePersistentOverlay();
        hideLoadingOverlay();
    }

    /**
     * Forwards the memory trim event to the service. The service may
     * reconcile a stalled IDLE state on trim.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", exception);
            }
        }
    }

    /**
     * Called when a new intent is received while activity is running.
     *
     * @param intent The new intent
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Called when window focus changes.
     *
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Handles media button key events (headset controls). Routes through
     * the same request methods as UI buttons, so state-machine
     * serialization applies uniformly.
     *
     * @param keyCode The key code
     * @param event The key event
     * @return True if handled, false otherwise
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Handles activity results from folder selection and battery
     * optimization.
     *
     * @param requestCode The request code
     * @param resultCode The result code
     * @param data The result data intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                // Any loose tracks inside the newly-imported folder are now
                // covered by the folder permission; drop the redundant copies.
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized = powerManager.isIgnoringBatteryOptimizations(getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows the battery optimization result toast. Delayed because the
     * persistent overlay from the settings dialog may still be animating.
     *
     * @param optimized True if battery optimization is disabled
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    String message = optimized ?
                        "Background playback optimized" :
                        "Background playback restricted";
                    ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                }
            }
        }, 150);
    }

    /**
     * Handles runtime permission request results.
     *
     * @param requestCode The request code
     * @param permissions Requested permissions
     * @param grantResults Grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permissions required to read and play songs in background", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================

    /**
     * Called when navigation button group state changes.
     *
     * @param group The button group that changed
     * @param disabled True if the group is now disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    /**
     * Initializes all UI components, sets up typefaces, and configures
     * button animations.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        // FontAwesome glyphs on control buttons.
        final Typeface fontAwesomeTypeface = FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        // Background selectors provide the pressed/enabled visual states.
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Letter spacing gives the secondary buttons a spaced-caps look.
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Press animation on every interactive button.
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Adds a scale animation to a button for visual touch feedback.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================

    /**
     * Checks and requests runtime permissions. API 33+ uses
     * READ_MEDIA_AUDIO and POST_NOTIFICATIONS; API 34+ also requires
     * FOREGROUND_SERVICE_MEDIA_PLAYBACK; API 31+ requires BLUETOOTH_CONNECT.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 34) {
                if (checkSelfPermission("android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK");
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Proceeds with app initialization after permissions are granted.
     */
    private void proceedWithInitialization() {
        final SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !preferences.getBoolean(KEY_FIRST_RUN, false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        if (isFirstRun) {
            // First launch: skip the last-song restore path and start fresh.
            applyNoSongState();

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }

        handleIncomingFile(getIntent());
    }

    /**
     * Requests the system to ignore battery optimizations for this app.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to request battery optimization", exception);
                }
            }
        }
    }

    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================

    /**
     * Registers media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register media button receiver", exception);
        }
    }

    /**
     * Unregisters media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception exception) {
            // Ignore
        }
    }

    // ========================================================================
    // Incoming File Handling
    // ========================================================================

    /**
     * Handles ACTION_VIEW intents for audio files. Existing songs are played
     * directly; new songs are added as loose tracks and then played.
     *
     * <p>The play request is issued via {@code setPendingSongPath}, which
     * the service's anchor resolver consumes when the playlist next updates.
     * This unifies the "open a file" flow with the normal playlist
     * pipeline.</p>
     *
     * @param intent The incoming intent (ACTION_VIEW from file manager)
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }

        final String action = intent.getAction();
        if (!Intent.ACTION_VIEW.equals(action)) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        // Case 1: already in the library.
        Song existingSong = SongDatabase.getInstance(this).getSong(filePath);
        if (existingSong != null) {
            Log.d(TAG, "Song already in library, playing: " + filePath);
            if (mMusicService != null && mIsServiceBound) {
                mMusicService.forceClearTransitionState();
                mMusicService.playSongByPath(filePath);
                updateUIForPlayingSong(existingSong);
                updateAlbumArt(filePath);
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();
            } else {
                mPendingIncomingPath = filePath;
                Log.d(TAG, "Service not ready, queued existing song: " + filePath);
            }
            return;
        }

        // Case 2: already a loose track.
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (filePath.equals(looseSong.getPath())) {
                    Log.d(TAG, "Already a loose track, playing: " + filePath);
                    if (mMusicService != null && mIsServiceBound) {
                        mMusicService.forceClearTransitionState();
                        mMusicService.playSongByPath(filePath);
                        updateUIForPlayingSong(looseSong);
                        updateAlbumArt(filePath);
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    } else {
                        mPendingIncomingPath = filePath;
                        Log.d(TAG, "Service not ready, queued loose track: " + filePath);
                    }
                    return;
                }
            }
        }

        // Case 3: brand new file. Parse metadata, add as loose track, play.
        Log.d(TAG, "New song detected, adding to library: " + filePath);

        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        final Song newSong;
        if (parsedSong == null) {
            // Fallback: filename as title, unknown everything else.
            String fileName = new File(filePath).getName();
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > 0) {
                fileName = fileName.substring(0, dotIndex);
            }
            newSong = new Song(
                fileName,
                "Unknown Artist",
                "Unknown Album",
                "Unknown Genre",
                filePath,
                0,
                null
            );
        } else {
            newSong = parsedSong;
        }

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.forceClearTransitionState();
            mMusicService.setPendingSongPath(filePath);
            Log.d(TAG, "Pending song path set in MusicService: " + filePath);
        } else {
            mPendingIncomingPath = filePath;
            Log.d(TAG, "Service not ready, queued pending path: " + filePath);
        }

        // Also broadcast so any other receiver (e.g., a background service)
        // can pick this up.
        Intent setPendingIntent = new Intent(ACTION_SET_PENDING_SONG);
        setPendingIntent.putExtra("song_path", filePath);
        sendBroadcast(setPendingIntent);

        final String finalFilePath = filePath;
        PlaylistService playlistService = PlaylistService.getInstance(this);
        playlistService.addLooseTrackAndUpdate(newSong, new PlaylistService.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track added successfully: " + finalFilePath);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mMusicService != null && mIsServiceBound) {
                            mMusicService.playPendingSongIfExists();

                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null && finalFilePath.equals(currentSong.getPath())) {
                                updateUIForPlayingSong(currentSong);
                                updateAlbumArt(currentSong.getPath());
                            }
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        } else {
                            Log.d(TAG, "Service not ready after loose track addition, will retry");
                            mPendingIncomingPath = finalFilePath;
                            if (!mIsServiceBound) {
                                Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                                startService(serviceIntent);
                                bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                            }
                        }
                    }
                }, PLAY_LOOSE_TRACKS_DELAY_MS);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Failed to add loose track: " + error);
                if (mMusicService != null) {
                    mMusicService.clearPendingSongPath();
                }
                mPendingIncomingPath = null;
                ToastManager.showToast(MusicPlayer.this, "Failed to open file: " + error, ToastManager.LENGTH_NORMAL);
            }
        });
    }

    // ========================================================================
    // URI Helper Methods
    // ========================================================================

    /**
     * Converts a content URI to a file system path. Falls back to copying
     * the stream to a cache file when the DATA column is unavailable (which
     * happens with some document providers).
     *
     * @param uri The URI to convert
     * @return File system path or null
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    /**
     * Copies a content URI to a temporary file when direct path resolution
     * fails. Uses {@link SystemClock#elapsedRealtime()} for the suffix to
     * avoid collisions and remain immune to wall-clock changes.
     *
     * @param uri The content URI
     * @return Path to temporary file or null
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes loose tracks that fall inside a newly imported folder. Those
     * files are now covered by the folder permission, so their loose-track
     * duplicates are redundant.
     *
     * @param folderUri The folder URI being imported
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;

        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================

    /**
     * Loads the full playlist asynchronously and sets it on MusicService.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;

        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                        mSongTitle.setText(currentSong.getTitle());
                        mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        mSongArtist.setText(currentSong.getArtist());
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        updateAlbumArt(currentSong.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
            }
        });
    }

    // ========================================================================
    // UI Update Methods
    // ========================================================================

    /**
     * Thread-safe UI update method that prevents concurrent updates. A
     * second request while one is in flight is queued and executed after
     * the first finishes.
     *
     * @param update The runnable to execute on UI thread
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }

        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Updates UI with song metadata (non-playing state). Truncates long
     * titles and artists with ellipsis to prevent layout shifts.
     *
     * @param song The song to display
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.updateMediaSessionMetadata(finalSong, null);
                }

                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Updates UI for a playing song. Like updateUIForSong but also triggers
     * a fresh album art load for the given path.
     *
     * @param song The song being played
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.updateMediaSessionMetadata(finalSong, null);
                }

                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Enables all playback control buttons when songs are present.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }

    /**
     * Updates control buttons state based on playlist size.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }

    /**
     * Applies the "no songs" state. Called on first launch, after playlist
     * reset, and whenever the service reports an empty playlist.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }

        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }

        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }

        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    // ========================================================================
    // Playback Control Methods
    // ========================================================================

    /**
     * Executes an action on the MusicService under the service lock. Returns
     * silently if the service isn't bound; request methods are designed to
     * be safe no-ops in that state.
     *
     * @param action The action to execute
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays a song at the specified index in the playlist.
     *
     * @param index The playlist index
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 &&
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles between play and pause states.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        safeCallService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    /**
     * Forwards a NEXT request to the service. The service's state machine
     * serializes concurrent NEXT presses.
     */
    private void playNextSong() {
        if (mNextButton == null || !mNextButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playNextSong();
                // Deferred play/pause button refresh: the service updates
                // state asynchronously and the button visual should follow.
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    /**
     * Forwards a PREV request to the service.
     */
    private void playPreviousSong() {
        if (mPrevButton == null || !mPrevButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playPreviousSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    // ========================================================================
    // Button State Update Methods
    // ========================================================================

    /**
     * Updates the repeat button based on current repeat mode. Mode 2 uses a
     * distinct glyph (REPEAT_ONE); modes 0 and 1 share REPEAT with different
     * active tints.
     */
    private void updateRepeatButton() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mRepeatButton.isEnabled();

            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);

                if (repeatMode == 0) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else if (repeatMode == 1) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                }

                mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(mRepeatButton, false, false);
            }
        }
    }

    /**
     * Updates the shuffle button based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mShuffleButton.isEnabled();

            mShuffleButton.setText(FontAwesome.SHUFFLE);

            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(mShuffleButton, false, false);
            }
        }
    }

    /**
     * Updates the play/pause button based on current playback state.
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                    return;
                }

                mPlayButton.setEnabled(true);

                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }

                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                        return;
                    }

                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating play/pause button", exception);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }

    // ========================================================================
    // SeekBar Methods
    // ========================================================================

    /**
     * Sets up the SeekBar listener for position seeking. During drag, the
     * time label updates optimistically; the actual seek fires on release.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts a recurring handler to update the time display and seek bar
     * position. Suppressed while the user is actively seeking.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();

                    // Fallback to the cached song duration when the player
                    // hasn't reported one yet (e.g., during PREPARING).
                    if (duration <= 0) {
                        final Song currentSong = service.getCurrentSong();
                        if (currentSong != null && currentSong.getDuration() > 0) {
                            duration = (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(formatTime(duration));
                        }

                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display", exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Formats milliseconds into time string (MM:SS or HH:MM:SS).
     *
     * @param milliseconds Time in milliseconds
     * @return Formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ========================================================================
    // Album Art Methods
    // ========================================================================

    /**
     * Calculates the appropriate sample size for loading album art.
     *
     * @param options BitmapFactory.Options with outWidth and outHeight set
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The calculated sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes sampled bitmap from byte array to prevent OOM errors.
     *
     * @param data The image byte array
     * @param reqWidth Requested width
     * @param reqHeight Requested height
     * @return Sampled bitmap or null
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }

    /**
     * Updates album art for the given song path using the single-threaded
     * album-art executor. In-flight loads for the previous path are
     * cancelled when a new request arrives.
     *
     * @param filePath Path to the song file
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }

        // Same path as currently displayed: no-op.
        if (filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }

        mCurrentAlbumArtPath = filePath;

        // Cache hit: no async needed.
        if (mAlbumArtCache != null) {
            final Bitmap cachedBitmap = mAlbumArtCache.get(filePath);
            if (cachedBitmap != null) {
                applyAlbumArtWithFade(cachedBitmap);
                return;
            }
        }

        // Cancel any in-flight load for the previous path.
        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }

        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;

        mCurrentAlbumArtFuture = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap albumArtBitmap = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        albumArtBitmap = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception exception) {
                            // Ignore
                        }
                    }
                }

                final Bitmap resultBitmap = albumArtBitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        // Only apply if this is still the path we want.
                        if (taskPath.equals(mCurrentLoadingArtPath) && taskPath.equals(mCurrentAlbumArtPath)) {
                            if (resultBitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, resultBitmap);
                                applyAlbumArtWithFade(resultBitmap);
                                if (mMusicService != null && mIsServiceBound) {
                                    mMusicService.updateMediaSessionArt(resultBitmap);
                                }
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtFuture != null && mCurrentAlbumArtFuture.isDone()) {
                            mCurrentAlbumArtFuture = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }

    /**
     * Applies album art bitmap with fade animation.
     *
     * @param bitmap The bitmap to display
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }

        if (isFinishing() || isDestroyed() || mAlbumArtView == null) {
            return;
        }

        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);

        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }

        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }

    /**
     * Loads and displays the themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    /**
     * Pushes the current album art (or placeholder) to the notification.
     * The service handles the notification-side caching.
     */
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) {
            return;
        }

        Bitmap albumArt = null;
        Bitmap placeholder = null;

        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }

        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cachedBitmap = mAlbumArtCache.get(currentPath);
            if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
                albumArt = cachedBitmap;
            }
        }

        mMusicService.setNotificationAlbumArt(albumArt, placeholder, currentPath);
    }

    /**
     * Gets the path of the currently playing song.
     *
     * @return Song path or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Checks if a bitmap is valid for display.
     *
     * @param bitmap The bitmap to check
     * @return True if bitmap is valid
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }

    // ========================================================================
    // Placeholder Methods
    // ========================================================================

    /**
     * Updates the themed placeholder bitmap asynchronously. Runs on the
     * placeholder executor to keep the main thread free during bitmap copies
     * and tinting operations.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    // Try to reuse the original (untinted) bitmap.
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tintedBitmap = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    // First run: load from resources and stash the original.
                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tintedBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    // Tint via SRC_IN color filter.
                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            // Only swap the visible image if the current song
                            // has no album art of its own.
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG, "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Safely recycles a bitmap.
     *
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================

    /**
     * Applies rounded corner clipping to the album art container. Uses
     * ViewOutlineProvider on API 21+.
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }

    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================

    /**
     * Shows a dim overlay with a progress spinner. Used during long-running
     * playlist scans and metadata loads.
     */
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) {
                    return;
                }

                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) {
                    return;
                }

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;

                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }

    /**
     * Hides the loading overlay.
     */
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    /**
     * Opens the FolderManager activity.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the PlaylistActivity.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the MetadataEditor for the current song.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Gets the currently playing song.
     *
     * @return Current song or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ========================================================================
    // Initial Loading Methods
    // ========================================================================

    /**
     * Loads song metadata from a file path, preferring a complete DB entry
     * over a fresh ID3 read.
     *
     * @param lastPath The file path of the song
     * @return The loaded Song object, or null if loading fails
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong = SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null &&
            !cachedSong.getTitle().isEmpty() &&
            !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: " + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            // Fall back to filename when the ID3 title is missing.
            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = "Unknown Artist";
            }
            if (album == null) {
                album = "Unknown Album";
            }

            // Genre: prefer the DB value if it's already known.
            String genre = "Unknown Genre";
            Song databaseSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null && databaseSong.getGenre() != null &&
                !"Unknown Genre".equals(databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
                Log.d(TAG, "Found genre in database: " + genre);
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                    Log.d(TAG, "Read genre from file: " + genre);
                }
            }

            Song resultSong = new Song(title, artist, album, genre, lastPath, 0, null);
            // Seed the cache with the extracted art so the display path
            // can hit immediately.
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(albumArt, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: " + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Loads the last played song metadata asynchronously, then starts the
     * service with the cached song as a temporary playlist.
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);

        final SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }

            if (mCurrentMetadataFuture != null) {
                mCurrentMetadataFuture.cancel(true);
            }

            mCurrentMetadataFuture = mMetadataLoader.submit(new Runnable() {
                @Override
                public void run() {
                    if (Thread.currentThread().isInterrupted()) return;

                    final Song finalSong = loadSongMetadata(lastPath);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            if (finalSong != null && mThemeHelper != null) {
                                mCachedLastSong = finalSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(finalSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(finalSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                    if (mMusicService != null && mIsServiceBound) {
                                        mMusicService.updateMediaSessionArt(cachedArt);
                                    }
                                } else {
                                    loadAndDisplayPlaceholder();
                                    // Retry the album art load once the service
                                    // is connected (it may have the art cached
                                    // from MediaSession).
                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (isFinishing() || isDestroyed()) {
                                                return;
                                            }
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }

    /**
     * Starts MusicService with the cached last song as a temporary playlist.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) {
            return;
        }
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    /**
     * Loads all songs from library and starts MusicService.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);

        if (mMusicLibrary == null) return;

        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(currentSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(currentSong.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(currentSong.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }

    // ========================================================================
    // Theme Methods
    // ========================================================================

    /**
     * Registers restart receiver for app updates.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }

    /**
     * Registers theme change broadcast receiver.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }

    /**
     * Applies the current theme color to all UI components. Called on
     * initial layout and whenever a THEME_COLOR_CHANGED broadcast arrives.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mPlayButton != null) {
            // Auto-enable if we know songs are present but the button was
            // disabled during initial load.
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }

        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }

        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }

        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    /**
     * Performs app restart after update.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================

    /**
     * Registers all broadcast receivers for inter-component communication.
     */
    private void registerReceivers() {
        /**
         * Core playback-state receiver. Reads the full snapshot from the
         * intent and gates on generation. Stale broadcasts (lower
         * generation) are dropped.
         *
         * <p>During PREPARING the bound player is still on the outgoing
         * song while getCurrentSong() returns the destination, so the
         * receiver verifies against target_song_path in that state to
         * align with the notification and lock screen. It also prefetches
         * the target album art so the art swap and the title swap land
         * together when PLAYING fires.</p>
         */
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                // Generation gate: strictly less is stale, equal is a
                // same-generation tick (position advances) and must be
                // accepted.
                final long generation = intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) return;
                    if (generation > mLastSeenGeneration) mLastSeenGeneration = generation;
                }

                final String state = intent.getStringExtra("state");
                final String songPath = intent.getStringExtra("song_path");
                final String targetPath = intent.getStringExtra("target_song_path");
                final boolean playing = intent.getBooleanExtra("is_playing", false);
                final int positionMs = intent.getIntExtra("position_ms", 0);
                final int durationMs = intent.getIntExtra("duration_ms", 0);

                safeUpdateUI(new Runnable() {
                    @Override
                    public void run() {
                        updatePlayPauseButton();

                        if (mSeekBar != null && mSeekBar.isEnabled() && durationMs > 0) {
                            if (mSeekBar.getMax() != durationMs) mSeekBar.setMax(durationMs);
                            mSeekBar.setProgress(positionMs);
                        }

                        if (mMusicService != null && mIsServiceBound) {
                            final boolean isPreparing = "PREPARING".equals(state);
                            final String verifyPath = (isPreparing && targetPath != null) ? targetPath : songPath;
                            if (verifyPath != null) {
                                final Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && verifyPath.equals(currentSong.getPath())) {
                                    if (playing) {
                                        updateUIForPlayingSong(currentSong);
                                    } else {
                                        updateUIForSong(currentSong);
                                        if (isPreparing) {
                                            // Prefetch the target album art
                                            // so it is ready when PLAYING
                                            // fires.
                                            updateAlbumArt(currentSong.getPath());
                                        }
                                    }
                                }
                            }
                        }

                        setupSeekBar();
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            // Resume if we already have a player; otherwise
                            // play from the current index.
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };

        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        preferences.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };

        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);

                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();

                            // Optionally reset repeat/shuffle to defaults.
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }

                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }

                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };

        /**
         * FORCE_UPDATE_PLAYER is a metadata-change event (not a playback
         * state event). It carries no generation and triggers a specific
         * refresh of the named song's metadata and/or album art.
         */
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");

                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            // Replace the cached copy of the updated song in
                            // both the main list and the loose tracks.
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;

                                for (int index = 0; index < allSongs.size(); index++) {
                                    final Song existingSong = allSongs.get(index);
                                    if (existingSong != null && targetPath.equals(existingSong.getPath())) {
                                        allSongs.set(index, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }

                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int index = 0; index < looseSongs.size(); index++) {
                                            final Song existingSong = looseSongs.get(index);
                                            if (existingSong != null && targetPath.equals(existingSong.getPath())) {
                                                looseSongs.set(index, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }

                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }

                        // Album art was cleared in the metadata editor.
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                                if (mMusicService != null && mIsServiceBound) {
                                    Bitmap placeholder = null;
                                    synchronized (mPlaceholderLock) {
                                        placeholder = mPlaceholderBitmap;
                                    }
                                    mMusicService.updateMediaSessionArt(placeholder);
                                }
                            }
                        }

                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            // Refresh art for the current song if requested.
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            // Re-fetch metadata if it was just edited.
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };

        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };

        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };

        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };

        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };

        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");

                    if (songPath == null || mMusicService == null) {
                        return;
                    }

                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");

                    // Service handles the actual metadata refresh.
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);

                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                            if (mMusicService != null && mIsServiceBound) {
                                Bitmap placeholder = null;
                                synchronized (mPlaceholderLock) {
                                    placeholder = mPlaceholderBitmap;
                                }
                                mMusicService.updateMediaSessionArt(placeholder);
                            }
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            // New art: evict old, trigger reload.
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }

                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);

                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        "Playback recovered", ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    /**
     * Safely registers a broadcast receiver.
     *
     * @param receiver The receiver to register
     * @param action The intent action to listen for
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver for " + action, exception);
        }
    }

    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // Ignore
            }
        }
    }

    // ========================================================================
    // Listener Setup Methods
    // ========================================================================

    /**
     * Wires click listeners for all control buttons. Each listener applies
     * a per-button debounce (using elapsedRealtime, immune to wall-clock
     * changes) before dispatching to the service request API.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            // Cycle: 0 -> 1 -> 2 -> 0
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String message = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            // Pure setter on the service side; no history
                            // manipulation from the UI layer.
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        // Slide-down animation on the whole content view;
                        // the dialog slides up over it and the animation
                        // reverses on dismiss.
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dismissedDialog) {
                                final View contentView = findViewById(android.R.id.content);
                                contentView.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }

    // ========================================================================
    // Utility Methods
    // ========================================================================

    /**
     * Compatibility method for checking if activity is destroyed.
     *
     * @return True if activity is destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}