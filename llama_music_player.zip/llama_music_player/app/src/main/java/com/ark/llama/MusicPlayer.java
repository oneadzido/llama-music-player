package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.Manifest;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MusicPlayer - Main activity for music playback and control.
 *
 * <p>This activity is the main entry point of the Llama Music Player
 * application. It is a renderer over {@link MusicService}'s authoritative
 * playback state machine: user input is forwarded to the service, and the
 * resulting state is reflected from {@code UPDATE_PLAYER} broadcasts.</p>
 *
 * <h3>Architecture Overview</h3>
 * <p>The activity delegates all orchestration to {@link MusicService}. It
 * does not serialize user input; rapid button presses are forwarded to the
 * service, which owns the transition state. The activity's job is to
 * reflect the current state as it arrives via {@code UPDATE_PLAYER}
 * broadcasts.</p>
 *
 * <h3>Media Button Routing</h3>
 * <p>Media buttons from headsets, hardware keys, and notification action
 * buttons are routed through {@code androidx.media.session.MediaButtonReceiver}
 * and dispatched to the active {@link android.support.v4.media.session.MediaSessionCompat}
 * held by {@link MusicService}. This activity does not register a media
 * button receiver. The {@link #onKeyDown(int, KeyEvent)} override remains
 * as a fallback for hardware keys delivered to a focused activity.</p>
 *
 * <h3>Generation-Gated Broadcasts</h3>
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic {@code generation}
 * alongside the full playback snapshot. The activity tracks the highest
 * generation it has seen and drops any broadcast with a strictly lower
 * one. Equal-generation broadcasts are accepted because position and
 * duration advance within a generation. This makes out-of-order delivery
 * harmless.</p>
 *
 * <h3>Service Reconnection</h3>
 * <p>When the service is (re)bound, the high-water generation mark is reset
 * to -1: a new service instance restarts its counter at 0, and a stale high
 * mark would silently drop every broadcast from the new instance.</p>
 *
 * <h3>Playlist Refresh</h3>
 * <p>The {@code UPDATE_PLAYLIST_FROM_FOLDERS} receiver refreshes the
 * existing {@link MusicLibrary} instance synchronously before reading the
 * song list. {@link MusicLibrary#refreshCache()} reads the database on the
 * calling thread inside the library's write lock, so the returned list is
 * complete when the method returns.</p>
 *
 * <h3>Initial Load Overlay</h3>
 * <p>Cold start shows a {@code "Just a moment..."} persistent overlay,
 * mirrored to the status bar by {@link NotificationController} through
 * {@link ToastManager}. The load runs through
 * {@link MusicLibrary#loadAllSongsWithProgress}, whose progress callbacks
 * double as heartbeats that keep the persistent overlay alive past
 * {@code ToastManager}'s stuck timeout. A dedicated self-scheduling
 * heartbeat in this activity fills any gap between those callbacks so the
 * overlay cannot be flagged as stuck during a slow scan. The overlay is
 * dismissed by the load's completion or error callback, whichever fires.</p>
 *
 * <h3>Album Art</h3>
 * <p>The activity's album art loader is independent of the notification's.
 * The notification's art is produced and held by {@link MusicService};
 * this activity loads its own copy into an LRU cache and renders it in the
 * album art {@link ImageView}. Downsampling is applied via
 * {@code BitmapFactory.Options.inSampleSize} to prevent OOM on large
 * embedded images. Placeholder bitmaps are themed and regenerated whenever
 * the theme color changes.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialized by {@code mServiceLock}. UI updates go
 * through {@code safeUpdateUI} which coalesces concurrent requests. The
 * main handler is drained on {@code onDestroy} to prevent leaks.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for battery optimization. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing first run flag. */
    private static final String KEY_FIRST_RUN = "first_run";

    /** Key for storing last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action for restarting the app after update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";

    /** Broadcast action for updating sort mode from playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action for setting pending song path in MusicService. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /**
     * Operation ID for the cold-start library load overlay. Passed through
     * {@link ToastManager} to the library notification as an ownership
     * token. A dismiss with this ID is refused if another operation has
     * taken over the overlay in the interim.
     */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Message shown during cold-start library load. */
    private static final String MESSAGE_LIBRARY_LOAD = "Just a moment...";

    /**
     * Interval for the library-load heartbeat, safely below
     * {@link ToastManager}'s {@code STUCK_TIMEOUT_MS} (1000 ms) so a gap
     * between load progress callbacks cannot trip the stuck detector.
     */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500;

    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;

    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Timeout for loading overlay display in milliseconds. */
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;

    /** Delay for service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000;

    /** Delay for next/prev button updates in milliseconds. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;

    /** Delay for repeat/shuffle button updates in milliseconds. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250;

    /** Delay for playing loose tracks in milliseconds. */
    private static final long PLAY_LOOSE_TRACKS_DELAY_MS = 500;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;

    /** Delay for focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Buffer size for file copying operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 500;

    /** Duration of button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation (97% of normal size). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;

    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;

    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    // ========================================================================
    // UI Components
    // ========================================================================

    @Nullable private TextView mSongTitle;
    @Nullable private TextView mSongArtist;
    @Nullable private TextView mSeekTime;
    @Nullable private TextView mTotalTime;
    @Nullable private SeekBar mSeekBar;
    @Nullable private Button mPlayButton;
    @Nullable private Button mPrevButton;
    @Nullable private Button mNextButton;
    @Nullable private Button mRepeatButton;
    @Nullable private Button mShuffleButton;
    @Nullable private Button mManagerButton;
    @Nullable private Button mLlamaButton;
    @Nullable private Button mPlaylistButton;
    @Nullable private Button mEqualizerButton;
    @Nullable private Button mMetadataButton;
    @Nullable private ImageView mAlbumArtView;

    // ========================================================================
    // Managers and Services
    // ========================================================================

    @Nullable private MusicLibrary mMusicLibrary;
    @Nullable private MusicService mMusicService;
    @Nullable private StorageAccessHelper mStorageHelper;

    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    @NonNull private final Handler mServiceHandler = new Handler(Looper.getMainLooper());
    @Nullable private Handler mTimeHandler = null;

    private boolean mIsServiceBound = false;
    private boolean mIsUserSeeking = false;

    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    @Nullable private Runnable mPendingUIUpdate = null;
    private volatile String mPendingIncomingPath = null;
    @NonNull private final Object mServiceLock = new Object();

    private long mLastSeenGeneration = -1L;

    // ========================================================================
    // State Flags
    // ========================================================================

    private boolean mIsPostUpdateRestart = false;
    private boolean isLoadingComplete = false;

    @Nullable private Runnable mLibraryHeartbeatRunnable;

    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================

    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;

    // ========================================================================
    // Album Art Components
    // ========================================================================

    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    @NonNull private final ExecutorService mAlbumArtExecutor = Executors.newSingleThreadExecutor();
    @Nullable private Future<?> mCurrentAlbumArtFuture = null;
    @Nullable private String mCurrentLoadingArtPath = null;
    @Nullable private String mCurrentAlbumArtPath = null;

    @NonNull private final ExecutorService mMetadataLoader = Executors.newSingleThreadExecutor();
    @Nullable private Future<?> mCurrentMetadataFuture = null;

    @Nullable private Bitmap mPlaceholderBitmap = null;
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    @NonNull private final Object mPlaceholderLock = new Object();

    @Nullable private View mDimOverlay = null;
    @Nullable private ProgressBar mLoadingSpinner = null;

    @Nullable private ThemeManager mThemeManager;
    @Nullable private ThemeHelper mThemeHelper;
    @Nullable private BroadcastReceiver mThemeReceiver;

    @Nullable private StorageObserver mStorageObserver;

    @Nullable private Song mCachedLastSong = null;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mMetadataUpdatedReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;

    // ========================================================================
    // Service Connection
    // ========================================================================

    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG, "Processing pending incoming file on service connect: " + pendingPath);
                mMusicService.setPendingSongPath(pendingPath);
                sendBroadcast(new Intent("SOFT_UPDATE_PLAYLIST"));
            }

            if (mPlayButton != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, true, true);
            }

            loadFullPlaylistInBackground();
            updateRepeatButton();
            updateShuffleButton();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) return;
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow = (mMusicService != null && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);

        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();

            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(this, MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }

        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }
        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            mAlbumArtCache = null;
        }

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // Ignore
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();

        ToastManager.hidePersistentOverlay();
        hideLoadingOverlay();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", exception);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized = powerManager.isIgnoringBatteryOptimizations(getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    String message = optimized ?
                        "Background playback optimized" :
                        "Background playback restricted";
                    ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                }
            }
        }, 150);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    "Permissions required to read and play songs in background",
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                hideLoadingOverlay();
            }
        }
    }

    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================

    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        final Typeface fontAwesomeTypeface = FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================

    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 34) {
                if (checkSelfPermission("android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK");
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }

    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        if (isFirstRun) {
            applyNoSongState();

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }

        handleIncomingFile(getIntent());
    }

    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to request battery optimization", exception);
                }
            }
        }
    }

    // ========================================================================
    // Incoming File Handling
    // ========================================================================

    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }

        final String action = intent.getAction();
        if (!Intent.ACTION_VIEW.equals(action)) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        Song existingSong = SongDatabase.getInstance(this).getSong(filePath);
        if (existingSong != null) {
            Log.d(TAG, "Song already in library, playing: " + filePath);
            if (mMusicService != null && mIsServiceBound) {
                mMusicService.playSongByPath(filePath);
                updateUIForPlayingSong(existingSong);
                updateAlbumArt(filePath);
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();
            } else {
                mPendingIncomingPath = filePath;
                Log.d(TAG, "Service not ready, queued existing song: " + filePath);
            }
            return;
        }

        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (filePath.equals(looseSong.getPath())) {
                    Log.d(TAG, "Already a loose track, playing: " + filePath);
                    if (mMusicService != null && mIsServiceBound) {
                        mMusicService.playSongByPath(filePath);
                        updateUIForPlayingSong(looseSong);
                        updateAlbumArt(filePath);
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    } else {
                        mPendingIncomingPath = filePath;
                        Log.d(TAG, "Service not ready, queued loose track: " + filePath);
                    }
                    return;
                }
            }
        }

        Log.d(TAG, "New song detected, adding to library: " + filePath);

        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        final Song newSong;
        if (parsedSong == null) {
            String fileName = new File(filePath).getName();
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > 0) {
                fileName = fileName.substring(0, dotIndex);
            }
            newSong = new Song(
                fileName,
                "Unknown Artist",
                "Unknown Album",
                "Unknown Genre",
                filePath,
                0,
                null
            );
        } else {
            newSong = parsedSong;
        }

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setPendingSongPath(filePath);
            Log.d(TAG, "Pending song path set in MusicService: " + filePath);
        } else {
            mPendingIncomingPath = filePath;
            Log.d(TAG, "Service not ready, queued pending path: " + filePath);
        }

        Intent setPendingIntent = new Intent(ACTION_SET_PENDING_SONG);
        setPendingIntent.putExtra("song_path", filePath);
        sendBroadcast(setPendingIntent);

        final String finalFilePath = filePath;
        PlaylistService playlistService = PlaylistService.getInstance(this);
        playlistService.addLooseTrackAndUpdate(newSong, new PlaylistService.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track added successfully: " + finalFilePath);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mMusicService != null && mIsServiceBound) {
                            mMusicService.playPendingSongIfExists();

                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null && finalFilePath.equals(currentSong.getPath())) {
                                updateUIForPlayingSong(currentSong);
                                updateAlbumArt(currentSong.getPath());
                            }
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        } else {
                            Log.d(TAG, "Service not ready after loose track addition, will retry");
                            mPendingIncomingPath = finalFilePath;
                            if (!mIsServiceBound) {
                                Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                                startService(serviceIntent);
                                bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                            }
                        }
                    }
                }, PLAY_LOOSE_TRACKS_DELAY_MS);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Failed to add loose track: " + error);
                if (mMusicService != null) {
                    mMusicService.clearPendingSongPath();
                }
                mPendingIncomingPath = null;
                ToastManager.showToast(MusicPlayer.this,
                    "Failed to open file: " + error, ToastManager.LENGTH_NORMAL);
            }
        });
    }

    // ========================================================================
    // URI Helper Methods
    // ========================================================================

    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;

        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================

    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;

        mMusicLibrary.loadAllSongsWithProgress(new MusicLibrary.LoadProgressListener() {
            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(MESSAGE_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(@NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong != null && mSongTitle != null
                        && mSongArtist != null && mThemeHelper != null) {
                        mSongTitle.setText(currentSong.getTitle());
                        mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        mSongArtist.setText(currentSong.getArtist());
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        updateAlbumArt(currentSong.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                hideLoadingOverlay();
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                hideLoadingOverlay();
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is running. Idempotent;
     * a second call while a heartbeat is already scheduled is a no-op.
     *
     * <p>The heartbeat resets {@link ToastManager}'s stuck timer every
     * {@link #LIBRARY_HEARTBEAT_INTERVAL_MS} milliseconds, well under its
     * {@code STUCK_TIMEOUT_MS}, so the overlay cannot be flagged as stuck
     * during a slow scan or a gap between progress callbacks. The runnable
     * self-terminates once the operation ID is no longer
     * {@link #OPERATION_LIBRARY_LOAD}.</p>
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    // ========================================================================
    // UI Update Methods
    // ========================================================================

    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }

        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pendingUpdate);
                    }
                }
            }
        });
    }

    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.updateMediaSessionMetadata(finalSong, null);
                }

                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }

    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }

                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.updateMediaSessionMetadata(finalSong, null);
                }

                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }

    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }

    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }

    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }

        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }

        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }

        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    // ========================================================================
    // Playback Control Methods
    // ========================================================================

    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        safeCallService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    private void playNextSong() {
        if (mNextButton == null || !mNextButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playNextSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    private void playPreviousSong() {
        if (mPrevButton == null || !mPrevButton.isEnabled()) {
            return;
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playPreviousSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    // ========================================================================
    // Button State Update Methods
    // ========================================================================

    private void updateRepeatButton() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mRepeatButton.isEnabled();

            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);

                if (repeatMode == 2) {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                }

                mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(mRepeatButton, false, false);
            }
        }
    }

    private void updateShuffleButton() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mShuffleButton.isEnabled();

            mShuffleButton.setText(FontAwesome.SHUFFLE);

            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(mShuffleButton, false, false);
            }
        }
    }

    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                    return;
                }

                mPlayButton.setEnabled(true);

                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }

                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                        return;
                    }

                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating play/pause button", exception);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }

    // ========================================================================
    // SeekBar Methods
    // ========================================================================

    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong = service.getCurrentSong();
                        if (currentSong != null && currentSong.getDuration() > 0) {
                            duration = (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(formatTime(duration));
                        }

                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display", exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ========================================================================
    // Album Art Methods
    // ========================================================================

    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }

    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            return;
        }

        if (filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }

        mCurrentAlbumArtPath = filePath;

        if (mAlbumArtCache != null) {
            final Bitmap cachedBitmap = mAlbumArtCache.get(filePath);
            if (cachedBitmap != null) {
                applyAlbumArtWithFade(cachedBitmap);
                return;
            }
        }

        if (mCurrentAlbumArtFuture != null) {
            mCurrentAlbumArtFuture.cancel(true);
            mCurrentAlbumArtFuture = null;
        }

        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;

        mCurrentAlbumArtFuture = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                Bitmap albumArtBitmap = null;
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        albumArtBitmap = decodeSampledBitmap(artBytes,
                            MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, exception);
                } finally {
                    if (retriever != null) {
                        try {
                            retriever.release();
                        } catch (Exception exception) {
                            // Ignore
                        }
                    }
                }

                final Bitmap resultBitmap = albumArtBitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (taskPath.equals(mCurrentLoadingArtPath) && taskPath.equals(mCurrentAlbumArtPath)) {
                            if (resultBitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, resultBitmap);
                                applyAlbumArtWithFade(resultBitmap);
                                if (mMusicService != null && mIsServiceBound) {
                                    mMusicService.updateMediaSessionArt(resultBitmap);
                                }
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtFuture != null && mCurrentAlbumArtFuture.isDone()) {
                            mCurrentAlbumArtFuture = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }

    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            return;
        }

        if (isFinishing() || isDestroyed() || mAlbumArtView == null) {
            return;
        }

        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);

        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }

        applyAlbumArtClipping();
    }

    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled()
            && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }

    // ========================================================================
    // Placeholder Methods
    // ========================================================================

    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tintedBitmap = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap = BitmapFactory.decodeResource(
                            getResources(), R.drawable.album_art_placeholder, options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tintedBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null
                                || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                }
                            }
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG, "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================

    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }

    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================

    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) {
                    return;
                }

                final ViewGroup rootView = (ViewGroup) getWindow()
                    .getDecorView().findViewById(android.R.id.content);
                if (rootView == null) {
                    return;
                }

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP));
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;

                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }

    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ========================================================================
    // Initial Loading Methods
    // ========================================================================

    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong = SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null &&
            !cachedSong.getTitle().isEmpty() &&
            !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: " + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = "Unknown Artist";
            }
            if (album == null) {
                album = "Unknown Album";
            }

            String genre = "Unknown Genre";
            Song databaseSong = SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null && databaseSong.getGenre() != null &&
                !"Unknown Genre".equals(databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
                Log.d(TAG, "Found genre in database: " + genre);
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                    Log.d(TAG, "Read genre from file: " + genre);
                }
            }

            Song resultSong = new Song(title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(albumArt,
                    MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: " + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // Ignore
                }
            }
        }
    }

    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);

        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }

            if (mCurrentMetadataFuture != null) {
                mCurrentMetadataFuture.cancel(true);
            }

            mCurrentMetadataFuture = mMetadataLoader.submit(new Runnable() {
                @Override
                public void run() {
                    if (Thread.currentThread().isInterrupted()) return;

                    final Song finalSong = loadSongMetadata(lastPath);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            if (finalSong != null && mThemeHelper != null) {
                                mCachedLastSong = finalSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(finalSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(finalSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null
                                    ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                    if (mMusicService != null && mIsServiceBound) {
                                        mMusicService.updateMediaSessionArt(cachedArt);
                                    }
                                } else {
                                    loadAndDisplayPlaceholder();
                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (isFinishing() || isDestroyed()) {
                                                return;
                                            }
                                            if (mMusicService != null
                                                && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }

    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) {
            return;
        }
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);

        if (mMusicLibrary == null) return;

        mMusicLibrary.loadAllSongsWithProgress(new MusicLibrary.LoadProgressListener() {
            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(MESSAGE_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(@NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(currentSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(currentSong.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(currentSong.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                hideLoadingOverlay();
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading songs: " + error);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this,
                    "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }

    // ========================================================================
    // Theme Methods
    // ========================================================================

    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }

    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }

    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }

        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }

        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }

        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================

    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                final long generation = intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) return;
                    if (generation > mLastSeenGeneration) mLastSeenGeneration = generation;
                }

                final String state = intent.getStringExtra("state");
                final String songPath = intent.getStringExtra("song_path");
                final String targetPath = intent.getStringExtra("target_song_path");
                final boolean playing = intent.getBooleanExtra("is_playing", false);
                final int positionMs = intent.getIntExtra("position_ms", 0);
                final int durationMs = intent.getIntExtra("duration_ms", 0);

                safeUpdateUI(new Runnable() {
                    @Override
                    public void run() {
                        updatePlayPauseButton();

                        if (mSeekBar != null && mSeekBar.isEnabled() && durationMs > 0) {
                            if (mSeekBar.getMax() != durationMs) mSeekBar.setMax(durationMs);
                            mSeekBar.setProgress(positionMs);
                        }

                        if (mMusicService != null && mIsServiceBound) {
                            final boolean isPreparing = "PREPARING".equals(state);
                            final String verifyPath = (isPreparing && targetPath != null)
                                ? targetPath : songPath;
                            if (verifyPath != null) {
                                final Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && verifyPath.equals(currentSong.getPath())) {
                                    if (playing) {
                                        updateUIForPlayingSong(currentSong);
                                    } else {
                                        updateUIForSong(currentSong);
                                        if (isPreparing) {
                                            updateAlbumArt(currentSong.getPath());
                                        }
                                    }
                                }
                            }
                        }

                        setupSeekBar();
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };

        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };

        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);

                    if (mMusicService != null) {
                        // Full teardown: this broadcast is only sent after the user
                        // has removed every folder or every track, so the playlist
                        // must be cleared, not soft-stopped.
                        mMusicService.stopCompletely();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();

                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }

                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }

                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };

        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };

        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };

        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    if (mMusicLibrary == null) {
                        mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    }
                    mMusicLibrary.refreshCache();

                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    Song currentSong = (mMusicService != null)
                                        ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };

        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null)
                                        ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            mMusicLibrary.refreshCache();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"METADATA_UPDATED".equals(intent.getAction())) {
                    return;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist = intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");

                // Update the service's in-memory playlist entry and current
                // song (if applicable). Handles both the "changed song is
                // current" and "changed song is elsewhere in the playlist"
                // cases uniformly.
                mMusicService.refreshMetadataForSong(songPath, title, artist,
                    album, genre, albumArtBytes, albumArtRemoved);

                // Refresh the in-memory MusicLibrary list so subsequent reads
                // see the change. Reads the row from the database rather than
                // trusting the broadcast payload — the database is the
                // authority.
                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                // Handle the current-song case: invalidate the album art
                // cache and refresh the UI. The service has already committed
                // the playlist change above.
                final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                    if (albumArtRemoved && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        mCurrentAlbumArtPath = null;
                        loadAndDisplayPlaceholder();
                        if (mMusicService != null && mIsServiceBound) {
                            Bitmap placeholder = null;
                            synchronized (mPlaceholderLock) {
                                placeholder = mPlaceholderBitmap;
                            }
                            mMusicService.updateMediaSessionArt(placeholder);
                        }
                    } else if (hasAlbumArt && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        mCurrentAlbumArtPath = null;
                        updateAlbumArt(songPath);
                    }

                    if (mMusicService.isPlaying()) {
                        updateUIForPlayingSong(currentSong);
                    } else {
                        updateUIForSong(currentSong);
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    // Non-current song: the library list was refreshed above;
                    // no UI update is required.
                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        "Playback recovered", ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null)
                                    ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mMetadataUpdatedReceiver, "METADATA_UPDATED");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver for " + action, exception);
        }
    }

    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // Ignore
            }
        }
    }

    // ========================================================================
    // Listener Setup Methods
    // ========================================================================

    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String message = newMode == 0 ? "Repeat: OFF"
                                : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this,
                                newShuffle ? "Shuffle: ON" : "Shuffle: OFF",
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(
                            MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dismissedDialog) {
                                final View contentView = findViewById(android.R.id.content);
                                contentView.startAnimation(AnimationUtils.loadAnimation(
                                    MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }

    // ========================================================================
    // Utility Methods
    // ========================================================================

    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}