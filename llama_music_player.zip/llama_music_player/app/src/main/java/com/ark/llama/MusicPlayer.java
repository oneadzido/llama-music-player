// MusicPlayer.java
package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Renders the main playback screen and forwards user input to
 * {@link MusicService}.
 *
 * <p>The activity is a view over {@link MusicService}'s authoritative
 * playback state machine. User input is forwarded to the service, and
 * the resulting state is reflected from {@code UPDATE_PLAYER}
 * broadcasts. The activity does not own a transition state of its own;
 * the service owns every transition and the activity follows the
 * broadcasts.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The playback state machine is owned by {@link MusicService}. This
 * activity owns the render state derived from that machine: the text
 * and color of the current song's title and artist, the seek bar
 * position and duration, the enabled state of the transport controls,
 * and the album-art carousel's placeholder bitmap. Service calls are
 * serialised by {@link #mServiceLock}, and UI updates are coalesced by
 * {@link #updateUISafely(Runnable)}.</p>
 *
 * <p>The transport controls' enabled state, labels, and active tints
 * are written by {@link #refreshTransportControls()} alone. Every
 * other method in this class that wants the controls refreshed calls
 * that method; none of them sets a control's fields directly. The
 * single-writer shape is what keeps the runtime-permission gate, the
 * service-bound state, and the library contents from disagreeing
 * about whether playback is available.</p>
 *
 * <p>The album-art carousel is a pure renderer of the
 * {@link PlaybackWindow} that the service publishes on every
 * {@code UPDATE_PLAYER} broadcast, together with the transition
 * direction and the restart flag the service names alongside it.</p>
 *
 * <h3>Transport Requests</h3>
 * <p>A next or previous request from the UI is dispatched to the
 * service and answered by the service's own {@code UPDATE_PLAYER}
 * broadcast. {@link #playNextSong()} and {@link #playPreviousSong()}
 * call {@link MusicService#playNextSong()} or
 * {@link MusicService#playPreviousSong()}, which assign the target,
 * bump the transition generation, note the direction and restart for
 * that generation, and start the MediaPlayer work in the same
 * main-thread turn. The animation begins when the service's
 * committing broadcast reaches the carousel's receiver, in the same
 * turn the window is committed.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every transition the user can cause — a transport tap, a
 * committed swipe, a headset key, an automatic song change, an
 * incoming file — arrives at the activity as an {@code UPDATE_PLAYER}
 * broadcast. The receiver builds one commit runnable that writes every
 * surface the transition touches. The carousel reports through
 * {@link AlbumArtCarousel#setWindow(PlaybackWindow, int, boolean)}
 * whether the window landed synchronously. When it did, the runnable
 * runs in the receiver's own turn. When an animation is running, the
 * runnable is queued on the carousel through
 * {@link AlbumArtCarousel#postOnSettle(Runnable)} and runs on the
 * frame the strip snaps to rest. The two branches converge on the
 * same main-thread turn.</p>
 *
 * <h3>Ordering</h3>
 * <p>Media buttons from headsets, hardware keys, and notification
 * action buttons are routed through
 * {@code androidx.media.session.MediaButtonReceiver} and dispatched to
 * the active
 * {@link android.support.v4.media.session.MediaSessionCompat} held by
 * {@link MusicService}. This activity keeps a fallback
 * {@link #onKeyDown(int, KeyEvent)} for hardware keys delivered to a
 * focused activity.</p>
 *
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic
 * {@code generation} alongside the full playback snapshot and the
 * transition direction and restart of that generation. The activity
 * tracks the highest generation it has seen and drops any broadcast
 * with a strictly lower one.</p>
 *
 * <h3>Volume-Key Observation</h3>
 * <p>The activity overrides {@link #dispatchKeyEvent(KeyEvent)} to
 * observe the volume-up key before the window system consumes it.
 * The event is not consumed. In one specific case — the music volume
 * is already at the device maximum and the song is bound but paused —
 * the activity resumes the song directly, because the framework emits
 * no {@code VOLUME_CHANGED_ACTION} when no value changes.</p>
 *
 * <h3>Album-Art Gestures</h3>
 * <p>The album-art container owns every gesture that operates on the
 * album art. A single touch listener classifies each gesture on the
 * first significant move: a horizontal swipe becomes a carousel
 * swipe, a vertical swipe that starts inside the left or right edge
 * zone becomes a volume change, and a vertical swipe that starts at
 * the centre becomes a playback gesture — upward resumes a paused
 * song and downward pauses a playing one. The playback gesture
 * requires twice the touch slop of travel to distinguish an
 * intentional swipe from digitizer wobble on a resting finger.</p>
 *
 * <h3>Home Button</h3>
 * <p>The Home control is a two-tap gesture. The first tap enters
 * {@link HomeConfirmState#ARMED} and paints the button in the
 * themed active colour; a second tap within
 * {@link #HOME_CONFIRM_WINDOW_MS} enters
 * {@link HomeConfirmState#CONFIRMED}, paints the button in the
 * pending colour, and schedules the return-home for
 * {@link #HOME_CONFIRM_DWELL_MS} later. A tap on any other button
 * in either phase cancels the return and restores the Home button
 * to its steady inactive colour. The button's three colours map to
 * the three states: inactive grey for {@code IDLE}, themed for
 * {@code ARMED}, pending red for {@code CONFIRMED}.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>{@link #applyAlbumArtSize(Configuration)} decides the
 * album-art container's size and visibility from
 * {@code Configuration.screenHeightDp}.</p>
 *
 * <h3>Permissions</h3>
 * <p>The set of runtime permissions the app needs is defined once, in
 * {@link PermissionChecker}. This activity reads that set through two
 * of the checker's methods. {@link #checkPermissionsAndInitialize()}
 * asks {@link PermissionChecker#getMissing(Context)} for the array it
 * requests, {@link #onResume()} asks
 * {@link PermissionChecker#allGranted(Context)} for the yes-or-no
 * answer it acts on, and {@link #canEnableTransportControls()} asks
 * the same question as one of the three facts it combines.</p>
 *
 * <h3>Cold-Start Overlay</h3>
 * <p>The cold-start library load shows a "Just a moment..." toast and
 * a dim-and-spinner overlay under
 * {@link OverlayManager#REASON_COLD_START}.</p>
 *
 * <h3>Incoming File Requests</h3>
 * <p>An incoming file from another app is handed to the service
 * through a direct main-thread method call on the bound service
 * ({@code MusicService.requestIncomingFile(String)}) when the service
 * is bound, or parked on {@link #mPendingIncomingPath} and handed off
 * from {@link #onServiceConnected} when the bind has not yet
 * completed. No broadcast is involved, so there is no delivery
 * window in which the path could be lost.</p>
 *
 * <h3>Language Application</h3>
 * <p>The activity wraps its base context through
 * {@link LanguageManager#wrap(Context)} in
 * {@link #attachBaseContext(Context)}, so every string it resolves
 * through {@code getString} is read from the resource folder that
 * matches the selected language from the moment the activity is
 * created.</p>
 *
 * <p>A {@code LANGUAGE_CHANGED} broadcast reaches this activity when
 * the user selects a language in the picker that {@link CreditsDialog}
 * opens. The receiver answers with {@code recreate()}. The activity
 * rebuilds in the new locale on the next turn; every dialog that is
 * on screen when the broadcast fires is dismissed as part of the
 * rebuild, and the next time each dialog is opened it is constructed
 * against the new locale.</p>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible string the activity writes resolves from a
 * string resource at the point of the write. The metadata fallbacks —
 * the values the activity writes when a song has no title or artist —
 * resolve from {@link CharacterMapper}'s placeholder producers.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialised by {@link #mServiceLock}. UI updates
 * are coalesced by {@link #updateUISafely(Runnable)}. The main handler
 * is drained in {@link #onDestroy()} so no post is left after the
 * activity is gone.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see PermissionChecker
 * @see OverlayManager
 * @see AlbumArtCarousel
 * @see PlaybackWindow
 * @see NotificationController
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 * @see LanguageManager
 * @see CharacterMapper
 *
 * @author Richard Korbla Adzido
 * @version 1.4.5
 * @since 1.0.0
 */
public class MusicPlayer extends Activity
        implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for the folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for the battery optimization request. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action that restarts the app after an update. */
    private static final String ACTION_RESTART_APP =
        "com.ark.llama.RESTART_APP";

    /** Broadcast action that updates the sort mode from the playlist. */
    private static final String ACTION_UPDATE_SORT_MODE =
        "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that sets a pending song path in the service. */
    private static final String ACTION_SET_PENDING_SONG =
        "SET_PENDING_SONG";

    /** Broadcast action that asks the activity to rebuild from folders. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS =
        "UPDATE_PLAYLIST_FROM_FOLDERS";

    /**
     * Broadcast action received when the display language changes.
     *
     * <p>Sent by {@link LanguageDialog} through {@link CreditsDialog}'s
     * picker. Every activity registers a receiver for it and answers
     * with {@code recreate()}, so the wrapped base context is rebuilt
     * with the new locale on the next creation. This activity
     * recreates immediately on the broadcast's turn.</p>
     */
    private static final String ACTION_LANGUAGE_CHANGED =
        "LANGUAGE_CHANGED";

    /** Broadcast action carrying the full playback snapshot from the service. */
    private static final String ACTION_UPDATE_PLAYER = "UPDATE_PLAYER";

    /** Broadcast action asking the service to play the song at a given path. */
    private static final String ACTION_PLAY_SONG = "PLAY_SONG";

    /** Broadcast action asking the service to resume after a headset event. */
    private static final String ACTION_BLUETOOTH_PLAY = "BLUETOOTH_PLAY";

    /** Broadcast action asking the service to pause before a metadata write. */
    private static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";

    /** Broadcast action reporting a headset connection state change. */
    private static final String ACTION_BLUETOOTH_CONNECTED =
        "BLUETOOTH_CONNECTED";

    /** Broadcast action asking the service to persist its state now. */
    private static final String ACTION_SAVE_PLAYER_STATE_NOW =
        "SAVE_PLAYER_STATE_NOW";

    /** Broadcast action reporting the start of a playlist sync. */
    private static final String ACTION_SYNC_STARTED = "SYNC_STARTED";

    /** Broadcast action reporting the end of a playlist sync. */
    private static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Broadcast action announcing a change to the songs table. */
    private static final String ACTION_UPDATE_PLAYLIST = "UPDATE_PLAYLIST";

    /** Broadcast action asking consumers to refresh from the songs table. */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST =
        "SOFT_UPDATE_PLAYLIST";

    /** Broadcast action asking the playlist activity to redraw. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";

    /** Broadcast action asking the player to refresh its metadata display. */
    private static final String ACTION_FORCE_UPDATE_PLAYER =
        "FORCE_UPDATE_PLAYER";

    /** Broadcast action announcing that a song's metadata was written. */
    private static final String ACTION_METADATA_UPDATED = "METADATA_UPDATED";

    /** Broadcast action reporting that playback was recovered after a failure. */
    private static final String ACTION_PLAYBACK_RECOVERED =
        "PLAYBACK_RECOVERED";

    /** Broadcast action asking the service for its current playing state. */
    private static final String ACTION_GET_PLAYING_STATE =
        "GET_PLAYING_STATE";

    /** Broadcast action carrying the service's reply to a playing-state query. */
    private static final String ACTION_PLAYING_STATE_RESPONSE =
        "PLAYING_STATE_RESPONSE";

    /** Broadcast action announcing a theme color change. */
    private static final String ACTION_THEME_COLOR_CHANGED =
        "THEME_COLOR_CHANGED";

    /** Operation ID for the library-load overlay mirror. */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Interval for the library-load heartbeat, in milliseconds. */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500L;

    /**
     * Maximum time the library-load heartbeat runs before the load
     * is considered abandoned, in milliseconds.
     *
     * <p>The heartbeat runnable re-posts itself while the
     * {@link #OPERATION_LIBRARY_LOAD} operation is on the stack, and
     * stops after this much time has passed since the first
     * heartbeat. When it stops, {@link #abandonLibraryLoadOverlay}
     * hides the overlay and tells the user the library could not be
     * loaded.</p>
     */
    private static final long LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS =
        30000L;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /**
     * Window during which a second tap on the Home button confirms
     * the return-home gesture, in milliseconds.
     *
     * <p>The value matches {@link ToastManager#LENGTH_NORMAL}
     * so the arming toast and the confirmation window end
     * together: the toast disappearing is the user's visual signal
     * that the ARMED state has closed.</p>
     */
    private static final long HOME_CONFIRM_WINDOW_MS = 1000L;

    /**
     * Dwell on the themed CONFIRMED state before the return-home
     * fires, in milliseconds.
     *
     * <p>The user perceives three states of the Home button in the
     * two-tap gesture: the steady inactive colour, the ARMED red,
     * and the CONFIRMED themed colour. This dwell is what makes
     * the third state visible — the themed colour is shown for
     * the dwell before the task moves to the back. Half a second
     * is long enough to register as an acknowledgement and short
     * enough that the app does not feel unresponsive.</p>
     */
    private static final long HOME_CONFIRM_DWELL_MS = 500L;

    /** Delay for the service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000L;

    /** Delay before performing focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500L;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500L;

    /** Delay before updating the repeat and shuffle buttons. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250L;

    /** Buffer size for file copy operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of the button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /**
     * Width of the volume-gesture edge zone on each side of the
     * album-art container, in density-independent pixels.
     */
    private static final int VOLUME_GESTURE_EDGE_DP = 60;

    /**
     * Fraction of the device's volume range the finger must travel
     * past a limit before the volume toast echoes a second time.
     */
    private static final float VOLUME_LIMIT_ECHO_STEP_FRACTION = 0.15f;

    /** The gesture is not currently clamped to either volume limit. */
    private static final int VOLUME_LIMIT_SIDE_NONE = 0;

    /** The gesture is clamped to the device's maximum music volume. */
    private static final int VOLUME_LIMIT_SIDE_MAXIMUM = +1;

    /** The gesture is clamped to zero music volume. */
    private static final int VOLUME_LIMIT_SIDE_MINIMUM = -1;

    /**
     * Window height above which the album art is shown at its full
     * size.
     */
    private static final int SPLIT_SCREEN_FULL_HEIGHT_DP = 600;

    /**
     * Window height below which the album art is hidden entirely.
     */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    /** Album-art size at full screen, in dp. */
    private static final int ALBUM_ART_FULL_DP = 300;

    /** Album-art size in a shrunk split-screen window, in dp. */
    private static final int ALBUM_ART_SHRUNK_DP = 180;

    /**
     * Bottom padding of the transport row in split-screen mode, in dp.
     */
    private static final int TRANSPORT_ROW_SPLIT_BOTTOM_DP = 48;

    // ============================================================================
    // Message Resource Identifiers
    // ============================================================================

    /**
     * Message shown while the cold-start library load runs.
     */
    private static final int MESSAGE_LIBRARY_LOAD =
        R.string.player_library_loading;

    /**
     * Message shown when the cold-start load never completes.
     */
    private static final int MESSAGE_LIBRARY_LOAD_FAILED =
        R.string.player_library_load_failed;

    /**
     * Message shown when the service bind is refused synchronously.
     */
    private static final int MESSAGE_SERVICE_BIND_FAILED =
        R.string.player_service_bind_failed;

    // ============================================================================
    // UI Components
    // ============================================================================

    @Nullable private TextView mSongTitle;
    @Nullable private TextView mSongArtist;
    @Nullable private TextView mSeekTime;
    @Nullable private TextView mTotalTime;
    @Nullable private SeekBar mSeekBar;
    @Nullable private Button mPlayButton;
    @Nullable private Button mPrevButton;
    @Nullable private Button mNextButton;
    @Nullable private Button mRepeatButton;
    @Nullable private Button mShuffleButton;
    @Nullable private Button mManagerButton;
    @Nullable private Button mLlamaButton;
    @Nullable private Button mPlaylistButton;
    @Nullable private Button mEqualizerButton;
    @Nullable private Button mMetadataButton;
    @Nullable private Button mFavoriteButton;
    @Nullable private Button mHomeButton;
    @Nullable private FrameLayout mAlbumArtContainer;
    @Nullable private LinearLayout mAlbumArtWrapper;
    @Nullable private FrameLayout mSongInfoGroup;
    @Nullable private LinearLayout mTransportRow;

    /**
     * Per-child default {@code layout_gravity} of
     * {@link #mSongInfoGroup}'s children, captured from the layout at
     * init time.
     *
     * <p>The song-info group is a {@link FrameLayout}. Unlike a
     * {@code LinearLayout}, a FrameLayout has no gravity of its own;
     * each child carries its own {@code layout_gravity} in its
     * {@link FrameLayout.LayoutParams}. The split-mode adjustment
     * restores these values when the album art returns, so the
     * favourites heart snaps back to its declared
     * {@code end|center_vertical} position and the text column to its
     * declared {@code center_vertical} position without re-inflating
     * the layout.</p>
     */
    @Nullable private int[] mDefaultSongInfoChildGravities;

    /** Top padding of {@link #mSongInfoGroup} as declared by the layout. */
    private int mDefaultSongInfoPaddingTop = 0;

    /** Bottom padding of {@link #mTransportRow} as declared by the layout. */
    private int mDefaultTransportPaddingBottom = 0;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    @Nullable private MusicLibrary mMusicLibrary;
    @Nullable private MusicService mMusicService;
    @Nullable private StorageAccessHelper mStorageAccessHelper;
    @Nullable private NotificationController mNotificationController;

    /**
     * The pending return-home timeout.
     *
     * <p>One field carries both phases of the gesture. In
     * {@link HomeConfirmState#ARMED} the runnable ends the arming
     * window at {@link #HOME_CONFIRM_WINDOW_MS} and reverts the
     * button to its steady inactive colour. In
     * {@link HomeConfirmState#CONFIRMED} the runnable ends the
     * confirmed dwell at {@link #HOME_CONFIRM_DWELL_MS} and moves
     * the task to the back. The runnable's body branches on
     * {@link #mHomeConfirmState} to decide which phase it is
     * ending; the field itself does not need to know.</p>
     *
     * <p>{@link #cancelReturnHome()} cancels this field without
     * needing to know which phase scheduled it.</p>
     */
    @Nullable private Runnable mHomeReturnRunnable;

    @NonNull private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    @NonNull private final Handler mServiceHandler =
        new Handler(Looper.getMainLooper());

    @Nullable private Handler mTimeHandler = null;

    private boolean mIsServiceBound = false;
    private boolean mIsUserSeeking = false;

    /**
     * State of the two-tap return-home gesture.
     *
     * <p>{@link #IDLE} is the steady state. {@link #ARMED} is the
     * state after the first tap, during which a second tap
     * confirms. {@link #CONFIRMED} is the state after the second
     * tap, during which the button shows the themed colour and
     * the return-home fires at the end of
     * {@link #HOME_CONFIRM_DWELL_MS}.</p>
     *
     * <p>The enum is the single expression of the gesture's phase.
     * Every branch of the click handler and every entry point in
     * the cancel path reads it, so the button's colour, the
     * pending toast, and the pending runnable cannot disagree
     * about which phase the gesture is in.</p>
     */
    @NonNull
    private HomeConfirmState mHomeConfirmState = HomeConfirmState.IDLE;

    @NonNull private final AtomicBoolean mIsUpdatingUI =
        new AtomicBoolean(false);

    /**
     * Update queued behind the currently running one.
     *
     * <p>Written by any thread that calls
     * {@link #updateUISafely(Runnable)} while another update is in
     * flight, and read on the main thread after the running update
     * completes. {@code volatile} is required so the main thread sees
     * the most recent write: the caller writes the field after the
     * running update has already set {@code mIsUpdatingUI} to
     * {@code true}, and the main thread reads it in the
     * {@code finally} block before deciding whether to re-enter.</p>
     */
    @Nullable private volatile Runnable mPendingUIUpdate = null;

    private volatile String mPendingIncomingPath = null;

    @NonNull private final Object mServiceLock = new Object();

    private long mLastSeenGeneration = -1L;

    // ============================================================================
    // State Flags
    // ============================================================================

    private boolean mIsPostUpdateRestart = false;
    private boolean isLoadingComplete = false;
    private boolean mInitializationAttempted = false;
    private boolean mPermissionsDenied = false;
    @Nullable private Runnable mLibraryHeartbeatRunnable;

    /**
     * True when the current playback scope contains no songs.
     *
     * <p>Read by the preload path and the transport gate so the
     * player can present the no-song state without waiting for
     * a song to appear. Written only by
     * {@link #mUpdatePlayerReceiver}, which reads the
     * {@code scope_count} extra the service publishes with
     * every {@code UPDATE_PLAYER} broadcast.</p>
     *
     * <p>The library may hold songs while this flag is true —
     * the scope exists specifically to limit what can be
     * played. {@link #canEnableTransportControls()} treats the
     * scoped playlist as the source of truth, so transport is
     * disabled when the scope is empty even though the
     * database is not.</p>
     */
    private boolean mScopeEmpty = false;

    // ============================================================================
    // Click Debounce Timestamps
    // ============================================================================

    private long mLastPlayPauseClickTime = 0L;
    private long mLastNextClickTime = 0L;
    private long mLastPrevClickTime = 0L;
    private long mLastRepeatClickTime = 0L;
    private long mLastShuffleClickTime = 0L;
    private long mLastEqualizerClickTime = 0L;
    private long mLastManagerClickTime = 0L;
    private long mLastLlamaClickTime = 0L;
    private long mLastPlaylistClickTime = 0L;
    private long mLastMetadataClickTime = 0L;
    private long mLastFavoriteClickTime = 0L;
    private long mLastHomeClickTime = 0L;

    // ============================================================================
    // Album Art Components
    // ============================================================================

    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    @NonNull private final ExecutorService mAlbumArtExecutor =
        Executors.newSingleThreadExecutor();

    @NonNull private final ExecutorService mMetadataLoader =
        Executors.newSingleThreadExecutor();

    @Nullable private Future<?> mCurrentMetadataFuture = null;

    @Nullable private Bitmap mPlaceholderBitmap = null;
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    @NonNull private final ExecutorService mPlaceholderExecutor =
        Executors.newSingleThreadExecutor();

    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    @NonNull private final Object mPlaceholderLock = new Object();

    @Nullable private AlbumArtCarousel mAlbumArtCarousel;

    @Nullable private ThemeManager mThemeManager;
    @Nullable private ThemeHelper mThemeHelper;
    @Nullable private BroadcastReceiver mThemeReceiver;

    @Nullable private StorageObserver mStorageObserver;

    @Nullable private Song mCachedLastSong = null;

    /**
     * Timestamp of the last completed tap on the album-art
     * container, used to detect a double-tap. Reset to zero after a
     * favorite toggle so a third tap does not fire another toggle.
     */
    private long mLastTapTime = 0L;

    // ============================================================================
    // Gesture State
    // ============================================================================

    @Nullable private AudioManager mAudioManager;

    /**
     * Classification of the current touch on the album-art
     * container.
     *
     * <p>{@link #TOUCHED} is the resting state before a significant
     * move has been classified: a quick tap that never leaves the
     * touch-slop radius stays here from {@code ACTION_DOWN} to
     * {@code ACTION_UP}, which is what makes the double-tap favorite
     * gesture visible to the handler.</p>
     */
    private enum GestureState {
        TOUCHED,
        CAROUSEL,
        VOLUME,
        PLAYBACK,
        CANCELLED
    }

    /**
     * State of the two-tap return-home gesture.
     */
    private enum HomeConfirmState {

        /** The Home button is in its steady inactive colour. */
        IDLE,

        /**
         * The first tap has landed. The button shows the themed
         * active colour and a second tap within
         * {@link #HOME_CONFIRM_WINDOW_MS} confirms. The window is
         * bounded by {@link #mHomeReturnRunnable}.
         */
        ARMED,

        /**
         * The second tap has landed. The button shows the pending
         * colour. The return-home fires at the end of
         * {@link #HOME_CONFIRM_DWELL_MS}, bounded by
         * {@link #mHomeReturnRunnable}. Any user-initiated
         * transition through another button cancels this state
         * and returns the button to {@link #IDLE}.
         */
        CONFIRMED
    }

    @NonNull private GestureState mGestureState = GestureState.TOUCHED;

    private float mGestureStartX = 0f;
    private float mGestureStartY = 0f;
    private int mGestureContainerWidth = 1;
    private int mGestureContainerHeight = 1;
    private int mVolumeGestureStartVolume = 0;
    private int mVolumeGestureMaxVolume = 0;
    private int mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
    private float mVolumeGestureLimitEchoBaseline = Float.NaN;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mLibraryResetReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mMetadataUpdatedReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mLanguageChangedReceiver;

    // ============================================================================
    // Service Connection
    // ============================================================================

    @NonNull
    private final ServiceConnection mServiceConnection =
            new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG,
                    "Handing off parked incoming path: " + pendingPath);
                handOffIncomingPath(pendingPath);
            }

            refreshTransportControls();

            loadFullPlaylistInBackground();
            refreshCarouselFromService();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }
                    if (canEnableTransportControls()) {
                        refreshTransportControls();
                        refreshCarouselFromService();
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing()
                            && !isDestroyed()) {
                        Log.d(TAG,
                            "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(
                            MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection,
                            BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    /**
     * Wraps the base context with the currently selected locale.
     *
     * <p>The wrap is performed before any activity state is created,
     * so every string resolved through {@code getString} during the
     * activity's lifetime is read from the resource folder that
     * matches the selected language. Changing the selection recreates
     * the activity, at which point this method runs again with the
     * new locale already persisted.</p>
     *
     * @param newBase Base context supplied by the framework
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase));
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, the view hierarchy, the receivers,
     * and the service binding, and starts the permission check.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);
        OverlayManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        mAlbumArtCache =
            AlbumArtCache.getInstance(this).asLruCache();

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageAccessHelper = StorageAccessHelper.getInstance(this);
        mNotificationController =
            NotificationController.getInstance(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        mIsPostUpdateRestart = getIntent()
            .getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Registers the theme receiver if it is not already registered.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onStop() {
        super.onStop();
        cancelReturnHome();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the playback display from the service, reapplies the theme,
     * and drives the permission and initialization gates.
     *
     * <p>This method is the single owner of "has initialization run."
     * The permission outcome recorded by
     * {@link #onRequestPermissionsResult(int, String[], int[])} is
     * read here and turned into one of three actions: run the
     * initialization flow, apply the empty state, or do nothing.</p>
     *
     * <p>Two flags decide the branch:
     * {@link #mInitializationAttempted}, which is set the first time
     * the flow is entered and prevents re-entry, and
     * {@link #mPermissionsDenied}, which latches when the permissions
     * are first missing and clears when they are restored.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        final boolean permissionsGranted =
            PermissionChecker.allGranted(this);

        if (permissionsGranted && mMusicService != null
                && mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0) {
            refreshTransportControls();
            refreshCarouselFromService();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(
                this,
                getString(MESSAGE_LIBRARY_LOAD),
                "",
                OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();

        if (!permissionsGranted) {
            if (!mPermissionsDenied) {
                mPermissionsDenied = true;
                applyNoSongState();
            }
            return;
        }

        if (mPermissionsDenied) {
            mPermissionsDenied = false;
            if (mInitializationAttempted) {
                // The permission was restored after the app had
                // already been running. The library's in-memory
                // state is stale against the filesystem, and the
                // service (if bound) holds a playlist that cannot
                // be played. Reset both so the initialization flow
                // runs again from a clean slate.
                mInitializationAttempted = false;
                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }
            }
        }

        if (!mInitializationAttempted) {
            proceedWithInitialization();
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Releases every resource held by the activity.
     *
     * <p>Does not tear down any persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; this
     * activity may be destroying itself while {@link FolderManager}
     * still owns the {@code "FOLDER_SYNC"} overlay or
     * {@link PlaylistManager} still owns the
     * {@code "GENRE_UPDATE"} or {@code "LIBRARY_RESET"} overlays.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null
                && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }
        if (mCurrentPlaceholderTask != null) {
            mCurrentPlaceholderTask.cancel(true);
            mCurrentPlaceholderTask = null;
        }
        if (!mPlaceholderExecutor.isShutdown()) {
            mPlaceholderExecutor.shutdownNow();
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.clear();
            mAlbumArtCarousel = null;
        }

        mAlbumArtCache = null;

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mLanguageChangedReceiver);

        cancelReturnHome();

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();
    }

    /**
     * Forwards the trim-memory signal to the bound service when one
     * is available, and evicts the album art cache under sustained
     * pressure.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG,
                    "Failed to forward onTrimMemory to service",
                    exception);
            }
        }
        if (level >= TRIM_MEMORY_BACKGROUND && mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
    }

    /**
     * Updates the intent and either closes the app or processes a
     * new incoming file.
     *
     * @param intent The new intent delivered to the activity
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Applies the album-art size and visibility for the new window
     * height.
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applyAlbumArtSize(config);
    }

    /**
     * Intercepts the volume-up key before the window handles it.
     *
     * @param event The key event delivered to the activity
     * @return Whatever {@code super.dispatchKeyEvent} returns
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            resumeIfPausedAtMaxVolume();
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * Handles media keys delivered to a focused activity.
     *
     * @param keyCode Code of the pressed key
     * @param event Full key event
     * @return True when the key was consumed
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Resumes playback when the volume is already at the device
     * maximum and the user pressed volume up while a song was bound
     * but paused.
     */
    private void resumeIfPausedAtMaxVolume() {
        if (mAudioManager == null
                || mMusicService == null
                || !mIsServiceBound) {
            return;
        }
        try {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume <= 0) {
                return;
            }
            final int currentVolume = mAudioManager.getStreamVolume(
                AudioManager.STREAM_MUSIC);
            if (currentVolume < maxVolume) {
                return;
            }
            if (!mMusicService.isPausedOrReady()) {
                return;
            }
            mMusicService.resume();
        } catch (Exception exception) {
            Log.w(TAG,
                "Failed to resume on volume-up at max", exception);
        }
    }

    /**
     * Handles the folder selection result and the battery
     * optimization result.
     *
     * @param requestCode The request code passed to the launcher
     * @param resultCode The result code returned by the target
     *        activity
     * @param data The intent carrying the result, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE
                && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageAccessHelper != null) {
                final String folderPath =
                    mStorageAccessHelper.getFolderPathFromUri(treeUri);
                mStorageAccessHelper.storeFolderPermission(
                    treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName =
                    mStorageAccessHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this,
                    getString(R.string.folder_manager_imported_toast,
                        folderName),
                    ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager =
                    (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized =
                        powerManager.isIgnoringBatteryOptimizations(
                            getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows a battery optimization result toast after a short delay.
     *
     * @param optimized True when the app is exempt from battery
     *        optimizations
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    final int messageRes = optimized
                        ? R.string.player_battery_optimized
                        : R.string.player_battery_restricted;
                    ToastManager.showToast(MusicPlayer.this,
                        getString(messageRes),
                        ToastManager.LENGTH_NORMAL);
                }
            }
        }, 150);
    }

    /**
     * Handles the runtime permission result.
     *
     * <p>The result is recorded, not acted on. A grant clears the
     * permission-blocked latch and lets the next resume advance the
     * initialization flow. A denial shows the reason as a short toast
     * and applies the empty state.</p>
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions,
            grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult
                        != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                mPermissionsDenied = false;
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    getString(R.string.player_permissions_required),
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                mPermissionsDenied = true;
                applyNoSongState();
            }
        }
    }

    // ============================================================================
    // NavigationController Listener Implementation
    // ============================================================================

    /**
     * Enables or disables the playlist and metadata buttons
     * according to the current database-actions state.
     *
     * @param group Button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(
            NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches typefaces and touch animations,
     * constructs the album-art carousel with its swipe commit
     * listener, and primes the initial control state.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mFavoriteButton = (Button) findViewById(R.id.favoriteButton);
        mHomeButton = (Button) findViewById(R.id.homeButton);
        mAlbumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        mAlbumArtWrapper =
            (LinearLayout) findViewById(R.id.albumArtWrapper);
        mSongInfoGroup =
            (FrameLayout) findViewById(R.id.songInfoGroup);
        mTransportRow =
            (LinearLayout) findViewById(R.id.transportRow);

        if (mSongInfoGroup != null) {
            mDefaultSongInfoPaddingTop =
                mSongInfoGroup.getPaddingTop();

            final int childCount = mSongInfoGroup.getChildCount();
            mDefaultSongInfoChildGravities = new int[childCount];
            for (int i = 0; i < childCount; i++) {
                final View child = mSongInfoGroup.getChildAt(i);
                if (child.getLayoutParams()
                        instanceof FrameLayout.LayoutParams) {
                    mDefaultSongInfoChildGravities[i] =
                        ((FrameLayout.LayoutParams) child.getLayoutParams())
                            .gravity;
                } else {
                    mDefaultSongInfoChildGravities[i] =
                        Gravity.CENTER_VERTICAL;
                }
            }
        }

        if (mTransportRow != null) {
            mDefaultTransportPaddingBottom =
                mTransportRow.getPaddingBottom();
        }

        if (mAlbumArtContainer != null && mAlbumArtCache != null) {
            mAlbumArtCarousel = new AlbumArtCarousel(
                this, mAlbumArtContainer, mAlbumArtCache,
                mAlbumArtExecutor);
            mAlbumArtCarousel.setEdgeZonePx(
                dpToPx(VOLUME_GESTURE_EDGE_DP));
            mAlbumArtCarousel.setSwipeCommitListener(direction -> {
                if (direction > 0) {
                    playNextSong();
                } else if (direction < 0) {
                    playPreviousSong();
                }
            });
            mAlbumArtCarousel.attach();
        }

        applyAlbumArtClipping();
        setupAlbumArtGestures();

        final Typeface fontAwesomeTypeface =
            FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }
        if (mFavoriteButton != null) {
            mFavoriteButton.setTypeface(fontAwesomeTypeface);
            mFavoriteButton.setText(FontAwesome.HEART);
            mFavoriteButton.setTextSize(30);
            if (mThemeHelper != null) {
                mThemeHelper.updateControlButton(mFavoriteButton, true, false);
            }
        }
        if (mHomeButton != null) {
            mHomeButton.setTypeface(fontAwesomeTypeface);
            mHomeButton.setText(FontAwesome.HOME);
            mHomeButton.setTextSize(28);
            if (mThemeHelper != null) {
                mThemeHelper.updateControlButton(mHomeButton, true, false);
            }
        }

        if (mPlayButton != null) {
            mPlayButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mPrevButton != null) {
            mPrevButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mNextButton != null) {
            mNextButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }

        if (mManagerButton != null) {
            mManagerButton.setLetterSpacing(0.1f);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setLetterSpacing(0.1f);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setLetterSpacing(0.1f);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setLetterSpacing(0.1f);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setLetterSpacing(0.1f);
        }

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);
        animateButton(mFavoriteButton);
        animateButton(mHomeButton);

        applyAlbumArtSize(getResources().getConfiguration());

        loadAndDisplayPlaceholder();
        refreshTransportControls();
    }

    /**
     * Refreshes the carousel's window from the bound service.
     */
    private void refreshCarouselFromService() {
        if (mMusicService == null || mAlbumArtCarousel == null) {
            return;
        }
        mAlbumArtCarousel.setWindow(
            mMusicService.getWindowSnapshot(), 0, false);
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN)
                            .scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL)
                            .scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Split-Screen Layout
    // ============================================================================

    /**
     * Applies the album-art size and visibility for the current
     * window height.
     *
     * @param config Configuration carrying the current window height
     */
    private void applyAlbumArtSize(@NonNull Configuration config) {
        if (mAlbumArtContainer == null) {
            return;
        }

        final int heightDp = config.screenHeightDp;
        final int sizeDp;
        final int visibility;

        if (heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP) {
            sizeDp = ALBUM_ART_FULL_DP;
            visibility = View.VISIBLE;
        } else if (heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP) {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.VISIBLE;
        } else {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.GONE;
        }

        final int sizePx = dpToPx(sizeDp);
        final ViewGroup.LayoutParams params =
            mAlbumArtContainer.getLayoutParams();
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx;
            params.height = sizePx;
            mAlbumArtContainer.setLayoutParams(params);
        }
        if (mAlbumArtContainer.getVisibility() != visibility) {
            mAlbumArtContainer.setVisibility(visibility);
        }

        applySongInfoLayout(visibility == View.GONE);

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.onContainerResized();
        }
    }

    /**
     * Positions the title-and-artist group and the transport row for
     * the current album-art visibility.
     *
     * <p>The song-info group is a {@link FrameLayout}. A FrameLayout
     * has no gravity of its own; each child carries its own
     * {@code layout_gravity} in its {@link FrameLayout.LayoutParams}.
     * When the album art is hidden, each child's {@code layout_gravity}
     * has its vertical component replaced with {@code TOP}, so both
     * the text column and the favourites heart move up together. The
     * horizontal component of each child's declared gravity is
     * preserved, so the text column keeps its centred horizontal
     * position and the heart stays at the trailing edge. When the
     * album art is visible, each child's {@code layout_gravity} is
     * restored to the value captured from the layout at init time.</p>
     *
     * @param albumArtHidden True when the album art is
     *        {@link View#GONE}
     */
    private void applySongInfoLayout(boolean albumArtHidden) {
        if (mAlbumArtWrapper != null) {
            final int wrapperVisibility =
                albumArtHidden ? View.GONE : View.VISIBLE;
            if (mAlbumArtWrapper.getVisibility()
                    != wrapperVisibility) {
                mAlbumArtWrapper.setVisibility(wrapperVisibility);
            }
        }

        if (mSongInfoGroup != null) {
            final int albumArtTopOffset =
                (mAlbumArtWrapper != null)
                    ? mAlbumArtWrapper.getPaddingTop()
                    : 0;
            final int desiredTopPadding = albumArtHidden
                ? albumArtTopOffset
                : mDefaultSongInfoPaddingTop;
            if (mSongInfoGroup.getPaddingTop()
                    != desiredTopPadding) {
                mSongInfoGroup.setPadding(
                    mSongInfoGroup.getPaddingLeft(),
                    desiredTopPadding,
                    mSongInfoGroup.getPaddingRight(),
                    mSongInfoGroup.getPaddingBottom());
            }

            if (mDefaultSongInfoChildGravities != null) {
                final int horizontalMask =
                    Gravity.LEFT | Gravity.RIGHT
                        | Gravity.START | Gravity.END
                        | Gravity.CENTER_HORIZONTAL;

                final int childCount = mSongInfoGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    final View child = mSongInfoGroup.getChildAt(i);
                    if (!(child.getLayoutParams()
                            instanceof FrameLayout.LayoutParams)) {
                        continue;
                    }
                    final FrameLayout.LayoutParams params =
                        (FrameLayout.LayoutParams)
                            child.getLayoutParams();
                    final int defaultGravity =
                        (i < mDefaultSongInfoChildGravities.length)
                            ? mDefaultSongInfoChildGravities[i]
                            : Gravity.CENTER_VERTICAL;
                    final int targetGravity;
                    if (albumArtHidden) {
                        targetGravity =
                            (defaultGravity & horizontalMask)
                                | Gravity.TOP;
                    } else {
                        targetGravity = defaultGravity;
                    }
                    if (params.gravity != targetGravity) {
                        params.gravity = targetGravity;
                        child.setLayoutParams(params);
                    }
                }
            }
        }

        if (mTransportRow != null) {
            final int desiredBottomPadding = albumArtHidden
                ? dpToPx(TRANSPORT_ROW_SPLIT_BOTTOM_DP)
                : mDefaultTransportPaddingBottom;
            if (mTransportRow.getPaddingBottom()
                    != desiredBottomPadding) {
                mTransportRow.setPadding(
                    mTransportRow.getPaddingLeft(),
                    mTransportRow.getPaddingTop(),
                    mTransportRow.getPaddingRight(),
                    desiredBottomPadding);
            }
        }
    }

    // ============================================================================
    // Album-Art Gestures
    // ============================================================================

    /**
     * Attaches the gesture listener to the album-art container.
     */
    private void setupAlbumArtGestures() {
        if (mAlbumArtContainer == null) {
            return;
        }
        mAlbumArtContainer.setOnTouchListener(
            new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                return handleAlbumArtGesture(view, event);
            }
        });
    }

    /**
     * Dispatches a touch event on the album-art container through
     * the gesture classifier and the selected mode's handler.
     *
     * @param view Album-art container
     * @param event Touch event
     * @return True when the gesture is being consumed
     */
    private boolean handleAlbumArtGesture(@NonNull View view,
                                          @NonNull MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return handleGestureDown(view, event);
            case MotionEvent.ACTION_MOVE:
                return handleGestureMove(view, event);
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return handleGestureUp(view, event);
            default:
                return false;
        }
    }

    /**
     * Handles the start of a touch sequence on the album-art
     * container.
     *
     * <p>The mode resets to {@link GestureState#TOUCHED}, which is
     * both the "no significant move yet" state and the state from
     * which a double-tap favorite is detected on
     * {@code ACTION_UP}.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_DOWN} event
     * @return Always true; the sequence is consumed from this point
     */
    private boolean handleGestureDown(@NonNull View view,
                                      @NonNull MotionEvent event) {
        mGestureState = GestureState.TOUCHED;
        mGestureStartX = event.getX();
        mGestureStartY = event.getY();
        mGestureContainerWidth = Math.max(1, view.getWidth());
        mGestureContainerHeight = Math.max(1, view.getHeight());

        if (mAudioManager != null) {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume > 0) {
                mVolumeGestureMaxVolume = maxVolume;
                mVolumeGestureStartVolume =
                    mAudioManager.getStreamVolume(
                        AudioManager.STREAM_MUSIC);
            } else {
                mVolumeGestureMaxVolume = 0;
                mVolumeGestureStartVolume = 0;
            }
        } else {
            mVolumeGestureMaxVolume = 0;
            mVolumeGestureStartVolume = 0;
        }

        mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
        mVolumeGestureLimitEchoBaseline = Float.NaN;

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    /**
     * Handles a move event on the album-art container, classifying
     * the gesture on the first significant move and then dispatching
     * to the selected mode's handler.
     *
     * @param view Album-art container
     * @param event {@code ACTION_MOVE} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureMove(@NonNull View view,
                                      @NonNull MotionEvent event) {
        if (mGestureState == GestureState.TOUCHED) {
            classifyGesture(event);
        }

        switch (mGestureState) {
            case CAROUSEL:
                if (mAlbumArtCarousel != null) {
                    final float horizontalDisplacement =
                        event.getX() - mGestureStartX;
                    mAlbumArtCarousel.updateSwipe(
                        horizontalDisplacement);
                }
                return true;
            case VOLUME:
                handleVolumeDrag(event);
                return true;
            case PLAYBACK:
                return true;
            case CANCELLED:
            case TOUCHED:
            default:
                return true;
        }
    }

    /**
     * Handles the release of a touch sequence on the album-art
     * container, committing the carousel swipe when it passed its
     * threshold, applying the playback gesture, resolving a
     * double-tap into a favorite toggle, and releasing the parent's
     * touch interception.
     *
     * <p>An {@code ACTION_CANCEL} releases the carousel with a
     * displacement of zero, so the strip returns to rest rather than
     * committing a swipe the user did not complete. The cancel
     * carries a position where the touch was taken away, which is
     * not the displacement the user meant to gesture. For the same
     * reason a cancelled playback gesture is not applied: the user
     * did not complete it.</p>
     *
     * <p>The double-tap check runs only when the mode is still
     * {@link GestureState#TOUCHED} on {@code ACTION_UP}. That mode
     * is never reached after a swipe, a volume drag, or a playback
     * swipe, because each classifies on the first significant move.
     * A single tap records its timestamp; two taps within
     * {@link android.view.ViewConfiguration#getDoubleTapTimeout()}
     * fire {@link #handleGestureDoubleTap()} and reset the
     * timestamp to zero so a third tap starts a fresh pair.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_UP} or {@code ACTION_CANCEL} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureUp(@NonNull View view,
                                    @NonNull MotionEvent event) {
        if (mGestureState == GestureState.CAROUSEL
                && mAlbumArtCarousel != null) {
            final float horizontalDisplacement =
                (event.getActionMasked() == MotionEvent.ACTION_CANCEL)
                    ? 0f
                    : event.getX() - mGestureStartX;
            mAlbumArtCarousel.endSwipe(horizontalDisplacement);
            cancelReturnHome();
        } else if (mGestureState == GestureState.PLAYBACK
                && event.getActionMasked() == MotionEvent.ACTION_UP) {
            handlePlaybackGesture(event.getY() - mGestureStartY);
        } else if (mGestureState == GestureState.TOUCHED
                && event.getActionMasked() == MotionEvent.ACTION_UP) {
            final long tapTime = event.getEventTime();
            if (tapTime - mLastTapTime
                    <= ViewConfiguration.getDoubleTapTimeout()) {
                handleGestureDoubleTap();
                mLastTapTime = 0L;
            } else {
                mLastTapTime = tapTime;
            }
        }

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }

        mGestureState = GestureState.TOUCHED;
        return true;
    }

    /**
     * Handles a double-tap on the album-art container by toggling
     * the current song's favorite flag and showing the
     * corresponding toast.
     *
     * <p>The toggle is delegated to
     * {@link MusicService#toggleFavorite()}, which owns the flag and
     * the commit. The activity shows the confirmation toast so the
     * message reads the same whether the change came from the
     * transport heart, the album-art double-tap, or the playlist
     * row's heart (that last one shows no toast by design — a batched
     * edit is its own feedback).</p>
     */
    private void handleGestureDoubleTap() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            final Song current = mMusicService.getCurrentSong();
            if (current == null) {
                return;
            }
            final boolean newFavorite = !current.isFavorite();
            mMusicService.toggleFavorite();
            ToastManager.showToast(MusicPlayer.this,
                getString(newFavorite
                    ? R.string.player_toast_favorite_on
                    : R.string.player_toast_favorite_off),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Classifies a gesture on the first significant move.
     *
     * <p>Under the touch-slop radius, the mode stays
     * {@link GestureState#TOUCHED}; the gesture has not yet committed
     * to a direction and the double-tap detector must still be able
     * to observe it. Once slop is crossed, the horizontal-dominant
     * gesture becomes a carousel swipe, a vertical gesture that
     * started in the edge zone becomes a volume drag (or
     * {@link GestureState#CANCELLED} on a device that reports no
     * music stream), and a vertical gesture that started in the
     * centre becomes a playback gesture.</p>
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void classifyGesture(@NonNull MotionEvent event) {
        final float horizontalDisplacement =
            event.getX() - mGestureStartX;
        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float absoluteHorizontal =
            Math.abs(horizontalDisplacement);
        final float absoluteVertical =
            Math.abs(verticalDisplacement);
        final int touchSlop = ViewConfiguration.get(this)
            .getScaledTouchSlop();

        if (absoluteHorizontal < touchSlop
                && absoluteVertical < touchSlop) {
            return;
        }

        if (absoluteHorizontal > absoluteVertical) {
            mGestureState = GestureState.CAROUSEL;
            if (mAlbumArtCarousel != null) {
                mAlbumArtCarousel.beginSwipe();
            }
            return;
        }

        final int edgeZone = dpToPx(VOLUME_GESTURE_EDGE_DP);
        final boolean startedInEdge =
            mGestureStartX <= edgeZone
                || mGestureStartX >= mGestureContainerWidth - edgeZone;
        if (startedInEdge) {
            mGestureState = (mVolumeGestureMaxVolume > 0)
                ? GestureState.VOLUME
                : GestureState.CANCELLED;
            return;
        }

        mGestureState = GestureState.PLAYBACK;
    }

    /**
     * Applies a vertical drag to the music stream volume.
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void handleVolumeDrag(@NonNull MotionEvent event) {
        if (mAudioManager == null || mVolumeGestureMaxVolume <= 0) {
            return;
        }

        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float fraction =
            -verticalDisplacement / mGestureContainerHeight;
        final float unclampedTarget = mVolumeGestureStartVolume
            + fraction * mVolumeGestureMaxVolume;
        int targetVolume = Math.round(unclampedTarget);
        targetVolume = Math.max(0,
            Math.min(mVolumeGestureMaxVolume, targetVolume));

        final int currentVolume = mAudioManager.getStreamVolume(
            AudioManager.STREAM_MUSIC);

        if (targetVolume == mVolumeGestureMaxVolume) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MAXIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MAXIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else if (targetVolume == 0) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MINIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MINIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else {
            mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
            mVolumeGestureLimitEchoBaseline = Float.NaN;
        }

        if (targetVolume != currentVolume) {
            try {
                mAudioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC, targetVolume, 0);
                showVolumeToast(targetVolume);
            } catch (SecurityException exception) {
                Log.w(TAG, "setStreamVolume refused", exception);
            }
            if (targetVolume == mVolumeGestureMaxVolume) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f,
                        unclampedTarget - mVolumeGestureMaxVolume);
            } else if (targetVolume == 0) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f, -unclampedTarget);
            }
            return;
        }

        final float echoStep = Math.max(1f,
            mVolumeGestureMaxVolume * VOLUME_LIMIT_ECHO_STEP_FRACTION);

        if (targetVolume == mVolumeGestureMaxVolume
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MAXIMUM) {
            final float overshoot =
                unclampedTarget - mVolumeGestureMaxVolume;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        } else if (targetVolume == 0
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MINIMUM) {
            final float overshoot = -unclampedTarget;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        }
    }

    /**
     * Applies a completed centre-vertical swipe to the playback
     * state.
     *
     * <p>An upward swipe resumes a paused song; a downward swipe
     * pauses a playing song. The displacement is signed: upward is
     * negative, downward is positive. The action is one-shot and
     * silent when the song is already in the target state — a
     * swipe up on a playing song is a no-op, and so is a swipe
     * down on a paused one. The decision is read from the service's
     * own state, so a swipe cannot put the service into a state it
     * did not already have.</p>
     *
     * <p>The threshold is twice the touch slop. Classification
     * fires at one slop, but a stationary finger on a capacitive
     * digitizer wobbles roughly a slop on its own; acting on any
     * classified playback swipe would let a resting finger toggle
     * playback. The second slop is the noise floor above that
     * wobble. It is not a commitment threshold — a deliberate
     * swipe moves many multiples of it, so the filter never costs
     * a real gesture.</p>
     *
     * <p>The upward branch resumes a paused or ready song through
     * {@link MusicService#resume()}. Whether the resume is
     * audible is the service's decision: the service raises the
     * music stream to an audible level when it is at zero, as
     * part of the same main-thread turn that starts the player,
     * so the gesture's contract is "resume the song" and the
     * audible outcome is the service's. The gesture does not
     * read or write the stream volume.</p>
     *
     * <p>The downward branch pauses a playing song. It does not
     * touch the volume; a downward swipe at a non-zero volume
     * keeps the volume where the user set it, and a downward
     * swipe at zero finds the service already paused by the
     * volume rule.</p>
     *
     * @param verticalDisplacement Signed vertical displacement of
     *        the touch, in pixels; negative for upward
     */
    private void handlePlaybackGesture(float verticalDisplacement) {
        final int threshold = ViewConfiguration.get(this)
            .getScaledTouchSlop() * 2;
        if (Math.abs(verticalDisplacement) < threshold) {
            return;
        }

        cancelReturnHome();

        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            try {
                if (verticalDisplacement < 0) {
                    if (!mMusicService.isPlaying()
                            && mMusicService.isPausedOrReady()) {
                        mMusicService.resume();
                    }
                } else {
                    if (mMusicService.isPlaying()) {
                        mMusicService.togglePlayPause();
                    }
                }
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to handle playback gesture", exception);
            }
        }
    }

    /**
     * Shows a transient toast reporting the current volume as a
     * percentage.
     *
     * @param volumeLevel Current stream volume
     */
    private void showVolumeToast(int volumeLevel) {
        if (mVolumeGestureMaxVolume <= 0) {
            return;
        }
        final int percent = Math.round(
            100f * volumeLevel / mVolumeGestureMaxVolume);
        ToastManager.showToast(this,
            getString(R.string.player_toast_volume, percent),
            ToastManager.LENGTH_NORMAL);
    }

    // ============================================================================
    // Permission and Initialization Methods
    // ============================================================================

    /**
     * Requests the runtime permissions the app needs and proceeds
     * with initialization once they have been decided.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            proceedWithInitialization();
            return;
        }

        final String[] permissionsToRequest =
            PermissionChecker.getMissing(this);

        if (permissionsToRequest.length > 0) {
            requestPermissions(
                permissionsToRequest, PERMISSION_REQUEST_CODE);
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Runs the initialization path once permissions have been
     * decided.
     */
    private void proceedWithInitialization() {
        mInitializationAttempted = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        preloadLastSongDisplay();

        if (mMusicService != null && mIsServiceBound) {
            loadFullPlaylistInBackground();
            handleIncomingFile(getIntent());
            return;
        }

        final Intent serviceIntent = new Intent(
            MusicPlayer.this, MusicService.class);
        startService(serviceIntent);

        final boolean bound = bindService(
            serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        if (!bound) {
            Log.e(TAG, "bindService refused; abandoning library load");
            abandonLibraryLoadOverlay(MESSAGE_SERVICE_BIND_FAILED);
            return;
        }

        handleIncomingFile(getIntent());
    }

    /**
     * Requests an exemption from battery optimizations when the app
     * is not yet exempt.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager =
                (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null
                    && !powerManager.isIgnoringBatteryOptimizations(
                        getPackageName())) {
                try {
                    Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(
                        Uri.parse("package:" + getPackageName()));
                    startActivityForResult(
                        intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG,
                        "Failed to request battery optimization",
                        exception);
                }
            }
        }
    }

    // ============================================================================
    // Incoming File Handling
    // ============================================================================

    /**
     * Handles an incoming audio file reference.
     *
     * @param intent The intent that triggered the activity, or null
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        if (isSongInLibrary(filePath)) {
            Log.d(TAG, "Song is already in the library");
            handOffIncomingPath(filePath);
            return;
        }

        Log.d(TAG, "New song detected; adding as a loose track");

        handOffIncomingPath(filePath);

        preDecodeIncomingArt(filePath);

        final Song newSong = parseIncomingSong(filePath);
        insertLooseTrackAndHandOff(newSong);
    }

    /**
     * Returns whether the given path is already known to the library.
     *
     * @param filePath Absolute path of the file
     * @return True when the path is already in the library
     */
    private boolean isSongInLibrary(@NonNull String filePath) {
        if (SongDatabase.getInstance(this).hasSong(filePath)) {
            return true;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (looseSong != null
                        && filePath.equals(looseSong.getPath())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Parses the metadata for an incoming file, falling back to the
     * file name when {@link CharacterMapper} cannot read the embedded
     * tags.
     *
     * @param filePath Absolute path of the file
     * @return The parsed song; never null
     */
    @NonNull
    private Song parseIncomingSong(@NonNull String filePath) {
        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        if (parsedSong != null) {
            return parsedSong;
        }
        String fileName = new File(filePath).getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            fileName = fileName.substring(0, dotIndex);
        }
        return new Song(
            fileName,
            null,
            null,
            null,
            filePath,
            0,
            null);
    }

    /**
     * Inserts the given song as a loose track and hands the path to
     * the service once the insertion completes.
     *
     * <p>If the insert fails, the pending path is cleared from the
     * service through
     * {@link MusicService#clearPendingSongPath()}, so a later
     * reconcile cannot resolve to a path that was never added to the
     * playlist.</p>
     *
     * @param newSong The song to insert
     */
    private void insertLooseTrackAndHandOff(
            @NonNull final Song newSong) {
        final String filePath = newSong.getPath();

        PlaylistManager.getInstance(this).addLooseTrackAndUpdate(
            newSong,
            new PlaylistManager.UpdateCallback() {

            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track inserted: " + filePath);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG,
                    "Failed to insert loose track: " + error);
                mPendingIncomingPath = null;
                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.clearPendingSongPath();
                }
                ToastManager.showToast(MusicPlayer.this,
                    getString(R.string.folder_manager_error, error),
                    ToastManager.LENGTH_NORMAL);
            }
        });
    }

    /**
     * Hands the given path to the service as the target of the next
     * transition.
     *
     * <p>When the service is bound, the path is handed off through a
     * direct main-thread method call on the service. The call is
     * synchronous: the service stores the path and, if the playlist
     * already contains it, asks the state machine to transition to
     * it on the same turn. No broadcast is involved, so there is no
     * delivery window in which the path could be lost.</p>
     *
     * <p>When the service is not yet bound — the bootstrap case,
     * before {@link #onCreate(Bundle)} has finished binding — the
     * path is parked on {@link #mPendingIncomingPath} and handed off
     * from {@link #onServiceConnected} once the bind completes. The
     * parked path is not cleared here; it is cleared only after the
     * handoff has been made, which keeps the two code paths from
     * clearing each other's work.</p>
     *
     * @param filePath Absolute path of the file
     */
    private void handOffIncomingPath(@NonNull String filePath) {
        Log.d(TAG, "Handing off incoming path: " + filePath);

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.requestIncomingFile(filePath);
            return;
        }

        mPendingIncomingPath = filePath;
    }

    /**
     * Decodes the given file's embedded art on the metadata loader
     * and hands the bitmap to the carousel when it resolves.
     *
     * @param filePath Absolute path of the incoming file
     */
    private void preDecodeIncomingArt(@NonNull final String filePath) {
        if (mMetadataLoader == null || mMetadataLoader.isShutdown()) {
            return;
        }
        mMetadataLoader.execute(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                loadSongMetadata(filePath);

                final Bitmap decoded = (mAlbumArtCache != null)
                    ? mAlbumArtCache.get(filePath)
                    : null;
                if (decoded == null || decoded.isRecycled()) {
                    return;
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.onArtReady(
                                filePath, decoded);
                        }
                    }
                });
            }
        });
    }

    // ============================================================================
    // URI Helper Methods
    // ============================================================================

    /**
     * Resolves the filesystem path of the given content URI, copying
     * the content to a temporary file when the media store path is
     * not available.
     *
     * <p>The media store query can return no rows — the provider may
     * not expose a {@code DATA} column, or the URI may come from a
     * provider that does not implement the media store schema. The
     * copy fallback is therefore reached both when the query raises
     * and when it returns an empty cursor. Without the empty-cursor
     * path the file would be silently dropped.</p>
     *
     * @param uri Content URI to resolve
     * @return The filesystem path, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if (!"content".equals(uri.getScheme())) {
            return null;
        }

        String path = null;
        Cursor cursor = null;
        try {
            final String[] projection = {
                android.provider.MediaStore.Audio.Media.DATA
            };
            cursor = getContentResolver().query(uri, projection,
                null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int columnIndex =
                    cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Audio.Media
                            .DATA);
                path = cursor.getString(columnIndex);
            }
        } catch (Exception exception) {
            Log.w(TAG,
                "MediaStore query failed; falling back to copy",
                exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        if (path == null) {
            path = copyContentUriToTempFile(uri);
        }
        return path;
    }

    /**
     * Copies the content of the given URI to a temporary cache file.
     *
     * @param uri Content URI to copy
     * @return The path of the temporary file, or null on failure
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream =
                getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_"
                    + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream =
                new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies
     * inside the given folder.
     *
     * @param folderUri Folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageAccessHelper == null) {
            return;
        }

        final String folderPath =
            mStorageAccessHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this)
                    .removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ============================================================================
    // Playlist Loading Methods
    // ============================================================================

    /**
     * Loads the full playlist on a background thread and hands it
     * to the bound service when the load completes.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) {
            return;
        }

        OverlayManager.show(OverlayManager.REASON_COLD_START);

        mMusicLibrary.loadAllSongsWithProgress(
            new MusicLibrary.LoadProgressListener() {

            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(
                        getString(MESSAGE_LIBRARY_LOAD),
                        "",
                        OPERATION_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(
                    @NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                }
                refreshCarouselFromService();
                refreshTransportControls();
                setupSeekBar();
                updateTimeDisplay();

                if (songs.isEmpty()
                        && mMusicLibrary != null
                        && !mMusicLibrary.getSelectedFolders().isEmpty()
                        && !isFinishing()
                        && !isDestroyed()) {
                    triggerAutomaticFolderUpdate();
                    return;
                }

                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Runs the folder-update scan automatically when the cold-start
     * load returns no songs but folders are configured.
     */
    private void triggerAutomaticFolderUpdate() {
        PlaylistManager.getInstance(this).updatePlaylist(
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Automatic folder update complete: "
                    + songCount + " songs");
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                sendBroadcast(new Intent(
                    ACTION_UPDATE_PLAYLIST_FROM_FOLDERS));
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Automatic folder update failed: "
                    + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is scheduled. A
     * second call while a heartbeat is already scheduled does
     * nothing.
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        final long startedAt = SystemClock.elapsedRealtime();
        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                if (SystemClock.elapsedRealtime() - startedAt
                        > LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS) {
                    Log.w(TAG,
                        "Library load heartbeat deadline exceeded; "
                            + "abandoning overlay");
                    mLibraryHeartbeatRunnable = null;
                    abandonLibraryLoadOverlay(
                        MESSAGE_LIBRARY_LOAD_FAILED);
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(
                    this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(
            mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    /**
     * Abandons the library-load overlay and tells the user the
     * library could not be loaded.
     *
     * @param messageRes String resource identifier for the failure
     *        toast
     */
    private void abandonLibraryLoadOverlay(int messageRes) {
        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
        OverlayManager.hide(OverlayManager.REASON_COLD_START);
        if (!isFinishing() && !isDestroyed()) {
            ToastManager.showToast(this,
                getString(messageRes),
                ToastManager.LENGTH_NORMAL);
        }
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Runs the given UI update on the main thread, coalescing
     * requests that arrive while another update is in flight.
     *
     * <p>The claim on the update slot is a
     * {@link AtomicBoolean#compareAndSet(boolean, boolean)} rather
     * than a read-then-write. Two callers on different threads that
     * both read {@code false} would otherwise both proceed to post,
     * and the update would run twice. The slot is claimed once, and
     * the losing caller queues its update in
     * {@link #mPendingUIUpdate}, which the winning caller drains in
     * its {@code finally} block.</p>
     *
     * <p>{@link #mPendingUIUpdate} is {@code volatile}: the caller
     * writes it after the running update has already set the slot to
     * {@code true}, and the main thread reads it in the
     * {@code finally} block. Without the visibility guarantee the
     * main thread could read a stale null and the queued update
     * would be lost.</p>
     *
     * @param update The update to run
     */
    private void updateUISafely(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (!mIsUpdatingUI.compareAndSet(false, true)) {
            mPendingUIUpdate = update;
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate =
                            mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        updateUISafely(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Writes the given song's title and artist to the UI.
     *
     * @param song Song to display, or null
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle
                        : CharacterMapper.getUnknownTitle());
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText
                        : CharacterMapper.getUnknownArtist());
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshTransportControls();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Writes the given playing song's title and artist to the UI
     * and refreshes the album art.
     *
     * @param song Song that started playing, or null
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle
                        : CharacterMapper.getUnknownTitle());
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText
                        : CharacterMapper.getUnknownArtist());
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshCarouselFromService();
                refreshTransportControls();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Shows the empty state: placeholder title, placeholder artist,
     * placeholder album art, and disabled transport controls.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText(R.string.player_placeholder_title);
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText(R.string.player_placeholder_artist);
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.setWindow(PlaybackWindow.EMPTY, 0, false);
        }

        if (mAlbumArtContainer != null) {
            if (mPlaceholderBitmap != null
                    && !mPlaceholderBitmap.isRecycled()) {
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.setPlaceholder(
                        mPlaceholderBitmap);
                }
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
        }

        applyAlbumArtClipping();

        if (mSeekBar != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
        }

        refreshTransportControls();

        if (mSeekTime != null) {
            mSeekTime.setText(R.string.player_time_zero);
        }
        if (mTotalTime != null) {
            mTotalTime.setText(R.string.player_time_zero);
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent(ACTION_UPDATE_PLAYER);
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the
     * editor knows it. When the editor only knows the URI — a
     * SAF-only write where the content provider does not expose a
     * filesystem path — the path is resolved against the song
     * database by URI match. Both forms name the same song; the
     * resolution keeps consumers that key by path working on
     * paths.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }

    // ============================================================================
    // Playback Control Methods
    // ============================================================================

    /**
     * Runs the given service action on the main thread while holding
     * the service lock, when the service is bound.
     *
     * @param action The service action to run
     */
    private void callServiceSafely(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays the song at the given index and updates the UI.
     *
     * @param index Index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0
            && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles playback through the service when the library contains
     * songs.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null
                && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        callServiceSafely(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    /**
     * Asks the service to advance.
     */
    private void playNextSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playNextSong();
        }
    }

    /**
     * Asks the service to go back.
     */
    private void playPreviousSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playPreviousSong();
        }
    }

    // ============================================================================
    // Button State Update Methods
    // ============================================================================

    /**
     * Returns whether the transport controls may be enabled.
     *
     * <p>Four facts compose the answer: the runtime permissions
     * the app needs are granted, the service is bound, the
     * service has a playlist, and that playlist is non-empty.
     * The last check is the scope-aware one — when the active
     * scope yields no songs, the service's current playlist is
     * empty even though the database is not, and the transport
     * is disabled, matching the no-song state the player
     * shows.</p>
     *
     * @return True when the transport controls may be enabled
     */
    private boolean canEnableTransportControls() {
        return PermissionChecker.allGranted(this)
            && mMusicService != null
            && mIsServiceBound
            && mMusicService.getCurrentPlaylist() != null
            && !mMusicService.getCurrentPlaylist().isEmpty();
    }

    /**
     * Writes every transport control's enabled state, label, and
     * active tint from the current playback facts.
     *
     * <p>The favorite button's active state follows the current
     * song's favorite flag. Because the flag lives on the song and
     * the song lives on the service, the button reads its state
     * through the same service call the other controls use, and the
     * commit on the service's side reaches the button through the
     * {@code UPDATE_PLAYER} broadcast.</p>
     */
    private void refreshTransportControls() {
        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                boolean canEnable = canEnableTransportControls();
                boolean isPlaying = false;
                boolean isShuffleOn = false;
                boolean isFavorite = false;
                int repeatMode = 0;

                if (canEnable && mMusicService != null) {
                    try {
                        isPlaying =
                            mMusicService.getCurrentSong() != null
                                && mMusicService.isPlaying();
                        repeatMode = mMusicService.getRepeatMode();
                        isShuffleOn = mMusicService.isShuffle();
                        Song currentSong = mMusicService.getCurrentSong();
                        isFavorite = currentSong != null
                            && currentSong.isFavorite();
                    } catch (Exception exception) {
                        Log.e(TAG,
                            "Error reading playback state", exception);
                        canEnable = false;
                    }
                }

                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setText(isPlaying
                        ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mPlayButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mPlayButton, canEnable, canEnable);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mPrevButton, canEnable, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mNextButton, canEnable, false);
                }
                if (mRepeatButton != null && mThemeHelper != null) {
                    mRepeatButton.setText(repeatMode == 2
                        ? FontAwesome.REPEAT_ONE : FontAwesome.REPEAT);
                    mRepeatButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mRepeatButton, canEnable, repeatMode != 0);
                }
                if (mShuffleButton != null && mThemeHelper != null) {
                    mShuffleButton.setText(FontAwesome.SHUFFLE);
                    mShuffleButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mShuffleButton, canEnable, isShuffleOn);
                }
                if (mFavoriteButton != null && mThemeHelper != null) {
                    mFavoriteButton.setText(FontAwesome.HEART);
                    mFavoriteButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mFavoriteButton, canEnable, isFavorite);
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(canEnable);
                    mThemeHelper.updateSeekBar(mSeekBar, canEnable);
                }
            }
        });
    }

    // ============================================================================
    // Seek Bar Methods
    // ============================================================================

    /**
     * Attaches the seek-bar change listener.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser && mMusicService != null
                        && seekBar.isEnabled()
                        && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts the periodic time-display update runnable.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mAlbumArtCarousel != null
                        && mAlbumArtCarousel.isAnimating()) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition =
                        service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong =
                            service.getCurrentSong();
                        if (currentSong != null
                                && currentSong.getDuration() > 0) {
                            duration =
                                (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(
                                formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(
                                formatTime(duration));
                        }

                        if (mSeekBar != null
                                && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display",
                        exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(
                        this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Returns the given duration formatted as {@code mm:ss} or
     * {@code hh:mm:ss}.
     *
     * @param milliseconds Duration in milliseconds
     * @return The formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d",
                hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ============================================================================
    // Album Art Methods
    // ============================================================================

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested size.
     *
     * @param options Options whose bounds have been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateInSampleSize(
            @NonNull BitmapFactory.Options options,
            int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes the given image bytes with downsampling to the
     * requested size.
     *
     * @param data Image bytes to decode
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth,
                                       int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(
            data, 0, data.length, options);

        options.inSampleSize =
            calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, options);
    }

    /**
     * Returns the path of the current song, or null when no song is
     * playing.
     *
     * @return The current song's path, or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null
                && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Loads and displays the current themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    // ============================================================================
    // Placeholder Methods
    // ============================================================================

    /**
     * Rebuilds the themed placeholder bitmap from the source image
     * and applies the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task =
            mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null
                                && !mOriginalPlaceholderBitmap
                                    .isRecycled()) {
                            tintedBitmap =
                                mOriginalPlaceholderBitmap.copy(
                                    Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options =
                            new BitmapFactory.Options();
                        options.inPreferredConfig =
                            Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap =
                            BitmapFactory.decodeResource(
                                getResources(),
                                R.drawable.album_art_placeholder,
                                options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null
                                        && !mOriginalPlaceholderBitmap
                                            .isRecycled()) {
                                    mOriginalPlaceholderBitmap
                                        .recycle();
                                }
                                mOriginalPlaceholderBitmap =
                                    tintedBitmap.copy(
                                        Bitmap.Config.ARGB_8888,
                                        true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(
                        themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null
                                        && !mPlaceholderBitmap
                                            .isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            if (mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.setPlaceholder(
                                    mPlaceholderBitmap);
                            }
                            applyAlbumArtClipping();
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG,
                        "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cancels any in-flight placeholder render task and recycles
     * the placeholder bitmaps.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            recycleBitmapSafely(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            recycleBitmapSafely(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Recycles the given bitmap, ignoring any exception.
     *
     * @param bitmap Bitmap to recycle, or null
     */
    private void recycleBitmapSafely(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ============================================================================
    // Album Art Clipping Methods
    // ============================================================================

    /**
     * Applies rounded-corner clipping and the container background
     * to the album art container.
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(
                new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(
                        View view,
                        android.graphics.Outline outline) {
                    final int radius =
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0,
                        view.getWidth(), view.getHeight(), radius);
                }
            });
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        } else {
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        }
    }

    // ============================================================================
    // Navigation Methods
    // ============================================================================

    /**
     * Opens the folder manager activity with the slide-left
     * transition.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the playlist activity with the slide-right transition.
     */
    private void openPlaylist() {
        final Intent intent =
            new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the metadata editor for the current song, or in the
     * awaiting state when no song is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent =
            new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path",
                currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra(
                    "song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Cancels the pending return-home gesture and restores the
     * Home button to its steady inactive state. Idempotent.
     *
     * <p>The gesture has two phases — the ARMED phase, bounded by
     * {@link #HOME_CONFIRM_WINDOW_MS}, and the CONFIRMED phase,
     * bounded by {@link #HOME_CONFIRM_DWELL_MS} — and both are
     * carried by {@link #mHomeReturnRunnable}. This method cancels
     * whichever phase is pending, resets the state to
     * {@link HomeConfirmState#IDLE}, and repaints the button in
     * its steady inactive colour.</p>
     *
     * <p>The Home button is an action, not a mode indicator, so
     * its steady state is the inactive control-button colour —
     * the same colour every transport control uses when it is
     * enabled but not expressing an active mode. The themed
     * colour appears only in the CONFIRMED state, as a momentary
     * acknowledgement that the second tap landed.</p>
     */
    private void cancelReturnHome() {
        mHomeConfirmState = HomeConfirmState.IDLE;
        mLastHomeClickTime = 0L;
        if (mHomeReturnRunnable != null) {
            mMainHandler.removeCallbacks(mHomeReturnRunnable);
            mHomeReturnRunnable = null;
        }
        if (mThemeHelper != null && mHomeButton != null) {
            mThemeHelper.updateControlButton(
                mHomeButton, true, false);
        }
    }

    /**
     * Enters the ARMED phase of the return-home gesture: repaints
     * the Home button in the themed colour, shows the arming
     * toast, and schedules the phase's expiry on
     * {@link #mHomeReturnRunnable}.
     *
     * <p>The runnable's body checks the current phase before
     * acting. A tap that has already superseded this arming (a
     * second tap entering CONFIRMED, or any other button running
     * {@link #cancelReturnHome()}) has cleared the field, so a
     * stray post is the only way this body can run under a
     * different phase; the check rejects that case cleanly.</p>
     *
     * @param tapTime Timestamp of the arming tap, in
     *        {@link SystemClock#elapsedRealtime()} milliseconds
     */
    private void enterArmedState(long tapTime) {
        mHomeConfirmState = HomeConfirmState.ARMED;
        mLastHomeClickTime = tapTime;

        if (mThemeHelper != null) {
            mThemeHelper.updateControlButton(
                mHomeButton, true, true);
        }

        ToastManager.showToast(this,
            getString(R.string.player_return_home),
            ToastManager.LENGTH_NORMAL);

        mHomeReturnRunnable = new Runnable() {
            @Override
            public void run() {
                mHomeReturnRunnable = null;
                if (mHomeConfirmState != HomeConfirmState.ARMED) {
                    return;
                }
                mHomeConfirmState = HomeConfirmState.IDLE;
                mLastHomeClickTime = 0L;
                if (mThemeHelper != null && mHomeButton != null) {
                    mThemeHelper.updateControlButton(
                        mHomeButton, true, false);
                }
            }
        };
        mMainHandler.postDelayed(
            mHomeReturnRunnable, HOME_CONFIRM_WINDOW_MS);
    }

    /**
     * Enters the CONFIRMED phase of the return-home gesture:
     * repaints the Home button in the pending colour, dismisses
     * any persistent overlay, and schedules the return-home on
     * {@link #mHomeReturnRunnable}.
     *
     * <p>{@link #moveTaskToBack(boolean)} is the mechanism the
     * framework's own back-at-root gesture uses. It asks the
     * ActivityManager to move this task behind the next one in
     * the stack, which brings whatever the user was doing before
     * the player forward. It does not depend on resolving a home
     * intent, and the visible result is the same whether the
     * home screen, the lock screen, or another app's task
     * receives the foreground.</p>
     */
    private void enterConfirmedState() {
        mHomeConfirmState = HomeConfirmState.CONFIRMED;

        ToastManager.hidePersistentOverlay();

        if (mThemeHelper != null) {
            mThemeHelper.updateButtonPendingState(
                mHomeButton, true, Color.parseColor("#E53935"));
        }

        mHomeReturnRunnable = new Runnable() {
            @Override
            public void run() {
                mHomeReturnRunnable = null;
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                if (mHomeConfirmState
                        != HomeConfirmState.CONFIRMED) {
                    return;
                }
                moveTaskToBack(true);
                mHomeConfirmState = HomeConfirmState.IDLE;
            }
        };
        mMainHandler.postDelayed(
            mHomeReturnRunnable, HOME_CONFIRM_DWELL_MS);
    }

    /**
     * Returns the current song from the service, or null when the
     * service is not bound.
     *
     * @return The current song, or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ============================================================================
    // Cold-Start Preload
    // ============================================================================

    /**
     * Paints the previous song's title, artist, and art before the
     * playlist loads.
     */
    private void preloadLastSongDisplay() {
        final SharedPreferences preferences = getSharedPreferences(
            PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(
            KEY_LAST_SONG_PATH, null);

        if (lastPath == null || !new File(lastPath).exists()) {
            applyNoSongState();
            return;
        }

        if (mSongTitle != null) {
            mSongTitle.setText(R.string.player_placeholder_title);
        }
        if (mSongArtist != null) {
            mSongArtist.setText(R.string.player_placeholder_artist);
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
        }

        mCurrentMetadataFuture =
            mMetadataLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                final Song loadedSong = loadSongMetadata(lastPath);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mScopeEmpty) {
                            return;
                        }
                        if (loadedSong != null
                                && mThemeHelper != null) {
                            mCachedLastSong = loadedSong;
                            if (mSongTitle != null) {
                                mSongTitle.setText(
                                    loadedSong.getTitle());
                                mSongTitle.setTextColor(
                                    mThemeHelper
                                        .getThemeColorInt());
                            }
                            if (mSongArtist != null) {
                                mSongArtist.setText(
                                    loadedSong.getArtist());
                                mSongArtist.setTextColor(
                                    Color.parseColor("#C0C0C0"));
                            }

                            final Bitmap cachedArt =
                                mAlbumArtCache != null
                                    ? mAlbumArtCache.get(lastPath)
                                    : null;
                            if (cachedArt != null
                                    && mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.onArtReady(
                                    lastPath, cachedArt);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                        } else {
                            applyNoSongState();
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the metadata for the given path from the database when
     * a usable cached entry exists, and from the file otherwise.
     *
     * @param lastPath Absolute path of the song
     * @return The song, or null when the file cannot be read
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong =
            SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null
                && !cachedSong.getTitle().isEmpty()
                && !CharacterMapper.isUnknownTitle(
                    cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: "
                + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = CharacterMapper.getUnknownArtist();
            }
            if (album == null) {
                album = CharacterMapper.getUnknownAlbum();
            }

            String genre = CharacterMapper.getUnknownGenre();
            Song databaseSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null
                    && databaseSong.getGenre() != null
                    && !CharacterMapper.isUnknownGenre(
                        databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
            } else {
                String fileGenre =
                    CharacterMapper.getGenre(lastPath);
                if (fileGenre != null
                        && !CharacterMapper.isUnknownGenre(fileGenre)) {
                    genre = fileGenre;
                }
            }

            Song resultSong = new Song(
                title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(
                    albumArt, MAX_ALBUM_ART_SIZE_PX,
                    MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: "
                + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Registers the receiver for app-restart broadcasts.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        ContextCompat.registerReceiver(
            this, mRestartReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(
                        intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter =
            new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Applies the current theme color to every control in the
     * activity and rebuilds the placeholder bitmap.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed()
                || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        OverlayManager.setColor(mThemeHelper.getThemeColorInt());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(
                mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(
                mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(
                mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(
                mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(
                mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mHomeButton != null) {
            if (mHomeConfirmState == HomeConfirmState.ARMED) {
                mThemeHelper.updateControlButton(
                    mHomeButton, true, true);
            } else if (mHomeConfirmState
                    == HomeConfirmState.CONFIRMED) {
                mThemeHelper.updateButtonPendingState(
                    mHomeButton, true,
                    Color.parseColor("#E53935"));
            } else {
                mThemeHelper.updateControlButton(
                    mHomeButton, true, false);
            }
        }

        refreshTransportControls();

        if (mSongTitle != null) {
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    /**
     * Restarts the activity with the no-animation flag.
     */
    private void performUpdate() {
        final Intent restartIntent =
            new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_UPDATE_PLAYER.equals(
                            intent.getAction())) {
                    return;
                }

                // The service publishes the active scope's size
                // with every UPDATE_PLAYER broadcast. A zero
                // means the scope yields no songs, which is a
                // distinct state from "no library" — the
                // library may be full. The player must show the
                // no-song state whenever the scope is empty,
                // and the transport stays disabled until the
                // scope yields songs again.
                final int scopedSongCount =
                    intent.getIntExtra("scope_count", -1);
                if (scopedSongCount == 0) {
                    if (!mScopeEmpty) {
                        mScopeEmpty = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                applyNoSongState();
                            }
                        });
                    }
                    return;
                } else if (scopedSongCount > 0) {
                    mScopeEmpty = false;
                }

                final long generation =
                    intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    if (generation > mLastSeenGeneration) {
                        mLastSeenGeneration = generation;
                    }
                }

                final String displayTitle =
                    intent.getStringExtra("display_title");
                final String displayArtist =
                    intent.getStringExtra("display_artist");
                final int positionMs =
                    intent.getIntExtra("position_ms", 0);
                final int durationMs =
                    intent.getIntExtra("duration_ms", 0);
                final int transitionDirection =
                    intent.getIntExtra("transition_direction", 0);
                final boolean transitionRestart =
                    intent.getBooleanExtra("transition_restart", false);

                final PlaybackWindow windowSnapshot =
                    new PlaybackWindow(
                        intent.getStringExtra(
                            "window_previous_path"),
                        intent.getStringExtra(
                            "window_current_path"),
                        intent.getStringExtra(
                            "window_next_path"),
                        generation);

                updateUISafely(new Runnable() {
                    @Override
                    public void run() {
                        if (mAlbumArtCarousel == null) {
                            return;
                        }

                        final boolean committedSynchronously =
                            mAlbumArtCarousel.setWindow(
                                windowSnapshot,
                                transitionDirection,
                                transitionRestart);

                        final int finalPositionMs = positionMs;
                        final int finalDurationMs = durationMs;
                        final String finalTitle = displayTitle;
                        final String finalArtist = displayArtist;

                        final Runnable commit = new Runnable() {
                            @Override
                            public void run() {
                                if (isFinishing() || isDestroyed()) {
                                    return;
                                }

                                if (mNotificationController != null) {
                                    mNotificationController
                                        .commitNow();
                                }

                                refreshTransportControls();

                                if (mSeekBar != null
                                        && mSeekBar.isEnabled()
                                        && finalDurationMs > 0) {
                                    if (mSeekBar.getMax()
                                            != finalDurationMs) {
                                        mSeekBar.setMax(
                                            finalDurationMs);
                                    }
                                    mSeekBar.setProgress(
                                        finalPositionMs);
                                }

                                if (mSongTitle != null
                                        && finalTitle != null) {
                                    mSongTitle.setText(finalTitle);
                                    if (mThemeHelper != null) {
                                        mSongTitle.setTextColor(
                                            mThemeHelper
                                                .getThemeColorInt());
                                    }
                                }
                                if (mSongArtist != null
                                        && finalArtist != null) {
                                    mSongArtist.setText(finalArtist);
                                    mSongArtist.setTextColor(
                                        Color.parseColor(
                                            "#C0C0C0"));
                                }

                                setupSeekBar();
                            }
                        };

                        if (committedSynchronously) {
                            commit.run();
                        } else {
                            mAlbumArtCarousel.postOnSettle(commit);
                        }
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_PLAY_SONG.equals(intent.getAction())) {
                    final String songPath =
                        intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_BLUETOOTH_PLAY.equals(
                            intent.getAction())) {
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        final int currentIndex =
                            mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0
                                && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    refreshTransportControls();
                }
            }
        };

        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET
                            .equals(intent.getAction())) {
                    return;
                }

                final boolean preserveSettings =
                    intent.getBooleanExtra(
                        PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);

                mPendingIncomingPath = null;
                mIsUserSeeking = false;
                mLastSeenGeneration = -1L;

                if (mCurrentMetadataFuture != null) {
                    mCurrentMetadataFuture.cancel(true);
                    mCurrentMetadataFuture = null;
                }

                mCachedLastSong = null;

                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();

                        if (!preserveSettings
                                && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }

                        refreshTransportControls();
                    }
                });
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_SAVE_PLAYER_STATE_NOW.equals(
                            intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_BLUETOOTH_CONNECTED.equals(
                            intent.getAction())) {
                    final boolean connected =
                        intent.getBooleanExtra(
                            "connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(
                            connected);
                    }
                }
            }
        };

        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_SYNC_STARTED.equals(intent.getAction())) {
                    return;
                }
                final String action =
                    intent.getStringExtra("custom_text");
                final String detail =
                    intent.getStringExtra("custom_detail");
                final String operationId =
                    intent.getStringExtra("operation_id");
                if (action == null) {
                    return;
                }
                final String nonNullDetail =
                    detail != null ? detail : "";
                final String overlayText = nonNullDetail.isEmpty()
                    ? action
                    : action + " \u00B7 " + nonNullDetail;

                if (ToastManager.hasPersistentToast()) {
                    final String currentOwner =
                        ToastManager.getCurrentOperationId();
                    if (currentOwner != null) {
                        ToastManager.updatePersistentOverlay(
                            overlayText,
                            nonNullDetail,
                            currentOwner);
                    }
                    return;
                }

                if (operationId == null || operationId.isEmpty()) {
                    Log.w(TAG,
                        "SYNC_STARTED without operation_id; ignoring");
                    return;
                }
                ToastManager.showPersistentOverlay(
                    MusicPlayer.this,
                    overlayText,
                    nonNullDetail,
                    operationId);
            }
        };

        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_SYNC_COMPLETE.equals(intent.getAction())) {
                    return;
                }
                Log.d(TAG, "SYNC_COMPLETE received");
            }
        };

        mUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_UPDATE_PLAYLIST.equals(
                            intent.getAction())) {
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (allSongs != null
                                && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(
                                allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    refreshTransportControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                }
                            });
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            mMusicLibrary.refreshCache();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager
                                        .hidePersistentOverlay();
                                }
                            });
                        }
                    }
                }
            }
        };

        mUpdatePlaylistFromFoldersReceiver =
            new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_UPDATE_PLAYLIST_FROM_FOLDERS.equals(
                            intent.getAction())) {
                    return;
                }
                if (mMusicLibrary == null) {
                    mMusicLibrary =
                        new MusicLibrary(MusicPlayer.this);
                }

                final MusicLibrary library = mMusicLibrary;
                final MusicService service = mMusicService;

                mMetadataLoader.execute(new Runnable() {
                    @Override
                    public void run() {
                        library.refreshCache();
                        final ArrayList<Song> allSongs =
                            library.getAllSongs();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()
                                        && service != null) {
                                    if (!allSongs.isEmpty()) {
                                        service.setPlaylist(
                                            allSongs, true);
                                        refreshTransportControls();
                                        setupSeekBar();
                                        updateTimeDisplay();
                                    } else {
                                        service.setPlaylist(
                                            null, false);
                                        applyNoSongState();
                                    }
                                    sendBroadcast(new Intent(
                                        ACTION_DISPLAY_PLAYLIST));
                                }

                                sendBroadcast(new Intent(
                                    PlaylistManager
                                        .ACTION_TRIGGER_GENRE_LOADING));
                            }
                        });
                    }
                });
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist = intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final String uriString =
                    intent.getStringExtra("song_uri");
                final boolean hasAlbumArt =
                    intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved =
                    intent.getBooleanExtra(
                        "album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                // The service updates every playlist entry with
                // this path, evicts and repopulates the shared
                // album-art cache, and broadcasts UPDATE_PLAYER.
                mMusicService.refreshMetadataForSong(
                    songPath, title, artist, album, genre,
                    uriString, albumArtBytes, albumArtRemoved);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                // Invalidate the carousel's per-path cache so a
                // neighbour slot showing the edited song resolves
                // fresh art on its next re-render.
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.invalidatePath(songPath);
                }

                // If the edited song is not current, the UI does
                // not need to change here — a different song is on
                // screen. Ask the playlist to redraw the edited
                // row.
                final Song currentSong =
                    mMusicService.getCurrentSong();
                final boolean editedIsCurrent = currentSong != null
                    && songPath.equals(currentSong.getPath());
                if (!editedIsCurrent) {
                    sendBroadcast(
                        new Intent(ACTION_DISPLAY_PLAYLIST));
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYBACK_RECOVERED.equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        getString(R.string.player_playback_recovered),
                        ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(
                        intent.getAction())) {
                    final int newSortMode =
                        intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong =
                                    (mMusicService != null)
                                        ? mMusicService
                                            .getCurrentSong()
                                        : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                                refreshCarouselFromService();
                            }
                        });
                        Log.d(TAG,
                            "Sort mode update received, refreshed UI: "
                                + newSortMode);
                    }
                }
            }
        };

        mLanguageChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_LANGUAGE_CHANGED.equals(
                            intent.getAction())) {
                    return;
                }
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                recreate();
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver,
            new IntentFilter(ACTION_UPDATE_PLAYER));
        registerReceiverSafely(mPlaySongReceiver,
            new IntentFilter(ACTION_PLAY_SONG));
        registerReceiverSafely(mBluetoothPlayReceiver,
            new IntentFilter(ACTION_BLUETOOTH_PLAY));
        registerReceiverSafely(mLibraryResetReceiver,
            new IntentFilter(PlaylistManager.ACTION_LIBRARY_RESET));
        registerReceiverSafely(mSavePlayerStateNowReceiver,
            new IntentFilter(ACTION_SAVE_PLAYER_STATE_NOW));
        registerReceiverSafely(mBluetoothConnectionReceiver,
            new IntentFilter(ACTION_BLUETOOTH_CONNECTED));
        registerReceiverSafely(mSyncStartedReceiver,
            new IntentFilter(ACTION_SYNC_STARTED));
        registerReceiverSafely(mSyncCompleteReceiver,
            new IntentFilter(ACTION_SYNC_COMPLETE));
        registerReceiverSafely(mUpdatePlaylistReceiver,
            new IntentFilter(ACTION_UPDATE_PLAYLIST));
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver,
            new IntentFilter(ACTION_UPDATE_PLAYLIST_FROM_FOLDERS));
        registerReceiverSafely(mMetadataUpdatedReceiver,
            new IntentFilter(ACTION_METADATA_UPDATED));
        registerReceiverSafely(mPlaybackRecoveryReceiver,
            new IntentFilter(ACTION_PLAYBACK_RECOVERED));
        registerReceiverSafely(mSortModeReceiver,
            new IntentFilter(ACTION_UPDATE_SORT_MODE));
        registerReceiverSafely(mLanguageChangedReceiver,
            new IntentFilter(ACTION_LANGUAGE_CHANGED));
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG,
                "Failed to register receiver",
                exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every button click listener used by the activity,
     * each guarded by a debounce.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null
                                && mRepeatButton.isEnabled()) {
                            final int newMode =
                                (mMusicService.getRepeatMode() + 1)
                                    % 3;
                            mMusicService.setRepeatMode(newMode);
                            refreshTransportControls();
                            final int messageRes;
                            switch (newMode) {
                                case 0:
                                    messageRes = R.string
                                        .player_toast_repeat_off;
                                    break;
                                case 1:
                                    messageRes = R.string
                                        .player_toast_repeat_all;
                                    break;
                                default:
                                    messageRes = R.string
                                        .player_toast_repeat_one;
                                    break;
                            }
                            ToastManager.showToast(MusicPlayer.this,
                                getString(messageRes),
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null
                                && mShuffleButton.isEnabled()) {
                            final boolean newShuffle =
                                !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            refreshTransportControls();
                            ToastManager.showToast(MusicPlayer.this,
                                getString(newShuffle
                                    ? R.string.player_toast_shuffle_on
                                    : R.string.player_toast_shuffle_off),
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        cancelReturnHome();
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        cancelReturnHome();
                        final View mainContent =
                            findViewById(android.R.id.content);
                        mainContent.startAnimation(
                            AnimationUtils.loadAnimation(
                                MusicPlayer.this,
                                R.anim.slide_out_down));
                        final CreditsDialog dialog =
                            new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(
                            new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(
                                    DialogInterface
                                        dismissedDialog) {
                                final View contentView =
                                    findViewById(
                                        android.R.id.content);
                                contentView.startAnimation(
                                    AnimationUtils.loadAnimation(
                                        MusicPlayer.this,
                                        R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        cancelReturnHome();
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        cancelReturnHome();
                        startActivity(new Intent(
                            MusicPlayer.this,
                            EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        cancelReturnHome();
                        openMetadataEditor();
                    }
                }
            });
        }

        if (mFavoriteButton != null) {
            mFavoriteButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastFavoriteClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastFavoriteClickTime = currentTime;
                        callServiceSafely(new Runnable() {
                            @Override
                            public void run() {
                                if (mMusicService != null) {
                                    final Song currentSong =
                                        mMusicService.getCurrentSong();
                                    final boolean wasFavorite =
                                        currentSong != null
                                            && currentSong.isFavorite();
                                    mMusicService.toggleFavorite();
                                    ToastManager.showToast(
                                        MusicPlayer.this,
                                        getString(wasFavorite
                                            ? R.string
                                                .player_toast_favorite_off
                                            : R.string
                                                .player_toast_favorite_on),
                                        ToastManager.LENGTH_NORMAL);
                                }
                            }
                        });
                    }
                }
            });
        }

        if (mHomeButton != null) {
            mHomeButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();

                    // A third tap on a CONFIRMED button is a
                    // no-op. The user has committed; the
                    // return-home is half a second away and
                    // cannot be un-committed by another tap.
                    // The cancellation path for a user who has
                    // changed their mind is to tap any other
                    // button; that tap runs cancelReturnHome(),
                    // which resets this state to IDLE.
                    if (mHomeConfirmState
                            == HomeConfirmState.CONFIRMED) {
                        return;
                    }

                    // Clear any pending timeout from the
                    // previous phase before scheduling the
                    // next one.
                    if (mHomeReturnRunnable != null) {
                        mMainHandler.removeCallbacks(
                            mHomeReturnRunnable);
                        mHomeReturnRunnable = null;
                    }

                    // A second tap inside the ARMED window
                    // confirms.
                    if (mHomeConfirmState
                                == HomeConfirmState.ARMED
                            && currentTime - mLastHomeClickTime
                                <= HOME_CONFIRM_WINDOW_MS) {
                        enterConfirmedState();
                        return;
                    }

                    // A first tap, or any tap after the ARMED
                    // window has expired, arms the gesture.
                    enterArmedState(currentTime);
                }
            });
        }
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Returns whether the activity has been destroyed, using the
     * API-appropriate check.
     *
     * @return True when the activity has been destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp
            * getResources().getDisplayMetrics().density);
    }
}