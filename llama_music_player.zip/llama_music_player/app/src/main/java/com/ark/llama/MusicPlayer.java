// MusicPlayer.java
package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Renders the main playback screen and forwards user input to
 * {@link MusicService}.
 *
 * <p>The activity is a view over {@link MusicService}'s authoritative
 * playback state machine. User input is forwarded to the service, and
 * the resulting state is reflected from the service's
 * {@code UPDATE_PLAYER} event, delivered through
 * {@link BroadcastTranslator}. The activity does not own a transition
 * state of its own; the service owns every transition and the
 * activity follows the events.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The playback state machine is owned by {@link MusicService}.
 * This activity owns the render state derived from that machine: the
 * text and color of the current song's title and artist, the seek
 * bar position and duration, the enabled state of the transport
 * controls, and the album-art carousel's placeholder bitmap. Service
 * calls are serialised by {@link #mServiceLock}, and UI updates are
 * coalesced by {@link #updateUISafely(Runnable)}.</p>
 *
 * <p>The transport controls' enabled state, labels, and active tints
 * are written by {@link #refreshTransportControls()} alone. Every
 * other method in this class that wants the controls refreshed calls
 * that method; none of them sets a control's fields directly.</p>
 *
 * <h3>Transport Requests</h3>
 * <p>A next or previous request from the UI is dispatched to the
 * service and answered by the service's own {@code UPDATE_PLAYER}
 * event. {@link #playNextSong()} and {@link #playPreviousSong()}
 * call {@link MusicService#playNextSong()} or
 * {@link MusicService#playPreviousSong()}, which assign the target,
 * bump the transition generation, note the direction and restart for
 * that generation, and start the MediaPlayer work in the same
 * main-thread turn. The animation begins when the service's
 * committing event reaches the carousel's subscriber, in the same
 * turn the window is committed.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every transition the user can cause — a transport tap, a
 * committed swipe, a headset key, an automatic song change, an
 * incoming file — arrives at the activity as an {@code UPDATE_PLAYER}
 * event. The subscriber builds one commit runnable that writes every
 * surface the transition touches. The carousel reports through
 * {@link AlbumArtCarousel#setWindow(PlaybackWindow, int, boolean)}
 * whether the window landed synchronously. When it did, the runnable
 * runs in the subscriber's own turn. When an animation is running,
 * the runnable is queued on the carousel through
 * {@link AlbumArtCarousel#postOnSettle(Runnable)} and runs on the
 * frame the strip snaps to rest. The two branches converge on the
 * same main-thread turn.</p>
 *
 * <h3>Ordering</h3>
 * <p>Media buttons from headsets, hardware keys, and notification
 * action buttons are routed through
 * {@code androidx.media.session.MediaButtonReceiver} and dispatched to
 * the active
 * {@link android.support.v4.media.session.MediaSessionCompat} held by
 * {@link MusicService}. This activity keeps a fallback
 * {@link #onKeyDown(int, KeyEvent)} for hardware keys delivered to a
 * focused activity.</p>
 *
 * <p>Every {@code UPDATE_PLAYER} event carries a monotonic
 * {@code generation} alongside the full playback snapshot and the
 * transition direction and restart of that generation. The activity
 * tracks the highest generation it has seen and drops any event
 * with a strictly lower one.</p>
 *
 * <h3>Volume-Key Observation</h3>
 * <p>The activity overrides {@link #dispatchKeyEvent(KeyEvent)} to
 * observe the volume-up key before the window system consumes it.
 * The event is not consumed. In one specific case — the music volume
 * is already at the device maximum and the song is bound but paused —
 * the activity resumes the song directly, because the framework emits
 * no {@code VOLUME_CHANGED_ACTION} when no value changes.</p>
 *
 * <h3>Album-Art Gestures</h3>
 * <p>The album-art container owns every gesture that operates on the
 * album art. A single touch listener classifies each gesture on the
 * first significant move: a horizontal swipe becomes a carousel
 * swipe, a vertical swipe that starts inside the left or right edge
 * zone becomes a volume change, and a vertical swipe that starts at
 * the centre becomes a playback gesture — upward resumes a paused
 * song and downward pauses a playing one. The playback gesture
 * requires twice the touch slop of travel to distinguish an
 * intentional swipe from digitizer wobble on a resting finger.</p>
 *
 * <h3>Home Button</h3>
 * <p>The Home control is a two-tap gesture. The first tap enters
 * {@link HomeConfirmState#ARMED} and paints the button in
 * the themed active colour; a second tap within
 * {@link #HOME_CONFIRM_WINDOW_MS} enters
 * {@link HomeConfirmState#CONFIRMED}, paints the button in the
 * pending colour, and schedules the return-home for
 * {@link #HOME_CONFIRM_DWELL_MS} later. A tap on any other button
 * in either phase cancels the return and restores the Home button
 * to its steady inactive colour.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>{@link #applyAlbumArtSize(Configuration)} decides the
 * album-art container's size and visibility from
 * {@code Configuration.screenHeightDp}.</p>
 *
 * <p>The timer row below the SeekBar shows only when the
 * seek-bar section can show it in full. In a short window
 * where the section is given a fixed share, a section
 * shorter than the SeekBar plus the row hides the row
 * and keeps the SeekBar, centred in its share. When
 * space returns, the row returns.</p>
 *
 * <h3>Permissions</h3>
 * <p>The set of runtime permissions the app needs is defined once, in
 * {@link PermissionChecker}. This activity reads that set through two
 * of the checker's methods.</p>
 *
 * <h3>Cold-Start Overlay</h3>
 * <p>The cold-start library load shows a "Just a moment" toast and
 * a dim-and-spinner overlay under
 * {@link OverlayManager#REASON_COLD_START}.</p>
 *
 * <h3>Incoming File Requests</h3>
 * <p>An incoming file from another app is handed to the service
 * through a direct main-thread method call on the bound service
 * ({@code MusicService.requestIncomingFile(String)}) when the service
 * is bound, or parked on {@link #mPendingIncomingPath} and handed off
 * from {@link #onServiceConnected} when the bind has not yet
 * completed.</p>
 *
 * <h3>Language and Theme Application</h3>
 * <p>The activity wraps its base context through
 * {@link LanguageManager#wrap(Context)} in
 * {@link #attachBaseContext(Context)}, so every string it resolves
 * through {@code getString} is read from the resource folder that
 * matches the selected language from the moment the activity is
 * created. A {@code LANGUAGE_CHANGED} event reaches this activity
 * through {@link BroadcastTranslator} and answers with
 * {@code recreate()}. A {@code THEME_COLOR_CHANGED} event reaches
 * this activity through {@link BroadcastTranslator} and answers with
 * {@code recreateActivity()}.</p>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible string the activity writes resolves from a
 * string resource at the point of the write. The metadata fallbacks —
 * the values the activity writes when a song has no title or artist —
 * resolve from {@link CharacterMapper}'s placeholder producers.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialised by {@link #mServiceLock}. UI updates
 * are coalesced by {@link #updateUISafely(Runnable)}. The main handler
 * is drained in {@link #onDestroy()} so no post is left after the
 * activity is gone.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see PermissionChecker
 * @see OverlayManager
 * @see AlbumArtCarousel
 * @see PlaybackWindow
 * @see NotificationController
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 * @see LanguageManager
 * @see CharacterMapper
 * @see BroadcastTranslator
 *
 * @author Richard Korbla Adzido
 * @version 1.6.8
 * @since 1.0.0
 */
public class MusicPlayer extends Activity
        implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for the folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for the battery optimization request. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action that asks the activity to rebuild from folders. */
    private static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS =
        "UPDATE_PLAYLIST_FROM_FOLDERS";

    /** Broadcast action asking the playlist to redraw. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";

    /** Broadcast action asking the player to refresh its metadata display. */
    private static final String ACTION_FORCE_UPDATE_PLAYER =
        "FORCE_UPDATE_PLAYER";

    /** Broadcast action asking the service for its current playing state. */
    private static final String ACTION_GET_PLAYING_STATE =
        "GET_PLAYING_STATE";

    /** Broadcast action carrying the service's reply to a playing-state query. */
    private static final String ACTION_PLAYING_STATE_RESPONSE =
        "PLAYING_STATE_RESPONSE";

    /** Operation ID for the library-load overlay mirror. */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Interval for the library-load heartbeat, in milliseconds. */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500L;

    /** Maximum time the library-load heartbeat runs before the load
     *  is considered abandoned, in milliseconds. */
    private static final long LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS =
        30000L;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Window during which a second tap on the Home button confirms
     *  the return-home gesture, in milliseconds. */
    private static final long HOME_CONFIRM_WINDOW_MS = 1000L;

    /** Dwell on the themed CONFIRMED state before the return-home
     *  fires, in milliseconds. */
    private static final long HOME_CONFIRM_DWELL_MS = 500L;

    /** Delay for the service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000L;

    /** Delay before performing focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500L;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500L;

    /** Delay before updating the repeat and shuffle buttons. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250L;

    /** Buffer size for file copy operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of the button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /** Width of the volume-gesture edge zone on each side of the
     *  album-art container, in density-independent pixels. */
    private static final int VOLUME_GESTURE_EDGE_DP = 60;

    /** Fraction of the device's volume range the finger must travel
     *  past a limit before the volume toast echoes a second time. */
    private static final float VOLUME_LIMIT_ECHO_STEP_FRACTION = 0.15f;

    /** The gesture is not currently clamped to either volume limit. */
    private static final int VOLUME_LIMIT_SIDE_NONE = 0;

    /** The gesture is clamped to the device's maximum music volume. */
    private static final int VOLUME_LIMIT_SIDE_MAXIMUM = +1;

    /** The gesture is clamped to zero music volume. */
    private static final int VOLUME_LIMIT_SIDE_MINIMUM = -1;

    /** Window height above which the album art is shown at its full
     *  size. */
    private static final int SPLIT_SCREEN_FULL_HEIGHT_DP = 600;

    /** Window height below which the album art is hidden entirely. */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    /** Window width below which the song-info group is not docked
     *  beside the transport row. A narrow landscape window, such
     *  as landscape split-screen, is too narrow for the two side
     *  by side: the transport row alone needs 288dp, so it falls
     *  back to the stacked portrait layout instead. */
    private static final int DOCK_MIN_WIDTH_DP = 600;

    /** Album-art size at full screen, in dp. */
    private static final int ALBUM_ART_FULL_DP = 300;

    /** Album-art size in a shrunk split-screen window, in dp. */
    private static final int ALBUM_ART_SHRUNK_DP = 180;

    /**
     * The toast lane in dp: the reserved space between the
     * side-by-side row and the bottom buttons where toasts
     * show. In split view it is the transport row's bottom
     * padding; in landscape it is the docked row's bottom
     * margin. The bottom buttons row's 16dp top padding sits
     * below it, and its 16dp bottom padding is the existing
     * space to the edge.
     */
    private static final int TRANSPORT_ROW_SPLIT_BOTTOM_DP = 48;

    /**
     * Gap in dp between the song-info group and the seek-bar
     * section when the two share the space in a short,
     * undocked window.
     */
    private static final int SONG_INFO_SEEK_BAR_GAP_DP = 12;

    /**
     * Height in dp of the title/artist column and the
     * short-window minimum for the song-info group, matching
     * the 48dp Home and Favorite buttons.
     */
    private static final int SONG_INFO_BUTTON_GROUP_HEIGHT_DP = 48;

    // ============================================================================
    // Message Resource Identifiers
    // ============================================================================

    /** Message shown while the cold-start library load runs. */
    private static final int MESSAGE_LIBRARY_LOAD =
        R.string.player_library_loading;

    /** Message shown when the cold-start load never completes. */
    private static final int MESSAGE_LIBRARY_LOAD_FAILED =
        R.string.player_library_load_failed;

    /** Message shown when the service bind is refused synchronously. */
    private static final int MESSAGE_SERVICE_BIND_FAILED =
        R.string.player_service_bind_failed;

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Displays the title of the current song. */
    @Nullable private TextView mSongTitle;
    /** Displays the artist name of the current song. */
    @Nullable private TextView mSongArtist;
    /** Displays the elapsed playback time. */
    @Nullable private TextView mSeekTime;
    /** Displays the total duration of the current track. */
    @Nullable private TextView mTotalTime;
    /** Seek bar for scrubbing through the current track. */
    @Nullable private SeekBar mSeekBar;
    /** Row holding the current time and the total duration. */
    @Nullable private View mTimeRow;
    /** Toggles playback between play and pause. */
    @Nullable private Button mPlayButton;
    /** Skips to the previous track. */
    @Nullable private Button mPrevButton;
    /** Skips to the next track. */
    @Nullable private Button mNextButton;
    /** Toggles repeat mode for the playback queue. */
    @Nullable private Button mRepeatButton;
    /** Toggles shuffle mode for the playback queue. */
    @Nullable private Button mShuffleButton;
    /** Opens the folder manager. */
    @Nullable private Button mManagerButton;
    /** Opens the credits dialog. */
    @Nullable private Button mLlamaButton;
    /** Opens the playlist. */
    @Nullable private Button mPlaylistButton;
    /** Opens the equalizer. */
    @Nullable private Button mEqualizerButton;
    /** Opens the metadata editor. */
    @Nullable private Button mMetadataButton;
    /** Toggles the favourite status of the current track. */
    @Nullable private Button mFavoriteButton;
    /** Navigates back to the home screen. */
    @Nullable private Button mHomeButton;
    /** Actual content boundary used only to decide whether the timer row fits. */
    @Nullable private View mActivityContentRoot;
    /** Viewport whose children are built at runtime by AlbumArtCarousel. */
    @Nullable private FrameLayout mAlbumArtContainer;
    /** Padding-only container wrapping the album-art carousel viewport. */
    @Nullable private LinearLayout mAlbumArtWrapper;
    /** Groups the song title and artist with the home and favourite buttons. */
    @Nullable private FrameLayout mSongInfoGroup;
    /** Row holding the transport controls. */
    @Nullable private LinearLayout mTransportRow;

    /** Per-child default {@code layout_gravity} of
     *  {@link #mSongInfoGroup}'s children, captured from the layout at
     *  init time. */
    @Nullable private int[] mDefaultSongInfoChildGravities;

    /** Top padding of {@link #mSongInfoGroup} as declared by the layout. */
    private int mDefaultSongInfoPaddingTop = 0;

    /** Bottom padding of {@link #mTransportRow} as declared by the layout. */
    private int mDefaultTransportPaddingBottom = 0;

    /**
     * Horizontal row the song-info group and the transport row dock
     * into in a short landscape window, created on first dock.
     */
    @Nullable private LinearLayout mSongInfoDockRow;

    /** Whether the song-info group is docked beside the transport row. */
    private boolean mSongInfoDocked;

    /**
     * {@link #mSongInfoGroup}'s layout params in the root layout,
     * restored on undock.
     */
    @Nullable private ViewGroup.LayoutParams mSongInfoRootParams;

    /**
     * {@link #mTransportRow}'s layout params in the root layout,
     * restored on undock.
     */
    @Nullable private ViewGroup.LayoutParams mTransportRootParams;

    /** {@link #mSongInfoGroup}'s index in the root layout, restored on undock. */
    private int mSongInfoRootIndex = -1;

    /** {@link #mTransportRow}'s index in the root layout, restored on undock. */
    private int mTransportRootIndex = -1;

    /**
     * The seek-bar section, given weight 1 while docked so it
     * takes the leftover space above the docked row.
     */
    @Nullable private LinearLayout mSeekBarSection;

    /**
     * The seek-bar section's layout params in the root layout,
     * restored on undock.
     */
    @Nullable private ViewGroup.LayoutParams mSeekBarSectionRootParams;

    /** The seek-bar section's gravity as declared by the layout. */
    private int mDefaultSeekBarSectionGravity;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    @Nullable private MusicLibrary mMusicLibrary;
    @Nullable private MusicService mMusicService;
    @Nullable private StorageAccessHelper mStorageAccessHelper;
    @Nullable private NotificationController mNotificationController;

    /** The pending return-home timeout. */
    @Nullable private Runnable mHomeReturnRunnable;

    @NonNull private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    @NonNull private final Handler mServiceHandler =
        new Handler(Looper.getMainLooper());

    @Nullable private Handler mTimeHandler = null;

    private boolean mIsServiceBound = false;
    private boolean mIsUserSeeking = false;

    /** State of the two-tap return-home gesture. */
    @NonNull
    private HomeConfirmState mHomeConfirmState = HomeConfirmState.IDLE;

    @NonNull private final AtomicBoolean mIsUpdatingUI =
        new AtomicBoolean(false);

    @Nullable private volatile Runnable mPendingUIUpdate = null;

    private volatile String mPendingIncomingPath = null;

    @NonNull private final Object mServiceLock = new Object();

    private long mLastSeenGeneration = -1L;

    /**
     * Last observed music-stream volume, used to distinguish actual
     * volume changes from unrelated system-setting notifications.
     */
    private int mLastObservedMusicVolume = -1;

    // ============================================================================
    // State Flags
    // ============================================================================

    private boolean mInitializationAttempted = false;
    private boolean mIsPostUpdateRestart = false;
    private boolean isLoadingComplete = false;
    private boolean mPermissionsDenied = false;
    private boolean mRecreationPending = false;

    /**
     * Set when a {@code THEME_COLOR_CHANGED} event arrives while the
     * activity is not started. The event is not dropped: the pending
     * recreate runs from {@link #onStart()}, so the activity is
     * rebuilt against the new theme when it returns to the
     * foreground instead of keeping the theme it was constructed
     * with.
     */
    private boolean mThemeRecreationPending = false;
    @Nullable private Runnable mLibraryHeartbeatRunnable;

    /** True when the current playback scope contains no songs. */
    private boolean mScopeEmpty = false;

    /**
     * True while the activity is started and visible to the user.
     * Used by the theme receiver and MusicService to gate
     * visibility-dependent behavior.
     */
    private volatile boolean mIsStarted = false;

    /**
     * True only while this activity is resumed and foreground-interactive.
     * Prevents activity-originated playback actions while backgrounded.
     */
    private volatile boolean mIsResumed = false;

    // ============================================================================
    // Click Debounce Timestamps
    // ============================================================================

    private long mLastNextClickTime = 0L;
    private long mLastPrevClickTime = 0L;
    private long mLastShuffleClickTime = 0L;
    private long mLastRepeatClickTime = 0L;
    private long mLastPlayPauseClickTime = 0L;
    private long mLastEqualizerClickTime = 0L;
    private long mLastManagerClickTime = 0L;
    private long mLastLlamaClickTime = 0L;
    private long mLastPlaylistClickTime = 0L;
    private long mLastMetadataClickTime = 0L;
    private long mLastFavoriteClickTime = 0L;
    private long mLastHomeClickTime = 0L;

    // ============================================================================
    // Album Art Components
    // ============================================================================

    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    @NonNull private final ExecutorService mAlbumArtExecutor =
        Executors.newSingleThreadExecutor();

    @NonNull private final ExecutorService mMetadataLoader =
        Executors.newSingleThreadExecutor();

    @Nullable private Future<?> mCurrentMetadataFuture = null;

    @Nullable private Bitmap mPlaceholderBitmap = null;
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    @NonNull private final ExecutorService mPlaceholderExecutor =
        Executors.newSingleThreadExecutor();

    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    @NonNull private final Object mPlaceholderLock = new Object();

    @Nullable private AlbumArtCarousel mAlbumArtCarousel;

    @Nullable private ThemeManager mThemeManager;
    @Nullable private ThemeHelper mThemeHelper;

    @Nullable private ContentObserver mVolumeObserver;

    @Nullable private StorageObserver mStorageObserver;

    @Nullable private Song mCachedLastSong = null;

    /** Timestamp of the last completed tap on the album-art
     *  container, used to detect a double-tap. */
    private long mLastTapTime = 0L;

    // ============================================================================
    // Gesture State
    // ============================================================================

    @Nullable private AudioManager mAudioManager;

    /** Classification of the current touch on the album-art
     *  container. */
    private enum GestureState {
        TOUCHED,
        CAROUSEL,
        VOLUME,
        PLAYBACK,
        CANCELLED
    }

    /** State of the two-tap return-home gesture. */
    private enum HomeConfirmState {
        IDLE,
        ARMED,
        CONFIRMED
    }

    @NonNull private GestureState mGestureState = GestureState.TOUCHED;

    private float mGestureStartX = 0f;
    private float mGestureStartY = 0f;
    private int mGestureContainerWidth = 1;
    private int mGestureContainerHeight = 1;
    private int mVolumeGestureStartVolume = 0;
    private int mVolumeGestureMaxVolume = 0;
    private int mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
    private float mVolumeGestureLimitEchoBaseline = Float.NaN;

    // ============================================================================
    // Service Connection
    // ============================================================================

    @NonNull
    private final ServiceConnection mServiceConnection =
            new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mMusicService.setActivityInForeground(mIsStarted);

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG,
                    "Handing off parked incoming path: " + pendingPath);
                handOffIncomingPath(pendingPath);
            }

            refreshTransportControls();

            loadFullPlaylistInBackground();
            syncDisplayFromService();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }
                    if (canEnableTransportControls()) {
                        refreshTransportControls();
                        syncDisplayFromService();
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (mMusicService != null) {
                mMusicService.setActivityInForeground(false);
            }
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing()
                            && !isDestroyed()) {
                        Log.d(TAG,
                            "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(
                            MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection,
                            BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    /**
     * Wraps the base context with the currently selected locale.
     *
     * @param newBase Base context supplied by the framework
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase));
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, the view hierarchy, its
     * {@link BroadcastTranslator} subscription, and the service
     * binding, and starts the permission check.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);
        OverlayManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        mAlbumArtCache =
            AlbumArtCache.getInstance(this).asLruCache();

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageAccessHelper = StorageAccessHelper.getInstance(this);
        mNotificationController =
            NotificationController.getInstance(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        mIsPostUpdateRestart = getIntent()
            .getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        BroadcastTranslator.getInstance(this).register(this);
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Registers the system-settings observer when the activity becomes visible.
     */
    @Override
    protected void onStart() {
        super.onStart();
        mIsStarted = true;

        if (mThemeRecreationPending) {
            mThemeRecreationPending = false;
            recreateActivity();
            return;
        }

        if (mAudioManager != null) {
            mLastObservedMusicVolume = mAudioManager.getStreamVolume(
                AudioManager.STREAM_MUSIC);
        }

        mVolumeObserver = new ContentObserver(
            new Handler(Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) {
                super.onChange(selfChange);
                handleObservedMusicVolumeChange();
            }
        };

        getContentResolver().registerContentObserver(
            Settings.System.CONTENT_URI,
            true,
            mVolumeObserver);
    }

    /**
     * Disables activity-originated playback actions as soon as the
     * activity loses foreground interaction.
     */
    @Override
    protected void onPause() {
        mIsResumed = false;

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setActivityInForeground(false);
        }

        super.onPause();
    }

    /**
     * Marks the activity as stopped and unregisters the volume observer.
     */
    @Override
    protected void onStop() {
        mIsStarted = false;
        mIsResumed = false;

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setActivityInForeground(false);
        }

        // Unregister the observer added in onStart().
        if (mVolumeObserver != null) {
            getContentResolver().unregisterContentObserver(mVolumeObserver);
            mVolumeObserver = null;
        }

        super.onStop();
        cancelReturnHome();
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the playback display from the service, reapplies the theme,
     * and drives the permission and initialization gates.
     */
    @Override
    protected void onResume() {
        super.onResume();
        LanguageManager.getInstance(this).reapply(this);

        mIsResumed = true;

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setActivityInForeground(true);
        }

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        final boolean permissionsGranted =
            PermissionChecker.allGranted(this);

        if (permissionsGranted && mMusicService != null
                && mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0) {
            refreshTransportControls();
            // INSTANT SYNC: pull the full snapshot
            // (title, artist, position, duration, favourite, scope)
            // from the service, then ask the service to re-broadcast
            // it. The pull covers the steady state; the broadcast
            // covers a transition that was in flight, where the pull
            // deliberately does nothing. Same-generation broadcasts
            // are applied, not dropped, so this is idempotent.
            syncDisplayFromService();
            mMusicService.requestPlayerResync();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(
                this,
                getString(MESSAGE_LIBRARY_LOAD),
                "",
                OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();

        if (!permissionsGranted) {
            if (!mPermissionsDenied) {
                mPermissionsDenied = true;
                applyNoSongState();
            }
            return;
        }

        if (mPermissionsDenied) {
            mPermissionsDenied = false;
            if (mInitializationAttempted) {
                mInitializationAttempted = false;
                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }
            }
        }

        if (!mInitializationAttempted) {
            proceedWithInitialization();
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Releases every resource held by the activity.
     */
    @Override
    protected void onDestroy() {
        BroadcastTranslator.getInstance(this).unregister(this);
        super.onDestroy();

        mIsStarted = false;
        mIsResumed = false;

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setActivityInForeground(false);
        }

        if (mVolumeObserver != null) {
            getContentResolver().unregisterContentObserver(mVolumeObserver);
            mVolumeObserver = null;
        }

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null
                && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }
        if (mCurrentPlaceholderTask != null) {
            mCurrentPlaceholderTask.cancel(true);
            mCurrentPlaceholderTask = null;
        }
        if (!mPlaceholderExecutor.isShutdown()) {
            mPlaceholderExecutor.shutdownNow();
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.clear();
            mAlbumArtCarousel = null;
        }

        mAlbumArtCache = null;

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
        }

        cancelReturnHome();

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();
    }

    /**
     * Forwards the trim-memory signal to the bound service when one
     * is available, and evicts the album art cache under sustained
     * pressure.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG,
                    "Failed to forward onTrimMemory to service",
                    exception);
            }
        }
        if (level >= TRIM_MEMORY_BACKGROUND && mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
    }

    /**
     * Updates the intent and either closes the app or processes a
     * new incoming file.
     *
     * @param intent The new intent delivered to the activity
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Applies the album-art size and visibility for the new window
     * height.
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        LanguageManager.getInstance(this).reapply(this);
        applyAlbumArtSize(config);
        forceRedraw();
    }

    /**
     * Intercepts the volume-up key before the window handles it.
     *
     * @param event The key event delivered to the activity
     * @return Whatever {@code super.dispatchKeyEvent} returns
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            // At maximum, pressing up changes nothing, so the
            // volume observer does not fire for this press.
            // Check after the system applies the volume change.
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                resumeIfPausedAtMaxVolume();
            }, 100L);
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * Handles media keys delivered to a focused activity.
     *
     * @param keyCode Code of the pressed key
     * @param event Full key event
     * @return True when the key was consumed
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Resumes paused or ready playback for the volume-up-at-maximum
     * action. The maximum-volume requirement is specific to this
     * trigger; the playback swipe uses the same foreground and audio
     * focus safeguards without that volume requirement.
     *
     * @return True when a resume request was issued
     */
    private boolean resumeIfPausedAtMaxVolume() {
        return resumeIfPausedAndFocused(true, "volume-up at maximum");
    }

    /**
     * Resumes playback only while this activity is foreground-interactive,
     * the service is bound, playback is paused or ready, and the app
     * already holds or can successfully obtain audio focus.
     *
     * @param maxVolumeRequired Whether the trigger requires maximum
     *                         music-stream volume
     * @param trigger Description used in diagnostic logging
     * @return True when a resume request was issued
     */
    private boolean resumeIfPausedAndFocused(boolean maxVolumeRequired,
                                              @NonNull String trigger) {
        if (!mIsResumed || mMusicService == null || !mIsServiceBound) {
            return false;
        }

        try {
            if (maxVolumeRequired) {
                if (mAudioManager == null) {
                    return false;
                }

                final int maxVolume = mAudioManager.getStreamMaxVolume(
                    AudioManager.STREAM_MUSIC);

                if (maxVolume <= 0) {
                    return false;
                }

                final int currentVolume = mAudioManager.getStreamVolume(
                    AudioManager.STREAM_MUSIC);

                if (currentVolume < maxVolume) {
                    return false;
                }
            }

            if (!mMusicService.isPausedOrReady()) {
                return false;
            }

            // doResume() requests focus itself and refuses if not granted.
            mMusicService.resume();
            return true;

        } catch (Exception exception) {
            Log.w(TAG, "Failed to resume playback for " + trigger,
                exception);
            return false;
        }
    }

    /**
     * Handles the folder selection result and the battery
     * optimization result.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE
                && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageAccessHelper != null) {
                final String folderPath =
                    mStorageAccessHelper.getFolderPathFromUri(treeUri);
                mStorageAccessHelper.storeFolderPermission(
                    treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName =
                    mStorageAccessHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this,
                    getString(R.string.folder_manager_imported_toast,
                        folderName),
                    ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager =
                    (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized =
                        powerManager.isIgnoringBatteryOptimizations(
                            getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows a battery optimization result toast after a short delay.
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    final int messageRes = optimized
                        ? R.string.player_battery_optimized
                        : R.string.player_battery_restricted;
                    ToastManager.showToast(MusicPlayer.this,
                        getString(messageRes),
                        ToastManager.LENGTH_NORMAL);
                }
            }
        }, 150L);
    }

    /**
     * Handles the runtime permission result.
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions,
            grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult
                        != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                mPermissionsDenied = false;
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    getString(R.string.player_permissions_required),
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                mPermissionsDenied = true;
                applyNoSongState();
            }
        }
    }

    // ============================================================================
    // NavigationController Listener Implementation
    // ============================================================================

    /**
     * Enables or disables the playlist and metadata buttons
     * according to the current database-actions state.
     */
    @Override
    public void onButtonStateChanged(
            NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // BroadcastTranslator subscribers
    // ============================================================================

    /**
     * Handles an {@code UPDATE_PLAYER} event.
     *
     * <p>Refresh order is chosen so that the surface a user reads
     * first is written first. The transport controls are written
     * synchronously in the subscriber's own main-thread turn and are
     * never deferred by the album-art carousel: their state is a
     * function of the service snapshot alone, and deferring them
     * behind an animation would delay the play/pause and favorite
     * feedback the user expects to see at the instant of the tap.
     * Album art continues its own asynchronous carousel transition.
     * The title, artist, and seek bar are committed in the same UI
     * turn as the service event, rather than waiting for that
     * independent animation to settle.</p>
     */
    @org.greenrobot.eventbus.Subscribe
    public void onUpdatePlayerEvent(
            BroadcastTranslator.UpdatePlayerEvent event) {
        if (event == null) {
            return;
        }

        final long generation = event.generation;
        if (generation >= 0) {
            if (generation < mLastSeenGeneration) {
                return;
            }
            if (generation > mLastSeenGeneration) {
                mLastSeenGeneration = generation;
            }
        }

        // Reject stale generations before applying the empty-scope
        // state. Otherwise a delayed empty-scope broadcast could clear
        // the UI after a newer non-empty scope has already committed.
        final int scopedSongCount = event.scopeCount;
        if (scopedSongCount == 0) {
            if (!mScopeEmpty) {
                mScopeEmpty = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();
                    }
                });
            }
            return;
        } else if (scopedSongCount > 0) {
            mScopeEmpty = false;
        }

        final String displayTitle = event.displayTitle;
        final String displayArtist = event.displayArtist;
        final int positionMs = event.positionMs;
        final int durationMs = event.durationMs;
        final int transitionDirection = event.transitionDirection;
        final boolean transitionRestart = event.transitionRestart;

        refreshTransportControls();

        final PlaybackWindow windowSnapshot =
            new PlaybackWindow(
                event.windowPreviousPath,
                event.windowCurrentPath,
                event.windowNextPath,
                generation);

        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (mAlbumArtCarousel == null) {
                    return;
                }

                mAlbumArtCarousel.setWindow(
                    windowSnapshot,
                    transitionDirection,
                    transitionRestart);

                final int finalPositionMs = positionMs;
                final int finalDurationMs = durationMs;
                final String finalTitle = displayTitle;
                final String finalArtist = displayArtist;

                final Runnable commit = new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        if (mSeekBar != null
                                && mSeekBar.isEnabled()
                                && finalDurationMs > 0) {
                            if (mSeekBar.getMax()
                                    != finalDurationMs) {
                                mSeekBar.setMax(
                                    finalDurationMs);
                            }
                            mSeekBar.setProgress(
                                finalPositionMs);
                        }

                        if (mSongTitle != null
                                && finalTitle != null) {
                            mSongTitle.setText(finalTitle);
                            if (mThemeHelper != null) {
                                mSongTitle.setTextColor(
                                    mThemeHelper
                                        .getThemeColorInt());
                            }
                        }
                        if (mSongArtist != null
                                && finalArtist != null) {
                            mSongArtist.setText(finalArtist);
                            mSongArtist.setTextColor(
                                Color.parseColor(
                                    "#C0C0C0"));
                        }

                        setupSeekBar();
                    }
                };

                // Playback metadata is independent of album-art decoding and
                // carousel animation. Commit it in this UI turn so the title,
                // artist, and seek bar reflect the service snapshot immediately.
                // The carousel continues its own transition without holding
                // these controls behind the animation's settle callback.
                commit.run();
            }
        });
    }

    /**
     * Handles a {@code PLAY_SONG} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onPlaySongEvent(
            BroadcastTranslator.PlaySongEvent event) {
        if (event == null) {
            return;
        }
        final String songPath = event.songPath;
        if (songPath != null && mMusicService != null) {
            mMusicService.playSongByPath(songPath);
        }
    }

    /**
     * Handles a {@code BLUETOOTH_PLAY} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onBluetoothPlayEvent(
            BroadcastTranslator.BluetoothPlayEvent event) {
        if (event == null) {
            return;
        }
        if (mMusicService != null
                && mMusicLibrary != null) {
            final int currentIndex =
                mMusicService.getCurrentIndex();
            final ArrayList<Song> allSongs =
                mMusicLibrary.getAllSongs();
            if (currentIndex >= 0
                    && currentIndex < allSongs.size()) {
                if (mMusicService.getDuration() == 0) {
                    playSong(currentIndex);
                } else {
                    mMusicService.resume();
                }
            } else if (mMusicLibrary.getSongCount() > 0) {
                playSong(0);
            }
        }
        refreshTransportControls();
    }

    /**
     * Handles a {@code LIBRARY_RESET} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onLibraryResetEvent(
            BroadcastTranslator.LibraryResetEvent event) {
        if (event == null) {
            return;
        }

        final boolean preserveSettings = event.preserveSettings;

        mPendingIncomingPath = null;
        mIsUserSeeking = false;
        mLastSeenGeneration = -1L;

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        mCachedLastSong = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.invalidate();
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                applyNoSongState();

                if (!preserveSettings
                        && mMusicService != null) {
                    mMusicService.setRepeatMode(0);
                    mMusicService.setShuffle(false);
                }

                refreshTransportControls();
            }
        });
    }

    /**
     * Handles a {@code com.ark.llama.RESTART_APP} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onRestartAppEvent(
            BroadcastTranslator.RestartAppEvent event) {
        if (event == null) {
            return;
        }
        performUpdate();
    }

    /**
     * Handles a {@code SAVE_PLAYER_STATE_NOW} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onSavePlayerStateNowEvent(
            BroadcastTranslator.SavePlayerStateNowEvent event) {
        if (event == null) {
            return;
        }
        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }
    }

    /**
     * Handles a {@code BLUETOOTH_CONNECTED} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onBluetoothConnectedEvent(
            BroadcastTranslator.BluetoothConnectedEvent event) {
        if (event == null) {
            return;
        }
        if (mMusicService != null) {
            mMusicService.setBluetoothConnected(event.connected);
        }
    }

    /**
     * Handles a {@code SYNC_STARTED} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onSyncStartedEvent(
            BroadcastTranslator.SyncStartedEvent event) {
        if (event == null) {
            return;
        }
        if (ToastManager.hasPersistentToast()) {
            ToastManager.ensureOverlayAttached(
                MusicPlayer.this);
        }
    }

    /**
     * Handles a {@code SYNC_COMPLETE} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onSyncCompleteEvent(
            BroadcastTranslator.SyncCompleteEvent event) {
        if (event == null) {
            return;
        }
        Log.d(TAG, "SYNC_COMPLETE received");
    }

    /**
     * Handles an {@code UPDATE_PLAYLIST_FROM_FOLDERS} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onUpdatePlaylistFromFoldersEvent(
            BroadcastTranslator.UpdatePlaylistFromFoldersEvent event) {
        if (event == null) {
            return;
        }
        if (mMusicLibrary == null) {
            mMusicLibrary =
                new MusicLibrary(MusicPlayer.this);
        }

        final MusicLibrary library = mMusicLibrary;
        final MusicService service = mMusicService;

        mMetadataLoader.execute(new Runnable() {
            @Override
            public void run() {
                library.refreshCache();
                final ArrayList<Song> allSongs =
                    library.getAllSongs();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()
                                && service != null) {
                            if (!allSongs.isEmpty()) {
                                service.setPlaylist(
                                    allSongs, true);
                                refreshTransportControls();
                                setupSeekBar();
                                updateTimeDisplay();
                            } else {
                                service.setPlaylist(
                                    null, false);
                                applyNoSongState();
                            }
                            sendBroadcast(new Intent(
                                ACTION_DISPLAY_PLAYLIST));
                        }

                        sendBroadcast(new Intent(
                            BroadcastTranslator
                                .ACTION_TRIGGER_GENRE_LOADING));
                    }
                });
            }
        });
    }

    /**
     * Handles an {@code UPDATE_PLAYLIST} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onUpdatePlaylistEvent(
            BroadcastTranslator.UpdatePlaylistEvent event) {
        if (event == null) {
            return;
        }
        if (mMusicService != null
                && mMusicLibrary != null) {
            mMusicLibrary.refreshCache();
            final ArrayList<Song> allSongs =
                mMusicLibrary.getAllSongs();
            if (allSongs != null
                    && !allSongs.isEmpty()) {
                mMusicService.setPlaylist(
                    allSongs, true);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshTransportControls();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                });
            } else {
                mMusicService.stop();
                mMusicService.setPlaylist(null, false);
                mMusicLibrary.refreshCache();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();
                        ToastManager
                            .hidePersistentOverlay();
                    }
                });
            }
        }
    }

    /**
     * Handles a {@code METADATA_UPDATED} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onMetadataUpdatedEvent(
            BroadcastTranslator.MetadataUpdatedEvent event) {
        if (event == null) {
            return;
        }

        final String songPath =
            resolveBroadcastSongPath(event.songPath, event.songUri);
        if (songPath == null || mMusicService == null) {
            return;
        }

        final MusicService service = mMusicService;

        if (mMusicLibrary != null) {
            mMusicLibrary.refreshCache();
        }

        final boolean artChanged =
            event.albumArtRemoved || event.albumArtBytes != null;
        if (artChanged && mAlbumArtCarousel != null) {
            mAlbumArtCarousel.invalidatePath(songPath);
        }

        final Song currentSong = service.getCurrentSong();
        final boolean editedIsCurrent = currentSong != null
            && songPath.equals(currentSong.getPath());
        if (editedIsCurrent) {
            mMainHandler.post(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                final Song refreshedSong = service.getCurrentSong();
                if (refreshedSong == null
                        || !songPath.equals(refreshedSong.getPath())) {
                    return;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(refreshedSong.getTitle());
                    if (mThemeHelper != null) {
                        mSongTitle.setTextColor(
                            mThemeHelper.getThemeColorInt());
                    }
                }
                if (mSongArtist != null) {
                    mSongArtist.setText(refreshedSong.getArtist());
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }
            });
        } else {
            sendBroadcast(
                new Intent(ACTION_DISPLAY_PLAYLIST));
        }
    }

    /**
     * Handles a {@code PLAYBACK_RECOVERED} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onPlaybackRecoveredEvent(
            BroadcastTranslator.PlaybackRecoveredEvent event) {
        if (event == null) {
            return;
        }
        ToastManager.showToast(MusicPlayer.this,
            getString(R.string.player_playback_recovered),
            ToastManager.LENGTH_NORMAL);
    }

    /**
     * Handles an {@code UPDATE_SORT_MODE} event.
     */
    @org.greenrobot.eventbus.Subscribe
    public void onUpdateSortModeEvent(
            BroadcastTranslator.UpdateSortModeEvent event) {
        if (event == null) {
            return;
        }
        final int newSortMode = event.sortMode;
        if (mMusicService != null
                && mMusicLibrary != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Song currentSong =
                        (mMusicService != null)
                            ? mMusicService
                                .getCurrentSong()
                            : null;
                    if (currentSong != null) {
                        updateUIForSong(currentSong);
                    }
                    refreshCarouselFromService();
                }
            });
            Log.d(TAG,
                "Sort mode update received, refreshed UI: "
                    + newSortMode);
        }
    }

    /**
     * Handles a {@code LANGUAGE_CHANGED} event.
     *
     * <p>Recreates the activity against the newly selected locale.
     * The recreation re-runs {@link #attachBaseContext(Context)},
     * which produces a base context wrapped by
     * {@link LanguageManager#wrap(Context)} for the new language, so
     * every string this activity resolves through {@code getString}
     * from its new {@code onCreate} onward is read from the matching
     * resource folder.</p>
     *
     * <p>The event is posted by {@link CreditsDialog} through
     * {@link BroadcastTranslator} from the picker's own
     * {@code onDismiss} callback, so the picker window is already
     * detached before this subscriber runs. That ordering
     * guarantees the recreation cannot race the picker's window
     * teardown.</p>
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onLanguageChangedEvent(
            BroadcastTranslator.LanguageChangedEvent event) {
        if (event == null) {
            return;
        }
        if (!mIsStarted) {
            mThemeRecreationPending = true;
            return;
        }
        if (isFinishing() || isDestroyed()) {
            return;
        }
        recreateActivity();
    }

    /**
     * Handles a {@code THEME_COLOR_CHANGED} event.
     *
     * <p>When the activity is started it recreates immediately, as
     * before. When it is not started the event is not dropped: the
     * recreate is deferred to {@link #onStart()} through
     * {@link #mThemeRecreationPending}, so a theme change made from
     * another surface still rebuilds this activity when it returns
     * to the foreground.</p>
     */
    @org.greenrobot.eventbus.Subscribe
    public void onThemeColorChangedEvent(
            BroadcastTranslator.ThemeColorChangedEvent event) {
        if (event == null) {
            return;
        }
        if (!mIsStarted) {
            mThemeRecreationPending = true;
            return;
        }
        if (isFinishing() || isDestroyed()) {
            return;
        }
        recreateActivity();
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches typefaces and touch animations,
     * constructs the album-art carousel with its swipe commit
     * listener, and primes the initial control state.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mTimeRow = findViewById(R.id.timeRow);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mFavoriteButton = (Button) findViewById(R.id.favoriteButton);
        mHomeButton = (Button) findViewById(R.id.homeButton);
        mAlbumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);
        mAlbumArtWrapper =
            (LinearLayout) findViewById(R.id.albumArtWrapper);
        mSongInfoGroup =
            (FrameLayout) findViewById(R.id.songInfoGroup);
        mTransportRow =
            (LinearLayout) findViewById(R.id.transportRow);
        mSeekBarSection =
            (LinearLayout) findViewById(R.id.seekBarSection);
        mActivityContentRoot = findViewById(android.R.id.content);

        if (mSongInfoGroup != null) {
            mDefaultSongInfoPaddingTop =
                mSongInfoGroup.getPaddingTop();

            final int childCount = mSongInfoGroup.getChildCount();
            mDefaultSongInfoChildGravities = new int[childCount];
            for (int i = 0; i < childCount; i++) {
                final View child = mSongInfoGroup.getChildAt(i);
                if (child.getLayoutParams()
                        instanceof FrameLayout.LayoutParams) {
                    mDefaultSongInfoChildGravities[i] =
                        ((FrameLayout.LayoutParams) child.getLayoutParams())
                            .gravity;
                } else {
                    mDefaultSongInfoChildGravities[i] =
                        Gravity.CENTER_VERTICAL;
                }
            }
        }

        if (mTransportRow != null) {
            mDefaultTransportPaddingBottom =
                mTransportRow.getPaddingBottom();
        }

        if (mSeekBarSection != null) {
            mDefaultSeekBarSectionGravity =
                mSeekBarSection.getGravity();
            mSeekBarSection.addOnLayoutChangeListener(
                (view, left, top, right, bottom,
                 oldLeft, oldTop, oldRight, oldBottom) -> {
                    if (top != oldTop || bottom != oldBottom
                            || right - left != oldRight - oldLeft) {
                        updateTimeVisibility();
                    }
                });
        }

        // Split-screen divider drags can change the visible activity bounds
        // without changing the seek-bar section's own measured height when
        // that section is WRAP_CONTENT. Recheck only the timer row here:
        // album-art sizing and docking continue to use Configuration exactly
        // as in the established layout logic.
        if (mActivityContentRoot != null) {
            mActivityContentRoot.addOnLayoutChangeListener(
                (view, left, top, right, bottom,
                 oldLeft, oldTop, oldRight, oldBottom) -> {
                    if (top != oldTop || bottom != oldBottom
                            || right - left != oldRight - oldLeft) {
                        updateTimeVisibility();
                    }
                });
        }

        if (mAlbumArtContainer != null && mAlbumArtCache != null) {
            mAlbumArtCarousel = new AlbumArtCarousel(
                this, mAlbumArtContainer, mAlbumArtCache,
                mAlbumArtExecutor);
            mAlbumArtCarousel.setEdgeZonePx(
                dpToPx(VOLUME_GESTURE_EDGE_DP));
            mAlbumArtCarousel.setSwipeCommitListener(direction -> {
                if (direction > 0) {
                    playNextSong();
                } else if (direction < 0) {
                    playPreviousSong();
                }
            });
            mAlbumArtCarousel.attach();
        }

        applyAlbumArtClipping();
        setupAlbumArtGestures();

        final Typeface fontAwesomeTypeface =
            FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }
        if (mFavoriteButton != null) {
            mFavoriteButton.setTypeface(fontAwesomeTypeface);
            mFavoriteButton.setText(FontAwesome.HEART);
            mFavoriteButton.setTextSize(30);
            if (mThemeHelper != null) {
                mThemeHelper.updateControlButton(mFavoriteButton, true, false);
            }
        }
        if (mHomeButton != null) {
            mHomeButton.setTypeface(fontAwesomeTypeface);
            mHomeButton.setText(FontAwesome.HOME);
            mHomeButton.setTextSize(28);
            if (mThemeHelper != null) {
                mThemeHelper.updateControlButton(mHomeButton, true, false);
            }
        }

        if (mPlayButton != null) {
            mPlayButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mPrevButton != null) {
            mPrevButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mNextButton != null) {
            mNextButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }

        if (mManagerButton != null) {
            mManagerButton.setLetterSpacing(0.1f);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setLetterSpacing(0.1f);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setLetterSpacing(0.1f);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setLetterSpacing(0.1f);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setLetterSpacing(0.1f);
        }

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);
        animateButton(mFavoriteButton);
        animateButton(mHomeButton);

        applyAlbumArtSize(getResources().getConfiguration());

        loadAndDisplayPlaceholder();
        refreshTransportControls();
    }

    /**
     * Pulls the full display snapshot from the bound service and
     * writes it directly, without waiting for the next broadcast.
     *
     * <p>This is the instant-sync pull. {@code UPDATE_PLAYER} is
     * posted, not sticky, so a player that was destroyed or
     * backgrounded while a metadata edit, sort, scope, or favourite
     * change broadcast missed that broadcast. The pull on return
     * writes title, artist, seek-bar max, and seek-bar position
     * from the same service snapshot, along with the carousel
     * window and the transport controls, so all of them stay
     * in step.</p>
     *
     * <p>It deliberately does nothing while a transition is pending:
     * during PREPARING the service's display song is the target and
     * {@link MusicService#getCurrentSong()} is still the outgoing
     * song, so pulling then would flash the outgoing title. The
     * transition's own broadcast carries the correct display title,
     * and the explicit resync on resume covers it.</p>
     *
     * <p>Unlike the broadcast commit path, this pull does not go
     * through {@code postOnSettle}: a return to the foreground is
     * not a transition, the carousel is at rest, and the text must
     * land in this turn, not on the next settle frame.</p>
     */
    private void syncDisplayFromService() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (mMusicService == null || mAlbumArtCarousel == null) {
            return;
        }
        if (mMusicService.isTransitionPending()) {
            return;
        }
        final int scopedCount =
                mMusicService.getScopedPlaylistSize();
        if (scopedCount == 0) {
            // Match the broadcast path: mark the empty scope first
            // so the empty-state broadcast this triggers does not
            // re-apply the empty state a second time.
            mScopeEmpty = true;
            applyNoSongState();
            return;
        }
        final Song currentSong = mMusicService.getCurrentSong();
        if (currentSong == null) {
            refreshCarouselFromService();
            refreshTransportControls();
            return;
        }
        final String title = currentSong.getTitle();
        final String artist = currentSong.getArtist();
        final int positionMs = mMusicService.getCurrentPosition();
        final int durationMs = mMusicService.getDuration();
        final long generation = mMusicService.getGeneration();
        if (generation >= 0 && generation > mLastSeenGeneration) {
            mLastSeenGeneration = generation;
        }
        // Carousel window first, so art and text come from the same
        // service snapshot.
        refreshCarouselFromService();
        if (mSongTitle != null && title != null) {
            mSongTitle.setText(title);
            if (mThemeHelper != null) {
                mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
            }
        }
        if (mSongArtist != null && artist != null) {
            mSongArtist.setText(artist);
            mSongArtist.setTextColor(
                    Color.parseColor("#C0C0C0"));
        }
        if (mSeekBar != null && mSeekBar.isEnabled()
                && durationMs > 0) {
            if (mSeekBar.getMax() != durationMs) {
                mSeekBar.setMax(durationMs);
            }
            mSeekBar.setProgress(positionMs);
        }
        if (mSeekTime != null) {
            mSeekTime.setText(formatTime(positionMs));
        }
        if (mTotalTime != null) {
            mTotalTime.setText(formatTime(durationMs));
        }
        refreshTransportControls();
    }

    /**
     * Refreshes the carousel's window from the bound service.
     */
    private void refreshCarouselFromService() {
        if (mMusicService == null || mAlbumArtCarousel == null) {
            return;
        }
        mAlbumArtCarousel.setWindow(
            mMusicService.getWindowSnapshot(), 0, false);
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN)
                            .scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL)
                            .scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(
                                BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Split-Screen Layout
    // ============================================================================

    /**
     * Applies the album-art size and visibility for the current
     * window height, then hands the resulting docking and
     * sharing decision to {@link #applySongInfoLayout}.
     *
     * @param config Configuration carrying the current window height
     */
    private void applyAlbumArtSize(@NonNull Configuration config) {
        if (mAlbumArtContainer == null) {
            return;
        }

        final int heightDp = config.screenHeightDp;
        final int sizeDp;
        final int visibility;

        if (heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP) {
            sizeDp = ALBUM_ART_FULL_DP;
            visibility = View.VISIBLE;
        } else if (heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP) {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.VISIBLE;
        } else {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.GONE;
        }

        final int sizePx = dpToPx(sizeDp);
        final ViewGroup.LayoutParams params =
            mAlbumArtContainer.getLayoutParams();
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx;
            params.height = sizePx;
            mAlbumArtContainer.setLayoutParams(params);
        }
        if (mAlbumArtContainer.getVisibility() != visibility) {
            mAlbumArtContainer.setVisibility(visibility);
        }

        final boolean albumArtHidden = visibility == View.GONE;
        // The docked row needs width, so it only applies in a
        // short landscape window that is wide enough for the
        // group and the transport row side by side. A narrow
        // landscape window, such as landscape split-screen,
        // falls back to the stacked portrait layout instead of
        // cramping.
        final boolean dockSongInfo = albumArtHidden
                && config.orientation == Configuration.ORIENTATION_LANDSCAPE
                && config.screenWidthDp >= DOCK_MIN_WIDTH_DP;
        // A short window that is not docked uses the stacked
        // layout with the song-info group and the seek-bar
        // section sharing the space between the top bar and
        // the transport row. That is short portrait
        // split-screen, and short, narrow landscape
        // split-screen — the same evaluation in both, not a
        // landscape-only rule.
        final boolean shareSpace =
            albumArtHidden && !dockSongInfo;
        applySongInfoLayout(albumArtHidden, dockSongInfo,
            shareSpace);

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.onContainerResized();
        }
    }

    /**
     * Positions the title-and-artist group and the transport row for
     * the current album-art visibility.
     *
     * <p>The XML baseline is the shape for every undocked case:
     * the song-info group and the seek-bar section each take 0dp
     * height with weight 1, a 12dp gap separates them
     * ({@link #SONG_INFO_SEEK_BAR_GAP_DP} as the seek-bar
     * section's top margin), and the seek-bar section carries
     * centre-vertical gravity so its contents sit centred in
     * their half. This method therefore works only on the
     * surfaces that depend on runtime state: the album-art
     * wrapper's visibility, the docked-versus-undocked row
     * shape, the transport row's toast-lane padding, and the
     * timer row's fit within the seek-bar section's measured
     * share. Undocking restores the seek-bar section's saved
     * layout params, so the XML baseline, including the 12dp
     * gap, returns with the section.</p>
     *
     * @param albumArtHidden True when the album art is
     *        {@link View#GONE}
     * @param dockSongInfo True when the song-info group should sit
     *        beside the transport row
     * @param shareSpace True when the song-info group and
     *        the seek-bar section share the space equally, in a
     *        short window that is not docked
     */
    private void applySongInfoLayout(boolean albumArtHidden,
                                     boolean dockSongInfo,
                                     boolean shareSpace) {
        if (mAlbumArtWrapper != null) {
            final int wrapperVisibility =
                albumArtHidden ? View.GONE : View.VISIBLE;
            if (mAlbumArtWrapper.getVisibility()
                    != wrapperVisibility) {
                mAlbumArtWrapper.setVisibility(wrapperVisibility);
            }
        }

        setSongInfoDocked(dockSongInfo);

        // The XML minimum protects the title/artist stack in normal layouts.
        // In a very short, stacked split-screen window, retain only the
        // 48dp control-group height. The title/artist column is also fixed
        // at 48dp so it stays aligned with the home/favourite buttons.
        if (mSongInfoGroup != null) {
            final int desiredMinimumHeight = shareSpace
                ? dpToPx(SONG_INFO_BUTTON_GROUP_HEIGHT_DP)
                : dpToPx(80);
            if (mSongInfoGroup.getMinimumHeight()
                    != desiredMinimumHeight) {
                mSongInfoGroup.setMinimumHeight(desiredMinimumHeight);
            }
        }

        if (mTransportRow != null) {
            // A docked transport row hugs its buttons: the bottom
            // padding would push the buttons to the top of the row.
            // Its bottom padding is zero while docked because the
            // toast lane is the docked row's 48dp bottom margin,
            // not padding. Undocked, the bottom padding is the
            // toast lane: 48dp with the art hidden, the layout's
            // 64dp with the art visible.
            final int desiredBottomPadding = dockSongInfo
                ? 0
                : albumArtHidden
                    ? dpToPx(TRANSPORT_ROW_SPLIT_BOTTOM_DP)
                    : mDefaultTransportPaddingBottom;
            if (mTransportRow.getPaddingBottom()
                    != desiredBottomPadding) {
                mTransportRow.setPadding(
                    mTransportRow.getPaddingLeft(),
                    mTransportRow.getPaddingTop(),
                    mTransportRow.getPaddingRight(),
                    desiredBottomPadding);
            }
        }

        if (mSeekBarSection != null) {
            mSeekBarSection.post(this::updateTimeVisibility);
        }
    }

    /**
     * Moves the song-info group into a horizontal row beside the
     * transport row, or restores it to its own row above the seek
     * bar. The two share the docked row with 0.5 weight each —
     * group first, then the transport row. The docked row hugs
     * its content and carries a 48dp bottom margin: the toast
     * lane, reserved between the side-by-side row and the bottom
     * buttons. The transport row's bottom padding stays zero
     * while docked so the lane is the margin, not padding. The
     * seek-bar section takes what is left — weight 1, its content
     * centred. The group's, the transport row's and the seek-bar
     * section's original indices, layout params and gravity are
     * restored on undock.
     *
     * @param dock True to dock the group beside the transport
     *        row, false to restore it
     */
    private void setSongInfoDocked(boolean dock) {
        if (mSongInfoGroup == null || mTransportRow == null) {
            return;
        }
        if (dock == mSongInfoDocked) {
            return;
        }

        if (dock) {
            final ViewGroup root =
                    (ViewGroup) mSongInfoGroup.getParent();
            if (root == null) {
                return;
            }
            mSongInfoRootIndex = root.indexOfChild(mSongInfoGroup);
            mTransportRootIndex = root.indexOfChild(mTransportRow);
            if (mSongInfoRootIndex < 0 || mTransportRootIndex < 0) {
                return;
            }
            mSongInfoRootParams = mSongInfoGroup.getLayoutParams();
            mTransportRootParams = mTransportRow.getLayoutParams();

            if (mSeekBarSection != null) {
                mSeekBarSectionRootParams =
                    mSeekBarSection.getLayoutParams();
                // The seek-bar section takes what is left: the
                // side-by-side row, the toast lane, the bottom
                // buttons and the 16dp to the edge stay in place,
                // and this section absorbs the rest, its content
                // centred in it.
                mSeekBarSection.setLayoutParams(
                    new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        0,
                        1f));
                mSeekBarSection.setGravity(
                    Gravity.CENTER_VERTICAL);
            }

            if (mSongInfoDockRow == null) {
                final LinearLayout dockRow = new LinearLayout(this);
                dockRow.setOrientation(LinearLayout.HORIZONTAL);
                dockRow.setGravity(Gravity.CENTER_VERTICAL);
                // The docked row hugs its content. Its bottom
                // margin is the toast lane: 48dp, the same lane
                // as split view, reserved between the
                // side-by-side row and the bottom buttons.
                final LinearLayout.LayoutParams dockRowParams =
                    new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                dockRowParams.bottomMargin =
                    dpToPx(TRANSPORT_ROW_SPLIT_BOTTOM_DP);
                dockRow.setLayoutParams(dockRowParams);
                mSongInfoDockRow = dockRow;
            }

            root.removeView(mSongInfoGroup);
            root.removeView(mTransportRow);

            // The transport row sat after the song-info group, so
            // removing the group shifts its slot up by one.
            final int dockRowIndex = mTransportRootIndex
                    - (mSongInfoRootIndex < mTransportRootIndex ? 1 : 0);
            root.addView(mSongInfoDockRow, dockRowIndex);

            final LinearLayout.LayoutParams songInfoParams =
                    new LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            0.5f);
            songInfoParams.gravity = Gravity.CENTER_VERTICAL;
            mSongInfoDockRow.addView(mSongInfoGroup, songInfoParams);

            final LinearLayout.LayoutParams transportParams =
                    new LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            0.5f);
            transportParams.gravity = Gravity.CENTER_VERTICAL;
            mSongInfoDockRow.addView(mTransportRow, transportParams);
        } else {
            final ViewGroup dockRow =
                    (ViewGroup) mSongInfoGroup.getParent();
            if (dockRow == null || mSongInfoDockRow == null
                    || dockRow != mSongInfoDockRow) {
                return;
            }
            final ViewGroup root = (ViewGroup) dockRow.getParent();
            if (root == null || mSongInfoRootParams == null
                    || mTransportRootParams == null
                    || mSongInfoRootIndex < 0
                    || mTransportRootIndex < 0) {
                return;
            }
            dockRow.removeView(mSongInfoGroup);
            dockRow.removeView(mTransportRow);
            root.removeView(dockRow);

            if (mSeekBarSection != null
                    && mSeekBarSectionRootParams != null) {
                mSeekBarSection.setLayoutParams(
                    mSeekBarSectionRootParams);
                mSeekBarSection.setGravity(
                    mDefaultSeekBarSectionGravity);
            }

            // Re-add in ascending index order: each earlier
            // insertion restores the slot the later index assumed.
            root.addView(mSongInfoGroup, mSongInfoRootIndex,
                    mSongInfoRootParams);
            root.addView(mTransportRow, mTransportRootIndex,
                    mTransportRootParams);
        }

        mSongInfoDocked = dock;
    }

    /**
     * Shows the timer row only when the seek-bar section can show
     * it in full.
     *
     * <p>In every undocked case the section holds half the space
     * between the top bar and the transport row at weight 1, so
     * its measured height is compared with what the row needs.
     * When the section is shorter, the row is hidden and its top
     * margin is zeroed on the same turn, so the SeekBar stays
     * centred in its share without an empty gap below it. When
     * space returns, the row and its margin return. A half-cut
     * timer never shows.</p>
     *
     * <p>The check compares the predicted timer bottom against
     * the actual visible activity window, not only against the
     * seek-bar section's own height, which prevents the row from
     * being clipped by the bottom of the screen in split-screen
     * landscape.</p>
     */
    private void updateTimeVisibility() {
        if (mSeekBarSection == null
                || mSeekBar == null
                || mTimeRow == null) {
            return;
        }

        final ViewGroup.LayoutParams sectionParams =
            mSeekBarSection.getLayoutParams();
        final boolean constrained =
            sectionParams instanceof LinearLayout.LayoutParams
                && ((LinearLayout.LayoutParams) sectionParams).height == 0
                && ((LinearLayout.LayoutParams) sectionParams).weight > 0f;

        // Measure at the current width on every pass. This is important after
        // split-screen resizing and also lets a GONE row be reconsidered.
        final int sectionWidth = mSeekBarSection.getWidth()
            - mSeekBarSection.getPaddingLeft()
            - mSeekBarSection.getPaddingRight();
        if (sectionWidth <= 0) {
            mSeekBarSection.post(this::updateTimeVisibility);
            return;
        }
        final int widthSpec = View.MeasureSpec.makeMeasureSpec(
            sectionWidth, View.MeasureSpec.EXACTLY);
        final int heightSpec = View.MeasureSpec.makeMeasureSpec(
            0, View.MeasureSpec.UNSPECIFIED);
        mTimeRow.measure(widthSpec, heightSpec);
        final int timerHeight = mTimeRow.getMeasuredHeight();
        final int seekBarHeight = mSeekBar.getHeight();
        if (timerHeight <= 0 || seekBarHeight <= 0) {
            mSeekBarSection.post(this::updateTimeVisibility);
            return;
        }

        // Always evaluate with the designed 8dp gap, even while the row is
        // GONE (its actual margin is zero then). Otherwise a hidden row could
        // pass using the smaller requirement, reappear, and immediately fail.
        final int timerTopMargin = dpToPx(8);
        final ViewGroup.LayoutParams timerParams =
            mTimeRow.getLayoutParams();

        final int needed = seekBarHeight + timerTopMargin + timerHeight
            + mSeekBarSection.getPaddingTop()
            + mSeekBarSection.getPaddingBottom();

        boolean fits = true;

        // 1. Check against the actual window bounds if possible.
        // In split-screen landscape, the layout might allocate space
        // that is physically cut off by the window edge.
        if (mActivityContentRoot != null
                && mActivityContentRoot.getHeight() > 0) {
            final int[] rootLocation = new int[2];
            final int[] seekLocation = new int[2];
            mActivityContentRoot.getLocationInWindow(rootLocation);
            mSeekBar.getLocationInWindow(seekLocation);
            final int timerBottomInWindow = seekLocation[1]
                + seekBarHeight + timerTopMargin + timerHeight;
            final int contentBottomInWindow = rootLocation[1]
                + mActivityContentRoot.getHeight()
                - mActivityContentRoot.getPaddingBottom();
            if (timerBottomInWindow > contentBottomInWindow) {
                fits = false;
            }
        }

        // 2. Check against the section height (if constrained by weight).
        if (fits && constrained) {
            final int sectionHeight = mSeekBarSection.getHeight();
            if (sectionHeight <= 0) {
                mSeekBarSection.post(this::updateTimeVisibility);
                return;
            }
            if (needed > sectionHeight) {
                fits = false;
            }
        }

        final int desiredVisibility = fits ? View.VISIBLE : View.GONE;
        // Margin is part of the timer's fit requirement. Keep it in sync
        // independently of visibility: previously it was only updated when the
        // visibility changed, allowing stale spacing to survive a resize pass.
        if (timerParams instanceof LinearLayout.LayoutParams) {
            final LinearLayout.LayoutParams lp =
                (LinearLayout.LayoutParams) timerParams;
            final int desiredTopMargin = desiredVisibility == View.GONE
                ? 0 : dpToPx(8);
            if (lp.topMargin != desiredTopMargin) {
                lp.topMargin = desiredTopMargin;
                mTimeRow.setLayoutParams(lp);
            }
        }
        if (mTimeRow.getVisibility() != desiredVisibility) {
            mTimeRow.setVisibility(desiredVisibility);
            // Re-evaluate after the visibility/margin change has completed a
            // layout pass, using the final split-screen bounds.
            mSeekBarSection.post(this::updateTimeVisibility);
        }
    }

    // ============================================================================
    // Album-Art Gestures
    // ============================================================================

    /**
     * Attaches the gesture listener to the album-art container.
     */
    private void setupAlbumArtGestures() {
        if (mAlbumArtContainer == null) {
            return;
        }
        mAlbumArtContainer.setOnTouchListener(
            new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                return handleAlbumArtGesture(view, event);
            }
        });
    }

    /**
     * Dispatches a touch event on the album-art container through
     * the gesture classifier and the selected mode's handler.
     */
    private boolean handleAlbumArtGesture(@NonNull View view,
                                          @NonNull MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return handleGestureDown(view, event);
            case MotionEvent.ACTION_MOVE:
                return handleGestureMove(view, event);
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return handleGestureUp(view, event);
            default:
                return false;
        }
    }

    /**
     * Handles the start of a touch sequence on the album-art
     * container.
     */
    private boolean handleGestureDown(@NonNull View view,
                                      @NonNull MotionEvent event) {
        mGestureState = GestureState.TOUCHED;
        mGestureStartX = event.getX();
        mGestureStartY = event.getY();
        mGestureContainerWidth = Math.max(1, view.getWidth());
        mGestureContainerHeight = Math.max(1, view.getHeight());

        if (mAudioManager != null) {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume > 0) {
                mVolumeGestureMaxVolume = maxVolume;
                mVolumeGestureStartVolume =
                    mAudioManager.getStreamVolume(
                        AudioManager.STREAM_MUSIC);
            } else {
                mVolumeGestureMaxVolume = 0;
                mVolumeGestureStartVolume = 0;
            }
        } else {
            mVolumeGestureMaxVolume = 0;
            mVolumeGestureStartVolume = 0;
        }

        mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
        mVolumeGestureLimitEchoBaseline = Float.NaN;

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    /**
     * Handles a move event on the album-art container.
     */
    private boolean handleGestureMove(@NonNull View view,
                                      @NonNull MotionEvent event) {
        if (mGestureState == GestureState.TOUCHED) {
            classifyGesture(event);
        }

        switch (mGestureState) {
            case CAROUSEL:
                if (mAlbumArtCarousel != null) {
                    final float horizontalDisplacement =
                        event.getX() - mGestureStartX;
                    mAlbumArtCarousel.updateSwipe(
                        horizontalDisplacement);
                }
                return true;
            case VOLUME:
                handleVolumeDrag(event);
                return true;
            case PLAYBACK:
                return true;
            case CANCELLED:
            case TOUCHED:
            default:
                return true;
        }
    }

    /**
     * Handles the release of a touch sequence on the album-art
     * container.
     */
    private boolean handleGestureUp(@NonNull View view,
                                    @NonNull MotionEvent event) {
        if (mGestureState == GestureState.CAROUSEL
                && mAlbumArtCarousel != null) {
            final float horizontalDisplacement =
                (event.getActionMasked() == MotionEvent.ACTION_CANCEL)
                    ? 0f
                    : event.getX() - mGestureStartX;
            mAlbumArtCarousel.endSwipe(horizontalDisplacement);
            cancelReturnHome();
        } else if (mGestureState == GestureState.PLAYBACK
                && event.getActionMasked() == MotionEvent.ACTION_UP) {
            handlePlaybackGesture(event.getY() - mGestureStartY);
        } else if (mGestureState == GestureState.TOUCHED
                && event.getActionMasked() == MotionEvent.ACTION_UP) {
            final long tapTime = event.getEventTime();
            if (tapTime - mLastTapTime
                    <= ViewConfiguration.getDoubleTapTimeout()) {
                handleGestureDoubleTap();
                mLastTapTime = 0L;
            } else {
                mLastTapTime = tapTime;
            }
        }

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }

        mGestureState = GestureState.TOUCHED;
        return true;
    }

    /**
     * Handles a double-tap on the album-art container by toggling
     * the current song's favorite flag and showing the
     * corresponding toast.
     */
    private void handleGestureDoubleTap() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            final Song current = mMusicService.getCurrentSong();
            if (current == null) {
                return;
            }
            final boolean newFavorite = !current.isFavorite();
            mMusicService.toggleFavorite();
            refreshTransportControls();
            ToastManager.showToast(MusicPlayer.this,
                getString(newFavorite
                    ? R.string.player_toast_favorite_on
                    : R.string.player_toast_favorite_off),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Classifies a gesture on the first significant move.
     */
    private void classifyGesture(@NonNull MotionEvent event) {
        final float horizontalDisplacement =
            event.getX() - mGestureStartX;
        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float absoluteHorizontal =
            Math.abs(horizontalDisplacement);
        final float absoluteVertical =
            Math.abs(verticalDisplacement);
        final int touchSlop = ViewConfiguration.get(this)
            .getScaledTouchSlop();

        if (absoluteHorizontal < touchSlop
                && absoluteVertical < touchSlop) {
            return;
        }

        if (absoluteHorizontal > absoluteVertical) {
            mGestureState = GestureState.CAROUSEL;
            if (mAlbumArtCarousel != null) {
                mAlbumArtCarousel.beginSwipe();
            }
            return;
        }

        final int edgeZone = dpToPx(VOLUME_GESTURE_EDGE_DP);
        final boolean startedInEdge =
            mGestureStartX <= edgeZone
                || mGestureStartX >= mGestureContainerWidth - edgeZone;
        if (startedInEdge) {
            mGestureState = (mVolumeGestureMaxVolume > 0)
                ? GestureState.VOLUME
                : GestureState.CANCELLED;
            return;
        }

        mGestureState = GestureState.PLAYBACK;
    }

    /**
     * Applies a vertical drag to the music stream volume.
     */
    private void handleVolumeDrag(@NonNull MotionEvent event) {
        if (mAudioManager == null || mVolumeGestureMaxVolume <= 0) {
            return;
        }

        final float verticalDisplacement =
            event.getY() - mGestureStartY;
        final float fraction =
            -verticalDisplacement / mGestureContainerHeight;
        final float unclampedTarget = mVolumeGestureStartVolume
            + fraction * mVolumeGestureMaxVolume;
        int targetVolume = Math.round(unclampedTarget);
        targetVolume = Math.max(0,
            Math.min(mVolumeGestureMaxVolume, targetVolume));

        final int currentVolume = mAudioManager.getStreamVolume(
            AudioManager.STREAM_MUSIC);

        if (targetVolume == mVolumeGestureMaxVolume) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MAXIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MAXIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else if (targetVolume == 0) {
            if (mVolumeGestureLimitSide
                    != VOLUME_LIMIT_SIDE_MINIMUM) {
                mVolumeGestureLimitSide =
                    VOLUME_LIMIT_SIDE_MINIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else {
            mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
            mVolumeGestureLimitEchoBaseline = Float.NaN;
        }

        if (targetVolume != currentVolume) {
            try {
                mAudioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC, targetVolume, 0);
                showVolumeToast(targetVolume);
            } catch (SecurityException exception) {
                Log.w(TAG, "setStreamVolume refused", exception);
            }
            // Drag-to-max follows the same resume rule as
            // volume-up at maximum.
            if (targetVolume == mVolumeGestureMaxVolume) {
                if (resumeIfPausedAtMaxVolume()) {
                    refreshTransportControls();
                }
            }
            if (targetVolume == mVolumeGestureMaxVolume) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f,
                        unclampedTarget - mVolumeGestureMaxVolume);
            } else if (targetVolume == 0) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f, -unclampedTarget);
            }
            return;
        }

        final float echoStep = Math.max(1f,
            mVolumeGestureMaxVolume * VOLUME_LIMIT_ECHO_STEP_FRACTION);

        if (targetVolume == mVolumeGestureMaxVolume
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MAXIMUM) {
            // Still at max and still dragging up: apply the
            // volume-up-at-maximum resume rule.
            if (resumeIfPausedAtMaxVolume()) {
                refreshTransportControls();
            }
            final float overshoot =
                unclampedTarget - mVolumeGestureMaxVolume;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        } else if (targetVolume == 0
                && mVolumeGestureLimitSide
                    == VOLUME_LIMIT_SIDE_MINIMUM) {
            final float overshoot = -unclampedTarget;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        }
    }

    /**
     * Applies a completed centre-vertical swipe to the playback
     * state.
     */
    private void handlePlaybackGesture(float verticalDisplacement) {
        final int threshold = ViewConfiguration.get(this)
            .getScaledTouchSlop() * 2;
        if (Math.abs(verticalDisplacement) < threshold) {
            return;
        }

        cancelReturnHome();

        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            try {
                if (verticalDisplacement < 0) {
                    if (!mMusicService.isPlaying()
                            && resumeIfPausedAndFocused(
                                false, "upward playback swipe")) {
                        refreshTransportControls();
                    }
                } else {
                    if (mMusicService.isPlaying()) {
                        mMusicService.togglePlayPause();
                        refreshTransportControls();
                    }
                }
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to handle playback gesture", exception);
            }
        }
    }

    /**
     * Detects actual music-volume changes and applies the
     * maximum-volume playback-resume rule.
     */
    private void handleObservedMusicVolumeChange() {
        if (mAudioManager == null) {
            return;
        }
        final int currentVolume = mAudioManager.getStreamVolume(
            AudioManager.STREAM_MUSIC);
        if (currentVolume == mLastObservedMusicVolume) {
            return;
        }
        mLastObservedMusicVolume = currentVolume;

        resumeIfPausedAtMaxVolume();
    }

    /**
     * Shows a transient toast reporting the current volume as a
     * percentage.
     */
    private void showVolumeToast(int volumeLevel) {
        if (mVolumeGestureMaxVolume <= 0) {
            return;
        }
        final int percent = Math.round(
            100f * volumeLevel / mVolumeGestureMaxVolume);
        ToastManager.showToast(this,
            getString(R.string.player_toast_volume, percent),
            ToastManager.LENGTH_NORMAL);
    }

    // ============================================================================
    // Permission and Initialization Methods
    // ============================================================================

    /**
     * Requests the runtime permissions the app needs and proceeds
     * with initialization once they have been decided.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            proceedWithInitialization();
            return;
        }

        final String[] permissionsToRequest =
            PermissionChecker.getMissing(this);

        if (permissionsToRequest.length > 0) {
            requestPermissions(
                permissionsToRequest, PERMISSION_REQUEST_CODE);
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Runs the initialization path once permissions have been
     * decided.
     */
    private void proceedWithInitialization() {
        mInitializationAttempted = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        preloadLastSongDisplay();

        if (mMusicService != null && mIsServiceBound) {
            loadFullPlaylistInBackground();
            handleIncomingFile(getIntent());
            return;
        }

        final Intent serviceIntent = new Intent(
            MusicPlayer.this, MusicService.class);
        startService(serviceIntent);

        final boolean bound = bindService(
            serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        if (!bound) {
            Log.e(TAG, "bindService refused; abandoning library load");
            abandonLibraryLoadOverlay(MESSAGE_SERVICE_BIND_FAILED);
            return;
        }

        handleIncomingFile(getIntent());
    }

    /**
     * Requests an exemption from battery optimizations when the app
     * is not yet exempt.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager =
                (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null
                    && !powerManager.isIgnoringBatteryOptimizations(
                        getPackageName())) {
                try {
                    Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(
                        Uri.parse("package:" + getPackageName()));
                    startActivityForResult(
                        intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG,
                        "Failed to request battery optimization",
                        exception);
                }
            }
        }
    }

    // ============================================================================
    // Incoming File Handling
    // ============================================================================

    /**
     * Handles an incoming audio file reference.
     *
     * @param intent The intent that triggered the activity, or null
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        if (isSongInLibrary(filePath)) {
            Log.d(TAG, "Song is already in the library");
            handOffIncomingPath(filePath);
            return;
        }

        Log.d(TAG, "New song detected; adding as a loose track");

        handOffIncomingPath(filePath);

        preDecodeIncomingArt(filePath);

        final Song newSong = parseIncomingSong(filePath);
        insertLooseTrackAndHandOff(newSong);
    }

    /**
     * Returns whether the given path is already known to the library.
     */
    private boolean isSongInLibrary(@NonNull String filePath) {
        if (SongDatabase.getInstance(this).hasSong(filePath)) {
            return true;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (looseSong != null
                        && filePath.equals(looseSong.getPath())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Parses the metadata for an incoming file, falling back to the
     * file name when {@link CharacterMapper} cannot read the embedded
     * tags.
     */
    @NonNull
    private Song parseIncomingSong(@NonNull String filePath) {
        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        if (parsedSong != null) {
            return parsedSong;
        }
        String fileName = new File(filePath).getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            fileName = fileName.substring(0, dotIndex);
        }
        return new Song(
            fileName,
            null,
            null,
            null,
            filePath,
            0,
            null);
    }

    /**
     * Inserts the given song as a loose track and hands the path to
     * the service once the insertion completes.
     */
    private void insertLooseTrackAndHandOff(
            @NonNull final Song newSong) {
        final String filePath = newSong.getPath();

        PlaylistManager.getInstance(this).addLooseTrackAndUpdate(
            newSong,
            new PlaylistManager.UpdateCallback() {

            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Loose track inserted: " + filePath);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG,
                    "Failed to insert loose track: " + error);
                mPendingIncomingPath = null;
                if (mMusicService != null && mIsServiceBound) {
                    mMusicService.clearPendingSongPath();
                }
                ToastManager.showToast(MusicPlayer.this,
                    getString(R.string.folder_manager_error, error),
                    ToastManager.LENGTH_NORMAL);
            }
        });
    }

    /**
     * Hands the given path to the service as the target of the next
     * transition.
     */
    private void handOffIncomingPath(@NonNull String filePath) {
        Log.d(TAG, "Handing off incoming path: " + filePath);

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.requestIncomingFile(filePath);
            return;
        }

        mPendingIncomingPath = filePath;
    }

    /**
     * Decodes the given file's embedded art on the metadata loader
     * and hands the bitmap to the carousel when it resolves.
     */
    private void preDecodeIncomingArt(@NonNull final String filePath) {
        if (mMetadataLoader == null || mMetadataLoader.isShutdown()) {
            return;
        }
        mMetadataLoader.execute(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                loadSongMetadata(filePath);

                final Bitmap decoded = (mAlbumArtCache != null)
                    ? mAlbumArtCache.get(filePath)
                    : null;
                if (decoded == null || decoded.isRecycled()) {
                    return;
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.onArtReady(
                                filePath, decoded);
                        }
                    }
                });
            }
        });
    }

    // ============================================================================
    // URI Helper Methods
    // ============================================================================

    /**
     * Resolves the filesystem path of the given content URI.
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if (!"content".equals(uri.getScheme())) {
            return null;
        }

        String path = null;
        Cursor cursor = null;
        try {
            final String[] projection = {
                android.provider.MediaStore.Audio.Media.DATA
            };
            cursor = getContentResolver().query(uri, projection,
                null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int columnIndex =
                    cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Audio.Media
                            .DATA);
                path = cursor.getString(columnIndex);
            }
        } catch (Exception exception) {
            Log.w(TAG,
                "MediaStore query failed; falling back to copy",
                exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        if (path == null) {
            path = copyContentUriToTempFile(uri);
        }
        return path;
    }

    /**
     * Copies the content of the given URI to a temporary cache file.
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream =
                getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_"
                    + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream =
                new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies
     * inside the given folder.
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageAccessHelper == null) {
            return;
        }

        final String folderPath =
            mStorageAccessHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this)
                    .removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ============================================================================
    // Playlist Loading Methods
    // ============================================================================

    /**
     * Loads the full playlist on a background thread and hands it
     * to the bound service when the load completes.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) {
            return;
        }

        OverlayManager.show(OverlayManager.REASON_COLD_START);

        mMusicLibrary.loadAllSongsWithProgress(
            new MusicLibrary.LoadProgressListener() {

            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(
                        getString(MESSAGE_LIBRARY_LOAD),
                        "",
                        OPERATION_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(
                    @NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                }
                refreshCarouselFromService();
                refreshTransportControls();
                setupSeekBar();
                updateTimeDisplay();

                if (songs.isEmpty()
                        && mMusicLibrary != null
                        && !mMusicLibrary.getSelectedFolders().isEmpty()
                        && !isFinishing()
                        && !isDestroyed()) {
                    triggerAutomaticFolderUpdate();
                    return;
                }

                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Runs the folder-update scan automatically when the cold-start
     * load returns no songs but folders are configured.
     */
    private void triggerAutomaticFolderUpdate() {
        PlaylistManager.getInstance(this).updatePlaylist(
            new PlaylistManager.UpdateCallback() {
            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG, "Automatic folder update complete: "
                    + songCount + " songs");
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
                sendBroadcast(new Intent(
                    ACTION_UPDATE_PLAYLIST_FROM_FOLDERS));
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Automatic folder update failed: "
                    + error);
                ToastManager.hidePersistentOverlay(
                    OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is scheduled.
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        final long startedAt = SystemClock.elapsedRealtime();
        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                if (SystemClock.elapsedRealtime() - startedAt
                        > LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS) {
                    Log.w(TAG,
                        "Library load heartbeat deadline exceeded; "
                            + "abandoning overlay");
                    mLibraryHeartbeatRunnable = null;
                    abandonLibraryLoadOverlay(
                        MESSAGE_LIBRARY_LOAD_FAILED);
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(
                    this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(
            mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    /**
     * Abandons the library-load overlay and tells the user the
     * library could not be loaded.
     */
    private void abandonLibraryLoadOverlay(int messageRes) {
        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
        OverlayManager.hide(OverlayManager.REASON_COLD_START);
        if (!isFinishing() && !isDestroyed()) {
            ToastManager.showToast(this,
                getString(messageRes),
                ToastManager.LENGTH_NORMAL);
        }
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Runs the given UI update on the main thread, coalescing
     * requests that arrive while another update is in flight.
     *
     * <p>When the caller is already on the main thread and no other
     * update is in flight, the update runs synchronously. That is
     * the common case: EventBus subscribers use the default
     * {@code POSTING} mode and therefore run on the main looper,
     * {@link android.content.BroadcastReceiver#onReceive} runs on
     * the main looper, and click listeners run on the main looper.
     * Posting a runnable from any of those contexts only adds a
     * frame of latency without any benefit. The post path is kept
     * for updates that originate off the main thread.</p>
     *
     * <p>Coalescing is preserved in both paths: an update that
     * arrives while another is running is stashed on
     * {@link #mPendingUIUpdate} and executed once the in-flight
     * update finishes, so a burst of events collapses to one write
     * per surface.</p>
     *
     * @param update Update to run
     */
    private void updateUISafely(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (Looper.myLooper() == Looper.getMainLooper()
                && !mIsUpdatingUI.get()) {
            if (!mIsUpdatingUI.compareAndSet(false, true)) {
                mPendingUIUpdate = update;
                return;
            }
            try {
                if (!isFinishing() && !isDestroyed()) {
                    update.run();
                }
            } finally {
                mIsUpdatingUI.set(false);
                final Runnable pending = mPendingUIUpdate;
                if (pending != null) {
                    mPendingUIUpdate = null;
                    updateUISafely(pending);
                }
            }
            return;
        }

        if (!mIsUpdatingUI.compareAndSet(false, true)) {
            mPendingUIUpdate = update;
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate =
                            mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        updateUISafely(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Writes the given song's title and artist to the UI.
     *
     * @param song Song to display, or null
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle
                        : CharacterMapper.getUnknownTitle());
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText
                        : CharacterMapper.getUnknownArtist());
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshTransportControls();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Writes the given playing song's title and artist to the UI
     * and refreshes the album art.
     *
     * @param song Song that started playing, or null
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length()
                            > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle
                        : CharacterMapper.getUnknownTitle());
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length()
                                > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText
                        : CharacterMapper.getUnknownArtist());
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshCarouselFromService();
                refreshTransportControls();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Shows the empty state: placeholder title, placeholder artist,
     * placeholder album art, and disabled transport controls.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText(R.string.player_placeholder_title);
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText(R.string.player_placeholder_artist);
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.setWindow(PlaybackWindow.EMPTY, 0, false);
        }

        if (mAlbumArtContainer != null) {
            if (mPlaceholderBitmap != null
                    && !mPlaceholderBitmap.isRecycled()) {
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.setPlaceholder(
                        mPlaceholderBitmap);
                }
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
        }

        applyAlbumArtClipping();

        // A no-song state is not merely a disabled transport state:
        // discard the previous track's position and duration as well.
        // Disable first so no pending user interaction can seek the old
        // player while the empty-state values are being applied.
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
            if (mThemeHelper != null) {
                mThemeHelper.updateSeekBar(mSeekBar, false);
            }
            mSeekBar.setMax(100);
            mSeekBar.setProgress(0);
        }

        refreshTransportControls();

        if (mSeekTime != null) {
            mSeekTime.setText(R.string.player_time_zero);
        }
        if (mTotalTime != null) {
            mTotalTime.setText(R.string.player_time_zero);
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    /**
     * Returns the song path a {@code METADATA_UPDATED} event refers
     * to.
     */
    @Nullable
    private String resolveBroadcastSongPath(
            @Nullable String songPath,
            @Nullable String songUri) {
        if (songPath != null && !songPath.isEmpty()) {
            return songPath;
        }
        if (songUri == null || songUri.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && songUri.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }

    // ============================================================================
    // Playback Control Methods
    // ============================================================================

    /**
     * Runs the given service action on the main thread while holding
     * the service lock, when the service is bound.
     */
    private void callServiceSafely(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays the song at the given index and updates the UI.
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0
            && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles playback through the service when the library contains
     * songs.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null
                && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        callServiceSafely(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                    refreshTransportControls();
                }
            }
        });
    }

    /**
     * Asks the service to advance.
     */
    private void playNextSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playNextSong();
        }
    }

    /**
     * Asks the service to go back.
     */
    private void playPreviousSong() {
        synchronized (mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) {
                return;
            }
            mMusicService.playPreviousSong();
        }
    }

    // ============================================================================
    // Button State Update Methods
    // ============================================================================

    /**
     * Returns whether the transport controls may be enabled.
     */
    private boolean canEnableTransportControls() {
        return PermissionChecker.allGranted(this)
            && mMusicService != null
            && mIsServiceBound
            && mMusicService.getCurrentPlaylist() != null
            && !mMusicService.getCurrentPlaylist().isEmpty();
    }

    /**
     * Writes every transport control's enabled state, label, and
     * active tint from the current playback facts.
     *
     * <p>The writes are scheduled through
     * {@link #updateUISafely(Runnable)}, which runs them
     * synchronously when the caller is already on the main thread
     * and no other update is in flight. A transport refresh
     * therefore lands in the same main-thread turn as the call, with
     * no intermediate post, whether it originates from an EventBus
     * subscriber, a click handler, or a background callback that has
     * already hopped to the main thread.</p>
     *
     * <p>No explicit invalidate call is issued beyond the layout
     * pass the setters schedule: the buttons' own setText and
     * setBackground calls invalidate the views on the next frame.
     * An extra {@code postInvalidateOnAnimation} would only add a
     * second redraw behind the same vsync, and on slower input
     * pipelines that second redraw can be serialised behind the
     * animation callback scheduler, which is exactly the latency the
     * user reads as the button not responding.</p>
     */
    private void refreshTransportControls() {
        updateUISafely(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                boolean canEnable = canEnableTransportControls();
                boolean isPlaying = false;
                boolean isShuffleOn = false;
                boolean isFavorite = false;
                int repeatMode = 0;

                if (canEnable && mMusicService != null) {
                    try {
                        isPlaying =
                            mMusicService.getCurrentSong() != null
                                && mMusicService.isPlaying();
                        repeatMode = mMusicService.getRepeatMode();
                        isShuffleOn = mMusicService.isShuffle();
                        Song currentSong = mMusicService.getCurrentSong();
                        isFavorite = currentSong != null
                            && currentSong.isFavorite();
                    } catch (Exception exception) {
                        Log.e(TAG,
                            "Error reading playback state", exception);
                        canEnable = false;
                    }
                }

                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setText(isPlaying
                        ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mPlayButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mPlayButton, canEnable, canEnable);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mPrevButton, canEnable, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mNextButton, canEnable, false);
                }
                if (mRepeatButton != null && mThemeHelper != null) {
                    mRepeatButton.setText(repeatMode == 2
                        ? FontAwesome.REPEAT_ONE : FontAwesome.REPEAT);
                    mRepeatButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mRepeatButton, canEnable, repeatMode != 0);
                }
                if (mShuffleButton != null && mThemeHelper != null) {
                    mShuffleButton.setText(FontAwesome.SHUFFLE);
                    mShuffleButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mShuffleButton, canEnable, isShuffleOn);
                }
                if (mFavoriteButton != null && mThemeHelper != null) {
                    mFavoriteButton.setText(FontAwesome.HEART);
                    mFavoriteButton.setEnabled(canEnable);
                    mThemeHelper.updateControlButton(
                        mFavoriteButton, canEnable, isFavorite);
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(canEnable);
                    mThemeHelper.updateSeekBar(mSeekBar, canEnable);
                }
                if (mTransportRow != null) {
                    mTransportRow.requestLayout();
                    mTransportRow.invalidate();
                }
                if (mPlayButton != null) {
                    mPlayButton.invalidate();
                }
            }
        });
    }

    // ============================================================================
    // Seek Bar Methods
    // ============================================================================

    /**
     * Attaches the seek-bar change listener.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser && mMusicService != null
                        && seekBar.isEnabled()
                        && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts the periodic time-display update runnable.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mAlbumArtCarousel != null
                        && mAlbumArtCarousel.isAnimating()) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    // The service can still be finishing its reset after
                    // the UI has received LIBRARY_RESET. Do not let this
                    // periodic updater repaint the previous song's
                    // position while the service playlist is empty.
                    final ArrayList<Song> currentPlaylist =
                        service.getCurrentPlaylist();
                    if (currentPlaylist == null
                            || currentPlaylist.isEmpty()) {
                        if (mSeekBar != null) {
                            mSeekBar.setEnabled(false);
                            if (mThemeHelper != null) {
                                mThemeHelper.updateSeekBar(
                                    mSeekBar, false);
                            }
                            mSeekBar.setMax(100);
                            mSeekBar.setProgress(0);
                        }
                        if (mSeekTime != null) {
                            mSeekTime.setText(
                                R.string.player_time_zero);
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(
                                R.string.player_time_zero);
                        }
                        if (mTimeHandler != null) {
                            mTimeHandler.postDelayed(
                                this, TIME_UPDATE_INTERVAL_MS);
                        }
                        return;
                    }

                    int currentPosition =
                        service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong =
                            service.getCurrentSong();
                        if (currentSong != null
                                && currentSong.getDuration() > 0) {
                            duration =
                                (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(
                                formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(
                                formatTime(duration));
                        }

                        if (mSeekBar != null
                                && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display",
                        exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(
                        this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Returns the given duration formatted as {@code mm:ss} or
     * {@code hh:mm:ss}.
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        java.util.Locale appLocale = LanguageManager.getInstance(this)
            .getCurrentLocale();
        java.text.NumberFormat digits = java.text.NumberFormat
            .getIntegerInstance(appLocale);
        digits.setGroupingUsed(false);
        digits.setMinimumIntegerDigits(2);
        if (hours > 0) {
            return digits.format(hours) + ":" + digits.format(minutes)
                + ":" + digits.format(seconds);
        } else {
            return digits.format(minutes) + ":" + digits.format(seconds);
        }
    }

    // ============================================================================
    // Album Art Methods
    // ============================================================================

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested size.
     */
    private int calculateInSampleSize(
            @NonNull BitmapFactory.Options options,
            int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes the given image bytes with downsampling to the
     * requested size.
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth,
                                       int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(
            data, 0, data.length, options);

        options.inSampleSize =
            calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, options);
    }

    /**
     * Returns the path of the current song, or null when no song is
     * playing.
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null
                && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Loads and displays the current themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    // ============================================================================
    // Placeholder Methods
    // ============================================================================

    /**
     * Rebuilds the themed placeholder bitmap from the source image
     * and applies the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task =
            mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null
                                && !mOriginalPlaceholderBitmap
                                    .isRecycled()) {
                            tintedBitmap =
                                mOriginalPlaceholderBitmap.copy(
                                    Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options =
                            new BitmapFactory.Options();
                        options.inPreferredConfig =
                            Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap =
                            BitmapFactory.decodeResource(
                                getResources(),
                                R.drawable.album_art_placeholder,
                                options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null
                                        && !mOriginalPlaceholderBitmap
                                            .isRecycled()) {
                                    mOriginalPlaceholderBitmap
                                        .recycle();
                                }
                                mOriginalPlaceholderBitmap =
                                    tintedBitmap.copy(
                                        Bitmap.Config.ARGB_8888,
                                        true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(
                        themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null
                                        && !mPlaceholderBitmap
                                            .isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            if (mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.setPlaceholder(
                                    mPlaceholderBitmap);
                            }
                            applyAlbumArtClipping();
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG,
                        "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cancels any in-flight placeholder render task and recycles
     * the placeholder bitmaps.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            recycleBitmapSafely(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            recycleBitmapSafely(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Recycles the given bitmap, ignoring any exception.
     */
    private void recycleBitmapSafely(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ============================================================================
    // Album Art Clipping Methods
    // ============================================================================

    /**
     * Applies rounded-corner clipping and the container background
     * to the album art container.
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(
                new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(
                        View view,
                        android.graphics.Outline outline) {
                    final int radius =
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0,
                        view.getWidth(), view.getHeight(), radius);
                }
            });
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        } else {
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        }
    }

    // ============================================================================
    // Navigation Methods
    // ============================================================================

    /**
     * Opens the folder manager activity with the slide-left
     * transition.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the playlist activity with the slide-right transition.
     */
    private void openPlaylist() {
        final Intent intent =
            new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the metadata editor for the current song, or in the
     * awaiting state when no song is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent =
            new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path",
                currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra(
                    "song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Shows {@link CreditsDialog} and drives the content slide with
     * the existing {@code slide_out_down} and {@code slide_in_up}
     * animations.
     */
    private void showCreditsDialog() {
        final View mainContent = findViewById(android.R.id.content);
        if (mainContent == null || isFinishing() || isDestroyed()) {
            return;
        }

        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                mainContent.startAnimation(
                    AnimationUtils.loadAnimation(
                        MusicPlayer.this, R.anim.slide_out_down));
            }
        });

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dismissedDialog) {
                final View contentView = findViewById(android.R.id.content);
                if (contentView != null) {
                    contentView.startAnimation(
                        AnimationUtils.loadAnimation(
                            MusicPlayer.this, R.anim.slide_in_up));
                }
            }
        });

        dialog.show();
    }

    /**
     * Cancels the pending return-home gesture and restores the
     * Home button to its steady inactive state. Idempotent.
     */
    private void cancelReturnHome() {
        mHomeConfirmState = HomeConfirmState.IDLE;
        mLastHomeClickTime = 0L;
        if (mHomeReturnRunnable != null) {
            mMainHandler.removeCallbacks(mHomeReturnRunnable);
            mHomeReturnRunnable = null;
        }
        if (mThemeHelper != null && mHomeButton != null) {
            mThemeHelper.updateControlButton(
                mHomeButton, true, false);
        }
    }

    /**
     * Enters the ARMED phase of the return-home gesture.
     */
    private void enterArmedState(long tapTime) {
        mHomeConfirmState = HomeConfirmState.ARMED;
        mLastHomeClickTime = tapTime;

        if (mThemeHelper != null) {
            mThemeHelper.updateControlButton(
                mHomeButton, true, true);
        }

        ToastManager.showToast(this,
            getString(R.string.player_return_home),
            ToastManager.LENGTH_NORMAL);

        mHomeReturnRunnable = new Runnable() {
            @Override
            public void run() {
                mHomeReturnRunnable = null;
                if (mHomeConfirmState != HomeConfirmState.ARMED) {
                    return;
                }
                mHomeConfirmState = HomeConfirmState.IDLE;
                mLastHomeClickTime = 0L;
                if (mThemeHelper != null && mHomeButton != null) {
                    mThemeHelper.updateControlButton(
                        mHomeButton, true, false);
                }
            }
        };
        mMainHandler.postDelayed(
            mHomeReturnRunnable, HOME_CONFIRM_WINDOW_MS);
    }

    /**
     * Enters the CONFIRMED phase of the return-home gesture.
     */
    private void enterConfirmedState() {
        mHomeConfirmState = HomeConfirmState.CONFIRMED;

        ToastManager.hidePersistentOverlay();

        if (mThemeHelper != null) {
            mThemeHelper.updateButtonPendingState(
                mHomeButton, true, Color.parseColor("#E53935"));
        }

        mHomeReturnRunnable = new Runnable() {
            @Override
            public void run() {
                mHomeReturnRunnable = null;
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                if (mHomeConfirmState
                        != HomeConfirmState.CONFIRMED) {
                    return;
                }
                moveTaskToBack(true);
                mHomeConfirmState = HomeConfirmState.IDLE;
            }
        };
        mMainHandler.postDelayed(
            mHomeReturnRunnable, HOME_CONFIRM_DWELL_MS);
    }

    /**
     * Returns the current song from the service, or null when the
     * service is not bound.
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ============================================================================
    // Cold-Start Preload
    // ============================================================================

    /**
     * Paints the previous song's title, artist, and art before the
     * playlist loads.
     */
    private void preloadLastSongDisplay() {
        final SharedPreferences preferences = getSharedPreferences(
            PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(
            KEY_LAST_SONG_PATH, null);

        if (lastPath == null || !new File(lastPath).exists()) {
            applyNoSongState();
            return;
        }

        if (mSongTitle != null) {
            mSongTitle.setText(R.string.player_placeholder_title);
        }
        if (mSongArtist != null) {
            mSongArtist.setText(R.string.player_placeholder_artist);
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
        }

        mCurrentMetadataFuture =
            mMetadataLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                final Song loadedSong = loadSongMetadata(lastPath);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mScopeEmpty) {
                            return;
                        }
                        if (loadedSong != null
                                && mThemeHelper != null) {
                            mCachedLastSong = loadedSong;
                            if (mSongTitle != null) {
                                mSongTitle.setText(
                                    loadedSong.getTitle());
                                mSongTitle.setTextColor(
                                    mThemeHelper
                                        .getThemeColorInt());
                            }
                            if (mSongArtist != null) {
                                mSongArtist.setText(
                                    loadedSong.getArtist());
                                mSongArtist.setTextColor(
                                    Color.parseColor("#C0C0C0"));
                            }

                            final Bitmap cachedArt =
                                mAlbumArtCache != null
                                    ? mAlbumArtCache.get(lastPath)
                                    : null;
                            if (cachedArt != null
                                    && mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.onArtReady(
                                    lastPath, cachedArt);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                        } else {
                            applyNoSongState();
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the metadata for the given path from the database when
     * a usable cached entry exists, and from the file otherwise.
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong =
            SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null
                && !cachedSong.getTitle().isEmpty()
                && !CharacterMapper.isUnknownTitle(
                    cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: "
                + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = CharacterMapper.getUnknownArtist();
            }
            if (album == null) {
                album = CharacterMapper.getUnknownAlbum();
            }

            String genre = CharacterMapper.getUnknownGenre();
            Song databaseSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null
                    && databaseSong.getGenre() != null
                    && !CharacterMapper.isUnknownGenre(
                        databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
            } else {
                String fileGenre =
                    CharacterMapper.getGenre(lastPath);
                if (fileGenre != null
                        && !CharacterMapper.isUnknownGenre(fileGenre)) {
                    genre = fileGenre;
                }
            }

            Song resultSong = new Song(
                title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(
                    albumArt, MAX_ALBUM_ART_SIZE_PX,
                    MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: "
                + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Applies the current theme color to every control in the
     * activity and rebuilds the placeholder bitmap.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed()
                || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        OverlayManager.setColor(mThemeHelper.getThemeColorInt());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(
                mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(
                mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(
                mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(
                mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(
                mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mHomeButton != null) {
            if (mHomeConfirmState == HomeConfirmState.ARMED) {
                mThemeHelper.updateControlButton(
                    mHomeButton, true, true);
            } else if (mHomeConfirmState
                    == HomeConfirmState.CONFIRMED) {
                mThemeHelper.updateButtonPendingState(
                    mHomeButton, true,
                    Color.parseColor("#E53935"));
            } else {
                mThemeHelper.updateControlButton(
                    mHomeButton, true, false);
            }
        }

        refreshTransportControls();

        if (mSongTitle != null) {
            mSongTitle.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
        forceRedraw();
    }

    /**
     * Restarts the activity with the no-animation flag.
     */
    private void performUpdate() {
        final Intent restartIntent =
            new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every button click listener used by the activity,
     * each guarded by a debounce.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null
                                && mRepeatButton.isEnabled()) {
                            final int newMode =
                                (mMusicService.getRepeatMode() + 1)
                                    % 3;
                            mMusicService.setRepeatMode(newMode);
                            refreshTransportControls();
                            final int messageRes;
                            switch (newMode) {
                                case 0:
                                    messageRes = R.string
                                        .player_toast_repeat_off;
                                    break;
                                case 1:
                                    messageRes = R.string
                                        .player_toast_repeat_all;
                                    break;
                                default:
                                    messageRes = R.string
                                        .player_toast_repeat_one;
                                    break;
                            }
                            ToastManager.showToast(MusicPlayer.this,
                                getString(messageRes),
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null
                                && mShuffleButton.isEnabled()) {
                            final boolean newShuffle =
                                !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            refreshTransportControls();
                            ToastManager.showToast(MusicPlayer.this,
                                getString(newShuffle
                                    ? R.string.player_toast_shuffle_on
                                    : R.string.player_toast_shuffle_off),
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        cancelReturnHome();
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        cancelReturnHome();
                        showCreditsDialog();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        cancelReturnHome();
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        cancelReturnHome();
                        startActivity(new Intent(
                            MusicPlayer.this,
                            EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        cancelReturnHome();
                        openMetadataEditor();
                    }
                }
            });
        }

        if (mFavoriteButton != null) {
            mFavoriteButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cancelReturnHome();
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastFavoriteClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastFavoriteClickTime = currentTime;
                        callServiceSafely(new Runnable() {
                            @Override
                            public void run() {
                                if (mMusicService != null) {
                                    final Song currentSong =
                                        mMusicService.getCurrentSong();
                                    final boolean wasFavorite =
                                        currentSong != null
                                            && currentSong.isFavorite();
                                    mMusicService.toggleFavorite();
                                    refreshTransportControls();
                                    ToastManager.showToast(
                                        MusicPlayer.this,
                                        getString(wasFavorite
                                            ? R.string
                                                .player_toast_favorite_off
                                            : R.string
                                                .player_toast_favorite_on),
                                        ToastManager.LENGTH_NORMAL);
                                }
                            }
                        });
                    }
                }
            });
        }

        if (mHomeButton != null) {
            mHomeButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();

                    if (mHomeConfirmState
                            == HomeConfirmState.CONFIRMED) {
                        return;
                    }

                    if (mHomeReturnRunnable != null) {
                        mMainHandler.removeCallbacks(
                            mHomeReturnRunnable);
                        mHomeReturnRunnable = null;
                    }

                    if (mHomeConfirmState
                                == HomeConfirmState.ARMED
                            && currentTime - mLastHomeClickTime
                                <= HOME_CONFIRM_WINDOW_MS) {
                        enterConfirmedState();
                        return;
                    }

                    enterArmedState(currentTime);
                }
            });
        }
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Forces the activity content to re-measure, re-layout, and re-draw.
     */
    private void forceRedraw() {
        View root = findViewById(android.R.id.content);
        if (root == null) {
            return;
        }
        root.requestLayout();
        root.invalidate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation();
        }
    }

    /**
     * Recreates the activity.
     *
     * <p>The incoming activity builds its resources from
     * {@code attachBaseContext}, which applies the current locale
     * through {@link LanguageManager#wrap(Context)} and the current
     * theme through {@link ThemeManager} in its own
     * {@code onCreate}.</p>
     */
    private void recreateActivity() {
        if (mRecreationPending || isFinishing() || isDestroyed()) {
            return;
        }
        mRecreationPending = true;
        final View decor = getWindow() != null
            ? getWindow().getDecorView() : null;
        if (decor == null) {
            mRecreationPending = false;
            return;
        }
        decor.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                recreate();
                overridePendingTransition(0, 0);
            }
        });
    }

    /**
     * Returns whether the activity has been destroyed, using the
     * API-appropriate check.
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to pixels.
     */
    private int dpToPx(int dp) {
        return Math.round(dp
            * getResources().getDisplayMetrics().density);
    }
}