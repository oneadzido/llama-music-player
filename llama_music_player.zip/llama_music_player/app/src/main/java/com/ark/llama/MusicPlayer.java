package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MusicPlayer - Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Playback stall recovery with user feedback</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All background operations use ExecutorService to prevent memory leaks
 * and provide better cancellation support. All time calculations use
 * {@link SystemClock#elapsedRealtime()} which is unaffected by system time changes,
 * ensuring consistent debouncing and timeout behavior.</p>
 * 
 * <h3>ExecutorService Usage</h3>
 * <ul>
 *   <li><b>mExecutor</b> - Single-thread executor for album art loading and metadata loading</li>
 *   <li><b>mPlaceholderExecutor</b> - Single-thread executor for placeholder bitmap generation</li>
 *   <li><b>Future.cancel()</b> - Proper cancellation of pending tasks</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing first run flag. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Intent action for restarting the app after update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Broadcast action for updating sort mode from playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Timeout for loading overlay display. */
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;
    
    /** Delay for play/pause button update. */
    private static final long PLAY_PAUSE_UPDATE_DELAY_MS = 50;
    
    /** Delay for next/prev button updates. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;
    
    /** Buffer size for file copying operations. */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Duration of album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    /** Shutdown timeout for executor service in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView for displaying song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView for displaying artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView for current seek position. */
    @Nullable private TextView mSeekTime;
    
    /** TextView for total track duration. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Play/Pause control button. */
    @Nullable private Button mPlayButton;
    
    /** Previous track button. */
    @Nullable private Button mPrevButton;
    
    /** Next track button. */
    @Nullable private Button mNextButton;
    
    /** Repeat mode button (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Shuffle mode button. */
    @Nullable private Button mShuffleButton;
    
    /** Button to open folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button to open credits dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button to open playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button to open equalizer. */
    @Nullable private Button mEqualizerButton;
    
    /** Button to open metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for album art display. */
    @Nullable private ImageView mAlbumArtView;
    
    // ========================================================================
    // ExecutorService for Async Operations (Replaces AsyncTask)
    // ========================================================================
    
    /**
     * Single-thread executor for background operations including:
     * - Album art loading
     * - Metadata loading
     * - Last song info loading
     * 
     * Using a single thread ensures operations are queued and prevents
     * concurrent resource contention.
     */
    @NonNull private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    
    /**
     * Executor for placeholder bitmap generation.
     * Separate from main executor to prevent blocking album art loading.
     */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Future for the current album art loading task (allows cancellation). */
    @Nullable private Future<?> mCurrentAlbumArtFuture = null;
    
    /** Future for the current metadata loading task. */
    @Nullable private Future<?> mCurrentMetadataFuture = null;
    
    /** Future for the current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderFuture = null;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Music library manager for song data. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Bound music service instance. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Main thread handler for delayed operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for time display updates (to prevent memory leaks). */
    @Nullable private Handler mTimeHandler = null;
    
    /** Flag indicating service binding state. */
    private boolean mIsServiceBound = false;
    
    /** Flag indicating user is currently seeking. */
    private boolean mIsUserSeeking = false;
    
    /** Atomic flag to prevent concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for thread-safe service access. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating post-update restart. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transitions. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    // ========================================================================
    // Click Debounce Timestamps (using SystemClock.elapsedRealtime)
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    /** LRU cache for album art bitmaps. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Path of currently loading album art. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    /** Path of currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    /** Themed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Lock object for placeholder synchronization. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components
    // ========================================================================
    
    /** Dim overlay for loading state. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner inside dim overlay. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Theme manager for color management. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Theme helper for UI color application. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme changes. */
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick loading. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Service connection for binding to MusicService.
     * Handles service lifecycle, initial UI setup, and automatic reconnection.
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        
        /**
         * Called when the service connection is established.
         * Initializes UI components, loads playlist, and sets up playback controls.
         *
         * @param name The component name of the connected service
         * @param service The IBinder of the service
         */
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            // Enable play button if songs exist
            if (mPlayButton != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }

            loadFullPlaylistInBackground();
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();

            // Delayed UI initialization
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButtonIcon();
                        updateShuffleButtonIcon();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow = (mMusicService != null && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButtonIcon();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButtonIcon();
                        }
                        
                        // Always use the service's current song directly
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);
            
            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        /**
         * Called when the service disconnects unexpectedly.
         * Attempts to automatically reconnect after a short delay.
         *
         * @param name The component name of the disconnected service
         */
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            // Attempt to reconnect after a delay
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is first created.
     * Initializes all UI components, managers, executors, and registers receivers.
     * Sets up full-screen mode, theme, and starts permission checking.
     *
     * @param savedInstanceState Previously saved state, or null if fresh start
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        // Handle app closure intent
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        // Initialize album art cache with size limit
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        // Register for navigation button state changes
        NavigationController.getInstance().registerListener(this);
    }
    
    /**
     * Called when the activity becomes visible to the user.
     * Re-registers the theme receiver if needed.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity is no longer visible.
     * Unregisters the theme receiver to prevent memory leaks.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes and becomes interactive.
     * Reattaches persistent UI elements, syncs button states, and refreshes UI.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Reattach ToastManager persistent overlay if exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        // Update StorageObserver activity reference for toasts
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        // Sync button state with NavigationController
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();
            updatePlayPauseButton();
            
            // Always use the service's current song directly
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     * Reattaches persistent toast overlays.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called before the activity is destroyed.
     * Cancels all pending tasks, shuts down executors, unregisters receivers,
     * saves player state, and cleans up resources to prevent memory leaks.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // Cancel all pending futures
        if (mCurrentAlbumArtFuture != null && !mCurrentAlbumArtFuture.isDone()) {
            mCurrentAlbumArtFuture.cancel(true);
        }
        if (mCurrentMetadataFuture != null && !mCurrentMetadataFuture.isDone()) {
            mCurrentMetadataFuture.cancel(true);
        }
        if (mCurrentPlaceholderFuture != null && !mCurrentPlaceholderFuture.isDone()) {
            mCurrentPlaceholderFuture.cancel(true);
        }
        
        // Shutdown executors gracefully
        shutdownExecutor(mExecutor);
        shutdownExecutor(mPlaceholderExecutor);
        
        // Clean up time handler to prevent memory leaks
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        
        // Unregister from navigation button state changes
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();
        
        // Hide ToastManager persistent overlay if showing
        ToastManager.hidePersistentOverlay();
        
        hideLoadingOverlay();
    }
    
    /**
     * Shuts down an executor service gracefully.
     * Waits for pending tasks to complete before forcing shutdown.
     *
     * @param executor The executor to shut down
     */
    private void shutdownExecutor(ExecutorService executor) {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    executor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", e);
            }
        }
    }
    
    /**
     * Called when the system requests memory trimming.
     * Forwards the event to the MusicService to release caches.
     *
     * @param level The trim level (e.g., TRIM_MEMORY_RUNNING_LOW)
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        // Forward to MusicService if bound
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     * Handles app closure or processes incoming audio files.
     *
     * @param intent The new intent
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     * Enables immersive full-screen mode when focused (Android 4.4+).
     *
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    /**
     * Handles hardware media key presses.
     *
     * @param keyCode The key code of the pressed button
     * @param event The key event
     * @return True if the event was handled
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    /**
     * Handles results from started activities (e.g., folder selection).
     *
     * @param requestCode The request code from startActivityForResult
     * @param resultCode The result code (RESULT_OK or RESULT_CANCELED)
     * @param data The returned intent with result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Handles runtime permission request results.
     *
     * @param requestCode The request code from requestPermissions
     * @param permissions The requested permissions
     * @param grantResults The grant results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when button states change in the NavigationController.
     * Updates UI button enabled states based on group disable flags.
     *
     * @param group The button group that changed
     * @param disabled True if the group should be disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // PLAYLIST button
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }
                    
                    // METADATA button
                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Hides title bar and sets status/navigation bar colors for Android L+.
     * For Android 4.4+, enables immersive sticky mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components from the layout.
     * Sets up FontAwesome icons, button backgrounds, letter spacing,
     * and press animations for all interactive elements.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        // Set FontAwesome icons
        final Typeface faTypeface = FontAwesome.getTypeface();
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        // Set button backgrounds
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Set letter spacing for action buttons
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Apply animations to all buttons
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButtonIcon();
        updateShuffleButtonIcon();
        updateControlButtonsState();
    }

    /**
     * Adds press animation (scale down/up) to a button.
     *
     * @param button The button to animate, or null if none
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests necessary runtime permissions.
     * For Android 13+ (API 33+), requests READ_MEDIA_AUDIO and POST_NOTIFICATIONS.
     * For older versions, requests READ_EXTERNAL_STORAGE.
     * For Android 12+ (API 31+), requests BLUETOOTH_CONNECT.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            // Android 13+ (API 33+) uses granular media permissions
            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                // Pre-Android 13 uses READ_EXTERNAL_STORAGE
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            // Bluetooth connect permission for Android 12+ (API 31+)
            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * Checks if it's the first run, sets up appropriate UI state,
     * starts and binds to the MusicService, and handles incoming files.
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers a media button event receiver for headset controls.
     * Uses AudioManager to register BluetoothReceiver component.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters the media button event receiver.
     * Should be called during cleanup to prevent leaks.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles incoming audio files from other apps via ACTION_VIEW intent.
     * Extracts metadata, adds to database, builds playlist, and starts playback.
     *
     * @param intent The intent containing the file URI
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                // Create or retrieve song object
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                // Add to loose tracks database
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                // Build complete playlist including loose tracks
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<Song>();
                }
                
                // Find or add the song in playlist (duplicate check)
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<Song>(allSongs);
                
                // Clear last playing state
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                // Play the song using path-based method (reliable, avoids index issues)
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                // Broadcast updates
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming song when MusicService is already bound.
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath Path to the audio file
     * @param newSong The song object to play
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    enableAllControls();
                    updateUIForSong(newSong);
                }
            });
            
            mMusicService.playSongByPath(filePath);
            
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to MusicService and plays an incoming song when service is not yet bound.
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath Path to the audio file
     * @param newSong The song object to play
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            enableAllControls();
                            updateUIForSong(newSong);
                            applyAlbumArtClipping();
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     * Handles both file:// and content:// schemes.
     *
     * @param uri The URI to convert
     * @return The file path, or null if conversion fails
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file when direct path resolution fails.
     *
     * @param uri The content URI to copy
     * @return The path to the temporary file, or null if copy fails
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that are inside an imported folder to prevent duplicates.
     *
     * @param folderUri The URI of the imported folder
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist in the background using async callback.
     * Updates MusicService playlist and refreshes UI when loading completes.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                        mSongTitle.setText(current.getTitle());
                        mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        mSongArtist.setText(current.getArtist());
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        updateAlbumArt(current.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Safely updates the UI with queuing to prevent concurrent updates.
     * Uses atomic flag to ensure only one update runs at a time.
     *
     * @param update The update operation to perform
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pending = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pending);
                    }
                }
            }
        });
    }
    
    /**
     * Updates the UI for a song (title, artist, controls).
     * Truncates long titles and artists for display.
     *
     * @param song The song to display, or null for no song state
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Updates UI specifically for a playing song (includes album art refresh).
     *
     * @param song The song that is now playing
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        final Song finalSong = song;
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Enables or disables all control buttons based on whether songs exist.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButtonIcon();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButtonIcon();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }
    
    /**
     * Updates the state of previous, next, repeat, and shuffle buttons.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButtonIcon();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButtonIcon();
        }
    }
    
    /**
     * Applies the "no song" state to the UI, disabling controls and showing placeholder.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }
        
        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on the MusicService with synchronization.
     *
     * @param action The action to execute
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     *
     * @param index The playlist index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles play/pause state of the current song.
     * Shows a toast if no songs are available.
     */
    private void togglePlayPause() {
        if (mPlayButton != null && mPlayButton.isEnabled()) {
            if (mMusicLibrary != null) {
                final int playlistSize = mMusicLibrary.getAllSongs().size();
                if (playlistSize == 0) {
                    ToastManager.showToast(this, "No songs found", ToastManager.LENGTH_NORMAL);
                    return;
                }
            }
            
            safeCallService(new Runnable() {
                @Override
                public void run() {
                    final int currentIndex = mMusicService.getCurrentIndex();
                    if (currentIndex < 0 || (mMusicLibrary != null && currentIndex >= mMusicLibrary.getAllSongs().size())) {
                        playSong(0);
                        return;
                    }
                    mMusicService.togglePlayPause();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                        }
                    }, PLAY_PAUSE_UPDATE_DELAY_MS);
                }
            });
        }
    }
    
    /**
     * Plays the next song in the playlist (or shuffles if enabled).
     * Uses atomic flag to prevent multiple rapid transitions.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playNext();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * Uses atomic flag to prevent multiple rapid transitions.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playPrevious();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button icon based on current repeat mode:
     * - Mode 0: REPEAT (off)
     * - Mode 1: REPEAT (all)
     * - Mode 2: REPEAT_ONE
     */
    private void updateRepeatButtonIcon() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mRepeatButton.isEnabled();
            
            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);
                
                if (repeatMode == 0) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else if (repeatMode == 1) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                }
                
                mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(mRepeatButton, false, false);
            }
        }
    }
    
    /**
     * Updates the shuffle button icon and active state.
     */
    private void updateShuffleButtonIcon() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mShuffleButton.isEnabled();
            
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            
            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(mShuffleButton, false, false);
            }
        }
    }
    
    /**
     * Updates the play/pause button text and state based on current playback.
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
                
                final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
                
                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                    return;
                }
                
                mPlayButton.setEnabled(true);
                
                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }
                
                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                        return;
                    }
                    
                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                } catch (Exception e) {
                    Log.e(TAG, "Error updating play/pause button", e);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position tracking and seeking.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }
    
    /**
     * Updates the time display and SeekBar progress at regular intervals.
     * Uses a dedicated Handler to prevent memory leaks.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }
        
        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                
                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }
                
                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }
                
                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();
                    
                    if (duration <= 0) {
                        final Song currentSong = service.getCurrentSong();
                        if (currentSong != null && currentSong.getDuration() > 0) {
                            duration = (int) currentSong.getDuration();
                        }
                    }
                    
                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(formatTime(duration));
                        }
                        
                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error updating time display", e);
                }
                
                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }
    
    /**
     * Formats milliseconds into MM:SS or HH:MM:SS string.
     *
     * @param milliseconds Time in milliseconds
     * @return Formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods (Using ExecutorService instead of AsyncTask)
    // ========================================================================
    
    /**
     * Calculates the inSampleSize for downsampling bitmap to requested dimensions.
     *
     * @param options BitmapFactory.Options with outWidth/outHeight
     * @param reqWidth Requested width
     * @param reqHeight Requested height
     * @return The calculated sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Decodes a byte array into a downsampled bitmap.
     *
     * @param data The raw image data
     * @param reqWidth Requested max width
     * @param reqHeight Requested max height
     * @return The downsampled bitmap, or null if decoding fails
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Updates the album art display for the given song path.
     * Uses LRU cache and ExecutorService for background loading.
     *
     * @param filePath Path to the audio file containing album art
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        // Cancel any ongoing task
        if (mCurrentAlbumArtFuture != null && !mCurrentAlbumArtFuture.isDone()) {
            mCurrentAlbumArtFuture.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;
        
        mCurrentAlbumArtFuture = mExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;
                
                MediaMetadataRetriever retriever = null;
                Bitmap result = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        result = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                
                final Bitmap bitmap = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        if (!Thread.currentThread().isInterrupted() && 
                            taskPath.equals(mCurrentLoadingArtPath) && 
                            taskPath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, bitmap);
                                applyAlbumArtWithFade(bitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtFuture == Thread.currentThread()) {
                            mCurrentAlbumArtFuture = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Applies album art bitmap with a fade-in animation.
     *
     * @param bitmap The bitmap to display, or null to use placeholder
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }
        
        if (isFinishing() || isDestroyed() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        
        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }
        
        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }
    
    /**
     * Loads and displays the themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    /**
     * Updates the notification with current album art for the Now Playing notification.
     */
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(currentPath);
            if (cached != null && !cached.isRecycled()) {
                art = cached;
            }
        }
        
        mMusicService.setNotificationAlbumArt(art, placeholder, currentPath);
    }
    
    /**
     * Gets the path of the currently playing song.
     *
     * @return The song path, or null if no song is playing
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }
    
    /**
     * Checks if a bitmap is valid (non-null, not recycled, with positive dimensions).
     *
     * @param bitmap The bitmap to check
     * @return True if the bitmap is valid for display
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    // ========================================================================
    // Last Song Metadata Loading (Using ExecutorService instead of AsyncTask)
    // ========================================================================
    
    /**
     * Loads the last played song metadata from SharedPreferences using ExecutorService.
     * This method replaces the AsyncTask implementation for better thread management.
     * All time calculations use SystemClock.elapsedRealtime().
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            // Cancel any existing metadata task
            if (mCurrentMetadataFuture != null && !mCurrentMetadataFuture.isDone()) {
                mCurrentMetadataFuture.cancel(true);
            }
            
            mCurrentMetadataFuture = mExecutor.submit(new Runnable() {
                @Override
                public void run() {
                    final Song resultSong = loadSongMetadataSync(lastPath);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            
                            if (resultSong != null && mThemeHelper != null) {
                                mCachedLastSong = resultSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(resultSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(resultSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                } else {
                                    loadAndDisplayPlaceholder();
                                    mHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Synchronously loads song metadata from file or database.
     * This method runs on the executor thread.
     *
     * @param lastPath The file path of the last played song
     * @return The loaded Song object, or null if loading fails
     */
    @Nullable
    private Song loadSongMetadataSync(@NonNull String lastPath) {
        // First check database for cached song with real genre
        Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
        
        if (cachedSong != null && cachedSong.getTitle() != null && 
            !cachedSong.getTitle().isEmpty() && 
            !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: " + cachedSong.getGenre());
            
            // Try to get album art from cache
            if (mAlbumArtCache != null) {
                try {
                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                    mmr.setDataSource(lastPath);
                    final byte[] art = mmr.getEmbeddedPicture();
                    mmr.release();
                    if (art != null) {
                        final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                        if (bmp != null) {
                            mAlbumArtCache.put(lastPath, bmp);
                        }
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Failed to load album art for cached song", e);
                }
            }
            return cachedSong;
        }
        
        // Fall back to reading from file
        try {
            final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(lastPath);
            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] art = mmr.getEmbeddedPicture();
            mmr.release();
            
            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dot = name.lastIndexOf('.');
                if (dot > 0) {
                    name = name.substring(0, dot);
                }
                title = name;
            }
            if (artist == null) artist = "Unknown Artist";
            if (album == null) album = "Unknown Album";
            
            // Try to get real genre from database or file
            String genre = "Unknown Genre";
            Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
            if (dbSong != null && dbSong.getGenre() != null && 
                !"Unknown Genre".equals(dbSong.getGenre())) {
                genre = dbSong.getGenre();
                Log.d(TAG, "Found genre in database: " + genre);
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                    Log.d(TAG, "Read genre from file: " + genre);
                }
            }
            
            final Song song = new Song(title, artist, album, genre, lastPath, 0, null);
            if (art != null && mAlbumArtCache != null) {
                final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                if (bmp != null) {
                    mAlbumArtCache.put(lastPath, bmp);
                }
            }
            return song;
        } catch (Exception e) {
            Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
            return null;
        }
    }
    
    /**
     * Starts the MusicService with the cached last song as the current track.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<Song>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs from storage and starts the MusicService.
     * Shows a loading overlay during the operation.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Placeholder Methods (Using ExecutorService)
    // ========================================================================
    
    /**
     * Updates the themed placeholder bitmap on a background thread.
     * The placeholder is tinted with the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderFuture != null) {
                mCurrentPlaceholderFuture.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderFuture = task;
        }
    }
    
    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderFuture != null) {
                mCurrentPlaceholderFuture.cancel(true);
                mCurrentPlaceholderFuture = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    /**
     * Safely recycles a bitmap, handling exceptions.
     *
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corner clipping to the album art container.
     * Uses ViewOutlineProvider for Android 5.0+ or a background drawable for older versions.
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a dim overlay with a loading spinner.
     * Used during long-running operations like loading the song library.
     */
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) return;

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Hides the loading overlay if it is currently visible.
     */
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the FolderManager activity to import folders.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the PlaylistActivity to display the current playlist.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the MetadataEditor for editing song metadata.
     * Passes the current song path if one is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song from MusicService.
     *
     * @return The current Song, or null if none is playing
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers a broadcast receiver for app restart after update.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers a broadcast receiver for theme color changes.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies the current theme color to all UI components.
     * Updates buttons, text colors, seek bar, and placeholder.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs an app update by restarting the activity.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for inter-component communication.
     * Includes receivers for player updates, Bluetooth events, sync status, etc.
     */
    private void registerReceivers() {
        // Update player receiver
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            /**
             * Updates the UI when playback state changes.
             * Refreshes play/pause button, seek bar, and song info.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    safeUpdateUI(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            
                            if (mMusicService != null) {
                                if (mSeekBar != null && mSeekBar.isEnabled()) {
                                    final int duration = mMusicService.getDuration();
                                    final int position = mMusicService.getCurrentPosition();
                                    mSeekBar.setMax(duration);
                                    mSeekBar.setProgress(position);
                                }
                                
                                final Song song = mMusicService.getCurrentSong();
                                if (song != null) {
                                    if (mMusicService.isPlaying()) {
                                        updateUIForPlayingSong(song);
                                    } else {
                                        updateUIForSong(song);
                                    }
                                }
                            }
                            setupSeekBar();
                        }
                    });
                }
            }
        };
        
        // Play song receiver
        mPlaySongReceiver = new BroadcastReceiver() {
            /**
             * Plays a specific song by its file path.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        // Bluetooth play receiver
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            /**
             * Resumes or starts playback when Bluetooth play command is received.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Bluetooth pause receiver
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            /**
             * Pauses playback when Bluetooth pause command is received.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        
        // Media button receiver
        mMediaButtonReceiver = new BroadcastReceiver() {
            /**
             * Handles media button events from headset controls.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Get playing state receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            /**
             * Saves the current playing state to SharedPreferences.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isPlaying()).apply();
                    }
                }
            }
        };
        
        // Reset player receiver
        mResetPlayerReceiver = new BroadcastReceiver() {
            /**
             * Resets the player state, optionally preserving settings.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };
        
        // Force update player receiver
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            /**
             * Forces a complete UI update, optionally refreshing metadata or album art.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };
        
        // Save player state now receiver
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            /**
             * Immediately saves the player state to preferences.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        // Bluetooth connection receiver
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            /**
             * Updates Bluetooth connection state in MusicService.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        // Sync started receiver
        mSyncStartedReceiver = new BroadcastReceiver() {
            /**
             * Shows a persistent toast overlay during sync operations.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        // Sync complete receiver
        mSyncCompleteReceiver = new BroadcastReceiver() {
            /**
             * Hides the persistent toast overlay when sync completes.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        // Update playlist from folders receiver
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            /**
             * Updates the playlist from imported folders.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        // Soft update playlist receiver
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            /**
             * Performs a lightweight playlist update without full reload.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        // Update song in playlist receiver
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            /**
             * Updates a specific song's metadata in the playlist.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) return;
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        // Playback recovery receiver
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            /**
             * Shows a toast when playback has been recovered from an error.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        // Sort mode update receiver
        mSortModeReceiver = new BroadcastReceiver() {
            /**
             * Updates the UI when the playlist sort mode changes.
             */
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        // Register all receivers
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }
    
    /**
     * Safely registers a broadcast receiver, catching any exceptions.
     *
     * @param receiver The receiver to register
     * @param action The intent action to listen for
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver, catching any exceptions.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all UI buttons with debouncing to prevent rapid multiple clicks.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButtonIcon();
                            final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButtonIcon();
                            ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(android.content.DialogInterface d) {
                                final View mainContent = findViewById(android.R.id.content);
                                mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }
    
    /**
     * Checks if the activity is destroyed (compatibility wrapper for older Android versions).
     *
     * @return True if the activity is destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels (dp) to actual pixels (px).
     *
     * @param dp Value in dp
     * @return Value in px
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}