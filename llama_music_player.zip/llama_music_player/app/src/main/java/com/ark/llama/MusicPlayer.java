package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity follows the principle that MusicService is the single source
 * of truth for all playback state. It never stores local copies of playlist,
 * current index, or current song. All UI updates are driven by service callbacks
 * and broadcasts.</p>
 * 
 * <h3>Key Improvements</h3>
 * <ul>
 *   <li>No local mCurrentIndex or mCachedLastSong – always query service</li>
 *   <li>No direct MusicLibrary reads for live data – use service getters</li>
 *   <li>Service binding race conditions eliminated with ready flag</li>
 *   <li>All service calls wrapped in null‑safe helper</li>
 *   <li>Album art updates check activity lifecycle</li>
 *   <li>All broadcast receivers registered safely and cleaned up</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicPlayer";
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int FOLDER_SELECT_CODE = 200;
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_ASKED_BATTERY_OPTIMIZATION = "asked_battery_optimization";
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final long SEEK_RESET_DELAY_MS = 150;
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    private static final int BUFFER_SIZE = 8192;

    // ========================================================================
    // UI Components
    // ========================================================================
    
    private TextView mSongTitle;
    private TextView mSongArtist;
    private TextView mSeekTime;
    private TextView mTotalTime;
    private SeekBar mSeekBar;
    private Button mPlayButton;
    private Button mPrevButton;
    private Button mNextButton;
    private Button mRepeatButton;
    private Button mShuffleButton;
    private Button mManagerButton;
    private Button mLlamaButton;
    private Button mPlaylistButton;
    private Button mEqualizerButton;
    private Button mMetadataButton;
    private ImageView mAlbumArtView;
    private FrameLayout mAlbumArtContainer;

    // ========================================================================
    // Managers and Service
    // ========================================================================
    
    private MusicService mMusicService;
    private DisplayManager mDisplayManager;
    private ThemeManager mThemeManager;
    private ThemeHelper mThemeHelper;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    private volatile boolean mIsServiceBound = false;
    private volatile boolean mServiceReady = false;
    private volatile boolean mIsUserSeeking = false;
    private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    private final AtomicBoolean mPlayButtonUpdateQueued = new AtomicBoolean(false);
    private final Object mServiceLock = new Object();
    private boolean mIsPostUpdateRestart = false;
    private boolean mBatteryOptimizationRequested = false;

    // Executor for metadata loading (replaces AsyncTask)
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    private Future<?> mCurrentMetadataTask = null;

    // Click debounce timestamps
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;

    // Broadcast receivers
    private BroadcastReceiver mUpdatePlayerReceiver;
    private BroadcastReceiver mPlaySongReceiver;
    private BroadcastReceiver mBluetoothPlayReceiver;
    private BroadcastReceiver mBluetoothPauseReceiver;
    private BroadcastReceiver mMediaButtonReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mResetPlayerReceiver;
    private BroadcastReceiver mForceUpdatePlayerReceiver;
    private BroadcastReceiver mRestartReceiver;
    private BroadcastReceiver mSavePlayerStateNowReceiver;
    private BroadcastReceiver mBluetoothConnectionReceiver;
    private BroadcastReceiver mSyncStartedReceiver;
    private BroadcastReceiver mSyncCompleteReceiver;
    private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    private BroadcastReceiver mPlaybackRecoveryReceiver;
    private BroadcastReceiver mSortModeReceiver;
    private BroadcastReceiver mThemeReceiver;
    private StorageObserver mStorageObserver;

    // ========================================================================
    // Service Connection
    // ========================================================================
    
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mServiceReady = true;
            
            refreshUiFromService();
            EqualizerManager.getInstance(MusicPlayer.this);
            loadFullPlaylistInBackground();
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !mBatteryOptimizationRequested) {
                mBatteryOptimizationRequested = true;
                checkAndRequestBatteryOptimization();
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            if (!prefs.getBoolean(KEY_FIRST_RUN, false)) {
                prefs.edit().putBoolean(KEY_FIRST_RUN, true).apply();
                Log.d(TAG, "First run marked complete after service connection");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            mServiceReady = false;
            mMusicService = null;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            mHandler.postDelayed(() -> {
                if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                    bindService(new Intent(MusicPlayer.this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
                }
            }, 1000);
        }
    };

    // ========================================================================
    // Activity Lifecycle
    // ========================================================================
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mDisplayManager = new DisplayManager(this, mThemeManager, mThemeHelper);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }
        
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try { unregisterReceiver(mThemeReceiver); } catch (Exception ignored) {}
            mThemeReceiver = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mServiceReady && mMusicService != null) {
            refreshUiFromService();
        }
        
        if (mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
        
        if (!mIsUserSeeking && mServiceReady && mMusicService != null && mSeekBar != null && mSeekBar.isEnabled()) {
            int position = mMusicService.getCurrentPosition();
            int duration = mMusicService.getDuration();
            if (duration > 0 && mSeekBar.getMax() != duration) {
                mSeekBar.setMax(duration);
            }
            mSeekBar.setProgress(position);
            if (mSeekTime != null) {
                mSeekTime.setText(DisplayManager.formatTime(position));
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        NavigationController.getInstance().unregisterListener(this);
        stopTimeDisplayUpdates();
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);
        
        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try { unbindService(mServiceConnection); } catch (Exception ignored) {}
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        mHandler.removeCallbacksAndMessages(null);
        unregisterMediaButtonReceiver();
        
        if (mDisplayManager != null) {
            mDisplayManager.release();
        }
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdownNow();
        }
        ToastManager.hidePersistentOverlay();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            mMusicService.onTrimMemory(level);
        }
        if (mDisplayManager != null) {
            if (level >= TRIM_MEMORY_MODERATE) {
                Log.d(TAG, "Memory pressure detected, clearing album art cache");
                mDisplayManager.clearAlbumArtCache();
                mDisplayManager.resetCurrentArtPath();
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) return super.onKeyDown(keyCode, event);
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mServiceReady && mMusicService != null && !mMusicService.isPlaying()) {
                    if (mMusicService.isPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicService.getPlaylistSize() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mServiceReady && mMusicService != null && mMusicService.isPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                } else {
                    ToastManager.showToast(this, "Background playback may be restricted", ToastManager.LENGTH_NORMAL);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
            }
        }
    }

    // ========================================================================
    // NavigationController Listener
    // ========================================================================
    
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            runOnUiThread(() -> {
                if (mPlaylistButton != null) {
                    mPlaylistButton.setEnabled(!disabled);
                    if (mThemeHelper != null) mThemeHelper.updateButton(mPlaylistButton, !disabled);
                }
                if (mMetadataButton != null) {
                    mMetadataButton.setEnabled(!disabled);
                    if (mThemeHelper != null) mThemeHelper.updateButton(mMetadataButton, !disabled);
                }
            });
        }
    }

    // ========================================================================
    // UI Initialisation
    // ========================================================================
    
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        Typeface faTypeface = FontAwesome.getTypeface();
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }

        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        if (mDisplayManager != null && mAlbumArtView != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
        }
        
        updateRepeatButtonIcon();
        updateShuffleButtonIcon();
        if (mSeekBar != null) mSeekBar.setEnabled(false);
    }

    private void animateButton(final Button button) {
        if (button == null) return;
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
            }
            return false;
        });
    }

    // ========================================================================
    // Permission and Initialisation
    // ========================================================================
    
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> permissionsToRequest = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED)
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED)
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
            }
            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }

    private void proceedWithInitialization() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);
        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(this, "Just a moment...", ToastManager.LENGTH_NORMAL);
            Intent serviceIntent = new Intent(this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
            prefs.edit().putBoolean(KEY_FIRST_RUN, true).apply();
        } else {
            loadLastSongMetadata();
        }
        handleIncomingFile(getIntent());
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            if (!prefs.getBoolean(KEY_ASKED_BATTERY_OPTIMIZATION, false)) {
                prefs.edit().putBoolean(KEY_ASKED_BATTERY_OPTIMIZATION, true).apply();
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        }
    }

    // ========================================================================
    // Media Button Receiver
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }

    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }

    // ========================================================================
    // Incoming File Handling (Loose Tracks)
    // ========================================================================
    
    private void handleIncomingFile(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            Uri uri = intent.getData();
            if (uri == null) return;
            String filePath = getFilePathFromUri(uri);
            if (filePath == null || !new File(filePath).exists()) {
                ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                return;
            }
            Song tempSong = CharacterMapper.getSongFromFile(filePath);
            final Song newSong = (tempSong != null) ? tempSong : new Song(
                new File(filePath).getName(), "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
            SongDatabase.getInstance(this).insertLooseSong(newSong);
            MusicLibrary musicLibrary = new MusicLibrary(this);
            ArrayList<Song> allSongs = musicLibrary.getAllSongs();
            int existingIndex = -1;
            for (int i = 0; i < allSongs.size(); i++) {
                if (allSongs.get(i).getPath().equals(filePath)) {
                    existingIndex = i;
                    break;
                }
            }
            final int playIndex = (existingIndex >= 0) ? existingIndex : allSongs.size() - 1;
            final ArrayList<Song> finalSongs = new ArrayList<>(allSongs);
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean("last_playing", false).apply();
            if (mServiceReady && mMusicService != null) {
                playSongFromIncoming(finalSongs, filePath, newSong);
            } else {
                bindServiceForIncomingFile(finalSongs, filePath, newSong);
            }
            sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
        }
    }

    private void playSongFromIncoming(ArrayList<Song> finalSongs, String filePath, Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            runOnUiThread(() -> {
                enableAllControls();
                updateUIForSong(newSong);
            });
            mMusicService.playSongByPath(filePath);
            mHandler.postDelayed(() -> updatePlayPauseButton(), FOCUS_SCROLL_DELAY_MS);
        }
    }

    private void bindServiceForIncomingFile(ArrayList<Song> finalSongs, String filePath, Song newSong) {
        Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                mServiceReady = true;
                mMusicService.setPlaylist(finalSongs, false);
                runOnUiThread(() -> {
                    enableAllControls();
                    updateUIForSong(newSong);
                    if (mDisplayManager != null && mAlbumArtContainer != null)
                        mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
                });
                mMusicService.playSongByPath(filePath);
                mHandler.postDelayed(() -> updatePlayPauseButton(), FOCUS_SCROLL_DELAY_MS);
            }
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
                mServiceReady = false;
            }
        }, BIND_AUTO_CREATE);
    }

    private String getFilePathFromUri(Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) return uri.getPath();
        if ("content".equals(uri.getScheme())) {
            android.database.Cursor cursor = null;
            try {
                String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(idx);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) cursor.close();
            }
        }
        return path;
    }

    private String copyContentUriToTempFile(Uri uri) {
        try {
            java.io.InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            File temp = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            java.io.FileOutputStream out = new java.io.FileOutputStream(temp);
            byte[] buffer = new byte[BUFFER_SIZE];
            int len;
            while ((len = in.read(buffer)) != -1) out.write(buffer, 0, len);
            in.close();
            out.close();
            return temp.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "copyContentUriToTempFile failed", e);
            return null;
        }
    }

    // ========================================================================
    // Playlist Loading
    // ========================================================================
    
    private void loadFullPlaylistInBackground() {
        MusicLibrary musicLibrary = new MusicLibrary(this);
        musicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    refreshUiFromService();
                }
                if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
            }
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
            }
        });
    }

    // ========================================================================
    // UI Updates (from Service)
    // ========================================================================
    
    private void refreshUiFromService() {
        if (!mServiceReady || mMusicService == null) return;
        safeUpdateUI(() -> {
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                mSongTitle.setText(DisplayManager.formatSongTitle(currentSong.getTitle()));
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                mSongArtist.setText(DisplayManager.formatArtistName(currentSong.getArtist()));
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                if (mTotalTime != null && currentSong.getDuration() > 0)
                    mTotalTime.setText(DisplayManager.formatTime((int) currentSong.getDuration()));
                if (mDisplayManager != null && mAlbumArtView != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            } else {
                applyNoSongState();
            }
            updatePlayPauseButton();
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();
            boolean hasSongs = mMusicService.getPlaylistSize() > 0;
            boolean isPrepared = mMusicService.isPlayerPrepared();
            boolean enabled = hasSongs && isPrepared;
            if (mSeekBar != null) {
                mSeekBar.setEnabled(enabled);
                if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
            if (mPlayButton != null) {
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
            }
            if (mPrevButton != null) {
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
            }
            if (mNextButton != null) {
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
            }
            if (mRepeatButton != null) {
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
            }
            if (mShuffleButton != null) {
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
            }
        });
    }

    private void safeUpdateUI(Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        runOnUiThread(update);
    }

    private void updateUIForSong(Song song) {
        if (song == null) return;
        safeUpdateUI(() -> {
            if (mSongTitle != null) {
                mSongTitle.setText(DisplayManager.formatSongTitle(song.getTitle()));
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            if (mSongArtist != null) {
                mSongArtist.setText(DisplayManager.formatArtistName(song.getArtist()));
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mTotalTime != null && song.getDuration() > 0)
                mTotalTime.setText(DisplayManager.formatTime((int) song.getDuration()));
            updatePlayPauseButton();
            if (mDisplayManager != null && mAlbumArtView != null) {
                mDisplayManager.updateAlbumArt(mAlbumArtView, song.getPath());
            }
        });
    }

    private void applyNoSongState() {
        safeUpdateUI(() -> {
            if (mSongTitle != null) {
                mSongTitle.setText("Llama Player");
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Ready");
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mAlbumArtView != null && mDisplayManager != null) {
                mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                mDisplayManager.clearAlbumArtCache();
            }
            if (mPlayButton != null) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                mPlayButton.setAlpha(0.5f);
            }
            if (mPrevButton != null) {
                mPrevButton.setEnabled(false);
                mPrevButton.setAlpha(0.5f);
            }
            if (mNextButton != null) {
                mNextButton.setEnabled(false);
                mNextButton.setAlpha(0.5f);
            }
            if (mRepeatButton != null) {
                mRepeatButton.setEnabled(false);
                mRepeatButton.setAlpha(0.5f);
            }
            if (mShuffleButton != null) {
                mShuffleButton.setEnabled(false);
                mShuffleButton.setAlpha(0.5f);
            }
            if (mSeekBar != null) {
                mSeekBar.setProgress(0);
                mSeekBar.setMax(100);
                mSeekBar.setEnabled(false);
            }
            if (mSeekTime != null) mSeekTime.setText("00:00");
            if (mTotalTime != null) mTotalTime.setText("00:00");
        });
    }

    private void enableAllControls() {
        if (!mServiceReady || mMusicService == null) return;
        boolean hasSongs = mMusicService.getPlaylistSize() > 0;
        boolean isPrepared = mMusicService.isPlayerPrepared();
        boolean enabled = hasSongs && isPrepared;
        safeUpdateUI(() -> {
            if (mPlayButton != null) {
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, enabled, true);
            }
            if (mPrevButton != null) {
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPrevButton, enabled, false);
            }
            if (mNextButton != null) {
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mNextButton, enabled, false);
            }
            if (mRepeatButton != null) {
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateRepeatButtonIcon();
            }
            if (mShuffleButton != null) {
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateShuffleButtonIcon();
            }
            if (mSeekBar != null) {
                mSeekBar.setEnabled(enabled);
                if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
        });
    }

    // ========================================================================
    // Button State Updates (from Service)
    // ========================================================================
    
    private void updateRepeatButtonIcon() {
        if (!mServiceReady || mMusicService == null || mRepeatButton == null) return;
        int mode = mMusicService.getRepeatMode();
        boolean enabled = mRepeatButton.isEnabled();
        if (enabled) {
            if (mode == 2) mRepeatButton.setText(FontAwesome.REPEAT_ONE);
            else mRepeatButton.setText(FontAwesome.REPEAT);
            if (mThemeHelper != null) mThemeHelper.updateControlButton(mRepeatButton, true, mode != 0);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
            if (mThemeHelper != null) mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
    }

    private void updateShuffleButtonIcon() {
        if (!mServiceReady || mMusicService == null || mShuffleButton == null) return;
        boolean shuffle = mMusicService.isShuffle();
        boolean enabled = mShuffleButton.isEnabled();
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        if (mThemeHelper != null) mThemeHelper.updateControlButton(mShuffleButton, enabled, shuffle);
    }

    private void updatePlayPauseButton() {
        if (mPlayButtonUpdateQueued.getAndSet(true)) return;
        mHandler.post(() -> {
            mPlayButtonUpdateQueued.set(false);
            if (isFinishing() || isDestroyed() || mThemeHelper == null || mPlayButton == null) return;
            boolean hasSongs = mServiceReady && mMusicService != null && mMusicService.getPlaylistSize() > 0;
            if (!hasSongs) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                mPlayButton.setAlpha(0.5f);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, false, false);
                return;
            }
            if (mMusicService == null) return;
            try {
                boolean isPlaying = mMusicService.isPlaying();
                boolean isPrepared = mMusicService.isPlayerPrepared();
                boolean shouldEnable = isPrepared;
                if (mPlayButton.isEnabled() != shouldEnable) {
                    mPlayButton.setEnabled(shouldEnable);
                    mPlayButton.setAlpha(shouldEnable ? 1.0f : 0.5f);
                }
                mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                if (shouldEnable && mThemeHelper != null)
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
            } catch (Exception e) {
                Log.e(TAG, "Error updating play/pause button", e);
                mPlayButton.setText(FontAwesome.PLAY);
                if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, false, false);
            }
        });
    }

    // ========================================================================
    // Playback Control (calls to service)
    // ========================================================================
    
    private void callServiceSafely(Runnable action) {
        if (mServiceReady && mMusicService != null) {
            action.run();
        } else {
            Log.w(TAG, "Service not ready, ignoring action");
        }
    }

    private void togglePlayPause() {
        if (!mServiceReady || mMusicService == null) return;
        if (mMusicService.getPlaylistSize() == 0) {
            ToastManager.showToast(this, "No songs found", ToastManager.LENGTH_NORMAL);
            return;
        }
        callServiceSafely(() -> {
            if (mMusicService.getCurrentIndex() < 0 && mMusicService.getPlaylistSize() > 0) {
                mMusicService.playSong(0);
            } else {
                mMusicService.togglePlayPause();
            }
            mHandler.postDelayed(this::updatePlayPauseButton, 50);
        });
    }

    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            callServiceSafely(() -> {
                mMusicService.playNext();
                mHandler.postDelayed(() -> updatePlayPauseButton(), NEXT_PREV_UPDATE_DELAY_MS);
            });
        } finally {
            mControlsTransitioning.set(false);
        }
    }

    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            callServiceSafely(() -> {
                mMusicService.playPrevious();
                mHandler.postDelayed(() -> updatePlayPauseButton(), NEXT_PREV_UPDATE_DELAY_MS);
            });
        } finally {
            mControlsTransitioning.set(false);
        }
    }

    // ========================================================================
    // SeekBar Setup
    // ========================================================================
    
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mServiceReady && mMusicService != null && mSeekTime != null) {
                    mSeekTime.setText(DisplayManager.formatTime(progress));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) mIsUserSeeking = true;
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mServiceReady && mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mSeekHandler.removeCallbacksAndMessages(null);
                mSeekHandler.postDelayed(() -> {
                    mIsUserSeeking = false;
                    if (mServiceReady && mMusicService != null && mSeekBar != null && mSeekBar.isEnabled()) {
                        int pos = mMusicService.getCurrentPosition();
                        mSeekBar.setProgress(pos);
                        if (mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(pos));
                    }
                }, SEEK_RESET_DELAY_MS);
            }
        });
    }

    private void startTimeDisplayUpdates() {
        Runnable timeRunnable = new Runnable() {
            private long lastUpdate = 0;
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                if (!mServiceReady || mMusicService == null) {
                    mHandler.postDelayed(this, 500);
                    return;
                }
                if (mIsUserSeeking) {
                    mHandler.postDelayed(this, 500);
                    return;
                }
                long now = SystemClock.elapsedRealtime();
                if (now - lastUpdate < 500) {
                    mHandler.postDelayed(this, 50);
                    return;
                }
                lastUpdate = now;
                try {
                    int current = mMusicService.getCurrentPosition();
                    int duration = mMusicService.getDuration();
                    if (duration <= 0) {
                        Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null && currentSong.getDuration() > 0)
                            duration = (int) currentSong.getDuration();
                    }
                    if (duration > 0) {
                        if (mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(current));
                        if (mTotalTime != null) mTotalTime.setText(DisplayManager.formatTime(duration));
                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) mSeekBar.setMax(duration);
                            mSeekBar.setProgress(current);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Time update error", e);
                }
                mHandler.postDelayed(this, 500);
            }
        };
        mHandler.post(timeRunnable);
    }

    private void stopTimeDisplayUpdates() {
        mHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Navigation
    // ========================================================================
    
    private void openFolderManager() {
        startActivityForResult(new Intent(this, FolderManager.class), FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    private void openPlaylist() {
        startActivity(new Intent(this, PlaylistActivity.class));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void openMetadataEditor() {
        Intent editor = new Intent(this, MetadataEditor.class);
        Song current = (mServiceReady && mMusicService != null) ? mMusicService.getCurrentSong() : null;
        if (current != null && current.getPath() != null) {
            editor.putExtra("song_path", current.getPath());
            if (current.getUri() != null) editor.putExtra("song_uri", current.getUri());
            editor.putExtra("awaiting_file_selection", false);
        } else {
            editor.putExtra("awaiting_file_selection", true);
        }
        startActivity(editor);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    // ========================================================================
    // Initial Loading (Last Song Metadata)
    // ========================================================================
    
    private void loadLastSongMetadata() {
        ViewGroup rootView = findViewById(android.R.id.content);
        if (mDisplayManager != null && rootView != null) {
            mDisplayManager.showDelayedLoadingOverlay(rootView);
        }
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString("last_song_path", null);
        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) mSongTitle.setText("Loading...");
            if (mSongArtist != null) mSongArtist.setText("Loading...");
            if (mCurrentMetadataTask != null && !mCurrentMetadataTask.isDone())
                mCurrentMetadataTask.cancel(true);
            mCurrentMetadataTask = mMetadataExecutor.submit(() -> {
                Song song = null;
                try {
                    Song cached = SongDatabase.getInstance(this).getSong(lastPath);
                    if (cached != null && cached.getTitle() != null && !cached.getTitle().isEmpty()) {
                        song = cached;
                    } else {
                        android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                        mmr.setDataSource(lastPath);
                        String title = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String artist = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String album = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        mmr.release();
                        if (title == null || title.isEmpty()) {
                            File file = new File(lastPath);
                            String name = file.getName();
                            int dot = name.lastIndexOf('.');
                            if (dot > 0) name = name.substring(0, dot);
                            title = name;
                        }
                        if (artist == null) artist = "Unknown Artist";
                        if (album == null) album = "Unknown Album";
                        String genre = "Unknown Genre";
                        Song dbSong = SongDatabase.getInstance(this).getSong(lastPath);
                        if (dbSong != null && dbSong.getGenre() != null && !"Unknown Genre".equals(dbSong.getGenre()))
                            genre = dbSong.getGenre();
                        else {
                            String fileGenre = CharacterMapper.getGenre(lastPath);
                            if (fileGenre != null && !"Unknown Genre".equals(fileGenre))
                                genre = fileGenre;
                        }
                        song = new Song(title, artist, album, genre, lastPath, 0, null);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to load last song metadata", e);
                }
                final Song finalSong = song;
                mHandler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (finalSong != null) {
                        updateUIForSong(finalSong);
                        startServiceWithCachedSong();
                    } else {
                        applyNoSongState();
                        loadSongsAndStartService();
                    }
                });
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }

    private void startServiceWithCachedSong() {
        Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    private void loadSongsAndStartService() {
        ViewGroup rootView = findViewById(android.R.id.content);
        if (mDisplayManager != null && rootView != null) {
            mDisplayManager.showDelayedLoadingOverlay(rootView);
        }
        MusicLibrary musicLibrary = new MusicLibrary(this);
        musicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    refreshUiFromService();
                } else {
                    Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
            }
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }

    // ========================================================================
    // Theme
    // ========================================================================
    
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        registerReceiver(mRestartReceiver, new IntentFilter(ACTION_RESTART_APP));
    }

    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mManagerButton != null) mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        if (mLlamaButton != null) mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        if (mPlaylistButton != null) mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        if (mEqualizerButton != null) mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        if (mMetadataButton != null) mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());

        if (mPlayButton != null) {
            boolean isPlaying = mServiceReady && mMusicService != null && mMusicService.isPlaying();
            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        if (mNextButton != null) mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        if (mRepeatButton != null) {
            boolean isRepeatOn = mServiceReady && mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            boolean isShuffleOn = mServiceReady && mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }

        if (mSeekBar != null) mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        if (mSongTitle != null) mSongTitle.setTextColor(themeColor);
        if (mSeekTime != null) mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        if (mTotalTime != null) mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        if (mSongArtist != null) mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));

        if (mDisplayManager != null && mAlbumArtView != null) {
            mDisplayManager.refreshPlaceholder(mAlbumArtView);
        }
        ToastManager.refreshThemeColor();
    }

    private void performUpdate() {
        Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ========================================================================
    // Broadcast Receivers Setup
    // ========================================================================
    
    private void registerReceivers() {
        // UPDATE_PLAYER
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    refreshUiFromService();
                }
            }
        };
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");

        // FORCE_UPDATE_PLAYER
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    refreshUiFromService();
                    if (mDisplayManager != null && mAlbumArtView != null && mServiceReady && mMusicService != null) {
                        Song current = mMusicService.getCurrentSong();
                        if (current != null) mDisplayManager.updateAlbumArt(mAlbumArtView, current.getPath());
                    }
                }
            }
        };
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");

        // SOFT_UPDATE_PLAYLIST
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    refreshUiFromService();
                }
            }
        };
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");

        // BLUETOOTH_PLAY
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mServiceReady && mMusicService != null) {
                        int currentIndex = mMusicService.getCurrentIndex();
                        int playlistSize = mMusicService.getPlaylistSize();
                        if (currentIndex >= 0 && currentIndex < playlistSize) {
                            if (mMusicService.getDuration() == 0) {
                                mMusicService.playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (playlistSize > 0) {
                            mMusicService.playSong(0);
                        }
                        updatePlayPauseButton();
                    }
                }
            }
        };
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");

        // BLUETOOTH_PAUSE
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mServiceReady && mMusicService != null && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");

        // MEDIA_BUTTON_ACTION
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    int keyCode = intent.getIntExtra("key_code", -1);
                    if (mServiceReady && mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                        updatePlayPauseButton();
                    }
                }
            }
        };
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");

        // GET_PLAYING_STATE
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mServiceReady && mMusicService != null) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean("last_playing", mMusicService.isPlaying()).apply();
                    }
                }
            }
        };
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");

        // RESET_PLAYER_STATE
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    if (mServiceReady && mMusicService != null) {
                        mMusicService.stopCompletely();
                    }
                    runOnUiThread(() -> applyNoSongState());
                    if (!preserveSettings && mServiceReady && mMusicService != null) {
                        mMusicService.setRepeatMode(0);
                        mMusicService.setShuffle(false);
                    }
                    if (mDisplayManager != null) mDisplayManager.hideLoadingOverlay();
                    updatePlayPauseButton();
                    updateRepeatButtonIcon();
                    updateShuffleButtonIcon();
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");

        // SAVE_PLAYER_STATE_NOW
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mServiceReady && mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");

        // BLUETOOTH_CONNECTED
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    boolean connected = intent.getBooleanExtra("connected", false);
                    if (mServiceReady && mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");

        // SYNC_STARTED
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");

        // SYNC_COMPLETE
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                    refreshUiFromService();
                }
            }
        };
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");

        // UPDATE_PLAYLIST_FROM_FOLDERS
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    MusicLibrary lib = new MusicLibrary(MusicPlayer.this);
                    lib.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
                        @Override
                        public void onSongsLoaded(ArrayList<Song> songs) {
                            if (mServiceReady && mMusicService != null) {
                                mMusicService.setPlaylist(songs, true);
                                refreshUiFromService();
                                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                            }
                        }
                        @Override
                        public void onLoadingError(String error) {
                            Log.e(TAG, "Playlist update error: " + error);
                        }
                    });
                }
            }
        };
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");

        // UPDATE_SONG_IN_PLAYLIST
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    String songPath = intent.getStringExtra("song_path");
                    boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    String newTitle = intent.getStringExtra("title");
                    String newArtist = intent.getStringExtra("artist");
                    String newAlbum = intent.getStringExtra("album");
                    String newGenre = intent.getStringExtra("genre");

                    if (songPath == null || !mServiceReady || mMusicService == null) return;

                    mMusicService.refreshMetadataForSong(songPath, newTitle, newArtist, newAlbum, newGenre,
                            albumArtBytes, albumArtRemoved);

                    Song current = mMusicService.getCurrentSong();
                    if (current != null && songPath.equals(current.getPath())) {
                        if (albumArtRemoved && mDisplayManager != null) {
                            mDisplayManager.removeFromCache(songPath);
                            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                        } else if (hasAlbumArt && mDisplayManager != null) {
                            mDisplayManager.removeFromCache(songPath);
                            mDisplayManager.updateAlbumArt(mAlbumArtView, songPath);
                        }
                        refreshUiFromService();
                    }
                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                }
            }
        };
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");

        // PLAYBACK_RECOVERED
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");

        // SORT_MODE updates
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    refreshUiFromService();
                    Log.d(TAG, "Sort mode updated to " + newMode + ", UI refreshed");
                }
            }
        };
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    private void registerReceiverSafely(BroadcastReceiver receiver, String action) {
        if (receiver == null) return;
        try {
            IntentFilter filter = new IntentFilter(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        }
    }

    // ========================================================================
    // Listeners
    // ========================================================================
    
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlayPauseClickTime = now;
                    togglePlayPause();
                }
            });
        }
        if (mNextButton != null) {
            mNextButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastNextClickTime = now;
                    playNextSong();
                }
            });
        }
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPrevClickTime = now;
                    playPreviousSong();
                }
            });
        }
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastRepeatClickTime = now;
                    if (mServiceReady && mMusicService != null && mRepeatButton.isEnabled()) {
                        int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButtonIcon();
                        String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastShuffleClickTime = now;
                    if (mServiceReady && mMusicService != null && mShuffleButton.isEnabled()) {
                        boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButtonIcon();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastManagerClickTime = now;
                    openFolderManager();
                }
            });
        }
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastLlamaClickTime = now;
                    View main = findViewById(android.R.id.content);
                    main.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(d -> {
                        main.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                    });
                    dialog.show();
                }
            });
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlaylistClickTime = now;
                    openPlaylist();
                }
            });
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastEqualizerClickTime = now;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(v -> {
                long now = SystemClock.elapsedRealtime();
                if (now - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastMetadataClickTime = now;
                    openMetadataEditor();
                }
            });
        }
        setupSeekBar();
        startTimeDisplayUpdates();
    }

    // ========================================================================
    // Helpers
    // ========================================================================
    
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }
}