package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Renders the main playback screen and forwards user input to
 * {@link MusicService}.
 *
 * <p>The activity is a view over {@link MusicService}'s authoritative
 * playback state machine. User input is forwarded to the service, and
 * the resulting state is reflected from {@code UPDATE_PLAYER}
 * broadcasts. The activity does not own a transition state of its own;
 * the service owns every transition and the activity follows the
 * broadcasts.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The playback state machine is owned by {@link MusicService}. This
 * activity owns the render state derived from that machine: the text
 * and color of the current song's title and artist, the seek bar
 * position and duration, the enabled state of the transport controls,
 * and the album-art carousel's placeholder bitmap. Service calls are
 * serialised by {@link #mServiceLock}, and UI updates are coalesced by
 * {@link #safeUpdateUI(Runnable)}.</p>
 *
 * <p>The album-art carousel is a pure renderer of the
 * {@link PlaybackWindow} that the service publishes on every
 * {@code UPDATE_PLAYER} broadcast. The activity forwards the window to
 * the carousel and installs a listener that turns a committed swipe
 * into a next or previous request. The activity does not compute
 * neighbours, does not track a current art path, and does not mutate
 * the carousel's window by any path other than the broadcast and the
 * cold-start handoff. This is what keeps the carousel in sync with the
 * service unconditionally.</p>
 *
 * <p>The media session metadata and the playback notification are
 * owned by {@link NotificationController}. This activity does not push
 * art to the session. The service's prefetch resolves the art, pokes
 * the controller, and the controller writes both the notification and
 * the session metadata from one snapshot in one main-thread turn.</p>
 *
 * <h3>Ordering</h3>
 * <p>Media buttons from headsets, hardware keys, and notification
 * action buttons are routed through
 * {@code androidx.media.session.MediaButtonReceiver} and dispatched to
 * the active
 * {@link android.support.v4.media.session.MediaSessionCompat} held by
 * {@link MusicService}. This activity keeps a fallback
 * {@link #onKeyDown(int, KeyEvent)} for hardware keys delivered to a
 * focused activity.</p>
 *
 * <p>Every {@code UPDATE_PLAYER} carries a monotonic
 * {@code generation} alongside the full playback snapshot. The
 * activity tracks the highest generation it has seen and drops any
 * broadcast with a strictly lower one. Equal-generation broadcasts
 * are accepted because position and duration advance within a
 * generation. When the service is rebound, the high-water mark resets
 * to {@code -1}, because a new service instance restarts its counter
 * at zero. The same generation is also carried on the
 * {@link PlaybackWindow} the activity builds, so the carousel can
 * distinguish a fresh transition from a re-publication.</p>
 *
 * <h3>Volume-Key Observation</h3>
 * <p>The activity overrides {@link #dispatchKeyEvent(KeyEvent)} to
 * observe the volume-up key before the window system consumes it.
 * The event is not consumed. In one specific case — the music volume
 * is already at the device maximum and the song is bound but paused —
 * the activity resumes the song directly, because the framework emits
 * no {@code VOLUME_CHANGED_ACTION} when no value changes, and the
 * service's receiver never runs. See
 * {@link #resumeIfPausedAtMaxVolume()}.</p>
 *
 * <h3>Album-Art Gestures</h3>
 * <p>The album-art container owns every gesture that operates on the
 * album art. The container is divided into three horizontal zones:</p>
 * <ul>
 *   <li><b>Left edge</b> — {@link #VOLUME_GESTURE_EDGE_DP} wide.</li>
 *   <li><b>Middle</b> — the remainder.</li>
 *   <li><b>Right edge</b> — {@link #VOLUME_GESTURE_EDGE_DP} wide.</li>
 * </ul>
 *
 * <p>A single touch listener classifies each gesture on the first
 * significant move:</p>
 * <ul>
 *   <li><b>Horizontal</b> — the finger travels left or right.
 *       Anywhere on the art, this is the carousel's. The strip
 *       follows the finger, revealing the previous or next song's
 *       art. On release, the carousel either commits to the
 *       neighbour or springs back. Committing dispatches through the
 *       swipe commit listener installed in
 *       {@link #initializeViews()}, which calls
 *       {@link MusicService#playNextSong()} or
 *       {@link MusicService#playPreviousSong()}. The transport
 *       buttons drive the same visual slide:
 *       {@link #playNextSong()} and {@link #playPreviousSong()} call
 *       {@link AlbumArtCarousel#animateToNext()} and
 *       {@link AlbumArtCarousel#animateToPrevious()} before
 *       dispatching the service request, so the carousel's
 *       animation runs whether the user swiped or tapped.</li>
 *   <li><b>Vertical at edge</b> — the touch started in an edge zone
 *       and the finger travels up or down. The music stream volume
 *       is raised or lowered.</li>
 *   <li><b>Vertical at centre</b> — the touch started away from both
 *       edge zones and the finger travels vertically. The gesture is
 *       a no-op.</li>
 * </ul>
 *
 * <p>When the volume gesture reaches the device maximum or zero and
 * the finger continues to travel in the same direction, the volume
 * toast echoes at a fixed rhythm until the finger lifts or reverses
 * back inside the range. The echo is the same toast; its rhythm is
 * what tells the user the gesture is still being tracked even though
 * the device volume cannot change further.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>{@link #applyAlbumArtSize(Configuration)} decides the
 * album-art container's size and visibility from
 * {@code Configuration.screenHeightDp}. In tall windows the art is
 * shown at full size; in medium windows it shrinks; in short windows
 * it hides so the title, controls, and seek bar take the space.
 * Nothing else in the view hierarchy is touched: the top bar, song
 * info, seek bar, transport controls, and the metadata/equalizer row
 * are fixed-height and fit comfortably at 400dp.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Cold start shows {@link OverlayManager} under
 * {@link OverlayManager#REASON_COLD_START} while the library loads.
 * The overlay is hidden by the load's completion or error callback.
 * When the library is reset, {@link PlaylistManager}'s reset operation
 * sends a {@code LIBRARY_RESET} broadcast that this activity receives
 * through its own receiver.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Service calls are serialised by {@link #mServiceLock}. UI updates
 * are coalesced by {@link #safeUpdateUI(Runnable)}. The main handler
 * is drained in {@link #onDestroy()} so no post is left after the
 * activity is gone.</p>
 *
 * @see MusicService
 * @see MusicLibrary
 * @see OverlayManager
 * @see AlbumArtCarousel
 * @see PlaybackWindow
 * @see NotificationController
 * @see ThemeHelper
 * @see NavigationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.3
 * @since 1.0.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "MusicPlayer";

    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** Request code for the folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;

    /** Request code for the battery optimization request. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last playing flag. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Intent action that restarts the app after an update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";

    /** Broadcast action that updates the sort mode from the playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Broadcast action that sets a pending song path in the service. */
    private static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Operation ID for the library-load overlay mirror. */
    private static final String OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD";

    /** Message shown during the cold-start library load. */
    private static final String MESSAGE_LIBRARY_LOAD = "Just a moment...";

    /** Interval for the library-load heartbeat, in milliseconds. */
    private static final long LIBRARY_HEARTBEAT_INTERVAL_MS = 500;

    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;

    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay for the service reconnection in milliseconds. */
    private static final long RECONNECT_SERVICE_DELAY_MS = 1000;

    /** Delay before updating the next and previous buttons. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;

    /** Delay before updating the repeat and shuffle buttons. */
    private static final long REPEAT_SHUFFLE_DELAY_MS = 250;

    /** Delay before playing loose tracks. */
    private static final long PLAY_LOOSE_TRACKS_DELAY_MS = 500;

    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;

    /** Delay before performing focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Buffer size for file copy operations. */
    private static final int BUFFER_SIZE = 8192;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Duration of the button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float BUTTON_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;

    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    /**
     * Width of the volume-gesture edge zone on each side of the
     * album-art container, in density-independent pixels.
     *
     * <p>At the full album-art width of
     * {@link #ALBUM_ART_FULL_DP}, the two edge zones plus the middle
     * zone are {@code 30 + 240 + 30}. The middle zone is the
     * carousel's; the two edge zones are the volume gesture's. A
     * horizontal swipe anywhere on the container is the carousel's;
     * a vertical swipe is a volume gesture only when it started
     * inside an edge zone.</p>
     */
    private static final int VOLUME_GESTURE_EDGE_DP = 30;

    /**
     * Fraction of the device's volume range the finger must travel
     * past a limit before the volume toast echoes a second time.
     *
     * <p>Once the target volume is clamped to the device maximum or
     * to zero, further finger travel in the same direction changes
     * nothing on the device. The echo gives the user rhythmic
     * confirmation that the gesture is still being tracked. The
     * rhythm is expressed on the volume axis rather than the pixel
     * axis, so it is the same on every device regardless of how many
     * volume steps the platform reports.</p>
     */
    private static final float VOLUME_LIMIT_ECHO_STEP_FRACTION = 0.15f;

    /** The gesture is not currently clamped to either volume limit. */
    private static final int VOLUME_LIMIT_SIDE_NONE = 0;

    /** The gesture is clamped to the device's maximum music volume. */
    private static final int VOLUME_LIMIT_SIDE_MAXIMUM = +1;

    /** The gesture is clamped to zero music volume. */
    private static final int VOLUME_LIMIT_SIDE_MINIMUM = -1;

    /**
     * Window height above which the album art is shown at its full
     * size.
     */
    private static final int SPLIT_SCREEN_FULL_HEIGHT_DP = 600;

    /**
     * Window height below which the album art is hidden entirely.
     */
    private static final int SPLIT_SCREEN_MIN_HEIGHT_DP = 400;

    /** Album-art size at full screen, in dp. */
    private static final int ALBUM_ART_FULL_DP = 300;

    /** Album-art size in a shrunk split-screen window, in dp. */
    private static final int ALBUM_ART_SHRUNK_DP = 180;

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Text view showing the current song title. */
    @Nullable private TextView mSongTitle;

    /** Text view showing the current song artist. */
    @Nullable private TextView mSongArtist;

    /** Text view showing the elapsed playback time. */
    @Nullable private TextView mSeekTime;

    /** Text view showing the total playback duration. */
    @Nullable private TextView mTotalTime;

    /** Seek bar for scrubbing through the current song. */
    @Nullable private SeekBar mSeekBar;

    /** Play or pause button. */
    @Nullable private Button mPlayButton;

    /** Previous-track button. */
    @Nullable private Button mPrevButton;

    /** Next-track button. */
    @Nullable private Button mNextButton;

    /** Repeat-mode button. */
    @Nullable private Button mRepeatButton;

    /** Shuffle button. */
    @Nullable private Button mShuffleButton;

    /** Button that opens the folder manager. */
    @Nullable private Button mManagerButton;

    /** Button that opens the credits dialog. */
    @Nullable private Button mLlamaButton;

    /** Button that opens the playlist activity. */
    @Nullable private Button mPlaylistButton;

    /** Button that opens the equalizer activity. */
    @Nullable private Button mEqualizerButton;

    /** Button that opens the metadata editor. */
    @Nullable private Button mMetadataButton;

    /** Container that hosts the album-art carousel. */
    @Nullable private FrameLayout mAlbumArtContainer;

    // ============================================================================
    // Managers and Services
    // ============================================================================

    /** In-memory library used to read the current song list. */
    @Nullable private MusicLibrary mMusicLibrary;

    /** Bound service that owns the playback state machine. */
    @Nullable private MusicService mMusicService;

    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageAccessHelper;

    /** Handler for UI operations. */
    @NonNull private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Handler for delayed service operations. */
    @NonNull private final Handler mServiceHandler =
        new Handler(Looper.getMainLooper());

    /** Handler used to schedule time-display updates; null when idle. */
    @Nullable private Handler mTimeHandler = null;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** True while the user is dragging the seek bar. */
    private boolean mIsUserSeeking = false;

    /** Guard that serialises concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI =
        new AtomicBoolean(false);

    /** Deferred UI update posted while another update is running. */
    @Nullable private Runnable mPendingUIUpdate = null;

    /** Song path queued for playback once the service is bound. */
    private volatile String mPendingIncomingPath = null;

    /** Lock that serialises service calls. */
    @NonNull private final Object mServiceLock = new Object();

    /** Highest generation seen in an {@code UPDATE_PLAYER} broadcast. */
    private long mLastSeenGeneration = -1L;

    // ============================================================================
    // State Flags
    // ============================================================================

    /** True when the activity was started as part of a post-update restart. */
    private boolean mIsPostUpdateRestart = false;

    /** True once the cold-start library load has been requested. */
    private boolean isLoadingComplete = false;

    /** Runnable that heartbeats the library-load overlay. */
    @Nullable private Runnable mLibraryHeartbeatRunnable;

    // ============================================================================
    // Click Debounce Timestamps
    // ============================================================================

    /** Timestamp of the last play or pause click. */
    private long mLastPlayPauseClickTime = 0;

    /** Timestamp of the last next-track click. */
    private long mLastNextClickTime = 0;

    /** Timestamp of the last previous-track click. */
    private long mLastPrevClickTime = 0;

    /** Timestamp of the last repeat-mode click. */
    private long mLastRepeatClickTime = 0;

    /** Timestamp of the last shuffle click. */
    private long mLastShuffleClickTime = 0;

    /** Timestamp of the last equalizer button click. */
    private long mLastEqualizerClickTime = 0;

    /** Timestamp of the last manager button click. */
    private long mLastManagerClickTime = 0;

    /** Timestamp of the last llama button click. */
    private long mLastLlamaClickTime = 0;

    /** Timestamp of the last playlist button click. */
    private long mLastPlaylistClickTime = 0;

    /** Timestamp of the last metadata button click. */
    private long mLastMetadataClickTime = 0;

    // ============================================================================
    // Album Art Components
    // ============================================================================

    /** Cache of decoded album art bitmaps keyed by song path. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;

    /** Executor for album art decoding. */
    @NonNull private final ExecutorService mAlbumArtExecutor =
        Executors.newSingleThreadExecutor();

    /** Executor for metadata loading. */
    @NonNull private final ExecutorService mMetadataLoader =
        Executors.newSingleThreadExecutor();

    /** Currently running metadata load task. */
    @Nullable private Future<?> mCurrentMetadataFuture = null;

    /** Currently displayed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Untinted placeholder bitmap used to regenerate the tinted copy. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;

    /** Executor for placeholder rendering. */
    @NonNull private final ExecutorService mPlaceholderExecutor =
        Executors.newSingleThreadExecutor();

    /** Currently running placeholder render task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;

    /** Lock guarding the placeholder bitmaps. */
    @NonNull private final Object mPlaceholderLock = new Object();

    /**
     * Three-slot carousel that owns the album-art strip.
     *
     * <p>Constructed in {@link #onCreate(Bundle)} and attached to
     * {@link #mAlbumArtContainer} by {@link #initializeViews()}. The
     * carousel owns the strip, the three ImageViews, and the rolling
     * window of decoded bitmaps. The activity supplies the window the
     * carousel renders through {@link #refreshCarouselFromService()}
     * and through the {@code UPDATE_PLAYER} broadcast receiver, and
     * drives the carousel's slide for a transport button press through
     * {@link AlbumArtCarousel#animateToNext()} and
     * {@link AlbumArtCarousel#animateToPrevious()}.</p>
     */
    @Nullable private AlbumArtCarousel mAlbumArtCarousel;

    /** Manager for the current theme color. */
    @Nullable private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    @Nullable private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    @Nullable private BroadcastReceiver mThemeReceiver;

    /** Observer for MediaStore changes. */
    @Nullable private StorageObserver mStorageObserver;

    /** Song loaded from the persisted last path at startup. */
    @Nullable private Song mCachedLastSong = null;

    // ============================================================================
    // Gesture State
    // ============================================================================

    /** System audio manager, resolved in onCreate; null on devices without one. */
    @Nullable private AudioManager mAudioManager;

    /**
     * Modes a touch sequence on the album-art container can settle
     * into.
     */
    private enum GestureMode {

        /** No classification yet; the sequence is still in its slop window. */
        UNDECIDED,

        /** The gesture is a horizontal swipe on the album-art carousel. */
        CAROUSEL,

        /** The gesture is a vertical volume swipe in an edge zone. */
        VOLUME,

        /** The gesture has been classified but is not consumed. */
        CANCELLED
    }

    /** Current gesture mode. */
    @NonNull private GestureMode mGestureMode = GestureMode.UNDECIDED;

    /** X coordinate of the gesture's starting touch, in view-local pixels. */
    private float mGestureStartX = 0f;

    /** Y coordinate of the gesture's starting touch, in view-local pixels. */
    private float mGestureStartY = 0f;

    /** Container width sampled at gesture start, in pixels. */
    private int mGestureContainerWidth = 1;

    /** Container height sampled at gesture start, in pixels. */
    private int mGestureContainerHeight = 1;

    /** Music-stream volume at the start of a volume gesture. */
    private int mVolumeGestureStartVolume = 0;

    /** Maximum music-stream volume on this device, sampled at gesture start. */
    private int mVolumeGestureMaxVolume = 0;

    /**
     * Sign of the volume limit the gesture is currently riding: one
     * of {@link #VOLUME_LIMIT_SIDE_MAXIMUM},
     * {@link #VOLUME_LIMIT_SIDE_MINIMUM}, or
     * {@link #VOLUME_LIMIT_SIDE_NONE}.
     */
    private int mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;

    /**
     * Finger overshoot past the current limit at which the last
     * limit-echo toast fired, measured in volume steps.
     *
     * <p>Acts as the baseline from which the next echo step is
     * measured: the next echo fires when the current overshoot
     * reaches this value plus one echo step.
     * {@link Float#NaN} means no toast has fired at this limit yet
     * during the current gesture; the first overshoot past the limit
     * will fire immediately.</p>
     */
    private float mVolumeGestureLimitEchoBaseline = Float.NaN;

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mLibraryResetReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mMetadataUpdatedReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;

    // ============================================================================
    // Service Connection
    // ============================================================================

    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            mLastSeenGeneration = -1L;

            if (mPendingIncomingPath != null) {
                final String pendingPath = mPendingIncomingPath;
                mPendingIncomingPath = null;
                Log.d(TAG,
                    "Processing pending incoming file on service connect: "
                        + pendingPath);
                mMusicService.setPendingSongPath(pendingPath);
                sendBroadcast(new Intent("UPDATE_PLAYLIST"));
            }

            if (mPlayButton != null && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                }
            }

            loadFullPlaylistInBackground();
            updateRepeatButton();
            updateShuffleButton();
            refreshCarouselFromService();

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }
                    if (mMusicLibrary != null
                            && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        final boolean isPlayingNow =
                            (mMusicService != null
                                && mMusicService.isPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow
                                ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(
                                mPlayButton, true, true);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(
                                mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(
                                mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        refreshCarouselFromService();
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);

            setupSeekBar();
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");

            mServiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing()
                            && !isDestroyed()) {
                        Log.d(TAG,
                            "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(
                            MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection,
                            BIND_AUTO_CREATE);
                    }
                }
            }, RECONNECT_SERVICE_DELAY_MS);
        }
    };

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, the view hierarchy, the receivers,
     * and the service binding, and starts the permission check.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);

        ToastManager.init(this);
        OverlayManager.init(this);

        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }

        FontAwesome.init(this);

        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageAccessHelper = StorageAccessHelper.getInstance(this);
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        mIsPostUpdateRestart = getIntent()
            .getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        checkPermissionsAndInitialize();

        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();

        applyThemeToUI();
        NavigationController.getInstance().registerListener(this);
    }

    /**
     * Registers the theme receiver if it is not already registered.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the playback display from the service, and reapplies the
     * theme.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }

        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS));

        if (mMusicService != null && mMusicLibrary != null
                && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();
            refreshCarouselFromService();
        }

        applyThemeToUI();
        ToastManager.refreshThemeColor();

        if (!isLoadingComplete && !ToastManager.hasPersistentToast()) {
            isLoadingComplete = true;
            ToastManager.showPersistentOverlay(
                this, MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
        }

        ensureLibraryLoadHeartbeat();
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Releases every resource held by the activity.
     *
     * <p>Does not tear down any persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; this
     * activity may be destroying itself while {@link FolderManager}
     * still owns the {@code "FOLDER_SYNC"} overlay or
     * {@link PlaylistManager} still owns the
     * {@code "GENRE_UPDATE"} or {@code "LIBRARY_RESET"} overlays.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }

        mServiceHandler.removeCallbacksAndMessages(null);

        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdownNow();
        }
        if (mMetadataLoader != null && !mMetadataLoader.isShutdown()) {
            mMetadataLoader.shutdownNow();
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
            mCurrentMetadataFuture = null;
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.clear();
            mAlbumArtCarousel = null;
        }

        if (mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
            mAlbumArtCache = null;
        }

        mPendingUIUpdate = null;

        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
            mMusicLibrary = null;
        }

        NavigationController.getInstance().unregisterListener(this);

        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }

        final Intent stopNotifIntent =
            new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                // The service was already unbound.
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);

        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
        }

        cleanupPlaceholderBitmaps();
    }

    /**
     * Forwards the trim-memory signal to the bound service when one
     * is available, and evicts the album art cache under sustained
     * pressure.
     *
     * @param level The trim-memory level reported by the framework
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception exception) {
                Log.e(TAG,
                    "Failed to forward onTrimMemory to service", exception);
            }
        }
        if (level >= TRIM_MEMORY_BACKGROUND && mAlbumArtCache != null) {
            mAlbumArtCache.evictAll();
        }
    }

    /**
     * Updates the intent and either closes the app or processes a
     * new incoming file.
     *
     * @param intent The new intent delivered to the activity
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }

    /**
     * Reapplies immersive mode when the window gains focus.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * Applies the album-art size and visibility for the new window
     * height.
     *
     * <p>The activity declares {@code configChanges} for
     * {@code orientation}, {@code screenSize},
     * {@code smallestScreenSize}, {@code screenLayout}, and
     * {@code keyboardHidden}, so a resize does not recreate the
     * activity. Nothing else in the view hierarchy is touched: the
     * top bar, song info, seek bar, transport controls, and the
     * metadata/equalizer row are fixed-height and fit comfortably
     * inside the shortest window the app supports.</p>
     *
     * @param config New configuration
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        applyAlbumArtSize(config);
    }

    /**
     * Intercepts the volume-up key before the window handles it.
     *
     * <p>The framework does not deliver {@code KEYCODE_VOLUME_UP} to
     * {@link #onKeyDown(int, KeyEvent)}; the window system consumes it
     * first. {@code dispatchKeyEvent} is the only method that sees the
     * key before the window does.</p>
     *
     * <p>The event is not consumed. The system still processes the
     * volume key as it normally would; this override only observes the
     * key and, in one specific case, performs a side effect. That case
     * is the one the broadcast path cannot cover: the volume is
     * already at the device maximum, the song is bound but paused,
     * and the user pressed volume up. No volume change occurs, so the
     * system emits no {@code VOLUME_CHANGED_ACTION}, and the receiver
     * in {@link MusicService} never fires. Resuming from here closes
     * that gap.</p>
     *
     * @param event The key event delivered to the activity
     * @return Whatever {@code super.dispatchKeyEvent} returns
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            resumeIfPausedAtMaxVolume();
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * Handles media keys delivered to a focused activity.
     *
     * @param keyCode Code of the pressed key
     * @param event Full key event
     * @return True when the key was consumed
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Resumes playback when the volume is already at the device
     * maximum and the user pressed volume up while a song was bound
     * but paused.
     *
     * <p>Does nothing in every other case. A volume change below the
     * maximum is handled by the receiver in {@link MusicService}, which
     * fires on the broadcast the system emits when the value changes.
     * This method exists solely for the at-maximum case, where no
     * broadcast is emitted because no change occurred.</p>
     */
    private void resumeIfPausedAtMaxVolume() {
        if (mAudioManager == null
                || mMusicService == null
                || !mIsServiceBound) {
            return;
        }
        try {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume <= 0) {
                return;
            }
            final int currentVolume = mAudioManager.getStreamVolume(
                AudioManager.STREAM_MUSIC);
            if (currentVolume < maxVolume) {
                return;
            }
            if (!mMusicService.isPausedOrReady()) {
                return;
            }
            mMusicService.resume();
        } catch (Exception exception) {
            Log.w(TAG,
                "Failed to resume on volume-up at max", exception);
        }
    }

    /**
     * Handles the folder selection result and the battery
     * optimization result.
     *
     * @param requestCode The request code passed to the launcher
     * @param resultCode The result code returned by the target
     *        activity
     * @param data The intent carrying the result, or null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FOLDER_SELECT_CODE
                && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageAccessHelper != null) {
                final String folderPath =
                    mStorageAccessHelper.getFolderPathFromUri(treeUri);
                mStorageAccessHelper.storeFolderPermission(
                    treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName =
                    mStorageAccessHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName,
                    ToastManager.LENGTH_NORMAL);
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager powerManager =
                    (PowerManager) getSystemService(POWER_SERVICE);
                if (powerManager != null) {
                    boolean isOptimized =
                        powerManager.isIgnoringBatteryOptimizations(
                            getPackageName());
                    showBatteryOptimizationToast(isOptimized);
                }
            }
        }
    }

    /**
     * Shows a battery optimization result toast after a short delay.
     *
     * @param optimized True when the app is exempt from battery
     *        optimizations
     */
    private void showBatteryOptimizationToast(boolean optimized) {
        ToastManager.hidePersistentOverlay();

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    String message = optimized
                        ? "Background playback optimized"
                        : "Background playback restricted";
                    ToastManager.showToast(MusicPlayer.this, message,
                        ToastManager.LENGTH_SHORT);
                }
            }
        }, 150);
    }

    /**
     * Handles the runtime permission result, proceeding with
     * initialization when every permission was granted.
     *
     * @param requestCode The permission request code
     * @param permissions The requested permissions
     * @param grantResults The results for each permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions,
            grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
            } else {
                ToastManager.showToast(MusicPlayer.this,
                    "Permissions required to read and play songs in background",
                    ToastManager.LENGTH_NORMAL);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        }
    }

    // ============================================================================
    // NavigationController Listener Implementation
    // ============================================================================

    /**
     * Enables or disables the playlist and metadata buttons
     * according to the current database-actions state.
     *
     * @param group Button group whose state changed
     * @param disabled True when the group is disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group,
                                     boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mPlaylistButton, !finalDisabled);
                        }
                    }

                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(
                                mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization Methods
    // ============================================================================

    /**
     * Resolves every view, attaches typefaces and touch animations,
     * constructs the album-art carousel with its swipe commit
     * listener, and primes the initial control state.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtContainer =
            (FrameLayout) findViewById(R.id.albumArtContainer);

        if (mAlbumArtContainer != null && mAlbumArtCache != null) {
            mAlbumArtCarousel = new AlbumArtCarousel(
                this, mAlbumArtContainer, mAlbumArtCache,
                mAlbumArtExecutor);
            mAlbumArtCarousel.setEdgeZonePx(
                dpToPx(VOLUME_GESTURE_EDGE_DP));
            mAlbumArtCarousel.setSwipeCommitListener(direction -> {
                if (direction > 0) {
                    playNextSong();
                } else if (direction < 0) {
                    playPreviousSong();
                }
            });
            mAlbumArtCarousel.attach();
        }

        applyAlbumArtClipping();
        setupAlbumArtGestures();

        final Typeface fontAwesomeTypeface = FontAwesome.getTypeface();

        if (mPlayButton != null) {
            mPlayButton.setTypeface(fontAwesomeTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(fontAwesomeTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(fontAwesomeTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(fontAwesomeTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(fontAwesomeTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) {
            mPlayButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mPrevButton != null) {
            mPrevButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mNextButton != null) {
            mNextButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setBackgroundResource(
                R.drawable.control_button_selector);
        }
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(
                R.drawable.button_border_selector);
        }

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        applyAlbumArtSize(getResources().getConfiguration());

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Refreshes the carousel's window from the bound service.
     *
     * <p>Called after the service is bound and on every resume. The
     * ordinary update path goes through the {@code UPDATE_PLAYER}
     * broadcast; this method exists for the reconnect and cold-start
     * cases, where the broadcast may have fired before the activity
     * was listening.</p>
     */
    private void refreshCarouselFromService() {
        if (mMusicService == null || mAlbumArtCarousel == null) {
            return;
        }
        mAlbumArtCarousel.setWindow(mMusicService.getWindowSnapshot());
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(BUTTON_SCALE_DOWN)
                            .scaleY(BUTTON_SCALE_DOWN)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(BUTTON_SCALE_NORMAL)
                            .scaleY(BUTTON_SCALE_NORMAL)
                            .setDuration(BUTTON_ANIMATION_DURATION_MS)
                            .start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Split-Screen Layout
    // ============================================================================

    /**
     * Applies the album-art size and visibility for the current
     * window height.
     *
     * <p>The decision is a pure function of
     * {@code config.screenHeightDp}, which in multi-window mode is
     * the height of this app's window, not the device screen.</p>
     *
     * <ul>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_FULL_HEIGHT_DP}: album art visible
     *       at {@link #ALBUM_ART_FULL_DP} dp.</li>
     *   <li>Height greater than or equal to
     *       {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}: album art visible
     *       at {@link #ALBUM_ART_SHRUNK_DP} dp. The gestures remain
     *       available.</li>
     *   <li>Height below {@link #SPLIT_SCREEN_MIN_HEIGHT_DP}:
     *       album art hidden. The gestures are unavailable, and the
     *       title, controls, and seek bar take the space.</li>
     * </ul>
     *
     * @param config Configuration carrying the current window height
     */
    private void applyAlbumArtSize(@NonNull Configuration config) {
        if (mAlbumArtContainer == null) {
            return;
        }

        final int heightDp = config.screenHeightDp;
        final int sizeDp;
        final int visibility;

        if (heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP) {
            sizeDp = ALBUM_ART_FULL_DP;
            visibility = View.VISIBLE;
        } else if (heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP) {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.VISIBLE;
        } else {
            sizeDp = ALBUM_ART_SHRUNK_DP;
            visibility = View.GONE;
        }

        final int sizePx = dpToPx(sizeDp);
        final ViewGroup.LayoutParams params =
            mAlbumArtContainer.getLayoutParams();
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx;
            params.height = sizePx;
            mAlbumArtContainer.setLayoutParams(params);
        }
        if (mAlbumArtContainer.getVisibility() != visibility) {
            mAlbumArtContainer.setVisibility(visibility);
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.onContainerResized();
        }
    }

    // ============================================================================
    // Album-Art Gestures
    // ============================================================================

    /**
     * Attaches the gesture listener to the album-art container.
     *
     * <p>The listener classifies the gesture on the first
     * significant move. Horizontal moves become carousel swipes;
     * vertical moves that start in an edge zone become volume
     * changes; vertical moves that start at the centre are
     * cancelled. See {@link GestureMode} for the classification.</p>
     *
     * <p>While a gesture is active, the container requests its
     * parent to disallow intercepting the touch. That keeps a swipe
     * from being consumed by a scroll container above the album
     * art.</p>
     */
    private void setupAlbumArtGestures() {
        if (mAlbumArtContainer == null) {
            return;
        }
        mAlbumArtContainer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                return handleAlbumArtGesture(view, event);
            }
        });
    }

    /**
     * Dispatches a touch event on the album-art container through
     * the gesture classifier and the selected mode's handler.
     *
     * @param view Album-art container
     * @param event Touch event
     * @return True when the gesture is being consumed
     */
    private boolean handleAlbumArtGesture(@NonNull View view,
                                          @NonNull MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return handleGestureDown(view, event);
            case MotionEvent.ACTION_MOVE:
                return handleGestureMove(view, event);
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return handleGestureUp(view, event);
            default:
                return false;
        }
    }

    /**
     * Handles the start of a touch sequence on the album-art
     * container.
     *
     * <p>Every touch is consumed at this point; the classification
     * happens on the first significant move. Both start coordinates
     * are recorded in the container's own coordinate space, the
     * same space the moves that will be compared against them
     * arrive in. The container's dimensions are sampled so the
     * volume mapping and the carousel threshold use the size the
     * container had at the moment the finger went down.</p>
     *
     * <p>The volume limit-echo state is reset here, so the first
     * move of every gesture establishes the limit side afresh.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_DOWN} event
     * @return Always true; the sequence is consumed from this point
     */
    private boolean handleGestureDown(@NonNull View view,
                                      @NonNull MotionEvent event) {
        mGestureMode = GestureMode.UNDECIDED;
        mGestureStartX = event.getX();
        mGestureStartY = event.getY();
        mGestureContainerWidth = Math.max(1, view.getWidth());
        mGestureContainerHeight = Math.max(1, view.getHeight());

        if (mAudioManager != null) {
            final int maxVolume = mAudioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC);
            if (maxVolume > 0) {
                mVolumeGestureMaxVolume = maxVolume;
                mVolumeGestureStartVolume = mAudioManager.getStreamVolume(
                    AudioManager.STREAM_MUSIC);
            } else {
                mVolumeGestureMaxVolume = 0;
                mVolumeGestureStartVolume = 0;
            }
        } else {
            mVolumeGestureMaxVolume = 0;
            mVolumeGestureStartVolume = 0;
        }

        mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
        mVolumeGestureLimitEchoBaseline = Float.NaN;

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    /**
     * Handles a move event on the album-art container, classifying
     * the gesture on the first significant move and then dispatching
     * to the selected mode's handler.
     *
     * @param view Album-art container
     * @param event {@code ACTION_MOVE} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureMove(@NonNull View view,
                                      @NonNull MotionEvent event) {
        if (mGestureMode == GestureMode.UNDECIDED) {
            classifyGesture(event);
        }

        switch (mGestureMode) {
            case CAROUSEL:
                if (mAlbumArtCarousel != null) {
                    final float horizontalDisplacement =
                        event.getX() - mGestureStartX;
                    mAlbumArtCarousel.updateSwipe(horizontalDisplacement);
                }
                return true;
            case VOLUME:
                handleVolumeDrag(event);
                return true;
            case CANCELLED:
            case UNDECIDED:
            default:
                return true;
        }
    }

    /**
     * Handles the release of a touch sequence on the album-art
     * container, committing the carousel swipe when it passed its
     * threshold and releasing the parent's touch interception.
     *
     * <p>A committed swipe is dispatched by the carousel through the
     * listener installed in {@link #initializeViews()}. This method
     * does not inspect the commit result; the carousel and the
     * service settle their agreement through the playback
     * broadcast.</p>
     *
     * @param view Album-art container
     * @param event {@code ACTION_UP} or {@code ACTION_CANCEL} event
     * @return True when the gesture is being consumed
     */
    private boolean handleGestureUp(@NonNull View view,
                                    @NonNull MotionEvent event) {
        if (mGestureMode == GestureMode.CAROUSEL
                && mAlbumArtCarousel != null) {
            final float horizontalDisplacement =
                event.getX() - mGestureStartX;
            mAlbumArtCarousel.endSwipe(horizontalDisplacement);
        }

        final ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }

        mGestureMode = GestureMode.UNDECIDED;
        return true;
    }

    /**
     * Classifies a gesture on the first significant move.
     *
     * <p>The touch slop is read from the container's configuration.
     * Anything inside the slop leaves the mode at
     * {@link GestureMode#UNDECIDED}. A move whose horizontal
     * component dominates becomes a carousel swipe regardless of
     * where it started. A move whose vertical component dominates
     * becomes a volume gesture only when the touch started inside
     * one of the two edge zones; otherwise it is cancelled.</p>
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void classifyGesture(@NonNull MotionEvent event) {
        final float horizontalDisplacement = event.getX() - mGestureStartX;
        final float verticalDisplacement = event.getY() - mGestureStartY;
        final float absoluteHorizontal = Math.abs(horizontalDisplacement);
        final float absoluteVertical = Math.abs(verticalDisplacement);
        final int touchSlop = ViewConfiguration.get(this)
            .getScaledTouchSlop();

        if (absoluteHorizontal < touchSlop
                && absoluteVertical < touchSlop) {
            return;
        }

        if (absoluteHorizontal > absoluteVertical) {
            mGestureMode = GestureMode.CAROUSEL;
            if (mAlbumArtCarousel != null) {
                mAlbumArtCarousel.beginSwipe();
            }
            return;
        }

        final int edgeZone = dpToPx(VOLUME_GESTURE_EDGE_DP);
        final boolean startedInEdge =
            mGestureStartX <= edgeZone
                || mGestureStartX >= mGestureContainerWidth - edgeZone;
        if (startedInEdge && mVolumeGestureMaxVolume > 0) {
            mGestureMode = GestureMode.VOLUME;
            return;
        }

        mGestureMode = GestureMode.CANCELLED;
    }

    /**
     * Applies a vertical drag to the music stream volume.
     *
     * <p>The finger's vertical displacement is mapped linearly onto
     * the volume range: a full container height of travel moves
     * through every step. Upward travel raises the volume; downward
     * travel lowers it. The target is clamped to the range the
     * platform reports.</p>
     *
     * <p>When the target is clamped to a limit and the user continues
     * dragging past it, the volume toast echoes every
     * {@link #VOLUME_LIMIT_ECHO_STEP_FRACTION} of the range the
     * finger travels beyond the limit. The echo gives the user
     * rhythmic confirmation that the gesture is still being tracked
     * even though the device volume cannot change further. The
     * rhythm is measured on the volume axis, so it is the same on
     * every device regardless of how many volume steps the platform
     * reports.</p>
     *
     * <p>The first arrival at a limit fires the ordinary toast
     * through the volume-change path; the echo path is used only for
     * the additional travel past a limit whose toast has already
     * fired at that limit during this gesture.</p>
     *
     * @param event {@code ACTION_MOVE} event
     */
    private void handleVolumeDrag(@NonNull MotionEvent event) {
        if (mAudioManager == null || mVolumeGestureMaxVolume <= 0) {
            return;
        }

        final float verticalDisplacement = event.getY() - mGestureStartY;
        final float fraction =
            -verticalDisplacement / mGestureContainerHeight;
        final float unclampedTarget = mVolumeGestureStartVolume
            + fraction * mVolumeGestureMaxVolume;
        int targetVolume = Math.round(unclampedTarget);
        targetVolume = Math.max(0,
            Math.min(mVolumeGestureMaxVolume, targetVolume));

        final int currentVolume = mAudioManager.getStreamVolume(
            AudioManager.STREAM_MUSIC);

        // Establish which limit, if any, the gesture is currently riding.
        // The side is recorded the first time the target reaches a limit
        // and cleared the moment the target moves back inside the range.
        if (targetVolume == mVolumeGestureMaxVolume) {
            if (mVolumeGestureLimitSide != VOLUME_LIMIT_SIDE_MAXIMUM) {
                mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_MAXIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else if (targetVolume == 0) {
            if (mVolumeGestureLimitSide != VOLUME_LIMIT_SIDE_MINIMUM) {
                mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_MINIMUM;
                mVolumeGestureLimitEchoBaseline = Float.NaN;
            }
        } else {
            mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE;
            mVolumeGestureLimitEchoBaseline = Float.NaN;
        }

        if (targetVolume != currentVolume) {
            try {
                mAudioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC, targetVolume, 0);
                showVolumeToast(targetVolume);
            } catch (SecurityException exception) {
                Log.w(TAG, "setStreamVolume refused", exception);
            }
            // The change was the arrival toast for this limit, if the
            // target is now at one. Record the baseline so the echo
            // rhythm starts from here.
            if (targetVolume == mVolumeGestureMaxVolume) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f, unclampedTarget - mVolumeGestureMaxVolume);
            } else if (targetVolume == 0) {
                mVolumeGestureLimitEchoBaseline =
                    Math.max(0f, -unclampedTarget);
            }
            return;
        }

        // No change in device volume. If the gesture is riding a limit,
        // echo the toast each time the finger has travelled an additional
        // echo step past the limit since the last toast.
        final float echoStep = Math.max(1f,
            mVolumeGestureMaxVolume * VOLUME_LIMIT_ECHO_STEP_FRACTION);

        if (targetVolume == mVolumeGestureMaxVolume
                && mVolumeGestureLimitSide == VOLUME_LIMIT_SIDE_MAXIMUM) {
            final float overshoot =
                unclampedTarget - mVolumeGestureMaxVolume;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        } else if (targetVolume == 0
                && mVolumeGestureLimitSide == VOLUME_LIMIT_SIDE_MINIMUM) {
            final float overshoot = -unclampedTarget;
            final float baseline = Float.isNaN(
                    mVolumeGestureLimitEchoBaseline)
                ? -echoStep
                : mVolumeGestureLimitEchoBaseline;
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot;
                showVolumeToast(targetVolume);
            }
        }
    }

    /**
     * Shows a transient toast reporting the current volume as a
     * percentage.
     *
     * <p>Uses the normal duration so the reading is legible at a
     * glance and matches the duration used by the repeat and shuffle
     * confirmations. A gesture that moves through several steps
     * replaces the previous toast each time, so the duration applies
     * to the last value in the sequence.</p>
     *
     * @param volumeLevel Current stream volume
     */
    private void showVolumeToast(int volumeLevel) {
        if (mVolumeGestureMaxVolume <= 0) {
            return;
        }
        final int percent = Math.round(
            100f * volumeLevel / mVolumeGestureMaxVolume);
        ToastManager.showToast(this, "Volume: " + percent + "%",
            ToastManager.LENGTH_NORMAL);
    }

    // ============================================================================
    // Permission and Initialization Methods
    // ============================================================================

    /**
     * Requests the runtime permissions the app needs and proceeds
     * with initialization once they have been decided.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest =
                new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission(
                        "android.permission.READ_MEDIA_AUDIO")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        "android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission(
                        "android.permission.POST_NOTIFICATIONS")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        "android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 34) {
                if (checkSelfPermission(
                        "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK");
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission(
                        "android.permission.BLUETOOTH_CONNECT")
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(
                        "android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(
                    permissionsToRequest.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
            }
        } else {
            proceedWithInitialization();
        }
    }

    /**
     * Runs the initialization path once permissions have been
     * decided.
     */
    private void proceedWithInitialization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestBatteryOptimization();
        }

        preloadLastSongDisplay();

        final Intent serviceIntent = new Intent(
            MusicPlayer.this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);

        handleIncomingFile(getIntent());
    }

    /**
     * Requests an exemption from battery optimizations when the app
     * is not yet exempt.
     */
    private void requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager =
                (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null
                    && !powerManager.isIgnoringBatteryOptimizations(
                        getPackageName())) {
                try {
                    Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(
                        Uri.parse("package:" + getPackageName()));
                    startActivityForResult(
                        intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                } catch (Exception exception) {
                    Log.w(TAG,
                        "Failed to request battery optimization",
                        exception);
                }
            }
        }
    }

    // ============================================================================
    // Incoming File Handling
    // ============================================================================

    /**
     * Plays, queues, or imports the audio file referenced by the
     * given {@code ACTION_VIEW} intent.
     *
     * @param intent The intent that triggered the activity, or null
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }

        final String action = intent.getAction();
        if (!Intent.ACTION_VIEW.equals(action)) {
            return;
        }

        final Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        final String filePath = getFilePathFromUri(uri);
        if (filePath == null || !new File(filePath).exists()) {
            Log.w(TAG, "File not found or inaccessible: " + filePath);
            return;
        }

        Log.d(TAG, "Handling incoming file: " + filePath);

        Song existingSong = SongDatabase.getInstance(this).getSong(filePath);
        if (existingSong != null) {
            Log.d(TAG, "Song already in library, playing: " + filePath);
            if (mMusicService != null && mIsServiceBound) {
                mMusicService.playSongByPath(filePath);
                updateUIForPlayingSong(existingSong);
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();
            } else {
                mPendingIncomingPath = filePath;
                Log.d(TAG,
                    "Service not ready, queued existing song: " + filePath);
            }
            return;
        }

        ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs != null) {
            for (Song looseSong : looseSongs) {
                if (filePath.equals(looseSong.getPath())) {
                    Log.d(TAG,
                        "Already a loose track, playing: " + filePath);
                    if (mMusicService != null && mIsServiceBound) {
                        mMusicService.playSongByPath(filePath);
                        updateUIForPlayingSong(looseSong);
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    } else {
                        mPendingIncomingPath = filePath;
                        Log.d(TAG,
                            "Service not ready, queued loose track: "
                                + filePath);
                    }
                    return;
                }
            }
        }

        Log.d(TAG, "New song detected, adding to library: " + filePath);

        Song parsedSong = CharacterMapper.getSongFromFile(filePath);
        final Song newSong;
        if (parsedSong == null) {
            String fileName = new File(filePath).getName();
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > 0) {
                fileName = fileName.substring(0, dotIndex);
            }
            newSong = new Song(
                fileName,
                "Unknown Artist",
                "Unknown Album",
                "Unknown Genre",
                filePath,
                0,
                null
            );
        } else {
            newSong = parsedSong;
        }

        if (mMusicService != null && mIsServiceBound) {
            mMusicService.setPendingSongPath(filePath);
            Log.d(TAG,
                "Pending song path set in MusicService: " + filePath);
        } else {
            mPendingIncomingPath = filePath;
            Log.d(TAG, "Service not ready, queued pending path: " + filePath);
        }

        Intent setPendingIntent = new Intent(ACTION_SET_PENDING_SONG);
        setPendingIntent.putExtra("song_path", filePath);
        sendBroadcast(setPendingIntent);

        final String finalFilePath = filePath;
        PlaylistManager playlistManager = PlaylistManager.getInstance(this);
        playlistManager.addLooseTrackAndUpdate(newSong,
            new PlaylistManager.UpdateCallback() {

            @Override
            public void onProgress(int current, int total) {
            }

            @Override
            public void onComplete(int songCount) {
                Log.d(TAG,
                    "Loose track added successfully: " + finalFilePath);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (mMusicService != null && mIsServiceBound) {
                            mMusicService.playPendingSongIfExists();

                            Song currentSong =
                                mMusicService.getCurrentSong();
                            if (currentSong != null
                                    && finalFilePath.equals(
                                        currentSong.getPath())) {
                                updateUIForPlayingSong(currentSong);
                            }
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        } else {
                            Log.d(TAG,
                                "Service not ready after loose track "
                                    + "addition, will retry");
                            mPendingIncomingPath = finalFilePath;
                            if (!mIsServiceBound) {
                                Intent serviceIntent = new Intent(
                                    MusicPlayer.this, MusicService.class);
                                startService(serviceIntent);
                                bindService(serviceIntent,
                                    mServiceConnection, BIND_AUTO_CREATE);
                            }
                        }
                    }
                }, PLAY_LOOSE_TRACKS_DELAY_MS);
            }

            @Override
            public void onError(@NonNull String error) {
                Log.e(TAG, "Failed to add loose track: " + error);
                if (mMusicService != null) {
                    mMusicService.clearPendingSongPath();
                }
                mPendingIncomingPath = null;
                ToastManager.showToast(MusicPlayer.this,
                    "Failed to open file: " + error,
                    ToastManager.LENGTH_NORMAL);
            }
        });
    }

    // ============================================================================
    // URI Helper Methods
    // ============================================================================

    /**
     * Resolves the filesystem path of the given content URI, copying
     * the content to a temporary file when the media store path is
     * not available.
     *
     * @param uri Content URI to resolve
     * @return The filesystem path, or null when it cannot be
     *         determined
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {
                    android.provider.MediaStore.Audio.Media.DATA
                };
                cursor = getContentResolver().query(uri, projection,
                    null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception exception) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }

    /**
     * Copies the content of the given URI to a temporary cache file.
     *
     * @param uri Content URI to copy
     * @return The path of the temporary file, or null on failure
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream =
                getContentResolver().openInputStream(uri);
            if (inputStream == null) {
                return null;
            }
            final File tempFile = new File(getCacheDir(),
                "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream =
                new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception exception) {
            Log.e(TAG, "Failed to copy URI to temp file", exception);
            return null;
        }
    }

    /**
     * Removes from the loose-tracks table any song whose path lies
     * inside the given folder.
     *
     * @param folderUri Folder URI to clean
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageAccessHelper == null) {
            return;
        }

        final String folderPath =
            mStorageAccessHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return;
        }
        final ArrayList<Song> looseSongs =
            SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) {
            return;
        }
        final String normalizedPath = folderPath.endsWith("/")
            ? folderPath : folderPath + "/";
        for (Song looseSong : looseSongs) {
            if (looseSong.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this)
                    .removeLooseSong(looseSong.getPath());
            }
        }
    }

    // ============================================================================
    // Playlist Loading Methods
    // ============================================================================

    /**
     * Loads the full playlist on a background thread and hands it
     * to the bound service when the load completes.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) {
            return;
        }

        OverlayManager.show(OverlayManager.REASON_COLD_START);

        mMusicLibrary.loadAllSongsWithProgress(
            new MusicLibrary.LoadProgressListener() {

            @Override
            public void onLoadProgress(int currentCount) {
                if (OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    ToastManager.updatePersistentOverlay(
                        MESSAGE_LIBRARY_LOAD, OPERATION_LIBRARY_LOAD);
                }
            }

            @Override
            public void onLoadComplete(@NonNull ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                }
                refreshCarouselFromService();
                updatePlayPauseButton();
                setupSeekBar();
                updateTimeDisplay();

                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }

            @Override
            public void onLoadError(@NonNull String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD);
                OverlayManager.hide(OverlayManager.REASON_COLD_START);
            }
        });
    }

    /**
     * Ensures the cold-start library-load heartbeat is scheduled. A
     * second call while a heartbeat is already scheduled does
     * nothing.
     */
    private void ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) {
            return;
        }

        mLibraryHeartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                if (!OPERATION_LIBRARY_LOAD.equals(
                        ToastManager.getCurrentOperationId())) {
                    mLibraryHeartbeatRunnable = null;
                    return;
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD);
                mMainHandler.postDelayed(
                    this, LIBRARY_HEARTBEAT_INTERVAL_MS);
            }
        };
        mMainHandler.postDelayed(
            mLibraryHeartbeatRunnable, LIBRARY_HEARTBEAT_INTERVAL_MS);
    }

    // ============================================================================
    // UI Update Methods
    // ============================================================================

    /**
     * Runs the given UI update on the main thread, coalescing
     * requests that arrive while another update is in flight.
     *
     * @param update The update to run
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }

        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pendingUpdate = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pendingUpdate);
                    }
                }
            }
        });
    }

    /**
     * Writes the given song's title and artist to the UI.
     *
     * @param song Song to display, or null
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Writes the given playing song's title and artist to the UI
     * and refreshes the album art.
     *
     * @param song Song that started playing, or null
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) {
            return;
        }
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()
                        || mThemeHelper == null) {
                    return;
                }

                String displayTitle = finalSong.getTitle();
                if (displayTitle != null
                        && displayTitle.length() > MAX_TITLE_LENGTH) {
                    displayTitle = displayTitle.substring(
                        0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayTitle != null
                        ? displayTitle : "Unknown Title");
                    mSongTitle.setTextColor(
                        mThemeHelper.getThemeColorInt());
                }

                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null
                            && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(
                            0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null
                        ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }

                refreshCarouselFromService();
                updatePlayPauseButton();
                applyAlbumArtClipping();
            }
        });
    }

    /**
     * Enables every transport control when the library contains
     * songs.
     */
    private void enableAllControls() {
        final boolean hasSongs =
            (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(
                        mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }

    /**
     * Applies the current library state to the previous, next,
     * repeat, and shuffle controls.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs =
            (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);

        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }

    /**
     * Shows the empty state: placeholder title, placeholder artist,
     * placeholder album art, and disabled transport controls.
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAlbumArtCarousel != null) {
            mAlbumArtCarousel.setWindow(PlaybackWindow.EMPTY);
        }

        if (mAlbumArtContainer != null) {
            if (mPlaceholderBitmap != null
                    && !mPlaceholderBitmap.isRecycled()) {
                if (mAlbumArtCarousel != null) {
                    mAlbumArtCarousel.setPlaceholder(mPlaceholderBitmap);
                }
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
        }

        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }

        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }

        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }

        mCachedLastSong = null;

        Intent emptyStateIntent = new Intent("UPDATE_PLAYER");
        emptyStateIntent.putExtra("current_index", -1);
        emptyStateIntent.putExtra("is_playing", false);
        sendBroadcast(emptyStateIntent);
    }

    // ============================================================================
    // Playback Control Methods
    // ============================================================================

    /**
     * Runs the given service action on the main thread while holding
     * the service lock, when the service is bound.
     *
     * @param action The service action to run
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }

    /**
     * Plays the song at the given index and updates the UI.
     *
     * @param index Index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null
            && mMusicLibrary.getAllSongs().size() > 0
            && index >= 0
            && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }

    /**
     * Toggles playback through the service when the library contains
     * songs.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            return;
        }

        if (mMusicLibrary != null && mMusicLibrary.getSongCount() == 0) {
            return;
        }

        safeCallService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.togglePlayPause();
                }
            }
        });
    }

    /**
     * Animates the carousel toward the next neighbour and asks the
     * service to advance.
     *
     * <p>The carousel's animation is chosen to match the transition
     * the service will make. Under repeat-one the service restarts
     * the current song, so the pre-animation is the below-threshold
     * nudge — the same animation the repeat-one auto-loop produces.
     * Under every other mode the service advances, so the
     * pre-animation is the full commit slide.</p>
     *
     * <p>The carousel's animation and the service's transition run in
     * parallel. The service request is dispatched immediately, so the
     * audio changes as soon as the button is pressed. When the
     * resulting window arrives, the carousel settles on the incoming
     * art — or, under repeat-one, glides back from the nudge because
     * the current song did not change.</p>
     *
     * <p>When the carousel cannot animate — a commit or nudge is
     * already in flight, the viewport is not laid out, or the window
     * advertises no forward neighbour — the pre-animation is a no-op
     * and the service request still proceeds. The window that results
     * is adopted without animation.</p>
     */
    private void playNextSong() {
        if (mAlbumArtCarousel != null) {
            final boolean repeatOne = (mMusicService != null
                && mMusicService.getRepeatMode() == 2);
            if (repeatOne) {
                mAlbumArtCarousel.nudgeToNext();
            } else {
                mAlbumArtCarousel.animateToNext();
            }
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playNextSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    /**
     * Animates the carousel toward the previous neighbour and asks
     * the service to go back.
     *
     * <p>Symmetric to {@link #playNextSong()}: the pre-animation is
     * the below-threshold nudge under repeat-one and the full commit
     * slide under every other mode.</p>
     */
    private void playPreviousSong() {
        if (mAlbumArtCarousel != null) {
            final boolean repeatOne = (mMusicService != null
                && mMusicService.getRepeatMode() == 2);
            if (repeatOne) {
                mAlbumArtCarousel.nudgeToPrevious();
            } else {
                mAlbumArtCarousel.animateToPrevious();
            }
        }
        safeCallService(new Runnable() {
            @Override
            public void run() {
                mMusicService.playPreviousSong();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing() && !isDestroyed()) {
                            updatePlayPauseButton();
                        }
                    }
                }, NEXT_PREV_UPDATE_DELAY_MS);
            }
        });
    }

    // ============================================================================
    // Button State Update Methods
    // ============================================================================

    /**
     * Updates the repeat button's label and active state from the
     * service's current repeat mode.
     */
    private void updateRepeatButton() {
        if (mMusicService != null && mRepeatButton != null
                && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled =
                hasSongs && mRepeatButton.isEnabled();

            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);

                if (repeatMode == 2) {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                }

                mThemeHelper.updateControlButton(
                    mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(
                    mRepeatButton, false, false);
            }
        }
    }

    /**
     * Updates the shuffle button's active state from the service's
     * current shuffle flag.
     */
    private void updateShuffleButton() {
        if (mMusicService != null && mShuffleButton != null
                && mThemeHelper != null) {
            final boolean hasSongs =
                (mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled =
                hasSongs && mShuffleButton.isEnabled();

            mShuffleButton.setText(FontAwesome.SHUFFLE);

            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(
                    mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(
                    mShuffleButton, false, false);
            }
        }
    }

    /**
     * Updates the play/pause button's label and enabled state from
     * the service's current playback state.
     *
     * <p>{@link MusicService#isPlaying()} reports the destination
     * of the current transition, so the button never flashes a
     * pause icon during a next/previous switch. The play icon
     * appears only when the state machine is genuinely paused and
     * will not auto-start.</p>
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing()
                        || isDestroyed() || mThemeHelper == null) {
                    return;
                }

                final boolean hasSongs =
                    (mMusicLibrary != null
                        && mMusicLibrary.getSongCount() > 0);

                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(
                        mPlayButton, false, false);
                    return;
                }

                mPlayButton.setEnabled(true);

                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                    return;
                }

                try {
                    final Song currentSong = mMusicService.getCurrentSong();
                    if (currentSong == null) {
                        mPlayButton.setText(FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(
                            mPlayButton, true, true);
                        return;
                    }

                    final boolean isPlaying = mMusicService.isPlaying();
                    mPlayButton.setText(isPlaying
                        ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                } catch (Exception exception) {
                    Log.e(TAG,
                        "Error updating play/pause button", exception);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(
                        mPlayButton, true, true);
                }
            }
        });
    }

    // ============================================================================
    // Seek Bar Methods
    // ============================================================================

    /**
     * Attaches the seek-bar change listener.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) {
            return;
        }

        mSeekBar.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser && mMusicService != null
                        && seekBar.isEnabled() && mSeekTime != null) {
                    mMusicService.seekTo(progress);
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (seekBar.isEnabled()) {
                    mIsUserSeeking = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekBar.getProgress());
                }
                mIsUserSeeking = false;
            }
        });
    }

    /**
     * Starts the periodic time-display update runnable.
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }

        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(
                            this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }

                try {
                    int currentPosition = service.getCurrentPosition();
                    int duration = service.getDuration();

                    if (duration <= 0) {
                        final Song currentSong = service.getCurrentSong();
                        if (currentSong != null
                                && currentSong.getDuration() > 0) {
                            duration = (int) currentSong.getDuration();
                        }
                    }

                    if (duration > 0) {
                        if (mSeekTime != null) {
                            mSeekTime.setText(
                                formatTime(currentPosition));
                        }
                        if (mTotalTime != null) {
                            mTotalTime.setText(formatTime(duration));
                        }

                        if (mSeekBar != null && mSeekBar.isEnabled()) {
                            if (mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPosition);
                        }
                    }
                } catch (Exception exception) {
                    Log.e(TAG, "Error updating time display", exception);
                }

                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(
                        this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    /**
     * Returns the given duration formatted as {@code mm:ss} or
     * {@code hh:mm:ss}.
     *
     * @param milliseconds Duration in milliseconds
     * @return The formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d",
                hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // ============================================================================
    // Album Art Methods
    // ============================================================================

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested size.
     *
     * @param options Options whose bounds have been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options,
                                      int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Decodes the given image bytes with downsampling to the
     * requested size.
     *
     * @param data Image bytes to decode
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth,
                                       int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);

        options.inSampleSize =
            calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(
            data, 0, data.length, options);
    }

    /**
     * Returns the path of the current song, or null when no song is
     * playing.
     *
     * @return The current song's path, or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null
                && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }

    /**
     * Loads and displays the current themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }

    // ============================================================================
    // Placeholder Methods
    // ============================================================================

    /**
     * Rebuilds the themed placeholder bitmap from the source image
     * and applies the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) {
            return;
        }

        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }

        final int themeColor = mThemeHelper.getThemeColorInt();

        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tintedBitmap = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null
                                && !mOriginalPlaceholderBitmap
                                    .isRecycled()) {
                            tintedBitmap = mOriginalPlaceholderBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                        }
                    }

                    if (tintedBitmap == null) {
                        final BitmapFactory.Options options =
                            new BitmapFactory.Options();
                        options.inPreferredConfig =
                            Bitmap.Config.ARGB_8888;
                        Bitmap loadedBitmap = BitmapFactory.decodeResource(
                            getResources(),
                            R.drawable.album_art_placeholder, options);
                        if (loadedBitmap != null) {
                            tintedBitmap = loadedBitmap.copy(
                                Bitmap.Config.ARGB_8888, true);
                            loadedBitmap.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null
                                        && !mOriginalPlaceholderBitmap
                                            .isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap =
                                    tintedBitmap.copy(
                                        Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }

                    if (tintedBitmap == null) {
                        return;
                    }

                    final Canvas canvas = new Canvas(tintedBitmap);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(
                        themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tintedBitmap, 0, 0, paint);

                    final Bitmap finalTintedBitmap = tintedBitmap;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null
                                        && !mPlaceholderBitmap
                                            .isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTintedBitmap;
                            }
                            if (mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.setPlaceholder(
                                    mPlaceholderBitmap);
                            }
                            applyAlbumArtClipping();
                        }
                    });
                } catch (Exception exception) {
                    Log.e(TAG,
                        "updatePlaceholderBitmap error", exception);
                }
            }
        });

        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }

    /**
     * Cancels any in-flight placeholder render task and recycles
     * the placeholder bitmaps.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }

            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;

            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }

    /**
     * Recycles the given bitmap, ignoring any exception.
     *
     * @param bitmap Bitmap to recycle, or null
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception exception) {
                Log.e(TAG, "Error recycling bitmap", exception);
            }
        }
    }

    // ============================================================================
    // Album Art Clipping Methods
    // ============================================================================

    /**
     * Applies rounded-corner clipping and the container background
     * to the album art container.
     *
     * <p>The outline provider reads the view's current width and
     * height at outline time, and the framework invalidates the
     * outline when the view's size changes. A resize from the
     * split-screen layout is therefore reflected in the clipped
     * corners without any coordination here.</p>
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(
                new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view,
                                        android.graphics.Outline outline) {
                    final int radius =
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0,
                        view.getWidth(), view.getHeight(), radius);
                }
            });
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        } else {
            mAlbumArtContainer.setBackgroundResource(
                R.drawable.album_art_container);
        }
    }

    // ============================================================================
    // Navigation Methods
    // ============================================================================

    /**
     * Opens the folder manager activity with the slide-left
     * transition.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /**
     * Opens the playlist activity with the slide-right transition.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /**
     * Opens the metadata editor for the current song, or in the
     * awaiting state when no song is playing.
     */
    private void openMetadataEditor() {
        final Intent editorIntent =
            new Intent(this, MetadataEditor.class);

        final Song currentSong = getCurrentSong();

        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra(
                    "song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }

        startActivity(editorIntent);
        overridePendingTransition(
            R.anim.slide_in_up, R.anim.slide_out_up);
    }

    /**
     * Returns the current song from the service, or null when the
     * service is not bound.
     *
     * @return The current song, or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }

    // ============================================================================
    // Cold-Start Preload
    // ============================================================================

    /**
     * Paints the previous song's title, artist, and art before the
     * playlist loads.
     */
    private void preloadLastSongDisplay() {
        final SharedPreferences preferences = getSharedPreferences(
            PREFS_NAME, MODE_PRIVATE);
        final String lastPath = preferences.getString(
            KEY_LAST_SONG_PATH, null);

        if (lastPath == null || !new File(lastPath).exists()) {
            applyNoSongState();
            return;
        }

        if (mSongTitle != null) {
            mSongTitle.setText("Loading...");
        }
        if (mSongArtist != null) {
            mSongArtist.setText("Loading...");
        }

        if (mCurrentMetadataFuture != null) {
            mCurrentMetadataFuture.cancel(true);
        }

        mCurrentMetadataFuture = mMetadataLoader.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                final Song loadedSong = loadSongMetadata(lastPath);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        if (loadedSong != null && mThemeHelper != null) {
                            mCachedLastSong = loadedSong;
                            if (mSongTitle != null) {
                                mSongTitle.setText(
                                    loadedSong.getTitle());
                                mSongTitle.setTextColor(
                                    mThemeHelper.getThemeColorInt());
                            }
                            if (mSongArtist != null) {
                                mSongArtist.setText(
                                    loadedSong.getArtist());
                                mSongArtist.setTextColor(
                                    Color.parseColor("#C0C0C0"));
                            }

                            final Bitmap cachedArt =
                                mAlbumArtCache != null
                                    ? mAlbumArtCache.get(lastPath)
                                    : null;
                            if (cachedArt != null
                                    && mAlbumArtCarousel != null) {
                                mAlbumArtCarousel.onArtReady(
                                    lastPath, cachedArt);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                        } else {
                            applyNoSongState();
                        }
                    }
                });
            }
        });
    }

    /**
     * Reads the metadata for the given path from the database when
     * a usable cached entry exists, and from the file otherwise.
     *
     * @param lastPath Absolute path of the song
     * @return The song, or null when the file cannot be read
     */
    @Nullable
    private Song loadSongMetadata(@NonNull String lastPath) {
        Song cachedSong =
            SongDatabase.getInstance(this).getSong(lastPath);

        if (cachedSong != null && cachedSong.getTitle() != null
                && !cachedSong.getTitle().isEmpty()
                && !"Unknown Title".equals(cachedSong.getTitle())) {
            Log.d(TAG, "Using cached song with genre: "
                + cachedSong.getGenre());
            return cachedSong;
        }

        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(lastPath);
            String title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ALBUM);
            final byte[] albumArt = retriever.getEmbeddedPicture();

            if (title == null || title.isEmpty()) {
                final File file = new File(lastPath);
                String name = file.getName();
                final int dotIndex = name.lastIndexOf('.');
                if (dotIndex > 0) {
                    name = name.substring(0, dotIndex);
                }
                title = name;
            }
            if (artist == null) {
                artist = "Unknown Artist";
            }
            if (album == null) {
                album = "Unknown Album";
            }

            String genre = "Unknown Genre";
            Song databaseSong =
                SongDatabase.getInstance(this).getSong(lastPath);
            if (databaseSong != null
                    && databaseSong.getGenre() != null
                    && !"Unknown Genre".equals(databaseSong.getGenre())) {
                genre = databaseSong.getGenre();
            } else {
                String fileGenre = CharacterMapper.getGenre(lastPath);
                if (fileGenre != null
                        && !"Unknown Genre".equals(fileGenre)) {
                    genre = fileGenre;
                }
            }

            Song resultSong = new Song(
                title, artist, album, genre, lastPath, 0, null);
            if (albumArt != null && mAlbumArtCache != null) {
                final Bitmap albumArtBitmap = decodeSampledBitmap(
                    albumArt, MAX_ALBUM_ART_SIZE_PX,
                    MAX_ALBUM_ART_SIZE_PX);
                if (albumArtBitmap != null) {
                    mAlbumArtCache.put(lastPath, albumArtBitmap);
                }
            }
            return resultSong;
        } catch (Exception exception) {
            Log.e(TAG, "Failed to load last song metadata for: "
                + lastPath, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    // ============================================================================
    // Theme Methods
    // ============================================================================

    /**
     * Registers the receiver for app-restart broadcasts.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        ContextCompat.registerReceiver(
            this, mRestartReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter =
            new IntentFilter("THEME_COLOR_CHANGED");
        ContextCompat.registerReceiver(
            this, mThemeReceiver, filter,
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Applies the current theme color to every control in the
     * activity and rebuilds the placeholder bitmap.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed()
                || mThemeHelper == null || mThemeManager == null) {
            return;
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        OverlayManager.setColor(mThemeHelper.getThemeColorInt());

        if (mManagerButton != null) {
            mThemeHelper.updateButton(
                mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(
                mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(
                mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(
                mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(
                mMetadataButton, mMetadataButton.isEnabled());
        }

        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null
                    && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(
                mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(
                mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(
                mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn =
                mMusicService != null
                    && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(
                mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn =
                mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(
                mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }

        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }

        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }

        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }

    /**
     * Restarts the activity with the no-animation flag.
     */
    private void performUpdate() {
        final Intent restartIntent =
            new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                final long generation =
                    intent.getLongExtra("generation", -1L);
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    if (generation > mLastSeenGeneration) {
                        mLastSeenGeneration = generation;
                    }
                }

                final String stateName =
                    intent.getStringExtra("state");
                final String displayTitle =
                    intent.getStringExtra("display_title");
                final String displayArtist =
                    intent.getStringExtra("display_artist");
                final boolean playing =
                    intent.getBooleanExtra("is_playing", false);
                final int positionMs =
                    intent.getIntExtra("position_ms", 0);
                final int durationMs =
                    intent.getIntExtra("duration_ms", 0);

                final PlaybackWindow windowSnapshot = new PlaybackWindow(
                    intent.getStringExtra("window_previous_path"),
                    intent.getStringExtra("window_current_path"),
                    intent.getStringExtra("window_next_path"),
                    generation);

                safeUpdateUI(new Runnable() {
                    @Override
                    public void run() {
                        updatePlayPauseButton();

                        if (mSeekBar != null && mSeekBar.isEnabled()
                                && durationMs > 0) {
                            if (mSeekBar.getMax() != durationMs) {
                                mSeekBar.setMax(durationMs);
                            }
                            mSeekBar.setProgress(positionMs);
                        }

                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.setWindow(windowSnapshot);
                        }

                        if (mSongTitle != null && displayTitle != null) {
                            mSongTitle.setText(displayTitle);
                            if (mThemeHelper != null) {
                                mSongTitle.setTextColor(
                                    mThemeHelper.getThemeColorInt());
                            }
                        }

                        if (mSongArtist != null && displayArtist != null) {
                            mSongArtist.setText(displayArtist);
                            mSongArtist.setTextColor(
                                Color.parseColor("#C0C0C0"));
                        }

                        setupSeekBar();
                    }
                });
            }
        };

        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath =
                        intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };

        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex =
                            mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0
                                && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };

        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null
                            && mMusicService.isPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };

        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "GET_PLAYING_STATE".equals(
                            intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences preferences =
                            getSharedPreferences(
                                PREFS_NAME, MODE_PRIVATE);
                        preferences.edit().putBoolean(
                            KEY_LAST_PLAYING,
                            mMusicService.isPlaying()).apply();
                    }
                }
            }
        };

        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(
                            intent.getAction())) {
                    return;
                }

                final boolean preserveSettings = intent.getBooleanExtra(
                    PlaylistManager.EXTRA_PRESERVE_SETTINGS, true);

                mPendingIncomingPath = null;
                mIsUserSeeking = false;
                mLastSeenGeneration = -1L;

                if (mCurrentMetadataFuture != null) {
                    mCurrentMetadataFuture.cancel(true);
                    mCurrentMetadataFuture = null;
                }

                mCachedLastSong = null;

                if (mMusicLibrary != null) {
                    mMusicLibrary.invalidate();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyNoSongState();

                        if (!preserveSettings && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }

                        if (mShuffleButton != null
                                && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null
                                && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mRepeatButton, false, false);
                        }
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPlayButton, false, false);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mPrevButton, false, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mThemeHelper.updateControlButton(
                                mNextButton, false, false);
                        }
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(mSeekBar, false);
                        }

                        updatePlayPauseButton();
                    }
                });
            }
        };

        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "SAVE_PLAYER_STATE_NOW".equals(
                            intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };

        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "BLUETOOTH_CONNECTED".equals(
                            intent.getAction())) {
                    final boolean connected =
                        intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };

        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_STARTED".equals(intent.getAction())) {
                    return;
                }
                final String text = intent.getStringExtra("custom_text");
                final String operationId =
                    intent.getStringExtra("operation_id");
                if (text == null) {
                    return;
                }

                if (ToastManager.hasPersistentToast()) {
                    final String currentOwner =
                        ToastManager.getCurrentOperationId();
                    if (currentOwner != null) {
                        ToastManager.updatePersistentOverlay(
                            text, currentOwner);
                    }
                    return;
                }

                if (operationId == null || operationId.isEmpty()) {
                    Log.w(TAG,
                        "SYNC_STARTED without operation_id; ignoring");
                    return;
                }
                ToastManager.showPersistentOverlay(
                    MusicPlayer.this, text, operationId);
            }
        };

        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"SYNC_COMPLETE".equals(intent.getAction())) {
                    return;
                }
                Log.d(TAG, "SYNC_COMPLETE received");
            }
        };

        mUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "UPDATE_PLAYLIST".equals(
                            intent.getAction())) {
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs =
                            mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    refreshCarouselFromService();
                                }
                            });
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            mMusicLibrary.refreshCache();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                }
                            });
                        }
                    }
                }
            }
        };

        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYLIST_FROM_FOLDERS".equals(
                            intent.getAction())) {
                    return;
                }
                if (mMusicLibrary == null) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                }

                final MusicLibrary library = mMusicLibrary;
                final MusicService service = mMusicService;

                mMetadataLoader.execute(new Runnable() {
                    @Override
                    public void run() {
                        library.refreshCache();
                        final ArrayList<Song> allSongs =
                            library.getAllSongs();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()
                                        && service != null) {
                                    if (!allSongs.isEmpty()) {
                                        service.setPlaylist(
                                            allSongs, true);
                                        enableAllControls();
                                        updatePlayPauseButton();
                                        setupSeekBar();
                                        updateTimeDisplay();
                                        refreshCarouselFromService();
                                    } else {
                                        service.setPlaylist(null, false);
                                        applyNoSongState();
                                    }
                                    sendBroadcast(new Intent(
                                        "DISPLAY_PLAYLIST"));
                                }

                                sendBroadcast(new Intent(
                                    PlaylistManager
                                        .ACTION_TRIGGER_GENRE_LOADING));
                            }
                        });
                    }
                });
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"METADATA_UPDATED".equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    intent.getStringExtra("song_path");
                if (songPath == null || mMusicService == null) {
                    return;
                }

                final String title = intent.getStringExtra("title");
                final String artist = intent.getStringExtra("artist");
                final String album = intent.getStringExtra("album");
                final String genre = intent.getStringExtra("genre");
                final boolean hasAlbumArt =
                    intent.getBooleanExtra("has_album_art", false);
                final boolean albumArtRemoved =
                    intent.getBooleanExtra("album_art_removed", false);
                final byte[] albumArtBytes =
                    intent.getByteArrayExtra("album_art_bytes");

                mMusicService.refreshMetadataForSong(songPath, title,
                    artist, album, genre, albumArtBytes,
                    albumArtRemoved);

                if (mMusicLibrary != null) {
                    mMusicLibrary.refreshCache();
                }

                final Song currentSong = (mMusicService != null)
                    ? mMusicService.getCurrentSong() : null;
                if (currentSong != null
                        && songPath.equals(currentSong.getPath())) {
                    if (albumArtRemoved && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.invalidatePath(songPath);
                        }
                        loadAndDisplayPlaceholder();
                    } else if (hasAlbumArt && mAlbumArtCache != null) {
                        mAlbumArtCache.remove(songPath);
                        if (mAlbumArtCarousel != null) {
                            mAlbumArtCarousel.invalidatePath(songPath);
                        }
                        refreshCarouselFromService();
                    }

                    if (mMusicService.isPlaying()) {
                        updateUIForPlayingSong(currentSong);
                    } else {
                        updateUIForSong(currentSong);
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                }
            }
        };

        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this,
                        "Playback recovered",
                        ToastManager.LENGTH_NORMAL);
                }
            }
        };

        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode =
                        intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null
                            && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong =
                                    (mMusicService != null)
                                        ? mMusicService.getCurrentSong()
                                        : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                                refreshCarouselFromService();
                            }
                        });
                        Log.d(TAG,
                            "Sort mode update received, refreshed UI: "
                                + newSortMode);
                    }
                }
            }
        };

        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(
            mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(
            mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(
            mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(
            mLibraryResetReceiver,
            PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(
            mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(
            mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(
            mUpdatePlaylistReceiver, "UPDATE_PLAYLIST");
        registerReceiverSafely(
            mUpdatePlaylistFromFoldersReceiver,
            "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(
            mMetadataUpdatedReceiver, "METADATA_UPDATED");
        registerReceiverSafely(
            mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(
            mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
    }

    /**
     * Registers the given receiver for the given action with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to register, or null
     * @param action Broadcast action to subscribe to
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG,
                "Failed to register receiver for " + action, exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any failure raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                // The receiver was already unregistered.
            }
        }
    }

    // ============================================================================
    // Listener Setup Methods
    // ============================================================================

    /**
     * Attaches every button click listener used by the activity,
     * each guarded by a debounce.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlayPauseClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }

        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastNextClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }

        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPrevClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }

        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastRepeatClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null
                                && mRepeatButton.isEnabled()) {
                            final int newMode =
                                (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String message = newMode == 0
                                ? "Repeat: OFF"
                                : (newMode == 1
                                    ? "Repeat: ALL"
                                    : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this,
                                message, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastShuffleClickTime
                            >= REPEAT_SHUFFLE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null
                                && mShuffleButton.isEnabled()) {
                            final boolean newShuffle =
                                !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this,
                                newShuffle
                                    ? "Shuffle: ON"
                                    : "Shuffle: OFF",
                                ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }

        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastManagerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }

        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastLlamaClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent =
                            findViewById(android.R.id.content);
                        mainContent.startAnimation(
                            AnimationUtils.loadAnimation(
                                MusicPlayer.this,
                                R.anim.slide_out_down));
                        final CreditsDialog dialog =
                            new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(
                            new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(
                                    DialogInterface dismissedDialog) {
                                final View contentView =
                                    findViewById(android.R.id.content);
                                contentView.startAnimation(
                                    AnimationUtils.loadAnimation(
                                        MusicPlayer.this,
                                        R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }

        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastPlaylistClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }

        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastEqualizerClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this,
                            EqualizerActivity.class));
                    }
                }
            });
        }

        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final long currentTime =
                        SystemClock.elapsedRealtime();
                    if (currentTime - mLastMetadataClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Returns whether the activity has been destroyed, using the
     * API-appropriate check.
     *
     * @return True when the activity has been destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp
            * getResources().getDisplayMetrics().density);
    }
}