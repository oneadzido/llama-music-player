package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>MusicPlayer follows the Model-View-Controller pattern where:</p>
 * <ul>
 *   <li><b>Activity</b> serves as the View, displaying UI and capturing user input</li>
 *   <li><b>MusicService</b> acts as the Controller, managing playback in background</li>
 *   <li><b>PlaybackController</b> provides the single source of truth for state</li>
 *   <li><b>MusicLibrary</b> manages the data model (songs, playlists)</li>
 *   <li><b>DisplayManager</b> handles all UI display logic (album art, placeholders, overlays)</li>
 * </ul>
 * 
 * <h3>Seek Bar Rubber-Banding Prevention</h3>
 * <p>The seek bar position is protected from rubber-banding using multiple safeguards:</p>
 * <ul>
 *   <li><b>Stale Position Detection:</b> Position updates that jump backward more than 500ms are ignored</li>
 *   <li><b>User Seek Flag:</b> Prevents updates while user is dragging the seek bar</li>
 *   <li><b>Pause Transition Flag:</b> Prevents updates during pause/resume transitions</li>
 *   <li><b>Last Reported Position Tracking:</b> Validates position monotonicity</li>
 *   <li><b>Stabilization Delay:</b> After seek, ignores updates for 300ms to let AudioTrack stabilize</li>
 * </ul>
 * 
 * <h3>Control Button Management</h3>
 * <p><b>IMPORTANT:</b> All control buttons start DISABLED and only become
 * enabled when the player is prepared (song loaded and ready to play). This
 * prevents crashes and no-ops when users click buttons before the player is ready.</p>
 * 
 * @see MusicService
 * @see PlaybackController
 * @see DisplayManager
 * @see MusicLibrary
 * @see ThemeManager
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for permission requests. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for tracking first run of the application. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing the last played song's file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Action for restarting the application after updates. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action indicating a song has been prepared for playback. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Action indicating the player is ready for playback. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks to prevent rapid firing (milliseconds). */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before showing loading overlay (milliseconds). */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Delay for next/previous button UI updates (milliseconds). */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus operations and scrolling (milliseconds). */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Delay before resetting seek state after user stops seeking (milliseconds). */
    private static final int SEEK_RESET_DELAY_MS = 150;
    
    /** Buffer size for file copying operations (8KB). */
    private static final int BUFFER_SIZE = 8192;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Minimum time between position UI updates (50ms = 20fps, owner's throttle). */
    private static final long POSITION_UPDATE_THROTTLE_MS = 50;
    
    /** Maximum album art dimension for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Number of retry attempts for album art loading. */
    private static final int ALBUM_ART_RETRY_COUNT = 3;
    
    /** Delay between album art retry attempts (milliseconds). */
    private static final int ALBUM_ART_RETRY_DELAY_MS = 200;
    
    /** Threshold for stale position detection - positions jumping backward more than this are ignored. */
    private static final long POSITION_STALE_THRESHOLD_MS = 500;
    
    /** Delay to let AudioTrack stabilize after seek before accepting position updates. */
    private static final int SEEK_STABILIZATION_DELAY_MS = 300;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Button for play/pause toggling. */
    @Nullable private Button mPlayButton;
    
    /** Button for previous song navigation. */
    @Nullable private Button mPrevButton;
    
    /** Button for next song navigation. */
    @Nullable private Button mNextButton;
    
    /** Button for repeat mode cycling (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Button for shuffle mode toggling. */
    @Nullable private Button mShuffleButton;
    
    /** Button for opening folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button for showing credits/about dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button for opening playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button for opening equalizer settings. */
    @Nullable private Button mEqualizerButton;
    
    /** Button for opening metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Container for album art with rounded corners. */
    @Nullable private FrameLayout mAlbumArtContainer;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Library manager for accessing song data and playlists. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Background service for music playback. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for storage access framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Display manager for album art, placeholders, and overlays. */
    @Nullable private DisplayManager mDisplayManager;
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable private PlaybackController mPlaybackController;
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    @Nullable private BroadcastReceiver mPlayerReadyReceiver;
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // PlaybackController Listener
    // ========================================================================
    
    /** Listener for PlaybackController callbacks. */
    @Nullable private PlaybackController.PlaybackControllerListener mPlaybackControllerListener;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if the service is bound. */
    private volatile boolean mIsServiceBound = false;
    
    /** Flag indicating if user is actively seeking (dragging seek bar). */
    private volatile boolean mIsUserSeeking = false;
    
    /** Flag indicating if we're in a pause transition (prevents rubber-banding). */
    private volatile boolean mIsPausing = false;
    
    /** Last reported position for stale detection. */
    private long mLastReportedPosition = 0;
    
    /** Timestamp when the last seek occurred (for stabilization). */
    private long mLastSeekTimestamp = 0;
    
    /** Last time we updated the position UI (for throttling). */
    private long mLastPositionUpdateTime = 0;
    
    /** Target position for pending seek operations. */
    private int mSeekTargetPosition = -1;
    
    /** Handler for seek operation timeouts. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Atomic flag for UI update synchronization. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable for debounced updates. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for service synchronization. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Flag indicating if activity is restarting after an update. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transition synchronization. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    /** Atomic flag to prevent multiple concurrent play button updates. */
    @NonNull private final AtomicBoolean mPlayButtonUpdateQueued = new AtomicBoolean(false);
    
    /** Flag indicating if any player has been prepared. */
    private final AtomicBoolean mIsPlayerPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if playlist has songs. */
    private volatile boolean mHasSongs = false;
    
    /** Runnable to enable controls when prepared. */
    private Runnable mEnableControlsRunnable = null;
    
    /** Handler for delayed enable operations. */
    private final Handler mEnableHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick access. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    /** Single-thread executor for metadata extraction operations. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    /** Path of the currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Connection to the MusicService for playback control.
     * 
     * <p>This ServiceConnection handles binding to MusicService and initializing
     * the UI once the service is connected. It includes automatic reconnection
     * logic if the service disconnects unexpectedly.</p>
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            // Get current song from service
            Song currentSong = mMusicService.getCurrentSong();
            
            if (currentSong != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                // We have a current song - update UI
                updateUIForSong(currentSong);
                
                // Update album art with retry to ensure it appears
                if (mDisplayManager != null && mAlbumArtView != null) {
                    String songPath = currentSong.getPath();
                    loadAlbumArtWithRetry(mAlbumArtView, songPath, ALBUM_ART_RETRY_COUNT);
                }
                
                // Enable controls if player is prepared
                if (mMusicService.isAnyPlayerPrepared()) {
                    enableControlsWhenReady();
                }
                
                // Update play button state
                safeUpdatePlayButton();
            } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                // No current song but playlist has songs - prepare first song without auto-play
                applyNoSongState();
            } else {
                applyNoSongState();
            }
            
            setupSeekBar();
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                    Log.d(TAG, "Attempting to reconnect to MusicService");
                    Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>This method performs the following initialization steps:</p>
     * <ol>
     *   <li>Sets full-screen immersive mode</li>
     *   <li>Inflates the layout from activity_music_player.xml</li>
     *   <li>Initializes ToastManager for user feedback</li>
     *   <li>Checks for close_app intent flag</li>
     *   <li>Initializes FontAwesome icon library</li>
     *   <li>Creates DisplayManager for album art and UI display</li>
     *   <li>Initializes managers (Theme, Storage, MusicLibrary)</li>
     *   <li>Initializes UI views and sets up listeners</li>
     *   <li>Registers broadcast receivers for service communication</li>
     *   <li>Sets up theme change receiver</li>
     *   <li>Registers restart receiver for app updates</li>
     *   <li>Sets up media button receiver for headset controls</li>
     *   <li>Checks permissions and initializes further</li>
     *   <li>Starts StorageObserver for external storage monitoring</li>
     *   <li>Applies theme colors to UI elements</li>
     *   <li>Registers with NavigationController for button state</li>
     *   <li>Sets up PlaybackController listener</li>
     * </ol>
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        // Initialize DisplayManager for album art and UI display
        mDisplayManager = new DisplayManager(this, mThemeManager, mThemeHelper);
        mDisplayManager.setAlbumArtUpdateListener((art, placeholder, artPath) -> {
            if (mMusicService != null) {
                mMusicService.setNotificationAlbumArt(art, placeholder, artPath);
            }
        });
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        NavigationController.getInstance().registerListener(this);
        
        mPlaybackController = PlaybackController.getInstance();
        setupPlaybackControllerListener();
    }
    
    /**
     * Called when the activity resumes and comes to the foreground.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                
                // CRITICAL: Restore album art on resume with retry
                if (mDisplayManager != null && mAlbumArtView != null) {
                    String songPath = currentSong.getPath();
                    loadAlbumArtWithRetry(mAlbumArtView, songPath, ALBUM_ART_RETRY_COUNT);
                }
            }
        }
        
        // Restore position from PlaybackController on resume
        if (mPlaybackController != null) {
            long savedPosition = mPlaybackController.getCurrentPosition();
            if (savedPosition > 0 && mSeekBar != null) {
                mSeekBar.setProgress((int) savedPosition);
                if (mSeekTime != null) {
                    mSeekTime.setText(DisplayManager.formatTime((int) savedPosition));
                }
                Log.d(TAG, "onResume - restored position: " + savedPosition + "ms");
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0 && mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        unregisterReceiverSafely(mPlayerReadyReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        if (mEnableHandler != null) {
            mEnableHandler.removeCallbacksAndMessages(null);
        }
        mEnableControlsRunnable = null;
        
        unregisterMediaButtonReceiver();
        
        // Cleanup DisplayManager resources
        if (mDisplayManager != null) {
            mDisplayManager.release();
        }
        
        ToastManager.hidePersistentOverlay();
        
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    // ========================================================================
    // Seek Bar Rubber-Banding Prevention Methods
    // ========================================================================
    
    /**
     * Handles pause with position preservation to prevent rubber-banding.
     * Called when the user presses the pause button.
     * 
     * <p>This method stores the current position before pausing and sets
     * the mIsPausing flag to prevent position updates during the transition.</p>
     */
    private void handlePauseWithPositionPreservation() {
        if (mMusicService == null) return;
        
        // Store current position before pausing
        int currentPos = mMusicService.getCurrentPosition();
        mLastReportedPosition = currentPos;
        mIsPausing = true;
        
        // Pause the player
        mMusicService.pause();
        
        // Update UI immediately to show paused position
        if (mSeekBar != null) {
            mSeekBar.setProgress(currentPos);
        }
        if (mSeekTime != null) {
            mSeekTime.setText(DisplayManager.formatTime(currentPos));
        }
        
        // Reset pause flag after a short delay
        mHandler.postDelayed(() -> {
            mIsPausing = false;
        }, 200);
    }
    
    /**
     * Checks if a position update is stale (rubber-banding detection).
     * 
     * <p>A position update is considered stale if it jumps backward more than
     * POSITION_STALE_THRESHOLD_MS (500ms) from the last reported position,
     * or if a seek just occurred and the AudioTrack hasn't stabilized yet.</p>
     *
     * @param newPosition The new position to validate
     * @return True if the position update should be ignored
     */
    private boolean isStalePositionUpdate(long newPosition) {
        // During user seek or pause transition, ignore all updates
        if (mIsUserSeeking || mIsPausing) {
            return true;
        }
        
        // During seek stabilization period, ignore updates
        long timeSinceSeek = SystemClock.elapsedRealtime() - mLastSeekTimestamp;
        if (timeSinceSeek < SEEK_STABILIZATION_DELAY_MS) {
            Log.v(TAG, "Ignoring position update during seek stabilization: " + newPosition + "ms");
            return true;
        }
        
        // Check for stale backward jumps
        if (mLastReportedPosition > 0 && newPosition < mLastReportedPosition - POSITION_STALE_THRESHOLD_MS) {
            Log.d(TAG, "Ignoring stale position update: " + newPosition + 
                  " (last reported: " + mLastReportedPosition + ")");
            return true;
        }
        
        return false;
    }
    
    // ========================================================================
    // Album Art Helper Methods
    // ========================================================================
    
    /**
     * Loads album art with retry mechanism to ensure it appears.
     * 
     * <p>This method attempts to load album art from cache first.
     * If not cached, it triggers loading and retries if the image hasn't
     * appeared after a short delay.</p>
     *
     * @param imageView The ImageView to display album art in
     * @param songPath The file path of the song
     * @param retriesRemaining Number of retry attempts remaining
     */
    private void loadAlbumArtWithRetry(@NonNull ImageView imageView, @NonNull String songPath, int retriesRemaining) {
        if (mDisplayManager == null) return;
        
        // Check if already cached
        if (mDisplayManager.isAlbumArtCached(songPath)) {
            mDisplayManager.updateAlbumArt(imageView, songPath);
            Log.d(TAG, "Album art loaded from cache for: " + songPath);
            return;
        }
        
        // Trigger loading
        mDisplayManager.updateAlbumArt(imageView, songPath);
        
        // If we have retries left and the image might still be loading, check again
        if (retriesRemaining > 0) {
            mHandler.postDelayed(() -> {
                if (!isFinishing() && !isDestroyed() && mDisplayManager != null) {
                    // Check if album art is now cached
                    if (mDisplayManager.isAlbumArtCached(songPath)) {
                        mDisplayManager.updateAlbumArt(imageView, songPath);
                        Log.d(TAG, "Album art loaded on retry for: " + songPath);
                    } else if (retriesRemaining > 1) {
                        // Still not cached, retry again
                        loadAlbumArtWithRetry(imageView, songPath, retriesRemaining - 1);
                    } else {
                        // Final attempt with placeholder
                        mDisplayManager.updateAlbumArt(imageView, songPath);
                        Log.d(TAG, "Album art final attempt with placeholder for: " + songPath);
                    }
                }
            }, ALBUM_ART_RETRY_DELAY_MS);
        }
    }
    
    // ========================================================================
    // PlaybackController Listener Setup
    // ========================================================================
    
    /**
     * Sets up the PlaybackController listener for state change callbacks.
     * 
     * <p>This method configures a listener that receives position updates,
     * play state changes, song changes, and prepared state changes.
     * MusicPlayer is the OWNER of UI decisions - it decides when to throttle,
     * when to skip updates, and when to update the UI.</p>
     * 
     * <p><b>Rubber-Banding Prevention:</b> The onPositionChanged callback
     * includes stale position detection to prevent seek bar from jumping
     * backward when AudioTrack reports old positions after seek operations.</p>
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        
        if (mPlaybackControllerListener != null) {
            mPlaybackController.setListener(null);
        }
        
        mPlaybackControllerListener = new PlaybackController.PlaybackControllerListener() {
            @Override
            public void onPositionChanged(long positionMs, long durationMs) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    // CRITICAL: Stale position detection prevents rubber-banding
                    if (isStalePositionUpdate(positionMs)) return;
                    
                    long now = SystemClock.elapsedRealtime();
                    if (now - mLastPositionUpdateTime < POSITION_UPDATE_THROTTLE_MS) return;
                    mLastPositionUpdateTime = now;
                    
                    mLastReportedPosition = positionMs;
                    
                    if (mSeekBar != null) {
                        if (durationMs > 0 && mSeekBar.getMax() != (int) durationMs) {
                            mSeekBar.setMax((int) durationMs);
                        }
                        mSeekBar.setProgress((int) positionMs);
                    }
                    
                    if (mSeekTime != null) {
                        mSeekTime.setText(DisplayManager.formatTime((int) positionMs));
                    }
                    if (mTotalTime != null && durationMs > 0) {
                        mTotalTime.setText(DisplayManager.formatTime((int) durationMs));
                    }
                });
            }
            
            @Override
            public void onPlayStateChanged(boolean isPlaying) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    safeUpdatePlayButton();
                    
                    // When playback resumes, ensure position is correct
                    if (isPlaying && mPlaybackController != null) {
                        long position = mPlaybackController.getCurrentPosition();
                        if (mSeekBar != null && position > 0) {
                            mSeekBar.setProgress((int) position);
                        }
                    }
                });
            }
            
            @Override
            public void onSongChanged(String title, String artist, String path, long duration) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    mHasSongs = true;
                    mLastReportedPosition = 0;  // Reset position tracking for new song
                    
                    if (mSongTitle != null) {
                        String t = DisplayManager.formatSongTitle(title);
                        mSongTitle.setText(t);
                        if (mThemeHelper != null) {
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                    }
                    
                    if (mSongArtist != null) {
                        String a = DisplayManager.formatArtistName(artist);
                        mSongArtist.setText(a);
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                    }
                    
                    if (mSeekBar != null && duration > 0) {
                        mSeekBar.setMax((int) duration);
                        mSeekBar.setProgress(0);
                    }
                    
                    if (mTotalTime != null && duration > 0) {
                        mTotalTime.setText(DisplayManager.formatTime((int) duration));
                    }
                    if (mSeekTime != null) {
                        mSeekTime.setText("00:00");
                    }
                    
                    if (mDisplayManager != null) {
                        mDisplayManager.updateAlbumArt(mAlbumArtView, path);
                    }
                    safeUpdatePlayButton();
                });
            }
            
            @Override
            public void onPreparedStateChanged(boolean isPrepared) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    Log.d(TAG, "onPreparedStateChanged: isPrepared=" + isPrepared);
                    mIsPlayerPrepared.set(isPrepared);
                    
                    if (isPrepared) {
                        enableControlsWhenReady();
                    } else {
                        disableAllControls();
                    }
                    
                    safeUpdatePlayButton();
                    
                    if (isPrepared && mPlaybackController != null) {
                        long duration = mPlaybackController.getDuration();
                        if (mTotalTime != null && duration > 0) {
                            mTotalTime.setText(DisplayManager.formatTime((int) duration));
                        }
                        if (mSeekBar != null && duration > 0) {
                            mSeekBar.setMax((int) duration);
                            if (mIsPlayerPrepared.get() && mHasSongs) {
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                            }
                        }
                        Log.d(TAG, "Player prepared - duration: " + duration + "ms");
                    }
                });
            }
            
            @Override
            public void onOperationFailed(String operation, String reason) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        String message = "Cannot " + operation;
                        if (reason != null && !reason.isEmpty()) {
                            message += ": " + reason;
                        }
                        ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                        Log.w(TAG, "Operation failed: " + operation + " - " + reason);
                    }
                });
            }
        };
        
        mPlaybackController.setListener(mPlaybackControllerListener);
        Log.d(TAG, "PlaybackController listener configured with rubber-banding prevention");
    }
    
    // ========================================================================
    // Toggle Play/Pause with Rubber-Banding Prevention
    // ========================================================================
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method reads current state from PlaybackController
     * (single source of truth) and calls the appropriate MusicService method.
     * When pausing, it uses handlePauseWithPositionPreservation() to prevent
     * the seek bar from rubber-banding.</p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        boolean isPlaying = false;
        boolean isPrepared = false;
        
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
            isPrepared = mPlaybackController.isPrepared();
        }
        
        if (isPlaying) {
            // Use the dedicated method to prevent rubber-banding
            handlePauseWithPositionPreservation();
        } else if (isPrepared) {
            Log.d(TAG, "togglePlayPause: Resuming playback");
            mIsPausing = false;
            mMusicService.resume();
            updatePositionFromController();
        } else {
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(() -> {
                if (mPlaylistButton != null) {
                    mPlaylistButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                    }
                }
                
                if (mMetadataButton != null) {
                    mMetadataButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        final Typeface faTypeface = FontAwesome.getTypeface();
        
        // ALL CONTROL BUTTONS START DISABLED
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }

        // Apply button backgrounds
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Set letter spacing for text buttons
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Add touch animations
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        // Load placeholder album art
        if (mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
        }
        
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
        
        // Ensure seek bar is disabled initially
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }
    
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                        .setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                    break;
            }
            return false;
        });
    }
    
    // ========================================================================
    // Control Enable Methods
    // ========================================================================
    
    private void enableControlsWhenReady() {
        if (mEnableControlsRunnable != null) {
            mEnableHandler.removeCallbacks(mEnableControlsRunnable);
        }
        
        mEnableControlsRunnable = () -> {
            if (isFinishing() || isDestroyed()) return;
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
            
            Log.d(TAG, "enableControlsWhenReady: hasSongs=" + hasSongs + ", isPrepared=" + isPrepared);
            
            if (hasSongs && isPrepared) {
                // Enable play button
                if (mPlayButton != null && !mPlayButton.isEnabled()) {
                    mPlayButton.setEnabled(true);
                    mPlayButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
                        mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                        mThemeHelper.updateControlButton(mPlayButton, true, true);
                    }
                    Log.d(TAG, "Play button ENABLED - player prepared");
                }
                
                // Enable prev/next buttons
                if (mPrevButton != null && !mPrevButton.isEnabled()) {
                    mPrevButton.setEnabled(true);
                    mPrevButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateControlButton(mPrevButton, true, false);
                    }
                }
                
                if (mNextButton != null && !mNextButton.isEnabled()) {
                    mNextButton.setEnabled(true);
                    mNextButton.setAlpha(1.0f);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateControlButton(mNextButton, true, false);
                    }
                }
                
                // Enable repeat/shuffle buttons
                if (mRepeatButton != null && !mRepeatButton.isEnabled()) {
                    mRepeatButton.setEnabled(true);
                    mRepeatButton.setAlpha(1.0f);
                    updateRepeatButton();
                }
                
                if (mShuffleButton != null && !mShuffleButton.isEnabled()) {
                    mShuffleButton.setEnabled(true);
                    mShuffleButton.setAlpha(1.0f);
                    updateShuffleButton();
                }
                
                // Enable seekbar
                if (mSeekBar != null && !mSeekBar.isEnabled()) {
                    mSeekBar.setEnabled(true);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateSeekBar(mSeekBar, true);
                    }
                }
            } else if (hasSongs && !isPrepared) {
                // Retry after 500ms - player might still be preparing
                mEnableHandler.postDelayed(this::enableControlsWhenReady, 500);
                Log.d(TAG, "enableControlsWhenReady: waiting for player preparation...");
            }
        };
        
        mEnableHandler.post(mEnableControlsRunnable);
        
        // Safety timeout - don't keep retrying forever
        mEnableHandler.postDelayed(() -> {
            if (mEnableControlsRunnable != null) {
                mEnableHandler.removeCallbacks(mEnableControlsRunnable);
                mEnableControlsRunnable = null;
                Log.d(TAG, "Enable controls timeout - giving up");
            }
        }, 10000);
    }
    
    private void disableAllControls() {
        Log.d(TAG, "disableAllControls - disabling all controls");
        
        if (mPlayButton != null) {
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
        }
        if (mPrevButton != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
        }
        if (mNextButton != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
        }
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(() -> {
                enableAllControls();
                updateUIForSong(newSong);
            });
            
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                setupSeekBar();
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(() -> {
                        enableAllControls();
                        updateUIForSong(newSong);
                        if (mDisplayManager != null && mAlbumArtContainer != null) {
                            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(() -> setupSeekBar(), FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(() -> {
                        Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                            if (mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(mAlbumArtView, current.getPath());
                            }
                        }
                        setupSeekBar();
                    });
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                runOnUiThread(() -> ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG));
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(() -> {
            try {
                if (!isFinishing() && !isDestroyed()) {
                    update.run();
                }
            } finally {
                mIsUpdatingUI.set(false);
                if (mPendingUIUpdate != null) {
                    final Runnable pending = mPendingUIUpdate;
                    mPendingUIUpdate = null;
                    safeUpdateUI(pending);
                }
            }
        });
    }
    
    private void updatePositionFromController() {
        if (mPlaybackController == null) return;
        
        long position = mPlaybackController.getCurrentPosition();
        long duration = mPlaybackController.getDuration();
        
        if (mSeekBar != null && duration > 0) {
            if (mSeekBar.getMax() != (int) duration) {
                mSeekBar.setMax((int) duration);
            }
            mSeekBar.setProgress((int) position);
        }
        if (mSeekTime != null) {
            mSeekTime.setText(DisplayManager.formatTime((int) position));
        }
        if (mTotalTime != null && duration > 0) {
            mTotalTime.setText(DisplayManager.formatTime((int) duration));
        }
    }
    
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(finalSong.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            if (mSongArtist != null) {
                String artistText = DisplayManager.formatArtistName(finalSong.getArtist());
                mSongArtist.setText(artistText);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && finalSong.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) finalSong.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForPlayingSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = DisplayManager.formatSongTitle(finalSong.getTitle());
            if (mSongTitle != null) {
                mSongTitle.setText(displayText);
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            if (mSongArtist != null) {
                String artistText = DisplayManager.formatArtistName(finalSong.getArtist());
                mSongArtist.setText(artistText);
                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && finalSong.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) finalSong.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.updateAlbumArt(mAlbumArtView, finalSong.getPath());
                mDisplayManager.hideLoadingOverlay();
                mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
            }
        });
    }
    
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        
        safeUpdateUI(() -> {
            if (mPlayButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPlayButton, enabled, true);
            }
            if (mPrevButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPrevButton, enabled, false);
            }
            if (mNextButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mNextButton, enabled, false);
            }
            if (mRepeatButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateRepeatButton();
            }
            if (mShuffleButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateShuffleButton();
            }
            if (mSeekBar != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mSeekBar.setEnabled(enabled);
                mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
        });
    }
    
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        final boolean enabled = hasSongs && isPrepared;
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(enabled);
            mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mPrevButton, enabled, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(enabled);
            mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
            mThemeHelper.updateControlButton(mNextButton, enabled, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(enabled);
            mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(enabled);
            mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
            updateShuffleButton();
        }
    }
    
    private void applyNoSongState() {
        int totalSongs = (mMusicLibrary != null ? mMusicLibrary.getSongCount() : 0);
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        int looseCount = (looseSongs != null ? looseSongs.size() : 0);
        if (totalSongs + looseCount > 0) return;
        
        if (mIsSyncInProgress) return;
        
        mHasSongs = false;
        mIsPlayerPrepared.set(false);
        
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null && mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
            mDisplayManager.clearAlbumArtCache();
        }

        if (mDisplayManager != null && mAlbumArtContainer != null) {
            mDisplayManager.applyAlbumArtClipping(mAlbumArtContainer);
        }

        // Disable ALL controls when no songs
        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playNext();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playPrevious();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state will be updated via PlaybackController listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    private void updateRepeatButton() {
        if (mRepeatButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mRepeatButton.setText(FontAwesome.REPEAT);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isActive = (repeatMode != 0);
        final boolean isEnabled = mRepeatButton.isEnabled();
        
        if (repeatMode == 2) {
            mRepeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
        }
        
        mThemeHelper.updateControlButton(mRepeatButton, isEnabled, isActive);
    }
    
    private void updateShuffleButton() {
        if (mShuffleButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        final boolean isEnabled = mShuffleButton.isEnabled();
        
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(mShuffleButton, isEnabled, isShuffleOn);
    }
    
    // ========================================================================
    // Centralized Play Button Update
    // ========================================================================
    
    private void safeUpdatePlayButton() {
        if (mPlayButtonUpdateQueued.getAndSet(true)) {
            return;
        }
        
        mHandler.post(() -> {
            mPlayButtonUpdateQueued.set(false);
            
            if (isFinishing() || isDestroyed() || mThemeHelper == null || mPlayButton == null) {
                return;
            }
            
            boolean isPlaying = false;
            boolean isPrepared = false;
            
            if (mPlaybackController != null) {
                isPlaying = mPlaybackController.isPlaying();
                isPrepared = mPlaybackController.isPrepared();
            }
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            
            if (!hasSongs) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                mPlayButton.setAlpha(0.5f);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                }
                Log.d(TAG, "Play button: DISABLED (no songs)");
                return;
            }
            
            boolean shouldEnable = isPrepared;
            
            if (mPlayButton.isEnabled() != shouldEnable) {
                mPlayButton.setEnabled(shouldEnable);
                mPlayButton.setAlpha(shouldEnable ? 1.0f : 0.5f);
                Log.d(TAG, "Play button enabled state: " + shouldEnable);
            }
            
            String newText = isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY;
            
            if (!newText.equals(mPlayButton.getText())) {
                mPlayButton.setText(newText);
                if (mThemeHelper != null && shouldEnable) {
                    mThemeHelper.updateControlButton(mPlayButton, shouldEnable, true);
                }
                Log.d(TAG, "Play button updated: " + (isPlaying ? "PAUSE" : "PLAY") + 
                      " (prepared=" + isPrepared + ", hasSongs=" + hasSongs + ")");
            }
        });
    }
    
    // ========================================================================
    // SeekBar Setup
    // ========================================================================
    
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(progress));
                if (fromUser) {
                    // Record seek timestamp for stabilization period
                    mLastSeekTimestamp = SystemClock.elapsedRealtime();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mPlaybackController != null) mPlaybackController.onSeekStart();
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekPos);
                    if (mSeekTime != null) mSeekTime.setText(DisplayManager.formatTime(seekPos));
                }
                mSeekTargetPosition = -1;
                
                mSeekHandler.removeCallbacksAndMessages(null);
                
                mSeekHandler.postDelayed(() -> {
                    mIsUserSeeking = false;
                    if (mPlaybackController != null) {
                        mPlaybackController.forceResetSeeking();
                    }
                    if (mMusicService != null) {
                        int currentPos = mMusicService.getCurrentPosition();
                        int duration = mMusicService.getDuration();
                        if (mSeekBar != null) {
                            if (duration > 0 && mSeekBar.getMax() != duration) {
                                mSeekBar.setMax(duration);
                            }
                            mSeekBar.setProgress(currentPos);
                        }
                        if (mSeekTime != null) {
                            mSeekTime.setText(DisplayManager.formatTime(currentPos));
                        }
                    }
                    Log.d(TAG, "Seek flag reset - UI updates resumed");
                }, SEEK_RESET_DELAY_MS);
            }
        });
    }
    
    // ========================================================================
    // Album Art Methods (Delegated to DisplayManager)
    // ========================================================================
    
    private void updateAlbumArt(@Nullable String filePath) {
        if (mDisplayManager != null) {
            mDisplayManager.updateAlbumArt(mAlbumArtView, filePath);
        }
    }
    
    private void loadAndDisplayPlaceholder() {
        if (mDisplayManager != null && mAlbumArtView != null) {
            mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods (Delegated to DisplayManager)
    // ========================================================================
    
    private void showLoadingOverlay() {
        if (mDisplayManager != null) {
            ViewGroup rootView = findViewById(android.R.id.content);
            mDisplayManager.showLoadingOverlay(rootView);
        }
    }
    
    private void hideLoadingOverlay() {
        if (mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(this::hideLoadingOverlay, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(() -> {
                Song song = null;
                try {
                    Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                    
                    if (cachedSong != null && cachedSong.getTitle() != null && 
                        !cachedSong.getTitle().isEmpty() && 
                        !"Unknown Title".equals(cachedSong.getTitle())) {
                        song = cachedSong;
                    } else {
                        final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                        mmr.setDataSource(lastPath);
                        String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        final byte[] art = mmr.getEmbeddedPicture();
                        mmr.release();
                        
                        if (title == null || title.isEmpty()) {
                            final File file = new File(lastPath);
                            String name = file.getName();
                            final int dot = name.lastIndexOf('.');
                            if (dot > 0) name = name.substring(0, dot);
                            title = name;
                        }
                        if (artist == null) artist = "Unknown Artist";
                        if (album == null) album = "Unknown Album";
                        
                        String genre = "Unknown Genre";
                        Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        if (dbSong != null && dbSong.getGenre() != null && 
                            !"Unknown Genre".equals(dbSong.getGenre())) {
                            genre = dbSong.getGenre();
                            Log.d(TAG, "Found genre in database: " + genre);
                        } else {
                            String fileGenre = CharacterMapper.getGenre(lastPath);
                            if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                genre = fileGenre;
                                Log.d(TAG, "Read genre from file: " + genre);
                            }
                        }
                        
                        song = new Song(title, artist, album, genre, lastPath, 0, null);
                        if (art != null && mDisplayManager != null) {
                            final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                }
                
                final Song finalSong = song;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (finalSong != null && mThemeHelper != null) {
                        mCachedLastSong = finalSong;
                        if (mSongTitle != null) {
                            mSongTitle.setText(finalSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(finalSong.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        if (mDisplayManager != null) {
                            Bitmap cachedArt = mDisplayManager.getCachedAlbumArt(lastPath);
                            if (cachedArt != null) {
                                // Album art will be displayed via DisplayManager
                            } else {
                                mDisplayManager.loadAndDisplayPlaceholder(mAlbumArtView);
                                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                    if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                        updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                    }
                                }, FOCUS_SCROLL_DELAY_MS);
                            }
                        }
                        startServiceWithCachedSong();
                    } else {
                        applyNoSongState();
                        loadSongsAndStartService();
                    }
                });
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(this::hideLoadingOverlay, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    setupSeekBar();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    if (mDisplayManager != null) {
                        mDisplayManager.refreshPlaceholder(mAlbumArtView);
                    }
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mDisplayManager != null) {
            mDisplayManager.refreshPlaceholder(mAlbumArtView);
        }
        ToastManager.refreshThemeColor();
    }
    
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    private void registerReceivers() {
        // Update Player Receiver
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    safeUpdateUI(() -> {
                        if (mMusicService != null) {
                            if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                final int duration = mMusicService.getDuration();
                                final int position = mMusicService.getCurrentPosition();
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(position);
                            }
                            
                            final Song song = mMusicService.getCurrentSong();
                            if (song != null) {
                                if (mMusicService.isAnyPlayerPlaying()) {
                                    updateUIForPlayingSong(song);
                                } else {
                                    updateUIForSong(song);
                                }
                            }
                        }
                        setupSeekBar();
                    });
                }
            }
        };
        
        // Play Song Receiver
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        // Bluetooth Play Receiver
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                }
            }
        };
        
        // Bluetooth Pause Receiver
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                    }
                }
            }
        };
        
        // Media Button Receiver
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                }
            }
        };
        
        // Get Playing State Receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        // Reset Player Receiver
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.pause();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(() -> {
                        applyNoSongState();
                        
                        if (!preserveSettings && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }
                        
                        if (mShuffleButton != null && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mShuffleButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mRepeatButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mRepeatButton, false, false);
                        }
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mPlayButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mPlayButton, false, false);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mPrevButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mPrevButton, false, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mNextButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mNextButton, false, false);
                        }
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(mSeekBar, false);
                        }
                        
                        ToastManager.hidePersistentOverlay();
                        hideLoadingOverlay();
                    });
                }
            }
        };
        
        // Force Update Player Receiver
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null) {
                            updateUIForPlayingSong(currentSong);
                        }
                        setupSeekBar();
                    }
                }
            }
        };
        
        // Save Player State Now Receiver
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        // Bluetooth Connection Receiver
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        // Sync Started Receiver
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        // Sync Complete Receiver
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        // Update Playlist From Folders Receiver
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                setupSeekBar();
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                    updateAlbumArt(currentSong.getPath());
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(() -> applyNoSongState());
                        }
                    }
                }
            }
        };
        
        // Soft Update Playlist Receiver
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                setupSeekBar();
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null) {
                                    updateAlbumArt(currentSong.getPath());
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.pause();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(() -> {
                                applyNoSongState();
                                ToastManager.hidePersistentOverlay();
                                hideLoadingOverlay();
                            });
                        }
                    }
                }
            }
        };
        
        // Update Song In Playlist Receiver
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        final Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null && songPath.equals(currentSong.getPath())) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(songPath);
                        }
                    }
                }
            }
        };
        
        // Playback Recovery Receiver
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        // Sort Mode Receiver
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(() -> {
                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null) {
                                updateUIForSong(currentSong);
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        // Player Status Receiver
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(() -> {
                            ToastManager.showToast(MusicPlayer.this, playerType + " is active...", ToastManager.LENGTH_NORMAL);
                        });
                    }
                }
            }
        };
        
        // Song Prepared Receiver
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra(EXTRA_DURATION, 0);
                    final int audioSessionId = intent.getIntExtra(EXTRA_AUDIO_SESSION_ID, -1);
                    final String songPath = intent.getStringExtra(EXTRA_SONG_PATH);
                    
                    runOnUiThread(() -> {
                        if (mTotalTime != null && duration > 0) {
                            mTotalTime.setText(DisplayManager.formatTime(duration));
                        }
                        if (mSeekBar != null && duration > 0) {
                            mSeekBar.setMax(duration);
                            if (mIsPlayerPrepared.get()) {
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                            }
                        }
                        if (mEqualizerButton != null) {
                            mEqualizerButton.setEnabled(true);
                            if (mThemeHelper != null) {
                                mThemeHelper.updateButton(mEqualizerButton, true);
                            }
                        }
                        if (songPath != null && mMusicService != null) {
                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                if (duration > 0) {
                                    currentSong.setDuration(duration);
                                }
                                updateUIForSong(currentSong);
                            }
                        }
                    });
                }
            }
        };
        
        // Player Ready Receiver
        mPlayerReadyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_READY.equals(intent.getAction())) {
                    runOnUiThread(() -> {
                        if (mPlayButton != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                            Log.d(TAG, "PLAYER_READY broadcast received - controls will be enabled when prepared");
                        }
                    });
                }
            }
        };
        
        // Register all receivers
        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);
        
        IntentFilter playSongFilter = new IntentFilter();
        playSongFilter.addAction("PLAY_SONG");
        registerReceiver(mPlaySongReceiver, playSongFilter);
        
        IntentFilter btPlayFilter = new IntentFilter();
        btPlayFilter.addAction("BLUETOOTH_PLAY");
        registerReceiver(mBluetoothPlayReceiver, btPlayFilter);
        
        IntentFilter btPauseFilter = new IntentFilter();
        btPauseFilter.addAction("BLUETOOTH_PAUSE");
        registerReceiver(mBluetoothPauseReceiver, btPauseFilter);
        
        IntentFilter mediaButtonFilter = new IntentFilter();
        mediaButtonFilter.addAction("MEDIA_BUTTON_ACTION");
        registerReceiver(mMediaButtonReceiver, mediaButtonFilter);
        
        IntentFilter getStateFilter = new IntentFilter();
        getStateFilter.addAction("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, getStateFilter);
        
        IntentFilter resetFilter = new IntentFilter();
        resetFilter.addAction("RESET_PLAYER_STATE");
        registerReceiver(mResetPlayerReceiver, resetFilter);
        
        IntentFilter forceUpdateFilter = new IntentFilter();
        forceUpdateFilter.addAction("FORCE_UPDATE_PLAYER");
        registerReceiver(mForceUpdatePlayerReceiver, forceUpdateFilter);
        
        IntentFilter saveStateFilter = new IntentFilter();
        saveStateFilter.addAction("SAVE_PLAYER_STATE_NOW");
        registerReceiver(mSavePlayerStateNowReceiver, saveStateFilter);
        
        IntentFilter btConnectionFilter = new IntentFilter();
        btConnectionFilter.addAction("BLUETOOTH_CONNECTED");
        registerReceiver(mBluetoothConnectionReceiver, btConnectionFilter);
        
        IntentFilter syncStartedFilter = new IntentFilter();
        syncStartedFilter.addAction("SYNC_STARTED");
        registerReceiver(mSyncStartedReceiver, syncStartedFilter);
        
        IntentFilter syncCompleteFilter = new IntentFilter();
        syncCompleteFilter.addAction("SYNC_COMPLETE");
        registerReceiver(mSyncCompleteReceiver, syncCompleteFilter);
        
        IntentFilter updatePlaylistFilter = new IntentFilter();
        updatePlaylistFilter.addAction("UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiver(mUpdatePlaylistFromFoldersReceiver, updatePlaylistFilter);
        
        IntentFilter softUpdateFilter = new IntentFilter();
        softUpdateFilter.addAction("SOFT_UPDATE_PLAYLIST");
        registerReceiver(mSoftUpdatePlaylistReceiver, softUpdateFilter);
        
        IntentFilter updateSongFilter = new IntentFilter();
        updateSongFilter.addAction("UPDATE_SONG_IN_PLAYLIST");
        registerReceiver(mUpdateSongInPlaylistReceiver, updateSongFilter);
        
        IntentFilter recoveryFilter = new IntentFilter();
        recoveryFilter.addAction("PLAYBACK_RECOVERED");
        registerReceiver(mPlaybackRecoveryReceiver, recoveryFilter);
        
        IntentFilter sortModeFilter = new IntentFilter();
        sortModeFilter.addAction(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, sortModeFilter);
        
        IntentFilter playerStatusFilter = new IntentFilter();
        playerStatusFilter.addAction(ACTION_PLAYER_STATUS_UPDATE);
        registerReceiver(mPlayerStatusReceiver, playerStatusFilter);
        
        IntentFilter songPreparedFilter = new IntentFilter();
        songPreparedFilter.addAction(ACTION_SONG_PREPARED);
        registerReceiver(mSongPreparedReceiver, songPreparedFilter);
        
        IntentFilter playerReadyFilter = new IntentFilter();
        playerReadyFilter.addAction(ACTION_PLAYER_READY);
        registerReceiver(mPlayerReadyReceiver, playerReadyFilter);
    }
    
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    private void setupListeners() {
        // Play button
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlayPauseClickTime = currentTime;
                    togglePlayPause();
                }
            });
        }
        
        // Next button
        if (mNextButton != null) {
            mNextButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastNextClickTime = currentTime;
                    playNextSong();
                }
            });
        }
        
        // Previous button
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPrevClickTime = currentTime;
                    playPreviousSong();
                }
            });
        }
        
        // Repeat button
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastRepeatClickTime = currentTime;
                    if (mMusicService != null && mRepeatButton.isEnabled()) {
                        final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButton();
                        final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        // Shuffle button
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastShuffleClickTime = currentTime;
                    if (mMusicService != null && mShuffleButton.isEnabled()) {
                        final boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButton();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        // Manager button
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastManagerClickTime = currentTime;
                    openFolderManager();
                }
            });
        }
        
        // Llama/Credits button
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastLlamaClickTime = currentTime;
                    final View mainContent = findViewById(android.R.id.content);
                    mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(d -> {
                        final View content = findViewById(android.R.id.content);
                        content.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                    });
                    dialog.show();
                }
            });
        }
    
        // Playlist button
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlaylistClickTime = currentTime;
                    openPlaylist();
                }
            });
        }
        
        // Equalizer button
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastEqualizerClickTime = currentTime;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        
        // Metadata button
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastMetadataClickTime = currentTime;
                    openMetadataEditor();
                }
            });
        }
    }
    
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }
    
    /**
     * Called when the system requests memory trimming.
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
        
        // Clear album art cache on memory pressure
        if (level >= TRIM_MEMORY_RUNNING_MODERATE && mDisplayManager != null) {
            mDisplayManager.clearAlbumArtCache();
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        // Refresh control buttons when window regains focus
        if (hasFocus && mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(mAlbumArtView, currentSong.getPath());
                }
            }
        }
    }
    
    /**
     * Called when a key is pressed down.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) {
            return super.onKeyDown(keyCode, event);
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /**
     * Called when a key is released.
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mMusicService != null && !mMusicService.isAnyPlayerPlaying()) {
                    if (mMusicService.isAnyPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
    /**
     * Called when an activity launched with startActivityForResult completes.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Called when permission request results are available.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
        }
    }
}