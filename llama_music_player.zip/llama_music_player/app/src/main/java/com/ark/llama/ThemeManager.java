package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Manager for application theme colors.
 * 
 * <p>This class provides:
 * <ul>
 *   <li>Singleton pattern for global theme management</li>
 *   <li>Persistence of selected theme color across app restarts</li>
 *   <li>Access to all available color options and their names</li>
 *   <li>Support for 30 different theme colors across multiple color families</li>
 * </ul>
 * </p>
 * 
 * <p>Available color families:
 * <ul>
 *   <li><b>Warm Tones</b> - Neon Flame, Berry Crush, Rose Quartz, Cherry Pop, etc.</li>
 *   <li><b>Golden Tones</b> - Amber Glow, Wild Honey, Lemon Drop, Solar Flare, etc.</li>
 *   <li><b>Fresh Tones</b> - Neon Lime, Fresh Kiwi, Clover Field, Neon Green</li>
 *   <li><b>Cool Tones</b> - Pine Grove, Cool Sage, Sea Foam, Neon Cyan</li>
 *   <li><b>Ocean Tones</b> - Aqua Wave, Navy Blue, Ocean Blue, Azure Sky, Royal Blue</li>
 *   <li><b>Mystic Tones</b> - Irish Haze, Indigo Dream, Cosmic Purple</li>
 * </ul>
 * </p>
 * 
 * <p>The manager follows Google's recommendations for:
 * <ul>
 *   <li>Singleton pattern with thread-safe initialization</li>
 *   <li>Proper context usage with application context</li>
 *   <li>Efficient SharedPreferences operations</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is thread-safe. The singleton instance is created using
 * synchronized double-checked locking. All read/write operations to
 * SharedPreferences are atomic and thread-safe.</p>
 * 
 * <p>All operations are immediate.</p>
 * 
 * @see ThemeHelper
 * @see SharedPreferences
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class ThemeManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the theme color value. */
    private static final String KEY_THEME_COLOR = "theme_color";
    
    /** Key for storing the theme color index. */
    private static final String KEY_THEME_INDEX = "theme_color_index";
    
    /** Default theme color index (0 = Royal Llama). */
    private static final int DEFAULT_THEME_INDEX = 0;
    
    // ========================================================================
    // Theme Color Data
    // ========================================================================
    
    /**
     * Array of color hex values for all available themes.
     * Index corresponds to position in the theme selection list.
     */
    private static final String[] COLOR_VALUES = {
        "#B8A86E",  // Royal Llama (Default) - 0
        
        // Warm Tones
        "#FF00FF",  // Neon Flame - 1
        "#FF40BF",  // Berry Crush - 2
        "#FF1493",  // Rose Quartz - 3
        "#FF0066",  // Cherry Pop - 4
        "#FF0000",  // Red Jasper - 5
        "#FF2400",  // Scarlet Fire - 6
        "#FF4500",  // Sunset Glow - 7
        "#FF6B35",  // Citrus Burst - 8
        
        // Golden Tones
        "#FF8C00",  // Amber Glow - 9
        "#FFB347",  // Wild Honey - 10
        "#FFD700",  // Lemon Drop - 11
        "#FFEA00",  // Solar Flare - 12
        "#FFFF00",  // Neon Yellow - 13
        
        // Fresh Tones
        "#CFFF00",  // Neon Lime - 14
        "#9AFF00",  // Fresh Kiwi - 15
        "#7FFF00",  // Clover Field - 16
        "#39FF14",  // Neon Green - 17
        
        // Cool Tones
        "#00FF66",  // Pine Grove - 18
        "#00FF7F",  // Cool Sage - 19
        "#00FFAA",  // Sea Foam - 20
        "#00FFFF",  // Neon Cyan - 21
        
        // Ocean Tones
        "#00E5FF",  // Aqua Wave - 22
        "#00CED1",  // Navy Blue - 23
        "#00BFFF",  // Ocean Blue - 24
        "#1E90FF",  // Azure Sky - 25
        "#4169E1",  // Royal Blue - 26
        
        // Mystic Tones
        "#6A5ACD",  // Irish Haze - 27
        "#8A2BE2",  // Indigo Dream - 28
        "#9D00FF",  // Cosmic Purple - 29
    };
    
    /**
     * Array of display names for all available themes.
     * Must match the order of COLOR_VALUES.
     */
    private static final String[] COLOR_NAMES = {
        "Royal Llama",      // 0
        
        // Warm Tones
        "Neon Flame",       // 1
        "Berry Crush",      // 2
        "Rose Quartz",      // 3
        "Cherry Pop",       // 4
        "Red Jasper",       // 5
        "Scarlet Fire",     // 6
        "Sunset Glow",      // 7
        "Citrus Burst",     // 8
        
        // Golden Tones
        "Amber Glow",       // 9
        "Wild Honey",       // 10
        "Lemon Drop",       // 11
        "Solar Flare",      // 12
        "Neon Yellow",      // 13
        
        // Fresh Tones
        "Neon Lime",        // 14
        "Fresh Kiwi",       // 15
        "Clover Field",     // 16
        "Neon Green",       // 17
        
        // Cool Tones
        "Pine Grove",       // 18
        "Cool Sage",        // 19
        "Sea Foam",         // 20
        "Neon Cyan",        // 21
        
        // Ocean Tones
        "Aqua Wave",        // 22
        "Navy Blue",        // 23
        "Ocean Blue",       // 24
        "Azure Sky",        // 25
        "Royal Blue",       // 26
        
        // Mystic Tones
        "Irish Haze",       // 27
        "Indigo Dream",     // 28
        "Cosmic Purple",    // 29
    };
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance (volatile for thread-safe double-checked locking). */
    @Nullable
    private static volatile ThemeManager sInstance;
    
    /** Application context. */
    @NonNull
    private final Context mContext;
    
    /** Current theme color value (hex string). */
    @NonNull
    private String mCurrentColor;
    
    /** Current theme color index. */
    private int mCurrentColorIndex;
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context (will be converted to application context)
     */
    private ThemeManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadTheme();
    }
    
    /**
     * Returns the singleton instance of ThemeManager.
     * Thread-safe with double-checked locking.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static ThemeManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (ThemeManager.class) {
                if (sInstance == null) {
                    sInstance = new ThemeManager(context);
                }
            }
        }
        return sInstance;
    }
    
    // ========================================================================
    // Theme Loading and Saving
    // ========================================================================
    
    /**
     * Loads the saved theme color from SharedPreferences.
     * Falls back to default if no saved theme exists or index is invalid.
     * This method is called from the constructor and is thread-safe.
     */
    private void loadTheme() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentColorIndex = prefs.getInt(KEY_THEME_INDEX, DEFAULT_THEME_INDEX);
        
        if (mCurrentColorIndex < 0 || mCurrentColorIndex >= COLOR_VALUES.length) {
            mCurrentColorIndex = DEFAULT_THEME_INDEX;
        }
        
        mCurrentColor = COLOR_VALUES[mCurrentColorIndex];
    }
    
    /**
     * Sets the current theme color by index.
     * Persists the selection to SharedPreferences.
     * Thread-safe: SharedPreferences.Editor.apply() is asynchronous but atomic.
     *
     * @param colorIndex The index of the theme color to set (must be within bounds)
     */
    public void setThemeColor(int colorIndex) {
        if (colorIndex >= 0 && colorIndex < COLOR_VALUES.length) {
            mCurrentColorIndex = colorIndex;
            mCurrentColor = COLOR_VALUES[colorIndex];
            
            SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
            editor.putString(KEY_THEME_COLOR, mCurrentColor);
            editor.putInt(KEY_THEME_INDEX, mCurrentColorIndex);
            editor.apply();
        }
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current theme color as a hex string.
     * Thread-safe: mCurrentColor is final after construction, only updated via setThemeColor.
     *
     * @return The current theme color (e.g., "#B8A86E")
     */
    @NonNull
    public String getCurrentColor() {
        return mCurrentColor;
    }
    
    /**
     * Returns the current theme color as an integer (ARGB format).
     * Thread-safe: Color.parseColor() is a pure function.
     *
     * @return The current theme color integer
     */
    public int getCurrentColorInt() {
        return Color.parseColor(mCurrentColor);
    }
    
    /**
     * Returns the current theme color index.
     * Thread-safe: mCurrentColorIndex is volatile and only updated via setThemeColor.
     *
     * @return The index in the color arrays
     */
    public int getCurrentColorIndex() {
        return mCurrentColorIndex;
    }
    
    /**
     * Returns all theme color names.
     * Returns a copy of the array to prevent modification.
     *
     * @return Array of color names
     */
    @NonNull
    public String[] getColorNames() {
        return COLOR_NAMES.clone();
    }
    
    /**
     * Returns all theme color hex values.
     * Returns a copy of the array to prevent modification.
     *
     * @return Array of color hex values
     */
    @NonNull
    public String[] getColorValues() {
        return COLOR_VALUES.clone();
    }
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Returns the number of available theme colors.
     *
     * @return The total number of themes
     */
    public int getThemeCount() {
        return COLOR_VALUES.length;
    }
    
    /**
     * Checks if a color index is valid.
     *
     * @param colorIndex The index to check
     * @return True if the index is within bounds
     */
    public boolean isValidColorIndex(int colorIndex) {
        return colorIndex >= 0 && colorIndex < COLOR_VALUES.length;
    }
    
    /**
     * Gets the color name for a specific index.
     *
     * @param colorIndex The index of the theme
     * @return The color name, or null if index is invalid
     */
    @Nullable
    public String getColorName(int colorIndex) {
        if (isValidColorIndex(colorIndex)) {
            return COLOR_NAMES[colorIndex];
        }
        return null;
    }
    
    /**
     * Gets the color value for a specific index.
     *
     * @param colorIndex The index of the theme
     * @return The color hex value, or null if index is invalid
     */
    @Nullable
    public String getColorValue(int colorIndex) {
        if (isValidColorIndex(colorIndex)) {
            return COLOR_VALUES[colorIndex];
        }
        return null;
    }
}