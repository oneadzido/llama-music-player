// ThemeManager.java
package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Stores the application's current theme color and exposes the set of
 * available themes.
 *
 * <p>The current theme is selected by index into {@link #COLOR_VALUES}
 * and the resource array {@code R.array.theme_names}, persisted to
 * {@link SharedPreferences}, and read back on the next process launch.
 * The class is the single source of truth for which color is applied;
 * {@link ThemeHelper} reads the current color from this manager when
 * it themes UI components.</p>
 *
 * <p>The theme display names live in the resource array
 * {@code R.array.theme_names} so that every locale can present the
 * list in its own language. The colour hex values are
 * locale-independent and remain in this class.</p>
 *
 * <h3>Localization of Theme Names</h3>
 * <p>The array is read on demand through
 * {@link LanguageManager#getLocalizedContext()}, not cached from the
 * application context at construction time. The application context
 * resolves against the system locale; the localized context resolves
 * against the app's selected one. A device whose system language
 * differs from the app's selection therefore presents the theme list
 * in the app's language rather than the system's.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The singleton instance is created under double-checked locking.
 * Every read of the current color returns the value held in memory at
 * that moment. {@link #setThemeColor(int)} updates the in-memory value
 * before scheduling the preference write, so a subsequent read observes
 * the new color even when the write has not yet been flushed to disk.</p>
 *
 * @see ThemeHelper
 * @see SharedPreferences
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.0.0
 */
public class ThemeManager {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "ThemeManager";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted theme color value. */
    private static final String KEY_THEME_COLOR = "theme_color";

    /** Key for the persisted theme color index. */
    private static final String KEY_THEME_INDEX = "theme_color_index";

    /** Default theme index, which corresponds to Royal Llama. */
    private static final int DEFAULT_THEME_INDEX = 0;

    // ============================================================================
    // Theme Color Data
    // ============================================================================

    /** Hex color values for the available themes, indexed by theme index. */
    private static final String[] COLOR_VALUES = {
        "#B8A86E",  // 0  Royal Llama
        // Warm tones.
        "#FF00FF",  // 1  Neon Flame
        "#FF40BF",  // 2  Berry Crush
        "#FF1493",  // 3  Rose Quartz
        "#FF0066",  // 4  Cherry Pop
        "#FF0000",  // 5  Red Jasper
        "#FF2400",  // 6  Scarlet Fire
        "#FF4500",  // 7  Sunset Glow
        "#FF6B35",  // 8  Citrus Burst
        // Golden tones.
        "#FF8C00",  // 9  Amber Glow
        "#FFB347",  // 10 Wild Honey
        "#FFD700",  // 11 Lemon Drop
        "#FFEA00",  // 12 Solar Flare
        "#FFFF00",  // 13 Neon Yellow
        // Fresh tones.
        "#CFFF00",  // 14 Neon Lime
        "#9AFF00",  // 15 Fresh Kiwi
        "#7FFF00",  // 16 Clover Field
        "#39FF14",  // 17 Neon Green
        // Cool tones.
        "#00FF66",  // 18 Pine Grove
        "#00FF7F",  // 19 Cool Sage
        "#00FFAA",  // 20 Sea Foam
        "#00FFFF",  // 21 Neon Cyan
        // Ocean tones.
        "#00E5FF",  // 22 Aqua Wave
        "#00CED1",  // 23 Navy Blue
        "#00BFFF",  // 24 Ocean Blue
        "#1E90FF",  // 25 Azure Sky
        "#4169E1",  // 26 Royal Blue
        // Mystic tones.
        "#6A5ACD",  // 27 Irish Haze
        "#8A2BE2",  // 28 Indigo Dream
        "#9D00FF",  // 29 Cosmic Purple
        // Muted tones.
        "#FFFFFF",  // 30 Pure White
        "#9DBCBC",  // 31 Frosted Glass
    };

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile ThemeManager sInstance;

    /** Application context used for preference and resource access. */
    @NonNull
    private final Context mContext;

    /** Current theme color value, as a hex string. */
    @NonNull
    private String mCurrentColor;

    /** Current theme index. */
    private int mCurrentColorIndex;

    /**
     * Constructs the singleton and reads the persisted theme into
     * memory.
     *
     * @param context A context; the application context is retained
     */
    private ThemeManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadTheme();
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static ThemeManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (ThemeManager.class) {
                if (sInstance == null) {
                    sInstance = new ThemeManager(context);
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Theme Loading and Saving
    // ============================================================================

    /**
     * Reads the persisted theme index into memory.
     *
     * <p>When the stored index is out of range, the default index is
     * used.</p>
     */
    private void loadTheme() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentColorIndex = preferences.getInt(KEY_THEME_INDEX, DEFAULT_THEME_INDEX);

        if (mCurrentColorIndex < 0 || mCurrentColorIndex >= COLOR_VALUES.length) {
            mCurrentColorIndex = DEFAULT_THEME_INDEX;
        }

        mCurrentColor = COLOR_VALUES[mCurrentColorIndex];
    }

    /**
     * Applies the theme at the given index and persists the selection.
     *
     * <p>An out-of-range index is ignored. An in-range index updates the
     * in-memory value before the preference write is scheduled.</p>
     *
     * @param colorIndex Index of the theme to apply
     */
    public void setThemeColor(int colorIndex) {
        if (colorIndex >= 0 && colorIndex < COLOR_VALUES.length) {
            mCurrentColorIndex = colorIndex;
            mCurrentColor = COLOR_VALUES[colorIndex];

            SharedPreferences.Editor editor = mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE).edit();
            editor.putString(KEY_THEME_COLOR, mCurrentColor);
            editor.putInt(KEY_THEME_INDEX, mCurrentColorIndex);
            editor.apply();
        }
    }

    // ============================================================================
    // Getter Methods
    // ============================================================================

    /**
     * Returns the current theme color as a hex string.
     *
     * @return The current theme color, such as {@code "#B8A86E"}
     */
    @NonNull
    public String getCurrentColor() {
        return mCurrentColor;
    }

    /**
     * Returns the current theme color as an integer.
     *
     * <p>The stored value is expected to be a valid hex string. A
     * malformed value causes {@link Color#parseColor(String)} to throw
     * {@link IllegalArgumentException}.</p>
     *
     * @return The current theme color as an integer
     */
    public int getCurrentColorInt() {
        return Color.parseColor(mCurrentColor);
    }

    /**
     * Returns the current theme index.
     *
     * @return The index into the color arrays
     */
    public int getCurrentColorIndex() {
        return mCurrentColorIndex;
    }

    /**
     * Returns a copy of every localized theme display name.
     *
     * <p>The array is read on demand from the app's selected locale,
     * through {@link LanguageManager#getLocalizedContext()}. A theme
     * list presented after a language change therefore shows the new
     * language's names without any cache invalidation on this class's
     * part.</p>
     *
     * @return A new array containing every theme name
     */
    @NonNull
    public String[] getColorNames() {
        return loadColorNames().clone();
    }

    /**
     * Returns a copy of every theme hex color value.
     *
     * @return A new array containing every theme color value
     */
    @NonNull
    public String[] getColorValues() {
        return COLOR_VALUES.clone();
    }

    // ============================================================================
    // Utility Methods
    // ============================================================================

    /**
     * Returns the number of available themes.
     *
     * @return The number of themes
     */
    public int getThemeCount() {
        return COLOR_VALUES.length;
    }

    /**
     * Returns whether the given theme index is within range.
     *
     * @param colorIndex Index to test
     * @return True when the index refers to an available theme
     */
    public boolean isValidColorIndex(int colorIndex) {
        return colorIndex >= 0 && colorIndex < COLOR_VALUES.length;
    }

    /**
     * Returns the localized display name of the theme at the given
     * index.
     *
     * @param colorIndex Index of the theme
     * @return The theme name, or null when the index is out of range
     */
    @Nullable
    public String getColorName(int colorIndex) {
        if (!isValidColorIndex(colorIndex)) {
            return null;
        }
        final String[] names = loadColorNames();
        return (colorIndex < names.length) ? names[colorIndex] : null;
    }

    /**
     * Returns the hex color value of the theme at the given index.
     *
     * @param colorIndex Index of the theme
     * @return The theme color value, or null when the index is out of
     *         range
     */
    @Nullable
    public String getColorValue(int colorIndex) {
        if (isValidColorIndex(colorIndex)) {
            return COLOR_VALUES[colorIndex];
        }
        return null;
    }

    // ============================================================================
    // Localization Helpers
    // ============================================================================

    /**
     * Reads the theme-names array from the app's selected locale.
     *
     * <p>Reads through {@link LanguageManager#getLocalizedContext()},
     * which carries the app's selected locale. The application context
     * would resolve against the system locale, which is the wrong
     * language on every device whose system setting differs from the
     * app's selection.</p>
     *
     * <p>The array is read on every call rather than cached; the
     * {@code Resources} class caches it internally, so the cost is a
     * map lookup.</p>
     *
     * @return The theme names in the app's selected language; empty
     *         when the resource cannot be read
     */
    @NonNull
    private String[] loadColorNames() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext()
                .getResources()
                .getStringArray(R.array.theme_names);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to load theme names", exception);
            return new String[0];
        }
    }
}