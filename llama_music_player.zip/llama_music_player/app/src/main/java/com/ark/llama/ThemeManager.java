package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Stores the application's current theme color and exposes the set of
 * available themes.
 *
 * <p>The current theme is selected by index into
 * {@link #COLOR_VALUES} and {@link #COLOR_NAMES}, persisted to
 * {@link SharedPreferences}, and read back on the next process launch.
 * The class is the single source of truth for which color is applied;
 * {@link ThemeHelper} reads the current color from this manager when it
 * themes UI components.</p>
 *
 * <p>The available themes are grouped into warm, golden, fresh, cool,
 * ocean, and mystic families, each contributing one or more named
 * colors to the list.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The singleton instance is created under double-checked locking.
 * Every read of the current color returns the value held in memory at
 * that moment. {@link #setThemeColor(int)} updates the in-memory value
 * before scheduling the preference write, so a subsequent read observes
 * the new color even when the write has not yet been flushed to disk.</p>
 *
 * @see ThemeHelper
 * @see SharedPreferences
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class ThemeManager {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted theme color value. */
    private static final String KEY_THEME_COLOR = "theme_color";

    /** Key for the persisted theme color index. */
    private static final String KEY_THEME_INDEX = "theme_color_index";

    /** Default theme index, which corresponds to Royal Llama. */
    private static final int DEFAULT_THEME_INDEX = 0;

    // ========================================================================
    // Theme Color Data
    // ========================================================================

    /** Hex color values for the available themes, indexed by theme index. */
    private static final String[] COLOR_VALUES = {
        "#B8A86E",  // 0  Royal Llama
        // Warm tones.
        "#FF00FF",  // 1  Neon Flame
        "#FF40BF",  // 2  Berry Crush
        "#FF1493",  // 3  Rose Quartz
        "#FF0066",  // 4  Cherry Pop
        "#FF0000",  // 5  Red Jasper
        "#FF2400",  // 6  Scarlet Fire
        "#FF4500",  // 7  Sunset Glow
        "#FF6B35",  // 8  Citrus Burst
        // Golden tones.
        "#FF8C00",  // 9  Amber Glow
        "#FFB347",  // 10 Wild Honey
        "#FFD700",  // 11 Lemon Drop
        "#FFEA00",  // 12 Solar Flare
        "#FFFF00",  // 13 Neon Yellow
        // Fresh tones.
        "#CFFF00",  // 14 Neon Lime
        "#9AFF00",  // 15 Fresh Kiwi
        "#7FFF00",  // 16 Clover Field
        "#39FF14",  // 17 Neon Green
        // Cool tones.
        "#00FF66",  // 18 Pine Grove
        "#00FF7F",  // 19 Cool Sage
        "#00FFAA",  // 20 Sea Foam
        "#00FFFF",  // 21 Neon Cyan
        // Ocean tones.
        "#00E5FF",  // 22 Aqua Wave
        "#00CED1",  // 23 Navy Blue
        "#00BFFF",  // 24 Ocean Blue
        "#1E90FF",  // 25 Azure Sky
        "#4169E1",  // 26 Royal Blue
        // Mystic tones.
        "#6A5ACD",  // 27 Irish Haze
        "#8A2BE2",  // 28 Indigo Dream
        "#9D00FF",  // 29 Cosmic Purple
    };

    /** Display names for the available themes, index-aligned with {@link #COLOR_VALUES}. */
    private static final String[] COLOR_NAMES = {
        "Royal Llama",      // 0
        // Warm tones.
        "Neon Flame",       // 1
        "Berry Crush",      // 2
        "Rose Quartz",      // 3
        "Cherry Pop",       // 4
        "Red Jasper",       // 5
        "Scarlet Fire",     // 6
        "Sunset Glow",      // 7
        "Citrus Burst",     // 8
        // Golden tones.
        "Amber Glow",       // 9
        "Wild Honey",       // 10
        "Lemon Drop",       // 11
        "Solar Flare",      // 12
        "Neon Yellow",      // 13
        // Fresh tones.
        "Neon Lime",        // 14
        "Fresh Kiwi",       // 15
        "Clover Field",     // 16
        "Neon Green",       // 17
        // Cool tones.
        "Pine Grove",       // 18
        "Cool Sage",        // 19
        "Sea Foam",         // 20
        "Neon Cyan",        // 21
        // Ocean tones.
        "Aqua Wave",        // 22
        "Navy Blue",        // 23
        "Ocean Blue",       // 24
        "Azure Sky",        // 25
        "Royal Blue",       // 26
        // Mystic tones.
        "Irish Haze",       // 27
        "Indigo Dream",     // 28
        "Cosmic Purple",    // 29
    };

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile ThemeManager sInstance;

    /** Application context used for preference access. */
    @NonNull
    private final Context mContext;

    /** Current theme color value, as a hex string. */
    @NonNull
    private String mCurrentColor;

    /** Current theme index. */
    private int mCurrentColorIndex;

    /**
     * Constructs the singleton and reads the persisted theme into
     * memory.
     *
     * @param context A context; the application context is retained
     */
    private ThemeManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadTheme();
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static ThemeManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (ThemeManager.class) {
                if (sInstance == null) {
                    sInstance = new ThemeManager(context);
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Theme Loading and Saving
    // ========================================================================

    /**
     * Reads the persisted theme index into memory.
     *
     * <p>When the stored index is out of range, the default index is
     * used.</p>
     */
    private void loadTheme() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentColorIndex = preferences.getInt(KEY_THEME_INDEX, DEFAULT_THEME_INDEX);

        if (mCurrentColorIndex < 0 || mCurrentColorIndex >= COLOR_VALUES.length) {
            mCurrentColorIndex = DEFAULT_THEME_INDEX;
        }

        mCurrentColor = COLOR_VALUES[mCurrentColorIndex];
    }

    /**
     * Applies the theme at the given index and persists the selection.
     *
     * <p>An out-of-range index is ignored. An in-range index updates the
     * in-memory value before the preference write is scheduled.</p>
     *
     * @param colorIndex Index of the theme to apply
     */
    public void setThemeColor(int colorIndex) {
        if (colorIndex >= 0 && colorIndex < COLOR_VALUES.length) {
            mCurrentColorIndex = colorIndex;
            mCurrentColor = COLOR_VALUES[colorIndex];

            SharedPreferences.Editor editor = mContext.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE).edit();
            editor.putString(KEY_THEME_COLOR, mCurrentColor);
            editor.putInt(KEY_THEME_INDEX, mCurrentColorIndex);
            editor.apply();
        }
    }

    // ========================================================================
    // Getter Methods
    // ========================================================================

    /**
     * Returns the current theme color as a hex string.
     *
     * @return The current theme color, such as {@code "#B8A86E"}
     */
    @NonNull
    public String getCurrentColor() {
        return mCurrentColor;
    }

    /**
     * Returns the current theme color as an integer.
     *
     * <p>The stored value is expected to be a valid hex string. A
     * malformed value causes {@link Color#parseColor(String)} to throw
     * {@link IllegalArgumentException}.</p>
     *
     * @return The current theme color as an integer
     */
    public int getCurrentColorInt() {
        return Color.parseColor(mCurrentColor);
    }

    /**
     * Returns the current theme index.
     *
     * @return The index into the color arrays
     */
    public int getCurrentColorIndex() {
        return mCurrentColorIndex;
    }

    /**
     * Returns a copy of every theme display name.
     *
     * @return A new array containing every theme name
     */
    @NonNull
    public String[] getColorNames() {
        return COLOR_NAMES.clone();
    }

    /**
     * Returns a copy of every theme hex color value.
     *
     * @return A new array containing every theme color value
     */
    @NonNull
    public String[] getColorValues() {
        return COLOR_VALUES.clone();
    }

    // ========================================================================
    // Utility Methods
    // ========================================================================

    /**
     * Returns the number of available themes.
     *
     * @return The number of themes
     */
    public int getThemeCount() {
        return COLOR_VALUES.length;
    }

    /**
     * Returns whether the given theme index is within range.
     *
     * @param colorIndex Index to test
     * @return True when the index refers to an available theme
     */
    public boolean isValidColorIndex(int colorIndex) {
        return colorIndex >= 0 && colorIndex < COLOR_VALUES.length;
    }

    /**
     * Returns the display name of the theme at the given index.
     *
     * @param colorIndex Index of the theme
     * @return The theme name, or null when the index is out of range
     */
    @Nullable
    public String getColorName(int colorIndex) {
        if (isValidColorIndex(colorIndex)) {
            return COLOR_NAMES[colorIndex];
        }
        return null;
    }

    /**
     * Returns the hex color value of the theme at the given index.
     *
     * @param colorIndex Index of the theme
     * @return The theme color value, or null when the index is out of
     *         range
     */
    @Nullable
    public String getColorValue(int colorIndex) {
        if (isValidColorIndex(colorIndex)) {
            return COLOR_VALUES[colorIndex];
        }
        return null;
    }
}