// PlaylistActivity.java
package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Displays the playlist, supports search and sort, and tracks the
 * currently playing song.
 *
 * <p>The activity reads the current playlist from
 * {@link MusicService} and listens for {@code UPDATE_PLAYER}
 * broadcasts for playback state. Users can search the playlist,
 * cycle through ten sort modes, and tap a song to play it. The row
 * that corresponds to the currently playing song is highlighted,
 * and the list scrolls it into view when a transition moves it
 * offscreen.</p>
 *
 * <h3>State Ownership</h3>
 * <p>{@link MusicService} owns the authoritative playlist and the
 * current playing index. This activity owns the display list, the
 * current sort mode, the presentation hint that highlights the
 * current row, the scroll position, and the genre-loading flag
 * that suppresses refreshes while a genre load is in flight. The
 * persistent genre-loading overlay is owned by
 * {@link PlaylistManager}.</p>
 *
 * <h3>Sort Progress Feedback</h3>
 * <p>Cycling the sort mode shows the process-wide dim-and-spinner
 * overlay for the duration of the sort. A sort on a large library
 * is fast; without a floor, the overlay would flash and vanish
 * before the user perceived it.</p>
 *
 * <p>The overlay is not hidden on a timer. It is hidden only after
 * the RecyclerView has settled with the new data: the adapter has
 * been updated, the current song has been scrolled to its new
 * position, and the frame containing the settled list has been
 * drawn. The hide is scheduled from the list's next pre-draw
 * callback, which fires after the RecyclerView has committed the
 * new data to its layout and before the frame containing it is
 * drawn; the hide is then posted from inside the callback, which
 * defers removal of the overlay until after the frame that
 * contains the settled list has been committed. The overlay's
 * exit therefore reveals a list already in its final state, and
 * nothing further changes on screen.</p>
 *
 * <p>The focus scroll that centers the current song on its new row
 * is performed synchronously as part of the sort, not on the
 * delayed focus path the ordinary update flow uses. Doing it here
 * means the scroll and the sort land in the same frame, so the
 * settled state — new order, new scroll position — is what the
 * overlay's exit reveals.</p>
 *
 * <p>The {@link #SORT_OVERLAY_MIN_DURATION_MS} floor is applied on
 * top of the settle wait, so a fast sort never flashes the overlay
 * and a slow sort never holds it past the settled frame. The
 * reason token is released on every exit path from the sort,
 * including activity destruction.</p>
 *
 * <h3>Ordering</h3>
 * <p>Every {@code UPDATE_PLAYER} broadcast carries a monotonic
 * {@code generation}. The activity drops any broadcast with a
 * strictly lower generation than the highest it has seen. When the
 * service is rebound, the high-water mark resets to {@code -1},
 * because a new service instance restarts its counter at zero.</p>
 *
 * <h3>Edge Fast Scroll</h3>
 * <p>A vertical drag that starts inside the leftmost or rightmost
 * {@link #PLAYLIST_EDGE_SCROLL_DP} of the list scrolls the list
 * proportionally: a full viewport-height of finger travel maps to
 * {@link #FAST_SCROLL_FRACTION_PER_VIEWPORT} of the total
 * scrollable range, anchored at the position the drag began. A
 * drag that starts anywhere else is left to the RecyclerView's
 * own scroll handling.</p>
 *
 * <p>Fast scroll only engages when the content is at least
 * {@link #FAST_SCROLL_MIN_CONTENT_RATIO} times taller than the
 * viewport. On a shorter list the proportional mapping would be
 * too coarse for a user who is reading rows, and the edge zones
 * defer to ordinary scrolling.</p>
 *
 * <p>A tap is never consumed. The interceptor only takes over
 * once the finger has moved beyond the touch slop, so tapping a
 * song that happens to sit near an edge still plays it.</p>
 *
 * <h3>Library Reset</h3>
 * <p>When the library is reset, {@link PlaylistManager}'s reset
 * operation sends a {@code LIBRARY_RESET} broadcast that this
 * activity receives through its own receiver. The receiver clears
 * the display list and drops every piece of presentation state
 * that referred to a song that no longer exists, including the
 * genre-loading flag that a cancelled load would otherwise leave
 * set forever.</p>
 *
 * <h3>Language Application</h3>
 * <p>The activity wraps its base context through
 * {@link LanguageManager#wrap(Context)} in
 * {@link #attachBaseContext(Context)}, so every string it resolves
 * through {@code getString} is read from the resource folder that
 * matches the selected language from the moment the activity is
 * created. A {@code LANGUAGE_CHANGED} broadcast is answered with a
 * posted {@code recreate()}, which runs {@code attachBaseContext}
 * again with the new locale already persisted.</p>
 *
 * <h3>Theme Application</h3>
 * <p>A {@code THEME_COLOR_CHANGED} broadcast is answered with
 * {@code recreateWithConfiguration()}. The activity rebuilds against
 * the persisted color on the next turn. The search bar chrome, the
 * sort button, the row hearts, and the header labels are all rebuilt
 * from the new color; no view in this activity is repainted in
 * place.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>Nothing changes. The RecyclerView is the scroller; it
 * simply scrolls further as the window shrinks. Row density is a
 * list concern, not a window concern, and every touch target
 * keeps its declared size. When the list is empty, the
 * placeholder that occupies its slot is centred in that slot,
 * below the header bar.</p>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible label resolves from a string resource at the
 * point of the write. The top-bar title, the two empty-state
 * sentences, the two sort header labels, the ten sort bracket labels
 * and the ten sort toasts, the search-results header, and the song
 * count are each read from {@code R.string} or {@code R.plurals} in
 * the app's selected language. The sort display labels live in a
 * {@code @StringRes int[]} array indexed by the sort mode, so the
 * header and the toast pick the correct resource without a switch and
 * a translator who adds a language sees the new rendering on the next
 * cycle.</p>
 *
 * <p>The song count is resolved through the {@code song_count} plural,
 * so a language with more than two plural forms supplies the correct
 * one for the count the list holds. In search mode the count is
 * rendered as {@code visible / total} followed by the plural of the
 * total, so the plural agreement follows the number the label is
 * actually about.</p>
 *
 * <p>The playlist-load progress receiver constructs a {@link Song}
 * from the broadcast's raw extras and passes them through to the
 * constructor unchanged. When an extra is absent, the constructor
 * stores null and the corresponding getter resolves the app's
 * current placeholder at the moment the value is displayed. The
 * receiver does not supply fallback text of its own, so a German
 * playlist shows the German placeholder for a song whose title was
 * absent from the broadcast and an Arabic playlist shows the Arabic
 * one, without any code path in this file naming either.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistManager
 * @see OverlayManager
 * @see ThemeManager
 * @see ToastManager
 * @see LanguageManager
 * @see CharacterMapper
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.0.0
 */
public class PlaylistActivity extends Activity {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistActivity";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action that requests a playlist refresh. */
    private static final String ACTION_REFRESH_PLAYLIST =
        "REFRESH_PLAYLIST";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE =
        "UPDATE_SORT_MODE";

    /**
     * Broadcast action received when the display language changes.
     *
     * <p>Sent by {@link CreditsDialog} through its language picker.
     * Every activity registers a receiver for it and answers with
     * {@code recreate()}, so the wrapped base context is rebuilt with
     * the new locale on the next creation.</p>
     */
    private static final String ACTION_LANGUAGE_CHANGED =
        "LANGUAGE_CHANGED";

    /** Broadcast action carrying the full playback snapshot from the service. */
    private static final String ACTION_UPDATE_PLAYER = "UPDATE_PLAYER";

    /** Broadcast action asking the playlist activity to redraw. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";

    /** Broadcast action announcing that a song's metadata was written. */
    private static final String ACTION_METADATA_UPDATED = "METADATA_UPDATED";

    /** Broadcast action carrying genre-load lifecycle events. */
    private static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Broadcast action asking the player to refresh its metadata display. */
    private static final String ACTION_FORCE_UPDATE_PLAYER =
        "FORCE_UPDATE_PLAYER";

    /** Broadcast action asking the service to play the song at a given path. */
    private static final String ACTION_PLAY_SONG = "PLAY_SONG";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Delay before the initial focus scroll, in milliseconds. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500L;

    /** Duration of button press animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum length of the search field. */
    private static final int MAX_SEARCH_LENGTH = 128;

    /** Corner radius of the search bar, in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;

    /** Corner radius of the search input, in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;

    /** Stroke width of the search bar border, in density-independent
     *  pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;

    /** Padding of the empty-state container, in density-independent
     *  pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /**
     * Width of the fast-scroll touch zone from each side of the
     * playlist, in density-independent pixels.
     *
     * <p>The list row's own content padding is 16dp on each side;
     * the zone extends another 16dp inward from there, for a total
     * of 32dp. A vertical drag that starts inside one of these
     * zones scrolls the list proportionally to the library's total
     * height, so the end of the library is reachable in a bounded
     * number of gestures regardless of how many songs it holds.</p>
     */
    private static final int PLAYLIST_EDGE_SCROLL_DP = 32;

    /**
     * Fraction of the total scrollable range traversed by one
     * viewport-height of finger travel in an edge fast-scroll
     * zone.
     */
    private static final float FAST_SCROLL_FRACTION_PER_VIEWPORT = 0.05f;

    /**
     * Minimum content-to-viewport ratio at which fast scroll
     * engages.
     */
    private static final float FAST_SCROLL_MIN_CONTENT_RATIO = 3.0f;

    /**
     * Minimum time the sort overlay stays on screen, measured from
     * the moment the sort began, in milliseconds.
     *
     * <p>A sort on a large library is fast; without a floor the
     * overlay would flash and vanish before the user perceived it.
     * The floor is applied on top of the wait for the RecyclerView's
     * settled frame: the overlay disappears at whichever is longer,
     * the frame that paints the settled list or the floor measured
     * from the sort's start. The overlay therefore never exits before
     * the list is settled and never flashes on a small library.</p>
     */
    private static final long SORT_OVERLAY_MIN_DURATION_MS = 250L;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Total number of sort modes. */
    private static final int SORT_MODE_COUNT = 10;

    /**
     * Separator between the sort-mode prefix and the mode label.
     */
    private static final String SORT_MODE_LABEL_SEPARATOR = " ";

    /** Shared preferences key for the persisted sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /**
     * Resource identifiers for the sort labels shown after the
     * "SORT MODE" prefix in the header, indexed by sort mode.
     *
     * <p>The prefix itself is a {@code translatable="false"} resource
     * because the same two English words are used in every locale the
     * app ships; the label that follows it is localised. The space
     * between the two is supplied by
     * {@link #SORT_MODE_LABEL_SEPARATOR} at concatenation time.</p>
     */
    @StringRes
    private static final int[] SORT_LABEL_RES = {
        R.string.playlist_sort_label_title_az,
        R.string.playlist_sort_label_title_za,
        R.string.playlist_sort_label_artist_az,
        R.string.playlist_sort_label_artist_za,
        R.string.playlist_sort_label_album_az,
        R.string.playlist_sort_label_album_za,
        R.string.playlist_sort_label_genre_az,
        R.string.playlist_sort_label_genre_za,
        R.string.playlist_sort_label_oldest,
        R.string.playlist_sort_label_newest
    };

    /**
     * Resource identifiers for the sort transition messages shown
     * after cycling the sort mode, indexed by sort mode.
     */
    @StringRes
    private static final int[] SORT_TOAST_RES = {
        R.string.playlist_sort_toast_title_az,
        R.string.playlist_sort_toast_title_za,
        R.string.playlist_sort_toast_artist_az,
        R.string.playlist_sort_toast_artist_za,
        R.string.playlist_sort_toast_album_az,
        R.string.playlist_sort_toast_album_za,
        R.string.playlist_sort_toast_genre_az,
        R.string.playlist_sort_toast_genre_za,
        R.string.playlist_sort_toast_oldest,
        R.string.playlist_sort_toast_newest
    };

    /**
     * Stages favorite-flag changes made by the user until
     * {@link #onPause()} flushes them to the service.
     *
     * <p>The playlist row heart writes through this class. A tap
     * that is reversed before the activity pauses therefore produces
     * no database write at all; the last value staged for each path
     * wins. The map is intentionally small — a user taps a few rows
     * before pausing — and the flush is a single method call to
     * {@link MusicService#commitFavorites(java.util.Map)}.</p>
     */
    private static final class PendingFavorites {

        @NonNull
        private final java.util.HashMap<String, Boolean> mMap =
            new java.util.HashMap<>();

        /**
         * Stages a favorite flag for the given path.
         *
         * @param path Path of the song
         * @param favorite New value
         */
        void stage(@NonNull String path, boolean favorite) {
            mMap.put(path, favorite);
        }

        /**
         * Returns whether the map is empty.
         *
         * @return True when no changes are staged
         */
        boolean isEmpty() {
            return mMap.isEmpty();
        }

        /**
         * Returns a copy of the staged changes.
         *
         * @return A snapshot of the map
         */
        @NonNull
        java.util.Map<String, Boolean> snapshot() {
            return new java.util.HashMap<>(mMap);
        }

        /**
         * Clears every staged change.
         */
        void clear() {
            mMap.clear();
        }
    }

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Recycler view that displays the playlist rows. */
    private RecyclerView mPlaylistRecyclerView;

    /** Layout manager backing the recycler view. */
    private LinearLayoutManager mLayoutManager;

    /** Adapter backing the recycler view. */
    private PlaylistAdapter mAdapter;

    /** Text view showing the sort mode or search context. */
    private TextView mPlaylistTitle;

    /** Text view showing the song count. */
    private TextView mSongCountText;

    /** Text field for the search query. */
    private EditText mSearchText;

    /** Button that opens the search bar. */
    private Button mSearchButton;

    /** Button that clears the search query. */
    private Button mClearButton;

    /** Button that cycles the sort mode. */
    private Button mSortButton;

    /** Button that closes the activity or hides the search bar. */
    private Button mCancelButton;

    /** Container that hosts the search bar. */
    private LinearLayout mSearchBar;

    /** Container shown when the playlist is empty. */
    private LinearLayout mEmptyContainer;

    /** Root frame layout that hosts the empty state. */
    private FrameLayout mRootContainer;

    // ============================================================================
    // Data Components
    // ============================================================================

    /** Songs currently displayed, after search and sort. */
    private ArrayList<Song> mCurrentDisplayList;

    /** Path of the song currently highlighted as playing, or null. */
    @Nullable private String mCurrentPlayingPath = null;

    /** True while the search bar is visible. */
    private boolean mIsSearchVisible = false;

    /** Input method manager used to show and hide the keyboard. */
    private InputMethodManager mInputMethodManager;

    /**
     * Changes to favorite flags staged by the user since the last
     * pause. Flushed to {@link MusicService} in {@link #onPause()}
     * and cleared afterward.
     */
    @NonNull private final PendingFavorites mPendingFavorites =
        new PendingFavorites();

    // ============================================================================
    // Scroll State Management
    // ============================================================================

    /** True while the user is dragging or flinging the list. */
    private volatile boolean mUserScrolling = false;

    /** Saved scroll position, restored after list updates. */
    @Nullable private Parcelable mSavedScrollState = null;

    /** True while a saved scroll position is waiting to be
     *  restored. */
    private boolean mScrollRestorePending = false;

    // ============================================================================
    // Theme Components
    // ============================================================================

    /** Manager for the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper for applying theme colors to UI components. */
    private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    /** Receiver for language change broadcasts. */
    @Nullable private BroadcastReceiver mLanguageChangedReceiver;

    // ============================================================================
    // Sort Components
    // ============================================================================

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** Timestamp of the last sort button click. */
    private long mLastSortClickTime = 0L;

    /** True when a sort should be applied once genre loading
     *  completes. */
    private boolean mPendingSortAfterGenre = false;

    /**
     * Pending hide runnable for the sort overlay, or null when no
     * sort is in flight. Stored so a subsequent cycle can cancel
     * the previous hide before scheduling its own.
     */
    @Nullable private Runnable mSortOverlayHideRunnable = null;

    /**
     * Generation of the sort cycle.
     *
     * <p>Advanced by every {@link #cycleSortMode()} call. The hide
     * callback that runs after the RecyclerView has settled checks
     * this value against the generation its cycle was started with,
     * so a superseded cycle cannot take the overlay down on the
     * current cycle's behalf.</p>
     */
    private long mSortGeneration = 0L;

    // ============================================================================
    // Interaction State
    // ============================================================================

    /** Timestamp of the last search button click. */
    private long mLastSearchClickTime = 0L;

    /** Timestamp of the last cancel button click. */
    private long mLastCancelClickTime = 0L;

    /** True while a tap is being processed. */
    private volatile boolean mUserInteractionInProgress = false;

    /** True while genre loading is in flight. */
    private volatile boolean mIsGenreLoading = false;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // Generation Gate and Deferred Focus
    // ============================================================================

    /** Highest generation seen in an {@code UPDATE_PLAYER}
     *  broadcast. */
    private long mLastSeenGeneration = -1L;

    /** Row waiting for focus once genre loading completes, or -1. */
    private int mDeferredGenreFocusRow = -1;

    // ============================================================================
    // Service Connection
    // ============================================================================

    /** Bound service, or null while not bound. */
    @Nullable private MusicService mMusicService;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** Connection that resets the generation gate on every
     *  (re)connect. */
    private final ServiceConnection mServiceConnection =
        new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mLastSeenGeneration = -1L;
            refreshPlaylistFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    /** Receiver for {@code UPDATE_PLAYER} broadcasts. */
    private BroadcastReceiver mUpdatePlayerReceiver;

    /** Receiver for {@code DISPLAY_PLAYLIST} broadcasts. */
    private BroadcastReceiver mDisplayPlaylistReceiver;

    /** Receiver for {@code METADATA_UPDATED} broadcasts. */
    private BroadcastReceiver mMetadataUpdatedReceiver;

    /** Receiver for playlist load progress broadcasts. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;

    /** Receiver for {@code GENRE_UPDATE} broadcasts. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for {@code REFRESH_PLAYLIST} broadcasts. */
    private BroadcastReceiver mRefreshPlaylistReceiver;

    /** Receiver for {@code LIBRARY_RESET} broadcasts emitted by
     *  {@link PlaylistManager}. */
    private BroadcastReceiver mLibraryResetReceiver;

    // ============================================================================
    // Language Application
    // ============================================================================

    /**
     * Wraps the base context with the currently selected locale.
     *
     * <p>The wrap is performed before any activity state is created,
     * so every string resolved through {@code getString} during the
     * activity's lifetime is read from the resource folder that
     * matches the selected language. Changing the selection recreates
     * the activity, at which point this method runs again with the
     * new locale already persisted.</p>
     *
     * @param newBase Base context supplied by the framework
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase));
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, its view hierarchy, its receivers,
     * and the service binding.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);
        OverlayManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager =
            (InputMethodManager) getSystemService(
                Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();
        setupEdgeFastScroll();

        registerReceivers();
        registerGenreUpdateReceiver();
        registerRefreshPlaylistReceiver();
        registerLibraryResetReceiver();
        registerLanguageReceiver();

        bindService(new Intent(this, MusicService.class),
            mServiceConnection, BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the list from the service, focuses the current song, and
     * reapplies the theme.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        refreshPlaylistFromService();

        if (mAdapter != null) {
            int currentPosition =
                findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null
                        || TextUtils.isEmpty(
                            mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading
                            && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100L);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver and flushes any pending
     * favorite changes to the service.
     *
     * <p>The flush runs before the activity loses focus so a change
     * staged since the last commit is persisted even when the user
     * has swiped the app away. The snapshot is passed by value; the
     * local map is cleared immediately so a rapid foreground-return
     * cycle does not double-commit.</p>
     */
    @Override
    protected void onPause() {
        super.onPause();

        if (!mPendingFavorites.isEmpty() && mMusicService != null) {
            mMusicService.commitFavorites(mPendingFavorites.snapshot());
            mPendingFavorites.clear();
        }

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister theme receiver", exception);
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Unbinds from the service, unregisters every receiver, and
     * removes every handler callback.
     *
     * <p>Releases the sort overlay reason if a sort was still in
     * flight. The overlay itself is owned by the process, so
     * releasing the reason here does not affect any other overlay
     * a different caller may be showing.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
        OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT);

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unbind from MusicService", exception);
            }
            mIsServiceBound = false;
        }

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister theme receiver", exception);
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mRefreshPlaylistReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);
        unregisterReceiverSafely(mLanguageChangedReceiver);

        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Reapplies immersive mode when the window gains focus and
     * reattaches any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Hides the search bar when it is visible, or returns to the
     * music player otherwise.
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ============================================================================
    // Navigation
    // ============================================================================

    /**
     * Returns to the music player activity with the slide-left
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ============================================================================
    // Edge Fast Scroll
    // ============================================================================

    /**
     * Attaches the shared edge fast-scroll interceptor to the
     * playlist's RecyclerView.
     *
     * <p>The behavior — 32dp edge zones, 5% of the total scroll
     * range per viewport-height of finger travel, engagement only
     * when content is at least 3× the viewport — lives in
     * {@link EdgeScrollHelper}. The playlist and the playback
     * scope dialog share that implementation so a change to the
     * edge width or scroll rate takes effect on both surfaces at
     * once.</p>
     */
    private void setupEdgeFastScroll() {
        if (mPlaylistRecyclerView == null) {
            return;
        }

        EdgeScrollHelper.attach(mPlaylistRecyclerView);
    }

    // ============================================================================
    // Scroll Listener
    // ============================================================================

    /**
     * Attaches the scroll listener that tracks the user's
     * scrolling state, saves the scroll position when the user is
     * not actively scrolling, and relays the scrolling state to
     * the adapter.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(
            new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(
                    @NonNull RecyclerView recyclerView, int newState) {
                boolean scrolling =
                    (newState != RecyclerView.SCROLL_STATE_IDLE);
                mUserScrolling = scrolling;
                if (mAdapter != null) {
                    mAdapter.setScrolling(scrolling);
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView,
                                   int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState =
                        mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    /**
     * Saves the current scroll position so it can be restored
     * after the next list update.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    /**
     * Restores the saved scroll position when one is pending.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null
                && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(
                    mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to restore scroll position", exception);
                mScrollRestorePending = false;
            }
        }
    }

    /**
     * Returns whether the given row is currently offscreen.
     *
     * @param row Row to test
     * @return True when the row is outside the visible range
     */
    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) {
            return false;
        }
        if (row < 0 || row >= mCurrentDisplayList.size()) {
            return false;
        }
        int firstVisibleRow =
            mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastVisibleRow =
            mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (firstVisibleRow == RecyclerView.NO_POSITION
                || lastVisibleRow == RecyclerView.NO_POSITION) {
            return false;
        }
        return row < firstVisibleRow || row > lastVisibleRow;
    }

    /**
     * Scrolls the given row into the vertical center of the list
     * when it is offscreen.
     *
     * @param row Row to scroll into view
     */
    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) {
            return;
        }
        if (!shouldAutoScrollTo(row)) {
            return;
        }
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                mLayoutManager.scrollToPositionWithOffset(
                    finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    /**
     * Applies the row stored in {@link #mDeferredGenreFocusRow} as
     * the scroll target and clears the deferred value.
     */
    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) {
            return;
        }
        int deferredRow = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(deferredRow);
    }

    // ============================================================================
    // Refresh
    // ============================================================================

    /**
     * Rebuilds the display list from the service's current
     * playlist.
     *
     * <p>When the service reports an empty playlist, the
     * empty-state message distinguishes an empty scope from an
     * empty library: a non-{@code ALL_SONGS} scope that returns no songs
     * shows the scope message, and the {@code ALL_SONGS} scope with no
     * songs shows the library message. Both messages occupy the
     * same slot; only the copy differs.</p>
     */
    private void refreshPlaylistFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist =
            mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            mCurrentPlayingPath = null;
            mDeferredGenreFocusRow = -1;
            PlaybackScope scope = mMusicService.getPlaybackScope();
            boolean scopeRestricts = scope.kind
                != PlaybackScope.Kind.ALL_SONGS;
            showEmptyView(scopeRestricts
                ? R.string.playlist_empty_scope
                : R.string.playlist_empty_state);
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
                mAdapter.setCurrentPlayingPath(null);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100L);
    }

    // ============================================================================
    // Sort
    // ============================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode =
            preferences.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit()
            .putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    /**
     * Advances to the next sort mode, persists it, broadcasts the
     * change, and re-sorts the display list on a background thread.
     *
     * <p>The process-wide dim-and-spinner overlay is shown for the
     * duration of the sort, so the user receives visual feedback on
     * the operation.</p>
     *
     * <p>When the background sort completes, the main thread updates
     * the adapter and immediately performs the focus scroll to the
     * current song's new position. Performing the scroll here — in
     * the same turn as the adapter update, rather than on the
     * delayed focus path — means the new order and the new scroll
     * position land in the same RecyclerView layout pass. The overlay
     * is then hidden only after that settled frame has been drawn,
     * so the frame the overlay last appears over already contains the
     * final list, and the frame after the overlay disappears contains
     * the exact same list. Nothing changes on screen when the overlay
     * exits.</p>
     *
     * <p>Each cycle advances {@link #mSortGeneration} so a superseded
     * cycle's settle callback cannot take the overlay down on the
     * current cycle's behalf.</p>
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);

        final ArrayList<Song> listToSort =
            new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int sortMode = mCurrentSortMode;
        final long sortStartedElapsed = SystemClock.elapsedRealtime();
        final long thisSortGeneration = ++mSortGeneration;

        OverlayManager.show(OverlayManager.REASON_PLAYLIST_SORT);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort,
                    getComparatorForSortMode(sortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            cancelSortOverlayHide();
                            OverlayManager.hide(
                                OverlayManager.REASON_PLAYLIST_SORT);
                            return;
                        }

                        if (thisSortGeneration != mSortGeneration) {
                            // A newer cycle has superseded this one;
                            // the newer cycle owns the overlay now.
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList, true);
                        }

                        if (currentPath != null) {
                            int newPosition =
                                findPositionByPath(currentPath);
                            if (newPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                if (mAdapter != null) {
                                    mAdapter.setCurrentPlayingIndex(
                                        newPosition);
                                }
                            }
                        }

                        // Synchronously scroll to the current song's
                        // new position before the overlay hides, so
                        // the sorted order and the settled scroll
                        // position land in the same RecyclerView
                        // layout pass.
                        scrollToCurrentSongImmediately();

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(
                            PlaylistActivity.this,
                            getString(SORT_TOAST_RES[mCurrentSortMode]),
                            ToastManager.LENGTH_NORMAL);

                        hideSortOverlayAfterListSettles(
                            thisSortGeneration, sortStartedElapsed);
                    }
                });
            }
        }).start();
    }

    /**
     * Cancels any pending sort-overlay hide. Idempotent.
     */
    private void cancelSortOverlayHide() {
        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
    }

    /**
     * Scrolls the RecyclerView to the current song's new position
     * synchronously, without the delayed focus path.
     *
     * <p>Used by the sort flow so the sorted order and the settled
     * scroll position land in the same RecyclerView layout pass.
     * {@link LinearLayoutManager#scrollToPositionWithOffset(int, int)}
     * is a jump, not an animated scroll, so it schedules a single
     * layout for the next frame and no scroll animation follows. The
     * delayed {@link #focusCurrentSong()} path is not used here
     * because it would scroll after the overlay has already
     * hidden.</p>
     *
     * <p>No-op when the RecyclerView is not laid out, the current
     * path is unknown, the current path is not in the display list,
     * or the user is already interacting with the list.</p>
     */
    private void scrollToCurrentSongImmediately() {
        if (mPlaylistRecyclerView == null || mLayoutManager == null
                || mCurrentPlayingPath == null
                || mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mUserScrolling || mIsGenreLoading
                || mUserInteractionInProgress) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null
                    && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }
        if (targetPosition < 0) {
            return;
        }

        mLayoutManager.scrollToPositionWithOffset(
            targetPosition, mPlaylistRecyclerView.getHeight() / 2);
    }

    /**
     * Schedules the sort overlay's hide for the moment the
     * RecyclerView has settled with the sorted list.
     *
     * <p>The pre-draw callback fires after the RecyclerView's layout
     * for the new data — including the synchronous focus scroll
     * performed by {@link #scrollToCurrentSongImmediately()} — is
     * complete and before the frame is drawn. The hide is then posted
     * from inside that callback, which defers removal of the overlay
     * until after the frame that contains the settled list has been
     * committed. The overlay's exit therefore reveals a list already
     * in its final state — sorted, scrolled, drawn — and nothing
     * further changes on screen.</p>
     *
     * <p>The {@link #SORT_OVERLAY_MIN_DURATION_MS} floor is applied
     * on top of the settle wait. If the sort is faster than the
     * floor, the overlay waits out the remainder after the frame has
     * been drawn; if the sort is slower, the overlay hides as soon as
     * the frame is committed.</p>
     *
     * <p>The sort generation is checked before the hide is scheduled.
     * A newer cycle that began before this one's draw callback fired
     * owns the overlay now, and this cycle must not hide it on the
     * newer cycle's behalf.</p>
     *
     * @param sortGeneration Generation of the cycle this callback
     *        serves
     * @param sortStartedElapsed Uptime at which the cycle began
     */
    private void hideSortOverlayAfterListSettles(
            final long sortGeneration,
            final long sortStartedElapsed) {
        if (mPlaylistRecyclerView == null) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        final ViewTreeObserver observer =
            mPlaylistRecyclerView.getViewTreeObserver();
        if (!observer.isAlive()) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        observer.addOnPreDrawListener(
            new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                final ViewTreeObserver current =
                    mPlaylistRecyclerView.getViewTreeObserver();
                if (current.isAlive()) {
                    current.removeOnPreDrawListener(this);
                }
                // The layout for the settled list has completed.
                // Post the hide so the frame containing that layout
                // is committed first; the overlay then disappears on
                // the frame after, revealing the same content.
                mPlaylistRecyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (sortGeneration != mSortGeneration) {
                            return;
                        }
                        scheduleSortOverlayHideAtMinDuration(
                            sortStartedElapsed);
                    }
                });
                return true;
            }
        });
    }

    /**
     * Schedules the sort overlay's hide for the end of the
     * {@link #SORT_OVERLAY_MIN_DURATION_MS} floor, measured from
     * the moment the sort began.
     *
     * @param sortStartedElapsed Uptime at which the sort began
     */
    private void scheduleSortOverlayHideAtMinDuration(
            final long sortStartedElapsed) {
        final long elapsed = SystemClock.elapsedRealtime()
            - sortStartedElapsed;
        final long remaining = Math.max(0L,
            SORT_OVERLAY_MIN_DURATION_MS - elapsed);
        scheduleSortOverlayHide(remaining);
    }

    /**
     * Schedules the sort overlay's hide after the given delay.
     *
     * <p>Cancels any previously-scheduled hide first, so a rapid
     * sequence of sort cycles produces one hide at the end of the
     * sequence rather than one per cycle.</p>
     *
     * @param delayMs Delay in milliseconds; 0 hides on the next
     *        main-thread turn
     */
    private void scheduleSortOverlayHide(long delayMs) {
        cancelSortOverlayHide();
        mSortOverlayHideRunnable = new Runnable() {
            @Override
            public void run() {
                mSortOverlayHideRunnable = null;
                OverlayManager.hide(
                    OverlayManager.REASON_PLAYLIST_SORT);
            }
        };
        mMainHandler.postDelayed(mSortOverlayHideRunnable, delayMs);
    }

    /**
     * Sorts the display list in place by the current sort mode.
     *
     * @param showToast True to broadcast the sort change and show a
     *        toast
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList,
            getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling
                                        && !mIsGenreLoading
                                        && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this,
                getString(SORT_TOAST_RES[mCurrentSortMode]),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Returns the index of the song with the given path in the
     * display list, or -1 when it is not present.
     *
     * @param path Path to search for
     * @return The display-list index, or -1
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch,
     *         or 0 when the song or its path is null
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0L;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the
     * given sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(
            final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return firstSong.getTitle()
                            .compareToIgnoreCase(
                                secondSong.getTitle());
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return secondSong.getTitle()
                            .compareToIgnoreCase(
                                firstSong.getTitle());
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getArtist()
                            .compareToIgnoreCase(
                                secondSong.getArtist());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getArtist()
                            .compareToIgnoreCase(
                                firstSong.getArtist());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getAlbum()
                            .compareToIgnoreCase(
                                secondSong.getAlbum());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getAlbum()
                            .compareToIgnoreCase(
                                firstSong.getAlbum());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getGenre()
                            .compareToIgnoreCase(
                                secondSong.getGenre());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getGenre()
                            .compareToIgnoreCase(
                                firstSong.getGenre());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            firstDate, secondDate);
                        if (comparisonResult == 0L) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            secondDate, firstDate);
                        if (comparisonResult == 0L) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return firstSong.getTitle()
                            .compareToIgnoreCase(
                                secondSong.getTitle());
                    }
                };
        }
    }

    /**
     * Updates the header to show the current sort mode or search
     * context, and toggles the sort button visibility.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText(
                getString(R.string.playlist_sort_mode_prefix)
                    + SORT_MODE_LABEL_SEPARATOR
                    + getString(SORT_LABEL_RES[mCurrentSortMode]));
            if (mSortButton != null
                    && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText(R.string.playlist_search_results);
            if (mSortButton != null
                    && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ============================================================================
    // Display
    // ============================================================================

    /**
     * Shows the empty-state placeholder in the slot the playlist
     * occupies.
     *
     * @param messageRes String resource identifier for the message;
     *        a scope-empty state passes
     *        {@code R.string.playlist_empty_scope}, a library-empty
     *        state passes {@code R.string.playlist_empty_state}
     */
    private void showEmptyView(@StringRes int messageRes) {
        if (mEmptyContainer != null) {
            final ViewParent existingParent = mEmptyContainer.getParent();
            if (existingParent instanceof ViewGroup) {
                ((ViewGroup) existingParent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText(messageRes);
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mPlaylistRecyclerView != null) {
            final ViewParent parent = mPlaylistRecyclerView.getParent();
            if (parent instanceof LinearLayout) {
                final LinearLayout parentLayout =
                    (LinearLayout) parent;
                final LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0, 1f);
                parentLayout.addView(mEmptyContainer, params);
            }
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    /**
     * Removes the empty-state placeholder and shows the playlist.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent parent = mEmptyContainer.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Creates the playlist adapter and attaches it to the
     * recycler view.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList,
            new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(
                    PlaylistActivity.this, MusicService.class);
                intent.setAction(ACTION_PLAY_SONG);
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition =
                                    findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(
                                    newPosition);
                            }
                        } catch (Exception exception) {
                            Log.e(TAG,
                                "Error setting playing index",
                                exception);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        mAdapter.setFavoriteListener((path, favorite) ->
            mPendingFavorites.stage(path, favorite));

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Updates the header and song count text from the current
     * search and display state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText(
                    getString(R.string.playlist_sort_mode_prefix)
                        + SORT_MODE_LABEL_SEPARATOR
                        + getString(SORT_LABEL_RES[mCurrentSortMode]));
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(
                    getResources().getQuantityString(
                        R.plurals.song_count,
                        songCount,
                        songCount));
            }
        } else {
            int totalSongs = (mMusicService != null
                && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText(R.string.playlist_search_results);
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(
                    songCount + " / "
                    + getResources().getQuantityString(
                        R.plurals.song_count,
                        totalSongs,
                        totalSongs));
            }
        }
    }

    /**
     * Reads the persisted last playing path into memory.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath =
            preferences.getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Returns the song path a {@code METADATA_UPDATED} broadcast
     * refers to.
     *
     * <p>The broadcast may carry the path directly when the
     * editor knows it. When the editor only knows the URI — a
     * SAF-only write where the content provider does not expose
     * a filesystem path — the path is resolved against the song
     * database by URI match. Both forms name the same song; the
     * resolution keeps consumers that key by path working on
     * paths.</p>
     *
     * @param intent The broadcast intent
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(@NonNull Intent intent) {
        final String path = intent.getStringExtra("song_path");
        if (path != null && !path.isEmpty()) {
            return path;
        }
        final String uriString =
            intent.getStringExtra("song_uri");
        if (uriString == null || uriString.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && uriString.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }

    /**
     * Scrolls the current song into the vertical center of the
     * list when it is offscreen and the user is not interacting
     * with the list.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG,
                "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null
                || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null
                    && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisibleRow =
                        mLayoutManager
                            .findFirstCompletelyVisibleItemPosition();
                    int lastVisibleRow =
                        mLayoutManager
                            .findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisibleRow
                            || finalPosition > lastVisibleRow) {
                        mLayoutManager.scrollToPositionWithOffset(
                            finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization
    // ============================================================================

    /**
     * Resolves every view, attaches touch animations and click
     * handlers, and creates the adapter.
     */
    private void initializeViews() {
        mPlaylistRecyclerView =
            (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        if (mSearchText != null) {
            mSearchText.setFilters(
                new android.text.InputFilter[] {
                    new android.text.InputFilter.LengthFilter(
                        MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Search
    // ============================================================================

    /**
     * Attaches the search text watcher, the editor action
     * listener, and the clear button handler.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    performSearch(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            mSearchText.setOnEditorActionListener(
                new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView view,
                                              int actionId,
                                              KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH
                            || actionId == EditorInfo.IME_ACTION_DONE
                            || (event != null
                                && event.getKeyCode()
                                    == KeyEvent.KEYCODE_ENTER
                                && event.getAction()
                                    == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager inputMethodManager =
                            (InputMethodManager) getSystemService(
                                Context.INPUT_METHOD_SERVICE);
                        if (inputMethodManager != null
                                && mSearchText != null) {
                            inputMethodManager
                                .hideSoftInputFromWindow(
                                    mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    /**
     * Filters the service's current playlist by the given query
     * and writes the result into the display list.
     *
     * @param query The search text; an empty or whitespace-only
     *        query matches every song
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs =
            mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase()
                                .contains(lowerQuery))
                            || (artist != null && artist.toLowerCase()
                                .contains(lowerQuery))
                            || (album != null && album.toLowerCase()
                                .contains(lowerQuery))
                            || (genre != null && genre.toLowerCase()
                                .contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    /**
     * Shows the search bar and requests focus on the search
     * field.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(
                    mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    /**
     * Hides the search bar, clears the query, and refreshes the
     * display list.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(
                    mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");
    }

    // ============================================================================
    // Theme
    // ============================================================================

    /**
     * Registers the receiver for theme color change broadcasts.
     *
     * <p>The receiver answers the broadcast by recreating the
     * activity, so the theme is applied to freshly constructed
     * views on the next creation. No view is repainted in place.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ThemeManager.ACTION_THEME_COLOR_CHANGED
                        .equals(intent.getAction())) {
                    return;
                }
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                recreateWithConfiguration();
            }
        };

        IntentFilter filter = new IntentFilter(
            ThemeManager.ACTION_THEME_COLOR_CHANGED);
        registerReceiverSafely(mThemeReceiver, filter);
    }

    /**
     * Registers the receiver for language change broadcasts.
     *
     * <p>A locale change requires the activity to be recreated so
     * the wrapped base context takes effect. The recreate is posted
     * from the receiver, so the broadcast delivery pass completes
     * before this activity begins its recreation.</p>
     */
    private void registerLanguageReceiver() {
        mLanguageChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_LANGUAGE_CHANGED.equals(
                            intent.getAction())) {
                    return;
                }
                if (!isFinishing() && !isDestroyed()) {
                    recreateWithConfiguration();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_LANGUAGE_CHANGED);
        registerReceiverSafely(mLanguageChangedReceiver, filter);
    }

    /**
     * Registers the receiver for genre update broadcasts.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_GENRE_UPDATE.equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");

                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG,
                            "Genre loading started for " + total
                                + " songs");
                        mIsGenreLoading = true;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }

                    } else if ("UPDATE".equals(status)) {
                        String songPath =
                            intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");

                        if (mAdapter != null && songPath != null
                                && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }

                    } else if ("COMPLETE".equals(status)) {
                        int loaded =
                            intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: "
                            + loaded + " genres loaded");

                        mIsGenreLoading = false;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }

                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }

                        Intent refreshMetadataIntent =
                            new Intent(ACTION_FORCE_UPDATE_PLAYER);
                        refreshMetadataIntent.putExtra(
                            "refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);

                        applyDeferredGenreFocus();
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_GENRE_UPDATE);
        registerReceiverSafely(mGenreUpdateReceiver, filter);
    }

    /**
     * Registers the receiver for playlist refresh broadcasts.
     */
    private void registerRefreshPlaylistReceiver() {
        mRefreshPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_REFRESH_PLAYLIST.equals(
                        intent.getAction())) {
                    Log.d(TAG, "Refresh playlist received - refreshing "
                        + "playlist from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshPlaylistFromService();
                            } else {
                                Log.d(TAG, "Refresh playlist suppressed "
                                    + "during genre loading");
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_REFRESH_PLAYLIST);
        registerReceiverSafely(mRefreshPlaylistReceiver, filter);
    }

    /**
     * Registers the receiver for library reset broadcasts emitted
     * by {@link PlaylistManager}.
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(
                            intent.getAction())) {
                    return;
                }

                Log.d(TAG,
                    "LIBRARY_RESET received — clearing display list");

                mCurrentDisplayList.clear();
                mCurrentPlayingPath = null;
                mDeferredGenreFocusRow = -1;
                mLastSeenGeneration = -1L;

                mIsGenreLoading = false;
                mPendingSortAfterGenre = false;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }
                        showEmptyView(R.string.playlist_empty_state);
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                            mAdapter.setCurrentPlayingPath(null);
                        }
                        updateTitleAndCount();
                    }
                });
            }
        };

        IntentFilter filter = new IntentFilter(
            PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(mLibraryResetReceiver, filter);
    }

    /**
     * Applies the header text color to every header TextView in
     * the activity.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews
     * in the given view hierarchy whose text names the playlist.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        final String playlistTitleText =
            getString(R.string.playlist_title);

        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView
                    && !(child instanceof Button)
                    && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                if (playlistTitleText.equals(
                        textView.getText().toString())) {
                    textView.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the current theme color to every control in the
     * activity and to the search bar background.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(
                mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(
                mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(
                mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(
                mSortButton, mSortButton.isEnabled());
        }

        if (mSearchBar != null) {
            GradientDrawable searchBarBorder =
                new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(
                dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(
                dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground =
                new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(
                dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAdapter != null && mAdapter.getItemCount() > 0) {
            // A theme change retints every visible heart. Rebinding
            // the whole visible range is cheaper than walking the
            // list to find each heart and tint it individually.
            mAdapter.notifyItemRangeChanged(0, mAdapter.getItemCount());
        }
        forceRedraw();
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_UPDATE_PLAYER.equals(
                            intent.getAction())) {
                    return;
                }

                long generation =
                    intent.getLongExtra("generation", -1L);
                boolean generationAdvanced;
                if (generation >= 0L) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    generationAdvanced =
                        (generation > mLastSeenGeneration);
                    if (generationAdvanced) {
                        mLastSeenGeneration = generation;
                    }
                } else {
                    generationAdvanced = false;
                }

                final String songPath =
                    intent.getStringExtra("song_path");
                if (songPath == null) {
                    return;
                }

                mCurrentPlayingPath = songPath;
                if (mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition < 0) {
                    return;
                }

                mAdapter.setCurrentPlayingIndex(displayPosition);

                if (!generationAdvanced) {
                    return;
                }
                if (!shouldAutoScrollTo(displayPosition)) {
                    return;
                }

                if (mIsGenreLoading) {
                    mDeferredGenreFocusRow = displayPosition;
                } else if (!mUserScrolling
                        && !mUserInteractionInProgress) {
                    scrollToRowIfOffscreen(displayPosition);
                }
            }
        };

        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && ACTION_DISPLAY_PLAYLIST.equals(
                            intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshPlaylistFromService();
                            }
                        }
                    });
                }
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !ACTION_METADATA_UPDATED.equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    resolveBroadcastSongPath(intent);
                if (songPath == null || mAdapter == null) {
                    return;
                }

                final int displayPosition =
                    findPositionByPath(songPath);
                if (displayPosition >= 0) {
                    final Song existing =
                        mCurrentDisplayList.get(displayPosition);
                    if (existing != null) {
                        final String title =
                            intent.getStringExtra("title");
                        final String artist =
                            intent.getStringExtra("artist");
                        final String album =
                            intent.getStringExtra("album");
                        final String genre =
                            intent.getStringExtra("genre");
                        final String uriString =
                            intent.getStringExtra("song_uri");

                        final Song updated = new Song(
                            title != null ? title : null,
                            artist != null ? artist : null,
                            album != null ? album : null,
                            genre != null ? genre : null,
                            songPath,
                            existing.getDuration(),
                            uriString != null
                                ? uriString
                                : existing.getUri());
                        mCurrentDisplayList.set(
                            displayPosition, updated);
                        mAdapter.notifyItemChanged(
                            displayPosition);
                    }
                }

                if (songPath.equals(mCurrentPlayingPath)) {
                    mCurrentPlayingPath = songPath;
                    mAdapter.setCurrentPlayingIndex(
                        displayPosition);
                }
            }
        };

        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(
                        intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }

                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null
                                && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists && !mIsGenreLoading
                            && !mUserScrolling) {
                        String title =
                            intent.getStringExtra("song_title");
                        String artist =
                            intent.getStringExtra("song_artist");
                        String album =
                            intent.getStringExtra("song_album");
                        String genre =
                            intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra(
                            "song_duration", 0L);

                        Song newSong = new Song(
                            title, artist, album, genre,
                            path, duration, null);

                        mCurrentDisplayList.add(newSong);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }

                        updateTitleAndCount();
                    }
                }
            }
        };

        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction(ACTION_UPDATE_PLAYER);
        registerReceiverSafely(mUpdatePlayerReceiver, playerFilter);

        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction(ACTION_DISPLAY_PLAYLIST);
        registerReceiverSafely(mDisplayPlaylistReceiver, displayFilter);

        IntentFilter metadataFilter = new IntentFilter();
        metadataFilter.addAction(ACTION_METADATA_UPDATED);
        registerReceiverSafely(
            mMetadataUpdatedReceiver, metadataFilter);

        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(
            MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiverSafely(
            mPlaylistLoadProgressReceiver, progressFilter);
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver", exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception
     * raised by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister receiver", exception);
            }
        }
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Forces the activity content to re-measure, re-layout, and re-draw.
     */
    private void forceRedraw() {
        View root = findViewById(android.R.id.content);
        if (root == null) {
            return;
        }
        root.requestLayout();
        root.invalidate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation();
        }
    }

    /**
     * Recreates the activity after refreshing the Resources configuration.
     */
    private void recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            getResources().updateConfiguration(
                getResources().getConfiguration(),
                getResources().getDisplayMetrics());
        }
        recreate();
        overridePendingTransition(0, 0);
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(
            getResources().getDisplayMetrics().density * dp);
    }
}