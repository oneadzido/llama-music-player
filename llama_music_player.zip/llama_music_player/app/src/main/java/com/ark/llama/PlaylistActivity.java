package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Activity for displaying and managing the current playlist.
 * 
 * <p>This activity provides a comprehensive playlist management interface that allows
 * users to view, search, sort, and interact with their music library. The activity
 * maintains a binding to MusicService to receive real-time updates about playback
 * state and playlist changes.</p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The PlaylistActivity follows a "source of truth" pattern where all playlist data
 * is obtained from the bound MusicService instance. This ensures consistency between
 * what the user sees and what is actually playing. The activity does not maintain its
 * own copy of the playlist; instead, it refreshes from the service whenever updates
 * occur via broadcast receivers.</p>
 * 
 * <p>The activity uses a two-phase approach for metadata loading. Phase 1 performs a
 * fast scan using MediaStore to display songs immediately with "Unknown Genre" placeholders.
 * Phase 2 runs in the background, reading ID3 tags to extract real genres, updating the
 * UI progressively as each song's genre becomes available.</p>
 * 
 * <h3>RecyclerView Best Practices</h3>
 * <p>This activity implements several Android RecyclerView best practices to ensure
 * smooth scrolling and a responsive user interface:</p>
 * 
 * <ul>
 *   <li><b>Stable IDs:</b> The PlaylistAdapter uses setHasStableIds(true) with song
 *       paths as stable identifiers, allowing RecyclerView to track items correctly
 *       across updates and maintain proper animation state.</li>
 *   <li><b>DiffUtil for List Updates:</b> Instead of calling notifyDataSetChanged(),
 *       the adapter uses DiffUtil to calculate minimal changes between old and new
 *       lists, resulting in smooth animations and better performance.</li>
 *   <li><b>Payload-Based Partial Updates:</b> Genre updates use notifyItemChanged()
 *       with a PAYLOAD_GENRE payload, which updates only the subtitle TextView
 *       without causing a full item rebind or layout re-measurement.</li>
 *   <li><b>Scroll State Tracking:</b> A scroll listener tracks when the user is
 *       actively scrolling, suppressing auto-scroll operations that would fight the
 *       user's input.</li>
 *   <li><b>Scroll Position Preservation:</b> Before playlist refreshes (add/remove
 *       operations), the current scroll position is saved and restored afterward,
 *       preventing unwanted jumps. Sort operations do not use this mechanism.</li>
 *   <li><b>Fixed Row Heights:</b> All song items have fixed heights (via maxLines="1"
 *       and ellipsize="end" in the layout), preventing layout shifts when text
 *       content changes during genre loading.</li>
 *   <li><b>Queue Sorting:</b> Sort operations are deferred until after genre loading
 *       completes, preventing the list from re-sorting multiple times during background
 *       updates and maintaining scroll stability.</li>
 * </ul>
 * 
 * <h3>User Interaction Guidelines</h3>
 * <p>To provide a frictionless user experience, the activity follows these interaction
 * guidelines:</p>
 * 
 * <ul>
 *   <li><b>Auto-scroll Only on Initial Load:</b> The playlist automatically scrolls
 *       to the currently playing song only once when the activity is first opened.</li>
 *   <li><b>Auto-scroll on User-Initiated Sort:</b> When the user changes the sort mode
 *       by tapping the SORT button, the playlist automatically scrolls to show where
 *       the currently playing song moved in the new sorted order.</li>
 *   <li><b>No Auto-scroll on Internal Sort:</b> When the playlist refreshes internally
 *       (e.g., after adding/removing songs), auto-scroll is suppressed and the user's
 *       scroll position is preserved via saveScrollPosition()/restoreScrollPosition().</li>
 *   <li><b>No Auto-scroll During User Input:</b> Auto-scroll is suppressed when the
 *       user is actively scrolling or interacting with the list.</li>
 *   <li><b>Song Selection Does Not Scroll:</b> When the user taps a song to play it,
 *       the playlist does not automatically scroll to that song.</li>
 *   <li><b>Theme Changes Do Not Reset Position:</b> When the theme color changes,
 *       only the currently playing item's text color is updated, not the entire list.</li>
 * </ul>
 * 
 * <h3>Search and Sort Features</h3>
 * <p>The activity provides a powerful search and sort system:</p>
 * 
 * <ul>
 *   <li><b>Search:</b> Real-time filtering across title, artist, album, and genre.
 *       The search bar appears when the SEARCH button is tapped and can be dismissed
 *       with the CANCEL button or back button.</li>
 *   <li><b>Sort:</b> Ten sort modes are available, cycled by tapping the SORT button
 *       in the header. The current sort mode is displayed in the header and persisted
 *       across app restarts. Sort changes are broadcast to MusicService so playback
 *       respects the user's preferred order.</li>
 * </ul>
 * 
 * <h3>Broadcast Communication</h3>
 * <p>The activity listens to several broadcast intents to stay synchronized with
 * MusicService and PlaylistService:</p>
 * 
 * <ul>
 *   <li><b>UPDATE_PLAYER:</b> Notifies when playback state changes</li>
 *   <li><b>DISPLAY_PLAYLIST:</b> Triggers a full refresh of the playlist display</li>
 *   <li><b>FORCE_UPDATE_PLAYER:</b> Forces a UI refresh after metadata editing</li>
 *   <li><b>GENRE_UPDATE:</b> Progressive genre loading updates during Phase 2</li>
 *   <li><b>FORCE_PLAYLIST_REFRESH:</b> Forces a playlist reload after genre loading</li>
 * </ul>
 * 
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistService
 * @see ThemeManager
 * @see ToastManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.6
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistActivity";
    
    /** Shared preferences file name for storing user preferences and app state. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the last played song path in SharedPreferences. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Broadcast action for forcing playlist refresh after genre loading completes. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    
    /** Broadcast action for updating sort mode in MusicService. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay in milliseconds before scrolling to the currently playing song. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Maximum length for search query input in characters. */
    private static final int MAX_SEARCH_LENGTH = 128;
    
    /** Corner radius for search bar in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    
    /** Corner radius for search input field in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    
    /** Stroke width for search bar border in density-independent pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    
    /** Padding for empty container in density-independent pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    
    // ========================================================================
    // Sort Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    /** Total number of available sort modes (10). */
    private static final int SORT_MODE_COUNT = 10;
    
    /** Preference key for storing the user's selected sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /**
     * Display names for each sort mode shown in the header.
     */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",
        "[TITLE Z-A]",
        "[ARTIST A-Z]",
        "[ARTIST Z-A]",
        "[ALBUM A-Z]",
        "[ALBUM Z-A]",
        "[GENRE A-Z]",
        "[GENRE Z-A]",
        "[OLDEST]",
        "[NEWEST]"
    };
    
    /**
     * Toast messages for each sort mode shown when user cycles sort.
     */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",
        "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]",
        "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",
        "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",
        "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",
        "SORT MODE: NEWEST"
    };
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** RecyclerView for displaying the playlist items. */
    private RecyclerView mPlaylistRecyclerView;
    
    /** Layout manager for the RecyclerView. */
    private LinearLayoutManager mLayoutManager;
    
    /** Adapter for the playlist RecyclerView. */
    private PlaylistAdapter mAdapter;
    
    /** TextView displaying the playlist title. */
    private TextView mPlaylistTitle;
    
    /** TextView displaying the song count. */
    private TextView mSongCountText;
    
    /** EditText for search input. */
    private EditText mSearchText;
    
    /** Button to toggle search mode visibility. */
    private Button mSearchButton;
    
    /** Button to clear the search query. */
    private Button mClearButton;
    
    /** Button to sort the playlist. */
    private Button mSortButton;
    
    /** Button to cancel/hide search or return to music player. */
    private Button mCancelButton;
    
    /** Container layout for the search bar. */
    private LinearLayout mSearchBar;
    
    /** Container for empty state UI when no songs exist. */
    private LinearLayout mEmptyContainer;
    
    /** Root container frame layout that holds all content. */
    private FrameLayout mRootContainer;
    
    // ========================================================================
    // Data Components
    // ========================================================================
    
    /** List of songs currently displayed (filtered by search and sorted). */
    private ArrayList<Song> mCurrentDisplayList;
    
    /** Path of the currently playing song. */
    @Nullable
    private String mCurrentPlayingPath = null;
    
    /** Flag indicating whether the search bar is currently visible. */
    private boolean mIsSearchVisible = false;
    
    /** Input method manager for controlling the soft keyboard. */
    private InputMethodManager mInputMethodManager;
    
    // ========================================================================
    // Scroll State Management
    // ========================================================================
    
    /** Flag indicating if the user is currently scrolling the RecyclerView. */
    private volatile boolean mUserScrolling = false;
    
    /** Saved scroll position for preservation during playlist refreshes. */
    @Nullable
    private Parcelable mSavedScrollState = null;
    
    /** Flag indicating if a scroll position restore is pending. */
    private boolean mScrollRestorePending = false;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Manager for theme color operations and persistence. */
    private ThemeManager mThemeManager;
    
    /** Helper for applying theme colors to UI components. */
    private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme color change events. */
    private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Sort Components
    // ========================================================================
    
    /** Current sort mode (default is SORT_TITLE_AZ). */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    /** Last sort button click timestamp for debouncing. */
    private long mLastSortClickTime = 0;
    
    /** Flag indicating if a sort update is pending (queued after genre loading). */
    private boolean mPendingSortAfterGenre = false;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Timestamp of the last search button click for debouncing. */
    private long mLastSearchClickTime = 0;
    
    /** Timestamp of the last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;
    
    /** Flag indicating if a user interaction (like song click) is in progress. */
    private volatile boolean mUserInteractionInProgress = false;
    
    /** Flag indicating if genre loading is currently in progress (Phase 2). */
    private volatile boolean mIsGenreLoading = false;
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Service Connection for MusicService (Source of Truth)
    // ========================================================================
    
    /** Reference to MusicService to obtain the current playlist. */
    @Nullable
    private MusicService mMusicService;
    
    /** Flag indicating whether the service is bound. */
    private boolean mIsServiceBound = false;
    
    /** Service connection for binding to MusicService. */
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            refreshFromService();
        }
        
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for playback state updates from MusicService. */
    private BroadcastReceiver mUpdatePlayerReceiver;
    
    /** Receiver for playlist display updates. */
    private BroadcastReceiver mDisplayPlaylistReceiver;
    
    /** Receiver for forced player updates (after metadata changes). */
    private BroadcastReceiver mForceUpdatePlayerReceiver;
    
    /** Receiver for playlist load progress updates during scanning. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;
    
    /** Receiver for genre update events from PlaylistService. */
    private BroadcastReceiver mGenreUpdateReceiver;
    
    /** Receiver for force refresh events from PlaylistService. */
    private BroadcastReceiver mForceRefreshReceiver;
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * @param savedInstanceState Saved instance state (not used in this activity)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        ToastManager.init(this);
        
        setFullScreen();
        setContentView(R.layout.activity_playlist);
        
        CharacterMapper.init(this);
        
        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        
        loadCurrentPlayingPath();
        loadSortMode();
        
        initializeViews();
        setupSearchListener();
        setupScrollListener();
        
        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();
        
        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
        
        applyThemeToUI();
        themeAllHeaders();
    }
    
    /**
     * Called when the activity resumes.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        refreshFromService();
        
        if (mAdapter != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null || TextUtils.isEmpty(mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100);
        
        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();
        
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity pauses.
     */
    @Override
    protected void onPause() {
        super.onPause();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unbind from MusicService", e);
            }
            mIsServiceBound = false;
        }
        
        ToastManager.hidePersistentOverlay();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);
        
        mMainHandler.removeCallbacksAndMessages(null);
    }
    
    /**
     * Called when the window focus changes.
     * 
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the back button is pressed.
     * 
     * <p>Back button behavior:
     * <ul>
     *   <li>If search is visible: Hides the search bar and returns to normal playlist view</li>
     *   <li>If search is not visible: Returns to MusicPlayer activity with slide animation</li>
     * </ul>
     * </p>
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Returns to MusicPlayer without destroying this activity.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    // ========================================================================
    // Scroll Listener
    // ========================================================================
    
    /**
     * Sets up the RecyclerView scroll listener to track user scrolling state.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                mUserScrolling = (newState != RecyclerView.SCROLL_STATE_IDLE);
            }
            
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState = mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }
    
    /**
     * Saves the current scroll position for later restoration.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }
    
    /**
     * Restores a previously saved scroll position.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception e) {
                Log.w(TAG, "Failed to restore scroll position", e);
                mScrollRestorePending = false;
            }
        }
    }
    
    // ========================================================================
    // Refresh Methods
    // ========================================================================
    
    /**
     * Refreshes the playlist from the MusicService (source of truth) and updates UI.
     */
    private void refreshFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshFromService suppressed during genre loading");
            return;
        }
        
        if (mUserScrolling) {
            Log.d(TAG, "refreshFromService suppressed during user scrolling");
            return;
        }
        
        if (mMusicService == null) {
            return;
        }
        
        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }
        
        saveScrollPosition();
        
        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
            return;
        }
        
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            
            applyCurrentSort(false);
            
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }
    
    // ========================================================================
    // Sort Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    /**
     * Cycles to the next sort mode and applies it.
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();
        
        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);
        
        final ArrayList<Song> listToSort = new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int currentSortMode = mCurrentSortMode;
        final boolean showToast = true;
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort, getComparatorForSortMode(currentSortMode));
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        
                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);
                        
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                            
                            if (currentPath != null) {
                                int newPosition = findPositionByPath(currentPath);
                                if (newPosition >= 0) {
                                    mCurrentPlayingPath = currentPath;
                                    mAdapter.setCurrentPlayingIndex(newPosition);
                                    
                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                                focusCurrentSong();
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                            }
                        }
                        
                        updateTitleAndCount();
                        updateSortHeaderDisplay();
                        
                        if (showToast) {
                            ToastManager.showToast(PlaylistActivity.this, 
                                SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
                        }
                    }
                });
            }
        }).start();
    }
    
    /**
     * Applies the current sort mode to the displayed list.
     *
     * @param showToast True to show a toast confirmation message AND auto-scroll
     *                  to the current song; false to sort silently without scrolling
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        
        final String currentPath = mCurrentPlayingPath;
        
        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));
        
        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }
        
        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);
            
            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);
                    
                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }
        
        updateTitleAndCount();
        
        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        }
    }
    
    /**
     * Finds the position of a song in mCurrentDisplayList by its file path.
     *
     * @param path The file path of the song to find
     * @return The position index, or -1 if the song is not found
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && path.equals(song.getPath())) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds since Unix epoch
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator<Song> that implements the requested sorting order
     */
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
                
            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleB.compareToIgnoreCase(titleA);
                    }
                };
                
            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistA.compareToIgnoreCase(artistB);
                        
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistB.compareToIgnoreCase(artistA);
                        
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumA.compareToIgnoreCase(albumB);
                        
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumB.compareToIgnoreCase(albumA);
                        
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreA.compareToIgnoreCase(genreB);
                        
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreB.compareToIgnoreCase(genreA);
                        
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateA, dateB);
                        
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateB, dateA);
                        
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
        }
    }
    
    /**
     * Updates the header to show the current sort mode.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle != null) {
            String searchText = mSearchText != null ? mSearchText.getText().toString() : "";
            
            if (TextUtils.isEmpty(searchText)) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                    mSortButton.setVisibility(View.VISIBLE);
                }
            } else {
                mPlaylistTitle.setText("SEARCH RESULTS");
                if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                    mSortButton.setVisibility(View.GONE);
                }
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    // ========================================================================
    // Display Methods
    // ========================================================================
    
    /**
     * Shows the empty state view when no songs are available.
     */
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));
            
            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);
            
            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer, 
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, 
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }
        
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }
    
    /**
     * Hides the empty state view and shows the playlist RecyclerView.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Sets up the playlist adapter with click listener.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }
                
                mUserInteractionInProgress = true;
                
                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);
                
                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition = findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(newPosition);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting playing index", e);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });
        
        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);
        
        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);
        
        mPlaylistRecyclerView.setAdapter(mAdapter);
    }
    
    /**
     * Updates the title and song count display based on search state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";
        
        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int count = mCurrentDisplayList.size();
                mSongCountText.setText(count + (count == 1 ? " song" : " songs"));
            }
        } else {
            int totalSongs = (mMusicService != null && mMusicService.getCurrentPlaylist() != null) 
                ? mMusicService.getCurrentPlaylist().size() : 0;
            
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int count = mCurrentDisplayList.size();
                mSongCountText.setText(count + " / " + totalSongs + (totalSongs == 1 ? " song" : " songs"));
            }
        }
    }
    
    /**
     * Sets the header texts for playlist title and song count.
     *
     * @param title The title text
     * @param count The count text
     */
    private void setHeaderTexts(@NonNull String title, @NonNull String count) {
        if (mPlaylistTitle != null) {
            if (title.equals("CURRENT PLAYLIST") || title.equals("SEARCH RESULTS")) {
                if (title.equals("CURRENT PLAYLIST")) {
                    mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                } else {
                    mPlaylistTitle.setText(title);
                }
            } else {
                mPlaylistTitle.setText(title);
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setText(count);
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Loads the current playing song path from SharedPreferences.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath = prefs.getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Scrolls the playlist to show the currently playing song.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading");
            return;
        }
        
        if (mUserScrolling) {
            Log.d(TAG, "focusCurrentSong suppressed during user scrolling");
            return;
        }
        
        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }
        
        if (mCurrentPlayingPath == null) {
            return;
        }
        
        int targetPosition = -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = i;
                break;
            }
        }
        
        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisible = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastVisible = mLayoutManager.findLastCompletelyVisibleItemPosition();
                    
                    if (finalPosition < firstVisible || finalPosition > lastVisible) {
                        mLayoutManager.scrollToPositionWithOffset(finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components and sets up click listeners.
     */
    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);
        
        if (mSearchText != null) {
            mSearchText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }
        
        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);
        
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });
        }
        
        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }
        
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }
        
        if (mSortButton != null) {
            mSortButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }
        
        setupAdapter();
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Search Methods
    // ========================================================================
    
    /**
     * Sets up the search functionality with text watcher and clear button.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }
                
                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            
            mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null && mSearchText != null) {
                            imm.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });
            
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }
        
        if (mClearButton != null) {
            mClearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }
    
    /**
     * Performs the search operation and updates the displayed list.
     *
     * @param query The search query string
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }
        
        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs = mMusicService.getCurrentPlaylist();
        
        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }
        
        mCurrentDisplayList.clear();
        
        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }
        
        applyCurrentSort(false);
        
        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }
        
        updateTitleAndCount();
    }
    
    /**
     * Shows the search bar and focuses the search input.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;
        
        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }
        
        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }
    
    /**
     * Hides the search bar and clears the search query.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;
        
        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }
        
        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
            }
        }
        
        performSearch("");
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers the theme color change broadcast receiver.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();
                    
                    if (mSortButton != null && mThemeHelper != null) {
                        mThemeHelper.updateButton(mSortButton, true);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the genre update broadcast receiver for async genre loading.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");
                    
                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG, "Genre loading started for " + total + " songs");
                        mIsGenreLoading = true;
                        
                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }
                        
                        ToastManager.showPersistentOverlay(PlaylistActivity.this, "Loading metadata...");
                        
                    } else if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");
                        int current = intent.getIntExtra("current", 0);
                        int total = intent.getIntExtra("total", 0);
                        
                        ToastManager.updatePersistentOverlay("Loading metadata... " + current + "/" + total);
                        
                        if (mAdapter != null && songPath != null && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }
                        
                    } else if ("COMPLETE".equals(status)) {
                        int loaded = intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");
                        
                        ToastManager.hidePersistentOverlay();
                        mIsGenreLoading = false;
                        
                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }
                        
                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }
                        
                        Intent refreshMetadataIntent = new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra("refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }
    
    /**
     * Registers the force refresh broadcast receiver for genre loading completion.
     */
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - refreshing from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            } else {
                                Log.d(TAG, "Force refresh suppressed during genre loading");
                            }
                        }
                    });
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }
    
    /**
     * Applies header styling to all header TextViews in the activity.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     *
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") || 
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }
    
    /**
     * Applies the current theme color to all UI components.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();
        
        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(mClearButton, mClearButton.isEnabled());
        }
        
        if (mSortButton != null) {
            mThemeHelper.updateButton(mSortButton, mSortButton.isEnabled());
        }
        
        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }
        
        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
            
            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);
            
            mSearchText.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAdapter != null && mCurrentPlayingPath != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            if (currentPosition >= 0) {
                mAdapter.notifyItemChanged(currentPosition);
            }
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for playlist and playback updates.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    if (!mIsGenreLoading && !mUserScrolling) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                        
                        if (currentPath != null && mAdapter != null) {
                            int displayPosition = findPositionByPath(currentPath);
                            if (displayPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                    }
                }
            }
        };
        
        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            }
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    if (mAdapter != null && !mIsGenreLoading && !mUserScrolling) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                        
                        if (currentPath != null) {
                            int displayPosition = findPositionByPath(currentPath);
                            if (displayPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                    }
                }
            }
        };
        
        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }
                    
                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }
                    
                    if (!exists && !mIsGenreLoading && !mUserScrolling) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);
                        
                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );
                        
                        mCurrentDisplayList.add(newSong);
                        
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }
                        
                        updateTitleAndCount();
                    }
                }
            }
        };
        
        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);
        
        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiver(mDisplayPlaylistReceiver, displayFilter);
        
        IntentFilter forceFilter = new IntentFilter();
        forceFilter.addAction("FORCE_UPDATE_PLAYER");
        registerReceiver(mForceUpdatePlayerReceiver, forceFilter);
        
        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiver(mPlaylistLoadProgressReceiver, progressFilter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister receiver", e);
            }
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}