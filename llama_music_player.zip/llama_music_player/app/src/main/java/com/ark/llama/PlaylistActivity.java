package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * PlaylistActivity - Playlist management with transition-driven auto-scroll.
 *
 * <p>This activity provides the playlist view. It maintains a binding to
 * {@link MusicService} to read the current playlist (source of truth) and
 * listens to {@code UPDATE_PLAYER} broadcasts for playback state.</p>
 *
 * <h3>Generation-Gated Broadcasts</h3>
 * <p>{@code UPDATE_PLAYER} broadcasts carry a monotonic {@code generation}.
 * The activity drops any broadcast with a strictly lower generation than
 * the highest it has seen. The high-water mark resets to -1 on service
 * (re)connect because a new service instance restarts at 0.</p>
 *
 * <h3>Transition-Driven Auto-Scroll</h3>
 * <p>When a transition moves the current song offscreen, the activity
 * scrolls it into view. Auto-scroll requires three conditions:</p>
 * <ul>
 *   <li>The user is not dragging or flinging ({@code mUserScrolling} is
 *       false).</li>
 *   <li>The user is not mid-tap ({@code mUserInteractionInProgress} is
 *       false).</li>
 *   <li>The row is not already fully visible.</li>
 * </ul>
 *
 * <p>Genre loading is the sole deferral. During loading, each genre update
 * triggers a DiffUtil call and newly-discovered songs may be inserted, so
 * row positions are in flux. A transition that arrives during this window
 * is stored in {@code mDeferredGenreFocusRow} and applied by
 * {@link #applyDeferredGenreFocus()} on GENRE_UPDATE COMPLETE, when the
 * list has settled.</p>
 *
 * <p>Behavior table:</p>
 * <ul>
 *   <li>Idle, row offscreen -> scroll to row.</li>
 *   <li>Idle, row visible -> no scroll.</li>
 *   <li>User scrolling or flinging -> auto-scroll does not run.</li>
 *   <li>Tap in progress -> auto-scroll does not run.</li>
 *   <li>Genre loading -> deferred until COMPLETE.</li>
 * </ul>
 *
 * <h3>Two-Phase Metadata Loading</h3>
 * <p>Phase 1 performs a fast scan using MediaStore to display songs
 * immediately with "Unknown Genre" placeholders. Phase 2 runs in the
 * background, reading ID3 tags to extract real genres, updating the UI
 * progressively as each song's genre becomes available.</p>
 *
 * <h3>RecyclerView Best Practices</h3>
 * <ul>
 *   <li>Stable IDs on the adapter for smooth item tracking.</li>
 *   <li>DiffUtil-based updates (no notifyDataSetChanged on bulk
 *       changes).</li>
 *   <li>Payload-based partial updates for genre changes.</li>
 *   <li>Scroll-state tracking so auto-scroll runs only when the user is
 *       idle.</li>
 *   <li>Scroll position preservation across playlist refreshes
 *       ({@code saveScrollPosition} / {@code restoreScrollPosition}),
 *       with transition-driven focus taking precedence when the two
 *       conflict.</li>
 *   <li>Fixed row heights (via maxLines and ellipsize) to prevent layout
 *       shifts when text changes during genre loading.</li>
 * </ul>
 *
 * <h3>User Interaction Guidelines</h3>
 * <ul>
 *   <li>Auto-scroll on initial load to bring the current song into view.</li>
 *   <li>Auto-scroll on user-initiated sort to show where the current song
 *       moved in the new sorted order.</li>
 *   <li>Auto-scroll on transition when the current row leaves the
 *       viewport and the user is idle.</li>
 *   <li>No auto-scroll during internal playlist refreshes; scroll position
 *       is preserved instead.</li>
 *   <li>Theme changes refresh only the current-playing row's styling, not
 *       the entire list.</li>
 * </ul>
 *
 * <h3>Search and Sort</h3>
 * <p>Real-time search across title, artist, album, and genre. Ten sort
 * modes cycled by the SORT button; the current mode is broadcast to
 * {@link MusicService} so playback respects the user's ordering.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistService
 * @see ThemeManager
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistActivity";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action for forcing playlist refresh after genre loading. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before scrolling to the currently playing song. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum search query length. */
    private static final int MAX_SEARCH_LENGTH = 128;

    /** Corner radius for search bar in dp. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;

    /** Corner radius for search input field in dp. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;

    /** Stroke width for search bar border in dp. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;

    /** Padding for empty container in dp. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    // ------------------------------------------------------------------------
    // Sort Mode Constants
    // ------------------------------------------------------------------------

    /** Sort mode: Title A-Z. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: Title Z-A. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: Artist A-Z. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: Artist Z-A. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: Album A-Z. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: Album Z-A. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: Genre A-Z. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: Genre Z-A. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: Oldest first by file modification date. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: Newest first by file modification date. */
    private static final int SORT_NEWEST = 9;

    /** Total number of sort modes. */
    private static final int SORT_MODE_COUNT = 10;

    /** Preference key for the selected sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Display names for each sort mode. */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",  "[TITLE Z-A]",
        "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]",  "[ALBUM Z-A]",
        "[GENRE A-Z]",  "[GENRE Z-A]",
        "[OLDEST]",     "[NEWEST]"
    };

    /** Toast messages for each sort mode. */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",  "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]", "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",  "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",  "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",       "SORT MODE: NEWEST"
    };

    // ========================================================================
    // UI Components
    // ========================================================================

    /** RecyclerView for displaying the playlist items. */
    private RecyclerView mPlaylistRecyclerView;

    /** Layout manager for the RecyclerView. */
    private LinearLayoutManager mLayoutManager;

    /** Adapter for the playlist RecyclerView. */
    private PlaylistAdapter mAdapter;

    /** TextView displaying the playlist title. */
    private TextView mPlaylistTitle;

    /** TextView displaying the song count. */
    private TextView mSongCountText;

    /** EditText for search input. */
    private EditText mSearchText;

    /** Button to toggle search mode visibility. */
    private Button mSearchButton;

    /** Button to clear the search query. */
    private Button mClearButton;

    /** Button to sort the playlist. */
    private Button mSortButton;

    /** Button to cancel/hide search or return to music player. */
    private Button mCancelButton;

    /** Container layout for the search bar. */
    private LinearLayout mSearchBar;

    /** Container for empty state UI when no songs exist. */
    private LinearLayout mEmptyContainer;

    /** Root container frame layout that holds all content. */
    private FrameLayout mRootContainer;

    // ========================================================================
    // Data Components
    // ========================================================================

    /** List of songs currently displayed (filtered by search and sorted). */
    private ArrayList<Song> mCurrentDisplayList;

    /** Path of the currently playing song. */
    @Nullable
    private String mCurrentPlayingPath = null;

    /** Flag indicating whether the search bar is currently visible. */
    private boolean mIsSearchVisible = false;

    /** Input method manager for controlling the soft keyboard. */
    private InputMethodManager mInputMethodManager;

    // ========================================================================
    // Scroll State Management
    // ========================================================================

    /** Flag indicating if the user is currently scrolling the RecyclerView. */
    private volatile boolean mUserScrolling = false;

    /** Saved scroll position for preservation during playlist refreshes. */
    @Nullable
    private Parcelable mSavedScrollState = null;

    /** Flag indicating if a scroll position restore is pending. */
    private boolean mScrollRestorePending = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Manager for theme color operations and persistence. */
    private ThemeManager mThemeManager;

    /** Helper for applying theme colors to UI components. */
    private ThemeHelper mThemeHelper;

    /** Broadcast receiver for theme color change events. */
    private BroadcastReceiver mThemeReceiver;

    // ========================================================================
    // Sort Components
    // ========================================================================

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** Last sort button click timestamp for debouncing. */
    private long mLastSortClickTime = 0;

    /** Flag indicating if a sort update is pending (queued after genre
     * loading). */
    private boolean mPendingSortAfterGenre = false;

    // ========================================================================
    // Interaction State
    // ========================================================================

    /** Timestamp of the last search button click for debouncing. */
    private long mLastSearchClickTime = 0;

    /** Timestamp of the last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;

    /** Flag indicating if a user interaction (like song click) is in
     * progress. */
    private volatile boolean mUserInteractionInProgress = false;

    /** Flag indicating if genre loading is currently in progress (Phase 2). */
    private volatile boolean mIsGenreLoading = false;

    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Generation Gate and Deferred Focus
    // ========================================================================

    /**
     * Highest generation seen from UPDATE_PLAYER. Broadcasts with a strictly
     * lower generation are stale and dropped. Reset to -1 on service
     * (re)connect: a new MusicService instance restarts its generation
     * counter at 0.
     */
    private long mLastSeenGeneration = -1L;

    /**
     * Row index a transition wanted to bring into view while genre loading
     * was churning the display list. Applied on GENRE_UPDATE COMPLETE via
     * {@link #applyDeferredGenreFocus()}, when row positions are stable.
     */
    private int mDeferredGenreFocusRow = -1;

    // ========================================================================
    // Service Connection
    // ========================================================================

    /** Bound MusicService (source of truth for the playlist). */
    @Nullable
    private MusicService mMusicService;

    /** Flag indicating whether the service is bound. */
    private boolean mIsServiceBound = false;

    /**
     * Service connection for binding to MusicService. Resets the generation
     * high-water mark on every (re)connect.
     */
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            // New service instance restarts mGeneration at 0.
            mLastSeenGeneration = -1L;
            refreshFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    /** Receiver for playback state updates from MusicService. */
    private BroadcastReceiver mUpdatePlayerReceiver;

    /** Receiver for playlist display updates. */
    private BroadcastReceiver mDisplayPlaylistReceiver;

    /** Receiver for forced player updates (after metadata changes). */
    private BroadcastReceiver mForceUpdatePlayerReceiver;

    /** Receiver for playlist load progress updates during scanning. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;

    /** Receiver for genre update events from PlaylistService. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for force refresh events from PlaylistService. */
    private BroadcastReceiver mForceRefreshReceiver;

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    /**
     * Called when the activity is created.
     *
     * @param savedInstanceState Saved instance state (not used in this
     *                           activity)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();

        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();

        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Called when the activity resumes.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        refreshFromService();

        if (mAdapter != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        // Entry scroll: brings the current song into view on first entry.
        // Runs only when the display is idle and no search is active.
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null || TextUtils.isEmpty(mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Called when the activity pauses.
     */
    @Override
    protected void onPause() {
        super.onPause();

        // Theme receiver is active only while visible.
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Called when the activity is restarting after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Called when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unbind from MusicService", e);
            }
            mIsServiceBound = false;
        }

        ToastManager.hidePersistentOverlay();

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);

        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Called when the window focus changes.
     *
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Called when the back button is pressed.
     *
     * <p>Back button behavior:</p>
     * <ul>
     *   <li>Search visible: hides the search bar and returns to normal
     *       playlist view.</li>
     *   <li>Search hidden: returns to MusicPlayer activity with slide
     *       animation.</li>
     * </ul>
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    /**
     * Returns to MusicPlayer without destroying this activity.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ========================================================================
    // Scroll Listener
    // ========================================================================

    /**
     * Tracks user scrolling. Scroll state determines whether a
     * transition-driven auto-scroll runs at the moment the transition
     * arrives. Transitions that arrive during a drag or fling do not queue
     * a scroll.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                mUserScrolling = (newState != RecyclerView.SCROLL_STATE_IDLE);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState = mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    /**
     * Saves the current scroll position for later restoration.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    /**
     * Restores a previously saved scroll position.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception e) {
                Log.w(TAG, "Failed to restore scroll position", e);
                mScrollRestorePending = false;
            }
        }
    }

    /**
     * True when the given row is not fully visible in the viewport. Uses
     * findFirst/LastCompletelyVisibleItemPosition so a partially-visible
     * row still counts as needing a scroll.
     *
     * @param row The row index to check
     * @return True if the row is outside the fully visible range
     */
    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) return false;
        if (row < 0 || row >= mCurrentDisplayList.size()) return false;
        int first = mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int last = mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (first == RecyclerView.NO_POSITION || last == RecyclerView.NO_POSITION) return false;
        return row < first || row > last;
    }

    /**
     * Scrolls the row to the center of the viewport if it is offscreen.
     * Clears any pending scroll restore, because a transition-driven focus
     * is a stronger signal than a refresh-driven restore.
     *
     * @param row The row index to bring into view
     */
    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) return;
        if (!shouldAutoScrollTo(row)) return;
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                mLayoutManager.scrollToPositionWithOffset(finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    /**
     * Applies a focus that was deferred during genre loading. Called only
     * from the GENRE_UPDATE COMPLETE handler, when the display list has
     * stopped changing and a scroll will land on a stable row.
     */
    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) return;
        int row = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(row);
    }

    // ========================================================================
    // Refresh Methods
    // ========================================================================

    /**
     * Refreshes the playlist from the bound service (source of truth) and
     * updates the UI. Suppressed during genre loading and while the user is
     * scrolling to prevent re-sorting mid-scroll.
     */
    private void refreshFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "refreshFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        // Restore the scroll position after the adapter has laid out the
        // new list.
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }

    // ========================================================================
    // Sort Methods
    // ========================================================================

    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    /**
     * Cycles to the next sort mode. Sorting runs on a background thread; the
     * UI update runs on the main thread after sorting completes. Broadcasts
     * UPDATE_SORT_MODE so the service reorders its playlist in the same
     * order.
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);

        // Snapshot for the background sort.
        final ArrayList<Song> listToSort = new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int currentSortMode = mCurrentSortMode;

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort, getComparatorForSortMode(currentSortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);

                            if (currentPath != null) {
                                int newPosition = findPositionByPath(currentPath);
                                if (newPosition >= 0) {
                                    mCurrentPlayingPath = currentPath;
                                    mAdapter.setCurrentPlayingIndex(newPosition);

                                    // User-initiated sort: scroll to the
                                    // current song's new position.
                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                                focusCurrentSong();
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                            }
                        }

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(PlaylistActivity.this,
                            SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
                    }
                });
            }
        }).start();
    }

    /**
     * Applies the current sort mode to the displayed list.
     *
     * @param showToast True to broadcast the sort mode and auto-scroll to
     *                  the current song; false for silent application (used
     *                  during refresh).
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        }
    }

    /**
     * Finds the position of a song in mCurrentDisplayList by its file path.
     *
     * @param path The file path of the song to find
     * @return The position index, or -1 if the song is not found
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && path.equals(song.getPath())) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Gets the date/timestamp for a song using the file's last modified
     * time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds since Unix epoch
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    /**
     * Returns a Comparator for the specified sort mode. All comparators fall
     * back to title A-Z as a secondary key for stable ordering.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator&lt;Song&gt; that implements the requested sorting
     *         order
     */
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleB.compareToIgnoreCase(titleA);
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";

                        int artistCompare = artistA.compareToIgnoreCase(artistB);

                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";

                        int artistCompare = artistB.compareToIgnoreCase(artistA);

                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";

                        int albumCompare = albumA.compareToIgnoreCase(albumB);

                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";

                        int albumCompare = albumB.compareToIgnoreCase(albumA);

                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";

                        int genreCompare = genreA.compareToIgnoreCase(genreB);

                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";

                        int genreCompare = genreB.compareToIgnoreCase(genreA);

                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);

                        int dateCompare = Long.compare(dateA, dateB);

                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);

                        int dateCompare = Long.compare(dateB, dateA);

                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
        }
    }

    /**
     * Updates the header to show the current sort mode.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
            if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText("SEARCH RESULTS");
            if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ========================================================================
    // Display Methods
    // ========================================================================

    /**
     * Shows the empty state view when no songs are available.
     */
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));

            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);

            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer,
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    /**
     * Hides the empty state view and shows the playlist RecyclerView.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Sets up the playlist adapter with a click listener. Song taps raise
     * {@code mUserInteractionInProgress} for one FOCUS_SCROLL_DELAY window;
     * a transition that arrives inside that window does not trigger
     * auto-scroll.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition = findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(newPosition);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting playing index", e);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Updates the title and song count display based on search state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int count = mCurrentDisplayList.size();
                mSongCountText.setText(count + (count == 1 ? " song" : " songs"));
            }
        } else {
            int totalSongs = (mMusicService != null && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int count = mCurrentDisplayList.size();
                mSongCountText.setText(count + " / " + totalSongs + (totalSongs == 1 ? " song" : " songs"));
            }
        }
    }

    /**
     * Loads the current playing song path from SharedPreferences.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath = prefs.getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Scrolls the playlist to show the currently playing song. Used for
     * entry scroll and user-initiated sort. Transition-driven scroll is
     * handled separately by {@link #scrollToRowIfOffscreen(int)}.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = i;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisible = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastVisible = mLayoutManager.findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisible || finalPosition > lastVisible) {
                        mLayoutManager.scrollToPositionWithOffset(finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    /**
     * Initializes all UI components and sets up click listeners.
     */
    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        // Cap search input length to prevent pathological queries.
        if (mSearchText != null) {
            mSearchText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        // Search bar starts hidden. The no-op touch listener on the bar
        // prevents touches from propagating to the list behind it.
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    /**
     * Adds a scale animation to a button for visual touch feedback.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Search Methods
    // ========================================================================

    /**
     * Sets up the search functionality with text watcher and clear button.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    // Enter or IME_ACTION_SEARCH: hide the keyboard.
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null && mSearchText != null) {
                            imm.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    /**
     * Filters the display list by the given query. Case-insensitive match
     * across title, artist, album, and genre.
     *
     * @param query The search query string
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs = mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    /**
     * Shows the search bar and focuses the search input.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        // Sort button hidden while in search mode: results are shown in
        // playlist order, not the current sort order.
        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    /**
     * Hides the search bar and clears the search query.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");
    }

    // ========================================================================
    // Theme Methods
    // ========================================================================

    /**
     * Registers the theme color change broadcast receiver.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();

                    if (mSortButton != null && mThemeHelper != null) {
                        mThemeHelper.updateButton(mSortButton, true);
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }

    /**
     * Registers the genre update broadcast receiver for async genre loading.
     * START/COMPLETE bracket the loading window; during this window the
     * display and refresh paths are held so the list does not re-sort
     * mid-load.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");

                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG, "Genre loading started for " + total + " songs");
                        mIsGenreLoading = true;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }

                        ToastManager.showPersistentOverlay(PlaylistActivity.this, "Loading metadata...");

                    } else if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");
                        int current = intent.getIntExtra("current", 0);
                        int total = intent.getIntExtra("total", 0);

                        ToastManager.updatePersistentOverlay("Loading metadata... " + current + "/" + total);

                        if (mAdapter != null && songPath != null && genre != null) {
                            // Payload-based partial update: only the subtitle
                            // TextView redraws.
                            mAdapter.updateSongGenre(songPath, genre);
                        }

                    } else if ("COMPLETE".equals(status)) {
                        int loaded = intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");

                        ToastManager.hidePersistentOverlay();
                        mIsGenreLoading = false;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }

                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }

                        // Force metadata refresh on the service side.
                        Intent refreshMetadataIntent = new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra("refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);

                        // Apply any focus that was queued during loading.
                        applyDeferredGenreFocus();
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }

    /**
     * Registers the force refresh broadcast receiver for genre loading
     * completion.
     */
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - refreshing from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            } else {
                                Log.d(TAG, "Force refresh suppressed during genre loading");
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }

    /**
     * Applies header styling to all header TextViews in the activity. Uses a
     * recursive walk to catch any headers nested inside sublayouts.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     *
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);

            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                // Header strings the app renders in the top chrome.
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") ||
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the current theme color to all UI components. Only the
     * current-playing row's text color is refreshed, not the entire list,
     * so theme changes do not reset scroll position.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(mSortButton, mSortButton.isEnabled());
        }

        // Search bar border in theme color.
        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(mThemeHelper.getThemeColorInt());
        }

        // Headers render in neutral gray regardless of theme.
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        // Refresh only the current-playing row's styling.
        if (mAdapter != null && mCurrentPlayingPath != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            if (currentPosition >= 0) {
                mAdapter.notifyItemChanged(currentPosition);
            }
        }
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================

    /**
     * Registers all broadcast receivers for playlist and playback updates.
     */
    private void registerReceivers() {
        /**
         * Core playback-state receiver. Reads the generation and, when it
         * advances, decides whether to bring the current song into view.
         * Position ticks within a generation update the highlight only.
         */
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                long gen = intent.getLongExtra("generation", -1L);
                boolean generationAdvanced;
                if (gen >= 0) {
                    if (gen < mLastSeenGeneration) return;
                    generationAdvanced = (gen > mLastSeenGeneration);
                    if (generationAdvanced) mLastSeenGeneration = gen;
                } else {
                    generationAdvanced = false;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null) return;

                mCurrentPlayingPath = songPath;
                if (mAdapter == null) return;

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition < 0) return;

                // Recolor the current-playing row on every tick.
                mAdapter.setCurrentPlayingIndex(displayPosition);

                // Only a real transition (generation advanced) warrants a
                // scroll. Position ticks do not.
                if (!generationAdvanced) return;
                if (!shouldAutoScrollTo(displayPosition)) return;

                if (mIsGenreLoading) {
                    // Display list is churning during loading; queue for
                    // COMPLETE when positions are stable.
                    mDeferredGenreFocusRow = displayPosition;
                } else if (!mUserScrolling && !mUserInteractionInProgress) {
                    scrollToRowIfOffscreen(displayPosition);
                }
            }
        };

        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            }
                        }
                    });
                }
            }
        };

        /**
         * FORCE_UPDATE_PLAYER: metadata refresh event. Recolors the current
         * row but does not trigger a scroll.
         */
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    if (mAdapter != null && !mIsGenreLoading && !mUserScrolling) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);

                        if (currentPath != null) {
                            int displayPosition = findPositionByPath(currentPath);
                            if (displayPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                    }
                }
            }
        };

        /**
         * Receives incremental song discoveries during the fast scan phase.
         * Inserts new songs into the display list without a full refresh,
         * which would reset scroll.
         */
        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }

                    // Deduplicate against the current display list.
                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists && !mIsGenreLoading && !mUserScrolling) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);

                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );

                        mCurrentDisplayList.add(newSong);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }

                        updateTitleAndCount();
                    }
                }
            }
        };

        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);

        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiver(mDisplayPlaylistReceiver, displayFilter);

        IntentFilter forceFilter = new IntentFilter();
        forceFilter.addAction("FORCE_UPDATE_PLAYER");
        registerReceiver(mForceUpdatePlayerReceiver, forceFilter);

        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiver(mPlaylistLoadProgressReceiver, progressFilter);
    }

    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister receiver", e);
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}