package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * PlaylistActivity - Playlist management with transition-driven auto-scroll.
 *
 * <p>This activity provides the playlist view. It maintains a binding to
 * {@link MusicService} to read the current playlist (source of truth) and
 * listens to {@code UPDATE_PLAYER} broadcasts for playback state.</p>
 *
 * <h3>Generation-Gated Broadcasts</h3>
 * <p>{@code UPDATE_PLAYER} broadcasts carry a monotonic {@code generation}.
 * The activity drops any broadcast with a strictly lower generation than
 * the highest it has seen. The high-water mark resets to -1 on service
 * (re)connect because a new service instance restarts at 0.</p>
 *
 * <h3>Transition-Driven Auto-Scroll</h3>
 * <p>When a transition moves the current song offscreen, the activity
 * scrolls it into view. Auto-scroll requires three conditions:</p>
 * <ul>
 *   <li>The user is not dragging or flinging ({@code mUserScrolling} is
 *       false).</li>
 *   <li>The user is not mid-tap ({@code mUserInteractionInProgress} is
 *       false).</li>
 *   <li>The row is not already fully visible.</li>
 * </ul>
 *
 * <p>Genre loading is the sole deferral. During loading, each genre update
 * triggers a DiffUtil call and newly-discovered songs may be inserted, so
 * row positions are in flux. A transition that arrives during this window
 * is stored in {@code mDeferredGenreFocusRow} and applied by
 * {@link #applyDeferredGenreFocus()} on GENRE_UPDATE COMPLETE, when the
 * list has settled.</p>
 *
 * <h3>Two-Phase Metadata Loading</h3>
 * <p>Phase 1 performs a fast scan using MediaStore to display songs
 * immediately with "Unknown Genre" placeholders. Phase 2 runs in the
 * background, reading ID3 tags to extract real genres, updating the UI
 * progressively as each song's genre becomes available.</p>
 *
 * <h3>Persistent Overlay Ownership</h3>
 * <p>Genre loading is owned by {@link PlaylistService}, which shows the
 * persistent "Loading metadata..." overlay with the
 * {@code "GENRE_UPDATE"} operation ID and heartbeats it independently of
 * any activity's lifecycle. This activity observes genre progress for its
 * own list state but never shows or updates the overlay itself, so
 * navigation between activities cannot steal ownership or leave the
 * overlay stranded.</p>
 *
 * <h3>Metadata Change Publication</h3>
 * <p>Metadata changes published by {@link MetadataEditor} arrive as a
 * single {@code METADATA_UPDATED} broadcast. This activity listens for it
 * and updates the affected row in place. The editor does not send a
 * separate {@code FORCE_UPDATE_PLAYER} for the same event; that broadcast
 * remains in use only for the genre-load refresh triggered internally.</p>
 *
 * <h3>Library Reset</h3>
 * <p>When the library becomes empty — the user removed the last folder and
 * the last loose track — the service reports an empty playlist on the next
 * refresh. This activity's {@link #refreshFromService()} clears the display
 * list and additionally drops the presentation state that referred to the
 * song that no longer exists: {@code mCurrentPlayingPath} and the deferred
 * auto-scroll target. Without that clear, the next list population would
 * briefly highlight or scroll to a row that matched the stale path.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistService
 * @see ThemeManager
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================

    private static final String TAG = "PlaylistActivity";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";

    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final int ANIMATION_DURATION_MS = 80;
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    private static final int MAX_SEARCH_LENGTH = 128;
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    // Sort mode constants
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;
    private static final int SORT_MODE_COUNT = 10;

    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",  "[TITLE Z-A]",
        "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]",  "[ALBUM Z-A]",
        "[GENRE A-Z]",  "[GENRE Z-A]",
        "[OLDEST]",     "[NEWEST]"
    };

    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",  "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]", "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",  "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",  "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",       "SORT MODE: NEWEST"
    };

    // ========================================================================
    // UI Components
    // ========================================================================

    private RecyclerView mPlaylistRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private PlaylistAdapter mAdapter;
    private TextView mPlaylistTitle;
    private TextView mSongCountText;
    private EditText mSearchText;
    private Button mSearchButton;
    private Button mClearButton;
    private Button mSortButton;
    private Button mCancelButton;
    private LinearLayout mSearchBar;
    private LinearLayout mEmptyContainer;
    private FrameLayout mRootContainer;

    // ========================================================================
    // Data Components
    // ========================================================================

    private ArrayList<Song> mCurrentDisplayList;
    @Nullable private String mCurrentPlayingPath = null;
    private boolean mIsSearchVisible = false;
    private InputMethodManager mInputMethodManager;

    // ========================================================================
    // Scroll State Management
    // ========================================================================

    private volatile boolean mUserScrolling = false;
    @Nullable private Parcelable mSavedScrollState = null;
    private boolean mScrollRestorePending = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    private ThemeManager mThemeManager;
    private ThemeHelper mThemeHelper;
    private BroadcastReceiver mThemeReceiver;

    // ========================================================================
    // Sort Components
    // ========================================================================

    private int mCurrentSortMode = SORT_TITLE_AZ;
    private long mLastSortClickTime = 0;
    private boolean mPendingSortAfterGenre = false;

    // ========================================================================
    // Interaction State
    // ========================================================================

    private long mLastSearchClickTime = 0;
    private long mLastCancelClickTime = 0;
    private volatile boolean mUserInteractionInProgress = false;
    private volatile boolean mIsGenreLoading = false;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Generation Gate and Deferred Focus
    // ========================================================================

    private long mLastSeenGeneration = -1L;
    private int mDeferredGenreFocusRow = -1;

    // ========================================================================
    // Service Connection
    // ========================================================================

    @Nullable private MusicService mMusicService;
    private boolean mIsServiceBound = false;

    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mLastSeenGeneration = -1L;
            refreshFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private BroadcastReceiver mUpdatePlayerReceiver;
    private BroadcastReceiver mDisplayPlaylistReceiver;
    private BroadcastReceiver mMetadataUpdatedReceiver;
    private BroadcastReceiver mPlaylistLoadProgressReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mForceRefreshReceiver;

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();

        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();

        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        refreshFromService();

        if (mAdapter != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null || TextUtils.isEmpty(mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister theme receiver", exception);
            }
            mThemeReceiver = null;
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unbind from MusicService", exception);
            }
            mIsServiceBound = false;
        }

        ToastManager.hidePersistentOverlay();

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister theme receiver", exception);
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);

        mMainHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ========================================================================
    // Scroll Listener
    // ========================================================================

    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                mUserScrolling = (newState != RecyclerView.SCROLL_STATE_IDLE);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState = mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception exception) {
                Log.w(TAG, "Failed to restore scroll position", exception);
                mScrollRestorePending = false;
            }
        }
    }

    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) return false;
        if (row < 0 || row >= mCurrentDisplayList.size()) return false;
        int firstVisibleRow = mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastVisibleRow = mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (firstVisibleRow == RecyclerView.NO_POSITION || lastVisibleRow == RecyclerView.NO_POSITION) {
            return false;
        }
        return row < firstVisibleRow || row > lastVisibleRow;
    }

    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) return;
        if (!shouldAutoScrollTo(row)) return;
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                mLayoutManager.scrollToPositionWithOffset(finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) return;
        int deferredRow = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(deferredRow);
    }

    // ========================================================================
    // Refresh Methods
    // ========================================================================

    private void refreshFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "refreshFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            // The library is empty. Drop the presentation state that
            // referred to a song that no longer exists, so a later list
            // population does not flash a highlight or scroll to a row
            // that matched the stale path.
            mCurrentPlayingPath = null;
            mDeferredGenreFocusRow = -1;
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
                mAdapter.setCurrentPlayingPath(null);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }

    // ========================================================================
    // Sort Methods
    // ========================================================================

    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);

        final ArrayList<Song> listToSort = new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int sortMode = mCurrentSortMode;

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort, getComparatorForSortMode(sortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);

                            if (currentPath != null) {
                                int newPosition = findPositionByPath(currentPath);
                                if (newPosition >= 0) {
                                    mCurrentPlayingPath = currentPath;
                                    mAdapter.setCurrentPlayingIndex(newPosition);

                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                                focusCurrentSong();
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                            }
                        }

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(PlaylistActivity.this,
                            SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
                    }
                });
            }
        }).start();
    }

    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        }
    }

    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentDisplayList.size(); index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return secondTitle.compareToIgnoreCase(firstTitle);
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(firstDate, secondDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(secondDate, firstDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                };
        }
    }

    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
            if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText("SEARCH RESULTS");
            if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ========================================================================
    // Display Methods
    // ========================================================================

    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));

            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);

            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer,
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition = findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(newPosition);
                            }
                        } catch (Exception exception) {
                            Log.e(TAG, "Error setting playing index", exception);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    private void updateTitleAndCount() {
        String searchText = mSearchText != null ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount + (songCount == 1 ? " song" : " songs"));
            }
        } else {
            int totalSongs = (mMusicService != null && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount + " / " + totalSongs + (totalSongs == 1 ? " song" : " songs"));
            }
        }
    }

    private void loadCurrentPlayingPath() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath = prefs.getString(KEY_LAST_SONG_PATH, null);
    }

    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size(); index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisibleRow = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastVisibleRow = mLayoutManager.findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisibleRow || finalPosition > lastVisibleRow) {
                        mLayoutManager.scrollToPositionWithOffset(finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        if (mSearchText != null) {
            mSearchText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Search Methods
    // ========================================================================

    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (inputMethodManager != null && mSearchText != null) {
                            inputMethodManager.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs = mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");
    }

    // ========================================================================
    // Theme Methods
    // ========================================================================

    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();

                    if (mSortButton != null && mThemeHelper != null) {
                        mThemeHelper.updateButton(mSortButton, true);
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }

    /**
     * Registers the genre update broadcast receiver for async genre loading.
     * START/COMPLETE bracket the loading window; during this window the
     * display and refresh paths are held so the list does not re-sort
     * mid-load.
     *
     * <p>The persistent overlay is owned by {@link PlaylistService}, which
     * shows it with the {@code "GENRE_UPDATE"} operation ID and heartbeats
     * it independently of this activity's lifecycle. This receiver
     * observes genre progress only to drive its own list state; it never
     * shows or updates the overlay itself.</p>
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");

                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG, "Genre loading started for " + total + " songs");
                        mIsGenreLoading = true;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }

                        // The overlay is owned by PlaylistService. Do not
                        // show or update it here — a second writer would
                        // steal ownership and strand the overlay when this
                        // activity is not the visible one.

                    } else if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");

                        if (mAdapter != null && songPath != null && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }

                    } else if ("COMPLETE".equals(status)) {
                        int loaded = intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");

                        mIsGenreLoading = false;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }

                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }

                        Intent refreshMetadataIntent = new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra("refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);

                        applyDeferredGenreFocus();
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }

    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - refreshing from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            } else {
                                Log.d(TAG, "Force refresh suppressed during genre loading");
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }

    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") ||
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(mSortButton, mSortButton.isEnabled());
        }

        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAdapter != null && mCurrentPlayingPath != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            if (currentPosition >= 0) {
                mAdapter.notifyItemChanged(currentPosition);
            }
        }
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================

    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                long generation = intent.getLongExtra("generation", -1L);
                boolean generationAdvanced;
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) return;
                    generationAdvanced = (generation > mLastSeenGeneration);
                    if (generationAdvanced) mLastSeenGeneration = generation;
                } else {
                    generationAdvanced = false;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null) return;

                mCurrentPlayingPath = songPath;
                if (mAdapter == null) return;

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition < 0) return;

                mAdapter.setCurrentPlayingIndex(displayPosition);

                if (!generationAdvanced) return;
                if (!shouldAutoScrollTo(displayPosition)) return;

                if (mIsGenreLoading) {
                    mDeferredGenreFocusRow = displayPosition;
                } else if (!mUserScrolling && !mUserInteractionInProgress) {
                    scrollToRowIfOffscreen(displayPosition);
                }
            }
        };

        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            }
                        }
                    });
                }
            }
        };

        /**
         * Metadata change published by {@link MetadataEditor}. Recolors the
         * affected row and refreshes the current-playing path if it changed.
         */
        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"METADATA_UPDATED".equals(intent.getAction())) {
                    return;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null || mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition >= 0) {
                    Song existing = mCurrentDisplayList.get(displayPosition);
                    if (existing != null) {
                        final String title = intent.getStringExtra("title");
                        final String artist = intent.getStringExtra("artist");
                        final String album = intent.getStringExtra("album");
                        final String genre = intent.getStringExtra("genre");
                        Song updated = new Song(
                            title != null ? title : existing.getTitle(),
                            artist != null ? artist : existing.getArtist(),
                            album != null ? album : existing.getAlbum(),
                            genre != null ? genre : existing.getGenre(),
                            songPath, existing.getDuration(), existing.getUri());
                        mCurrentDisplayList.set(displayPosition, updated);
                        mAdapter.notifyItemChanged(displayPosition);
                    }
                }

                if (songPath.equals(mCurrentPlayingPath)) {
                    mCurrentPlayingPath = songPath;
                    mAdapter.setCurrentPlayingIndex(displayPosition);
                }
            }
        };

        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }

                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists && !mIsGenreLoading && !mUserScrolling) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);

                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );

                        mCurrentDisplayList.add(newSong);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }

                        updateTitleAndCount();
                    }
                }
            }
        };

        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);

        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiver(mDisplayPlaylistReceiver, displayFilter);

        IntentFilter metadataFilter = new IntentFilter();
        metadataFilter.addAction("METADATA_UPDATED");
        registerReceiver(mMetadataUpdatedReceiver, metadataFilter);

        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiver(mPlaylistLoadProgressReceiver, progressFilter);
    }

    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister receiver", exception);
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}