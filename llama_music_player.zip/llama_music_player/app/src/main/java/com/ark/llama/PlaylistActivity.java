// PlaylistActivity.java
package com.ark.llama;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.res.Configuration;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Displays the playlist, supports search and sort, and tracks the
 * currently playing song.
 *
 * <p>The activity reads the current playlist from
 * {@link MusicService} and receives playback state changes through
 * {@link BroadcastTranslator}'s {@code UPDATE_PLAYER} event. Users
 * can search the playlist, cycle through ten sort modes, and tap a
 * song to play it. The row that corresponds to the currently
 * playing song is highlighted, and the list scrolls it into view
 * when a transition moves it offscreen.</p>
 *
 * <h3>State Ownership</h3>
 * <p>{@link MusicService} owns the authoritative playlist and the
 * current playing index. This activity owns the display list, the
 * current sort mode, the presentation hint that highlights the
 * current row, the scroll position, and the genre-loading flag
 * that suppresses refreshes while a genre load is in flight. The
 * persistent genre-loading overlay is owned by
 * {@link PlaylistManager}.</p>
 *
 * <h3>Sort Progress Feedback</h3>
 * <p>Cycling the sort mode shows the process-wide dim-and-spinner
 * overlay for the duration of the sort.</p>
 *
 * <h3>Ordering</h3>
 * <p>Every {@code UPDATE_PLAYER} event carries a monotonic
 * {@code generation}. The activity drops any event with a
 * strictly lower generation than the highest it has seen. When the
 * service is rebound, the high-water mark resets to {@code -1},
 * because a new service instance restarts its counter at zero.</p>
 *
 * <h3>Edge Fast Scroll</h3>
 * <p>A vertical drag that starts inside the leftmost or rightmost
 * {@link #PLAYLIST_EDGE_SCROLL_DP} of the list scrolls the list
 * proportionally through {@link EdgeScrollHelper}.</p>
 *
 * <h3>Library Reset</h3>
 * <p>When the library is reset, {@link PlaylistManager}'s reset
 * operation publishes a {@code LIBRARY_RESET} event through
 * {@link BroadcastTranslator}. This activity's subscriber clears
 * the display list and drops every piece of presentation state
 * that referred to a song that no longer exists, including the
 * genre-loading flag that a cancelled load would otherwise leave
 * set forever.</p>
 *
 * <h3>Language Application</h3>
 * <p>The activity wraps its base context through
 * {@link LanguageManager#wrap(Context)} in
 * {@link #attachBaseContext(Context)}, so every string it resolves
 * through {@code getString} is read from the resource folder that
 * matches the selected language from the moment the activity is
 * created. A {@code LANGUAGE_CHANGED} event reaches this activity
 * through {@link BroadcastTranslator} and is answered with
 * {@code recreateActivity()}, which runs {@code attachBaseContext}
 * again with the new locale already persisted.</p>
 *
 * <h3>Theme Application</h3>
 * <p>A {@code THEME_COLOR_CHANGED} event reaches this activity
 * through {@link BroadcastTranslator} and is answered with
 * {@code recreateActivity()}. The activity rebuilds
 * against the persisted color on the next turn. The search bar
 * chrome, the sort button, the row hearts, and the header labels
 * are all rebuilt from the new color; no view in this activity is
 * repainted in place.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>Nothing changes. The RecyclerView is the scroller; it
 * simply scrolls further as the window shrinks. Row density is a
 * list concern, not a window concern, and every touch target
 * keeps its declared size. When the list is empty, the
 * placeholder that occupies its slot is centred in that slot,
 * below the header bar.</p>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible label resolves from a string resource at the
 * point of the write. The top-bar title, the two empty-state
 * sentences, the two sort header labels, the ten sort bracket labels
 * and the ten sort toasts, the search-results header, and the song
 * count are each read from {@code R.string} or {@code R.plurals} in
 * the app's selected language.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistManager
 * @see OverlayManager
 * @see ThemeManager
 * @see ToastManager
 * @see LanguageManager
 * @see CharacterMapper
 * @see BroadcastTranslator
 *
 * @author Richard Korbla Adzido
 * @version 1.6.7
 * @since 1.0.0
 */
public class PlaylistActivity extends Activity {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistActivity";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE =
        "UPDATE_SORT_MODE";

    /** Broadcast action asking the player to refresh its metadata display. */
    private static final String ACTION_FORCE_UPDATE_PLAYER =
        "FORCE_UPDATE_PLAYER";

    /** Broadcast action asking the service to play the song at a given path. */
    private static final String ACTION_PLAY_SONG = "PLAY_SONG";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Delay before the initial focus scroll, in milliseconds. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500L;

    /** Duration of button press animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum length of the search field. */
    private static final int MAX_SEARCH_LENGTH = 128;

    /** Corner radius of the search bar, in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;

    /** Corner radius of the search input, in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;

    /** Stroke width of the search bar border, in density-independent
     *  pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;

    /** Padding of the empty-state container, in density-independent
     *  pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /** Width of the fast-scroll touch zone from each side of the
     *  playlist, in density-independent pixels. */
    private static final int PLAYLIST_EDGE_SCROLL_DP = 32;

    /** Fraction of the total scrollable range traversed by one
     *  viewport-height of finger travel in an edge fast-scroll
     *  zone. */
    private static final float FAST_SCROLL_FRACTION_PER_VIEWPORT = 0.05f;

    /** Minimum content-to-viewport ratio at which fast scroll
     *  engages. */
    private static final float FAST_SCROLL_MIN_CONTENT_RATIO = 3.0f;

    /** Minimum time the sort overlay stays on screen, measured from
     *  the moment the sort began, in milliseconds. */
    private static final long SORT_OVERLAY_MIN_DURATION_MS = 250L;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Total number of sort modes. */
    private static final int SORT_MODE_COUNT = 10;

    /** Separator between the sort-mode prefix and the mode label. */
    private static final String SORT_MODE_LABEL_SEPARATOR = " ";

    /** Shared preferences key for the persisted sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Resource identifiers for the sort labels shown after the
     *  "SORT MODE" prefix in the header, indexed by sort mode. */
    @StringRes
    private static final int[] SORT_LABEL_RES = {
        R.string.playlist_sort_label_title_az,
        R.string.playlist_sort_label_title_za,
        R.string.playlist_sort_label_artist_az,
        R.string.playlist_sort_label_artist_za,
        R.string.playlist_sort_label_album_az,
        R.string.playlist_sort_label_album_za,
        R.string.playlist_sort_label_genre_az,
        R.string.playlist_sort_label_genre_za,
        R.string.playlist_sort_label_oldest,
        R.string.playlist_sort_label_newest
    };

    /** Resource identifiers for the sort transition messages shown
     *  after cycling the sort mode, indexed by sort mode. */
    @StringRes
    private static final int[] SORT_TOAST_RES = {
        R.string.playlist_sort_toast_title_az,
        R.string.playlist_sort_toast_title_za,
        R.string.playlist_sort_toast_artist_az,
        R.string.playlist_sort_toast_artist_za,
        R.string.playlist_sort_toast_album_az,
        R.string.playlist_sort_toast_album_za,
        R.string.playlist_sort_toast_genre_az,
        R.string.playlist_sort_toast_genre_za,
        R.string.playlist_sort_toast_oldest,
        R.string.playlist_sort_toast_newest
    };

    /**
     * Stages favorite-flag changes made by the user until
     * {@link #onPause()} flushes them to the service.
     */
    private static final class PendingFavorites {

        @NonNull
        private final java.util.HashMap<String, Boolean> mMap =
            new java.util.HashMap<>();

        void stage(@NonNull String path, boolean favorite) {
            mMap.put(path, favorite);
        }

        boolean isEmpty() {
            return mMap.isEmpty();
        }

        @NonNull
        java.util.Map<String, Boolean> snapshot() {
            return new java.util.HashMap<>(mMap);
        }

        void clear() {
            mMap.clear();
        }
    }

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Recycler view that displays the playlist rows. */
    private RecyclerView mPlaylistRecyclerView;

    /** Layout manager backing the recycler view. */
    private LinearLayoutManager mLayoutManager;

    /** Adapter backing the recycler view. */
    private PlaylistAdapter mAdapter;

    /** Text view showing the sort mode or search context. */
    private TextView mPlaylistTitle;

    /** Text view showing the song count. */
    private TextView mSongCountText;

    /** Text field for the search query. */
    private EditText mSearchText;

    /** Button that opens the search bar. */
    private Button mSearchButton;

    /** Button that clears the search query. */
    private Button mClearButton;

    /** Button that cycles the sort mode. */
    private Button mSortButton;

    /** Button that closes the activity or hides the search bar. */
    private Button mCancelButton;

    /** Container that hosts the search bar. */
    private LinearLayout mSearchBar;

    /** Container shown when the playlist is empty. */
    private LinearLayout mEmptyContainer;

    /** Root frame layout that hosts the empty state. */
    private FrameLayout mRootContainer;

    // ============================================================================
    // Data Components
    // ============================================================================

    /** Songs currently displayed, after search and sort. */
    private ArrayList<Song> mCurrentDisplayList;

    /** Path of the song currently highlighted as playing, or null. */
    @Nullable private String mCurrentPlayingPath = null;

    /** True while the search bar is visible. */
    private boolean mIsSearchVisible = false;

    /** Input method manager used to show and hide the keyboard. */
    private InputMethodManager mInputMethodManager;

    /** Changes to favorite flags staged by the user since the last
     *  pause. Flushed to {@link MusicService} in {@link #onPause()}
     *  and cleared afterward. */
    @NonNull private final PendingFavorites mPendingFavorites =
        new PendingFavorites();

    // ============================================================================
    // Scroll State Management
    // ============================================================================

    /** True while the user is dragging or flinging the list. */
    private volatile boolean mUserScrolling = false;

    /** Saved scroll position, restored after list updates. */
    @Nullable private Parcelable mSavedScrollState = null;

    /** True while a saved scroll position is waiting to be
     *  restored. */
    private boolean mScrollRestorePending = false;

    // ============================================================================
    // Theme Components
    // ============================================================================

    /** Manager for the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper for applying theme colors to UI components. */
    private ThemeHelper mThemeHelper;

    // ============================================================================
    // Sort Components
    // ============================================================================

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** Timestamp of the last sort button click. */
    private long mLastSortClickTime = 0L;

    /** True when a sort should be applied once genre loading
     *  completes. */
    private boolean mPendingSortAfterGenre = false;

    /** Pending hide runnable for the sort overlay, or null when no
     *  sort is in flight. */
    @Nullable private Runnable mSortOverlayHideRunnable = null;

    /** Generation of the sort cycle. */
    private long mSortGeneration = 0L;

    // ============================================================================
    // Interaction State
    // ============================================================================

    /** Timestamp of the last search button click. */
    private long mLastSearchClickTime = 0L;

    /** Timestamp of the last cancel button click. */
    private long mLastCancelClickTime = 0L;

    /** True while a tap is being processed. */
    private volatile boolean mUserInteractionInProgress = false;

    /** True while genre loading is in flight. */
    private volatile boolean mIsGenreLoading = false;

    /** True between onResume() and onPause(); mirrors the pre-migration
     *  visible-only gate that the theme receiver used. */
    private volatile boolean mIsResumed = false;

    /** True while an activity recreation is pending. */
    private boolean mRecreationPending = false;

    /**
     * Set when a {@code THEME_COLOR_CHANGED} event arrives while the
     * activity is not resumed. The event is not dropped: the pending
     * recreate runs from {@link #onResume()}, so the activity is
     * rebuilt against the new theme when it returns to the
     * foreground instead of keeping the theme it was constructed
     * with.
     */
    private boolean mThemeRecreationPending = false;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // Generation Gate and Deferred Focus
    // ============================================================================

    /** Highest generation seen in an {@code UPDATE_PLAYER} event. */
    private long mLastSeenGeneration = -1L;

    /** Row waiting for focus once genre loading completes, or -1. */
    private int mDeferredGenreFocusRow = -1;
    private boolean mDeferredPlaylistRefresh = false;

    // ============================================================================
    // Service Connection
    // ============================================================================

    /** Bound service, or null while not bound. */
    @Nullable private MusicService mMusicService;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** Connection that resets the generation gate on every
     *  (re)connect. */
    private final ServiceConnection mServiceConnection =
        new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mLastSeenGeneration = -1L;
            refreshPlaylistFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ============================================================================
    // Language Application
    // ============================================================================

    /**
     * Wraps the base context with the currently selected locale.
     *
     * @param newBase Base context supplied by the framework
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase));
    }

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, its view hierarchy, its
     * {@link BroadcastTranslator} subscription, and the service
     * binding.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);
        OverlayManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager =
            (InputMethodManager) getSystemService(
                Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();
        setupEdgeFastScroll();

        BroadcastTranslator.getInstance(this).register(this);

        bindService(new Intent(this, MusicService.class),
            mServiceConnection, BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the list from the service, focuses the current song, and
     * reapplies the theme.
     */
    @Override
    protected void onResume() {
        super.onResume();
        LanguageManager.getInstance(this).reapply(this);
        mIsResumed = true;

        if (mThemeRecreationPending) {
            mThemeRecreationPending = false;
            recreateActivity();
            return;
        }

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        refreshPlaylistFromService();

        if (mAdapter != null) {
            int currentPosition =
                findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null
                        || TextUtils.isEmpty(
                            mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading
                            && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100L);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Flushes any pending favorite changes to the service.
     */
    @Override
    protected void onPause() {
        mIsResumed = false;
        super.onPause();

        if (!mPendingFavorites.isEmpty() && mMusicService != null) {
            mMusicService.commitFavorites(mPendingFavorites.snapshot());
            mPendingFavorites.clear();
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Unbinds from the service, unregisters from
     * {@link BroadcastTranslator}, and removes every handler
     * callback.
     */
    @Override
    protected void onDestroy() {
        BroadcastTranslator.getInstance(this).unregister(this);
        super.onDestroy();

        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
        OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT);

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unbind from MusicService", exception);
            }
            mIsServiceBound = false;
        }

        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Reapplies immersive mode when the window gains focus and
     * reattaches any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Reapplies the app locale when the activity receives a configuration change.
     *
     * @param config New configuration supplied by the system
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration config) {
        super.onConfigurationChanged(config);
        LanguageManager.getInstance(this).reapply(this);
    }

    /**
     * Hides the search bar when it is visible, or returns to the
     * music player otherwise.
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ============================================================================
    // BroadcastTranslator Subscribers
    // ============================================================================

    /**
     * Handles an {@code UPDATE_PLAYER} event.
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onUpdatePlayerEvent(
            BroadcastTranslator.UpdatePlayerEvent event) {
        if (event == null) {
            return;
        }

        final long generation = event.generation;
        final boolean generationAdvanced;
        if (generation >= 0L) {
            if (generation < mLastSeenGeneration) {
                return;
            }
            generationAdvanced = generation > mLastSeenGeneration;
            if (generationAdvanced) {
                mLastSeenGeneration = generation;
            }
        } else {
            generationAdvanced = false;
        }

        final String songPath = event.songPath;
        if (songPath == null || mAdapter == null) {
            return;
        }
        mCurrentPlayingPath = songPath;

        // transitionRestart is the source's restart/repeat-one signal.
        final boolean restartOrRepeatOne = event.transitionRestart;
        final boolean refreshNeeded = generationAdvanced
                || restartOrRepeatOne;
        if (refreshNeeded) {
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (generation >= 0L
                            && generation < mLastSeenGeneration) {
                        return;
                    }
                    final String activePath = mCurrentPlayingPath != null
                        ? mCurrentPlayingPath : songPath;
                    if (mIsGenreLoading) {
                        mDeferredPlaylistRefresh = true;
                        mDeferredGenreFocusRow = findPositionByPath(activePath);
                        return;
                    }
                    refreshPlaylistFromService(true);
                    int newPosition = findPositionByPath(activePath);
                    if (newPosition >= 0 && mAdapter != null) {
                        mAdapter.setCurrentPlayingIndex(newPosition);
                        if (!mUserScrolling && !mUserInteractionInProgress
                                && shouldAutoScrollTo(newPosition)) {
                            scrollToRowIfOffscreen(newPosition);
                        }
                    }
                }
            }, 500L);
        }

        int displayPosition = findPositionByPath(songPath);
        if (displayPosition < 0) {
            return;
        }
        mAdapter.setCurrentPlayingIndex(displayPosition);

        if (!generationAdvanced && !restartOrRepeatOne) {
            return;
        }
        if (!shouldAutoScrollTo(displayPosition)) {
            return;
        }
        if (mIsGenreLoading) {
            mDeferredGenreFocusRow = displayPosition;
        } else if (!mUserScrolling && !mUserInteractionInProgress) {
            scrollToRowIfOffscreen(displayPosition);
        }
    }


    @org.greenrobot.eventbus.Subscribe
    public void onDisplayPlaylistEvent(
            BroadcastTranslator.DisplayPlaylistEvent event) {
        if (event == null) {
            return;
        }
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mIsGenreLoading) {
                    mDeferredPlaylistRefresh = true;
                    return;
                }
                refreshPlaylistFromService(true);
                int position = findPositionByPath(mCurrentPlayingPath);
                if (position >= 0 && mAdapter != null) {
                    mAdapter.setCurrentPlayingIndex(position);
                    if (!mUserScrolling && !mUserInteractionInProgress
                            && shouldAutoScrollTo(position)) {
                        scrollToRowIfOffscreen(position);
                    }
                }
            }
        }, 500L);
    }


    @org.greenrobot.eventbus.Subscribe
    public void onMetadataUpdatedEvent(
            BroadcastTranslator.MetadataUpdatedEvent event) {
        if (event == null) {
            return;
        }

        final String songPath =
            resolveBroadcastSongPath(event.songPath, event.songUri);
        if (songPath == null || mAdapter == null) {
            return;
        }

        final int displayPosition =
            findPositionByPath(songPath);
        if (displayPosition >= 0) {
            final Song existing =
                mCurrentDisplayList.get(displayPosition);
            if (existing != null) {
                final String title = event.title;
                final String artist = event.artist;
                final String album = event.album;
                final String genre = event.genre;
                final String uriString = event.songUri;

                final Song updated = new Song(
                    title != null ? title : existing.getRawTitle(),
                    artist != null ? artist : existing.getRawArtist(),
                    album != null ? album : existing.getRawAlbum(),
                    genre != null ? genre : existing.getRawGenre(),
                    songPath,
                    existing.getDuration(),
                    uriString != null && !uriString.isEmpty()
                        ? uriString
                        : existing.getUri());
                updated.setFavorite(existing.isFavorite());
                mCurrentDisplayList.set(
                    displayPosition, updated);
                mAdapter.notifyItemChanged(
                    displayPosition);
            }
        }

        if (displayPosition >= 0
                && songPath.equals(mCurrentPlayingPath)) {
            mCurrentPlayingPath = songPath;
            mAdapter.setCurrentPlayingIndex(displayPosition);
        }
    }

    /**
     * Handles a {@code PLAYLIST_LOAD_PROGRESS} event.
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onPlaylistLoadProgressEvent(
            BroadcastTranslator.PlaylistLoadProgressEvent event) {
        if (event == null) {
            return;
        }

        String path = event.songPath;
        if (TextUtils.isEmpty(path)) {
            return;
        }

        boolean exists = false;
        for (Song song : mCurrentDisplayList) {
            if (song != null
                    && path.equals(song.getPath())) {
                exists = true;
                break;
            }
        }

        if (!exists && !mIsGenreLoading
                && !mUserScrolling) {
            String title = event.title;
            String artist = event.artist;
            String album = event.album;
            String genre = event.genre;
            long duration = event.duration;

            Song newSong = new Song(
                title, artist, album, genre,
                path, duration, null);

            mCurrentDisplayList.add(newSong);

            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }

            updateTitleAndCount();
        }
    }

    /**
     * Handles a {@code GENRE_UPDATE} event.
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onGenreUpdateEvent(
            BroadcastTranslator.GenreUpdateEvent event) {
        if (event == null) {
            return;
        }

        String status = event.status;

        if ("START".equals(status)) {
            int total = event.total;
            Log.d(TAG,
                "Genre loading started for " + total
                    + " songs");
            mIsGenreLoading = true;

            if (mAdapter != null) {
                mAdapter.setGenreLoading(true);
            }

        } else if ("UPDATE".equals(status)) {
            String songPath = event.songPath;
            String genre = event.genre;

            if (mAdapter != null && songPath != null
                    && genre != null) {
                mAdapter.updateSongGenre(songPath, genre);
            }

        } else if ("COMPLETE".equals(status)) {
            int loaded = event.current;
            Log.d(TAG, "Genre loading complete: "
                + loaded + " genres loaded");

            mIsGenreLoading = false;

            if (mAdapter != null) {
                mAdapter.setGenreLoading(false);
            }

            if (mPendingSortAfterGenre) {
                mPendingSortAfterGenre = false;
                applyCurrentSort(true);
            }

            if (mDeferredPlaylistRefresh) {
                mDeferredPlaylistRefresh = false;
                mDeferredGenreFocusRow = -1;
                refreshPlaylistFromService(true);
                int currentPosition = findPositionByPath(mCurrentPlayingPath);
                if (currentPosition >= 0 && mAdapter != null) {
                    mAdapter.setCurrentPlayingIndex(currentPosition);
                    if (!mUserScrolling && !mUserInteractionInProgress
                            && shouldAutoScrollTo(currentPosition)) {
                        scrollToRowIfOffscreen(currentPosition);
                    }
                }
            }

            Intent refreshMetadataIntent =
                new Intent(ACTION_FORCE_UPDATE_PLAYER);
            refreshMetadataIntent.putExtra(
                "refresh_metadata", true);
            sendBroadcast(refreshMetadataIntent);

            applyDeferredGenreFocus();
        }
    }

    /**
     * Handles a {@code REFRESH_PLAYLIST} event.
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onRefreshPlaylistEvent(
            BroadcastTranslator.RefreshPlaylistEvent event) {
        if (event == null) {
            return;
        }
        Log.d(TAG, "Refresh playlist received - refreshing "
            + "playlist from service");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (!mIsGenreLoading) {
                    refreshPlaylistFromService();
                } else {
                    Log.d(TAG, "Refresh playlist suppressed "
                        + "during genre loading");
                }
            }
        });
    }

    /**
     * Handles a {@code LIBRARY_RESET} event.
     *
     * <p>PlaylistActivity does not read {@code preserveSettings};
     * the extra is present in the event but not consumed.</p>
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onLibraryResetEvent(
            BroadcastTranslator.LibraryResetEvent event) {
        if (event == null) {
            return;
        }

        Log.d(TAG,
            "LIBRARY_RESET received — clearing display list");

        mCurrentDisplayList.clear();
        mCurrentPlayingPath = null;
        mDeferredGenreFocusRow = -1;
        mLastSeenGeneration = -1L;

        mIsGenreLoading = false;
        mPendingSortAfterGenre = false;
        mDeferredPlaylistRefresh = false;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mAdapter != null) {
                    mAdapter.setGenreLoading(false);
                }
                showEmptyView(R.string.playlist_empty_state);
                if (mAdapter != null) {
                    mAdapter.updateList(mCurrentDisplayList);
                    mAdapter.setCurrentPlayingPath(null);
                }
                updateTitleAndCount();
            }
        });
    }

    /**
     * Handles a {@code LANGUAGE_CHANGED} event.
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onLanguageChangedEvent(
            BroadcastTranslator.LanguageChangedEvent event) {
        if (event == null) {
            return;
        }
        if (!isFinishing() && !isDestroyed()) {
            recreateActivity();
        }
    }

    /**
     * Handles a {@code THEME_COLOR_CHANGED} event.
     *
     * <p>When the activity is resumed it recreates immediately, as
     * before. When it is not resumed the event is not dropped: the
     * recreate is deferred to {@link #onResume()} through
     * {@link #mThemeRecreationPending}, so a theme change made from
     * another surface still rebuilds this activity when it returns
     * to the foreground.</p>
     *
     * @param event The event posted by {@link BroadcastTranslator}
     */
    @org.greenrobot.eventbus.Subscribe
    public void onThemeColorChangedEvent(
            BroadcastTranslator.ThemeColorChangedEvent event) {
        if (event == null) {
            return;
        }
        if (!mIsResumed) {
            mThemeRecreationPending = true;
            return;
        }
        if (isFinishing() || isDestroyed()) {
            return;
        }
        recreateActivity();
    }

    // ============================================================================
    // Resolver
    // ============================================================================

    /**
     * Returns the song path a {@code METADATA_UPDATED} event refers
     * to.
     *
     * @param songPath The path the event carries, or null
     * @param songUri The URI the event carries, or null
     * @return The song path, or null when neither form resolves
     */
    @Nullable
    private String resolveBroadcastSongPath(
            @Nullable String songPath,
            @Nullable String songUri) {
        if (songPath != null && !songPath.isEmpty()) {
            return songPath;
        }
        if (songUri == null || songUri.isEmpty()) {
            return null;
        }
        try {
            final ArrayList<Song> all =
                SongDatabase.getInstance(this).getAllSongs();
            if (all != null) {
                for (Song song : all) {
                    if (song != null
                            && songUri.equals(song.getUri())) {
                        return song.getPath();
                    }
                }
            }
        } catch (Exception exception) {
            Log.w(TAG, "resolveBroadcastSongPath failed",
                exception);
        }
        return null;
    }

    // ============================================================================
    // Navigation
    // ============================================================================

    /**
     * Returns to the music player activity with the slide-left
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ============================================================================
    // Edge Fast Scroll
    // ============================================================================

    /**
     * Attaches the shared edge fast-scroll interceptor to the
     * playlist's RecyclerView.
     */
    private void setupEdgeFastScroll() {
        if (mPlaylistRecyclerView == null) {
            return;
        }

        EdgeScrollHelper.attach(mPlaylistRecyclerView);
    }

    // ============================================================================
    // Scroll Listener
    // ============================================================================

    /**
     * Attaches the scroll listener that tracks the user's
     * scrolling state.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(
            new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(
                    @NonNull RecyclerView recyclerView, int newState) {
                boolean scrolling =
                    (newState != RecyclerView.SCROLL_STATE_IDLE);
                mUserScrolling = scrolling;
                if (mAdapter != null) {
                    mAdapter.setScrolling(scrolling);
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView,
                                   int deltaX, int deltaY) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState =
                        mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    /**
     * Saves the current scroll position so it can be restored
     * after the next list update.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    /**
     * Restores the saved scroll position when one is pending.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null
                && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(
                    mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to restore scroll position", exception);
                mScrollRestorePending = false;
            }
        }
    }

    /**
     * Returns whether the given row is currently offscreen.
     *
     * @param row Row to test
     * @return True when the row is outside the visible range
     */
    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) {
            return false;
        }
        if (row < 0 || row >= mCurrentDisplayList.size()) {
            return false;
        }
        int firstVisibleRow =
            mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastVisibleRow =
            mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (firstVisibleRow == RecyclerView.NO_POSITION
                || lastVisibleRow == RecyclerView.NO_POSITION) {
            return false;
        }
        return row < firstVisibleRow || row > lastVisibleRow;
    }

    /**
     * Scrolls the given row into the vertical center of the list
     * when it is offscreen.
     *
     * @param row Row to scroll into view
     */
    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) {
            return;
        }
        if (!shouldAutoScrollTo(row)) {
            return;
        }
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                mLayoutManager.scrollToPositionWithOffset(
                    finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    /**
     * Applies the row stored in {@link #mDeferredGenreFocusRow} as
     * the scroll target and clears the deferred value.
     */
    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) {
            return;
        }
        int deferredRow = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(deferredRow);
    }

    // ============================================================================
    // Refresh
    // ============================================================================

    /**
     * Rebuilds the display list from the service's current
     * playlist.
     */
    private void refreshPlaylistFromService() {
        refreshPlaylistFromService(false);
    }

    /** Rebuilds from service when delayed event refreshes may run during scrolling. */
    private void refreshPlaylistFromService(boolean allowDuringScrolling) {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling && !allowDuringScrolling) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist =
            mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            mCurrentPlayingPath = null;
            mDeferredGenreFocusRow = -1;
            PlaybackScope scope = mMusicService.getPlaybackScope();
            boolean scopeRestricts = scope.kind
                != PlaybackScope.Kind.ALL_SONGS;
            showEmptyView(scopeRestricts
                ? R.string.playlist_empty_scope
                : R.string.playlist_empty_state);
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
                mAdapter.setCurrentPlayingPath(null);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100L);
    }

    // ============================================================================
    // Sort
    // ============================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode =
            preferences.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit()
            .putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    /**
     * Advances to the next sort mode, persists it, broadcasts the
     * change, and re-sorts the display list on a background thread.
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        notifyServiceOfSortMode();

        final ArrayList<Song> listToSort =
            new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int sortMode = mCurrentSortMode;
        final long sortStartedElapsed = SystemClock.elapsedRealtime();
        final long thisSortGeneration = ++mSortGeneration;

        OverlayManager.show(OverlayManager.REASON_PLAYLIST_SORT);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort,
                    getComparatorForSortMode(sortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            cancelSortOverlayHide();
                            OverlayManager.hide(
                                OverlayManager.REASON_PLAYLIST_SORT);
                            return;
                        }

                        if (thisSortGeneration != mSortGeneration) {
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList, true);
                        }

                        if (currentPath != null) {
                            int newPosition =
                                findPositionByPath(currentPath);
                            if (newPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                if (mAdapter != null) {
                                    mAdapter.setCurrentPlayingIndex(
                                        newPosition);
                                }
                            }
                        }

                        scrollToCurrentSongImmediately();

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(
                            PlaylistActivity.this,
                            getString(SORT_TOAST_RES[mCurrentSortMode]),
                            ToastManager.LENGTH_NORMAL);

                        hideSortOverlayAfterListSettles(
                            thisSortGeneration, sortStartedElapsed);
                    }
                });
            }
        }).start();
    }

    /**
     * Cancels any pending sort-overlay hide. Idempotent.
     */
    private void cancelSortOverlayHide() {
        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
    }

    /**
     * Scrolls the RecyclerView to the current song's new position
     * synchronously.
     */
    private void scrollToCurrentSongImmediately() {
        if (mPlaylistRecyclerView == null || mLayoutManager == null
                || mCurrentPlayingPath == null
                || mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mUserScrolling || mIsGenreLoading
                || mUserInteractionInProgress) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null
                    && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }
        if (targetPosition < 0) {
            return;
        }

        mLayoutManager.scrollToPositionWithOffset(
            targetPosition, mPlaylistRecyclerView.getHeight() / 2);
    }

    /**
     * Schedules the sort overlay's hide for the moment the
     * RecyclerView has settled with the sorted list.
     */
    private void hideSortOverlayAfterListSettles(
            final long sortGeneration,
            final long sortStartedElapsed) {
        if (mPlaylistRecyclerView == null) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        final ViewTreeObserver observer =
            mPlaylistRecyclerView.getViewTreeObserver();
        if (!observer.isAlive()) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        observer.addOnPreDrawListener(
            new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                final ViewTreeObserver current =
                    mPlaylistRecyclerView.getViewTreeObserver();
                if (current.isAlive()) {
                    current.removeOnPreDrawListener(this);
                }
                mPlaylistRecyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (sortGeneration != mSortGeneration) {
                            return;
                        }
                        scheduleSortOverlayHideAtMinDuration(
                            sortStartedElapsed);
                    }
                });
                return true;
            }
        });
    }

    /**
     * Schedules the sort overlay's hide for the end of the
     * {@link #SORT_OVERLAY_MIN_DURATION_MS} floor.
     */
    private void scheduleSortOverlayHideAtMinDuration(
            final long sortStartedElapsed) {
        final long elapsed = SystemClock.elapsedRealtime()
            - sortStartedElapsed;
        final long remaining = Math.max(0L,
            SORT_OVERLAY_MIN_DURATION_MS - elapsed);
        scheduleSortOverlayHide(remaining);
    }

    /**
     * Schedules the sort overlay's hide after the given delay.
     */
    private void scheduleSortOverlayHide(long delayMs) {
        cancelSortOverlayHide();
        mSortOverlayHideRunnable = new Runnable() {
            @Override
            public void run() {
                mSortOverlayHideRunnable = null;
                OverlayManager.hide(
                    OverlayManager.REASON_PLAYLIST_SORT);
            }
        };
        mMainHandler.postDelayed(mSortOverlayHideRunnable, delayMs);
    }

    /**
     * Sends the selected sort mode to the playback service directly.
     * The broadcast remains as a fallback if the service is not bound.
     */
    private void notifyServiceOfSortMode() {
        if (mMusicService != null) {
            mMusicService.applyPlaylistSortMode(mCurrentSortMode);
            return;
        }
        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);
    }


    /**
     * Sorts the display list in place by the current sort mode.
     *
     * @param showToast True to notify the service of the sort
     *        change and show a toast
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList,
            getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            notifyServiceOfSortMode();
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling
                                        && !mIsGenreLoading
                                        && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this,
                getString(SORT_TOAST_RES[mCurrentSortMode]),
                ToastManager.LENGTH_NORMAL);
        }
    }

    /**
     * Returns the index of the song with the given path in the
     * display list, or -1 when it is not present.
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0L;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the
     * given sort mode.
     */
    private Comparator<Song> getComparatorForSortMode(
            final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return firstSong.getTitle()
                            .compareToIgnoreCase(
                                secondSong.getTitle());
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return secondSong.getTitle()
                            .compareToIgnoreCase(
                                firstSong.getTitle());
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getArtist()
                            .compareToIgnoreCase(
                                secondSong.getArtist());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getArtist()
                            .compareToIgnoreCase(
                                firstSong.getArtist());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getAlbum()
                            .compareToIgnoreCase(
                                secondSong.getAlbum());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getAlbum()
                            .compareToIgnoreCase(
                                firstSong.getAlbum());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = firstSong.getGenre()
                            .compareToIgnoreCase(
                                secondSong.getGenre());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        int comparisonResult = secondSong.getGenre()
                            .compareToIgnoreCase(
                                firstSong.getGenre());
                        if (comparisonResult == 0) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            firstDate, secondDate);
                        if (comparisonResult == 0L) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            secondDate, firstDate);
                        if (comparisonResult == 0L) {
                            return firstSong.getTitle()
                                .compareToIgnoreCase(
                                    secondSong.getTitle());
                        }
                        return comparisonResult;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        return firstSong.getTitle()
                            .compareToIgnoreCase(
                                secondSong.getTitle());
                    }
                };
        }
    }

    /**
     * Updates the header to show the current sort mode or search
     * context, and toggles the sort button visibility.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText(
                getString(R.string.playlist_sort_mode_prefix)
                    + SORT_MODE_LABEL_SEPARATOR
                    + getString(SORT_LABEL_RES[mCurrentSortMode]));
            if (mSortButton != null
                    && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText(R.string.playlist_search_results);
            if (mSortButton != null
                    && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ============================================================================
    // Display
    // ============================================================================

    /**
     * Shows the empty-state placeholder in the slot the playlist
     * occupies.
     */
    private void showEmptyView(@StringRes int messageRes) {
        if (mEmptyContainer != null) {
            final ViewParent existingParent = mEmptyContainer.getParent();
            if (existingParent instanceof ViewGroup) {
                ((ViewGroup) existingParent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText(messageRes);
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mPlaylistRecyclerView != null) {
            final ViewParent parent = mPlaylistRecyclerView.getParent();
            if (parent instanceof LinearLayout) {
                final LinearLayout parentLayout =
                    (LinearLayout) parent;
                final LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0, 1f);
                parentLayout.addView(mEmptyContainer, params);
            }
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    /**
     * Removes the empty-state placeholder and shows the playlist.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent parent = mEmptyContainer.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Creates the playlist adapter and attaches it to the
     * recycler view.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList,
            new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(
                    PlaylistActivity.this, MusicService.class);
                intent.setAction(ACTION_PLAY_SONG);
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            // Refresh first, before highlighting.
                            // The service re-evaluates scope membership
                            // in rebuildPlaylists() when the tapped
                            // song commits (onPrepared): songs that are
                            // no longer in scope and no longer
                            // current/target drop out of
                            // getCurrentPlaylist(), and re-reading it
                            // here evicts them from the displayed
                            // list. The tapped song itself survives
                            // as the grace-period current/target when
                            // it committed, even if it is out of scope.
                            refreshPlaylistFromService(true);
                            if (findPositionByPath(selectedPath) < 0) {
                                // Evicted: the service never made this
                                // song current (it was already out of
                                // the displayed list). Do not highlight
                                // a row that is no longer displayed;
                                // the next UPDATE_PLAYER broadcast
                                // corrects mCurrentPlayingPath.
                                if (mAdapter != null) {
                                    mAdapter.setCurrentPlayingIndex(-1);
                                }
                                return;
                            }
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition =
                                    findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(
                                    newPosition);
                            }
                        } catch (Exception exception) {
                            Log.e(TAG,
                                "Error setting playing index",
                                exception);
                        } finally {
                            mUserInteractionInProgress = false;
                        }
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        mAdapter.setFavoriteListener((path, favorite) ->
            mPendingFavorites.stage(path, favorite));

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Updates the header and song count text from the current
     * search and display state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText(
                    getString(R.string.playlist_sort_mode_prefix)
                        + SORT_MODE_LABEL_SEPARATOR
                        + getString(SORT_LABEL_RES[mCurrentSortMode]));
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(
                    getResources().getQuantityString(
                        R.plurals.song_count,
                        songCount,
                        songCount));
            }
        } else {
            int totalSongs = (mMusicService != null
                && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText(R.string.playlist_search_results);
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(
                    songCount + " / "
                    + getResources().getQuantityString(
                        R.plurals.song_count,
                        totalSongs,
                        totalSongs));
            }
        }
    }

    /**
     * Reads the persisted last playing path into memory.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath =
            preferences.getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Scrolls the current song into the vertical center of the
     * list when it is offscreen and the user is not interacting
     * with the list.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG,
                "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null
                || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null
                    && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisibleRow =
                        mLayoutManager
                            .findFirstCompletelyVisibleItemPosition();
                    int lastVisibleRow =
                        mLayoutManager
                            .findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisibleRow
                            || finalPosition > lastVisibleRow) {
                        mLayoutManager.scrollToPositionWithOffset(
                            finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization
    // ============================================================================

    /**
     * Resolves every view, attaches touch animations and click
     * handlers, and creates the adapter.
     */
    private void initializeViews() {
        mPlaylistRecyclerView =
            (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        if (mSearchText != null) {
            mSearchText.setFilters(
                new android.text.InputFilter[] {
                    new android.text.InputFilter.LengthFilter(
                        MAX_SEARCH_LENGTH)
            });
            // The hint only ellipsizes while horizontal
            // scrolling is off. Start in hint mode: ellipsize on,
            // scrolling off. setupSearchListener() toggles it as
            // the user types (see afterTextChanged below).
            mSearchText.setEllipsize(
                    android.text.TextUtils.TruncateAt.END);
            mSearchText.setHorizontallyScrolling(false);
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Search
    // ============================================================================

    /**
     * Attaches the search text watcher, the editor action
     * listener, and the clear button handler.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence text, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence text, int start,
                                          int before, int count) {
                    performSearch(text.toString());
                }

                @Override
                public void afterTextChanged(Editable text) {
                    // hint vs typing need opposite settings.
                    // Empty -> hint shows, so ellipsize on and
                    // scrolling off so the placeholder truncates
                    // with "...". Typing -> ellipsize off and
                    // scrolling on so a long query scrolls instead
                    // of being cut off.
                    if (mSearchText == null) {
                        return;
                    }
                    final boolean empty =
                            text == null || text.length() == 0;
                    mSearchText.setEllipsize(empty
                            ? android.text.TextUtils.TruncateAt.END
                            : null);
                    mSearchText.setHorizontallyScrolling(!empty);
                }
            });

            mSearchText.setOnEditorActionListener(
                new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView view,
                                              int actionId,
                                              KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH
                            || actionId == EditorInfo.IME_ACTION_DONE
                            || (event != null
                                && event.getKeyCode()
                                    == KeyEvent.KEYCODE_ENTER
                                && event.getAction()
                                    == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager inputMethodManager =
                            (InputMethodManager) getSystemService(
                                Context.INPUT_METHOD_SERVICE);
                        if (inputMethodManager != null
                                && mSearchText != null) {
                            inputMethodManager
                                .hideSoftInputFromWindow(
                                    mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    /**
     * Filters the service's current playlist by the given query
     * and writes the result into the display list.
     *
     * @param query The search text; an empty or whitespace-only
     *        query matches every song
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs =
            mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase()
                                .contains(lowerQuery))
                            || (artist != null && artist.toLowerCase()
                                .contains(lowerQuery))
                            || (album != null && album.toLowerCase()
                                .contains(lowerQuery))
                            || (genre != null && genre.toLowerCase()
                                .contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    /**
     * Shows the search bar and requests focus on the search
     * field.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(
                    mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    /**
     * Hides the search bar, clears the query, refreshes the
     * display list, and scrolls the current song into view.
     *
     * <p>The scroll is posted after the same delay the sort path
     * uses, so the adapter has laid out the restored, unfiltered
     * list before the target row is measured. It is suppressed
     * while the user is scrolling or interacting, or while genre
     * loading is in flight, exactly like the other focus calls.</p>
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(
                    mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!mUserScrolling && !mIsGenreLoading
                        && !mUserInteractionInProgress) {
                    focusCurrentSong();
                }
            }
        }, FOCUS_SCROLL_DELAY_MS);
    }

    // ============================================================================
    // Theme
    // ============================================================================

    /**
     * Applies the current theme color to every control in the
     * activity and to the search bar background.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(
                mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(
                mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(
                mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(
                mSortButton, mSortButton.isEnabled());
        }

        if (mSearchBar != null) {
            GradientDrawable searchBarBorder =
                new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(
                dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(
                dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground =
                new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(
                dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAdapter != null && mAdapter.getItemCount() > 0) {
            mAdapter.notifyItemRangeChanged(0, mAdapter.getItemCount());
        }
        forceRedraw();
    }

    /**
     * Applies the header text color to every header TextView in
     * the activity.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews
     * in the given view hierarchy whose text names the playlist.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        final String playlistTitleText =
            getString(R.string.playlist_title);

        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView
                    && !(child instanceof Button)
                    && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                if (playlistTitleText.equals(
                        textView.getText().toString())) {
                    textView.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Forces the activity content to re-measure, re-layout, and re-draw.
     */
    private void forceRedraw() {
        View root = findViewById(android.R.id.content);
        if (root == null) {
            return;
        }
        root.requestLayout();
        root.invalidate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation();
        }
    }

    /**
     * Recreates the activity.
     *
     * <p>The incoming activity builds its resources from
     * {@code attachBaseContext}, which applies the current locale
     * through {@link LanguageManager#wrap(Context)} and the current
     * theme through {@link ThemeManager} in its own
     * {@code onCreate}.</p>
     */
    private void recreateActivity() {
        if (mRecreationPending || isFinishing() || isDestroyed()) {
            return;
        }
        mRecreationPending = true;
        final View decor = getWindow() != null
            ? getWindow().getDecorView() : null;
        if (decor == null) {
            mRecreationPending = false;
            return;
        }
        decor.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                recreate();
                overridePendingTransition(0, 0);
            }
        });
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(
            getResources().getDisplayMetrics().density * dp);
    }
}