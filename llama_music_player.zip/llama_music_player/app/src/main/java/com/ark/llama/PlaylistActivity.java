package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Activity for displaying and managing the current playlist.
 * 
 * <p>This activity ONLY DISPLAYS state from MusicService. It does NOT store
 * its own copy of the playlist or make playback decisions independently.</p>
 * 
 * <p>State flows: MusicService → Broadcast → PlaylistActivity (display only)</p>
 * <p>Commands flow: PlaylistActivity → MusicService (via bound methods)</p>
 * 
 * @author Richard Korbla Adzido
 * @version 2.0.0
 * @since 2.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "PlaylistActivity";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final int ANIMATION_DURATION_MS = 80;
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    private static final int MAX_SEARCH_LENGTH = 128;
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    
    // ========================================================================
    // Sort Constants
    // ========================================================================
    
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;
    private static final int SORT_MODE_COUNT = 10;
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]", "[TITLE Z-A]", "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]", "[ALBUM Z-A]", "[GENRE A-Z]", "[GENRE Z-A]",
        "[OLDEST]", "[NEWEST]"
    };
    
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]", "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]", "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]", "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]", "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST", "SORT MODE: NEWEST"
    };
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    private RecyclerView mPlaylistRecyclerView;
    private PlaylistAdapter mAdapter;
    private TextView mPlaylistTitle;
    private TextView mSongCountText;
    private EditText mSearchEditText;
    private Button mSearchButton;
    private Button mClearSearchButton;
    private LinearLayout mSearchBar;
    private Button mCancelButton;
    private LinearLayout mEmptyContainer;
    private FrameLayout mRootContainer;
    private TextView mSortButton;
    
    // ========================================================================
    // Service Connection (SINGLE SOURCE OF TRUTH)
    // ========================================================================
    
    @Nullable private MusicService mMusicService;
    private boolean mIsServiceBound = false;
    private final Object mServiceLock = new Object();
    
    // ========================================================================
    // Display State (NO LOCAL PLAYLIST COPY)
    // ========================================================================
    
    private ArrayList<Song> mCurrentDisplayList = new ArrayList<>();
    private int mCurrentPlayingIndex = -1;
    private String mCurrentPlayingPath = null;
    private boolean mIsSearchVisible = false;
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Executor for background operations
    // ========================================================================
    
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    private ThemeManager mThemeManager;
    private ThemeHelper mThemeHelper;
    private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    private long mLastSearchClickTime = 0;
    private long mLastCancelClickTime = 0;
    private long mLastSortClickTime = 0;
    private volatile boolean mUserInteractionInProgress = false;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private InputMethodManager mInputMethodManager;
    
    // ========================================================================
    // Broadcast Receivers (Receiving state FROM service)
    // ========================================================================
    
    private BroadcastReceiver mUpdatePlayerReceiver;
    private BroadcastReceiver mDisplayPlaylistReceiver;
    private BroadcastReceiver mForceUpdatePlayerReceiver;
    private BroadcastReceiver mGenreUpdateReceiver;
    private BroadcastReceiver mForceRefreshReceiver;
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            requestCurrentPlaylistFromService();
        }
        
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            mMusicService = null;
        }
    };
    
    // ========================================================================
    // Activity Lifecycle
    // ========================================================================
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_playlist);
        
        CharacterMapper.init(this);
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        
        loadSortMode();
        initializeViews();
        setupSearchListener();
        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();
        registerSortModeReceiver();
        registerThemeReceiver();
        
        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
        
        applyThemeToUI();
        themeAllHeaders();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        if (mIsServiceBound && mMusicService != null) {
            requestCurrentPlaylistFromService();
        }
        
        if (mAdapter != null) {
            mAdapter.setCurrentPlayingIndex(mCurrentPlayingIndex);
            if (TextUtils.isEmpty(getSearchQuery())) {
                if (!mUserInteractionInProgress) {
                    focusCurrentSong();
                }
            }
        }
        
        if (mSortButton != null && mThemeHelper != null) {
            mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        updateSortHeaderDisplay();
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        if (mThemeReceiver != null) {
            try { unregisterReceiver(mThemeReceiver); } catch (Exception e) {}
            mThemeReceiver = null;
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mIsServiceBound) {
            try { unbindService(mServiceConnection); } catch (Exception e) {}
        }
        
        ToastManager.hidePersistentOverlay();
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        
        mMainHandler.removeCallbacksAndMessages(null);
        mExecutor.shutdown();
    }
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }
    
    // ========================================================================
    // Service Communication Methods
    // ========================================================================
    
    private void requestCurrentPlaylistFromService() {
        if (mMusicService == null) return;
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Song> playlist = mMusicService.getFullPlaylist();
                final int currentIndex = mMusicService.getCurrentIndex();
                final int sortMode = mMusicService.getCurrentSortMode();
                final Song currentSong = (currentIndex >= 0 && playlist != null && currentIndex < playlist.size()) 
                    ? playlist.get(currentIndex) : null;
                final String currentPath = (currentSong != null) ? currentSong.getPath() : null;
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mCurrentSortMode != sortMode) {
                            mCurrentSortMode = sortMode;
                            saveSortMode();
                            updateSortHeaderDisplay();
                        }
                        
                        if (playlist != null && !playlist.isEmpty()) {
                            updateDisplayList(playlist, currentPath);
                            hideEmptyView();
                        } else {
                            mCurrentDisplayList.clear();
                            showEmptyView();
                        }
                        
                        mCurrentPlayingIndex = currentIndex;
                        mCurrentPlayingPath = currentPath;
                        
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                            mAdapter.setCurrentPlayingIndex(currentIndex);
                        }
                        
                        updateTitleAndCount();
                        
                        if (!mCurrentDisplayList.isEmpty() && !mUserInteractionInProgress && !mIsSearchVisible) {
                            focusCurrentSong();
                        }
                    }
                });
            }
        });
    }
    
    private void updateDisplayList(ArrayList<Song> playlist, @Nullable String currentPath) {
        String searchQuery = getSearchQuery();
        
        if (TextUtils.isEmpty(searchQuery)) {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
        } else {
            ArrayList<Song> results = new ArrayList<>();
            String lowerQuery = searchQuery.toLowerCase().trim();
            for (Song song : playlist) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        results.add(song);
                    }
                }
            }
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(results);
            applyCurrentSort(false);
        }
        
        if (currentPath != null) {
            int displayPosition = -1;
            for (int i = 0; i < mCurrentDisplayList.size(); i++) {
                Song song = mCurrentDisplayList.get(i);
                if (song != null && currentPath.equals(song.getPath())) {
                    displayPosition = i;
                    break;
                }
            }
            mCurrentPlayingIndex = displayPosition;
        } else {
            mCurrentPlayingIndex = -1;
        }
    }
    
    private void sendCommandToService(@NonNull Runnable command) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                command.run();
            }
        }
    }
    
    // ========================================================================
    // Sort Methods
    // ========================================================================
    
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();
        
        sendCommandToService(new Runnable() {
            @Override
            public void run() {
                if (mMusicService != null) {
                    mMusicService.setSortMode(mCurrentSortMode);
                }
            }
        });
        
        applyCurrentSort(true);
        updateSortHeaderDisplay();
        
        ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        
        if (!mUserInteractionInProgress && !mIsSearchVisible) {
            focusCurrentSong();
        }
    }
    
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) return;
        
        String currentSongPath = mCurrentPlayingPath;
        
        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));
        
        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);
            
            if (currentSongPath != null) {
                int newPosition = findPositionByPath(currentSongPath);
                if (newPosition >= 0) {
                    mCurrentPlayingIndex = newPosition;
                    mAdapter.setCurrentPlayingIndex(newPosition);
                }
            }
        }
        
        updateTitleAndCount();
    }
    
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) return -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && path.equals(song.getPath())) return i;
        }
        return -1;
    }
    
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleB.compareToIgnoreCase(titleA);
                    }
                };
            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        int artistCompare = artistA.compareToIgnoreCase(artistB);
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        int artistCompare = artistB.compareToIgnoreCase(artistA);
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        int albumCompare = albumA.compareToIgnoreCase(albumB);
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        int albumCompare = albumB.compareToIgnoreCase(albumA);
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        int genreCompare = genreA.compareToIgnoreCase(genreB);
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        int genreCompare = genreB.compareToIgnoreCase(genreA);
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        int dateCompare = Long.compare(dateA, dateB);
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        int dateCompare = Long.compare(dateB, dateA);
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
        }
    }
    
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle != null) {
            String searchText = getSearchQuery();
            if (TextUtils.isEmpty(searchText)) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                    mSortButton.setVisibility(View.VISIBLE);
                }
            } else {
                mPlaylistTitle.setText("SEARCH RESULTS");
                if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                    mSortButton.setVisibility(View.GONE);
                }
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    // ========================================================================
    // Display Methods
    // ========================================================================
    
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) return;
                
                mUserInteractionInProgress = true;
                
                sendCommandToService(new Runnable() {
                    @Override
                    public void run() {
                        if (mMusicService != null) {
                            mMusicService.playSongByPath(song.getPath());
                        }
                    }
                });
                
                final int selectedPosition = position;
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingIndex = selectedPosition;
                            mCurrentPlayingPath = song.getPath();
                            if (mAdapter != null && selectedPosition < mAdapter.getItemCount()) {
                                mAdapter.setCurrentPlayingIndex(selectedPosition);
                                focusCurrentSong();
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting playing index", e);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });
        
        mAdapter.setCurrentPlayingIndex(mCurrentPlayingIndex);
        
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(layoutManager);
        mPlaylistRecyclerView.setAdapter(mAdapter);
    }
    
    private void updateTitleAndCount() {
        String searchText = getSearchQuery();
        
        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " songs");
            }
        } else {
            int totalSongs = 0;
            if (mMusicService != null) {
                ArrayList<Song> fullPlaylist = mMusicService.getFullPlaylist();
                if (fullPlaylist != null) totalSongs = fullPlaylist.size();
            }
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " / " + totalSongs + " songs");
            }
        }
    }
    
    private void focusCurrentSong() {
        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) return;
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) return;
        if (mAdapter.getItemCount() == 0) return;
        
        String lastSongPath = mCurrentPlayingPath;
        if (lastSongPath == null) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            lastSongPath = prefs.getString(KEY_LAST_SONG_PATH, null);
        }
        
        if (lastSongPath == null) return;
        
        int targetPosition = -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && lastSongPath.equals(song.getPath())) {
                targetPosition = i;
                break;
            }
        }
        
        if (targetPosition >= 0) {
            mAdapter.setCurrentPlayingIndex(targetPosition);
            
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    RecyclerView.LayoutManager layoutManager = mPlaylistRecyclerView.getLayoutManager();
                    if (layoutManager instanceof LinearLayoutManager) {
                        LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
                        int firstVisible = linearManager.findFirstCompletelyVisibleItemPosition();
                        int lastVisible = linearManager.findLastCompletelyVisibleItemPosition();
                        
                        if (finalPosition < firstVisible || finalPosition > lastVisible) {
                            linearManager.scrollToPositionWithOffset(finalPosition,
                                mPlaylistRecyclerView.getHeight() / 2);
                        }
                    }
                }
            });
        }
    }
    
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));
            
            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);
            
            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer, 
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, 
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }
        
        if (mPlaylistRecyclerView != null) mPlaylistRecyclerView.setVisibility(View.GONE);
        if (mSearchBar != null) mSearchBar.setVisibility(View.GONE);
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }
    
    private void hideEmptyView() {
        if (mEmptyContainer != null) mEmptyContainer.setVisibility(View.GONE);
        if (mPlaylistRecyclerView != null) mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) mSearchBar.setVisibility(View.VISIBLE);
    }
    
    private String getSearchQuery() {
        return mSearchEditText != null ? mSearchEditText.getText().toString() : "";
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization
    // ========================================================================
    
    private void initializeViews() {
        mPlaylistRecyclerView = findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = findViewById(R.id.playlistTitle);
        mSongCountText = findViewById(R.id.songCountText);
        mSearchEditText = findViewById(R.id.searchEditText);
        mSearchButton = findViewById(R.id.searchButton);
        mClearSearchButton = findViewById(R.id.clearSearchButton);
        mSearchBar = findViewById(R.id.searchBar);
        mCancelButton = findViewById(R.id.cancelButton);
        mRootContainer = findViewById(R.id.rootContainer);
        
        if (mSearchEditText != null) {
            mSearchEditText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }
        
        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearSearchButton);
        
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });
        }
        
        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }
        
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }
        
        setupSortButton();
        setupAdapter();
    }
    
    private void setupSortButton() {
        mSortButton = findViewById(R.id.sortButton);
        
        if (mSortButton == null) return;
        
        int themeColor = mThemeHelper.getThemeColorInt();
        mSortButton.setTextColor(themeColor);
        
        mSortButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
        
        mSortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = currentTime;
                    cycleSortMode();
                }
            }
        });
    }
    
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Search Methods
    // ========================================================================
    
    private void setupSearchListener() {
        if (mSearchEditText != null) {
            mSearchEditText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }
                @Override public void afterTextChanged(Editable s) {}
            });
            
            mSearchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        if (mInputMethodManager != null && mSearchEditText != null) {
                            mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });
            
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
        }
        
        if (mClearSearchButton != null) {
            mClearSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSearchEditText != null) {
                        mSearchEditText.setText("");
                    }
                }
            });
        }
    }
    
    private void performSearch(@NonNull String query) {
        if (mMusicService == null) return;
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Song> fullPlaylist = mMusicService.getFullPlaylist();
                final String currentPath = mCurrentPlayingPath;
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fullPlaylist == null) return;
                        
                        if (query.trim().isEmpty()) {
                            updateDisplayList(fullPlaylist, currentPath);
                        } else {
                            ArrayList<Song> results = new ArrayList<>();
                            String lowerQuery = query.toLowerCase().trim();
                            for (Song song : fullPlaylist) {
                                if (song != null) {
                                    String title = song.getTitle();
                                    String artist = song.getArtist();
                                    String album = song.getAlbum();
                                    String genre = song.getGenre();
                                    
                                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                                        results.add(song);
                                    }
                                }
                            }
                            mCurrentDisplayList.clear();
                            mCurrentDisplayList.addAll(results);
                            applyCurrentSort(false);
                            
                            if (mAdapter != null) {
                                mAdapter.updateList(mCurrentDisplayList);
                            }
                        }
                        
                        updateTitleAndCount();
                        
                        if (query.trim().isEmpty() && !mUserInteractionInProgress) {
                            focusCurrentSong();
                        }
                    }
                });
            }
        });
    }
    
    private void showSearch() {
        if (mSearchBar != null) mSearchBar.setVisibility(View.VISIBLE);
        mIsSearchVisible = true;
        
        if (mSortButton != null) mSortButton.setVisibility(View.GONE);
        
        if (mSearchEditText != null) {
            mSearchEditText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchEditText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }
    
    private void hideSearch() {
        if (mSearchBar != null) mSearchBar.setVisibility(View.GONE);
        mIsSearchVisible = false;
        
        if (mSortButton != null) mSortButton.setVisibility(View.VISIBLE);
        
        if (mSearchEditText != null) {
            mSearchEditText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
            }
        }
        
        performSearch("");
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();
                    
                    if (mSortButton != null && mThemeHelper != null) {
                        mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"GENRE_UPDATE".equals(intent.getAction())) return;
                
                String status = intent.getStringExtra("status");
                
                if ("START".equals(status)) {
                    ToastManager.showPersistentOverlay(PlaylistActivity.this, "Loading metadata...");
                } else if ("UPDATE".equals(status)) {
                    String songPath = intent.getStringExtra("song_path");
                    String genre = intent.getStringExtra("genre");
                    int current = intent.getIntExtra("current", 0);
                    int total = intent.getIntExtra("total", 0);
                    
                    ToastManager.updatePersistentOverlay("Loading metadata... " + current + "/" + total);
                    
                    if (mAdapter != null && songPath != null && genre != null) {
                        mAdapter.updateSongGenre(songPath, genre);
                    }
                } else if ("COMPLETE".equals(status)) {
                    ToastManager.hidePersistentOverlay();
                    requestCurrentPlaylistFromService();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }
    
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    requestCurrentPlaylistFromService();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }
    
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        applyCurrentSort(false);
                        updateSortHeaderDisplay();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    requestCurrentPlaylistFromService();
                }
            }
        };
        
        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    requestCurrentPlaylistFromService();
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    requestCurrentPlaylistFromService();
                }
            }
        };
        
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mDisplayPlaylistReceiver, "DISPLAY_PLAYLIST");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
    }
    
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception e) {}
        }
    }
    
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        if (mSongCountText != null) mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") || 
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }
    
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();
        
        if (mCancelButton != null) mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        if (mSearchButton != null) mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        if (mClearSearchButton != null) mThemeHelper.updateButton(mClearSearchButton, mClearSearchButton.isEnabled());
        
        if (mSortButton != null) mSortButton.setTextColor(themeColor);
        
        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }
        
        if (mSearchEditText != null) {
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
            
            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchEditText.setBackground(searchBackground);
            
            mSearchEditText.setTextColor(themeColor);
        }
        
        if (mPlaylistTitle != null) mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        if (mSongCountText != null) mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        
        if (mAdapter != null) mAdapter.notifyDataSetChanged();
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}