package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Activity for displaying the current playlist.
 * 
 * <p>This activity follows the single‑source‑of‑truth principle: it never stores
 * its own copy of the playlist nor applies local sorting. All data is read directly
 * from MusicService, and the service broadcasts playlist changes when sort mode
 * or playback order changes. The activity only renders and sends commands.</p>
 * 
 * <h3>Key Improvements</h3>
 * <ul>
 *   <li>No local sort logic – playlist displayed exactly as in service</li>
 *   <li>No local copy of songs – adapter reads from service on each refresh</li>
 *   <li>Playlist changes broadcast by service trigger UI refresh</li>
 *   <li>Sort mode change sent to service, not applied locally</li>
 *   <li>Safe service binding with ready flag</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "PlaylistActivity";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final int ANIMATION_DURATION_MS = 80;
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    private static final int MAX_SEARCH_LENGTH = 128;
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    // ========================================================================
    // UI Components
    // ========================================================================
    
    private RecyclerView mPlaylistRecyclerView;
    private PlaylistAdapter mAdapter;
    private TextView mPlaylistTitle;
    private TextView mSongCountText;
    private EditText mSearchEditText;
    private Button mSearchButton;
    private Button mClearSearchButton;
    private LinearLayout mSearchBar;
    private Button mCancelButton;
    private FrameLayout mRootContainer;
    private LinearLayout mEmptyContainer;
    private TextView mSortButton;

    // ========================================================================
    // Data & State
    // ========================================================================
    
    private MusicLibrary mMusicLibrary;
    private MusicService mMusicService;
    private boolean mIsServiceBound = false;
    private boolean mServiceReady = false;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private InputMethodManager mInputMethodManager;
    private boolean mIsSearchVisible = false;
    private volatile boolean mUserInteractionInProgress = false;
    private int mCurrentPlayingIndex = -1;

    // ========================================================================
    // Theme
    // ========================================================================
    
    private ThemeManager mThemeManager;
    private ThemeHelper mThemeHelper;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mPlaylistChangedReceiver;
    private BroadcastReceiver mUpdatePlayerReceiver;
    private BroadcastReceiver mForceUpdatePlayerReceiver;

    // ========================================================================
    // Sort Mode (only for UI display, not for sorting)
    // ========================================================================
    
    private static final int SORT_TITLE_AZ = 0;
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]", "[TITLE Z-A]", "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]", "[ALBUM Z-A]", "[GENRE A-Z]", "[GENRE Z-A]",
        "[OLDEST]", "[NEWEST]"
    };
    private int mCurrentSortMode = SORT_TITLE_AZ;
    private long mLastSortClickTime = 0;

    // ========================================================================
    // Service Connection
    // ========================================================================
    
    private final android.content.ServiceConnection mServiceConnection = new android.content.ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, android.os.IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mServiceReady = true;
            loadCurrentPlayingIndex();
            refreshPlaylistFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mServiceReady = false;
            mIsServiceBound = false;
        }
    };

    // ========================================================================
    // Activity Lifecycle
    // ========================================================================
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_playlist);
        
        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        
        loadCurrentPlayingIndex();
        loadSortModeFromPrefs();
        initializeViews();
        setupSearchListener();
        registerReceivers();
        applyThemeToUI();
        themeAllHeaders();
        
        // Bind to MusicService to get the live playlist
        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        if (mThemeReceiver == null) registerThemeReceiver();
        if (mServiceReady && mMusicService != null) {
            refreshPlaylistFromService();
        }
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mThemeReceiver != null) {
            try { unregisterReceiver(mThemeReceiver); } catch (Exception ignored) {}
            mThemeReceiver = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mIsServiceBound) {
            try { unbindService(mServiceConnection); } catch (Exception ignored) {}
        }
        unregisterReceiverSafely(mPlaylistChangedReceiver);
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        mMainHandler.removeCallbacksAndMessages(null);
        ToastManager.hidePersistentOverlay();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ========================================================================
    // Navigation
    // ========================================================================
    
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ========================================================================
    // Playlist Refresh (from Service)
    // ========================================================================
    
    private void refreshPlaylistFromService() {
        if (!mServiceReady || mMusicService == null) return;
        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null) playlist = new ArrayList<>();
        
        if (playlist.isEmpty()) {
            showEmptyView();
        } else {
            hideEmptyView();
        }
        
        // Update adapter – adapter displays playlist as is, no sorting
        if (mAdapter == null) {
            mAdapter = new PlaylistAdapter(this, playlist, new PlaylistAdapter.OnSongClickListener() {
                @Override
                public void onSongClick(int position, @NonNull Song song) {
                    if (TextUtils.isEmpty(song.getPath())) return;
                    mUserInteractionInProgress = true;
                    Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                    intent.setAction("PLAY_SONG");
                    intent.putExtra("song_path", song.getPath());
                    startService(intent);
                    mMainHandler.postDelayed(() -> {
                        mCurrentPlayingIndex = position;
                        if (mAdapter != null) mAdapter.setCurrentPlayingIndex(position);
                        focusCurrentSong();
                        mUserInteractionInProgress = false;
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            });
            mPlaylistRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            mPlaylistRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.updateList(playlist);
        }
        
        // Update playing index
        String currentPath = getCurrentSongPath();
        int playingPos = -1;
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getPath().equals(currentPath)) {
                playingPos = i;
                break;
            }
        }
        mCurrentPlayingIndex = playingPos;
        mAdapter.setCurrentPlayingIndex(playingPos);
        
        updateTitleAndCount(playlist.size());
        if (!mIsSearchVisible && !mUserInteractionInProgress) {
            focusCurrentSong();
        }
    }

    private String getCurrentSongPath() {
        if (mServiceReady && mMusicService != null) {
            Song current = mMusicService.getCurrentSong();
            if (current != null) return current.getPath();
        }
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }

    // ========================================================================
    // Sort Mode (Send to Service, Do Not Sort Locally)
    // ========================================================================
    
    private void loadSortModeFromPrefs() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt("playlist_sort_mode", SORT_TITLE_AZ);
    }

    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_DISPLAY_NAMES.length;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt("playlist_sort_mode", mCurrentSortMode).apply();
        
        // Broadcast to MusicService – service will reorder its own playlist
        Intent intent = new Intent(ACTION_UPDATE_SORT_MODE);
        intent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(intent);
        
        ToastManager.showToast(this, "SORT MODE: " + SORT_DISPLAY_NAMES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        updateSortHeaderDisplay();
    }

    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle != null) {
            String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
            if (TextUtils.isEmpty(searchText)) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                if (mSortButton != null) mSortButton.setVisibility(View.VISIBLE);
            } else {
                mPlaylistTitle.setText("SEARCH RESULTS");
                if (mSortButton != null) mSortButton.setVisibility(View.GONE);
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }

    // ========================================================================
    // Search (Filters local adapter copy, still no sorting)
    // ========================================================================
    
    private void setupSearchListener() {
        if (mSearchEditText == null) return;
        mSearchEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                performSearch(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        mSearchEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                if (mInputMethodManager != null && mSearchEditText != null)
                    mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        if (mClearSearchButton != null) {
            mClearSearchButton.setOnClickListener(v -> {
                if (mSearchEditText != null) mSearchEditText.setText("");
            });
        }
    }

    private void performSearch(String query) {
        if (!mServiceReady || mMusicService == null) return;
        ArrayList<Song> fullPlaylist = mMusicService.getCurrentPlaylist();
        ArrayList<Song> filtered;
        if (TextUtils.isEmpty(query.trim())) {
            filtered = fullPlaylist;
        } else {
            filtered = new ArrayList<>();
            String lowerQuery = query.toLowerCase().trim();
            for (Song s : fullPlaylist) {
                if (s.getTitle().toLowerCase().contains(lowerQuery) ||
                    s.getArtist().toLowerCase().contains(lowerQuery) ||
                    s.getAlbum().toLowerCase().contains(lowerQuery) ||
                    s.getGenre().toLowerCase().contains(lowerQuery)) {
                    filtered.add(s);
                }
            }
        }
        if (mAdapter != null) mAdapter.updateList(filtered);
        updateTitleAndCount(filtered.size());
        if (!mUserInteractionInProgress && TextUtils.isEmpty(query)) {
            focusCurrentSong();
        }
        updateSortHeaderDisplay();
    }

    private void showSearch() {
        if (mSearchBar != null) mSearchBar.setVisibility(View.VISIBLE);
        mIsSearchVisible = true;
        if (mSortButton != null) mSortButton.setVisibility(View.GONE);
        if (mSearchEditText != null) {
            mSearchEditText.requestFocus();
            if (mInputMethodManager != null)
                mInputMethodManager.showSoftInput(mSearchEditText, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    private void hideSearch() {
        if (mSearchBar != null) mSearchBar.setVisibility(View.GONE);
        mIsSearchVisible = false;
        if (mSortButton != null) mSortButton.setVisibility(View.VISIBLE);
        if (mSearchEditText != null) {
            mSearchEditText.setText("");
            if (mInputMethodManager != null)
                mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
        }
        performSearch("");
    }

    // ========================================================================
    // UI Helpers
    // ========================================================================
    
    private void updateTitleAndCount(int count) {
        String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
        if (TextUtils.isEmpty(searchText)) {
            if (mSongCountText != null) mSongCountText.setText(count + " songs");
        } else {
            int total = mServiceReady && mMusicService != null ? mMusicService.getPlaylistSize() : 0;
            if (mSongCountText != null) mSongCountText.setText(count + " / " + total + " songs");
        }
    }

    private void focusCurrentSong() {
        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) return;
        if (mCurrentPlayingIndex < 0 || mCurrentPlayingIndex >= mAdapter.getItemCount()) return;
        mPlaylistRecyclerView.post(() -> {
            LinearLayoutManager lm = (LinearLayoutManager) mPlaylistRecyclerView.getLayoutManager();
            if (lm != null) {
                int first = lm.findFirstCompletelyVisibleItemPosition();
                int last = lm.findLastCompletelyVisibleItemPosition();
                if (mCurrentPlayingIndex < first || mCurrentPlayingIndex > last) {
                    lm.scrollToPositionWithOffset(mCurrentPlayingIndex, mPlaylistRecyclerView.getHeight() / 2);
                }
            }
        });
    }

    private void loadCurrentPlayingIndex() {
        mCurrentPlayingIndex = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_INDEX, -1);
    }

    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), dpToPx(EMPTY_CONTAINER_PADDING_DP * 2),
                dpToPx(EMPTY_CONTAINER_PADDING_DP), dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));
            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);
            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }
        if (mPlaylistRecyclerView != null) mPlaylistRecyclerView.setVisibility(View.GONE);
        if (mSearchBar != null) mSearchBar.setVisibility(View.GONE);
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    private void hideEmptyView() {
        if (mEmptyContainer != null) mEmptyContainer.setVisibility(View.GONE);
        if (mPlaylistRecyclerView != null) mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) mSearchBar.setVisibility(View.VISIBLE);
    }

    private void initializeViews() {
        mPlaylistRecyclerView = findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = findViewById(R.id.playlistTitle);
        mSongCountText = findViewById(R.id.songCountText);
        mSearchEditText = findViewById(R.id.searchEditText);
        mSearchButton = findViewById(R.id.searchButton);
        mClearSearchButton = findViewById(R.id.clearSearchButton);
        mSearchBar = findViewById(R.id.searchBar);
        mCancelButton = findViewById(R.id.cancelButton);
        mRootContainer = findViewById(R.id.rootContainer);
        mSortButton = findViewById(R.id.sortButton);

        if (mSearchEditText != null) {
            mSearchEditText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearSearchButton);
        if (mSearchBar != null) mSearchBar.setVisibility(View.GONE);

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = now;
                    showSearch();
                }
            });
        }
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = now;
                    if (mIsSearchVisible) hideSearch();
                    else returnToMusicPlayer();
                }
            });
        }

        // Sort button click – cycles sort mode and sends to service
        if (mSortButton != null) {
            mSortButton.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            });
            mSortButton.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = now;
                    cycleSortMode();
                }
            });
        }
    }

    private void animateButton(final Button button) {
        if (button == null) return;
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS).start();
                    break;
            }
            return false;
        });
    }

    // ========================================================================
    // Theme
    // ========================================================================
    
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();
                    if (mSortButton != null && mThemeHelper != null)
                        mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }

    private void applyThemeToUI() {
        if (mThemeHelper == null || mThemeManager == null) return;
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        if (mSearchButton != null) mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        if (mClearSearchButton != null) mThemeHelper.updateButton(mClearSearchButton, mClearSearchButton.isEnabled());
        if (mSortButton != null) mSortButton.setTextColor(themeColor);

        if (mSearchBar != null) {
            GradientDrawable border = new GradientDrawable();
            border.setShape(GradientDrawable.RECTANGLE);
            border.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            border.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            border.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(border);
        }

        if (mSearchEditText != null) {
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            bg.setColor(Color.parseColor("#1A1A1A"));
            mSearchEditText.setBackground(bg);
            mSearchEditText.setTextColor(themeColor);
        }

        if (mAdapter != null) mAdapter.updateThemeColor();
    }

    private void themeAllHeaders() {
        if (mPlaylistTitle != null) mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        if (mSongCountText != null) mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        View root = findViewById(android.R.id.content);
        if (root instanceof ViewGroup) themeHeadersRecursive((ViewGroup) root);
    }

    private void themeHeadersRecursive(ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                String text = ((TextView) child).getText().toString();
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") ||
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    ((TextView) child).setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    private void registerReceivers() {
        // Listen for playlist changes from MusicService
        mPlaylistChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicService.ACTION_PLAYLIST_CHANGED.equals(intent.getAction())) {
                    refreshPlaylistFromService();
                }
            }
        };
        registerReceiverSafely(mPlaylistChangedReceiver, MusicService.ACTION_PLAYLIST_CHANGED);

        // Listen for playback state changes (update playing indicator)
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYER".equals(intent.getAction())) {
                    refreshPlaylistFromService();
                }
            }
        };
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");

        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    refreshPlaylistFromService();
                }
            }
        };
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
    }

    private void registerReceiverSafely(BroadcastReceiver receiver, String action) {
        if (receiver == null) return;
        try {
            IntentFilter filter = new IntentFilter(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        }
    }

    // ========================================================================
    // Full Screen
    // ========================================================================
    
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // Helpers
    // ========================================================================
    
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}