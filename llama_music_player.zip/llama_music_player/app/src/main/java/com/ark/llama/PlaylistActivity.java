package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Displays the playlist, supports search and sort, and tracks the
 * currently playing song.
 *
 * <p>The activity reads the current playlist from {@link MusicService}
 * and listens for {@code UPDATE_PLAYER} broadcasts for playback state.
 * Users can search the playlist, cycle through ten sort modes, and tap a
 * song to play it. The row that corresponds to the currently playing
 * song is highlighted, and the list scrolls it into view when a
 * transition moves it offscreen.</p>
 *
 * <h3>State Ownership</h3>
 * <p>{@link MusicService} owns the authoritative playlist and the current
 * playing index. This activity owns the display list, the current sort
 * mode, the presentation hint that highlights the current row, and the
 * scroll position. The persistent genre-loading overlay is owned by
 * {@link PlaylistManager}: it shows the overlay with the
 * {@code "GENRE_UPDATE"} operation ID, heartbeats it independently of
 * this activity's lifecycle, and hides it by the same identifier. This
 * activity observes genre progress read-only for its own list state.</p>
 *
 * <h3>Ordering</h3>
 * <p>Every {@code UPDATE_PLAYER} broadcast carries a monotonic
 * {@code generation}. The activity drops any broadcast with a strictly
 * lower generation than the highest it has seen. When the service is
 * rebound, the high-water mark resets to {@code -1}, because a new
 * service instance restarts its counter at zero.</p>
 *
 * <p>Auto-scroll to the current song runs when three conditions hold
 * together. First, the user is not dragging or flinging the list.
 * Second, the user is not mid-tap. Third, the row is not already fully
 * visible. When a transition arrives while genre loading is in flight,
 * the target row is stored and applied on the
 * {@code GENRE_UPDATE COMPLETE} broadcast, once the list has settled.</p>
 *
 * <p>Metadata changes published by {@link MetadataEditor} arrive as a
 * single {@code METADATA_UPDATED} broadcast. This activity updates the
 * affected row in place.</p>
 *
 * <h3>Library reset</h3>
 * <p>When the library is reset, {@link PlaylistManager}'s reset
 * operation sends a {@code LIBRARY_RESET} broadcast that this activity
 * receives through its own receiver. The receiver clears the display
 * list and drops the presentation state that referred to a song that no
 * longer exists: the current playing path and the deferred auto-scroll
 * target. This ensures a later list population does not flash a
 * highlight or scroll to a row that matched a stale path. The service
 * reports an empty playlist on its own next refresh, so the two paths
 * converge on the same state.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Sort mode is read from and written to
 * {@code SharedPreferences} under the key {@code playlist_sort_mode}.
 * The current playing path is read from {@code SharedPreferences} on
 * first launch and kept in sync through the {@code UPDATE_PLAYER}
 * broadcasts thereafter.</p>
 *
 * <p>{@link #onDestroy()} does not tear down the persistent overlay.
 * The overlay's lifetime is owned by whichever operation showed it, and
 * an activity that happens to be destroyed while another operation
 * (such as {@link PlaylistManager}'s genre load or reset) owns the
 * overlay must not strand that operation's progress. Overlays are
 * hidden by their owners through
 * {@link ToastManager#hidePersistentOverlay(String)}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods run on the main thread. The activity's own sort
 * computation runs on a short-lived background thread and posts back to
 * the main handler.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistManager
 * @see ThemeManager
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistActivity";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action that requests a playlist refresh. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before the initial focus scroll, in milliseconds. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Duration of button press animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum length of the search field. */
    private static final int MAX_SEARCH_LENGTH = 128;

    /** Corner radius of the search bar, in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;

    /** Corner radius of the search input, in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;

    /** Stroke width of the search bar border, in density-independent pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;

    /** Padding of the empty-state container, in density-independent pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Total number of sort modes. */
    private static final int SORT_MODE_COUNT = 10;

    /** Shared preferences key for the persisted sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Sort labels shown next to the "SORT MODE" header. */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",  "[TITLE Z-A]",
        "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]",  "[ALBUM Z-A]",
        "[GENRE A-Z]",  "[GENRE Z-A]",
        "[OLDEST]",     "[NEWEST]"
    };

    /** Sort transition messages shown after cycling the sort mode. */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",  "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]", "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",  "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",  "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",       "SORT MODE: NEWEST"
    };

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Recycler view that displays the playlist rows. */
    private RecyclerView mPlaylistRecyclerView;

    /** Layout manager backing the recycler view. */
    private LinearLayoutManager mLayoutManager;

    /** Adapter backing the recycler view. */
    private PlaylistAdapter mAdapter;

    /** Text view showing the sort mode or search context. */
    private TextView mPlaylistTitle;

    /** Text view showing the song count. */
    private TextView mSongCountText;

    /** Text field for the search query. */
    private EditText mSearchText;

    /** Button that opens the search bar. */
    private Button mSearchButton;

    /** Button that clears the search query. */
    private Button mClearButton;

    /** Button that cycles the sort mode. */
    private Button mSortButton;

    /** Button that closes the activity or hides the search bar. */
    private Button mCancelButton;

    /** Container that hosts the search bar. */
    private LinearLayout mSearchBar;

    /** Container shown when the playlist is empty. */
    private LinearLayout mEmptyContainer;

    /** Root frame layout that hosts the empty state. */
    private FrameLayout mRootContainer;

    // ========================================================================
    // Data Components
    // ========================================================================

    /** Songs currently displayed, after search and sort. */
    private ArrayList<Song> mCurrentDisplayList;

    /** Path of the song currently highlighted as playing, or null. */
    @Nullable private String mCurrentPlayingPath = null;

    /** True while the search bar is visible. */
    private boolean mIsSearchVisible = false;

    /** Input method manager used to show and hide the keyboard. */
    private InputMethodManager mInputMethodManager;

    // ========================================================================
    // Scroll State Management
    // ========================================================================

    /** True while the user is dragging or flinging the list. */
    private volatile boolean mUserScrolling = false;

    /** Saved scroll position, restored after list updates. */
    @Nullable private Parcelable mSavedScrollState = null;

    /** True while a saved scroll position is waiting to be restored. */
    private boolean mScrollRestorePending = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Manager for the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    // ========================================================================
    // Sort Components
    // ========================================================================

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** Timestamp of the last sort button click. */
    private long mLastSortClickTime = 0;

    /** True when a sort should be applied once genre loading completes. */
    private boolean mPendingSortAfterGenre = false;

    // ========================================================================
    // Interaction State
    // ========================================================================

    /** Timestamp of the last search button click. */
    private long mLastSearchClickTime = 0;

    /** Timestamp of the last cancel button click. */
    private long mLastCancelClickTime = 0;

    /** True while a tap is being processed. */
    private volatile boolean mUserInteractionInProgress = false;

    /** True while genre loading is in flight. */
    private volatile boolean mIsGenreLoading = false;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Generation Gate and Deferred Focus
    // ========================================================================

    /** Highest generation seen in an {@code UPDATE_PLAYER} broadcast. */
    private long mLastSeenGeneration = -1L;

    /** Row waiting for focus once genre loading completes, or -1. */
    private int mDeferredGenreFocusRow = -1;

    // ========================================================================
    // Service Connection
    // ========================================================================

    /** Bound service, or null while not bound. */
    @Nullable private MusicService mMusicService;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** Connection that resets the generation gate on every (re)connect. */
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mLastSeenGeneration = -1L;
            refreshFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    /** Receiver for {@code UPDATE_PLAYER} broadcasts. */
    private BroadcastReceiver mUpdatePlayerReceiver;

    /** Receiver for {@code DISPLAY_PLAYLIST} broadcasts. */
    private BroadcastReceiver mDisplayPlaylistReceiver;

    /** Receiver for {@code METADATA_UPDATED} broadcasts. */
    private BroadcastReceiver mMetadataUpdatedReceiver;

    /** Receiver for playlist load progress broadcasts. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;

    /** Receiver for {@code GENRE_UPDATE} broadcasts. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for {@code FORCE_PLAYLIST_REFRESH} broadcasts. */
    private BroadcastReceiver mForceRefreshReceiver;

    /** Receiver for {@code LIBRARY_RESET} broadcasts emitted by {@link PlaylistManager}. */
    private BroadcastReceiver mLibraryResetReceiver;

    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================

    /**
     * Initializes the activity, its view hierarchy, its receivers, and
     * the service binding.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager =
            (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();

        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();
        registerLibraryResetReceiver();

        bindService(new Intent(this, MusicService.class), mServiceConnection,
            BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes the
     * list from the service, focuses the current song, and reapplies the
     * theme.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        refreshFromService();

        if (mAdapter != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null
                        || TextUtils.isEmpty(mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver so it is not invoked while the
     * activity is not visible.
     */
    @Override
    protected void onPause() {
        super.onPause();

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister theme receiver", exception);
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Unbinds from the service, unregisters every receiver, and removes
     * every handler callback.
     *
     * <p>Does not tear down the persistent overlay. The overlay's
     * lifetime is owned by whichever operation showed it; an activity
     * that is being destroyed while another operation owns the overlay
     * must not strand that operation's progress. Overlays are hidden by
     * their owners through
     * {@link ToastManager#hidePersistentOverlay(String)}.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unbind from MusicService", exception);
            }
            mIsServiceBound = false;
        }

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister theme receiver", exception);
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);

        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Reapplies immersive mode when the window gains focus and
     * reattaches any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Hides the search bar when it is visible, or returns to the music
     * player otherwise.
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ========================================================================
    // Navigation Methods
    // ========================================================================

    /**
     * Returns to the music player activity with the slide-left
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ========================================================================
    // Scroll Listener
    // ========================================================================

    /**
     * Attaches the scroll listener that tracks the user's scrolling
     * state, saves the scroll position when the user is not actively
     * scrolling, and relays the scrolling state to the adapter.
     *
     * <p>The adapter uses the scrolling state to defer genre updates
     * that arrive mid-scroll. Applying them immediately would call
     * {@code notifyItemChanged} on visible rows while the scroll
     * animation is still settling, and the current row would appear to
     * jump out of its own position.</p>
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                boolean scrolling = (newState != RecyclerView.SCROLL_STATE_IDLE);
                mUserScrolling = scrolling;
                if (mAdapter != null) {
                    mAdapter.setScrolling(scrolling);
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState = mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    /**
     * Saves the current scroll position so it can be restored after the
     * next list update.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    /**
     * Restores the saved scroll position when one is pending.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null
                && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception exception) {
                Log.w(TAG, "Failed to restore scroll position", exception);
                mScrollRestorePending = false;
            }
        }
    }

    /**
     * Returns whether the given row is currently offscreen.
     *
     * @param row Row to test
     * @return True when the row is outside the visible range
     */
    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) {
            return false;
        }
        if (row < 0 || row >= mCurrentDisplayList.size()) {
            return false;
        }
        int firstVisibleRow = mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastVisibleRow = mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (firstVisibleRow == RecyclerView.NO_POSITION
                || lastVisibleRow == RecyclerView.NO_POSITION) {
            return false;
        }
        return row < firstVisibleRow || row > lastVisibleRow;
    }

    /**
     * Scrolls the given row into the vertical center of the list when it
     * is offscreen.
     *
     * @param row Row to scroll into view
     */
    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) {
            return;
        }
        if (!shouldAutoScrollTo(row)) {
            return;
        }
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                mLayoutManager.scrollToPositionWithOffset(
                    finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    /**
     * Applies the row stored in {@link #mDeferredGenreFocusRow} as the
     * scroll target and clears the deferred value.
     */
    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) {
            return;
        }
        int deferredRow = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(deferredRow);
    }

    // ========================================================================
    // Refresh Methods
    // ========================================================================

    /**
     * Rebuilds the display list from the service's current playlist.
     *
     * <p>Suppressed while genre loading or user scrolling is in flight,
     * because the list is about to change. Saves the scroll position
     * before rebuilding and restores it afterward. When the service
     * reports an empty playlist, the presentation state that referred to
     * the missing song is cleared.</p>
     */
    private void refreshFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "refreshFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            // The library is empty. Drop the presentation state that
            // referred to a song that no longer exists, so a later list
            // population does not flash a highlight or scroll to a row
            // that matched the stale path.
            mCurrentPlayingPath = null;
            mDeferredGenreFocusRow = -1;
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
                mAdapter.setCurrentPlayingPath(null);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }

    // ========================================================================
    // Sort Methods
    // ========================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = preferences.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    /**
     * Advances to the next sort mode, persists it, broadcasts the
     * change, and re-sorts the display list on a background thread.
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);

        final ArrayList<Song> listToSort = new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int sortMode = mCurrentSortMode;

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort, getComparatorForSortMode(sortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);

                            if (currentPath != null) {
                                int newPosition = findPositionByPath(currentPath);
                                if (newPosition >= 0) {
                                    mCurrentPlayingPath = currentPath;
                                    mAdapter.setCurrentPlayingIndex(newPosition);

                                    mMainHandler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!mUserScrolling && !mIsGenreLoading
                                                    && !mUserInteractionInProgress) {
                                                focusCurrentSong();
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                            }
                        }

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(PlaylistActivity.this,
                            SORT_TOAST_MESSAGES[mCurrentSortMode],
                            ToastManager.LENGTH_SHORT);
                    }
                });
            }
        }).start();
    }

    /**
     * Sorts the display list in place by the current sort mode.
     *
     * @param showToast True to broadcast the sort change and show a
     *        toast
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling && !mIsGenreLoading
                                        && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode],
                ToastManager.LENGTH_SHORT);
        }
    }

    /**
     * Returns the index of the song with the given path in the display
     * list, or -1 when it is not present.
     *
     * @param path Path to search for
     * @return The display-list index, or -1
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentDisplayList.size(); index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch, or 0
     *         when the song or its path is null
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the given
     * sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return secondTitle.compareToIgnoreCase(firstTitle);
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = firstArtist.compareToIgnoreCase(secondArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = secondArtist.compareToIgnoreCase(firstArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = firstAlbum.compareToIgnoreCase(secondAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = secondAlbum.compareToIgnoreCase(firstAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = firstGenre.compareToIgnoreCase(secondGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = secondGenre.compareToIgnoreCase(firstGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(firstDate, secondDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(secondDate, firstDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong, Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(secondTitle);
                    }
                };
        }
    }

    /**
     * Updates the header to show the current sort mode or search
     * context, and toggles the sort button visibility.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
            if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText("SEARCH RESULTS");
            if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ========================================================================
    // Display Methods
    // ========================================================================

    /**
     * Displays the empty-state container and hides the playlist and
     * search bar.
     */
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));

            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);

            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer,
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    /**
     * Hides the empty-state container and shows the playlist.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Creates the playlist adapter and attaches it to the recycler
     * view.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(
            this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition = findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(newPosition);
                            }
                        } catch (Exception exception) {
                            Log.e(TAG, "Error setting playing index", exception);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Updates the header and song count text from the current search and
     * display state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount + (songCount == 1 ? " song" : " songs"));
            }
        } else {
            int totalSongs = (mMusicService != null
                && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount + " / " + totalSongs
                    + (totalSongs == 1 ? " song" : " songs"));
            }
        }
    }

    /**
     * Reads the persisted last playing path into memory.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath = preferences.getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Scrolls the current song into the vertical center of the list when
     * it is offscreen and the user is not interacting with the list.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG, "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null
                || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size(); index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisibleRow = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastVisibleRow = mLayoutManager.findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisibleRow || finalPosition > lastVisibleRow) {
                        mLayoutManager.scrollToPositionWithOffset(finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ========================================================================
    // Full Screen Configuration
    // ========================================================================

    /**
     * Configures the activity window for full-screen immersive display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ========================================================================
    // UI Initialization Methods
    // ========================================================================

    /**
     * Resolves every view, attaches touch animations and click handlers,
     * and creates the adapter.
     */
    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        if (mSearchText != null) {
            mSearchText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ========================================================================
    // Search Methods
    // ========================================================================

    /**
     * Attaches the search text watcher, the editor action listener, and
     * the clear button handler.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH
                            || actionId == EditorInfo.IME_ACTION_DONE
                            || (event != null
                                && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                                && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager inputMethodManager =
                            (InputMethodManager) getSystemService(
                                Context.INPUT_METHOD_SERVICE);
                        if (inputMethodManager != null && mSearchText != null) {
                            inputMethodManager.hideSoftInputFromWindow(
                                mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    /**
     * Filters the service's current playlist by the given query and
     * writes the result into the display list.
     *
     * @param query The search text; an empty or whitespace-only query
     *        matches every song
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs = mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase().contains(lowerQuery))
                            || (artist != null && artist.toLowerCase().contains(lowerQuery))
                            || (album != null && album.toLowerCase().contains(lowerQuery))
                            || (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    /**
     * Shows the search bar and requests focus on the search field.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(
                    mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    /**
     * Hides the search bar, clears the query, and refreshes the display
     * list.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(
                    mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");
    }

    // ========================================================================
    // Theme Methods
    // ========================================================================

    /**
     * Registers the receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();

                    if (mSortButton != null && mThemeHelper != null) {
                        mThemeHelper.updateButton(mSortButton, true);
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiverSafely(mThemeReceiver, filter);
    }

    /**
     * Registers the receiver for genre update broadcasts.
     *
     * <p>START and COMPLETE bracket the genre-loading window. During the
     * window, the display and refresh paths are held so the list does not
     * re-sort mid-load.</p>
     *
     * <p>The persistent overlay is owned by {@link PlaylistManager} and
     * shown with the {@code "GENRE_UPDATE"} operation ID. This receiver
     * observes genre progress only to drive its own list state.</p>
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");

                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG, "Genre loading started for " + total + " songs");
                        mIsGenreLoading = true;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }

                        // The overlay is owned by PlaylistManager.

                    } else if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");

                        if (mAdapter != null && songPath != null && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }

                    } else if ("COMPLETE".equals(status)) {
                        int loaded = intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");

                        mIsGenreLoading = false;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }

                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }

                        Intent refreshMetadataIntent = new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra("refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);

                        applyDeferredGenreFocus();
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiverSafely(mGenreUpdateReceiver, filter);
    }

    /**
     * Registers the receiver for playlist refresh broadcasts.
     */
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - refreshing from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            } else {
                                Log.d(TAG, "Force refresh suppressed during genre loading");
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiverSafely(mForceRefreshReceiver, filter);
    }

    /**
     * Registers the receiver for library reset broadcasts emitted by
     * {@link PlaylistManager}.
     *
     * <p>Reacts to the {@code LIBRARY_RESET} broadcast that the reset
     * operation sends after its write barrier commits. This activity
     * owns the display list and the presentation hint that highlights
     * the current row; the receiver clears the display list and drops
     * every piece of presentation state that referred to a song that no
     * longer exists, so a later list population does not flash a
     * highlight or scroll to a row that matched a stale path.</p>
     *
     * <p>The persistent overlay is left alone; it is owned by the reset
     * operation and is hidden by that operation when its work
     * completes.</p>
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(intent.getAction())) {
                    return;
                }

                Log.d(TAG, "LIBRARY_RESET received — clearing display list");

                mCurrentDisplayList.clear();
                mCurrentPlayingPath = null;
                mDeferredGenreFocusRow = -1;
                mLastSeenGeneration = -1L;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showEmptyView();
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                            mAdapter.setCurrentPlayingPath(null);
                        }
                        updateTitleAndCount();
                    }
                });
            }
        };

        IntentFilter filter = new IntentFilter(PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(mLibraryResetReceiver, filter);
    }

    /**
     * Applies the header text color to every header TextView in the
     * activity.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews in the
     * given view hierarchy.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView
                    && !(child instanceof Button)
                    && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST")
                        || text.equals("SEARCH RESULTS") || text.contains("songs")
                        || text.startsWith("SORT MODE")
                        || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the current theme color to every control in the activity
     * and to the search bar background.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(mSortButton, mSortButton.isEnabled());
        }

        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(mThemeHelper.getThemeColorInt());
        }

        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAdapter != null && mCurrentPlayingPath != null) {
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            if (currentPosition >= 0) {
                mAdapter.notifyItemChanged(currentPosition);
            }
        }
    }

    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     *
     * <p>Every receiver registered here listens only for broadcasts
     * sent by the app itself, so they are all registered with
     * {@code RECEIVER_NOT_EXPORTED} through
     * {@link #registerReceiverSafely}.</p>
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"UPDATE_PLAYER".equals(intent.getAction())) {
                    return;
                }

                long generation = intent.getLongExtra("generation", -1L);
                boolean generationAdvanced;
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    generationAdvanced = (generation > mLastSeenGeneration);
                    if (generationAdvanced) {
                        mLastSeenGeneration = generation;
                    }
                } else {
                    generationAdvanced = false;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null) {
                    return;
                }

                mCurrentPlayingPath = songPath;
                if (mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition < 0) {
                    return;
                }

                mAdapter.setCurrentPlayingIndex(displayPosition);

                if (!generationAdvanced) {
                    return;
                }
                if (!shouldAutoScrollTo(displayPosition)) {
                    return;
                }

                if (mIsGenreLoading) {
                    mDeferredGenreFocusRow = displayPosition;
                } else if (!mUserScrolling && !mUserInteractionInProgress) {
                    scrollToRowIfOffscreen(displayPosition);
                }
            }
        };

        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            }
                        }
                    });
                }
            }
        };

        /**
         * Receiver for metadata changes published by
         * {@link MetadataEditor}. Recolors the affected row and updates
         * the current playing path when it changed.
         */
        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !"METADATA_UPDATED".equals(intent.getAction())) {
                    return;
                }

                final String songPath = intent.getStringExtra("song_path");
                if (songPath == null || mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition >= 0) {
                    Song existing = mCurrentDisplayList.get(displayPosition);
                    if (existing != null) {
                        final String title = intent.getStringExtra("title");
                        final String artist = intent.getStringExtra("artist");
                        final String album = intent.getStringExtra("album");
                        final String genre = intent.getStringExtra("genre");
                        Song updated = new Song(
                            title != null ? title : existing.getTitle(),
                            artist != null ? artist : existing.getArtist(),
                            album != null ? album : existing.getAlbum(),
                            genre != null ? genre : existing.getGenre(),
                            songPath, existing.getDuration(), existing.getUri());
                        mCurrentDisplayList.set(displayPosition, updated);
                        mAdapter.notifyItemChanged(displayPosition);
                    }
                }

                if (songPath.equals(mCurrentPlayingPath)) {
                    mCurrentPlayingPath = songPath;
                    mAdapter.setCurrentPlayingIndex(displayPosition);
                }
            }
        };

        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }

                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists && !mIsGenreLoading && !mUserScrolling) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);

                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );

                        mCurrentDisplayList.add(newSong);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }

                        updateTitleAndCount();
                    }
                }
            }
        };

        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiverSafely(mUpdatePlayerReceiver, playerFilter);

        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiverSafely(mDisplayPlaylistReceiver, displayFilter);

        IntentFilter metadataFilter = new IntentFilter();
        metadataFilter.addAction("METADATA_UPDATED");
        registerReceiverSafely(mMetadataUpdatedReceiver, metadataFilter);

        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiverSafely(mPlaylistLoadProgressReceiver, progressFilter);
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any exception raised by
     * the framework.
     *
     * <p>Every receiver this activity registers listens only for
     * broadcasts sent by the app itself, so the correct export policy
     * is {@code RECEIVER_NOT_EXPORTED}. {@link ContextCompat#registerReceiver}
     * handles the API-level branching internally.</p>
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver,
                                        @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver", exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception raised by
     * the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.w(TAG, "Failed to unregister receiver", exception);
            }
        }
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}