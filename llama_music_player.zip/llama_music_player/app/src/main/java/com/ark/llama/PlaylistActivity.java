package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Activity for displaying and managing the current playlist.
 * 
 * <p>This activity provides a comprehensive playlist management interface that allows
 * users to view, search, sort, and interact with their music library. The activity stays
 * alive in the background to continue receiving playlist updates and playback
 * indicator changes, ensuring the UI stays in sync with the playback state.</p>
 * 
 * <h3>RecyclerView Best Practices Implemented</h3>
 * <ul>
 *   <li><b>Stable IDs</b> - Uses setHasStableIds(true) and song path as stable ID</li>
 *   <li><b>No notifyDataSetChanged()</b> - Uses DiffUtil and payload-based updates</li>
 *   <li><b>Scroll state tracking</b> - Suppresses auto-scroll while user is scrolling</li>
 *   <li><b>Current song tracking</b> - Uses song path instead of index position</li>
 *   <li><b>Scroll position preservation</b> - Saves/restores layout state before major updates</li>
 *   <li><b>No auto-scroll during background updates</b> - Prevents fighting user scrolling</li>
 *   <li><b>Queue sorting</b> - Defers sorting until after genre loading completes</li>
 * </ul>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>Playlist Display</b> - Scrollable list of songs in the current playlist with
 *       efficient RecyclerView implementation</li>
 *   <li><b>Sort Functionality</b> - Sort by title, artist, album, genre, or date with
 *       ascending/descending order. Click the SORT button in the header to cycle through
 *       all 10 sort modes. The current sort mode is displayed in the header (e.g.,
 *       "SORT MODE [A-Z]") and persisted across app restarts. Changes are broadcast to
 *       MusicService so playback respects the sort order.</li>
 *   <li><b>Search Functionality</b> - Filter songs by title, artist, or album with
 *       real-time search results that maintain the current sort order</li>
 *   <li><b>Playback Indicator</b> - Visual highlighting of the currently playing song
 *       with theme-colored text and dark background</li>
 *   <li><b>Auto-scroll</b> - Automatic scrolling to the currently playing song only when
 *       the playlist is first opened (NOT during background genre loading or user scrolling)</li>
 *   <li><b>Theme Support</b> - Consistent visual styling with theme color integration
 *       across all UI components including the SORT button</li>
 *   <li><b>Empty State Handling</b> - User-friendly message when no songs are available,
 *       with instructions on how to import music</li>
 *   <li><b>Real-time Updates</b> - Listens to broadcasts for playlist changes and
 *       playback state updates from MusicService</li>
 *   <li><b>Async Genre Loading</b> - Receives genre updates from PlaylistService
 *       during background ID3 tag reading, using batching to prevent scroll jitter</li>
 *   <li><b>Scroll Position Preservation</b> - Saves and restores scroll position during
 *       major playlist updates to prevent unwanted jumps</li>
 *   <li><b>User Scroll Detection</b> - Suppresses auto-scroll while user is actively
 *       scrolling to avoid fighting the user's input</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistActivity";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index in SharedPreferences. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last played song path in SharedPreferences. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Broadcast action for forcing playlist refresh after genre loading. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    
    /** Broadcast action for updating sort mode in MusicService. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay in milliseconds before scrolling to the currently playing song. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Maximum length for search query input in characters. */
    private static final int MAX_SEARCH_LENGTH = 128;
    
    /** Corner radius for search bar in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    
    /** Corner radius for search input field in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    
    /** Stroke width for search bar border in density-independent pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    
    /** Padding for empty container in density-independent pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    
    // ========================================================================
    // Sort Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). This is the default. */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    /** Total number of available sort modes (10). Used for cyclic navigation. */
    private static final int SORT_MODE_COUNT = 10;
    
    /** Preference key for storing the user's selected sort mode in SharedPreferences. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /**
     * Display names for each sort mode shown in the header.
     * Index matches the sort mode constants.
     */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",    // SORT_TITLE_AZ
        "[TITLE Z-A]",    // SORT_TITLE_ZA
        "[ARTIST A-Z]",   // SORT_ARTIST_AZ
        "[ARTIST Z-A]",   // SORT_ARTIST_ZA
        "[ALBUM A-Z]",    // SORT_ALBUM_AZ
        "[ALBUM Z-A]",    // SORT_ALBUM_ZA
        "[GENRE A-Z]",    // SORT_GENRE_AZ
        "[GENRE Z-A]",    // SORT_GENRE_ZA
        "[OLDEST]",       // SORT_OLDEST
        "[NEWEST]"        // SORT_NEWEST
    };
    
    /**
     * Toast messages for each sort mode shown when user cycles sort.
     * Index matches the sort mode constants.
     */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",
        "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]",
        "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",
        "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",
        "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",
        "SORT MODE: NEWEST"
    };
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** RecyclerView for displaying the playlist items with efficient recycling. */
    private RecyclerView mPlaylistRecyclerView;
    
    /** Layout manager for the RecyclerView (used for scroll position preservation). */
    private LinearLayoutManager mLayoutManager;
    
    /** Adapter for the playlist RecyclerView that handles view binding. */
    private PlaylistAdapter mAdapter;
    
    /** TextView displaying the playlist title (shows "SORT MODE [current]"). */
    private TextView mPlaylistTitle;
    
    /** TextView displaying the song count (e.g., "5 songs" or "5 / 120 songs"). */
    private TextView mSongCountText;
    
    /** EditText for search input with real-time filtering. */
    private EditText mSearchEditText;
    
    /** Button to toggle search mode visibility. */
    private Button mSearchButton;
    
    /** Button to clear the search query (stays in search mode). */
    private Button mClearSearchButton;
    
    /** Container layout for the search bar (initially hidden). */
    private LinearLayout mSearchBar;
    
    /** Button to cancel/hide search or return to music player. */
    private Button mCancelButton;
    
    /** Container for empty state UI when no songs exist in the playlist. */
    private LinearLayout mEmptyContainer;
    
    /** Root container frame layout that holds all content. */
    private FrameLayout mRootContainer;
    
    /** Clickable SORT text view in the header bar. */
    private TextView mSortButton;
    
    // ========================================================================
    // Data Components
    // ========================================================================
    
    /** List of songs currently displayed (filtered by search and sorted). */
    private ArrayList<Song> mCurrentDisplayList;
    
    /** Path of the currently playing song (null if no song is playing). */
    @Nullable
    private String mCurrentPlayingPath = null;
    
    /** Flag indicating whether the search bar is currently visible. */
    private boolean mIsSearchVisible = false;
    
    /** Input method manager for controlling the soft keyboard. */
    private InputMethodManager mInputMethodManager;
    
    // ========================================================================
    // Scroll State Management
    // ========================================================================
    
    /** Flag indicating if the user is currently scrolling the RecyclerView. */
    private volatile boolean mUserScrolling = false;
    
    /** Saved scroll position for preservation during updates. */
    @Nullable
    private Parcelable mSavedScrollState = null;
    
    /** Flag indicating if a scroll position restore is pending. */
    private boolean mScrollRestorePending = false;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Manager for theme color operations and persistence. */
    private ThemeManager mThemeManager;
    
    /** Helper for applying theme colors to UI components (buttons, text, etc.). */
    private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme color change events from ThemeManager. */
    private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Sort Components
    // ========================================================================
    
    /** Current sort mode (default is SORT_TITLE_AZ to match original behavior). */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    /** Last sort button click timestamp for debouncing (using elapsedRealtime). */
    private long mLastSortClickTime = 0;
    
    /** Flag indicating if a sort update is pending (queued after genre loading). */
    private boolean mPendingSortAfterGenre = false;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Timestamp of the last search button click for debouncing. */
    private long mLastSearchClickTime = 0;
    
    /** Timestamp of the last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;
    
    /**
     * Flag indicating if a user interaction (like song click) is in progress.
     * Used to prevent auto-scrolling during user interactions.
     */
    private volatile boolean mUserInteractionInProgress = false;
    
    /**
     * Flag indicating if genre loading is currently in progress (Phase 2).
     * Used to suppress playlist refreshes and auto-scrolling during Phase 2 loading.
     * When true, the adapter batches genre updates to prevent scroll jitter.
     */
    private volatile boolean mIsGenreLoading = false;
    
    /** Main thread handler for delayed operations (auto-scroll, focus, etc.). */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Service Connection for MusicService (Source of Truth)
    // ========================================================================
    
    /** Reference to MusicService to obtain the current playlist. */
    @Nullable
    private MusicService mMusicService;
    
    /** Flag indicating whether the service is bound. */
    private boolean mIsServiceBound = false;
    
    /** Service connection for binding to MusicService. */
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            refreshFromService();
        }
        
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for playback state updates from MusicService. */
    private BroadcastReceiver mUpdatePlayerReceiver;
    
    /** Receiver for playlist display updates (when playlist changes). */
    private BroadcastReceiver mDisplayPlaylistReceiver;
    
    /** Receiver for forced player updates (after metadata changes). */
    private BroadcastReceiver mForceUpdatePlayerReceiver;
    
    /** Receiver for playlist load progress updates during scanning. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;
    
    /**
     * Receiver for genre update events from PlaylistService during async genre loading.
     * Handles progressive genre display as ID3 tags are read in the background.
     * Uses batching to prevent scroll jitter during Phase 2 loading.
     */
    private BroadcastReceiver mGenreUpdateReceiver;
    
    /**
     * Receiver for force refresh events from PlaylistService after genre loading.
     * Ensures the playlist reloads from MusicService after orientation changes.
     */
    private BroadcastReceiver mForceRefreshReceiver;
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * Initializes the UI, managers, loads preferences, and registers receivers.
     *
     * @param savedInstanceState Saved instance state (not used in this activity)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_playlist);
        
        CharacterMapper.init(this);
        
        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        
        loadCurrentPlayingPath();          // Track by path, not index
        loadSortMode();
        initializeViews();
        setupSearchListener();
        setupScrollListener();              // Track user scrolling
        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();
        
        bindService(new Intent(this, MusicService.class), mServiceConnection, BIND_AUTO_CREATE);
        
        applyThemeToUI();
        themeAllHeaders();
    }
    
    /**
     * Called when the activity resumes.
     * Reattaches persistent toast, re-registers theme receiver, refreshes UI,
     * and ensures sort button and header display are up to date.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        refreshFromService();
        
        if (mAdapter != null) {
            // Find current playing position by path, not by stored index
            int currentPosition = findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
            
            if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                    focusCurrentSong();
                }
            }
        }
        
        if (mSortButton != null && mThemeHelper != null) {
            mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        updateSortHeaderDisplay();
        
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity pauses.
     * Unregisters the theme receiver to prevent memory leaks.
     */
    @Override
    protected void onPause() {
        super.onPause();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     * Reattaches persistent toast if it exists.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     * Cleans up resources, unbinds from MusicService, unregisters receivers,
     * and removes any pending handler callbacks.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unbind from MusicService", e);
            }
            mIsServiceBound = false;
        }
        
        ToastManager.hidePersistentOverlay();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);
        
        mMainHandler.removeCallbacksAndMessages(null);
    }
    
    /**
     * Called when the window focus changes.
     * Handles immersive mode for full-screen experience and reattaches persistent toast.
     *
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the back button is pressed.
     * 
     * <p>Back button behavior:
     * <ul>
     *   <li>If search is visible: Hides the search bar and returns to normal playlist view</li>
     *   <li>If search is not visible: Returns to MusicPlayer activity</li>
     * </ul>
     * </p>
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Returns to MusicPlayer without destroying this activity.
     * This allows playlist updates and playback indicator to continue in the background.
     * Symmetric to MusicPlayer.openPlaylist().
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    // ========================================================================
    // Scroll Listener
    // ========================================================================
    
    /**
     * Sets up the RecyclerView scroll listener to track user scrolling state.
     * This prevents auto-scroll from fighting the user's input during background updates.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                // Track when user is actively scrolling
                mUserScrolling = (newState != RecyclerView.SCROLL_STATE_IDLE);
                
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    // User stopped scrolling - can now safely auto-scroll if needed
                    if (!mIsGenreLoading && !mUserInteractionInProgress) {
                        focusCurrentSong();
                    }
                }
            }
            
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                // Save scroll position during scroll for potential restoration
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState = mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }
    
    /**
     * Saves the current scroll position for later restoration.
     * Called before major playlist updates to preserve user position.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }
    
    /**
     * Restores a previously saved scroll position.
     * Called after major playlist updates to return to the same position.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception e) {
                Log.w(TAG, "Failed to restore scroll position", e);
                mScrollRestorePending = false;
            }
        }
    }
    
    // ========================================================================
    // Refresh Methods
    // ========================================================================
    
    /**
     * Refreshes the playlist from the MusicService (source of truth) and updates UI.
     * If search is active, re-executes the search on the new playlist.
     * This method ensures that all playlist data comes from a single source of truth.
     * 
     * <p><b>Best Practices:</b>
     * <ul>
     *   <li>Suppressed during genre loading to prevent scroll interruption</li>
     *   <li>Suppressed during user scrolling to prevent fighting user input</li>
     *   <li>Preserves scroll position when possible</li>
     * </ul>
     * </p>
     */
    private void refreshFromService() {
        // Suppress refreshes during genre loading or user scrolling to prevent interruptions
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshFromService suppressed during genre loading");
            return;
        }
        
        if (mUserScrolling) {
            Log.d(TAG, "refreshFromService suppressed during user scrolling");
            return;
        }
        
        if (mMusicService == null) {
            return;
        }
        
        // Save scroll position before potential list changes
        saveScrollPosition();
        
        ArrayList<Song> playlist = mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
            return;
        }
        
        String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            
            applyCurrentSort(false);
            
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
            
            if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                focusCurrentSong();
            }
        }
        
        // Restore scroll position after update
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }
    
    // ========================================================================
    // Sort Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * Default is SORT_TITLE_AZ (Title A-Z) which matches the original code's behavior.
     * This method is called during onCreate to restore user preference.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     * Called whenever the user cycles to a new sort mode to persist preference.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    /**
     * Cycles to the next sort mode and applies it.
     * This method is called when the user clicks the SORT button in the header.
     * Cycles through all 10 sort modes in order, broadcasts the change to MusicService,
     * and shows a toast confirmation.
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        
        saveSortMode();
        
        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);
        
        applyCurrentSort(true);
        
        updateSortHeaderDisplay();
    }
    
    /**
     * Applies the current sort mode to the displayed list.
     * This method sorts the mCurrentDisplayList in place and updates the adapter.
     * It preserves the currently playing song highlight by finding its new position.
     *
     * @param showToast True to show a toast confirmation message
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        
        // Save the current playing path before sorting
        String currentPath = mCurrentPlayingPath;
        
        // Save scroll position before sort
        saveScrollPosition();
        
        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));
        
        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }
        
        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);
            
            // Find the song by path after sorting
            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);
                }
            }
        }
        
        updateTitleAndCount();
        
        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        }
        
        // Restore scroll position after sort
        restoreScrollPosition();
        
        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
            if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                focusCurrentSong();
            }
        }
    }
    
    /**
     * Finds the position of a song in mCurrentDisplayList by its file path.
     *
     * @param path The file path of the song to find
     * @return The position index, or -1 if the song is not found
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && path.equals(song.getPath())) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     * This is a reliable method that works across all Android versions without
     * requiring additional permissions.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds since Unix epoch
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     * All comparators use secondary sorting by Title (A-Z) when primary keys match
     * to ensure consistent, predictable display ordering.
     *
     * @param sortMode The sort mode constant (SORT_TITLE_AZ, SORT_GENRE_ZA, etc.)
     * @return A Comparator<Song> that implements the requested sorting order
     */
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
                
            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleB.compareToIgnoreCase(titleA);
                    }
                };
                
            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistA.compareToIgnoreCase(artistB);
                        
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistB.compareToIgnoreCase(artistA);
                        
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumA.compareToIgnoreCase(albumB);
                        
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumB.compareToIgnoreCase(albumA);
                        
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreA.compareToIgnoreCase(genreB);
                        
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreB.compareToIgnoreCase(genreA);
                        
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateA, dateB);
                        
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateB, dateA);
                        
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
        }
    }
    
    /**
     * Updates the header to show the current sort mode.
     * Example formats:
     * - "SORT MODE [A-Z]" (normal playlist view)
     * - "SEARCH RESULTS" (when search is active - no sort mode shown)
     * This method is called after sort mode changes or when the activity resumes.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle != null) {
            String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
            
            if (TextUtils.isEmpty(searchText)) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                    mSortButton.setVisibility(View.VISIBLE);
                }
            } else {
                mPlaylistTitle.setText("SEARCH RESULTS");
                if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                    mSortButton.setVisibility(View.GONE);
                }
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Sets up the clickable SORT button in the header bar.
     * The button is defined in XML layout, so we just find and configure it.
     */
    private void setupSortButton() {
        mSortButton = (TextView) findViewById(R.id.sortButton);
        
        if (mSortButton == null) {
            Log.w(TAG, "Sort button not found in layout");
            return;
        }
        
        int themeColor = mThemeHelper.getThemeColorInt();
        mSortButton.setTextColor(themeColor);
        
        mSortButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
        
        mSortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = currentTime;
                    cycleSortMode();
                }
            }
        });
    }
    
    // ========================================================================
    // Display Methods
    // ========================================================================
    
    /**
     * Shows the empty state view when no songs are available.
     * Displays instructional text and hides interactive elements.
     */
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));
            
            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);
            
            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer, 
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, 
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }
        
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }
    
    /**
     * Hides the empty state view and shows the playlist RecyclerView.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Sets up the playlist adapter with click listener.
     * Clicking a song plays it and updates the UI with the current playing indicator.
     * 
     * Note: DividerItemDecoration has been removed. Dividers are now handled
     * inside each item layout (item_song.xml) and controlled by PlaylistAdapter
     * to hide the divider for the currently playing song, eliminating the visual gap.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }
                
                mUserInteractionInProgress = true;
                
                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);
                
                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition = findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(newPosition);
                                if (!mIsGenreLoading && !mUserScrolling) {
                                    focusCurrentSong();
                                }
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting playing index", e);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });
        
        // Find position by path for initial highlight
        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);
        
        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);
        
        mPlaylistRecyclerView.setAdapter(mAdapter);
    }
    
    /**
     * Updates the title and song count display based on search state.
     * Shows sort mode in the header for normal view, hides it for search results.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
        
        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " songs");
            }
        } else {
            int totalSongs = (mMusicService != null && mMusicService.getCurrentPlaylist() != null) 
                ? mMusicService.getCurrentPlaylist().size() : 0;
            
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " / " + totalSongs + " songs");
            }
        }
    }
    
    /**
     * Sets the header texts for playlist title and song count.
     * Used primarily for empty state and initial setup.
     *
     * @param title The title text
     * @param count The count text
     */
    private void setHeaderTexts(@NonNull String title, @NonNull String count) {
        if (mPlaylistTitle != null) {
            if (title.equals("CURRENT PLAYLIST") || title.equals("SEARCH RESULTS")) {
                if (title.equals("CURRENT PLAYLIST")) {
                    mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                } else {
                    mPlaylistTitle.setText(title);
                }
            } else {
                mPlaylistTitle.setText(title);
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setText(count);
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Loads the current playing song path from SharedPreferences.
     * This allows the activity to show the correct playing indicator on startup.
     * Uses path instead of index for stable identification.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath = prefs.getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Scrolls the playlist to show the currently playing song.
     * Used ONLY when the playlist is first opened - NOT during background genre loading.
     * 
     * <p><b>Note:</b> Auto-scrolling is completely suppressed during genre loading or
     * user scrolling to prevent interrupting the user's scrolling experience.
     * This method returns immediately if mIsGenreLoading or mUserScrolling is true.</p>
     */
    private void focusCurrentSong() {
        // Never auto-scroll during background updates or user scrolling
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading");
            return;
        }
        
        if (mUserScrolling) {
            Log.d(TAG, "focusCurrentSong suppressed during user scrolling");
            return;
        }
        
        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }
        
        // Find the current song by path
        if (mCurrentPlayingPath == null) {
            return;
        }
        
        int targetPosition = -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = i;
                break;
            }
        }
        
        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisible = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastVisible = mLayoutManager.findLastCompletelyVisibleItemPosition();
                    
                    if (finalPosition < firstVisible || finalPosition > lastVisible) {
                        mLayoutManager.scrollToPositionWithOffset(finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets status bar and navigation bar colors based on Android version.
     * Uses deprecated methods for backward compatibility.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components and sets up click listeners.
     * This includes finding views by ID, setting up animations, and configuring the sort button.
     */
    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSearchEditText = (EditText) findViewById(R.id.searchEditText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearSearchButton = (Button) findViewById(R.id.clearSearchButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);
        
        if (mSearchEditText != null) {
            mSearchEditText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }
        
        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearSearchButton);
        
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });
        }
        
        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }
        
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }
        
        setupSortButton();
        setupAdapter();
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% of its original size when pressed,
     * then returns to normal when released.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Search Methods
    // ========================================================================
    
    /**
     * Sets up the search functionality with text watcher and clear button.
     * The search filters in real-time as the user types.
     * The Enter key on the keyboard dismisses the input method since
     * search is already live, so no need to re-trigger.
     */
    private void setupSearchListener() {
        if (mSearchEditText != null) {
            mSearchEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }
                
                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            
            mSearchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null && mSearchEditText != null) {
                            imm.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });
            
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
        }
        
        if (mClearSearchButton != null) {
            mClearSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSearchEditText != null) {
                        mSearchEditText.setText("");
                    }
                }
            });
        }
    }
    
    /**
     * Performs the search operation and updates the displayed list.
     * The current sort mode is maintained in the search results.
     * Now uses MusicService as the single source of truth for all playlist data.
     *
     * @param query The search query string
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }
        
        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs = mMusicService.getCurrentPlaylist();
        
        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }
        
        mCurrentDisplayList.clear();
        
        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }
        
        applyCurrentSort(false);
        
        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }
        
        updateTitleAndCount();
        
        if (query.trim().isEmpty() && !mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
            focusCurrentSong();
        }
    }
    
    /**
     * Shows the search bar and focuses the search input.
     * The keyboard automatically appears when the search bar becomes visible.
     * Sort button is hidden during search.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;
        
        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }
        
        if (mSearchEditText != null) {
            mSearchEditText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchEditText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }
    
    /**
     * Hides the search bar and clears the search query.
     * The keyboard is dismissed and the full playlist is restored.
     * Sort button is shown again.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;
        
        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }
        
        if (mSearchEditText != null) {
            mSearchEditText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
            }
        }
        
        performSearch("");
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers the theme color change broadcast receiver.
     * This allows the activity to update its UI when the user changes the theme.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();
                    
                    if (mSortButton != null && mThemeHelper != null) {
                        mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the genre update broadcast receiver for async genre loading.
     * 
     * <p>This receiver listens for GENRE_UPDATE broadcasts from PlaylistService
     * during the background ID3 tag reading phase. It progressively updates the
     * UI as each song's genre becomes available, using batching to prevent
     * scroll jitter during Phase 2 loading.</p>
     * 
     * <p><b>Best Practices Implemented:</b>
     * <ul>
     *   <li>No auto-scroll during updates</li>
     *   <li>Queue sorting for after loading completes</li>
     *   <li>No refreshFromService() call on COMPLETE</li>
     * </ul>
     * </p>
     * 
     * <p>The receiver handles three status types:
     * <ul>
     *   <li><b>START</b> - Loading phase begins (shows persistent overlay, enables batching)</li>
     *   <li><b>UPDATE</b> - Single song genre loaded, stored in adapter's pending map (no UI refresh)</li>
     *   <li><b>COMPLETE</b> - Loading complete, applies all pending updates with payload</li>
     * </ul>
     * </p>
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");
                    
                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG, "Genre loading started for " + total + " songs");
                        mIsGenreLoading = true;
                        
                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }
                        
                        ToastManager.showPersistentOverlay(PlaylistActivity.this, "Loading metadata...");
                        
                    } else if ("UPDATE".equals(status)) {
                        String songPath = intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");
                        int current = intent.getIntExtra("current", 0);
                        int total = intent.getIntExtra("total", 0);
                        
                        ToastManager.updatePersistentOverlay("Loading metadata... " + current + "/" + total);
                        
                        if (mAdapter != null && songPath != null && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }
                        
                    } else if ("COMPLETE".equals(status)) {
                        int loaded = intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");
                        
                        ToastManager.hidePersistentOverlay();
                        mIsGenreLoading = false;
                        
                        if (mAdapter != null) {
                            // This applies all pending genre updates with payload-based partial updates
                            // No full refresh - prevents scroll jitter
                            mAdapter.setGenreLoading(false);
                        }
                        
                        // Queue sorting until after loading completes
                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }
                        
                        // DO NOT call refreshFromService() here - it causes full list refresh and scroll jitter
                        // The adapter already has all the updated genres from the batched updates
                        
                        // Update MediaSession metadata in MusicService to reflect new genres
                        Intent refreshMetadataIntent = new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra("refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }
    
    /**
     * Registers the force refresh broadcast receiver for genre loading completion.
     * 
     * <p>This receiver listens for FORCE_PLAYLIST_REFRESH broadcasts from PlaylistService
     * after genre loading completes. Only refreshes if not in genre loading mode.</p>
     */
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - refreshing from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Only refresh if not in genre loading
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            } else {
                                Log.d(TAG, "Force refresh suppressed during genre loading");
                            }
                        }
                    });
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }
    
    /**
     * Applies header styling to all header TextViews in the activity.
     * This method recursively traverses the view hierarchy to find and style header texts.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     * Targets TextViews that contain header-like text such as "PLAYLIST", "SORT MODE",
     * "SEARCH RESULTS", or any text containing "songs".
     *
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") || 
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }
    
    /**
     * Applies the current theme color to all UI components.
     * This includes buttons, search bar border, edit text, and the SORT button.
     * Called when the theme changes or when the activity resumes.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();
        
        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearSearchButton != null) {
            mThemeHelper.updateButton(mClearSearchButton, mClearSearchButton.isEnabled());
        }
        
        if (mSortButton != null) {
            mSortButton.setTextColor(themeColor);
        }
        
        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }
        
        if (mSearchEditText != null) {
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
            
            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchEditText.setBackground(searchBackground);
            
            mSearchEditText.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for playlist and playback updates.
     * This includes receivers for player updates, playlist display, force updates,
     * and playlist load progress.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    // Skip updating during genre loading or user scrolling
                    if (!mIsGenreLoading && !mUserScrolling) {
                        // Reload current playing path from preferences
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                        
                        if (currentPath != null && mAdapter != null) {
                            // Find position by path
                            int displayPosition = findPositionByPath(currentPath);
                            if (displayPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                        
                        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                            if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                                focusCurrentSong();
                            }
                        }
                    }
                }
            }
        };
        
        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshFromService();
                            }
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    if (mAdapter != null && !mIsGenreLoading && !mUserScrolling) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                        
                        if (currentPath != null) {
                            int displayPosition = findPositionByPath(currentPath);
                            if (displayPosition >= 0) {
                                mCurrentPlayingPath = currentPath;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                        
                        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                            if (!mUserInteractionInProgress && !mIsGenreLoading && !mUserScrolling) {
                                focusCurrentSong();
                            }
                        }
                    }
                }
            }
        };
        
        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }
                    
                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }
                    
                    if (!exists && !mIsGenreLoading && !mUserScrolling) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);
                        
                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );
                        
                        mCurrentDisplayList.add(newSong);
                        
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }
                        
                        updateTitleAndCount();
                    }
                }
            }
        };
        
        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);
        
        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiver(mDisplayPlaylistReceiver, displayFilter);
        
        IntentFilter forceFilter = new IntentFilter();
        forceFilter.addAction("FORCE_UPDATE_PLAYER");
        registerReceiver(mForceUpdatePlayerReceiver, forceFilter);
        
        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiver(mPlaylistLoadProgressReceiver, progressFilter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     * This prevents crashes if the receiver was already unregistered.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister receiver", e);
            }
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     * Uses the device's screen density to calculate the correct pixel value.
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}