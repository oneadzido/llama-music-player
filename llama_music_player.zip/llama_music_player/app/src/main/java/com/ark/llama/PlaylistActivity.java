package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Displays the playlist, supports search and sort, and tracks the
 * currently playing song.
 *
 * <p>The activity reads the current playlist from
 * {@link MusicService} and listens for {@code UPDATE_PLAYER}
 * broadcasts for playback state. Users can search the playlist,
 * cycle through ten sort modes, and tap a song to play it. The row
 * that corresponds to the currently playing song is highlighted,
 * and the list scrolls it into view when a transition moves it
 * offscreen.</p>
 *
 * <h3>State Ownership</h3>
 * <p>{@link MusicService} owns the authoritative playlist and the
 * current playing index. This activity owns the display list, the
 * current sort mode, the presentation hint that highlights the
 * current row, the scroll position, and the genre-loading flag
 * that suppresses refreshes while a genre load is in flight. The
 * persistent genre-loading overlay is owned by
 * {@link PlaylistManager}.</p>
 *
 * <h3>Sort Progress Feedback</h3>
 * <p>Cycling the sort mode shows the process-wide dim-and-spinner
 * overlay for the duration of the sort. A sort on a large library
 * is fast; without a floor, the overlay would flash and vanish
 * before the user perceived it. The overlay appears the moment the
 * sort starts and disappears only after the RecyclerView has laid
 * out and drawn the sorted ordering: the hide is scheduled from
 * the list's next pre-draw callback, which fires after the
 * RecyclerView has committed the new data to its layout and
 * before the frame containing it is drawn. The overlay's exit
 * therefore reveals a list already in its final state, and
 * nothing further changes on screen. The
 * {@link #SORT_OVERLAY_MIN_DURATION_MS} floor is applied on top
 * of the draw wait, so a fast sort never flashes the overlay and
 * a slow sort never holds it past the drawn frame. The reason
 * token is released on every exit path from the sort, including
 * activity destruction.</p>
 *
 * <h3>Ordering</h3>
 * <p>Every {@code UPDATE_PLAYER} broadcast carries a monotonic
 * {@code generation}. The activity drops any broadcast with a
 * strictly lower generation than the highest it has seen. When the
 * service is rebound, the high-water mark resets to {@code -1},
 * because a new service instance restarts its counter at zero.</p>
 *
 * <h3>Edge Fast Scroll</h3>
 * <p>A vertical drag that starts inside the leftmost or rightmost
 * {@link #PLAYLIST_EDGE_SCROLL_DP} of the list scrolls the list
 * proportionally: a full viewport-height of finger travel maps to
 * {@link #FAST_SCROLL_FRACTION_PER_VIEWPORT} of the total
 * scrollable range, anchored at the position the drag began. A
 * drag that starts anywhere else is left to the RecyclerView's
 * own scroll handling.</p>
 *
 * <p>Fast scroll only engages when the content is at least
 * {@link #FAST_SCROLL_MIN_CONTENT_RATIO} times taller than the
 * viewport. On a shorter list the proportional mapping would be
 * too coarse for a user who is reading rows, and the edge zones
 * defer to ordinary scrolling.</p>
 *
 * <p>A tap is never consumed. The interceptor only takes over
 * once the finger has moved beyond the touch slop, so tapping a
 * song that happens to sit near an edge still plays it.</p>
 *
 * <h3>Library Reset</h3>
 * <p>When the library is reset, {@link PlaylistManager}'s reset
 * operation sends a {@code LIBRARY_RESET} broadcast that this
 * activity receives through its own receiver. The receiver clears
 * the display list and drops every piece of presentation state
 * that referred to a song that no longer exists, including the
 * genre-loading flag that a cancelled load would otherwise leave
 * set forever.</p>
 *
 * <h3>Split-Screen Layout</h3>
 * <p>Nothing changes. The RecyclerView is the scroller; it
 * simply scrolls further as the window shrinks. Row density is a
 * list concern, not a window concern, and every touch target
 * keeps its declared size. When the list is empty, the
 * placeholder that occupies its slot is centred in that slot,
 * below the header bar.</p>
 *
 * @see PlaylistAdapter
 * @see MusicService
 * @see PlaylistManager
 * @see OverlayManager
 * @see ThemeManager
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.0.0
 */
public class PlaylistActivity extends Activity {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaylistActivity";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Broadcast action that requests a playlist refresh. */
    private static final String ACTION_REFRESH_PLAYLIST =
        "REFRESH_PLAYLIST";

    /** Broadcast action that requests a sort mode change. */
    private static final String ACTION_UPDATE_SORT_MODE =
        "UPDATE_SORT_MODE";

    /** Intent extra key for the sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Debounce delay for button clicks, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;

    /** Delay before the initial focus scroll, in milliseconds. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;

    /** Duration of button press animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Maximum length of the search field. */
    private static final int MAX_SEARCH_LENGTH = 128;

    /** Corner radius of the search bar, in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;

    /** Corner radius of the search input, in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;

    /** Stroke width of the search bar border, in density-independent
     *  pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;

    /** Padding of the empty-state container, in density-independent
     *  pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;

    /**
     * Width of the fast-scroll touch zone from each side of the
     * playlist, in density-independent pixels.
     *
     * <p>The list row's own content padding is 16dp on each side;
     * the zone extends another 16dp inward from there, for a total
     * of 32dp. A vertical drag that starts inside one of these
     * zones scrolls the list proportionally to the library's total
     * height, so the end of the library is reachable in a bounded
     * number of gestures regardless of how many songs it holds.</p>
     */
    private static final int PLAYLIST_EDGE_SCROLL_DP = 32;

    /**
     * Fraction of the total scrollable range traversed by one
     * viewport-height of finger travel in an edge fast-scroll
     * zone.
     */
    private static final float FAST_SCROLL_FRACTION_PER_VIEWPORT = 0.05f;

    /**
     * Minimum content-to-viewport ratio at which fast scroll
     * engages.
     */
    private static final float FAST_SCROLL_MIN_CONTENT_RATIO = 3.0f;

    /**
     * Minimum time the sort overlay stays on screen, measured from
     * the moment the sort began, in milliseconds.
     *
     * <p>A sort on a large library is fast; without a floor the
     * overlay would flash and vanish before the user perceived it.
     * The floor is applied on top of the wait for the RecyclerView's
     * draw: the overlay disappears at whichever is longer, the
     * frame that paints the sorted list or the floor measured from
     * the sort's start. The overlay therefore never exits before
     * the list is on screen and never flashes on a small library.</p>
     */
    private static final long SORT_OVERLAY_MIN_DURATION_MS = 250L;

    /** Sort mode: title, ascending. */
    private static final int SORT_TITLE_AZ = 0;

    /** Sort mode: title, descending. */
    private static final int SORT_TITLE_ZA = 1;

    /** Sort mode: artist, ascending. */
    private static final int SORT_ARTIST_AZ = 2;

    /** Sort mode: artist, descending. */
    private static final int SORT_ARTIST_ZA = 3;

    /** Sort mode: album, ascending. */
    private static final int SORT_ALBUM_AZ = 4;

    /** Sort mode: album, descending. */
    private static final int SORT_ALBUM_ZA = 5;

    /** Sort mode: genre, ascending. */
    private static final int SORT_GENRE_AZ = 6;

    /** Sort mode: genre, descending. */
    private static final int SORT_GENRE_ZA = 7;

    /** Sort mode: oldest file first. */
    private static final int SORT_OLDEST = 8;

    /** Sort mode: newest file first. */
    private static final int SORT_NEWEST = 9;

    /** Total number of sort modes. */
    private static final int SORT_MODE_COUNT = 10;

    /** Shared preferences key for the persisted sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Sort labels shown next to the "SORT MODE" header. */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",  "[TITLE Z-A]",
        "[ARTIST A-Z]", "[ARTIST Z-A]",
        "[ALBUM A-Z]",  "[ALBUM Z-A]",
        "[GENRE A-Z]",  "[GENRE Z-A]",
        "[OLDEST]",     "[NEWEST]"
    };

    /** Sort transition messages shown after cycling the sort mode. */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",  "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]", "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",  "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",  "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",       "SORT MODE: NEWEST"
    };

    // ============================================================================
    // UI Components
    // ============================================================================

    /** Recycler view that displays the playlist rows. */
    private RecyclerView mPlaylistRecyclerView;

    /** Layout manager backing the recycler view. */
    private LinearLayoutManager mLayoutManager;

    /** Adapter backing the recycler view. */
    private PlaylistAdapter mAdapter;

    /** Text view showing the sort mode or search context. */
    private TextView mPlaylistTitle;

    /** Text view showing the song count. */
    private TextView mSongCountText;

    /** Text field for the search query. */
    private EditText mSearchText;

    /** Button that opens the search bar. */
    private Button mSearchButton;

    /** Button that clears the search query. */
    private Button mClearButton;

    /** Button that cycles the sort mode. */
    private Button mSortButton;

    /** Button that closes the activity or hides the search bar. */
    private Button mCancelButton;

    /** Container that hosts the search bar. */
    private LinearLayout mSearchBar;

    /** Container shown when the playlist is empty. */
    private LinearLayout mEmptyContainer;

    /** Root frame layout that hosts the empty state. */
    private FrameLayout mRootContainer;

    // ============================================================================
    // Data Components
    // ============================================================================

    /** Songs currently displayed, after search and sort. */
    private ArrayList<Song> mCurrentDisplayList;

    /** Path of the song currently highlighted as playing, or null. */
    @Nullable private String mCurrentPlayingPath = null;

    /** True while the search bar is visible. */
    private boolean mIsSearchVisible = false;

    /** Input method manager used to show and hide the keyboard. */
    private InputMethodManager mInputMethodManager;

    // ============================================================================
    // Scroll State Management
    // ============================================================================

    /** True while the user is dragging or flinging the list. */
    private volatile boolean mUserScrolling = false;

    /** Saved scroll position, restored after list updates. */
    @Nullable private Parcelable mSavedScrollState = null;

    /** True while a saved scroll position is waiting to be
     *  restored. */
    private boolean mScrollRestorePending = false;

    // ============================================================================
    // Theme Components
    // ============================================================================

    /** Manager for the current theme color. */
    private ThemeManager mThemeManager;

    /** Helper for applying theme colors. */
    private ThemeHelper mThemeHelper;

    /** Receiver for theme color change broadcasts. */
    private BroadcastReceiver mThemeReceiver;

    // ============================================================================
    // Sort Components
    // ============================================================================

    /** Current sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    /** Timestamp of the last sort button click. */
    private long mLastSortClickTime = 0;

    /** True when a sort should be applied once genre loading
     *  completes. */
    private boolean mPendingSortAfterGenre = false;

    /**
     * Pending hide runnable for the sort overlay, or null when no
     * sort is in flight. Stored so a subsequent cycle can cancel
     * the previous hide before scheduling its own.
     */
    @Nullable private Runnable mSortOverlayHideRunnable = null;

    /**
     * Generation of the sort cycle.
     *
     * <p>Advanced by every {@link #cycleSortMode()} call. The hide
     * callback that runs after the RecyclerView has drawn the sorted
     * list checks this value against the generation its cycle was
     * started with, so a superseded cycle cannot take the overlay
     * down on the current cycle's behalf.</p>
     */
    private long mSortGeneration = 0L;

    // ============================================================================
    // Interaction State
    // ============================================================================

    /** Timestamp of the last search button click. */
    private long mLastSearchClickTime = 0;

    /** Timestamp of the last cancel button click. */
    private long mLastCancelClickTime = 0;

    /** True while a tap is being processed. */
    private volatile boolean mUserInteractionInProgress = false;

    /** True while genre loading is in flight. */
    private volatile boolean mIsGenreLoading = false;

    /** Handler for delayed operations on the main thread. */
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // Generation Gate and Deferred Focus
    // ============================================================================

    /** Highest generation seen in an {@code UPDATE_PLAYER}
     *  broadcast. */
    private long mLastSeenGeneration = -1L;

    /** Row waiting for focus once genre loading completes, or -1. */
    private int mDeferredGenreFocusRow = -1;

    // ============================================================================
    // Service Connection
    // ============================================================================

    /** Bound service, or null while not bound. */
    @Nullable private MusicService mMusicService;

    /** True while the service is bound. */
    private boolean mIsServiceBound = false;

    /** Connection that resets the generation gate on every
     *  (re)connect. */
    private final ServiceConnection mServiceConnection =
        new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            MusicService.LocalBinder binder =
                (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;
            mLastSeenGeneration = -1L;
            refreshPlaylistFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicService = null;
            mIsServiceBound = false;
        }
    };

    // ============================================================================
    // Broadcast Receivers
    // ============================================================================

    /** Receiver for {@code UPDATE_PLAYER} broadcasts. */
    private BroadcastReceiver mUpdatePlayerReceiver;

    /** Receiver for {@code DISPLAY_PLAYLIST} broadcasts. */
    private BroadcastReceiver mDisplayPlaylistReceiver;

    /** Receiver for {@code METADATA_UPDATED} broadcasts. */
    private BroadcastReceiver mMetadataUpdatedReceiver;

    /** Receiver for playlist load progress broadcasts. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;

    /** Receiver for {@code GENRE_UPDATE} broadcasts. */
    private BroadcastReceiver mGenreUpdateReceiver;

    /** Receiver for {@code REFRESH_PLAYLIST} broadcasts. */
    private BroadcastReceiver mRefreshPlaylistReceiver;

    /** Receiver for {@code LIBRARY_RESET} broadcasts emitted by
     *  {@link PlaylistManager}. */
    private BroadcastReceiver mLibraryResetReceiver;

    // ============================================================================
    // Activity Lifecycle Methods
    // ============================================================================

    /**
     * Initializes the activity, its view hierarchy, its receivers,
     * and the service binding.
     *
     * @param savedInstanceState Previously saved state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ToastManager.init(this);
        OverlayManager.init(this);

        setFullScreen();
        setContentView(R.layout.activity_playlist);

        CharacterMapper.init(this);

        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager =
            (InputMethodManager) getSystemService(
                Context.INPUT_METHOD_SERVICE);

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);

        loadCurrentPlayingPath();
        loadSortMode();

        initializeViews();
        setupSearchListener();
        setupScrollListener();
        setupEdgeFastScroll();

        registerReceivers();
        registerGenreUpdateReceiver();
        registerRefreshPlaylistReceiver();
        registerLibraryResetReceiver();

        bindService(new Intent(this, MusicService.class),
            mServiceConnection, BIND_AUTO_CREATE);

        applyThemeToUI();
        themeAllHeaders();
    }

    /**
     * Reattaches a persistent overlay if one is active, refreshes
     * the list from the service, focuses the current song, and
     * reapplies the theme.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }

        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }

        refreshPlaylistFromService();

        if (mAdapter != null) {
            int currentPosition =
                findPositionByPath(mCurrentPlayingPath);
            mAdapter.setCurrentPlayingIndex(currentPosition);
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSearchText == null
                        || TextUtils.isEmpty(
                            mSearchText.getText().toString().trim())) {
                    if (!mUserInteractionInProgress && !mIsGenreLoading
                            && !mUserScrolling) {
                        focusCurrentSong();
                    }
                }
            }
        }, 100);

        if (mSortButton != null && mThemeHelper != null) {
            mThemeHelper.updateButton(mSortButton, true);
        }
        updateSortHeaderDisplay();

        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }

    /**
     * Unregisters the theme receiver so it is not invoked while
     * the activity is not visible.
     */
    @Override
    protected void onPause() {
        super.onPause();

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister theme receiver", exception);
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reattaches a persistent overlay if one is active.
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Unbinds from the service, unregisters every receiver, and
     * removes every handler callback.
     *
     * <p>Releases the sort overlay reason if a sort was still in
     * flight. The overlay itself is owned by the process, so
     * releasing the reason here does not affect any other overlay
     * a different caller may be showing.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
        OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT);

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unbind from MusicService", exception);
            }
            mIsServiceBound = false;
        }

        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister theme receiver", exception);
            }
        }

        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mMetadataUpdatedReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mRefreshPlaylistReceiver);
        unregisterReceiverSafely(mLibraryResetReceiver);

        mMainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Reapplies immersive mode when the window gains focus and
     * reattaches any persistent overlay.
     *
     * @param hasFocus True when the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus
                && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }

    /**
     * Hides the search bar when it is visible, or returns to the
     * music player otherwise.
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
        } else {
            returnToMusicPlayer();
        }
    }

    // ============================================================================
    // Navigation
    // ============================================================================

    /**
     * Returns to the music player activity with the slide-left
     * transition.
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(
            R.anim.slide_in_left, R.anim.slide_out_right);
    }

    // ============================================================================
    // Edge Fast Scroll
    // ============================================================================

    /**
     * Installs the edge fast-scroll interceptor on the playlist
     * RecyclerView.
     *
     * <p>A vertical drag that starts inside the leftmost or
     * rightmost {@link #PLAYLIST_EDGE_SCROLL_DP} of the list
     * scrolls the list proportionally: a full viewport-height of
     * finger travel maps to
     * {@link #FAST_SCROLL_FRACTION_PER_VIEWPORT} of the total
     * scrollable range, anchored at the position the drag began. A
     * drag that starts anywhere else is left to the RecyclerView's
     * own scroll handling.</p>
     *
     * <p>Fast scroll only engages when the content is at least
     * {@link #FAST_SCROLL_MIN_CONTENT_RATIO} times taller than the
     * viewport. On a shorter list the proportional mapping would
     * be too coarse for a user who is reading rows, and the edge
     * zones defer to ordinary scrolling.</p>
     *
     * <p>A tap is never consumed. The interceptor only takes over
     * once the finger has moved beyond the touch slop, so tapping
     * a song that happens to sit near an edge still plays it. Once
     * the interceptor has taken over, it cancels any scroll the
     * RecyclerView had already begun in its slop window and drives
     * the rest of the gesture itself.</p>
     */
    private void setupEdgeFastScroll() {
        if (mPlaylistRecyclerView == null) {
            return;
        }

        final int edgeZonePx = dpToPx(PLAYLIST_EDGE_SCROLL_DP);
        final int touchSlop = ViewConfiguration.get(this)
            .getScaledTouchSlop();

        mPlaylistRecyclerView.addOnItemTouchListener(
            new RecyclerView.OnItemTouchListener() {

                /** Y coordinate of the current gesture's starting
                 * touch, in view-local pixels. */
                private float anchorTouchY = 0f;

                /** Scroll offset in pixels at the moment the
                 * gesture started. */
                private int anchorScrollY = 0;

                /** Total scrollable range in pixels, sampled at
                 * gesture start. */
                private int scrollableRange = 1;

                /** Viewport height in pixels, sampled at gesture
                 * start. */
                private int viewportHeight = 1;

                /** True when the current gesture started inside an
                 * edge zone. */
                private boolean startedInEdgeZone = false;

                /** True once the interceptor has taken over the
                 * gesture. */
                private boolean consuming = false;

                @Override
                public boolean onInterceptTouchEvent(
                        @NonNull RecyclerView recyclerView,
                        @NonNull MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN: {
                            final float x = event.getX();
                            final int width = recyclerView.getWidth();
                            startedInEdgeZone = (x <= edgeZonePx
                                || x >= width - edgeZonePx);
                            consuming = false;
                            if (startedInEdgeZone) {
                                anchorTouchY = event.getY();
                                anchorScrollY = recyclerView
                                    .computeVerticalScrollOffset();
                                final int contentHeight = recyclerView
                                    .computeVerticalScrollRange();
                                viewportHeight = Math.max(
                                    1, recyclerView.getHeight());
                                scrollableRange = Math.max(
                                    1,
                                    contentHeight - viewportHeight);
                            }
                            return false;
                        }
                        case MotionEvent.ACTION_MOVE: {
                            if (!startedInEdgeZone) {
                                return false;
                            }
                            if (!consuming) {
                                if (Math.abs(
                                        event.getY() - anchorTouchY)
                                        <= touchSlop) {
                                    return false;
                                }
                                if (!fastScrollEngages(recyclerView)) {
                                    startedInEdgeZone = false;
                                    return false;
                                }
                                recyclerView.stopScroll();
                                consuming = true;
                                return true;
                            }
                            applyProportionalScroll(
                                recyclerView, event.getY());
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            final boolean wasConsuming = consuming;
                            consuming = false;
                            startedInEdgeZone = false;
                            return wasConsuming;
                        }
                        default:
                            return false;
                    }
                }

                @Override
                public void onTouchEvent(
                        @NonNull RecyclerView recyclerView,
                        @NonNull MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_MOVE: {
                            applyProportionalScroll(
                                recyclerView, event.getY());
                            break;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            consuming = false;
                            startedInEdgeZone = false;
                            break;
                        }
                        default:
                            break;
                    }
                }

                @Override
                public void onRequestDisallowInterceptTouchEvent(
                        boolean disallowIntercept) {
                    // The RecyclerView is asking whether the
                    // listener wants to veto an interception.
                    // The listener accepts the request
                    // unconditionally.
                }

                /**
                 * Returns whether the library is long enough for
                 * proportional fast scroll to be useful.
                 *
                 * @param recyclerView The playlist RecyclerView
                 * @return True when content exceeds
                 *         {@link #FAST_SCROLL_MIN_CONTENT_RATIO}
                 *         times the viewport
                 */
                private boolean fastScrollEngages(
                        @NonNull RecyclerView recyclerView) {
                    final int contentHeight = recyclerView
                        .computeVerticalScrollRange();
                    final int viewport = Math.max(
                        1, recyclerView.getHeight());
                    return contentHeight
                        > viewport * FAST_SCROLL_MIN_CONTENT_RATIO;
                }

                /**
                 * Moves the RecyclerView so its scroll offset is a
                 * fixed function of the finger's vertical
                 * position, measured from the position the
                 * gesture began.
                 *
                 * @param recyclerView The playlist RecyclerView
                 * @param currentTouchY Current finger Y in
                 *        view-local pixels
                 */
                private void applyProportionalScroll(
                        @NonNull RecyclerView recyclerView,
                        float currentTouchY) {
                    final float viewportFraction =
                        (currentTouchY - anchorTouchY) / viewportHeight;
                    final float libraryFraction = viewportFraction
                        * FAST_SCROLL_FRACTION_PER_VIEWPORT;
                    final int targetOffset = anchorScrollY
                        + Math.round(
                            libraryFraction * scrollableRange);
                    final int currentOffset = recyclerView
                        .computeVerticalScrollOffset();
                    final int delta = targetOffset - currentOffset;
                    if (delta != 0) {
                        recyclerView.scrollBy(0, delta);
                    }
                }
            });
    }

    // ============================================================================
    // Scroll Listener
    // ============================================================================

    /**
     * Attaches the scroll listener that tracks the user's
     * scrolling state, saves the scroll position when the user is
     * not actively scrolling, and relays the scrolling state to
     * the adapter.
     */
    private void setupScrollListener() {
        mPlaylistRecyclerView.addOnScrollListener(
            new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(
                    @NonNull RecyclerView recyclerView, int newState) {
                boolean scrolling =
                    (newState != RecyclerView.SCROLL_STATE_IDLE);
                mUserScrolling = scrolling;
                if (mAdapter != null) {
                    mAdapter.setScrolling(scrolling);
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView,
                                   int dx, int dy) {
                if (mLayoutManager != null && !mUserScrolling) {
                    mSavedScrollState =
                        mLayoutManager.onSaveInstanceState();
                }
            }
        });
    }

    /**
     * Saves the current scroll position so it can be restored
     * after the next list update.
     */
    private void saveScrollPosition() {
        if (mLayoutManager != null && !mUserScrolling) {
            mSavedScrollState = mLayoutManager.onSaveInstanceState();
            mScrollRestorePending = true;
        }
    }

    /**
     * Restores the saved scroll position when one is pending.
     */
    private void restoreScrollPosition() {
        if (mScrollRestorePending && mSavedScrollState != null
                && mLayoutManager != null && !mUserScrolling) {
            try {
                mLayoutManager.onRestoreInstanceState(
                    mSavedScrollState);
                mScrollRestorePending = false;
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to restore scroll position", exception);
                mScrollRestorePending = false;
            }
        }
    }

    /**
     * Returns whether the given row is currently offscreen.
     *
     * @param row Row to test
     * @return True when the row is outside the visible range
     */
    private boolean shouldAutoScrollTo(int row) {
        if (mLayoutManager == null || mCurrentDisplayList == null) {
            return false;
        }
        if (row < 0 || row >= mCurrentDisplayList.size()) {
            return false;
        }
        int firstVisibleRow =
            mLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastVisibleRow =
            mLayoutManager.findLastCompletelyVisibleItemPosition();
        if (firstVisibleRow == RecyclerView.NO_POSITION
                || lastVisibleRow == RecyclerView.NO_POSITION) {
            return false;
        }
        return row < firstVisibleRow || row > lastVisibleRow;
    }

    /**
     * Scrolls the given row into the vertical center of the list
     * when it is offscreen.
     *
     * @param row Row to scroll into view
     */
    private void scrollToRowIfOffscreen(int row) {
        if (mPlaylistRecyclerView == null || mLayoutManager == null) {
            return;
        }
        if (!shouldAutoScrollTo(row)) {
            return;
        }
        mScrollRestorePending = false;
        final int finalRow = row;
        mPlaylistRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                mLayoutManager.scrollToPositionWithOffset(
                    finalRow, mPlaylistRecyclerView.getHeight() / 2);
            }
        });
    }

    /**
     * Applies the row stored in {@link #mDeferredGenreFocusRow} as
     * the scroll target and clears the deferred value.
     */
    private void applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) {
            return;
        }
        int deferredRow = mDeferredGenreFocusRow;
        mDeferredGenreFocusRow = -1;
        scrollToRowIfOffscreen(deferredRow);
    }

    // ============================================================================
    // Refresh
    // ============================================================================

    /**
     * Rebuilds the display list from the service's current
     * playlist.
     */
    private void refreshPlaylistFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG,
                "refreshPlaylistFromService suppressed during user scrolling");
            return;
        }

        if (mMusicService == null) {
            return;
        }

        Song currentSong = mMusicService.getCurrentSong();
        if (currentSong != null && currentSong.getPath() != null) {
            mCurrentPlayingPath = currentSong.getPath();
        }

        saveScrollPosition();

        ArrayList<Song> playlist =
            mMusicService.getCurrentPlaylist();
        if (playlist == null || playlist.isEmpty()) {
            mCurrentDisplayList.clear();
            mCurrentPlayingPath = null;
            mDeferredGenreFocusRow = -1;
            showEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
                mAdapter.setCurrentPlayingPath(null);
            }
            updateTitleAndCount();
            return;
        }

        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";
        if (!TextUtils.isEmpty(searchText)) {
            performSearch(searchText);
        } else {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(playlist);
            applyCurrentSort(false);
            hideEmptyView();
            if (mAdapter != null) {
                mAdapter.updateList(mCurrentDisplayList);
            }
            updateTitleAndCount();
        }

        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                restoreScrollPosition();
            }
        }, 100);
    }

    // ============================================================================
    // Sort
    // ============================================================================

    /**
     * Reads the persisted sort mode into memory.
     */
    private void loadSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode =
            preferences.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }

    /**
     * Persists the current sort mode.
     */
    private void saveSortMode() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit()
            .putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }

    /**
     * Advances to the next sort mode, persists it, broadcasts the
     * change, and re-sorts the display list on a background thread.
     *
     * <p>The process-wide dim-and-spinner overlay is shown for the
     * duration of the sort, so the user receives visual feedback on
     * the operation. The overlay is hidden only after the
     * RecyclerView has laid out and drawn the sorted ordering: the
     * hide is scheduled from the list's next pre-draw callback,
     * which fires after the RecyclerView has committed the new data
     * to its layout and before the frame containing it is drawn.
     * The overlay's exit therefore reveals a list already in its
     * final state, and nothing further changes on screen. The
     * {@link #SORT_OVERLAY_MIN_DURATION_MS} floor is applied on top
     * of the draw wait, so a fast sort never flashes the overlay
     * and a slow sort never holds it past the drawn frame. Each
     * cycle advances {@link #mSortGeneration} so a superseded
     * cycle's draw callback cannot take the overlay down on the
     * current cycle's behalf.</p>
     */
    private void cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        saveSortMode();

        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);

        final ArrayList<Song> listToSort =
            new ArrayList<>(mCurrentDisplayList);
        final String currentPath = mCurrentPlayingPath;
        final int sortMode = mCurrentSortMode;
        final long sortStartedElapsed = SystemClock.elapsedRealtime();
        final long thisSortGeneration = ++mSortGeneration;

        OverlayManager.show(OverlayManager.REASON_PLAYLIST_SORT);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Collections.sort(listToSort,
                    getComparatorForSortMode(sortMode));

                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            cancelSortOverlayHide();
                            OverlayManager.hide(
                                OverlayManager.REASON_PLAYLIST_SORT);
                            return;
                        }

                        if (thisSortGeneration != mSortGeneration) {
                            // A newer cycle has superseded this one;
                            // the newer cycle owns the overlay now.
                            return;
                        }

                        mCurrentDisplayList.clear();
                        mCurrentDisplayList.addAll(listToSort);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);

                            if (currentPath != null) {
                                int newPosition =
                                    findPositionByPath(currentPath);
                                if (newPosition >= 0) {
                                    mCurrentPlayingPath = currentPath;
                                    mAdapter.setCurrentPlayingIndex(
                                        newPosition);

                                    mMainHandler.postDelayed(
                                        new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!mUserScrolling
                                                    && !mIsGenreLoading
                                                    && !mUserInteractionInProgress) {
                                                focusCurrentSong();
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                            }
                        }

                        updateTitleAndCount();
                        updateSortHeaderDisplay();

                        ToastManager.showToast(
                            PlaylistActivity.this,
                            SORT_TOAST_MESSAGES[mCurrentSortMode],
                            ToastManager.LENGTH_SHORT);

                        hideSortOverlayAfterListDraws(
                            thisSortGeneration, sortStartedElapsed);
                    }
                });
            }
        }).start();
    }

    /**
     * Cancels any pending sort-overlay hide. Idempotent.
     */
    private void cancelSortOverlayHide() {
        if (mSortOverlayHideRunnable != null) {
            mMainHandler.removeCallbacks(mSortOverlayHideRunnable);
            mSortOverlayHideRunnable = null;
        }
    }

    /**
     * Schedules the sort overlay's hide for the moment the
     * RecyclerView has laid out and drawn the sorted list.
     *
     * <p>A sort on a large library is fast; hiding the overlay on a
     * timer would let it disappear before the RecyclerView has
     * committed the new ordering to the screen, and the user would
     * see the list repaint itself after the overlay's exit. The
     * pre-draw callback fires after the RecyclerView's layout for
     * the new data is complete and before the frame is drawn; the
     * hide is then posted from inside it, which defers removal of
     * the overlay until after the frame that contains the new list
     * has been committed. The overlay's exit therefore reveals a
     * list already in its final state, and nothing further changes
     * on screen.</p>
     *
     * <p>The {@link #SORT_OVERLAY_MIN_DURATION_MS} floor is applied
     * on top of the draw wait. If the sort is faster than the floor,
     * the overlay waits out the remainder after the draw; if the
     * sort is slower, the overlay hides as soon as the frame is
     * committed.</p>
     *
     * <p>The sort generation is checked before the hide is
     * scheduled. A newer cycle that began before this one's draw
     * callback fired owns the overlay now, and this cycle must not
     * hide it on the newer cycle's behalf.</p>
     *
     * @param sortGeneration Generation of the cycle this callback
     *        serves
     * @param sortStartedElapsed Uptime at which the cycle began
     */
    private void hideSortOverlayAfterListDraws(
            final long sortGeneration,
            final long sortStartedElapsed) {
        if (mPlaylistRecyclerView == null) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        final ViewTreeObserver observer =
            mPlaylistRecyclerView.getViewTreeObserver();
        if (!observer.isAlive()) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(
                    sortStartedElapsed);
            }
            return;
        }

        observer.addOnPreDrawListener(
            new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                final ViewTreeObserver current =
                    mPlaylistRecyclerView.getViewTreeObserver();
                if (current.isAlive()) {
                    current.removeOnPreDrawListener(this);
                }
                mPlaylistRecyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (sortGeneration != mSortGeneration) {
                            return;
                        }
                        scheduleSortOverlayHideAtMinDuration(
                            sortStartedElapsed);
                    }
                });
                return true;
            }
        });
    }

    /**
     * Schedules the sort overlay's hide for the end of the
     * {@link #SORT_OVERLAY_MIN_DURATION_MS} floor, measured from
     * the moment the sort began.
     *
     * @param sortStartedElapsed Uptime at which the sort began
     */
    private void scheduleSortOverlayHideAtMinDuration(
            final long sortStartedElapsed) {
        final long elapsed = SystemClock.elapsedRealtime()
            - sortStartedElapsed;
        final long remaining = Math.max(0L,
            SORT_OVERLAY_MIN_DURATION_MS - elapsed);
        scheduleSortOverlayHide(remaining);
    }

    /**
     * Schedules the sort overlay's hide after the given delay.
     *
     * <p>Cancels any previously-scheduled hide first, so a rapid
     * sequence of sort cycles produces one hide at the end of the
     * sequence rather than one per cycle.</p>
     *
     * @param delayMs Delay in milliseconds; 0 hides on the next
     *        main-thread turn
     */
    private void scheduleSortOverlayHide(long delayMs) {
        cancelSortOverlayHide();
        mSortOverlayHideRunnable = new Runnable() {
            @Override
            public void run() {
                mSortOverlayHideRunnable = null;
                OverlayManager.hide(
                    OverlayManager.REASON_PLAYLIST_SORT);
            }
        };
        mMainHandler.postDelayed(mSortOverlayHideRunnable, delayMs);
    }

    /**
     * Sorts the display list in place by the current sort mode.
     *
     * @param showToast True to broadcast the sort change and show a
     *        toast
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }

        final String currentPath = mCurrentPlayingPath;

        Collections.sort(mCurrentDisplayList,
            getComparatorForSortMode(mCurrentSortMode));

        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }

        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);

            if (currentPath != null) {
                int newPosition = findPositionByPath(currentPath);
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath;
                    mAdapter.setCurrentPlayingIndex(newPosition);

                    if (showToast) {
                        mMainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!mUserScrolling
                                        && !mIsGenreLoading
                                        && !mUserInteractionInProgress) {
                                    focusCurrentSong();
                                }
                            }
                        }, FOCUS_SCROLL_DELAY_MS);
                    }
                }
            }
        }

        updateTitleAndCount();

        if (showToast) {
            ToastManager.showToast(this,
                SORT_TOAST_MESSAGES[mCurrentSortMode],
                ToastManager.LENGTH_SHORT);
        }
    }

    /**
     * Returns the index of the song with the given path in the
     * display list, or -1 when it is not present.
     *
     * @param path Path to search for
     * @return The display-list index, or -1
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null && path.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Returns the last-modified timestamp of the given song's file.
     *
     * @param song Song to inspect
     * @return Last-modified time in milliseconds since the epoch,
     *         or 0 when the song or its path is null
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        File file = new File(song.getPath());
        return file.lastModified();
    }

    /**
     * Returns the comparator that orders songs according to the
     * given sort mode.
     *
     * @param sortMode Sort mode to resolve
     * @return The comparator for the mode, or a title-ascending
     *         comparator when the mode is unknown
     */
    private Comparator<Song> getComparatorForSortMode(
            final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(
                            secondTitle);
                    }
                };

            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return secondTitle.compareToIgnoreCase(
                            firstTitle);
                    }
                };

            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = firstArtist
                            .compareToIgnoreCase(secondArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstArtist = firstSong.getArtist();
                        String secondArtist = secondSong.getArtist();
                        if (firstArtist == null) firstArtist = "";
                        if (secondArtist == null) secondArtist = "";
                        int comparisonResult = secondArtist
                            .compareToIgnoreCase(firstArtist);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = firstAlbum
                            .compareToIgnoreCase(secondAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstAlbum = firstSong.getAlbum();
                        String secondAlbum = secondSong.getAlbum();
                        if (firstAlbum == null) firstAlbum = "";
                        if (secondAlbum == null) secondAlbum = "";
                        int comparisonResult = secondAlbum
                            .compareToIgnoreCase(firstAlbum);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = firstGenre
                            .compareToIgnoreCase(secondGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstGenre = firstSong.getGenre();
                        String secondGenre = secondSong.getGenre();
                        if (firstGenre == null) firstGenre = "";
                        if (secondGenre == null) secondGenre = "";
                        int comparisonResult = secondGenre
                            .compareToIgnoreCase(firstGenre);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            firstDate, secondDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        long firstDate = getSongDate(firstSong);
                        long secondDate = getSongDate(secondSong);
                        int comparisonResult = Long.compare(
                            secondDate, firstDate);
                        if (comparisonResult == 0) {
                            String firstTitle = firstSong.getTitle();
                            String secondTitle = secondSong.getTitle();
                            if (firstTitle == null) firstTitle = "";
                            if (secondTitle == null) secondTitle = "";
                            return firstTitle.compareToIgnoreCase(
                                secondTitle);
                        }
                        return comparisonResult;
                    }
                };

            default:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song firstSong,
                                       Song secondSong) {
                        String firstTitle = firstSong.getTitle();
                        String secondTitle = secondSong.getTitle();
                        if (firstTitle == null) firstTitle = "";
                        if (secondTitle == null) secondTitle = "";
                        return firstTitle.compareToIgnoreCase(
                            secondTitle);
                    }
                };
        }
    }

    /**
     * Updates the header to show the current sort mode or search
     * context, and toggles the sort button visibility.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle == null) {
            return;
        }
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            mPlaylistTitle.setText("SORT MODE "
                + SORT_DISPLAY_NAMES[mCurrentSortMode]);
            if (mSortButton != null
                    && mSortButton.getVisibility() != View.VISIBLE) {
                mSortButton.setVisibility(View.VISIBLE);
            }
        } else {
            mPlaylistTitle.setText("SEARCH RESULTS");
            if (mSortButton != null
                    && mSortButton.getVisibility() == View.VISIBLE) {
                mSortButton.setVisibility(View.GONE);
            }
        }
        mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
    }

    // ============================================================================
    // Display
    // ============================================================================

    /**
     * Shows the empty-state placeholder in the slot the playlist
     * occupies.
     *
     * <p>The placeholder is added as a sibling of the playlist, in
     * the same {@link LinearLayout} the playlist lives in, carrying
     * the same layout weight. It therefore fills the same vertical
     * band the list fills, and its centred text appears exactly in
     * the middle of the view between the header bar and the bottom
     * of the window. The placeholder does not overlay the top bar
     * or the header bar; it sits below them.</p>
     */
    private void showEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent existingParent = mEmptyContainer.getParent();
            if (existingParent instanceof ViewGroup) {
                ((ViewGroup) existingParent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        mEmptyContainer = new LinearLayout(this);
        mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
        mEmptyContainer.setGravity(Gravity.CENTER);
        mEmptyContainer.setPadding(
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP),
            dpToPx(EMPTY_CONTAINER_PADDING_DP));

        TextView emptyText = new TextView(this);
        emptyText.setText(
            "No songs yet.\n\nUse MANAGER to import music folders.");
        emptyText.setTextColor(Color.parseColor("#C0C0C0"));
        emptyText.setTextSize(14);
        emptyText.setGravity(Gravity.CENTER);
        mEmptyContainer.addView(emptyText);

        if (mPlaylistRecyclerView != null) {
            final ViewParent parent = mPlaylistRecyclerView.getParent();
            if (parent instanceof LinearLayout) {
                final LinearLayout parentLayout =
                    (LinearLayout) parent;
                final LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0, 1f);
                parentLayout.addView(mEmptyContainer, params);
            }
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }

    /**
     * Removes the empty-state placeholder and shows the playlist.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            final ViewParent parent = mEmptyContainer.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(mEmptyContainer);
            }
            mEmptyContainer = null;
        }

        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Creates the playlist adapter and attaches it to the
     * recycler view.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList,
            new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }

                mUserInteractionInProgress = true;

                Intent intent = new Intent(
                    PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);

                final String selectedPath = song.getPath();
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingPath = selectedPath;
                            if (mAdapter != null) {
                                int newPosition =
                                    findPositionByPath(selectedPath);
                                mAdapter.setCurrentPlayingIndex(
                                    newPosition);
                            }
                        } catch (Exception exception) {
                            Log.e(TAG,
                                "Error setting playing index",
                                exception);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });

        int currentPosition = findPositionByPath(mCurrentPlayingPath);
        mAdapter.setCurrentPlayingIndex(currentPosition);

        mLayoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(mLayoutManager);

        mPlaylistRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Updates the header and song count text from the current
     * search and display state.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchText != null
            ? mSearchText.getText().toString() : "";

        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE "
                    + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount
                    + (songCount == 1 ? " song" : " songs"));
            }
        } else {
            int totalSongs = (mMusicService != null
                && mMusicService.getCurrentPlaylist() != null)
                ? mMusicService.getCurrentPlaylist().size() : 0;

            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(
                    Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                int songCount = mCurrentDisplayList.size();
                mSongCountText.setText(songCount + " / " + totalSongs
                    + (totalSongs == 1 ? " song" : " songs"));
            }
        }
    }

    /**
     * Reads the persisted last playing path into memory.
     */
    private void loadCurrentPlayingPath() {
        SharedPreferences preferences =
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingPath =
            preferences.getString(KEY_LAST_SONG_PATH, null);
    }

    /**
     * Scrolls the current song into the vertical center of the
     * list when it is offscreen and the user is not interacting
     * with the list.
     */
    private void focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG,
                "focusCurrentSong suppressed during genre loading");
            return;
        }

        if (mUserScrolling) {
            Log.d(TAG,
                "focusCurrentSong suppressed during user scrolling");
            return;
        }

        if (mPlaylistRecyclerView == null || mAdapter == null
                || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null
                || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }

        if (mCurrentPlayingPath == null) {
            return;
        }

        int targetPosition = -1;
        for (int index = 0; index < mCurrentDisplayList.size();
                index++) {
            Song song = mCurrentDisplayList.get(index);
            if (song != null
                    && mCurrentPlayingPath.equals(song.getPath())) {
                targetPosition = index;
                break;
            }
        }

        if (targetPosition >= 0) {
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    int firstVisibleRow =
                        mLayoutManager
                            .findFirstCompletelyVisibleItemPosition();
                    int lastVisibleRow =
                        mLayoutManager
                            .findLastCompletelyVisibleItemPosition();

                    if (finalPosition < firstVisibleRow
                            || finalPosition > lastVisibleRow) {
                        mLayoutManager.scrollToPositionWithOffset(
                            finalPosition,
                            mPlaylistRecyclerView.getHeight() / 2);
                    }
                }
            });
        }
    }

    // ============================================================================
    // Full Screen Configuration
    // ============================================================================

    /**
     * Configures the activity window for full-screen immersive
     * display.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(
                    getResources().getColor(
                        R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(
                    getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(
                    getResources().getColor(R.color.backgroundDark));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ============================================================================
    // UI Initialization
    // ============================================================================

    /**
     * Resolves every view, attaches touch animations and click
     * handlers, and creates the adapter.
     */
    private void initializeViews() {
        mPlaylistRecyclerView =
            (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSortButton = (Button) findViewById(R.id.sortButton);
        mSearchText = (EditText) findViewById(R.id.searchText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearButton = (Button) findViewById(R.id.clearButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);

        if (mSearchText != null) {
            mSearchText.setFilters(
                new android.text.InputFilter[] {
                    new android.text.InputFilter.LengthFilter(
                        MAX_SEARCH_LENGTH)
            });
        }

        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearButton);
        animateButton(mSortButton);

        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    return true;
                }
            });
        }

        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSearchClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }

        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastCancelClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }

        if (mSortButton != null) {
            mSortButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - mLastSortClickTime
                            >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSortClickTime = currentTime;
                        cycleSortMode();
                    }
                }
            });
        }

        setupAdapter();
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate, or null
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(ANIMATION_SCALE_DOWN)
                            .scaleY(ANIMATION_SCALE_DOWN)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS)
                            .start();
                        break;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    // ============================================================================
    // Search
    // ============================================================================

    /**
     * Attaches the search text watcher, the editor action
     * listener, and the clear button handler.
     */
    private void setupSearchListener() {
        if (mSearchText != null) {
            mSearchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    performSearch(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            mSearchText.setOnEditorActionListener(
                new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView view,
                                              int actionId,
                                              KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH
                            || actionId == EditorInfo.IME_ACTION_DONE
                            || (event != null
                                && event.getKeyCode()
                                    == KeyEvent.KEYCODE_ENTER
                                && event.getAction()
                                    == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager inputMethodManager =
                            (InputMethodManager) getSystemService(
                                Context.INPUT_METHOD_SERVICE);
                        if (inputMethodManager != null
                                && mSearchText != null) {
                            inputMethodManager
                                .hideSoftInputFromWindow(
                                    mSearchText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });

            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);
        }

        if (mClearButton != null) {
            mClearButton.setOnClickListener(
                new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mSearchText != null) {
                        mSearchText.setText("");
                    }
                }
            });
        }
    }

    /**
     * Filters the service's current playlist by the given query
     * and writes the result into the display list.
     *
     * @param query The search text; an empty or whitespace-only
     *        query matches every song
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null || mMusicService == null) {
            return;
        }

        String currentPath = mCurrentPlayingPath;
        ArrayList<Song> allSongs =
            mMusicService.getCurrentPlaylist();

        if (allSongs == null || allSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mAdapter.updateList(mCurrentDisplayList);
            updateTitleAndCount();
            return;
        }

        mCurrentDisplayList.clear();

        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Song song : allSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();

                    if ((title != null && title.toLowerCase()
                                .contains(lowerQuery))
                            || (artist != null && artist.toLowerCase()
                                .contains(lowerQuery))
                            || (album != null && album.toLowerCase()
                                .contains(lowerQuery))
                            || (genre != null && genre.toLowerCase()
                                .contains(lowerQuery))) {
                        mCurrentDisplayList.add(song);
                    }
                }
            }
        }

        applyCurrentSort(false);

        if (currentPath != null) {
            int displayPosition = findPositionByPath(currentPath);
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }

        updateTitleAndCount();
    }

    /**
     * Shows the search bar and requests focus on the search
     * field.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }

        if (mSearchText != null) {
            mSearchText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(
                    mSearchText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }

    /**
     * Hides the search bar, clears the query, and refreshes the
     * display list.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;

        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }

        if (mSearchText != null) {
            mSearchText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(
                    mSearchText.getWindowToken(), 0);
            }
        }

        performSearch("");
    }

    // ============================================================================
    // Theme
    // ============================================================================

    /**
     * Registers the receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }

        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();

                    if (mSortButton != null && mThemeHelper != null) {
                        mThemeHelper.updateButton(mSortButton, true);
                    }
                }
            }
        };

        IntentFilter filter =
            new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiverSafely(mThemeReceiver, filter);
    }

    /**
     * Registers the receiver for genre update broadcasts.
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GENRE_UPDATE".equals(intent.getAction())) {
                    String status = intent.getStringExtra("status");

                    if ("START".equals(status)) {
                        int total = intent.getIntExtra("total", 0);
                        Log.d(TAG,
                            "Genre loading started for " + total
                                + " songs");
                        mIsGenreLoading = true;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(true);
                        }

                    } else if ("UPDATE".equals(status)) {
                        String songPath =
                            intent.getStringExtra("song_path");
                        String genre = intent.getStringExtra("genre");

                        if (mAdapter != null && songPath != null
                                && genre != null) {
                            mAdapter.updateSongGenre(songPath, genre);
                        }

                    } else if ("COMPLETE".equals(status)) {
                        int loaded =
                            intent.getIntExtra("current", 0);
                        Log.d(TAG, "Genre loading complete: "
                            + loaded + " genres loaded");

                        mIsGenreLoading = false;

                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }

                        if (mPendingSortAfterGenre) {
                            mPendingSortAfterGenre = false;
                            applyCurrentSort(true);
                        }

                        Intent refreshMetadataIntent =
                            new Intent("FORCE_UPDATE_PLAYER");
                        refreshMetadataIntent.putExtra(
                            "refresh_metadata", true);
                        sendBroadcast(refreshMetadataIntent);

                        applyDeferredGenreFocus();
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiverSafely(mGenreUpdateReceiver, filter);
    }

    /**
     * Registers the receiver for playlist refresh broadcasts.
     */
    private void registerRefreshPlaylistReceiver() {
        mRefreshPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_REFRESH_PLAYLIST.equals(
                        intent.getAction())) {
                    Log.d(TAG, "Refresh playlist received - refreshing "
                        + "playlist from service");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshPlaylistFromService();
                            } else {
                                Log.d(TAG, "Refresh playlist suppressed "
                                    + "during genre loading");
                            }
                        }
                    });
                }
            }
        };

        IntentFilter filter =
            new IntentFilter(ACTION_REFRESH_PLAYLIST);
        registerReceiverSafely(mRefreshPlaylistReceiver, filter);
    }

    /**
     * Registers the receiver for library reset broadcasts emitted
     * by {@link PlaylistManager}.
     */
    private void registerLibraryResetReceiver() {
        mLibraryResetReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !PlaylistManager.ACTION_LIBRARY_RESET.equals(
                            intent.getAction())) {
                    return;
                }

                Log.d(TAG,
                    "LIBRARY_RESET received — clearing display list");

                mCurrentDisplayList.clear();
                mCurrentPlayingPath = null;
                mDeferredGenreFocusRow = -1;
                mLastSeenGeneration = -1L;

                mIsGenreLoading = false;
                mPendingSortAfterGenre = false;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mAdapter != null) {
                            mAdapter.setGenreLoading(false);
                        }
                        showEmptyView();
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                            mAdapter.setCurrentPlayingPath(null);
                        }
                        updateTitleAndCount();
                    }
                });
            }
        };

        IntentFilter filter = new IntentFilter(
            PlaylistManager.ACTION_LIBRARY_RESET);
        registerReceiverSafely(mLibraryResetReceiver, filter);
    }

    /**
     * Applies the header text color to every header TextView in
     * the activity.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }

    /**
     * Recursively applies the header text color to the TextViews
     * in the given view hierarchy.
     *
     * @param group The view group to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);

            if (child instanceof TextView
                    && !(child instanceof Button)
                    && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();

                if (text.equals("PLAYLIST")
                        || text.equals("CURRENT PLAYLIST")
                        || text.equals("SEARCH RESULTS")
                        || text.contains("songs")
                        || text.startsWith("SORT MODE")
                        || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(
                        Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }

    /**
     * Applies the current theme color to every control in the
     * activity and to the search bar background.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();

        if (mCancelButton != null) {
            mThemeHelper.updateButton(
                mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(
                mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearButton != null) {
            mThemeHelper.updateButton(
                mClearButton, mClearButton.isEnabled());
        }

        if (mSortButton != null) {
            mThemeHelper.updateButton(
                mSortButton, mSortButton.isEnabled());
        }

        if (mSearchBar != null) {
            GradientDrawable searchBarBorder =
                new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(
                dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(
                dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }

        if (mSearchText != null) {
            mThemeHelper.updateEditText(mSearchText);
            mThemeHelper.updateEditTextCursor(mSearchText);

            GradientDrawable searchBackground =
                new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(
                dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchText.setBackground(searchBackground);

            mSearchText.setTextColor(
                mThemeHelper.getThemeColorInt());
        }

        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }

        if (mAdapter != null && mCurrentPlayingPath != null) {
            int currentPosition =
                findPositionByPath(mCurrentPlayingPath);
            if (currentPosition >= 0) {
                mAdapter.notifyItemChanged(currentPosition);
            }
        }
    }

    // ============================================================================
    // Broadcast Receiver Setup
    // ============================================================================

    /**
     * Creates and registers every broadcast receiver used by the
     * activity.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"UPDATE_PLAYER".equals(
                            intent.getAction())) {
                    return;
                }

                long generation =
                    intent.getLongExtra("generation", -1L);
                boolean generationAdvanced;
                if (generation >= 0) {
                    if (generation < mLastSeenGeneration) {
                        return;
                    }
                    generationAdvanced =
                        (generation > mLastSeenGeneration);
                    if (generationAdvanced) {
                        mLastSeenGeneration = generation;
                    }
                } else {
                    generationAdvanced = false;
                }

                final String songPath =
                    intent.getStringExtra("song_path");
                if (songPath == null) {
                    return;
                }

                mCurrentPlayingPath = songPath;
                if (mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition < 0) {
                    return;
                }

                mAdapter.setCurrentPlayingIndex(displayPosition);

                if (!generationAdvanced) {
                    return;
                }
                if (!shouldAutoScrollTo(displayPosition)) {
                    return;
                }

                if (mIsGenreLoading) {
                    mDeferredGenreFocusRow = displayPosition;
                } else if (!mUserScrolling
                        && !mUserInteractionInProgress) {
                    scrollToRowIfOffscreen(displayPosition);
                }
            }
        };

        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null
                        && "DISPLAY_PLAYLIST".equals(
                            intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mIsGenreLoading) {
                                refreshPlaylistFromService();
                            }
                        }
                    });
                }
            }
        };

        mMetadataUpdatedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null
                        || !"METADATA_UPDATED".equals(
                            intent.getAction())) {
                    return;
                }

                final String songPath =
                    intent.getStringExtra("song_path");
                if (songPath == null || mAdapter == null) {
                    return;
                }

                int displayPosition = findPositionByPath(songPath);
                if (displayPosition >= 0) {
                    Song existing =
                        mCurrentDisplayList.get(displayPosition);
                    if (existing != null) {
                        final String title =
                            intent.getStringExtra("title");
                        final String artist =
                            intent.getStringExtra("artist");
                        final String album =
                            intent.getStringExtra("album");
                        final String genre =
                            intent.getStringExtra("genre");
                        Song updated = new Song(
                            title != null ? title
                                : existing.getTitle(),
                            artist != null ? artist
                                : existing.getArtist(),
                            album != null ? album
                                : existing.getAlbum(),
                            genre != null ? genre
                                : existing.getGenre(),
                            songPath, existing.getDuration(),
                            existing.getUri());
                        mCurrentDisplayList.set(
                            displayPosition, updated);
                        mAdapter.notifyItemChanged(displayPosition);
                    }
                }

                if (songPath.equals(mCurrentPlayingPath)) {
                    mCurrentPlayingPath = songPath;
                    mAdapter.setCurrentPlayingIndex(displayPosition);
                }
            }
        };

        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(
                        intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }

                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null
                                && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists && !mIsGenreLoading
                            && !mUserScrolling) {
                        String title =
                            intent.getStringExtra("song_title");
                        String artist =
                            intent.getStringExtra("song_artist");
                        String album =
                            intent.getStringExtra("song_album");
                        String genre =
                            intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra(
                            "song_duration", 0);

                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist
                                : "Unknown Artist",
                            album != null ? album
                                : "Unknown Album",
                            genre != null ? genre
                                : "Unknown Genre",
                            path, duration, null
                        );

                        mCurrentDisplayList.add(newSong);

                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }

                        updateTitleAndCount();
                    }
                }
            }
        };

        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiverSafely(mUpdatePlayerReceiver, playerFilter);

        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiverSafely(mDisplayPlaylistReceiver, displayFilter);

        IntentFilter metadataFilter = new IntentFilter();
        metadataFilter.addAction("METADATA_UPDATED");
        registerReceiverSafely(
            mMetadataUpdatedReceiver, metadataFilter);

        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(
            MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiverSafely(
            mPlaylistLoadProgressReceiver, progressFilter);
    }

    /**
     * Registers the given receiver for the given filter with
     * {@code RECEIVER_NOT_EXPORTED}, ignoring any exception raised
     * by the framework.
     *
     * @param receiver The receiver to register, or null
     * @param filter Intent filter for the receiver
     */
    private void registerReceiverSafely(
            @Nullable BroadcastReceiver receiver,
            @NonNull IntentFilter filter) {
        if (receiver == null) {
            return;
        }
        try {
            ContextCompat.registerReceiver(
                this, receiver, filter,
                ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception exception) {
            Log.e(TAG, "Failed to register receiver", exception);
        }
    }

    /**
     * Unregisters the given receiver, ignoring any exception
     * raised by the framework.
     *
     * @param receiver The receiver to unregister, or null
     */
    private void unregisterReceiverSafely(
            @Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception exception) {
                Log.w(TAG,
                    "Failed to unregister receiver", exception);
            }
        }
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(
            getResources().getDisplayMetrics().density * dp);
    }
}