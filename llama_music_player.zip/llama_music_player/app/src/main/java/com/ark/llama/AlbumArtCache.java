// AlbumArtCache.java
package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Process-scoped cache of decoded album art bitmaps, keyed by song
 * path.
 *
 * <p>The cache is a singleton and outlives every activity. Two
 * consumers read and write it — {@link AlbumArtCarousel} through
 * {@link MusicPlayer}, and {@link NotificationController} for the
 * playback notification and the media session — and both see the same
 * bitmaps for the same path. A song's art is decoded once per process
 * for as long as the entry remains in the cache.</p>
 *
 * <h3>Why process-scoped</h3>
 * <p>The bitmaps are a fact about the songs, not about any activity.
 * An activity-scoped cache is discarded on every recreate — a
 * configuration change the activity does not declare, a language
 * change, a theme change routed through {@code recreate()} — and the
 * carousel's next read then misses and schedules a fresh decode. The
 * user sees the placeholder while a full-size JPEG is read again, for
 * a bitmap the process already had a moment ago. Scoping the cache to
 * the process makes the decode survive every activity lifecycle event
 * that does not change which song is playing.</p>
 *
 * <h3>Entry lifetime</h3>
 * <p>An entry lives until the cache evicts it under memory pressure or
 * a caller removes it explicitly. {@link #remove(String)} is called
 * when a song's art changes or is deleted; the caller that owns the
 * change is responsible for the removal.</p>
 *
 * <h3>Thread safety</h3>
 * <p>{@link LruCache} is internally synchronised. All public methods
 * are safe to call from any thread.</p>
 *
 * @see AlbumArtCarousel
 * @see NotificationController
 *
 * @author Richard Korbla Adzido
 * @version 1.3.0
 * @since 1.3.0
 */
public final class AlbumArtCache {

    /** Maximum size of the cache, in megabytes. */
    private static final int MAX_CACHE_MB = 50;

    /** Singleton instance. */
    @Nullable
    private static volatile AlbumArtCache sInstance;

    /** The underlying LRU cache. */
    @NonNull
    private final LruCache<String, Bitmap> mCache;

    /**
     * Constructs the singleton.
     */
    private AlbumArtCache() {
        final int cacheSize = MAX_CACHE_MB * 1024 * 1024;
        mCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
        };
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static AlbumArtCache getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (AlbumArtCache.class) {
                if (sInstance == null) {
                    sInstance = new AlbumArtCache();
                }
            }
        }
        return sInstance;
    }

    /**
     * Returns the cached bitmap for the given path, or null when none
     * is cached.
     *
     * @param path Path to look up, or null
     * @return The cached bitmap, or null when none is cached or the
     *         cached bitmap has been recycled
     */
    @Nullable
    public Bitmap get(@Nullable String path) {
        if (path == null) {
            return null;
        }
        final Bitmap cached = mCache.get(path);
        return (cached != null && !cached.isRecycled()) ? cached : null;
    }

    /**
     * Stores the given bitmap under the given path, replacing any
     * existing entry.
     *
     * @param path Path to store under, or null to ignore the call
     * @param bitmap Bitmap to store, or null to ignore the call
     */
    public void put(@Nullable String path, @Nullable Bitmap bitmap) {
        if (path == null || bitmap == null || bitmap.isRecycled()) {
            return;
        }
        mCache.put(path, bitmap);
    }

    /**
     * Removes the entry for the given path, if one is present.
     *
     * @param path Path to remove, or null to ignore the call
     */
    public void remove(@Nullable String path) {
        if (path == null) {
            return;
        }
        mCache.remove(path);
    }

    /**
     * Evicts every entry.
     *
     * <p>Called by a caller that owns a state transition to "no song"
     * — the empty-state path in {@link MusicPlayer} — not from any
     * activity's {@code onDestroy}.</p>
     */
    public void evictAll() {
        mCache.evictAll();
    }

    /**
     * Returns the underlying {@link LruCache}.
     *
     * <p>Exposes the cache to consumers whose APIs were already built
     * against {@link LruCache}, such as
     * {@link AlbumArtCarousel#AlbumArtCarousel(android.content.Context,
     * android.widget.FrameLayout, LruCache, java.util.concurrent.ExecutorService)}.
     * The returned instance is the same one every other consumer reads
     * from; there is one cache in the process.</p>
     *
     * @return The underlying LRU cache
     */
    @NonNull
    public LruCache<String, Bitmap> asLruCache() {
        return mCache;
    }

    /**
     * Releases the singleton.
     *
     * <p>Evicts every entry. Called only at process teardown.</p>
     */
    public static void shutdown() {
        final AlbumArtCache cache = sInstance;
        if (cache != null) {
            cache.evictAll();
            sInstance = null;
        }
    }
}