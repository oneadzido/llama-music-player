package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a viewport
 * one slot wide. The strip's middle slot is aligned to the viewport at
 * rest; the outer slots are clipped by the container. When the user
 * drags horizontally on the album art, the strip follows the finger,
 * revealing the previous or next song's art. On release the strip
 * either springs back to the middle slot or animates to a neighbour
 * slot and then asks {@link MusicPlayer} to request the corresponding
 * song change from {@link MusicService}. The new window arrives through
 * the standard playback broadcast and is adopted; the snap that follows
 * a successful commit is pixel-identical because the art is keyed by
 * path, not by slot.</p>
 *
 * <p>The same slide is driven from the transport buttons. Pressing
 * Next or Previous calls {@link #animateToNext()} or
 * {@link #animateToPrevious()} before the service request is
 * dispatched, so the strip slides while the audio transitions and
 * settles on the incoming art when the service's window arrives. The
 * carousel does not dispatch the service request itself in this case;
 * the caller does. The visual outcome is identical to a committed
 * swipe.</p>
 *
 * <h3>Authority</h3>
 * <p>The window the carousel displays is a value published by
 * {@link MusicService}. The carousel computes neither the window nor
 * its neighbours; it renders the three paths the service names and
 * consults the shared {@link LruCache} for each path's art. The
 * carousel holds no playlist, no index, and no bitmap as primary state.
 * Its entire state is the last window it was given, the generation of
 * that window, the current commit or restart or reveal state, the
 * pending confirmed window during a commit animation, and the shared
 * placeholder bitmap.</p>
 *
 * <p>Every path through the service produces an {@code UPDATE_PLAYER}
 * broadcast carrying a {@link PlaybackWindow}, and every window is
 * adopted by the same {@link #setWindow(PlaybackWindow)} method. There
 * is no second mutation path that could disagree with the service.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn:</p>
 * <ul>
 *   <li><b>Previous</b> — the path the service names as the previous
 *       neighbour, or empty when none.</li>
 *   <li><b>Current</b> — the path the service names as the current
 *       song.</li>
 *   <li><b>Next</b> — the path the service names as the next neighbour,
 *       or empty when none.</li>
 * </ul>
 *
 * <h3>Transitions</h3>
 * <p>Every song transition, whatever its cause, runs one of three
 * animations, plus a no-op when nothing changed:</p>
 * <ul>
 *   <li><b>Commit.</b> The incoming current path is one of the
 *       previous window's neighbours. The strip slides a full slot
 *       width toward that neighbour and settles at rest on the
 *       incoming window. Reached by a committed swipe, by a transport
 *       button press through {@link #animateToNext()} or
 *       {@link #animateToPrevious()}, and by an automatic song change
 *       whose incoming window is a neighbour.</li>
 *   <li><b>Nudge.</b> The incoming current path is unchanged and the
 *       generation advanced — a repeat-one restart. The strip slides a
 *       fraction of the middle zone toward the neighbour the window
 *       advertises, then returns to rest. The user sees the neighbour
 *       nudge into the viewport and retreat.</li>
 *   <li><b>Reveal.</b> The incoming current path is neither neighbour
 *       and differs from the current song. The outgoing art stays on
 *       the strip at rest; an overlay {@link ImageView} rises over it
 *       with the incoming art, fading in from alpha zero to one over
 *       the transition duration. There is no midpoint and no blank
 *       frame.</li>
 * </ul>
 *
 * <p>A window that re-publishes the same three paths with the same
 * generation — a pause, a resume, a seek, a metadata poke, a position
 * checkpoint — is adopted at rest with no animation.</p>
 *
 * <h3>Motion</h3>
 * <p>Every slide uses a decelerating interpolator over the same
 * {@link #SWIPE_ANIMATION_MS} duration. The strip leaves the finger or
 * the button immediately and settles into rest, which is what a slide
 * that acknowledges a button press should feel like. The reveal's fade
 * is linear, so the cross-fade reads as one continuous move.
 * The below-threshold nudge's outward leg runs for
 * a duration proportional to the distance it travels, so the
 * strip's velocity matches a full commit's.</p>
 *
 * <h3>Synchronised Landing</h3>
 * <p>Every animation ends in a single main-thread turn: the strip's
 * snap to rest, the render of the incoming window, the removal of the
 * reveal overlay when one is running, and the
 * {@link #postOnSettle(Runnable)} queue are all flushed together.
 * Because view mutations are batched by the framework into the next
 * layout pass, the strip's new bitmaps and any work the activity
 * scheduled through {@link #postOnSettle(Runnable)} — the title, the
 * artist, the seek-bar range, the transport glyph — reach the screen on
 * the same frame. The art does not land before the text; both land
 * together, on the frame the transition is meant to be seen on.</p>
 *
 * <h3>Asynchronous Loading</h3>
 * <p>Whenever a window is adopted, {@link #render()} schedules a decode
 * for every path in the window whose art is not in the cache and not
 * already being decoded. Loads are deduplicated by path. When a decode
 * resolves, the bitmap is placed in the shared cache and the carousel
 * re-renders; a decode for a path that has since left the window is
 * placed in the cache and dropped. A decode that resolves while a
 * reveal is running and whose path is the one the overlay is
 * presenting is also installed into the overlay in place, so the
 * reveal continues with the resolved art rather than the placeholder
 * that was shown while the decode was in flight.</p>
 *
 * <p>Callers that have already decoded a song's art — the cold-start
 * preload, the metadata-editor path, and the incoming-file pre-decode
 * in {@link MusicPlayer} — hand the bitmap to the carousel through
 * {@link #onArtReady(String, Bitmap)}. The handoff is a cache write and
 * a render; the decode path and the identity rule are unchanged.</p>
 *
 * <h3>Main-Thread Work During an Animation</h3>
 * <p>The strip's animations run on the main thread through the
 * Choreographer. Work posted to the main thread while an animation is
 * in flight is drawn on the next frame, which the eye reads as a
 * stutter in the slide. Callers that have non-animation work to do —
 * text updates, seek-bar layout passes, and the like — register that
 * work through {@link #postOnSettle(Runnable)}. When the carousel is
 * idle the work runs immediately; when it is animating, the work is
 * queued and runs on the frame the carousel snaps to rest and
 * re-renders with the incoming window.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. Decoding runs on the
 * supplied executor; results are dispatched to the main thread before
 * touching any view or field.</p>
 *
 * @see MusicService
 * @see MusicPlayer
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.2.5
 * @since 1.2.0
 */
public final class AlbumArtCarousel {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "AlbumArtCarousel";

    /**
     * Maximum dimension of a slot bitmap, in pixels.
     *
     * <p>Slot bitmaps are downsampled to this size when decoded. The
     * shared {@link LruCache} can hold higher-resolution source bitmaps
     * for other consumers; the carousel takes a copy at this size so the
     * three slots stay cheap to keep resident.</p>
     */
    private static final int SLOT_BITMAP_SIZE_PX = 512;

    /**
     * Duration of a full-slot commit, spring-back, reveal, or
     * below-threshold return leg, in milliseconds.
     *
     * <p>Used by four animations: the outward leg of a commit, the
     * return leg of a spring-back or refusal, the return leg of the
     * below-threshold animation, and the one-way reveal. The
     * below-threshold animation's outward leg uses a proportionally
     * shorter duration, computed at run time so the strip's velocity
     * matches a full commit's.</p>
     */
    private static final long SWIPE_ANIMATION_MS = 500L;

    /**
     * Fraction of the middle zone the finger must travel before the
     * swipe commits.
     *
     * <p>The threshold is applied to the middle zone — the slot width
     * minus the two volume edge zones — not to the slot width. A
     * horizontal swipe is the carousel's gesture only in the middle
     * zone; the edge zones are the volume gesture's.</p>
     */
    private static final float COMMIT_THRESHOLD_FRACTION = 0.50f;

    /**
     * Fraction of the middle zone the below-threshold nudge travels.
     *
     * <p>Deliberately smaller than the commit threshold: it is an
     * acknowledgement that the song restarted, not the beginning of an
     * advance, so it reveals less of the neighbour than a swipe that
     * nearly committed would.</p>
     */
    private static final float RESTART_NUDGE_FRACTION = 0.25f;

    /**
     * Safety-net timeout for {@link SwipeState#AWAITING_SNAPSHOT}, in
     * milliseconds.
     *
     * <p>Under the commit guards a snapshot always arrives; the timeout
     * exists only to recover from the unexpected. When it fires, the
     * carousel springs back.</p>
     */
    private static final long SNAPSHOT_TIMEOUT_MS = 1500L;

    // ============================================================================
    // Commit State
    // ============================================================================

    /**
     * States of the commit protocol.
     */
    private enum SwipeState {

        /** No gesture, no pending commit. The resting state. */
        IDLE,

        /** Finger down, strip following the finger. */
        DRAGGING,

        /**
         * The strip is animating to a neighbour position. Entered by
         * the release of a swipe that passed its commit threshold, by
         * an external request through {@link #animateToNext()} or
         * {@link #animateToPrevious()}, or by an automatic song
         * transition whose incoming window arrives while the carousel
         * is idle.
         */
        COMMITTING,

        /** Animation done, commit under way, waiting for the service's window. */
        AWAITING_SNAPSHOT,

        /**
         * The strip is running the below-threshold animation: a
         * partial outward leg followed by a return to rest.
         */
        RESTARTING,

        /**
         * The carousel is running the one-way reveal used when the
         * current song changed to a path that was not one of the
         * previous window's neighbours.
         */
        REVEALING
    }

    // ============================================================================
    // Listener
    // ============================================================================

    /**
     * Receives a swipe commit request from the carousel.
     *
     * <p>The listener is dispatched only for commits that originated
     * from a swipe gesture. A commit that originated from
     * {@link #animateToNext()} or {@link #animateToPrevious()} does not
     * dispatch the listener, because the caller that started the
     * animation is responsible for dispatching the service request.</p>
     */
    public interface SwipeCommitListener {

        /**
         * Called when a swipe has committed and the carousel is waiting
         * for the service to confirm.
         *
         * @param direction +1 for a next commit, -1 for a previous commit
         */
        void onSwipeCommitted(int direction);
    }

    // ============================================================================
    // Collaborators
    // ============================================================================

    /** Context used for resource and density lookup. */
    @NonNull private final Context mContext;

    /** Viewport into which the strip is attached. */
    @NonNull private final FrameLayout mContainer;

    /** Shared album-art cache. */
    @NonNull private final LruCache<String, Bitmap> mCache;

    /** Executor for slot decodes. */
    @NonNull private final ExecutorService mExecutor;

    /** Main-thread handler for view mutation and the snapshot timeout. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());

    // ============================================================================
    // View State
    // ============================================================================

    /** The three-slot strip. Null before {@link #attach()}. */
    @Nullable private LinearLayout mStrip;

    /** Left slot: previous song. Null before {@link #attach()}. */
    @Nullable private ImageView mPreviousView;

    /** Middle slot: current song. Null before {@link #attach()}. */
    @Nullable private ImageView mCurrentView;

    /** Right slot: next song. Null before {@link #attach()}. */
    @Nullable private ImageView mNextView;

    /**
     * Temporary overlay used by the one-way reveal, or null when no
     * reveal is running. Added to the viewport for the duration of the
     * reveal and removed on its end frame.
     */
    @Nullable private ImageView mFadeOverlayView = null;

    /**
     * Path whose art the reveal overlay is currently presenting, or
     * null when no reveal is running. Used to decide whether an
     * incoming broadcast or a decoded bitmap should retarget the
     * overlay's bitmap.
     */
    @Nullable private String mFadeOverlayPath = null;

    /** Width of one slot in pixels, or 0 before the first layout. */
    private int mSlotWidth = 0;

    /** Height of one slot in pixels, or 0 before the first layout. */
    private int mSlotHeight = 0;

    /** Width of one volume edge zone in pixels. */
    private int mEdgeZonePx = 0;

    // ============================================================================
    // Window and Placeholder
    // ============================================================================

    /** The window the carousel currently renders. Never null. */
    @NonNull private PlaybackWindow mWindow = PlaybackWindow.EMPTY;

    /**
     * Generation of {@link #mWindow}.
     *
     * <p>Updated by {@link #setWindow(PlaybackWindow)} on every
     * adoption. Used by {@link #adoptInIdle(PlaybackWindow, long)} to
     * tell a fresh transition apart from a broadcast that merely
     * re-publishes the same window.</p>
     */
    private long mLastWindowGeneration = -1L;

    /**
     * Bitmap currently shown as the placeholder in the current slot
     * whenever the current song's real art is unavailable, or null.
     */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Paths currently being decoded, so a decode is not scheduled twice. */
    @NonNull private final Set<String> mInflightDecodePaths =
        Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    // ============================================================================
    // Commit State
    // ============================================================================

    /** Current state of the commit protocol. */
    @NonNull private SwipeState mSwipeState = SwipeState.IDLE;

    /** Direction of the current commit: +1 for next, -1 for previous. */
    private int mSwipeDirection = 0;

    /** Path the strip slid to, recorded when a commit starts. */
    @Nullable private String mExpectedCurrentPath = null;

    /**
     * Window that the service has published during a running commit
     * animation and that confirms the path the strip is sliding toward.
     */
    @Nullable private PlaybackWindow mConfirmedWindow = null;

    /** Listener that receives commit requests, or null. */
    @Nullable private SwipeCommitListener mSwipeCommitListener = null;

    /** Runnable that fires {@link #SNAPSHOT_TIMEOUT_MS} after a commit is dispatched. */
    @Nullable private Runnable mSnapshotTimeoutRunnable = null;

    /**
     * Actions queued by {@link #postOnSettle(Runnable)}, run on the
     * frame the carousel returns to {@link SwipeState#IDLE} after a
     * commit, nudge, or reveal.
     */
    @NonNull private final List<Runnable> mPostSettleActions =
        new ArrayList<>();

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a carousel bound to the given viewport, cache, and
     * executor.
     *
     * @param context Context used for resource and density lookup
     * @param container Viewport the strip is attached to
     * @param cache Shared album-art cache
     * @param executor Executor for slot decodes
     */
    public AlbumArtCarousel(@NonNull Context context,
                            @NonNull FrameLayout container,
                            @NonNull LruCache<String, Bitmap> cache,
                            @NonNull ExecutorService executor) {
        mContext = context;
        mContainer = container;
        mCache = cache;
        mExecutor = executor;
    }

    // ============================================================================
    // Configuration
    // ============================================================================

    /**
     * Installs the width of one volume edge zone.
     *
     * @param edgeZonePx Width in pixels
     */
    public void setEdgeZonePx(int edgeZonePx) {
        mEdgeZonePx = Math.max(0, edgeZonePx);
    }

    /**
     * Installs the listener that receives swipe commit requests.
     *
     * @param listener Listener, or null to clear
     */
    public void setSwipeCommitListener(@Nullable SwipeCommitListener listener) {
        mSwipeCommitListener = listener;
    }

    // ============================================================================
    // Attachment and Layout
    // ============================================================================

    /**
     * Builds the strip and attaches it inside the viewport.
     *
     * <p>Idempotent. The three slots are constructed once and reused for
     * the lifetime of the carousel.</p>
     */
    public void attach() {
        if (mStrip != null) {
            return;
        }

        LinearLayout strip = new LinearLayout(mContext);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setClickable(false);
        strip.setFocusable(false);
        strip.setVisibility(View.INVISIBLE);

        ImageView previousView = createSlot();
        ImageView currentView = createSlot();
        ImageView nextView = createSlot();

        strip.addView(previousView);
        strip.addView(currentView);
        strip.addView(nextView);

        mContainer.addView(strip);
        mContainer.setClipChildren(true);

        mStrip = strip;
        mPreviousView = previousView;
        mCurrentView = currentView;
        mNextView = nextView;

        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            layoutSlots();
            mStrip.setVisibility(View.VISIBLE);
            render();
        });
    }

    /**
     * Creates one slot ImageView with the carousel's standard
     * configuration.
     *
     * @return A newly-created slot ImageView
     */
    @NonNull
    private ImageView createSlot() {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setClickable(false);
        view.setFocusable(false);
        view.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /**
     * Recomputes the slot dimensions from the viewport's current size
     * and re-lays out the strip.
     */
    public void onContainerResized() {
        if (mStrip == null) {
            return;
        }
        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            cancelSwipe();
            layoutSlots();
            render();
        });
    }

    /**
     * Resizes each slot and the strip to match the viewport's current
     * width, then snaps the strip to rest.
     */
    private void layoutSlots() {
        if (mStrip == null || mCurrentView == null
                || mPreviousView == null || mNextView == null) {
            return;
        }
        final int width = mContainer.getWidth();
        final int height = mContainer.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }

        mSlotWidth = width;
        mSlotHeight = height;

        for (ImageView slotView : new ImageView[] {
                mPreviousView, mCurrentView, mNextView}) {
            LinearLayout.LayoutParams layoutParams =
                (LinearLayout.LayoutParams) slotView.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = new LinearLayout.LayoutParams(width, height);
            } else {
                layoutParams.width = width;
                layoutParams.height = height;
            }
            slotView.setLayoutParams(layoutParams);
        }

        ViewGroup.LayoutParams stripLayoutParams = mStrip.getLayoutParams();
        if (stripLayoutParams == null) {
            stripLayoutParams = new FrameLayout.LayoutParams(width * 3, height);
        } else {
            stripLayoutParams.width = width * 3;
            stripLayoutParams.height = height;
        }
        mStrip.setLayoutParams(stripLayoutParams);

        snapToRest();
    }

    /**
     * Sets the strip's {@code translationX} to {@code -mSlotWidth},
     * bringing the middle slot into the viewport, without animation.
     */
    private void snapToRest() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setTranslationX(-mSlotWidth);
        }
    }

    // ============================================================================
    // Main-Thread Work Contract
    // ============================================================================

    /**
     * Returns whether the strip is in any state other than
     * {@link SwipeState#IDLE}.
     *
     * @return True when the strip is animating or awaiting a commit
     *         confirmation
     */
    public boolean isAnimating() {
        return mSwipeState != SwipeState.IDLE;
    }

    /**
     * Queues an action to run on the frame the carousel settles.
     *
     * <p>When the carousel is already {@link SwipeState#IDLE} the
     * action runs immediately. Otherwise the action is queued and runs
     * on the frame the carousel snaps to rest and re-renders with the
     * incoming window — the same frame the strip's new bitmaps are
     * installed. A caller that has non-animation work to do — text
     * updates that trigger measure-and-layout passes, seek-bar layout
     * passes, and the like — uses this hook to schedule that work for
     * the settle frame, so the work and the strip's own re-render land
     * in one layout pass instead of two consecutive frames.</p>
     *
     * <p>Actions run in the order they were queued. An action that
     * queues another action from inside its own body is deferred to a
     * later settle, not run in the same pass. If the carousel is
     * cancelled before it settles — a viewport resize, a drag that
     * supersedes the animation, a snapshot timeout — the queued
     * actions run on the cancellation path, so a caller's work is
     * never silently dropped.</p>
     *
     * @param action Action to run on settle; never null
     */
    public void postOnSettle(@NonNull Runnable action) {
        if (mSwipeState == SwipeState.IDLE) {
            action.run();
            return;
        }
        mPostSettleActions.add(action);
    }

    /**
     * Runs and clears every action queued by
     * {@link #postOnSettle(Runnable)}.
     *
     * <p>Copies the queue before running so an action that queues
     * another action from its own body does not extend the pass it is
     * running in.</p>
     */
    private void runPostSettleActions() {
        if (mPostSettleActions.isEmpty()) {
            return;
        }
        final List<Runnable> pending = new ArrayList<>(mPostSettleActions);
        mPostSettleActions.clear();
        for (Runnable action : pending) {
            action.run();
        }
    }

    // ============================================================================
    // Window
    // ============================================================================

    /**
     * Adopts the given window and renders it.
     *
     * <p>The only entry point for changing what the carousel shows. The
     * service publishes a window on every {@code UPDATE_PLAYER}
     * broadcast; the activity forwards it here.</p>
     *
     * @param window Window to adopt; never null
     */
    public void setWindow(@NonNull PlaybackWindow window) {
        if (mStrip == null) {
            mWindow = window;
            mLastWindowGeneration = window.generation;
            return;
        }

        final long previousGeneration = mLastWindowGeneration;
        mLastWindowGeneration = window.generation;

        switch (mSwipeState) {
            case AWAITING_SNAPSHOT: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                mWindow = window;
                mExpectedCurrentPath = null;
                cancelSnapshotTimeout();
                mSwipeState = SwipeState.IDLE;
                if (accepted) {
                    snapToRest();
                } else {
                    animateToRest(null);
                }
                render();
                runPostSettleActions();
                return;
            }
            case COMMITTING: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                if (accepted) {
                    // The service confirmed the slide while the
                    // animation is still running. Store the window and
                    // let the animation finish; its end action will
                    // adopt the window and settle the strip at rest.
                    mConfirmedWindow = window;
                } else {
                    // The window contradicts the slide. The service
                    // decided otherwise — a repeat-one restart is the
                    // ordinary case — so the strip glides back to
                    // rest via the same method a rejected press uses,
                    // from wherever the animation had reached.
                    cancelSwipe();
                    mWindow = window;
                    render();
                    animateToRest(this::runPostSettleActions);
                }
                return;
            }
            case RESTARTING: {
                // A restart does not change the current song. Any
                // window that arrives during the nudge whose current
                // path matches the one the nudge is acknowledging —
                // the repeat-one restart's own broadcast — is stored,
                // and the nudge runs to completion. A window that
                // names a different current song is a genuine
                // takeover: the nudge is abandoned and the strip
                // returns to rest under the new window.
                final String incoming = window.currentPath;
                final boolean sameSong = incoming != null
                    && incoming.equals(mWindow.currentPath);
                if (sameSong) {
                    mWindow = window;
                    return;
                }
                cancelSwipe();
                mWindow = window;
                render();
                animateToRest(this::runPostSettleActions);
                return;
            }
            case REVEALING: {
                // A window arrived during the reveal. Store it and,
                // when its current path differs from the one the
                // overlay is presenting, retarget the overlay's
                // bitmap in place. The reveal continues toward the
                // newest current song rather than chaining a second
                // fade.
                mWindow = window;
                final String incoming = window.currentPath;
                if (mFadeOverlayView != null
                        && incoming != null
                        && !incoming.equals(mFadeOverlayPath)) {
                    installOverlayBitmap(incoming);
                }
                return;
            }
            case DRAGGING: {
                cancelSwipe();
                mWindow = window;
                snapToRest();
                render();
                runPostSettleActions();
                return;
            }
            case IDLE:
            default: {
                adoptInIdle(window, previousGeneration);
            }
        }
    }

    /**
     * Adopts a window while the carousel is idle, animating the strip
     * when the window describes a song transition.
     *
     * @param window Window to adopt; never null
     * @param previousGeneration Generation the carousel held before
     *        this call
     */
    private void adoptInIdle(@NonNull PlaybackWindow window,
                             long previousGeneration) {
        final String previousPath = mWindow.previousPath;
        final String currentPath = mWindow.currentPath;
        final String nextPath = mWindow.nextPath;
        final String incomingCurrent = window.currentPath;

        final boolean songChanged = (incomingCurrent != null)
            && !incomingCurrent.equals(currentPath);
        final boolean freshTransition =
            window.generation > previousGeneration;

        int direction = 0;
        if (songChanged) {
            if (incomingCurrent.equals(nextPath)) {
                direction = +1;
            } else if (incomingCurrent.equals(previousPath)) {
                direction = -1;
            }
        } else if (freshTransition) {
            if (nextPath != null) {
                direction = +1;
            } else if (previousPath != null) {
                direction = -1;
            }
        }

        if (direction == 0 || mSlotWidth <= 0) {
            mWindow = window;
            if (songChanged && mSlotWidth > 0) {
                startFade();
            } else {
                snapToRest();
                render();
            }
            return;
        }

        if (songChanged) {
            mConfirmedWindow = window;
            startCommit(direction, false);
        } else {
            mWindow = window;
            startBelowThreshold(direction);
        }
    }

    /**
     * Removes every slot's content and clears the window.
     *
     * <p>Used on library reset and when no song is playing.</p>
     */
    public void clear() {
        cancelSwipe();
        mWindow = PlaybackWindow.EMPTY;
        mLastWindowGeneration = -1L;
        if (mStrip != null) {
            snapToRest();
            render();
        }
    }

    // ============================================================================
    // Button-Driven Animation
    // ============================================================================

    /**
     * Animates the carousel to the next neighbour as if the user had
     * committed a forward swipe.
     *
     * @return True when the animation started
     */
    public boolean animateToNext() {
        return animateToNeighbour(+1);
    }

    /**
     * Animates the carousel to the previous neighbour as if the user
     * had committed a backward swipe.
     *
     * @return True when the animation started
     */
    public boolean animateToPrevious() {
        return animateToNeighbour(-1);
    }

    /**
     * Runs the below-threshold nudge toward the next neighbour.
     *
     * @return True when the animation started
     */
    public boolean nudgeToNext() {
        return nudgeToNeighbour(+1);
    }

    /**
     * Runs the below-threshold nudge toward the previous neighbour.
     *
     * @return True when the animation started
     */
    public boolean nudgeToPrevious() {
        return nudgeToNeighbour(-1);
    }

    /**
     * Starts a commit animation in the given direction when the
     * carousel is idle and the direction's neighbour exists.
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean animateToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null
                || neighbourPath.equals(mWindow.currentPath)) {
            return false;
        }
        startCommit(direction, false);
        return true;
    }

    /**
     * Starts the below-threshold nudge in the given direction when
     * the carousel is idle and the direction's neighbour exists.
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean nudgeToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null
                || neighbourPath.equals(mWindow.currentPath)) {
            return false;
        }
        startBelowThreshold(direction);
        return true;
    }

    // ============================================================================
    // External Art Handoff
    // ============================================================================

    /**
     * Records a decoded bitmap for the given path in the shared cache
     * and re-renders.
     *
     * <p>When a reveal is running and the path is the one the overlay
     * is presenting, the overlay's bitmap is also updated in place so
     * the reveal continues with the resolved art rather than the
     * placeholder that was shown while the decode was in flight.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     */
    public void onArtReady(@NonNull String path, @NonNull Bitmap bitmap) {
        mCache.put(path, bitmap);
        if (mStrip == null) {
            return;
        }
        if (mSwipeState == SwipeState.REVEALING
                && path.equals(mFadeOverlayPath)) {
            installOverlayBitmap(path);
        }
        render();
    }

    /**
     * Removes the bitmap for the given path from the shared cache and
     * re-renders.
     *
     * @param path Path to invalidate
     */
    public void invalidatePath(@NonNull String path) {
        mCache.remove(path);
        if (mStrip != null) {
            render();
        }
    }

    /**
     * Installs the given bitmap as the themed placeholder.
     *
     * @param placeholderBitmap Themed placeholder bitmap, or null to clear
     */
    public void setPlaceholder(@Nullable Bitmap placeholderBitmap) {
        mPlaceholderBitmap = placeholderBitmap;
        if (mStrip != null) {
            render();
        }
    }

    // ============================================================================
    // Swipe
    // ============================================================================

    /**
     * Marks the start of a horizontal swipe on the album art.
     */
    public void beginSwipe() {
        if (mSwipeState != SwipeState.IDLE) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        mSwipeState = SwipeState.DRAGGING;
    }

    /**
     * Updates the strip's position from the finger's horizontal
     * displacement.
     *
     * @param horizontalDisplacement Horizontal displacement in pixels,
     *        positive to the right
     */
    public void updateSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));
        mStrip.setTranslationX(-mSlotWidth + clampedDisplacement);
    }

    /**
     * Ends the swipe and either commits to the neighbour or springs
     * back.
     *
     * @param horizontalDisplacement Total horizontal displacement in
     *        pixels, positive to the right
     */
    public void endSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            mSwipeState = SwipeState.IDLE;
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            mSwipeState = SwipeState.IDLE;
            return;
        }

        final float middleZoneWidth = Math.max(
            1f, mSlotWidth - 2f * mEdgeZonePx);
        final float commitThreshold =
            middleZoneWidth * COMMIT_THRESHOLD_FRACTION;
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));

        final boolean wantsForward  = (clampedDisplacement <= -commitThreshold);
        final boolean wantsBackward = (clampedDisplacement >=  commitThreshold);

        final boolean canCommitForward = wantsForward
            && mWindow.nextPath != null
            && !mWindow.nextPath.equals(mWindow.currentPath);
        final boolean canCommitBackward = wantsBackward
            && mWindow.previousPath != null
            && !mWindow.previousPath.equals(mWindow.currentPath);

        if (canCommitForward) {
            startCommit(+1, true);
            return;
        }
        if (canCommitBackward) {
            startCommit(-1, true);
            return;
        }

        mSwipeState = SwipeState.IDLE;
        animateToRest(null);
    }

    // ============================================================================
    // Commit Animations
    // ============================================================================

    /**
     * Begins a commit in the given direction.
     *
     * @param direction +1 for a next commit, -1 for a previous commit
     * @param fireListener True when the commit originated from a swipe
     */
    private void startCommit(int direction, final boolean fireListener) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.COMMITTING;
        mExpectedCurrentPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;

        final float targetTranslationX = (direction > 0)
            ? (-2f * mSlotWidth)
            : 0f;

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(SWIPE_ANIMATION_MS)
            .setInterpolator(new DecelerateInterpolator(1.5f))
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.COMMITTING) {
                    return;
                }
                if (mConfirmedWindow != null) {
                    final PlaybackWindow confirmedWindow = mConfirmedWindow;
                    mConfirmedWindow = null;
                    mWindow = confirmedWindow;
                    mExpectedCurrentPath = null;
                    mSwipeState = SwipeState.IDLE;
                    snapToRest();
                    render();
                    runPostSettleActions();
                    return;
                }
                mSwipeState = SwipeState.AWAITING_SNAPSHOT;
                if (fireListener && mSwipeCommitListener != null) {
                    mSwipeCommitListener.onSwipeCommitted(mSwipeDirection);
                }
                scheduleSnapshotTimeout();
            })
            .start();
    }

    /**
     * Runs the below-threshold nudge: the strip slides out by a
     * fraction of the middle zone and then returns to rest.
     *
     * @param direction +1 for a forward animation, -1 for a backward
     *        one
     */
    private void startBelowThreshold(int direction) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.RESTARTING;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final float middleZoneWidth = Math.max(1f,
            mSlotWidth - 2f * mEdgeZonePx);
        final float nudgePx =
            middleZoneWidth * RESTART_NUDGE_FRACTION;

        final float targetTranslationX = (direction > 0)
            ? (-mSlotWidth - nudgePx)
            : (-mSlotWidth + nudgePx);

        final long outwardDuration = Math.max(1L,
            (long) (SWIPE_ANIMATION_MS * nudgePx
                / Math.max(1f, mSlotWidth)));

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(outwardDuration)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.RESTARTING) {
                    return;
                }
                animateToRest(() -> {
                    if (mSwipeState != SwipeState.RESTARTING) {
                        return;
                    }
                    mSwipeState = SwipeState.IDLE;
                    mSwipeDirection = 0;
                    mExpectedCurrentPath = null;
                    mConfirmedWindow = null;
                    runPostSettleActions();
                });
            })
            .start();
    }

    /**
     * Runs the one-way reveal used when the current song changed to a
     * path that was not one of the previous window's neighbours.
     *
     * <p>The outgoing art stays on the strip at rest, at full opacity,
     * for the whole animation. A temporary {@link ImageView} overlay is
     * added to the viewport with the incoming art at alpha 0 and faded
     * to alpha 1 over {@link #SWIPE_ANIMATION_MS}. On the fade's end
     * frame the overlay is removed, the strip is re-rendered with the
     * current {@link #mWindow}, and the settle hooks run — all in one
     * frame.</p>
     */
    private void startFade() {
        if (mStrip == null || mSlotWidth <= 0 || mSlotHeight <= 0) {
            snapToRest();
            render();
            return;
        }

        mSwipeState = SwipeState.REVEALING;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final String incomingPath = mWindow.currentPath;

        final ImageView overlay = new ImageView(mContext);
        overlay.setScaleType(ImageView.ScaleType.FIT_CENTER);
        overlay.setClickable(false);
        overlay.setFocusable(false);

        final FrameLayout.LayoutParams overlayParams =
            new FrameLayout.LayoutParams(mSlotWidth, mSlotHeight);
        overlayParams.gravity = Gravity.CENTER;
        overlay.setLayoutParams(overlayParams);
        overlay.setAlpha(0f);

        mContainer.addView(overlay);
        mFadeOverlayView = overlay;
        mFadeOverlayPath = incomingPath;
        installOverlayBitmap(incomingPath);

        overlay.animate()
            .alpha(1f)
            .setDuration(SWIPE_ANIMATION_MS)
            .setInterpolator(new LinearInterpolator())
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.REVEALING) {
                    return;
                }
                mContainer.removeView(overlay);
                mFadeOverlayView = null;
                mFadeOverlayPath = null;
                mSwipeState = SwipeState.IDLE;
                mSwipeDirection = 0;
                snapToRest();
                render();
                runPostSettleActions();
            })
            .start();
    }

    /**
     * Installs the cached art for the given path into the reveal
     * overlay, falling back to the placeholder when the art is not
     * cached.
     *
     * @param path Path whose art should be presented, or null
     */
    private void installOverlayBitmap(@Nullable String path) {
        if (mFadeOverlayView == null) {
            return;
        }
        final Bitmap art = (path != null) ? pathBitmap(path) : null;
        mFadeOverlayView.setImageBitmap(
            (art != null) ? art : mPlaceholderBitmap);
    }

    /**
     * Abandons any in-flight commit, nudge, or reveal and returns the
     * protocol to {@link SwipeState#IDLE}.
     */
    private void cancelSwipe() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setAlpha(1f);
        }
        if (mFadeOverlayView != null) {
            mFadeOverlayView.animate().cancel();
            mContainer.removeView(mFadeOverlayView);
            mFadeOverlayView = null;
        }
        mFadeOverlayPath = null;
        cancelSnapshotTimeout();
        mSwipeState = SwipeState.IDLE;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;
        runPostSettleActions();
    }

    /**
     * Animates the strip to rest over {@link #SWIPE_ANIMATION_MS}
     * milliseconds and runs the given action when the animation ends.
     *
     * @param endAction Action to run when the animation completes, or null
     */
    private void animateToRest(@Nullable final Runnable endAction) {
        if (mStrip == null) {
            if (endAction != null) {
                endAction.run();
            }
            return;
        }
        mStrip.animate()
            .translationX(-mSlotWidth)
            .setDuration(SWIPE_ANIMATION_MS)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                if (mStrip != null) {
                    mStrip.setTranslationX(-mSlotWidth);
                }
                if (endAction != null) {
                    endAction.run();
                }
            })
            .start();
    }

    /**
     * Schedules the safety-net timeout that fires when a commit is
     * dispatched but no window follows.
     */
    private void scheduleSnapshotTimeout() {
        cancelSnapshotTimeout();
        mSnapshotTimeoutRunnable = () -> {
            if (mSwipeState != SwipeState.AWAITING_SNAPSHOT) {
                return;
            }
            Log.w(TAG, "Snapshot timeout; springing back");
            mExpectedCurrentPath = null;
            mSwipeState = SwipeState.IDLE;
            animateToRest(this::runPostSettleActions);
        };
        mHandler.postDelayed(mSnapshotTimeoutRunnable, SNAPSHOT_TIMEOUT_MS);
    }

    /**
     * Cancels the safety-net snapshot timeout. Idempotent.
     */
    private void cancelSnapshotTimeout() {
        if (mSnapshotTimeoutRunnable != null) {
            mHandler.removeCallbacks(mSnapshotTimeoutRunnable);
            mSnapshotTimeoutRunnable = null;
        }
    }

    // ============================================================================
    // Rendering
    // ============================================================================

    /**
     * Renders the current window.
     *
     * <p>For each slot, consults the shared cache for the slot's path,
     * installs the bitmap when one is present, installs the placeholder
     * in the current slot when the current path's art is unavailable,
     * and schedules a decode for any path whose art is not cached and
     * not already being decoded.</p>
     */
    private void render() {
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }

        final Bitmap previousBitmap = pathBitmap(mWindow.previousPath);
        final Bitmap currentBitmap = pathBitmap(mWindow.currentPath);
        final Bitmap nextBitmap = pathBitmap(mWindow.nextPath);

        installImage(mPreviousView, previousBitmap);
        installImage(mCurrentView,
            (currentBitmap != null) ? currentBitmap : mPlaceholderBitmap);
        installImage(mNextView, nextBitmap);

        scheduleIfMissing(mWindow.previousPath, previousBitmap);
        scheduleIfMissing(mWindow.currentPath, currentBitmap);
        scheduleIfMissing(mWindow.nextPath, nextBitmap);
    }

    /**
     * Returns the cached bitmap for the given path, or null when none
     * is cached or the cached bitmap has been recycled.
     *
     * @param path Path to look up, or null
     * @return The cached bitmap, or null
     */
    @Nullable
    private Bitmap pathBitmap(@Nullable String path) {
        if (path == null) {
            return null;
        }
        final Bitmap cachedBitmap = mCache.get(path);
        return (cachedBitmap != null && !cachedBitmap.isRecycled())
            ? cachedBitmap : null;
    }

    /**
     * Installs the given bitmap into the given slot, or clears the
     * slot when the bitmap is null or recycled.
     *
     * @param slotView Slot to install into, or null
     * @param bitmap Bitmap to install, or null
     */
    private void installImage(@Nullable ImageView slotView,
                              @Nullable Bitmap bitmap) {
        if (slotView == null) {
            return;
        }
        if (bitmap != null && !bitmap.isRecycled()) {
            slotView.setImageBitmap(bitmap);
        } else {
            slotView.setImageDrawable(null);
        }
    }

    /**
     * Schedules a decode for the given path when its art is not cached
     * and not already being decoded.
     *
     * @param path Path to schedule, or null
     * @param alreadyLoadedBitmap Cached bitmap for the path, or null
     */
    private void scheduleIfMissing(@Nullable final String path,
                                   @Nullable Bitmap alreadyLoadedBitmap) {
        if (path == null || alreadyLoadedBitmap != null) {
            return;
        }
        if (!mInflightDecodePaths.add(path)) {
            return;
        }
        mExecutor.execute(() -> {
            final Bitmap decodedBitmap = decodeSlotBitmap(path);
            mContainer.post(() -> {
                mInflightDecodePaths.remove(path);
                if (decodedBitmap != null) {
                    mCache.put(path, decodedBitmap);
                }
                if (mStrip != null) {
                    render();
                }
            });
        });
    }

    /**
     * Decodes the art for the given path at slot resolution.
     *
     * <p>Runs on the executor. The {@link MediaMetadataRetriever} is
     * released in every exit path. The returned bitmap is a copy scaled
     * to at most {@link #SLOT_BITMAP_SIZE_PX} on the long side.</p>
     *
     * @param path Path of the song whose art should be decoded
     * @return The decoded bitmap, or null on failure or when the file
     *         has no embedded art
     */
    @Nullable
    private Bitmap decodeSlotBitmap(@NonNull String path) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(path);
            final byte[] embeddedPicture = retriever.getEmbeddedPicture();
            if (embeddedPicture == null || embeddedPicture.length == 0) {
                return null;
            }
            final BitmapFactory.Options boundsOptions =
                new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length, boundsOptions);
            final int sampleSize = calculateSampleSize(
                boundsOptions, SLOT_BITMAP_SIZE_PX, SLOT_BITMAP_SIZE_PX);
            final BitmapFactory.Options decodeOptions =
                new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            decodeOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length, decodeOptions);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to decode slot art for " + path, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits release.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above the
     * requested bounds.
     *
     * @param options Options whose bounds have already been decoded
     * @param requestedWidth Requested width in pixels
     * @param requestedHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateSampleSize(@NonNull BitmapFactory.Options options,
                                    int requestedWidth,
                                    int requestedHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > requestedHeight || width > requestedWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= requestedHeight
                    && (halfWidth / inSampleSize) >= requestedWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}