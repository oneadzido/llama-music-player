package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a viewport
 * one slot wide. The strip's middle slot is aligned to the viewport at
 * rest; the outer slots are clipped by the container. When the user
 * drags horizontally on the album art, the strip follows the finger,
 * revealing the previous or next song's art. On release the strip
 * either springs back to the middle slot or animates to a neighbour
 * slot and then asks {@link MusicPlayer} to request the corresponding
 * song change from {@link MusicService}. The new window arrives through
 * the standard playback broadcast and is adopted; the snap that follows
 * a successful commit is pixel-identical because the art is keyed by
 * path, not by slot.</p>
 *
 * <p>The same slide is driven from the transport buttons. Pressing
 * Next or Previous calls {@link #animateToNext()} or
 * {@link #animateToPrevious()} before the service request is
 * dispatched, so the strip slides while the audio transitions and
 * settles on the incoming art when the service's window arrives. The
 * carousel does not dispatch the service request itself in this case;
 * the caller does. The visual outcome is identical to a committed
 * swipe.</p>
 *
 * <h3>Authority</h3>
 * <p>The window the carousel displays is a value published by
 * {@link MusicService}. The carousel computes neither the window nor
 * its neighbours; it renders the three paths the service names and
 * consults the shared {@link LruCache} for each path's art. The
 * carousel holds no playlist, no index, and no bitmap as primary state.
 * Its entire state is the last window it was given, the generation of
 * that window, the current commit or restart state, the pending
 * confirmed window during a commit animation, and the shared
 * placeholder bitmap.</p>
 *
 * <p>Every path through the service produces a {@code UPDATE_PLAYER}
 * broadcast carrying a {@link PlaybackWindow}, and every window is
 * adopted by the same {@link #setWindow(PlaybackWindow)} method. There
 * is no second mutation path that could disagree with the service.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn:</p>
 * <ul>
 *   <li><b>Previous</b> — the path the service names as the previous
 *       neighbour, or empty when none.</li>
 *   <li><b>Current</b> — the path the service names as the current
 *       song.</li>
 *   <li><b>Next</b> — the path the service names as the next neighbour,
 *       or empty when none.</li>
 * </ul>
 *
 * <p>Under shuffle the service's "next" is the shuffle-chosen index, not
 * a positional neighbour; the carousel renders whatever path the
 * service publishes. Under repeat-one the service publishes the
 * positional or shuffle-chosen neighbours, and a swipe or a button
 * press slides the strip toward one of them, but the service restarts
 * the current song instead of advancing, so the window that follows
 * carries the same current path and the strip runs the below-threshold
 * animation. The strip's own refusal path produces the animation; the
 * carousel does not know or care that the reason was repeat-one. The
 * user sees the next or previous song's art nudge into the viewport and
 * then retreat, which is the visible acknowledgement that the tap
 * landed and the service is repeating.</p>
 *
 * <p>Every song transition, whatever its cause, runs one of the same
 * three animations: a committed advance, a below-threshold nudge, or
 * nothing. The window is the trigger. When the window's current path
 * changes to a neighbour, the strip slides and settles on the new song.
 * When the window's current path is unchanged but the window's
 * generation has advanced — a repeat-one restart — the strip runs the
 * below-threshold animation. When the window's current path is
 * unchanged and the generation has not advanced, the broadcast is
 * merely a re-publication and the strip does not move.</p>
 *
 * <p>Which of the two animations a button press produces is chosen by
 * the caller, not by the carousel. The activity knows the service's
 * current repeat mode and calls {@link #animateToNext()} or
 * {@link #nudgeToNext()} accordingly. The carousel exposes both and
 * stays a pure renderer with no knowledge of repeat modes. See
 * {@link MusicPlayer#playNextSong()} and
 * {@link MusicPlayer#playPreviousSong()}.</p>
 *
 * <p>The strip is {@code 3W × H} where {@code W} is the viewport width
 * and {@code H} is its height. The strip's {@code translationX} is
 * {@code -W} at rest. During a horizontal swipe, {@code translationX}
 * is {@code -W + dx} where {@code dx} is the horizontal finger
 * displacement.</p>
 *
 * <h3>Commit Protocol</h3>
 * <p>A commit has five states. {@link SwipeState#IDLE} is the resting
 * state. {@link SwipeState#DRAGGING} is set by {@link #beginSwipe()}
 * and held until the finger lifts; a button-driven commit does not pass
 * through this state. {@link SwipeState#COMMITTING} is entered when the
 * strip starts animating to the neighbour position — by the release of
 * a swipe that passed its commit threshold, by an external request
 * through {@link #animateToNext()} or {@link #animateToPrevious()}, or
 * by an automatic song transition whose incoming window arrives while
 * the carousel is idle. When the animation completes, the carousel
 * enters {@link SwipeState#AWAITING_SNAPSHOT}: it dispatches
 * {@link SwipeCommitListener#onSwipeCommitted(int)} when the commit
 * came from a swipe, and waits. {@link SwipeState#RESTARTING} is the
 * below-threshold nudge's dedicated state, entered by
 * {@link #nudgeToNext()}, {@link #nudgeToPrevious()}, or an automatic
 * repeat-one restart: the strip runs a partial outward leg to
 * {@link #RESTART_NUDGE_FRACTION} of the middle zone, followed by a
 * return via {@link #animateToRest(Runnable)}, and a re-publication
 * during the animation is ignored.</p>
 *
 * <p>The service is the authority. It accepts the request by publishing
 * a new window; the carousel adopts the window, snaps the strip to
 * rest, and renders. The snap is pixel-identical because the path the
 * carousel slid to has become the new current path, and the art for a
 * path is the same art regardless of which slot it occupies. When the
 * service refuses the request — the playlist shrank, the library was
 * reset, a different transition took over, or the request was a next
 * or previous press under repeat-one and the service restarted the
 * same song — the carousel sees a window whose current path is not the
 * path it slid to and glides back to rest via
 * {@link #animateToRest(Runnable)}. The glide is what a rejected press
 * looks like: the strip went out to show the neighbour the button would
 * have advanced to, the confirming window arrived with the same song
 * still current, and the strip returns to centre on the same art. A
 * safety-net timeout covers the case in which no broadcast arrives at
 * all; the commit guards make that case unreachable through the normal
 * flow.</p>
 *
 * <p>When a window arrives while the strip is still animating, the
 * carousel matches the window's current path against the path the strip
 * is sliding toward. A match is a confirmation: the window is stored
 * and adopted when the animation finishes, and the strip settles at
 * rest without a jump. A mismatch is a refusal: the animation is
 * abandoned and the strip animates back to rest via
 * {@link #animateToRest(Runnable)}, because the service has decided
 * otherwise.</p>
 *
 * <p>A window that arrives while the user is dragging is adopted
 * immediately: the drag is abandoned, the strip snaps to rest, and the
 * new window renders. This is what makes tap-next-during-swipe,
 * song-change-under-the-finger, and reconnect-during-swipe the same
 * code path.</p>
 *
 * <p>When a song ends and the service advances on its own — a
 * completed track, a headset media button dispatched through the media
 * session, a shuffle pick, a repeat-one restart — the carousel is idle
 * when the new window arrives. When the incoming song is one of the
 * previous window's neighbours, the strip animates to that neighbour
 * position over the commit duration and settles at rest on the
 * incoming window, exactly as a committed swipe does. When the
 * incoming song equals the current song and the window's generation
 * has advanced, the service restarted the current song; the strip runs
 * the below-threshold animation — a partial outward leg that moves the
 * strip to {@link #RESTART_NUDGE_FRACTION} of the middle zone, followed
 * by a return via {@link #animateToRest(Runnable)}. The user sees the
 * neighbour nudge into the viewport and retreat, matching what a very
 * small below-threshold swipe produces. When the incoming song is
 * neither neighbour and the current song has not restarted — the first
 * window after {@link #clear()}, a library reset, a media-session jump
 * to an unrelated index — the strip snaps to rest and the window
 * renders, because there is no neighbour position to slide toward and
 * no prior frame to slide from. See
 * {@link #adoptInIdle(PlaybackWindow, long)}.</p>
 *
 * <h3>Placeholder</h3>
 * <p>The carousel holds a themed placeholder supplied by
 * {@link MusicPlayer}. The current slot renders the placeholder
 * whenever the current path's art is not in the cache; the previous and
 * next slots render nothing when their art is not cached, so a drag
 * never reveals a slot filled with the wrong song's art. The
 * placeholder is not the slot's content: the decode is still scheduled,
 * and the placeholder is discarded when the decode resolves.</p>
 *
 * <h3>Asynchronous Loading</h3>
 * <p>Whenever a window is adopted, {@link #render()} schedules a decode
 * for every path in the window whose art is not in the cache and not
 * already being decoded. Loads are deduplicated by path so a path that
 * appears in two slots — the repeat-one case, or a shuffle pick that
 * lands on the current index — is decoded once. When a decode resolves,
 * the bitmap is placed in the shared cache and the carousel
 * re-renders. A decode for a path that has since left the window is
 * placed in the cache and dropped; the cache is path-keyed, so a future
 * window that re-uses the path finds the bitmap already there. No
 * generation counter is required: the path is the identity of a slot,
 * and a bitmap is installed only into a slot whose path matches.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. Decoding runs on the
 * supplied executor; results are dispatched to the main thread before
 * touching any view or field.</p>
 *
 * @see MusicService
 * @see MusicPlayer
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class AlbumArtCarousel {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "AlbumArtCarousel";

    /**
     * Maximum dimension of a slot bitmap, in pixels.
     *
     * <p>Slot bitmaps are downsampled to this size when decoded. The
     * shared {@link LruCache} can hold higher-resolution source bitmaps
     * for other consumers; the carousel takes a copy at this size so the
     * three slots stay cheap to keep resident.</p>
     */
    private static final int SLOT_BITMAP_SIZE_PX = 512;

    /**
     * Duration of a full-slot commit, spring-back, or below-threshold
     * return leg, in milliseconds.
     *
     * <p>Used by three animations: the outward leg of a commit (which
     * travels a full slot width), the return leg of a spring-back or
     * refusal via {@link #animateToRest(Runnable)} (from wherever the
     * strip is back to rest), and the return leg of the below-threshold
     * animation. The below-threshold animation's outward leg uses a
     * proportionally shorter duration, computed at run time so the
     * strip's velocity matches a full commit's.</p>
     */
    private static final long SWIPE_ANIMATION_MS = 500L;

    /**
     * Fraction of the middle zone the finger must travel before the
     * swipe commits.
     *
     * <p>The threshold is applied to the middle zone — the slot width
     * minus the two volume edge zones — not to the slot width. A
     * horizontal swipe is the carousel's gesture only in the middle
     * zone; the edge zones are the volume gesture's.</p>
     */
    private static final float COMMIT_THRESHOLD_FRACTION = 0.50f;

    /**
     * Fraction of the middle zone the below-threshold nudge travels.
     *
     * <p>Used by {@link #startBelowThreshold(int)}, which is reached
     * from three places: the repeat-one auto-loop, and the transport
     * buttons under repeat-one via {@link #nudgeToNext()} and
     * {@link #nudgeToPrevious()}. The nudge is deliberately smaller
     * than the commit threshold: it is an acknowledgement that the
     * song restarted, not the beginning of an advance, so it reveals
     * less of the neighbour than a swipe that nearly committed would.
     * At {@code 0.25} the nudge is half the commit threshold's travel,
     * which reads as a gentle peek rather than a full attempt.</p>
     *
     * <p>Separate from {@link #COMMIT_THRESHOLD_FRACTION} on purpose.
     * The commit threshold defines when a swipe commits and must stay
     * where it is; the nudge is a presentation choice that can be
     * tuned without affecting gesture behaviour.</p>
     */
    private static final float RESTART_NUDGE_FRACTION = 0.25f;

    /**
     * Safety-net timeout for {@link SwipeState#AWAITING_SNAPSHOT}, in
     * milliseconds.
     *
     * <p>Under the commit guards a snapshot always arrives; the timeout
     * exists only to recover from the unexpected — an activity that is
     * destroyed mid-transition, a service that is killed without
     * broadcasting. When it fires, the carousel springs back.</p>
     */
    private static final long SNAPSHOT_TIMEOUT_MS = 1500L;

    // ============================================================================
    // Commit State
    // ============================================================================

    /**
     * States of the commit protocol.
     */
    private enum SwipeState {

        /** No gesture, no pending commit. The resting state. */
        IDLE,

        /** Finger down, strip following the finger. */
        DRAGGING,

        /**
         * The strip is animating to a neighbour position. Entered by
         * the release of a swipe that passed its commit threshold, by
         * an external request through {@link #animateToNext()} or
         * {@link #animateToPrevious()}, or by an automatic song
         * transition whose incoming window arrives while the carousel
         * is idle.
         */
        COMMITTING,

        /** Animation done, commit under way, waiting for the service's window. */
        AWAITING_SNAPSHOT,

        /**
         * The strip is running the below-threshold animation: a
         * partial outward leg that moves the strip to the nudge
         * position — {@link #RESTART_NUDGE_FRACTION} of the middle
         * zone — followed by a return to rest via
         * {@link #animateToRest(Runnable)}. Entered by
         * {@link #nudgeToNext()}, {@link #nudgeToPrevious()}, or an
         * automatic repeat-one restart. The current song is
         * unchanged; there is no confirmed window to wait for and no
         * listener to dispatch. A window with the same generation
         * re-published during the animation is ignored; a window with
         * a newer generation aborts it.
         */
        RESTARTING
    }

    // ============================================================================
    // Listener
    // ============================================================================

    /**
     * Receives a swipe commit request from the carousel.
     *
     * <p>The listener is dispatched only for commits that originated
     * from a swipe gesture. A commit that originated from
     * {@link #animateToNext()} or {@link #animateToPrevious()} does not
     * dispatch the listener, because the caller that started the
     * animation is responsible for dispatching the service request.</p>
     */
    public interface SwipeCommitListener {

        /**
         * Called when a swipe has committed and the carousel is waiting
         * for the service to confirm.
         *
         * <p>The listener is expected to request the corresponding song
         * change from {@link MusicService}. The carousel does not
         * inspect the result; it observes the next
         * {@link #setWindow(PlaybackWindow)} call to learn whether the
         * service accepted the request.</p>
         *
         * @param direction +1 for a next commit, -1 for a previous commit
         */
        void onSwipeCommitted(int direction);
    }

    // ============================================================================
    // Collaborators
    // ============================================================================

    /** Context used for resource and density lookup. */
    @NonNull private final Context mContext;

    /** Viewport into which the strip is attached. */
    @NonNull private final FrameLayout mContainer;

    /** Shared album-art cache. */
    @NonNull private final LruCache<String, Bitmap> mCache;

    /** Executor for slot decodes. */
    @NonNull private final ExecutorService mExecutor;

    /** Main-thread handler for view mutation and the snapshot timeout. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());

    // ============================================================================
    // View State
    // ============================================================================

    /** The three-slot strip. Null before {@link #attach()}. */
    @Nullable private LinearLayout mStrip;

    /** Left slot: previous song. Null before {@link #attach()}. */
    @Nullable private ImageView mPreviousView;

    /** Middle slot: current song. Null before {@link #attach()}. */
    @Nullable private ImageView mCurrentView;

    /** Right slot: next song. Null before {@link #attach()}. */
    @Nullable private ImageView mNextView;

    /** Width of one slot in pixels, or 0 before the first layout. */
    private int mSlotWidth = 0;

    /** Height of one slot in pixels, or 0 before the first layout. */
    private int mSlotHeight = 0;

    /** Width of one volume edge zone in pixels. */
    private int mEdgeZonePx = 0;

    // ============================================================================
    // Window and Placeholder
    // ============================================================================

    /** The window the carousel currently renders. Never null. */
    @NonNull private PlaybackWindow mWindow = PlaybackWindow.EMPTY;

    /**
     * Generation of {@link #mWindow}.
     *
     * <p>The service's monotonic transition counter, carried on the
     * window. Updated by {@link #setWindow(PlaybackWindow)} on every
     * adoption. Used by {@link #adoptInIdle(PlaybackWindow, long)} to
     * tell a fresh transition apart from a broadcast that merely
     * re-publishes the same window: only a fresh transition advances
     * it, so only a fresh transition can animate a same-song
     * restart.</p>
     */
    private long mLastWindowGeneration = -1L;

    /**
     * Bitmap currently shown as the placeholder in the current slot
     * whenever the current song's real art is unavailable, or null.
     */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Paths currently being decoded, so a decode is not scheduled twice. */
    @NonNull private final Set<String> mInflightDecodePaths =
        Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    // ============================================================================
    // Commit State
    // ============================================================================

    /** Current state of the commit protocol. */
    @NonNull private SwipeState mSwipeState = SwipeState.IDLE;

    /** Direction of the current commit: +1 for next, -1 for previous. */
    private int mSwipeDirection = 0;

    /** Path the strip slid to, recorded when a commit starts. */
    @Nullable private String mExpectedCurrentPath = null;

    /**
     * Window that the service has published during a running commit
     * animation and that confirms the path the strip is sliding toward.
     *
     * <p>Set by {@link #setWindow(PlaybackWindow)} when a window arrives
     * while {@link SwipeState#COMMITTING} and the window's current path
     * equals {@link #mExpectedCurrentPath}. Also set by
     * {@link #adoptInIdle(PlaybackWindow, long)} before an automatic
     * song change's animation starts. Read by the animation's end
     * action, which adopts the window and settles the strip at rest
     * without a jump. Null in every other state.</p>
     */
    @Nullable private PlaybackWindow mConfirmedWindow = null;

    /** Listener that receives commit requests, or null. */
    @Nullable private SwipeCommitListener mSwipeCommitListener = null;

    /** Runnable that fires {@link #SNAPSHOT_TIMEOUT_MS} after a commit is dispatched. */
    @Nullable private Runnable mSnapshotTimeoutRunnable = null;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a carousel bound to the given viewport, cache, and
     * executor.
     *
     * <p>The views are not built until {@link #attach()} is called. The
     * constructor only records the collaborators.</p>
     *
     * @param context Context used for resource and density lookup
     * @param container Viewport the strip is attached to
     * @param cache Shared album-art cache
     * @param executor Executor for slot decodes
     */
    public AlbumArtCarousel(@NonNull Context context,
                            @NonNull FrameLayout container,
                            @NonNull LruCache<String, Bitmap> cache,
                            @NonNull ExecutorService executor) {
        mContext = context;
        mContainer = container;
        mCache = cache;
        mExecutor = executor;
    }

    // ============================================================================
    // Configuration
    // ============================================================================

    /**
     * Installs the width of one volume edge zone.
     *
     * <p>The carousel uses this to compute its commit threshold and its
     * nudge: both are a fraction of the middle zone,
     * {@code slotWidth - 2 * edgeZone}, with the fraction chosen per
     * use.</p>
     *
     * @param edgeZonePx Width in pixels
     */
    public void setEdgeZonePx(int edgeZonePx) {
        mEdgeZonePx = Math.max(0, edgeZonePx);
    }

    /**
     * Installs the listener that receives swipe commit requests.
     *
     * @param listener Listener, or null to clear
     */
    public void setSwipeCommitListener(@Nullable SwipeCommitListener listener) {
        mSwipeCommitListener = listener;
    }

    // ============================================================================
    // Attachment and Layout
    // ============================================================================

    /**
     * Builds the strip and attaches it inside the viewport.
     *
     * <p>Idempotent. The three slots are constructed once and reused for
     * the lifetime of the carousel; the window reassigns their images
     * rather than rebuilding the views.</p>
     *
     * <p>The first slot layout runs after the next frame, because the
     * viewport's width is not known during {@code onCreate}. Until then
     * the strip is invisible.</p>
     */
    public void attach() {
        if (mStrip != null) {
            return;
        }

        LinearLayout strip = new LinearLayout(mContext);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setClickable(false);
        strip.setFocusable(false);
        strip.setVisibility(View.INVISIBLE);

        ImageView previousView = createSlot();
        ImageView currentView = createSlot();
        ImageView nextView = createSlot();

        strip.addView(previousView);
        strip.addView(currentView);
        strip.addView(nextView);

        mContainer.addView(strip);
        mContainer.setClipChildren(true);

        mStrip = strip;
        mPreviousView = previousView;
        mCurrentView = currentView;
        mNextView = nextView;

        mContainer.post(new Runnable() {
            @Override
            public void run() {
                if (mStrip == null) {
                    return;
                }
                layoutSlots();
                mStrip.setVisibility(View.VISIBLE);
                render();
            }
        });
    }

    /**
     * Creates one slot ImageView with the carousel's standard
     * configuration.
     *
     * @return A newly-created slot ImageView
     */
    @NonNull
    private ImageView createSlot() {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setClickable(false);
        view.setFocusable(false);
        view.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /**
     * Recomputes the slot dimensions from the viewport's current size and
     * re-lays out the strip.
     *
     * <p>Called by the activity after the viewport has been resized, and
     * by {@link #attach()} once the viewport has been laid out. Abandons
     * any in-flight commit or nudge, since the geometry the animation
     * was computed against no longer applies, and snaps the strip to
     * rest.</p>
     */
    public void onContainerResized() {
        if (mStrip == null) {
            return;
        }
        mContainer.post(new Runnable() {
            @Override
            public void run() {
                if (mStrip == null) {
                    return;
                }
                cancelSwipe();
                layoutSlots();
                render();
            }
        });
    }

    /**
     * Resizes each slot and the strip to match the viewport's current
     * width, then snaps the strip to rest.
     *
     * <p>Runs on the main thread. When the viewport has zero width —
     * before the first layout or while the album art is hidden — the
     * method returns without touching the strip.</p>
     */
    private void layoutSlots() {
        if (mStrip == null || mCurrentView == null
                || mPreviousView == null || mNextView == null) {
            return;
        }
        final int width = mContainer.getWidth();
        final int height = mContainer.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }

        mSlotWidth = width;
        mSlotHeight = height;

        for (ImageView slotView : new ImageView[] {
                mPreviousView, mCurrentView, mNextView}) {
            LinearLayout.LayoutParams layoutParams =
                (LinearLayout.LayoutParams) slotView.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = new LinearLayout.LayoutParams(width, height);
            } else {
                layoutParams.width = width;
                layoutParams.height = height;
            }
            slotView.setLayoutParams(layoutParams);
        }

        ViewGroup.LayoutParams stripLayoutParams = mStrip.getLayoutParams();
        if (stripLayoutParams == null) {
            stripLayoutParams = new FrameLayout.LayoutParams(width * 3, height);
        } else {
            stripLayoutParams.width = width * 3;
            stripLayoutParams.height = height;
        }
        mStrip.setLayoutParams(stripLayoutParams);

        snapToRest();
    }

    /**
     * Sets the strip's {@code translationX} to {@code -mSlotWidth},
     * bringing the middle slot into the viewport.
     */
    private void snapToRest() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setTranslationX(-mSlotWidth);
        }
    }

    // ============================================================================
    // Window
    // ============================================================================

    /**
     * Adopts the given window and renders it.
     *
     * <p>The only entry point for changing what the carousel shows. The
     * service publishes a window on every {@code UPDATE_PLAYER}
     * broadcast; the activity forwards it here.</p>
     *
     * <p>Reconciliation against an in-flight commit or nudge:</p>
     * <ul>
     *   <li>{@link SwipeState#AWAITING_SNAPSHOT} — this is the
     *       confirmation, refusal, or override the carousel was waiting
     *       for. When the window's current path equals the path the
     *       strip slid to, the strip snaps to rest without animation, as
     *       the pixels at the viewport are unchanged. When it differs,
     *       the strip animates back to rest via
     *       {@link #animateToRest(Runnable)}.</li>
     *   <li>{@link SwipeState#COMMITTING} — a window arrived while the
     *       strip is animating toward a neighbour. When the window's
     *       current path equals the path the strip is sliding toward,
     *       the window confirms the slide; it is stored and adopted when
     *       the animation finishes, and the strip settles at rest
     *       without a jump. When the window does not match, the service
     *       decided otherwise — a repeat-one restart is the ordinary
     *       case — so the strip glides back to rest via
     *       {@link #animateToRest(Runnable)} from wherever the
     *       animation had reached, and the new window is adopted
     *       directly.</li>
     *   <li>{@link SwipeState#RESTARTING} — a window arrived during the
     *       below-threshold nudge. When the window's generation matches
     *       the generation the carousel already holds, the broadcast is
     *       a re-publication — a position update, a metadata poke, a
     *       pause, a resume, a seek — and the animation is not
     *       interrupted. When the generation is newer, a real
     *       transition has taken over; the animation is abandoned and
     *       the new window is adopted.</li>
     *   <li>{@link SwipeState#DRAGGING} — a window arrived mid-gesture.
     *       The window wins. The drag is abandoned, the strip snaps to
     *       rest, and the new window renders.</li>
     *   <li>{@link SwipeState#IDLE} — the ordinary case, and the
     *       automatic-transition case. When the incoming song is one of
     *       the current song's neighbours — a song completed, a headset
     *       media button arrived through the media session, shuffle
     *       picked the next song — the strip animates toward that
     *       neighbour position and settles on the incoming window.
     *       When the incoming song is unchanged but the window's
     *       generation has advanced — a repeat-one restart — the strip
     *       runs the below-threshold animation. Otherwise the window is
     *       adopted and the strip snaps to rest. See
     *       {@link #adoptInIdle(PlaybackWindow, long)}.</li>
     * </ul>
     *
     * @param window Window to adopt; never null
     */
    public void setWindow(@NonNull PlaybackWindow window) {
        if (mStrip == null) {
            mWindow = window;
            mLastWindowGeneration = window.generation;
            return;
        }

        final long previousGeneration = mLastWindowGeneration;
        mLastWindowGeneration = window.generation;

        switch (mSwipeState) {
            case AWAITING_SNAPSHOT: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                mWindow = window;
                mExpectedCurrentPath = null;
                cancelSnapshotTimeout();
                mSwipeState = SwipeState.IDLE;
                if (accepted) {
                    snapToRest();
                } else {
                    animateToRest(null);
                }
                render();
                return;
            }
            case COMMITTING: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                if (accepted) {
                    // The service confirmed the slide while the
                    // animation is still running. Store the window and
                    // let the animation finish; its end action will
                    // adopt the window and settle the strip at rest.
                    mConfirmedWindow = window;
                } else {
                    // The window contradicts the slide. The service
                    // decided otherwise — a repeat-one restart is the
                    // ordinary case — so the strip glides back to
                    // rest via the same method a rejected press uses,
                    // from wherever the animation had reached.
                    cancelSwipe();
                    mWindow = window;
                    render();
                    animateToRest(null);
                }
                return;
            }
            case RESTARTING: {
                if (window.generation == previousGeneration) {
                    // A re-publication during the below-threshold
                    // nudge: same generation, same three paths. The
                    // animation is not interrupted; the window is
                    // stored so any later read of the current window
                    // sees the latest snapshot, but the strip finishes
                    // both legs.
                    mWindow = window;
                } else {
                    // A fresh transition has taken over. Abort the
                    // animation and adopt the new window at rest.
                    cancelSwipe();
                    mWindow = window;
                    render();
                    animateToRest(null);
                }
                return;
            }
            case DRAGGING: {
                cancelSwipe();
                mWindow = window;
                snapToRest();
                render();
                return;
            }
            case IDLE:
            default: {
                adoptInIdle(window, previousGeneration);
            }
        }
    }

    /**
     * Adopts a window while the carousel is idle, animating the strip
     * when the window describes a song transition.
     *
     * <p>The automatic-transition case: a song completes and the
     * service advances, a headset media button arrives through the
     * media session, shuffle picks a new song on its own, a repeat-one
     * track restarts. In each of these the carousel is idle when the
     * new window arrives — no swipe commit and no button-driven commit
     * is in flight.</p>
     *
     * <p>Two forms of transition are recognised:</p>
     *
     * <ul>
     *   <li><b>Song change.</b> The window's current path differs from
     *       the previous window's current path. When the incoming
     *       current path is one of the previous window's neighbours,
     *       the strip animates to that neighbour position over the
     *       commit duration. The incoming window — which is exactly the
     *       confirmation the service would publish after a committed
     *       swipe — is stored before the animation starts and adopted
     *       by the animation's end action, which settles the strip at
     *       rest without a jump.</li>
     *   <li><b>Restart.</b> The window's current path equals the
     *       previous window's current path, but the window's
     *       generation has advanced. The service restarted the same
     *       song — the repeat-one loop. The strip runs the
     *       below-threshold animation: it slides out to
     *       {@link #RESTART_NUDGE_FRACTION} of the middle zone — well
     *       short of the commit threshold a swipe would have to cross
     *       — and then returns to rest via
     *       {@link #animateToRest(Runnable)}. The user sees the
     *       neighbour nudge into the viewport and retreat, matching
     *       what a very small below-threshold swipe produces.</li>
     * </ul>
     *
     * <p>Every other window arrival — a broadcast that re-publishes
     * the same window with the same generation (a pause, a resume, a
     * seek, a metadata poke), the first window after {@link #clear()},
     * a library reset, a media-session jump to an unrelated index —
     * snaps the strip to rest and renders without animation.</p>
     *
     * <p>The distinction between the two forms is the magnitude of the
     * slide. A song change is a full commit — the neighbour became the
     * current song, so the strip travels a full slot width. A restart
     * is a below-threshold nudge — nothing was committed, the song is
     * the same, so the strip travels only a small fraction of the
     * middle zone. Both animations end with a settle or a return; the
     * user sees the difference in how much of the neighbour
     * appears.</p>
     *
     * @param window Window to adopt; never null
     * @param previousGeneration Generation the carousel held before
     *        this call
     */
    private void adoptInIdle(@NonNull PlaybackWindow window,
                             long previousGeneration) {
        final String previousPath = mWindow.previousPath;
        final String currentPath = mWindow.currentPath;
        final String nextPath = mWindow.nextPath;
        final String incomingCurrent = window.currentPath;

        final boolean songChanged = (currentPath != null)
            && (incomingCurrent != null)
            && !incomingCurrent.equals(currentPath);
        final boolean freshTransition =
            window.generation > previousGeneration;

        int direction = 0;
        if (songChanged) {
            if (incomingCurrent.equals(nextPath)) {
                direction = +1;
            } else if (incomingCurrent.equals(previousPath)) {
                direction = -1;
            }
        } else if (freshTransition) {
            // Repeat-one restart: the current song is unchanged,
            // but the service started a fresh transition. The strip
            // runs the below-threshold animation toward the
            // positional or shuffle-chosen next, so the user sees
            // the same partial nudge a very small swipe would
            // produce.
            if (nextPath != null) {
                direction = +1;
            } else if (previousPath != null) {
                direction = -1;
            }
        }

        if (direction == 0 || mSlotWidth <= 0) {
            mWindow = window;
            snapToRest();
            render();
            return;
        }

        if (songChanged) {
            // A real song change. The animation ends by settling on
            // the confirmed window — this window — at rest.
            mConfirmedWindow = window;
            startCommit(direction, false);
        } else {
            // A repeat-one restart. The current song is unchanged;
            // there is no new song to settle on. Adopt the window
            // now and run the below-threshold animation.
            mWindow = window;
            startBelowThreshold(direction);
        }
    }

    /**
     * Removes every slot's content and clears the window.
     *
     * <p>Used on library reset and when no song is playing. Does not
     * detach the views; the strip is reused when a new window
     * arrives.</p>
     */
    public void clear() {
        cancelSwipe();
        mWindow = PlaybackWindow.EMPTY;
        mLastWindowGeneration = -1L;
        if (mStrip != null) {
            snapToRest();
            render();
        }
    }

    // ============================================================================
    // Button-Driven Animation
    // ============================================================================

    /**
     * Animates the carousel to the next neighbour as if the user had
     * committed a forward swipe.
     *
     * <p>The caller is expected to request the corresponding song
     * change from {@link MusicService} directly; the carousel does not
     * dispatch the swipe commit listener for a button-driven commit.
     * The strip slides to the neighbour position, and the carousel
     * waits for the service's window exactly as it does after a swipe
     * commit: on acceptance, the strip settles at rest on the new
     * window; on refusal, it springs back via
     * {@link #animateToRest(Runnable)}.</p>
     *
     * <p>This is the animation to choose when the service will
     * actually advance. When the service is in repeat-one and the
     * request restarts the current song instead, callers should use
     * {@link #nudgeToNext()} so the strip's motion matches the
     * service's behaviour.</p>
     *
     * <p>Refused when the carousel is not idle, when the viewport has
     * not been laid out, or when the window advertises no forward
     * neighbour. A refused call does not animate; the caller's service
     * request still proceeds, and the resulting window is adopted
     * without animation through the ordinary
     * {@link #setWindow(PlaybackWindow)} path.</p>
     *
     * @return True when the animation started
     */
    public boolean animateToNext() {
        return animateToNeighbour(+1);
    }

    /**
     * Animates the carousel to the previous neighbour as if the user
     * had committed a backward swipe.
     *
     * <p>Symmetric to {@link #animateToNext()}.</p>
     *
     * @return True when the animation started
     */
    public boolean animateToPrevious() {
        return animateToNeighbour(-1);
    }

    /**
     * Runs the below-threshold nudge toward the next neighbour.
     *
     * <p>The animation the caller should start when a next press will
     * restart the current song rather than advance — under repeat-one.
     * The strip moves a small fraction of the way toward the next
     * neighbour and returns to rest. The animation is the same one the
     * repeat-one auto-loop runs, so a deliberate press and an
     * involuntary restart look identical. See
     * {@link #startBelowThreshold(int)} for the shape.</p>
     *
     * <p>Refused under the same conditions as
     * {@link #animateToNext()}: not idle, no viewport, no neighbour.
     * A refused call is a no-op; the caller's service request still
     * proceeds.</p>
     *
     * @return True when the animation started
     */
    public boolean nudgeToNext() {
        return nudgeToNeighbour(+1);
    }

    /**
     * Runs the below-threshold nudge toward the previous neighbour.
     *
     * <p>Symmetric to {@link #nudgeToNext()}.</p>
     *
     * @return True when the animation started
     */
    public boolean nudgeToPrevious() {
        return nudgeToNeighbour(-1);
    }

    /**
     * Starts a commit animation in the given direction when the
     * carousel is idle and the direction's neighbour exists.
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean animateToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null
                || neighbourPath.equals(mWindow.currentPath)) {
            return false;
        }
        startCommit(direction, false);
        return true;
    }

    /**
     * Starts the below-threshold nudge in the given direction when
     * the carousel is idle and the direction's neighbour exists.
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean nudgeToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null
                || neighbourPath.equals(mWindow.currentPath)) {
            return false;
        }
        startBelowThreshold(direction);
        return true;
    }

    // ============================================================================
    // External Art Handoff
    // ============================================================================

    /**
     * Records a decoded bitmap for the given path in the shared cache
     * and re-renders.
     *
     * <p>Provided so callers that have already decoded a song's art —
     * the cold-start preload and the metadata-editor path are the cases
     * in this app — can hand the bitmap to the carousel directly instead
     * of waiting for the carousel's own decode. The path is the identity
     * of the bitmap; a bitmap is installed only into a slot whose path
     * matches, and the cache is path-keyed, so a bitmap that is never
     * referenced by the current window is simply resident for a future
     * window that re-uses the path.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     */
    public void onArtReady(@NonNull String path, @NonNull Bitmap bitmap) {
        mCache.put(path, bitmap);
        if (mStrip != null) {
            render();
        }
    }

    /**
     * Removes the bitmap for the given path from the shared cache and
     * re-renders.
     *
     * <p>Used when a metadata edit changes or removes a song's album
     * art. The next render will re-decode the path from the file.</p>
     *
     * @param path Path to invalidate
     */
    public void invalidatePath(@NonNull String path) {
        mCache.remove(path);
        if (mStrip != null) {
            render();
        }
    }

    /**
     * Installs the given bitmap as the themed placeholder.
     *
     * <p>The placeholder fills the current slot while the current song's
     * real art is being decoded, so the player UI agrees with the
     * notification and the media session carousel during the transition
     * window. Unlike real art, the placeholder is not remembered as the
     * slot's content: {@link #render()} still schedules the real decode,
     * and the placeholder is discarded when the decode resolves.</p>
     *
     * @param placeholderBitmap Themed placeholder bitmap, or null to clear
     */
    public void setPlaceholder(@Nullable Bitmap placeholderBitmap) {
        mPlaceholderBitmap = placeholderBitmap;
        if (mStrip != null) {
            render();
        }
    }

    // ============================================================================
    // Swipe
    // ============================================================================

    /**
     * Marks the start of a horizontal swipe on the album art.
     *
     * <p>Refused unless the protocol is {@link SwipeState#IDLE}. A
     * second gesture that arrives while a commit or nudge is in flight
     * is ignored; the first must settle first.</p>
     */
    public void beginSwipe() {
        if (mSwipeState != SwipeState.IDLE) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        mSwipeState = SwipeState.DRAGGING;
    }

    /**
     * Updates the strip's position from the finger's horizontal
     * displacement.
     *
     * <p>Runs on the main thread. When no swipe is active or the strip
     * has not been laid out the call is a no-op. The strip is clamped so
     * the finger cannot drag the strip past a neighbour slot.</p>
     *
     * @param horizontalDisplacement Horizontal displacement in pixels,
     *        positive to the right
     */
    public void updateSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));
        mStrip.setTranslationX(-mSlotWidth + clampedDisplacement);
    }

    /**
     * Ends the swipe and either commits to the neighbour or springs
     * back.
     *
     * <p>A commit is legal only when the release passes the threshold
     * and the corresponding neighbour path exists and differs from the
     * current path. A committed swipe animates to the neighbour position
     * over {@link #SWIPE_ANIMATION_MS} milliseconds, then enters
     * {@link SwipeState#AWAITING_SNAPSHOT} and dispatches
     * {@link SwipeCommitListener#onSwipeCommitted(int)}. A below-
     * threshold release animates the strip to {@code -mSlotWidth} via
     * {@link #animateToRest(Runnable)} and returns the protocol to
     * {@link SwipeState#IDLE}.</p>
     *
     * @param horizontalDisplacement Total horizontal displacement in
     *        pixels, positive to the right
     */
    public void endSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            mSwipeState = SwipeState.IDLE;
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            mSwipeState = SwipeState.IDLE;
            return;
        }

        final float middleZoneWidth = Math.max(
            1f, mSlotWidth - 2f * mEdgeZonePx);
        final float commitThreshold =
            middleZoneWidth * COMMIT_THRESHOLD_FRACTION;
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));

        final boolean wantsForward  = (clampedDisplacement <= -commitThreshold);
        final boolean wantsBackward = (clampedDisplacement >=  commitThreshold);

        final boolean canCommitForward = wantsForward
            && mWindow.nextPath != null
            && !mWindow.nextPath.equals(mWindow.currentPath);
        final boolean canCommitBackward = wantsBackward
            && mWindow.previousPath != null
            && !mWindow.previousPath.equals(mWindow.currentPath);

        if (canCommitForward) {
            startCommit(+1, true);
            return;
        }
        if (canCommitBackward) {
            startCommit(-1, true);
            return;
        }

        mSwipeState = SwipeState.IDLE;
        animateToRest(null);
    }

    /**
     * Begins a commit in the given direction.
     *
     * <p>Sets the expected current path, animates the strip to the
     * neighbour position over the full {@link #SWIPE_ANIMATION_MS}, and
     * arranges the end action. The end action either adopts a window
     * that the service published while the animation was running — or,
     * for an automatic song change, the window
     * {@link #adoptInIdle(PlaybackWindow, long)} stored before the
     * animation started — or enters
     * {@link SwipeState#AWAITING_SNAPSHOT} and, when the commit
     * originated from a swipe, dispatches
     * {@link SwipeCommitListener#onSwipeCommitted(int)}.</p>
     *
     * <p>The expected current path is set before the animation starts,
     * so a window that the service publishes during the animation can
     * be matched immediately. It is cleared by every path that leaves
     * the commit state.</p>
     *
     * @param direction +1 for a next commit, -1 for a previous commit
     * @param fireListener True when the commit originated from a swipe
     *        and the swipe commit listener should be dispatched at the
     *        end of the animation
     */
    private void startCommit(int direction, final boolean fireListener) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.COMMITTING;
        mExpectedCurrentPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;

        final float targetTranslationX = (direction > 0)
            ? (-2f * mSlotWidth)
            : 0f;

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(SWIPE_ANIMATION_MS)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (mSwipeState != SwipeState.COMMITTING) {
                        return;
                    }
                    if (mConfirmedWindow != null) {
                        final PlaybackWindow confirmedWindow =
                            mConfirmedWindow;
                        mConfirmedWindow = null;
                        mWindow = confirmedWindow;
                        mExpectedCurrentPath = null;
                        mSwipeState = SwipeState.IDLE;
                        snapToRest();
                        render();
                        return;
                    }
                    mSwipeState = SwipeState.AWAITING_SNAPSHOT;
                    if (fireListener && mSwipeCommitListener != null) {
                        mSwipeCommitListener.onSwipeCommitted(mSwipeDirection);
                    }
                    scheduleSnapshotTimeout();
                }
            })
            .start();
    }

    /**
     * Runs the below-threshold nudge: the strip slides out by exactly
     * the nudge distance — a fraction of the middle zone, deliberately
     * smaller than the commit threshold — and then returns to rest via
     * {@link #animateToRest(Runnable)}.
     *
     * <p>Reached from three callers, all under repeat-one: the
     * automatic restart when a track loops, and the transport buttons
     * via {@link #nudgeToNext()} and {@link #nudgeToPrevious()}. The
     * three produce identical animations, so a press and an
     * involuntary restart look the same.</p>
     *
     * <p>A repeat-one restart is not a rejected commit. Nothing was
     * committed; the song is the same as it was. The visible shape is
     * the shape of a very small below-threshold swipe: the strip moves
     * partway toward the neighbour — well short of the boundary a swipe
     * would have to cross to commit — and then returns. The neighbour
     * peeks into the viewport by exactly
     * {@link #RESTART_NUDGE_FRACTION} of the middle zone and no
     * more.</p>
     *
     * <p>A committed swipe under the same mode behaves differently:
     * the gesture crossed the threshold, so the strip travels the full
     * slot width toward the neighbour and only returns when the
     * service's refusal arrives. That is handled by
     * {@link #setWindow(PlaybackWindow)}'s COMMITTING mismatch branch,
     * not here.</p>
     *
     * <p>The outward leg's duration is proportional to the distance
     * travelled, so the strip's velocity matches a full commit's: a
     * full commit moves one slot width in {@link #SWIPE_ANIMATION_MS},
     * and the nudge moves the {@code nudgePx} fraction of that
     * distance in the corresponding fraction of
     * {@link #SWIPE_ANIMATION_MS}. The return leg uses
     * {@link #animateToRest(Runnable)}, the same method every other
     * return uses, and runs the full {@link #SWIPE_ANIMATION_MS}.</p>
     *
     * <p>The state stays {@link SwipeState#RESTARTING} across both
     * legs so a window that arrives during the animation is handled by
     * {@link #setWindow(PlaybackWindow)}'s RESTARTING branch, which
     * ignores a re-publication and aborts the animation only for a
     * genuine new transition. For the automatic-restart caller the
     * window is already adopted before this method runs — its three
     * paths match the previous window's — so no re-render is needed on
     * completion. For the button-press callers the confirming window
     * arrives during the animation and is handled by the same
     * branch.</p>
     *
     * @param direction +1 for a forward animation, -1 for a backward
     *        one
     */
    private void startBelowThreshold(int direction) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.RESTARTING;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        // The nudge distance: a fraction of the middle zone,
        // deliberately smaller than the commit threshold. The
        // animation moves the strip exactly this far, matching the
        // visible extent of a very small swipe that never came close
        // to committing.
        final float middleZoneWidth = Math.max(1f,
            mSlotWidth - 2f * mEdgeZonePx);
        final float nudgePx =
            middleZoneWidth * RESTART_NUDGE_FRACTION;

        // A forward swipe drags the strip toward -2W; the nudge
        // position for a forward animation is -W - nudge. A backward
        // swipe drags the strip toward 0; the nudge position for a
        // backward animation is -W + nudge.
        final float targetTranslationX = (direction > 0)
            ? (-mSlotWidth - nudgePx)
            : (-mSlotWidth + nudgePx);

        // Duration proportional to distance, matching the velocity of
        // a full commit: SWIPE_ANIMATION_MS covers mSlotWidth pixels,
        // so nudgePx pixels takes the corresponding fraction.
        final long outwardDuration = Math.max(1L,
            (long) (SWIPE_ANIMATION_MS * nudgePx
                / Math.max(1f, mSlotWidth)));

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(outwardDuration)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (mSwipeState != SwipeState.RESTARTING) {
                        return;
                    }
                    // Return leg, via the same method every other
                    // return uses.
                    animateToRest(new Runnable() {
                        @Override
                        public void run() {
                            if (mSwipeState != SwipeState.RESTARTING) {
                                return;
                            }
                            mSwipeState = SwipeState.IDLE;
                            mSwipeDirection = 0;
                            mExpectedCurrentPath = null;
                            mConfirmedWindow = null;
                        }
                    });
                }
            })
            .start();
    }

    /**
     * Abandons any in-flight commit or nudge and returns the protocol
     * to {@link SwipeState#IDLE}.
     *
     * <p>Cancels the strip animation, the snapshot timeout, and every
     * field the commit or animation was tracking, including
     * {@link #mConfirmedWindow}. Does not move the strip; callers that
     * need the strip at rest call {@link #snapToRest()} or
     * {@link #animateToRest(Runnable)} after this method.</p>
     */
    private void cancelSwipe() {
        if (mStrip != null) {
            mStrip.animate().cancel();
        }
        cancelSnapshotTimeout();
        mSwipeState = SwipeState.IDLE;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;
    }

    /**
     * Animates the strip to rest over {@link #SWIPE_ANIMATION_MS}
     * milliseconds and runs the given action when the animation ends.
     *
     * <p>Used by every return path: the spring-back after a
     * below-threshold swipe, the refusal path of a committed swipe or
     * button press, the mismatch path of an in-flight commit, and the
     * return leg of the below-threshold nudge. One method, one
     * duration, one visual for every return.</p>
     *
     * @param endAction Action to run when the animation completes, or null
     */
    private void animateToRest(@Nullable final Runnable endAction) {
        if (mStrip == null) {
            if (endAction != null) {
                endAction.run();
            }
            return;
        }
        mStrip.animate()
            .translationX(-mSlotWidth)
            .setDuration(SWIPE_ANIMATION_MS)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (mStrip != null) {
                        mStrip.setTranslationX(-mSlotWidth);
                    }
                    if (endAction != null) {
                        endAction.run();
                    }
                }
            })
            .start();
    }

    /**
     * Schedules the safety-net timeout that fires when a commit is
     * dispatched but no window follows.
     */
    private void scheduleSnapshotTimeout() {
        cancelSnapshotTimeout();
        mSnapshotTimeoutRunnable = new Runnable() {
            @Override
            public void run() {
                if (mSwipeState != SwipeState.AWAITING_SNAPSHOT) {
                    return;
                }
                Log.w(TAG, "Snapshot timeout; springing back");
                mExpectedCurrentPath = null;
                mSwipeState = SwipeState.IDLE;
                animateToRest(null);
            }
        };
        mHandler.postDelayed(mSnapshotTimeoutRunnable, SNAPSHOT_TIMEOUT_MS);
    }

    /**
     * Cancels the safety-net snapshot timeout. Idempotent.
     */
    private void cancelSnapshotTimeout() {
        if (mSnapshotTimeoutRunnable != null) {
            mHandler.removeCallbacks(mSnapshotTimeoutRunnable);
            mSnapshotTimeoutRunnable = null;
        }
    }

    // ============================================================================
    // Rendering
    // ============================================================================

    /**
     * Renders the current window.
     *
     * <p>For each slot, consults the shared cache for the slot's path,
     * installs the bitmap when one is present, installs the placeholder
     * in the current slot when the current path's art is unavailable,
     * and schedules a decode for any path whose art is not cached and
     * not already being decoded.</p>
     *
     * <p>Runs on the main thread. Idempotent; a repeated call with the
     * same window and the same cache state produces the same
     * result.</p>
     */
    private void render() {
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }

        final Bitmap previousBitmap = pathBitmap(mWindow.previousPath);
        final Bitmap currentBitmap = pathBitmap(mWindow.currentPath);
        final Bitmap nextBitmap = pathBitmap(mWindow.nextPath);

        installImage(mPreviousView, previousBitmap);
        installImage(mCurrentView,
            (currentBitmap != null) ? currentBitmap : mPlaceholderBitmap);
        installImage(mNextView, nextBitmap);

        scheduleIfMissing(mWindow.previousPath, previousBitmap);
        scheduleIfMissing(mWindow.currentPath, currentBitmap);
        scheduleIfMissing(mWindow.nextPath, nextBitmap);
    }

    /**
     * Returns the cached bitmap for the given path, or null when none is
     * cached or the cached bitmap has been recycled.
     *
     * @param path Path to look up, or null
     * @return The cached bitmap, or null
     */
    @Nullable
    private Bitmap pathBitmap(@Nullable String path) {
        if (path == null) {
            return null;
        }
        final Bitmap cachedBitmap = mCache.get(path);
        return (cachedBitmap != null && !cachedBitmap.isRecycled())
            ? cachedBitmap : null;
    }

    /**
     * Installs the given bitmap into the given slot, or clears the slot
     * when the bitmap is null or recycled.
     *
     * @param slotView Slot to install into, or null
     * @param bitmap Bitmap to install, or null
     */
    private void installImage(@Nullable ImageView slotView,
                              @Nullable Bitmap bitmap) {
        if (slotView == null) {
            return;
        }
        if (bitmap != null && !bitmap.isRecycled()) {
            slotView.setImageBitmap(bitmap);
        } else {
            slotView.setImageDrawable(null);
        }
    }

    /**
     * Schedules a decode for the given path when its art is not cached
     * and not already being decoded.
     *
     * <p>Decodes are deduplicated by path. When a decode resolves, the
     * bitmap is placed in the shared cache and the carousel
     * re-renders unconditionally; the new render consults the cache and
     * installs the bitmap only into a slot whose path matches.</p>
     *
     * @param path Path to schedule, or null
     * @param alreadyLoadedBitmap Cached bitmap for the path, or null
     */
    private void scheduleIfMissing(@Nullable final String path,
                                   @Nullable Bitmap alreadyLoadedBitmap) {
        if (path == null || alreadyLoadedBitmap != null) {
            return;
        }
        if (!mInflightDecodePaths.add(path)) {
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap decodedBitmap = decodeSlotBitmap(path);
                mContainer.post(new Runnable() {
                    @Override
                    public void run() {
                        mInflightDecodePaths.remove(path);
                        if (decodedBitmap != null) {
                            mCache.put(path, decodedBitmap);
                        }
                        if (mStrip != null) {
                            render();
                        }
                    }
                });
            }
        });
    }

    /**
     * Decodes the art for the given path at slot resolution.
     *
     * <p>Runs on the executor. The {@link MediaMetadataRetriever} is
     * released in every exit path. The returned bitmap is a copy scaled
     * to at most {@link #SLOT_BITMAP_SIZE_PX} on the long side.</p>
     *
     * @param path Path of the song whose art should be decoded
     * @return The decoded bitmap, or null on failure or when the file
     *         has no embedded art
     */
    @Nullable
    private Bitmap decodeSlotBitmap(@NonNull String path) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(path);
            final byte[] embeddedPicture = retriever.getEmbeddedPicture();
            if (embeddedPicture == null || embeddedPicture.length == 0) {
                return null;
            }
            final BitmapFactory.Options boundsOptions =
                new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length, boundsOptions);
            final int sampleSize = calculateSampleSize(
                boundsOptions, SLOT_BITMAP_SIZE_PX, SLOT_BITMAP_SIZE_PX);
            final BitmapFactory.Options decodeOptions =
                new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            decodeOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length, decodeOptions);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to decode slot art for " + path, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits release.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above the
     * requested bounds.
     *
     * @param options Options whose bounds have already been decoded
     * @param requestedWidth Requested width in pixels
     * @param requestedHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateSampleSize(@NonNull BitmapFactory.Options options,
                                    int requestedWidth,
                                    int requestedHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > requestedHeight || width > requestedWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= requestedHeight
                    && (halfWidth / inSampleSize) >= requestedWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}