package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a viewport
 * one slot wide. The strip's middle slot is aligned to the viewport at
 * rest; the outer slots are clipped by the container. When the user
 * drags horizontally on the album art, the strip follows the finger,
 * revealing the previous or next song's art. On release the strip
 * either springs back to the middle slot or animates to a neighbour
 * slot and then asks {@link MusicPlayer} to request the corresponding
 * song change from {@link MusicService}. The new window arrives through
 * the standard playback broadcast and is adopted; the snap that follows
 * a successful commit is pixel-identical because the art is keyed by
 * path, not by slot.</p>
 *
 * <p>Every other transition — a transport button, a headset key, an
 * automatic advance, a stall recovery, a metadata re-publication —
 * is driven from one signal: the {@link PlaybackWindow} the service
 * publishes on its {@code UPDATE_PLAYER} broadcast, together with the
 * transition direction and the restart flag the service names
 * alongside it. The carousel does not predict the direction from its
 * memory of an older window, and it does not animate before the
 * service has committed the transition. The strip starts moving on
 * the turn the service's broadcast reaches it, which is the same turn
 * the title, the artist, the seek bar's range, the transport glyph,
 * the notification, and the media session are written. Every entry
 * point — a swipe, a tap, an automatic song change — therefore
 * produces the same motion at the same point in the transition.</p>
 *
 * <h3>Authority</h3>
 * <p>The window the carousel displays is a value published by
 * {@link MusicService}. The carousel computes neither the window nor
 * its neighbours nor the direction of the transition that produced
 * it; it renders the three paths the service names and consults the
 * shared {@link LruCache} for each path's art, and it runs the one
 * animation the service's direction and restart flag describe. The
 * carousel holds no playlist, no index, and no bitmap as primary
 * state. Its entire state is the last window it was given, the
 * generation of that window, the current commit or restart or reveal
 * state, the pending confirmed window during a commit animation, and
 * the shared placeholder bitmap.</p>
 *
 * <p>Every path through the service produces an {@code UPDATE_PLAYER}
 * broadcast carrying a {@link PlaybackWindow}, a transition
 * direction, and a restart flag, and every window is adopted by the
 * same {@link #setWindow(PlaybackWindow, int, boolean)} method. There
 * is no second mutation path that could disagree with the service.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn:</p>
 * <ul>
 *   <li><b>Previous</b> — the path the service names as the previous
 *       neighbour, or empty when none.</li>
 *   <li><b>Current</b> — the path the service names as the current
 *       song.</li>
 *   <li><b>Next</b> — the path the service names as the next neighbour,
 *       or empty when none.</li>
 * </ul>
 *
 * <p>On a single-song playlist, or a shuffle re-pick that cannot avoid
 * the current index, the service names the current song as its own
 * neighbour — the request wraps to the same index and the service
 * restarts the song. The carousel renders the same art in the outer
 * slots, and the restart's nudge acknowledges the restart by sliding
 * toward that duplicate and returning.</p>
 *
 * <h3>Transitions</h3>
 * <p>The service names every transition's direction and restart. The
 * carousel runs one of three animations from them, plus a no-op when
 * the window merely re-publishes the same generation:</p>
 * <ul>
 *   <li><b>Commit.</b> The direction is non-zero, the restart flag
 *       is false, and the incoming current path differs from the
 *       current song. The strip slides a full slot width toward the
 *       named neighbour and settles at rest on the incoming window.
 *       Reached by a committed swipe, by a transport button press,
 *       and by an automatic song change.</li>
 *   <li><b>Restart.</b> The restart flag is true. The incoming
 *       current path is unchanged — a repeat-one restart, or a wrap
 *       that lands on the current index on a single-song playlist.
 *       The strip slides a fraction of the middle zone toward the
 *       neighbour the direction names, then returns to rest. The
 *       user sees the neighbour nudge into the viewport and
 *       retreat.</li>
 *   <li><b>Reveal.</b> The direction is zero and the incoming
 *       current path differs from the current song. The reveal is a
 *       staggered cross-fade: the outgoing art fades out over the
 *       first portion of the transition with an accelerating curve,
 *       and the incoming art fades in over the rest with a
 *       decelerating curve and a subtle scale-up. There is no
 *       midpoint and no blank frame.</li>
 * </ul>
 *
 * <p>A window that re-publishes the same three paths with the same
 * generation — a pause, a resume, a seek, a metadata poke, a position
 * checkpoint — is adopted at rest with no animation.</p>
 *
 * <h3>Motion</h3>
 * <p>The carousel's motion system follows Material Design 3 tokens.
 * Every slide uses the same duration band and the same easing family,
 * so a commit, a restart, and a reveal read as variations of one
 * gesture rather than three separate animations.</p>
 *
 * <p>The commit slide uses {@link #EMPHASIZED_DECELERATE}, the
 * easing curve Material prescribes for elements entering the screen.
 * The outgoing half of the reveal uses {@link #EMPHASIZED_ACCELERATE},
 * the curve prescribed for elements leaving the screen. The restart
 * runs both its legs on a {@link SpringAnimation} with a low-damping
 * {@link SpringForce}: the strip slides out with a subtle overshoot,
 * and the return carries it back with the same physical response.
 * The outward leg and the return leg share the damping ratio, the
 * stiffness, and the distance, so the two halves of the gesture read
 * as one motion rather than as an out-move followed by a faster
 * return.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every animation ends in a single main-thread turn: the strip's
 * snap to rest, the render of the incoming window, the removal of the
 * reveal overlay when one is running, and the
 * {@link #postOnSettle(Runnable)} queue are all flushed together.
 * Because view mutations are batched by the framework into the next
 * layout pass, the strip's new bitmaps and any work the caller
 * scheduled through {@link #postOnSettle(Runnable)} — the title, the
 * artist, the seek bar's range, the transport glyph, the notification,
 * the media session — reach their surfaces from one turn. The art does
 * not land before the text; both land together, on the frame the
 * transition is meant to be seen on.</p>
 *
 * <p>{@link #setWindow(PlaybackWindow, int, boolean)} reports whether
 * the commit landed synchronously. A return of {@code true} means the
 * window was adopted with no animation running afterwards; the caller
 * may run its remaining commit work in the current turn. A return of
 * {@code false} means an animation is running; the caller registers
 * that work through {@link #postOnSettle(Runnable)}, which runs on the
 * frame the animation ends. The two branches converge on the same
 * commit turn, so a caller writes one commit runnable and dispatches
 * it through this contract without inspecting the carousel's internal
 * state.</p>
 *
 * <h3>Asynchronous Loading</h3>
 * <p>Whenever a window is adopted, {@link #render()} schedules a decode
 * for every path in the window whose art is not in the cache and not
 * already being decoded. Loads are deduplicated by path. When a decode
 * resolves, the bitmap is placed in the shared cache and the carousel
 * re-renders; a decode for a path that has since left the window is
 * placed in the cache and dropped. A decode that resolves while a
 * reveal is running and whose path is the one the overlay is
 * presenting is also installed into the overlay in place, so the
 * reveal continues with the resolved art rather than the placeholder
 * that was shown while the decode was in flight.</p>
 *
 * <p>Callers that have already decoded a song's art — the cold-start
 * preload, the metadata-editor path, and the incoming-file pre-decode
 * in {@link MusicPlayer} — hand the bitmap to the carousel through
 * {@link #onArtReady(String, Bitmap)}. The handoff is a cache write and
 * a render; the decode path and the identity rule are unchanged.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. Decoding runs on the
 * supplied executor; results are dispatched to the main thread before
 * touching any view or field.</p>
 *
 * @see MusicService
 * @see MusicPlayer
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.2.6
 * @since 1.2.0
 */
public final class AlbumArtCarousel {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "AlbumArtCarousel";

    /**
     * Maximum dimension of a slot bitmap, in pixels.
     *
     * <p>Slot bitmaps are downsampled to this size when decoded. The
     * shared {@link LruCache} holds bitmaps at this same maximum
     * dimension, whether the carousel produced them or another
     * consumer did — the cold-start preload and the incoming-file
     * pre-decode in {@link MusicPlayer} both decode at this size —
     * so a path decoded by one consumer is a cache hit for the
     * others. The cap keeps the three slots cheap to keep
     * resident.</p>
     */
    private static final int SLOT_BITMAP_SIZE_PX = 1024;

    /**
     * Duration of a full-slot commit, in milliseconds.
     *
     * <p>Chosen from the Material Design 3 duration tokens: the long2
     * value, which sits in the band for a transition that moves a full
     * element across the screen. The commit is the carousel's most
     * substantial spatial move, so it earns the longest duration in
     * the set.</p>
     */
    private static final long COMMIT_DURATION_MS = 500L;

    /**
     * Duration of a return-to-rest glide, in milliseconds.
     *
     * <p>Shorter than the commit: a spring-back that does not travel a
     * full slot width should not take as long. The duration sits in the
     * Material medium band, which reads as a quick, decisive return
     * without feeling abrupt.</p>
     *
     * <p>Used by {@link #animateToRest(Runnable)}, which every return
     * from a partial commit runs — a refused committed swipe, a
     * snapshot timeout, the mismatch branch of an in-flight commit.
     * The restart's return leg does not use this constant; it runs on
     * the same spring as its outward leg, so the two halves of the
     * nudge share their motion model.</p>
     */
    private static final long RETURN_DURATION_MS = 350L;

    /**
     * Duration of the one-way reveal used when the current song changed
     * to a path that was not one of the previous window's neighbours.
     *
     * <p>The reveal is a staggered cross-fade, not a spatial movement.
     * The staggered timing divides this duration into an outgoing leg
     * and an incoming leg, each with its own curve. The value stays
     * within the Material long band for complex choreography: enough
     * room for the two legs to overlap in the middle third, short
     * enough that the transition does not read as a wait.</p>
     */
    private static final long REVEAL_DURATION_MS = 600L;

    /**
     * Fraction of {@link #REVEAL_DURATION_MS} the outgoing art spends
     * fading out.
     *
     * <p>The outgoing art reaches zero opacity at this fraction of the
     * total duration, before the incoming art reaches full opacity. The
     * two tracks overlap in the middle third, which is where the
     * cross-fade reads as a dissolve rather than a collision. The
     * outgoing leg is the shorter of the two: a leaving element clears
     * quickly so the incoming element has room to arrive.</p>
     */
    private static final float REVEAL_OUTGOING_FRACTION = 0.45f;

    /**
     * Scale the incoming art starts at and grows from during the
     * reveal.
     *
     * <p>A small scale-up from this value to 1.0 accompanies the
     * fade-in. The difference is deliberately subtle — enough to give
     * the incoming art a sense of depth arriving over the outgoing art,
     * not enough to read as a zoom. Combined with the decelerate curve,
     * the incoming art decelerates into its resting size as it reaches
     * full opacity.</p>
     */
    private static final float REVEAL_INCOMING_START_SCALE = 0.96f;

    /**
     * Fraction of {@link #REVEAL_DURATION_MS} the incoming leg's start
     * is advanced into the outgoing leg.
     *
     * <p>The incoming leg begins before the outgoing leg has finished.
     * The overlap is deliberate: a hard handoff where the outgoing
     * reaches zero before the incoming starts leaves one frame where
     * the viewport is empty. The overlap keeps at least one image on
     * screen for every frame of the transition, and because the
     * incoming curve is decelerating from zero, the overlap region is
     * dim enough that the two images do not read as a muddy
     * double-exposure.</p>
     */
    private static final float REVEAL_OVERLAP_FRACTION = 0.15f;

    /**
     * Fraction of the middle zone the finger must travel before the
     * swipe commits.
     *
     * <p>The threshold is applied to the middle zone — the slot width
     * minus the two volume edge zones — not to the slot width. A
     * horizontal swipe is the carousel's gesture only in the middle
     * zone; the edge zones are the volume gesture's.</p>
     */
    private static final float COMMIT_THRESHOLD_FRACTION = 0.50f;

    /**
     * Fraction of the middle zone the restart nudge travels.
     *
     * <p>Deliberately smaller than the commit threshold: it is an
     * acknowledgement that the song restarted, not the beginning of an
     * advance, so it reveals less of the neighbour than a swipe that
     * nearly committed would.</p>
     */
    private static final float RESTART_NUDGE_FRACTION = 0.25f;

    /**
     * Safety-net timeout for {@link SwipeState#AWAITING_SNAPSHOT}, in
     * milliseconds.
     *
     * <p>The commit guards close every ordinary path to a snapshot
     * arriving late. The timeout covers the unexpected — an activity
     * destroyed mid-transition, a service killed without broadcasting.
     * When it fires, the carousel springs back.</p>
     */
    private static final long SNAPSHOT_TIMEOUT_MS = 1500L;

    /**
     * Material Design 3 emphasized easing curve for elements entering
     * the screen.
     *
     * <p>The cubic-bezier control points are the platform's
     * {@code PathInterpolator} values for
     * {@code md.sys.motion.easing.emphasized.decelerate}: an element
     * that enters starts quickly and settles gently into its resting
     * position. The carousel uses this curve for the incoming half of
     * the commit slide and the incoming half of the reveal.</p>
     *
     * <p>See the Material Design 3
     * <a href="https://m3.material.io/styles/motion/easing-and-duration/tokens-specs">
     * easing and duration tokens</a> for the reference values.</p>
     */
    private static final PathInterpolator EMPHASIZED_DECELERATE =
        new PathInterpolator(0.05f, 0.7f, 0.1f, 1f);

    /**
     * Material Design 3 emphasized easing curve for elements leaving
     * the screen.
     *
     * <p>The cubic-bezier control points are the platform's
     * {@code PathInterpolator} values for
     * {@code md.sys.motion.easing.emphasized.accelerate}: an element
     * that leaves starts slowly and accelerates out of view. The
     * carousel uses this curve for the outgoing half of the reveal,
     * so the outgoing art clears quickly and the incoming art has
     * room to arrive.</p>
     */
    private static final PathInterpolator EMPHASIZED_ACCELERATE =
        new PathInterpolator(0.3f, 0f, 0.8f, 0.15f);

    /**
     * Damping ratio for the restart nudge's spring force.
     *
     * <p>A value below 1 makes the spring under-damped: the strip
     * overshoots its resting position and oscillates back. The chosen
     * value is the platform's low-bouncy constant — enough overshoot
     * to read as a physical acknowledgement, not enough to distract
     * from the song restart the nudge is confirming.</p>
     *
     * <p>Both legs of the nudge use this value. The outward leg
     * overshoots its displaced target by the same amount the return
     * leg overshoots rest, so the two halves of the gesture share
     * their physical character.</p>
     */
    private static final float NUDGE_SPRING_DAMPING_RATIO =
        SpringForce.DAMPING_RATIO_LOW_BOUNCY;

    /**
     * Stiffness for the restart nudge's spring force.
     *
     * <p>The platform's low-stiffness constant gives the spring a
     * gentle pull toward its target, so the oscillation decays over a
     * short, readable span rather than ringing.</p>
     *
     * <p>Both legs of the nudge use this value. The two springs have
     * the same natural frequency, so the outward leg and the return
     * leg take the same time to settle.</p>
     */
    private static final float NUDGE_SPRING_STIFFNESS =
        SpringForce.STIFFNESS_LOW;

    // ============================================================================
    // Commit State
    // ============================================================================

    /**
     * States of the commit protocol.
     */
    private enum SwipeState {

        /** No gesture, no pending commit. The resting state. */
        IDLE,

        /** Finger down, strip following the finger. */
        DRAGGING,

        /**
         * The strip is animating to a neighbour position. Entered by
         * the release of a swipe that passed its commit threshold, or
         * by an automatic song transition whose incoming window
         * arrives while the carousel is idle.
         */
        COMMITTING,

        /** Animation done, commit under way, waiting for the service's window. */
        AWAITING_SNAPSHOT,

        /**
         * The strip is running the restart animation: a spring-driven
         * outward leg followed by a spring-driven return to rest, both
         * on the same force.
         */
        RESTARTING,

        /**
         * The carousel is running the one-way reveal used when the
         * current song changed to a path that was not one of the
         * previous window's neighbours.
         */
        REVEALING
    }

    // ============================================================================
    // Listener
    // ============================================================================

    /**
     * Receives a swipe commit request from the carousel.
     *
     * <p>The listener is dispatched only for commits that originated
     * from a swipe gesture. Every other transition — a transport
     * button, a headset key, an automatic advance — is driven from the
     * service's broadcast, and the caller that requested it does not
     * need a callback from the carousel.</p>
     */
    public interface SwipeCommitListener {

        /**
         * Called when a swipe has committed and the carousel is waiting
         * for the service to confirm.
         *
         * @param direction +1 for a next commit, -1 for a previous commit
         */
        void onSwipeCommitted(int direction);
    }

    // ============================================================================
    // Collaborators
    // ============================================================================

    /** Context used for resource and density lookup. */
    @NonNull private final Context mContext;

    /** Viewport into which the strip is attached. */
    @NonNull private final FrameLayout mContainer;

    /** Shared album-art cache. */
    @NonNull private final LruCache<String, Bitmap> mCache;

    /** Executor for slot decodes. */
    @NonNull private final ExecutorService mExecutor;

    /** Main-thread handler for view mutation and the snapshot timeout. */
    @NonNull private final Handler mHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // View State
    // ============================================================================

    /** The three-slot strip. Null before {@link #attach()}. */
    @Nullable private LinearLayout mStrip;

    /** Left slot: previous song. Null before {@link #attach()}. */
    @Nullable private ImageView mPreviousView;

    /** Middle slot: current song. Null before {@link #attach()}. */
    @Nullable private ImageView mCurrentView;

    /** Right slot: next song. Null before {@link #attach()}. */
    @Nullable private ImageView mNextView;

    /**
     * Temporary overlay used by the one-way reveal, or null when no
     * reveal is running. Added to the viewport for the duration of the
     * reveal and removed on its end frame.
     */
    @Nullable private ImageView mFadeOverlayView = null;

    /**
     * Path whose art the reveal overlay is currently presenting, or
     * null when no reveal is running. Used to decide whether an
     * incoming broadcast or a decoded bitmap should retarget the
     * overlay's bitmap.
     */
    @Nullable private String mFadeOverlayPath = null;

    /** Width of one slot in pixels, or 0 before the first layout. */
    private int mSlotWidth = 0;

    /** Height of one slot in pixels, or 0 before the first layout. */
    private int mSlotHeight = 0;

    /** Width of one volume edge zone in pixels. */
    private int mEdgeZonePx = 0;

    // ============================================================================
    // Window and Placeholder
    // ============================================================================

    /** The window the carousel currently renders. Never null. */
    @NonNull private PlaybackWindow mWindow = PlaybackWindow.EMPTY;

    /**
     * Generation of {@link #mWindow}.
     *
     * <p>Updated by {@link #setWindow(PlaybackWindow, int, boolean)} on
     * every adoption. Used by
     * {@link #adoptInIdle(PlaybackWindow, long, int, boolean)} to tell
     * a fresh transition apart from a broadcast that merely
     * re-publishes the same window.</p>
     */
    private long mLastWindowGeneration = -1L;

    /**
     * Bitmap currently shown as the placeholder in the current slot
     * whenever the current song's real art is unavailable, or null.
     */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Paths currently being decoded, so a decode is not scheduled twice. */
    @NonNull private final Set<String> mInflightDecodePaths =
        Collections.newSetFromMap(
            new ConcurrentHashMap<String, Boolean>());

    // ============================================================================
    // Commit State
    // ============================================================================

    /** Current state of the commit protocol. */
    @NonNull private SwipeState mSwipeState = SwipeState.IDLE;

    /** Direction of the current commit: +1 for next, -1 for previous. */
    private int mSwipeDirection = 0;

    /** Path the strip slid to, recorded when a commit starts. */
    @Nullable private String mExpectedCurrentPath = null;

    /**
     * Window that the service has published during a running commit
     * animation and that confirms the path the strip is sliding toward.
     *
     * <p>Set by {@link #setWindow(PlaybackWindow, int, boolean)} when
     * the confirming broadcast arrives during a commit animation. The
     * commit animation's end action finds the window here on the first
     * frame after the slide completes, so the settle does not depend
     * on any further state.</p>
     */
    @Nullable private PlaybackWindow mConfirmedWindow = null;

    /** Listener that receives commit requests, or null. */
    @Nullable private SwipeCommitListener mSwipeCommitListener = null;

    /** Runnable that fires {@link #SNAPSHOT_TIMEOUT_MS} after a commit is dispatched. */
    @Nullable private Runnable mSnapshotTimeoutRunnable = null;

    /**
     * True while a return-to-rest animation is running.
     *
     * <p>The state enum is {@link SwipeState#IDLE} during a
     * return-to-rest — the commit is over and the strip is gliding home
     * — so the enum alone cannot report the strip as moving. This flag
     * carries that fact to {@link #isAnimating()}, so a caller that
     * gates work on the strip's motion, or that asks
     * {@link #setWindow(PlaybackWindow, int, boolean)} for the commit
     * contract, receives the honest answer.</p>
     */
    private boolean mReturningToRest = false;

    /**
     * The spring animation currently driving the strip for the
     * restart nudge, or null when no nudge is running. Held so the
     * animation can be cancelled when the nudge is superseded.
     *
     * <p>Reassigned on each leg so the outward leg and the return leg
     * both run on the nudge's damping ratio and stiffness. The two
     * springs have the same natural frequency, so the strip spends the
     * same amount of time on each half of the gesture and the two
     * halves read as one motion.</p>
     */
    @Nullable private SpringAnimation mNudgeSpring = null;

    /**
     * Actions queued by {@link #postOnSettle(Runnable)}, run on the
     * frame the carousel returns to {@link SwipeState#IDLE} after a
     * commit, restart, or reveal.
     */
    @NonNull private final List<Runnable> mPostSettleActions =
        new ArrayList<>();

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a carousel bound to the given viewport, cache, and
     * executor.
     *
     * @param context Context used for resource and density lookup
     * @param container Viewport the strip is attached to
     * @param cache Shared album-art cache
     * @param executor Executor for slot decodes
     */
    public AlbumArtCarousel(@NonNull Context context,
                            @NonNull FrameLayout container,
                            @NonNull LruCache<String, Bitmap> cache,
                            @NonNull ExecutorService executor) {
        mContext = context;
        mContainer = container;
        mCache = cache;
        mExecutor = executor;
    }

    // ============================================================================
    // Configuration
    // ============================================================================

    /**
     * Installs the width of one volume edge zone.
     *
     * @param edgeZonePx Width in pixels
     */
    public void setEdgeZonePx(int edgeZonePx) {
        mEdgeZonePx = Math.max(0, edgeZonePx);
    }

    /**
     * Installs the listener that receives swipe commit requests.
     *
     * @param listener Listener, or null to clear
     */
    public void setSwipeCommitListener(
            @Nullable SwipeCommitListener listener) {
        mSwipeCommitListener = listener;
    }

    // ============================================================================
    // Attachment and Layout
    // ============================================================================

    /**
     * Builds the strip and attaches it inside the viewport.
     *
     * <p>Idempotent. The three slots are constructed once and reused
     * for the lifetime of the carousel.</p>
     */
    public void attach() {
        if (mStrip != null) {
            return;
        }

        LinearLayout strip = new LinearLayout(mContext);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setClickable(false);
        strip.setFocusable(false);
        strip.setVisibility(View.INVISIBLE);

        ImageView previousView = createSlot();
        ImageView currentView = createSlot();
        ImageView nextView = createSlot();

        strip.addView(previousView);
        strip.addView(currentView);
        strip.addView(nextView);

        mContainer.addView(strip);
        mContainer.setClipChildren(true);

        mStrip = strip;
        mPreviousView = previousView;
        mCurrentView = currentView;
        mNextView = nextView;

        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            layoutSlots();
            mStrip.setVisibility(View.VISIBLE);
            render();
        });
    }

    /**
     * Creates one slot ImageView with the carousel's standard
     * configuration.
     *
     * @return A newly-created slot ImageView
     */
    @NonNull
    private ImageView createSlot() {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setClickable(false);
        view.setFocusable(false);
        view.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /**
     * Recomputes the slot dimensions from the viewport's current size
     * and re-lays out the strip.
     */
    public void onContainerResized() {
        if (mStrip == null) {
            return;
        }
        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            cancelSwipe();
            layoutSlots();
            render();
        });
    }

    /**
     * Resizes each slot and the strip to match the viewport's current
     * width, then snaps the strip to rest.
     */
    private void layoutSlots() {
        if (mStrip == null || mCurrentView == null
                || mPreviousView == null || mNextView == null) {
            return;
        }
        final int width = mContainer.getWidth();
        final int height = mContainer.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }

        mSlotWidth = width;
        mSlotHeight = height;

        for (ImageView slotView : new ImageView[] {
                mPreviousView, mCurrentView, mNextView}) {
            LinearLayout.LayoutParams layoutParams =
                (LinearLayout.LayoutParams) slotView.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = new LinearLayout.LayoutParams(
                    width, height);
            } else {
                layoutParams.width = width;
                layoutParams.height = height;
            }
            slotView.setLayoutParams(layoutParams);
        }

        ViewGroup.LayoutParams stripLayoutParams =
            mStrip.getLayoutParams();
        if (stripLayoutParams == null) {
            stripLayoutParams =
                new FrameLayout.LayoutParams(width * 3, height);
        } else {
            stripLayoutParams.width = width * 3;
            stripLayoutParams.height = height;
        }
        mStrip.setLayoutParams(stripLayoutParams);

        snapToRest();
    }

    /**
     * Sets the strip's {@code translationX} to {@code -mSlotWidth},
     * bringing the middle slot into the viewport, without animation.
     */
    private void snapToRest() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            if (mNudgeSpring != null) {
                mNudgeSpring.cancel();
            }
            mStrip.setTranslationX(-mSlotWidth);
        }
        mReturningToRest = false;
    }

    // ============================================================================
    // Main-Thread Work Contract
    // ============================================================================

    /**
     * Returns whether the strip is moving or awaiting a commit
     * confirmation.
     *
     * <p>True during a drag, a commit animation, a restart nudge, a
     * reveal, a commit awaiting the service's confirming window, and a
     * return-to-rest glide. False only when the strip is at rest and no
     * commit is in flight.</p>
     *
     * @return True when the strip is animating or awaiting a commit
     *         confirmation
     */
    public boolean isAnimating() {
        return mSwipeState != SwipeState.IDLE || mReturningToRest;
    }

    /**
     * Queues an action to run on the frame the carousel settles.
     *
     * <p>When the carousel is at rest the action runs immediately.
     * Otherwise the action is queued and runs on the frame the carousel
     * snaps to rest and re-renders with the incoming window — the same
     * frame the strip's new bitmaps are installed. A caller that has
     * non-animation work to do — text updates that trigger
     * measure-and-layout passes, seek-bar layout passes, notification
     * and media-session commits — uses this hook to schedule that work
     * for the settle frame, so the work and the strip's own re-render
     * land in one layout pass.</p>
     *
     * <p>Actions run in the order they were queued. An action that
     * queues another action from inside its own body is deferred to a
     * later settle, not run in the same pass. When the carousel is
     * cancelled before it settles — a viewport resize, a drag that
     * supersedes the animation, a snapshot timeout — the queued actions
     * run on the cancellation path.</p>
     *
     * @param action Action to run on settle; never null
     */
    public void postOnSettle(@NonNull Runnable action) {
        if (!isAnimating()) {
            action.run();
            return;
        }
        mPostSettleActions.add(action);
    }

    /**
     * Runs and clears every action queued by
     * {@link #postOnSettle(Runnable)}.
     *
     * <p>Copies the queue before running so an action that queues
     * another action from its own body does not extend the pass it is
     * running in.</p>
     */
    private void runPostSettleActions() {
        if (mPostSettleActions.isEmpty()) {
            return;
        }
        final List<Runnable> pending =
            new ArrayList<>(mPostSettleActions);
        mPostSettleActions.clear();
        for (Runnable action : pending) {
            action.run();
        }
    }

    // ============================================================================
    // Window
    // ============================================================================

    /**
     * Adopts the given window and the transition it describes.
     *
     * <p>The entry point for every window that arrives through the
     * service's {@code UPDATE_PLAYER} broadcast. The activity forwards
     * the window, the transition direction, and the restart flag it
     * read from the broadcast here.</p>
     *
     * <p>The direction is the service's own answer: {@code +1} for a
     * forward transition, {@code -1} for a backward one, and {@code 0}
     * when the transition has no spatial direction — an explicit
     * selection, a same-song reprepare, a state re-publication. The
     * restart flag is true when the transition restarts the current
     * song: repeat-one, a single-song playlist, or a shuffle re-pick
     * that cannot avoid the current index. Together they name the
     * animation the carousel runs; the carousel does not predict
     * either value from its memory of an older window.</p>
     *
     * <p>The direction and the restart are read only when the carousel
     * is idle. During an in-flight commit, restart, or reveal the
     * confirming broadcast is not a fresh transition and the two
     * values describe the transition already running, so they are
     * ignored.</p>
     *
     * <p>The return value is the commit contract. A return of
     * {@code true} means the window was adopted with no animation
     * running afterwards — the strip is at rest — and the caller may
     * run its remaining commit work in the current turn. A return of
     * {@code false} means an animation is running; the caller registers
     * its remaining work through {@link #postOnSettle(Runnable)}, which
     * runs on the frame the animation ends. The two branches converge
     * on one commit turn, so a caller writes one commit runnable and
     * dispatches it through this contract without inspecting the
     * carousel's internal state.</p>
     *
     * @param window Window to adopt; never null
     * @param direction +1 for a forward transition, -1 for a backward
     *        one, 0 when the transition has no spatial direction
     * @param restart True when the transition restarts the current
     *        song
     * @return True when the window was committed synchronously; false
     *         when an animation is running and the caller's remaining
     *         work must be queued on the settle frame
     */
    public boolean setWindow(@NonNull PlaybackWindow window,
                             int direction,
                             boolean restart) {
        if (mStrip == null) {
            mWindow = window;
            mLastWindowGeneration = window.generation;
            return true;
        }

        final long previousGeneration = mLastWindowGeneration;
        mLastWindowGeneration = window.generation;

        switch (mSwipeState) {
            case AWAITING_SNAPSHOT: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                mWindow = window;
                mExpectedCurrentPath = null;
                cancelSnapshotTimeout();
                mSwipeState = SwipeState.IDLE;
                if (accepted) {
                    snapToRest();
                    render();
                    runPostSettleActions();
                    return true;
                }
                render();
                animateToRest(this::runPostSettleActions);
                return false;
            }
            case COMMITTING: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                if (accepted) {
                    // The service confirmed the slide while the
                    // animation is still running. Store the window
                    // and let the animation finish; its end action
                    // adopts the window, settles the strip at rest,
                    // and runs the settle queue.
                    mConfirmedWindow = window;
                } else {
                    // The window contradicts the slide. The service
                    // decided otherwise — a repeat-one restart is the
                    // ordinary case — so the strip glides back to
                    // rest from wherever the animation had reached,
                    // and the new window is adopted directly.
                    cancelSwipe();
                    mWindow = window;
                    render();
                    animateToRest(this::runPostSettleActions);
                }
                return false;
            }
            case RESTARTING: {
                // A restart does not change the current song. A window
                // that arrives during the nudge whose current path
                // matches the one the nudge is acknowledging — the
                // repeat-one restart's own broadcast — is stored, and
                // the nudge runs both legs. A window that names a
                // different current song is a genuine takeover: the
                // nudge is abandoned and the strip returns to rest
                // under the new window.
                final String incoming = window.currentPath;
                final boolean sameSong = incoming != null
                    && incoming.equals(mWindow.currentPath);
                if (sameSong) {
                    mWindow = window;
                    return false;
                }
                cancelSwipe();
                mWindow = window;
                render();
                animateToRest(this::runPostSettleActions);
                return false;
            }
            case REVEALING: {
                // A window arrived during the reveal. Store it and,
                // when its current path differs from the one the
                // overlay is presenting, retarget the overlay's
                // bitmap in place. The reveal continues toward the
                // newest current song rather than chaining a second
                // fade.
                mWindow = window;
                final String incoming = window.currentPath;
                if (mFadeOverlayView != null
                        && incoming != null
                        && !incoming.equals(mFadeOverlayPath)) {
                    installOverlayBitmap(incoming);
                }
                return false;
            }
            case DRAGGING: {
                cancelSwipe();
                mWindow = window;
                snapToRest();
                render();
                runPostSettleActions();
                return true;
            }
            case IDLE:
            default: {
                return adoptInIdle(window, previousGeneration,
                    direction, restart);
            }
        }
    }

    /**
     * Adopts a window while the carousel is idle, animating the strip
     * from the direction and restart the service named.
     *
     * <p>The single transition path. The service's
     * {@code UPDATE_PLAYER} broadcast names the window, the direction,
     * and the restart; this method renders exactly what they describe.
     * The automatic advance, a transport button, a headset key, a
     * stall recovery, a metadata re-publication, and the swipe's own
     * confirming window all reach this method with the same inputs and
     * run the same branches.</p>
     *
     * <p>Four outcomes, selected from the inputs and the window's
     * generation:</p>
     * <ul>
     *   <li><b>Re-publication</b> — the generation is unchanged, or
     *       the incoming current path is empty, or the direction is
     *       zero and the current song is unchanged. The strip snaps
     *       to rest and re-renders with no animation.</li>
     *   <li><b>Restart</b> — the restart flag is true. The incoming
     *       window is adopted first, then
     *       {@link #startBelowThreshold(int)} runs. The direction
     *       names the side the nudge leans toward.</li>
     *   <li><b>Commit</b> — the direction is non-zero and the
     *       restart flag is false. The incoming window is stored as
     *       {@link #mConfirmedWindow} and
     *       {@link #startCommit(int, boolean)} runs. The commit
     *       animation's end action finds the stored window and
     *       settles synchronously; the state never enters
     *       {@link SwipeState#AWAITING_SNAPSHOT}, because the window
     *       that confirms the slide is already in hand.</li>
     *   <li><b>Reveal</b> — the direction is zero and the incoming
     *       current path differs from the current song. The incoming
     *       window is adopted and {@link #startFade()} runs.</li>
     * </ul>
     *
     * @param window Window to adopt; never null
     * @param previousGeneration Generation the carousel held before
     *        this call
     * @param direction +1 for a forward transition, -1 for a backward
     *        one, 0 when the transition has no spatial direction
     * @param restart True when the transition restarts the current
     *        song
     * @return True when the window was committed synchronously; false
     *         when an animation is running
     */
    private boolean adoptInIdle(@NonNull PlaybackWindow window,
                                long previousGeneration,
                                int direction,
                                boolean restart) {
        final String incomingCurrent = window.currentPath;
        final boolean songChanged = (incomingCurrent != null)
            && !incomingCurrent.equals(mWindow.currentPath);
        final boolean freshTransition =
            window.generation > previousGeneration;

        if (incomingCurrent == null
                || !freshTransition
                || mSlotWidth <= 0) {
            mWindow = window;
            snapToRest();
            render();
            return true;
        }

        if (direction == 0) {
            mWindow = window;
            if (songChanged) {
                startFade();
                return false;
            }
            snapToRest();
            render();
            return true;
        }

        if (restart) {
            mWindow = window;
            startBelowThreshold(direction);
            return false;
        }

        mConfirmedWindow = window;
        startCommit(direction, false);
        return false;
    }

    /**
     * Removes every slot's content and clears the window.
     *
     * <p>Used on library reset and when no song is playing.</p>
     */
    public void clear() {
        cancelSwipe();
        mWindow = PlaybackWindow.EMPTY;
        mLastWindowGeneration = -1L;
        if (mStrip != null) {
            snapToRest();
            render();
        }
    }

    // ============================================================================
    // External Art Handoff
    // ============================================================================

    /**
     * Records a decoded bitmap for the given path in the shared cache
     * and re-renders.
     *
     * <p>When a reveal is running and the path is the one the overlay
     * is presenting, the overlay's bitmap is also updated in place so
     * the reveal continues with the resolved art rather than the
     * placeholder that was shown while the decode was in flight.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     */
    public void onArtReady(@NonNull String path, @NonNull Bitmap bitmap) {
        mCache.put(path, bitmap);
        if (mStrip == null) {
            return;
        }
        if (mSwipeState == SwipeState.REVEALING
                && path.equals(mFadeOverlayPath)) {
            installOverlayBitmap(path);
        }
        render();
    }

    /**
     * Removes the bitmap for the given path from the shared cache and
     * re-renders.
     *
     * @param path Path to invalidate
     */
    public void invalidatePath(@NonNull String path) {
        mCache.remove(path);
        if (mStrip != null) {
            render();
        }
    }

    /**
     * Installs the given bitmap as the themed placeholder.
     *
     * @param placeholderBitmap Themed placeholder bitmap, or null to clear
     */
    public void setPlaceholder(@Nullable Bitmap placeholderBitmap) {
        mPlaceholderBitmap = placeholderBitmap;
        if (mStrip != null) {
            render();
        }
    }

    // ============================================================================
    // Swipe
    // ============================================================================

    /**
     * Marks the start of a horizontal swipe on the album art.
     */
    public void beginSwipe() {
        if (mSwipeState != SwipeState.IDLE || mReturningToRest) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        mSwipeState = SwipeState.DRAGGING;
    }

    /**
     * Updates the strip's position from the finger's horizontal
     * displacement.
     *
     * @param horizontalDisplacement Horizontal displacement in pixels,
     *        positive to the right
     */
    public void updateSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));
        mStrip.setTranslationX(-mSlotWidth + clampedDisplacement);
    }

    /**
     * Ends the swipe and either commits to the neighbour or springs
     * back.
     *
     * <p>A committed swipe begins its slide immediately, because the
     * strip is already displaced under the finger and returning to
     * rest before the service responded would break the gesture's
     * continuity. The slide is the continuation of the drag; the
     * service's confirming broadcast arrives during it and is absorbed
     * into the commit state. Every other transition is driven from the
     * service's broadcast alone.</p>
     *
     * @param horizontalDisplacement Total horizontal displacement in
     *        pixels, positive to the right
     */
    public void endSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            mSwipeState = SwipeState.IDLE;
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            mSwipeState = SwipeState.IDLE;
            return;
        }

        final float middleZoneWidth = Math.max(
            1f, mSlotWidth - 2f * mEdgeZonePx);
        final float commitThreshold =
            middleZoneWidth * COMMIT_THRESHOLD_FRACTION;
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));

        final boolean wantsForward =
            (clampedDisplacement <= -commitThreshold);
        final boolean wantsBackward =
            (clampedDisplacement >=  commitThreshold);

        final boolean canCommitForward = wantsForward
            && mWindow.nextPath != null
            && !mWindow.nextPath.equals(mWindow.currentPath);
        final boolean canCommitBackward = wantsBackward
            && mWindow.previousPath != null
            && !mWindow.previousPath.equals(mWindow.currentPath);

        if (canCommitForward) {
            startCommit(+1, true);
            return;
        }
        if (canCommitBackward) {
            startCommit(-1, true);
            return;
        }

        mSwipeState = SwipeState.IDLE;
        animateToRest(null);
    }

    // ============================================================================
    // Commit Animations
    // ============================================================================

    /**
     * Begins a commit in the given direction.
     *
     * <p>Sets the expected current path, animates the strip to the
     * neighbour position, and arranges the end action. The end action
     * either adopts the window already stored in
     * {@link #mConfirmedWindow} — set by
     * {@link #adoptInIdle(PlaybackWindow, long, int, boolean)} before
     * the commit starts, or by
     * {@link #setWindow(PlaybackWindow, int, boolean)} while the
     * animation is running — or enters
     * {@link SwipeState#AWAITING_SNAPSHOT} and, when the commit
     * originated from a swipe, dispatches
     * {@link SwipeCommitListener#onSwipeCommitted(int)}.</p>
     *
     * <p>The slide uses the Material Design 3
     * {@link #EMPHASIZED_DECELERATE} curve over
     * {@link #COMMIT_DURATION_MS}: the strip enters its new position
     * quickly and settles gently, which is the shape Material
     * prescribes for an element arriving on screen.</p>
     *
     * @param direction +1 for a next commit, -1 for a previous commit
     * @param fireListener True when the commit originated from a swipe
     */
    private void startCommit(int direction, final boolean fireListener) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.COMMITTING;
        mExpectedCurrentPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;

        final float targetTranslationX = (direction > 0)
            ? (-2f * mSlotWidth)
            : 0f;

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(COMMIT_DURATION_MS)
            .setInterpolator(EMPHASIZED_DECELERATE)
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.COMMITTING) {
                    return;
                }
                if (mConfirmedWindow != null) {
                    final PlaybackWindow confirmedWindow =
                        mConfirmedWindow;
                    mConfirmedWindow = null;
                    mWindow = confirmedWindow;
                    mExpectedCurrentPath = null;
                    mSwipeState = SwipeState.IDLE;
                    snapToRest();
                    render();
                    runPostSettleActions();
                    return;
                }
                mSwipeState = SwipeState.AWAITING_SNAPSHOT;
                if (fireListener && mSwipeCommitListener != null) {
                    mSwipeCommitListener.onSwipeCommitted(
                        mSwipeDirection);
                }
                scheduleSnapshotTimeout();
            })
            .start();
    }

    /**
     * Runs the restart nudge: the strip slides out by a fraction of
     * the middle zone and then returns to rest.
     *
     * <p>Reached from the automatic restart when a track loops, from
     * the wrap-restart on a single-song playlist, and from a
     * repeat-one transport press. The direction names the side the
     * nudge leans toward; the service is the sole source of that
     * value, so a press and an involuntary restart look the same.</p>
     *
     * <p>Both legs run on a {@link SpringAnimation} with the same
     * damping ratio and stiffness. The outward leg carries the strip
     * from rest to the displaced position, and the return leg carries
     * it back, over the same distance and with the same physical
     * response. The two legs therefore take the same time, reach
     * their peaks at the same point in the motion, and overshoot by
     * the same small amount — the strip reads as one gesture that
     * goes out and comes back, not as an out-motion followed by a
     * faster return. The state stays
     * {@link SwipeState#RESTARTING} across both legs, so a window that
     * arrives during the animation is handled by
     * {@link #setWindow(PlaybackWindow, int, boolean)}'s RESTARTING
     * branch, which absorbs the restart's own broadcast and aborts the
     * animation only for a genuine new transition.</p>
     *
     * @param direction +1 for a forward nudge, -1 for a backward one
     */
    private void startBelowThreshold(int direction) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.RESTARTING;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final float middleZoneWidth = Math.max(1f,
            mSlotWidth - 2f * mEdgeZonePx);
        final float nudgePx =
            middleZoneWidth * RESTART_NUDGE_FRACTION;

        final float displacedTranslationX = (direction > 0)
            ? (-mSlotWidth - nudgePx)
            : (-mSlotWidth + nudgePx);

        startNudgeSpring(displacedTranslationX, () -> {
            if (mSwipeState != SwipeState.RESTARTING) {
                return;
            }
            startNudgeReturn();
        });
    }

    /**
     * Runs the return leg of the nudge: a spring from the displaced
     * position back to rest, with the same damping ratio and
     * stiffness as the outward leg.
     *
     * <p>The return leg is a spring rather than a fixed-duration
     * tween so the two halves of the gesture share a motion model.
     * Both legs travel the same distance on the same force, so they
     * take the same time to settle and overshoot by the same small
     * amount. A tween on the return would deliver most of its motion
     * in the first tenth of its duration and read as a snap-back
     * against the slower spring that preceded it; matching the model
     * removes that asymmetry.</p>
     */
    private void startNudgeReturn() {
        startNudgeSpring(-mSlotWidth, this::finishNudge);
    }

    /**
     * Commits the nudge: transitions to {@link SwipeState#IDLE},
     * clears every field the nudge was tracking, and runs and clears
     * the settle-hook queue.
     */
    private void finishNudge() {
        if (mSwipeState != SwipeState.RESTARTING) {
            return;
        }
        mSwipeState = SwipeState.IDLE;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;
        runPostSettleActions();
    }

    /**
     * Starts a spring on the strip's {@code translationX} toward the
     * given target, with the nudge's damping ratio and stiffness, and
     * runs the given action when the spring settles.
     *
     * <p>The field {@link #mNudgeSpring} is reassigned on every leg,
     * so the outward leg and the return leg both run on the nudge's
     * own constants and neither inherits the other's velocity. A
     * spring that has already ended is not disturbed by the
     * {@code cancel()} on the previous instance: the framework treats
     * the cancel of a finished animation as a no-op, and the end
     * listener guards on {@code canceled} before running its
     * action.</p>
     *
     * @param targetTranslationX Target value for the strip's
     *        {@code translationX}
     * @param endAction Action to run when the spring settles; never
     *        null
     */
    private void startNudgeSpring(float targetTranslationX,
                                  @NonNull Runnable endAction) {
        if (mNudgeSpring != null) {
            mNudgeSpring.cancel();
        }
        mNudgeSpring = new SpringAnimation(
            mStrip, DynamicAnimation.TRANSLATION_X,
            targetTranslationX);
        mNudgeSpring.getSpring()
            .setDampingRatio(NUDGE_SPRING_DAMPING_RATIO)
            .setStiffness(NUDGE_SPRING_STIFFNESS);
        mNudgeSpring.addEndListener((animation, canceled, value,
                                     velocity) -> {
            if (canceled) {
                return;
            }
            endAction.run();
        });
        mNudgeSpring.start();
    }

    /**
     * Runs the one-way reveal used when the current song changed to a
     * path that was not one of the previous window's neighbours.
     *
     * <p>The reveal is a staggered cross-fade, not a single-track fade.
     * The outgoing art fades from full opacity to zero over
     * {@link #REVEAL_OUTGOING_FRACTION} of {@link #REVEAL_DURATION_MS},
     * using the Material Design 3 {@link #EMPHASIZED_ACCELERATE} curve
     * so it clears quickly. The incoming art fades from zero to full
     * opacity over the remaining portion of the duration, using the
     * {@link #EMPHASIZED_DECELERATE} curve so it settles gently, and
     * scales from {@link #REVEAL_INCOMING_START_SCALE} to 1.0 across
     * the same window. The two legs overlap by
     * {@link #REVEAL_OVERLAP_FRACTION} of the total duration, so at
     * least one image is on screen for every frame of the
     * transition.</p>
     *
     * <p>The outgoing art is the strip itself, at rest, at full
     * opacity. The incoming art is a temporary {@link ImageView}
     * overlay added to the viewport with a hardware layer set for the
     * duration of the fade. The hardware layer lets the GPU composite
     * the overlay's alpha and scale without a software redraw each
     * frame; the layer is cleared on the fade's end frame.</p>
     *
     * <p>On the fade's end frame the overlay is removed, the strip is
     * re-rendered with the current {@link #mWindow} at full opacity,
     * and the settle hooks run — all in one frame. There is no midpoint
     * and no blank frame: the incoming art rises over the outgoing art
     * as the outgoing art recedes.</p>
     *
     * <p>A broadcast arriving during the reveal with a different
     * current path is handled by {@link #setWindow(PlaybackWindow,
     * int, boolean)}'s REVEALING branch, which retargets the overlay's
     * bitmap in place so the reveal continues toward the newest
     * current song rather than chaining a second fade.</p>
     */
    private void startFade() {
        if (mStrip == null || mSlotWidth <= 0 || mSlotHeight <= 0) {
            snapToRest();
            render();
            return;
        }

        mSwipeState = SwipeState.REVEALING;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final String incomingPath = mWindow.currentPath;
        final Bitmap incomingBitmap = pathBitmap(incomingPath);

        final ImageView overlay = new ImageView(mContext);
        overlay.setScaleType(ImageView.ScaleType.FIT_CENTER);
        overlay.setClickable(false);
        overlay.setFocusable(false);

        final FrameLayout.LayoutParams overlayParams =
            new FrameLayout.LayoutParams(mSlotWidth, mSlotHeight);
        overlayParams.gravity = Gravity.CENTER;
        overlay.setLayoutParams(overlayParams);
        overlay.setImageBitmap(
            (incomingBitmap != null) ? incomingBitmap : mPlaceholderBitmap);
        overlay.setAlpha(0f);
        overlay.setScaleX(REVEAL_INCOMING_START_SCALE);
        overlay.setScaleY(REVEAL_INCOMING_START_SCALE);

        // A hardware layer for the duration of the fade. The overlay
        // is a full-size bitmap composited with alpha and scale every
        // frame; the layer keeps that compositing on the GPU instead
        // of re-rasterizing the bitmap through the software path. The
        // layer is cleared on the end frame so it does not linger as
        // memory.
        overlay.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        mContainer.addView(overlay);
        mFadeOverlayView = overlay;
        mFadeOverlayPath = incomingPath;

        // The outgoing leg: the strip fades from full opacity to zero
        // over the outgoing fraction, with the Material emphasized
        // accelerate curve. A leaving element accelerates out of view;
        // this is the complement of the incoming leg's decelerate, and
        // the two together read as one continuous dissolve.
        final long outgoingDuration = Math.max(1L,
            (long) (REVEAL_DURATION_MS * REVEAL_OUTGOING_FRACTION));
        mStrip.animate()
            .alpha(0f)
            .setDuration(outgoingDuration)
            .setInterpolator(EMPHASIZED_ACCELERATE)
            .start();

        // The incoming leg: the overlay fades from zero to full
        // opacity and scales from its start value to 1.0, over the
        // remainder of the duration, with the Material emphasized
        // decelerate curve. The decelerate curve is what makes an
        // entering element settle into place rather than arrive at
        // full speed.
        final long overlapDuration = Math.max(1L,
            (long) (REVEAL_DURATION_MS * REVEAL_OVERLAP_FRACTION));
        final long incomingDelay = Math.max(0L,
            outgoingDuration - overlapDuration);
        final long incomingDuration = Math.max(1L,
            REVEAL_DURATION_MS - incomingDelay);
        overlay.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(incomingDelay)
            .setDuration(incomingDuration)
            .setInterpolator(EMPHASIZED_DECELERATE)
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.REVEALING) {
                    return;
                }
                mContainer.removeView(overlay);
                mFadeOverlayView = null;
                mFadeOverlayPath = null;
                mSwipeState = SwipeState.IDLE;
                mSwipeDirection = 0;
                if (mStrip != null) {
                    mStrip.setAlpha(1f);
                }
                snapToRest();
                render();
                runPostSettleActions();
            })
            .start();
    }

    /**
     * Installs the cached art for the given path into the reveal
     * overlay, falling back to the placeholder when the art is not
     * cached.
     *
     * @param path Path whose art should be presented, or null
     */
    private void installOverlayBitmap(@Nullable String path) {
        if (mFadeOverlayView == null) {
            return;
        }
        final Bitmap art = (path != null) ? pathBitmap(path) : null;
        mFadeOverlayView.setImageBitmap(
            (art != null) ? art : mPlaceholderBitmap);
    }

    /**
     * Abandons any in-flight commit, restart, or reveal and returns
     * the protocol to {@link SwipeState#IDLE}.
     *
     * <p>Cancels the strip animation, the snapshot timeout, removes
     * the reveal overlay when one is present, restores the strip's
     * alpha, clears every field the commit, restart, or reveal was
     * tracking, and runs and clears the settle-hook queue. The queue is
     * flushed here so a queued action is never dropped when the
     * animation that was going to run it is abandoned. Does not move
     * the strip; callers that need the strip at rest call
     * {@link #snapToRest()} or {@link #animateToRest(Runnable)} after
     * this method.</p>
     */
    private void cancelSwipe() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setAlpha(1f);
        }
        if (mNudgeSpring != null) {
            mNudgeSpring.cancel();
        }
        if (mFadeOverlayView != null) {
            mFadeOverlayView.animate().cancel();
            mFadeOverlayView.setLayerType(View.LAYER_TYPE_NONE, null);
            mContainer.removeView(mFadeOverlayView);
            mFadeOverlayView = null;
        }
        mFadeOverlayPath = null;
        cancelSnapshotTimeout();
        mSwipeState = SwipeState.IDLE;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;
        mReturningToRest = false;
        runPostSettleActions();
    }

    /**
     * Animates the strip to rest over {@link #RETURN_DURATION_MS}
     * milliseconds and runs the given action when the animation ends.
     *
     * <p>Used by every return from a partial commit: the spring-back
     * after a below-threshold swipe, the refusal path of a committed
     * swipe, the mismatch path of an in-flight commit, and the
     * snapshot timeout. The return uses the Material
     * {@link #EMPHASIZED_DECELERATE} curve, so the strip settles into
     * rest with the same quality every other slide uses.</p>
     *
     * <p>The restart nudge does not use this method. Its return leg
     * runs on the same spring as its outward leg, so the two halves of
     * the nudge share a motion model.</p>
     *
     * @param endAction Action to run when the animation completes, or null
     */
    private void animateToRest(@Nullable final Runnable endAction) {
        if (mStrip == null) {
            if (endAction != null) {
                endAction.run();
            }
            return;
        }
        mReturningToRest = true;
        mStrip.animate()
            .translationX(-mSlotWidth)
            .setDuration(RETURN_DURATION_MS)
            .setInterpolator(EMPHASIZED_DECELERATE)
            .withEndAction(() -> {
                if (mStrip != null) {
                    mStrip.setTranslationX(-mSlotWidth);
                }
                mReturningToRest = false;
                if (endAction != null) {
                    endAction.run();
                }
            })
            .start();
    }

    /**
     * Schedules the safety-net timeout that fires when a commit is
     * dispatched but no window follows.
     */
    private void scheduleSnapshotTimeout() {
        cancelSnapshotTimeout();
        mSnapshotTimeoutRunnable = () -> {
            if (mSwipeState != SwipeState.AWAITING_SNAPSHOT) {
                return;
            }
            Log.w(TAG, "Snapshot timeout; springing back");
            mExpectedCurrentPath = null;
            mSwipeState = SwipeState.IDLE;
            animateToRest(this::runPostSettleActions);
        };
        mHandler.postDelayed(
            mSnapshotTimeoutRunnable, SNAPSHOT_TIMEOUT_MS);
    }

    /**
     * Cancels the safety-net snapshot timeout. Idempotent.
     */
    private void cancelSnapshotTimeout() {
        if (mSnapshotTimeoutRunnable != null) {
            mHandler.removeCallbacks(mSnapshotTimeoutRunnable);
            mSnapshotTimeoutRunnable = null;
        }
    }

    // ============================================================================
    // Rendering
    // ============================================================================

    /**
     * Renders the current window.
     *
     * <p>For each slot, consults the shared cache for the slot's path,
     * installs the bitmap when one is present, installs the placeholder
     * in the current slot when the current path's art is unavailable,
     * and schedules a decode for any path whose art is not cached and
     * not already being decoded.</p>
     */
    private void render() {
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }

        final Bitmap previousBitmap = pathBitmap(mWindow.previousPath);
        final Bitmap currentBitmap = pathBitmap(mWindow.currentPath);
        final Bitmap nextBitmap = pathBitmap(mWindow.nextPath);

        installImage(mPreviousView, previousBitmap);
        installImage(mCurrentView,
            (currentBitmap != null) ? currentBitmap : mPlaceholderBitmap);
        installImage(mNextView, nextBitmap);

        scheduleIfMissing(mWindow.previousPath, previousBitmap);
        scheduleIfMissing(mWindow.currentPath, currentBitmap);
        scheduleIfMissing(mWindow.nextPath, nextBitmap);
    }

    /**
     * Returns the cached bitmap for the given path, or null when none
     * is cached or the cached bitmap has been recycled.
     *
     * @param path Path to look up, or null
     * @return The cached bitmap, or null
     */
    @Nullable
    private Bitmap pathBitmap(@Nullable String path) {
        if (path == null) {
            return null;
        }
        final Bitmap cachedBitmap = mCache.get(path);
        return (cachedBitmap != null && !cachedBitmap.isRecycled())
            ? cachedBitmap : null;
    }

    /**
     * Installs the given bitmap into the given slot, or clears the
     * slot when the bitmap is null or recycled.
     *
     * @param slotView Slot to install into, or null
     * @param bitmap Bitmap to install, or null
     */
    private void installImage(@Nullable ImageView slotView,
                              @Nullable Bitmap bitmap) {
        if (slotView == null) {
            return;
        }
        if (bitmap != null && !bitmap.isRecycled()) {
            slotView.setImageBitmap(bitmap);
        } else {
            slotView.setImageDrawable(null);
        }
    }

    /**
     * Schedules a decode for the given path when its art is not cached
     * and not already being decoded.
     *
     * @param path Path to schedule, or null
     * @param alreadyLoadedBitmap Cached bitmap for the path, or null
     */
    private void scheduleIfMissing(@Nullable final String path,
                                   @Nullable Bitmap alreadyLoadedBitmap) {
        if (path == null || alreadyLoadedBitmap != null) {
            return;
        }
        if (!mInflightDecodePaths.add(path)) {
            return;
        }
        mExecutor.execute(() -> {
            final Bitmap decodedBitmap = decodeSlotBitmap(path);
            mContainer.post(() -> {
                mInflightDecodePaths.remove(path);
                if (decodedBitmap != null) {
                    mCache.put(path, decodedBitmap);
                }
                if (mStrip != null) {
                    render();
                }
            });
        });
    }

    /**
     * Decodes the art for the given path at slot resolution.
     *
     * @param path Path of the song whose art should be decoded
     * @return The decoded bitmap, or null on failure or when the file
     *         has no embedded art
     */
    @Nullable
    private Bitmap decodeSlotBitmap(@NonNull String path) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(path);
            final byte[] embeddedPicture =
                retriever.getEmbeddedPicture();
            if (embeddedPicture == null
                    || embeddedPicture.length == 0) {
                return null;
            }
            final BitmapFactory.Options boundsOptions =
                new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length,
                boundsOptions);
            final int sampleSize = calculateSampleSize(
                boundsOptions, SLOT_BITMAP_SIZE_PX,
                SLOT_BITMAP_SIZE_PX);
            final BitmapFactory.Options decodeOptions =
                new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            decodeOptions.inPreferredConfig =
                Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length,
                decodeOptions);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to decode slot art for " + path,
                exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested bounds.
     *
     * @param options Options whose bounds have already been decoded
     * @param requestedWidth Requested width in pixels
     * @param requestedHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateSampleSize(
            @NonNull BitmapFactory.Options options,
            int requestedWidth, int requestedHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > requestedHeight || width > requestedWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= requestedHeight
                    && (halfWidth / inSampleSize) >= requestedWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}