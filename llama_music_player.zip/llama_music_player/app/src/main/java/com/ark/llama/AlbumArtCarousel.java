package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a viewport
 * one slot wide. The strip's middle slot is aligned to the viewport at
 * rest; the outer slots are clipped by the container. When the user
 * drags horizontally on the album art, the strip follows the finger,
 * revealing the previous or next song's art. On release, the strip
 * either springs back to the middle slot or animates to a neighbour
 * slot, and the slot window is reassigned so the newly-visible art
 * becomes the new current.</p>
 *
 * <h3>Ownership</h3>
 * <p>The carousel owns the strip, the three {@link ImageView}s, the
 * rolling window of decoded bitmaps, and the async loading of the
 * previous and next neighbours. The activity that constructs the
 * carousel owns the viewport {@link FrameLayout} and supplies it to
 * {@link #attach()}. The activity also supplies the {@link LruCache}
 * the carousel reads from and writes to, and the {@link ExecutorService}
 * the carousel schedules neighbour decodes on. Both are shared with the
 * activity's other album-art work, so cached bitmaps are reused across
 * the carousel and any other consumer.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn:</p>
 * <ul>
 *   <li><b>Previous</b> — the song at {@code currentIndex - 1}, or empty
 *       when the current song is the first in the playlist.</li>
 *   <li><b>Current</b> — the song at {@code currentIndex}.</li>
 *   <li><b>Next</b> — the song at {@code currentIndex + 1}, or empty
 *       when the current song is the last in the playlist.</li>
 * </ul>
 *
 * <p>The strip is {@code 3W × W} where {@code W} is the viewport width.
 * The strip's {@code translationX} is {@code -W} at rest, so the
 * viewport shows the middle slot. During a horizontal swipe,
 * {@code translationX} is {@code -W + dx} where {@code dx} is the
 * horizontal finger displacement.</p>
 *
 * <h3>Commit and Spring-Back</h3>
 * <p>On release, the swipe either commits or springs back, based on the
 * absolute horizontal displacement relative to {@link
 * #COMMIT_THRESHOLD_FRACTION} of the viewport width. A committed swipe
 * animates the strip to the fully-revealed neighbour slot over
 * {@link #SWIPE_ANIMATION_MS} milliseconds and then reassigns the slot
 * window so the revealed art becomes the new current. A spring-back
 * animates the strip to {@code -W} over the same duration and leaves the
 * window unchanged.</p>
 *
 * <h3>Neighbour Loading</h3>
 * <p>Whenever the window changes — a new playlist, a new current song,
 * or a committed swipe — the carousel schedules loads for the previous
 * and next neighbours. Each load consults the shared {@link LruCache}
 * first; a miss schedules a decode on the supplied {@link
 * ExecutorService}. Loads are tagged with a generation counter, and a
 * result that arrives after the generation has advanced is discarded.
 * The window therefore converges on the correct art without flicker
 * under rapid user switching.</p>
 *
 * <h3>Coordination with the Activity's Fade</h3>
 * <p>When the current song changes as the result of a swipe, the
 * carousel has already shown the incoming art during the drag. The
 * activity's own fade animation would be a redundant second animation
 * on the same art. The activity calls {@link #suppressNextFade()} before
 * triggering the song change; the carousel consumes the flag on the
 * next current-art install and skips its fade. The flag is cleared
 * immediately after the install.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. Neighbour decoding
 * runs on the supplied executor; results are dispatched to the main
 * thread before touching any view or field.</p>
 *
 * <h3>Invariants</h3>
 * <ul>
 *   <li>I1 — {@link #mStrip} is a child of the viewport if and only if
 *       {@link #attach()} has run.</li>
 *   <li>I2 — The three slots are children of {@link #mStrip} in the
 *       fixed order prev, current, next. Reassignments swap the
 *       bitmaps, never the views.</li>
 *   <li>I3 — When the strip is at rest, {@code translationX} equals
 *       {@code -mSlotWidth}.</li>
 *   <li>I4 — {@link #mPrevPath}, {@link #mCurrentPath}, and
 *       {@link #mNextPath} always reflect the paths that would be
 *       displayed if the strip were frozen at this instant. Null paths
 *       mean the corresponding slot is empty.</li>
 *   <li>I5 — A decode result is installed only when its generation
 *       matches {@link #mGeneration}. A result whose generation is
 *       stale is discarded.</li>
 * </ul>
 *
 * @see MusicPlayer
 * @see OverlayManager
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class AlbumArtCarousel {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "AlbumArtCarousel";

    /**
     * Maximum dimension of a slot bitmap, in pixels.
     *
     * <p>Slot bitmaps are downsampled to this size when decoded. The
     * shared {@link LruCache} can hold higher-resolution source bitmaps
     * for other consumers; the carousel takes a copy at this size so the
     * three slots stay cheap to keep resident.</p>
     */
    private static final int SLOT_BITMAP_SIZE_PX = 512;

    /**
     * Duration of the commit and spring-back animations, in
     * milliseconds.
     *
     * <p>Applies to both outcomes so the finger-lift motion feels
     * consistent whether the swipe commits or not.</p>
     */
    private static final long SWIPE_ANIMATION_MS = 250L;

    /**
     * Fraction of the slot width the finger must travel before the
     * swipe commits.
     *
     * <p>Below the threshold the strip springs back to the current
     * song. At or above the threshold the strip completes to the
     * neighbouring song.</p>
     */
    private static final float COMMIT_THRESHOLD_FRACTION = 0.50f;

    // ============================================================================
    // Collaborators
    // ============================================================================

    /** Context used for resource and density lookup. */
    @NonNull
    private final Context mContext;

    /** Viewport into which the strip is attached. */
    @NonNull
    private final FrameLayout mContainer;

    /** Shared album-art cache. */
    @NonNull
    private final LruCache<String, Bitmap> mCache;

    /** Executor for neighbour decodes. */
    @NonNull
    private final ExecutorService mExecutor;

    // ============================================================================
    // View State
    // ============================================================================

    /** The three-slot strip. Null before {@link #attach()}. */
    @Nullable
    private LinearLayout mStrip;

    /** Left slot: previous song. Null before {@link #attach()}. */
    @Nullable
    private ImageView mPrevView;

    /** Middle slot: current song. Null before {@link #attach()}. */
    @Nullable
    private ImageView mCurrentView;

    /** Right slot: next song. Null before {@link #attach()}. */
    @Nullable
    private ImageView mNextView;

    /** Width of one slot in pixels, or 0 before the first layout. */
    private int mSlotWidth = 0;

    /** Height of one slot in pixels, or 0 before the first layout. */
    private int mSlotHeight = 0;

    // ============================================================================
    // Slot Content
    // ============================================================================

    /** Bitmap currently shown in the left slot, or null. */
    @Nullable
    private Bitmap mPrevBitmap = null;

    /** Bitmap currently shown in the middle slot, or null. */
    @Nullable
    private Bitmap mCurrentBitmap = null;

    /** Bitmap currently shown in the right slot, or null. */
    @Nullable
    private Bitmap mNextBitmap = null;

    /** Path of the previous neighbour, or null when the slot is empty. */
    @Nullable
    private String mPrevPath = null;

    /** Path of the current song, or null when nothing is loaded. */
    @Nullable
    private String mCurrentPath = null;

    /** Path of the next neighbour, or null when the slot is empty. */
    @Nullable
    private String mNextPath = null;

    // ============================================================================
    // Playlist Window
    // ============================================================================

    /** Playlist currently driving the carousel. Never null; empty by default. */
    @NonNull
    private List<Song> mPlaylist = Collections.emptyList();

    /** Index of the current song within {@link #mPlaylist}, or -1. */
    private int mCurrentIndex = -1;

    // ============================================================================
    // Swipe State
    // ============================================================================

    /** True while a horizontal swipe is being tracked. */
    private boolean mSwipeActive = false;

    /** True while the commit or spring-back animation is running. */
    private boolean mAnimating = false;

    /** True when the next current-art install should skip its fade. */
    private boolean mSuppressNextFade = false;

    // ============================================================================
    // Generation and Async Loading
    // ============================================================================

    /** Monotonic counter incremented on every window change. */
    @NonNull
    private final AtomicLong mGeneration = new AtomicLong(0L);

    /** Currently pending neighbour load task, or null. */
    @Nullable
    private Future<?> mNeighbourLoadFuture = null;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a carousel bound to the given viewport, cache, and
     * executor.
     *
     * <p>The views are not built until {@link #attach()} is called. The
     * constructor only records the collaborators.</p>
     *
     * @param context Context used for resource and density lookup
     * @param container Viewport the strip is attached to
     * @param cache Shared album-art cache
     * @param executor Executor for neighbour decodes
     */
    public AlbumArtCarousel(@NonNull Context context,
                            @NonNull FrameLayout container,
                            @NonNull LruCache<String, Bitmap> cache,
                            @NonNull ExecutorService executor) {
        mContext = context;
        mContainer = container;
        mCache = cache;
        mExecutor = executor;
    }

    // ============================================================================
    // Attachment
    // ============================================================================

    /**
     * Builds the strip and attaches it inside the viewport.
     *
     * <p>Idempotent. The three slots are constructed once and reused for
     * the lifetime of the carousel; the window reassigns their bitmaps
     * rather than rebuilding the views.</p>
     *
     * <p>The first slot layout runs after the next frame, because the
     * viewport's width is not known during {@code onCreate}. Until then
     * the strip is invisible.</p>
     */
    public void attach() {
        if (mStrip != null) {
            return;
        }

        LinearLayout strip = new LinearLayout(mContext);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setClickable(false);
        strip.setFocusable(false);
        strip.setVisibility(View.INVISIBLE);

        ImageView prevView = createSlot();
        ImageView currentView = createSlot();
        ImageView nextView = createSlot();

        strip.addView(prevView);
        strip.addView(currentView);
        strip.addView(nextView);

        mContainer.addView(strip);
        mContainer.setClipChildren(true);

        mStrip = strip;
        mPrevView = prevView;
        mCurrentView = currentView;
        mNextView = nextView;

        mContainer.post(new Runnable() {
            @Override
            public void run() {
                if (mStrip == null) {
                    return;
                }
                layoutSlots();
                mStrip.setVisibility(View.VISIBLE);
                loadWindow();
            }
        });
    }

    /**
     * Creates one slot ImageView with the carousel's standard
     * configuration.
     *
     * @return A newly-created slot ImageView
     */
    @NonNull
    private ImageView createSlot() {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setClickable(false);
        view.setFocusable(false);
        view.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /**
     * Recomputes the slot dimensions from the viewport's current size
     * and re-lays out the strip.
     *
     * <p>Called by the activity after {@code applyAlbumArtSize()} has
     * resized the viewport, and by {@link #attach()} once the viewport
     * has been laid out. Snaps the strip to rest.</p>
     */
    public void onContainerResized() {
        if (mStrip == null) {
            return;
        }
        mContainer.post(new Runnable() {
            @Override
            public void run() {
                if (mStrip == null) {
                    return;
                }
                layoutSlots();
            }
        });
    }

    /**
     * Resizes each slot and the strip to match the viewport's current
     * width, then snaps the strip to rest.
     *
     * <p>Runs on the main thread. When the viewport has zero width — for
     * example, before the first layout or while the album art is hidden
     * — the method returns without touching the strip.</p>
     */
    private void layoutSlots() {
        if (mStrip == null || mCurrentView == null || mPrevView == null
                || mNextView == null) {
            return;
        }
        final int width = mContainer.getWidth();
        final int height = mContainer.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }

        mSlotWidth = width;
        mSlotHeight = height;

        for (ImageView slot : new ImageView[] {mPrevView, mCurrentView, mNextView}) {
            LinearLayout.LayoutParams params =
                (LinearLayout.LayoutParams) slot.getLayoutParams();
            if (params == null) {
                params = new LinearLayout.LayoutParams(width, height);
            } else {
                params.width = width;
                params.height = height;
            }
            slot.setLayoutParams(params);
        }

        ViewGroup.LayoutParams stripParams = mStrip.getLayoutParams();
        if (stripParams == null) {
            stripParams = new FrameLayout.LayoutParams(width * 3, height);
        } else {
            stripParams.width = width * 3;
            stripParams.height = height;
        }
        mStrip.setLayoutParams(stripParams);

        snapToRest();
    }

    /**
     * Sets the strip's {@code translationX} to {@code -mSlotWidth},
     * bringing the middle slot into the viewport.
     */
    private void snapToRest() {
        if (mStrip != null && mSlotWidth > 0) {
            mStrip.setTranslationX(-mSlotWidth);
        }
    }

    // ============================================================================
    // Playlist Window
    // ============================================================================

    /**
     * Installs a new playlist window and current index.
     *
     * <p>Any in-flight neighbour load is invalidated, the window is
     * rebuilt from the new playlist and index, and fresh neighbour loads
     * are scheduled.</p>
     *
     * @param playlist The full playlist in its current sort order, or
     *        null to clear
     * @param currentIndex Index of the current song, or -1 when none
     */
    public void setPlaylist(@Nullable List<Song> playlist, int currentIndex) {
        mGeneration.incrementAndGet();

        if (playlist == null || playlist.isEmpty()) {
            mPlaylist = Collections.emptyList();
            mCurrentIndex = -1;
            mPrevPath = null;
            mCurrentPath = null;
            mNextPath = null;
            installSlots(null, null, null);
            return;
        }

        mPlaylist = new ArrayList<>(playlist);
        mCurrentIndex = Math.max(0, Math.min(currentIndex, mPlaylist.size() - 1));

        final Song currentSong = mPlaylist.get(mCurrentIndex);
        mCurrentPath = (currentSong != null) ? currentSong.getPath() : null;

        if (mCurrentIndex > 0) {
            final Song prevSong = mPlaylist.get(mCurrentIndex - 1);
            mPrevPath = (prevSong != null) ? prevSong.getPath() : null;
        } else {
            mPrevPath = null;
        }

        if (mCurrentIndex + 1 < mPlaylist.size()) {
            final Song nextSong = mPlaylist.get(mCurrentIndex + 1);
            mNextPath = (nextSong != null) ? nextSong.getPath() : null;
        } else {
            mNextPath = null;
        }

        snapToRest();
        loadWindow();
    }

    /**
     * Returns the path currently displayed in the middle slot, or null
     * when the window is empty.
     *
     * @return The current slot's path, or null
     */
    @Nullable
    public String getCurrentPath() {
        return mCurrentPath;
    }

    // ============================================================================
    // External Art Handoff
    // ============================================================================

    /**
     * Installs a decoded bitmap into the middle slot when the path
     * matches the current song.
     *
     * <p>Provided so callers that have already decoded the current song's
     * art — the cold-start preload is the case in this app — can hand
     * the bitmap to the carousel directly instead of waiting for the
     * carousel's own decode. When the path does not match the current
     * song the call is a no-op.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     * @param animate True to fade the bitmap in, false to set it
     *        directly
     */
    public void onCurrentArtReady(@NonNull String path,
                                  @NonNull Bitmap bitmap,
                                  boolean animate) {
        if (!path.equals(mCurrentPath)) {
            return;
        }
        mCache.put(path, bitmap);
        mCurrentBitmap = bitmap;

        final boolean skipFade = mSuppressNextFade;
        mSuppressNextFade = false;

        if (mCurrentView == null) {
            return;
        }
        if (skipFade || !animate) {
            mCurrentView.setAlpha(1f);
            mCurrentView.setImageBitmap(bitmap);
        } else {
            mCurrentView.setImageBitmap(bitmap);
            mCurrentView.setAlpha(0f);
            mCurrentView.animate()
                .alpha(1f)
                .setDuration(SWIPE_ANIMATION_MS * 2)
                .setListener(null)
                .start();
        }
    }

    /**
     * Installs a placeholder bitmap into the middle slot.
     *
     * <p>Used by the activity when no current song is playing and the
     * placeholder must fill the viewport. The placeholder is a
     * carousel-level replacement for the current slot only; the
     * neighbours are unaffected.</p>
     *
     * @param placeholder Themed placeholder bitmap, or null to clear
     */
    public void setPlaceholder(@Nullable Bitmap placeholder) {
        if (mCurrentView == null) {
            return;
        }
        mCurrentBitmap = placeholder;
        if (placeholder == null) {
            mCurrentView.setImageDrawable(null);
        } else {
            mCurrentView.setAlpha(1f);
            mCurrentView.setImageBitmap(placeholder);
        }
    }

    /**
     * Marks the next current-art install to skip its fade.
     *
     * <p>Called by the activity when a song change was triggered by a
     * swipe. The carousel has already shown the incoming art during the
     * drag, so a fade on top of that would be a redundant second
     * animation. The flag is consumed on the next install and cleared
     * immediately.</p>
     */
    public void suppressNextFade() {
        mSuppressNextFade = true;
    }

    /**
     * Removes every slot's content and clears the current path.
     *
     * <p>Used on library reset. Does not detach the views; the strip is
     * reused when a new playlist arrives.</p>
     */
    public void clear() {
        mGeneration.incrementAndGet();
        if (mNeighbourLoadFuture != null) {
            mNeighbourLoadFuture.cancel(true);
            mNeighbourLoadFuture = null;
        }
        mPlaylist = Collections.emptyList();
        mCurrentIndex = -1;
        mPrevPath = null;
        mCurrentPath = null;
        mNextPath = null;
        installSlots(null, null, null);
        snapToRest();
    }

    /**
     * Clears whichever slot matches the given path.
     *
     * <p>Used when a metadata edit changes or removes a song's album
     * art. The next window load will re-decode the slot from the file.
     * When the path does not match any slot the call is a no-op.</p>
     *
     * @param path Path to invalidate
     */
    public void invalidatePath(@NonNull String path) {
        if (path.equals(mCurrentPath)) {
            mCurrentBitmap = null;
            if (mCurrentView != null) {
                mCurrentView.setImageDrawable(null);
            }
        }
        if (path.equals(mPrevPath)) {
            mPrevBitmap = null;
            if (mPrevView != null) {
                mPrevView.setImageDrawable(null);
            }
        }
        if (path.equals(mNextPath)) {
            mNextBitmap = null;
            if (mNextView != null) {
                mNextView.setImageDrawable(null);
            }
        }
        mCache.remove(path);
        loadWindow();
    }

    // ============================================================================
    // Swipe
    // ============================================================================

    /**
     * Marks the start of a horizontal swipe on the album art.
     *
     * <p>Idempotent. Called by the activity when the gesture classifier
     * locks the touch sequence into a carousel swipe.</p>
     */
    public void beginSwipe() {
        if (mAnimating) {
            return;
        }
        mSwipeActive = true;
    }

    /**
     * Updates the strip's position from the finger's horizontal
     * displacement.
     *
     * <p>Runs on the main thread. When no swipe is active or the strip
     * has not been laid out the call is a no-op. The strip is clamped so
     * the finger cannot drag the strip past a neighbour slot.</p>
     *
     * @param dx Horizontal displacement in pixels, positive to the right
     */
    public void updateSwipe(float dx) {
        if (!mSwipeActive || mAnimating || mStrip == null || mSlotWidth <= 0) {
            return;
        }
        final float clamped = Math.max(-mSlotWidth, Math.min(mSlotWidth, dx));
        mStrip.setTranslationX(-mSlotWidth + clamped);
    }

    /**
     * Ends the swipe and either commits to the neighbour or springs
     * back, animating over {@link #SWIPE_ANIMATION_MS} milliseconds.
     *
     * <p>Runs on the main thread. Returns true when the swipe committed,
     * in which case the caller is responsible for triggering the
     * corresponding song change on the service.</p>
     *
     * @param dx Total horizontal displacement in pixels, positive to
     *        the right
     * @return True when the swipe committed, false when it sprang back
     */
    public boolean endSwipe(float dx) {
        if (!mSwipeActive || mStrip == null || mSlotWidth <= 0) {
            mSwipeActive = false;
            return false;
        }
        mSwipeActive = false;

        final float threshold = mSlotWidth * COMMIT_THRESHOLD_FRACTION;
        final float clamped = Math.max(-mSlotWidth, Math.min(mSlotWidth, dx));

        if (clamped <= -threshold) {
            animateStripTo(-mSlotWidth * 2f, true);
            return true;
        }
        if (clamped >= threshold) {
            animateStripTo(0f, false);
            return true;
        }

        animateStripTo(-mSlotWidth, false);
        return false;
    }

    /**
     * Animates the strip to the given {@code translationX} over
     * {@link #SWIPE_ANIMATION_MS} milliseconds and, when the animation
     * ends, reassigns the window if the swipe committed.
     *
     * <p>The strip is snapped back to rest at the end of the animation
     * and the slot bitmaps are reassigned so the newly-visible art is
     * still on screen; the user sees only the slide, not the reassign.
     * The caller's song-change request is expected to arrive separately
     * and will find the window already in the right state.</p>
     *
     * @param targetTranslationX The final strip translation
     * @param forward True for a forward (next) commit, false for a
     *        backward (previous) commit or a spring-back
     */
    private void animateStripTo(float targetTranslationX, final boolean forward) {
        if (mStrip == null) {
            return;
        }
        mAnimating = true;

        final boolean isSpringBack = (targetTranslationX == -mSlotWidth);

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(SWIPE_ANIMATION_MS)
            .setListener(null)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    mAnimating = false;
                    if (isSpringBack) {
                        snapToRest();
                        return;
                    }
                    if (forward) {
                        reassignWindowForward();
                    } else {
                        reassignWindowBackward();
                    }
                    snapToRest();
                }
            })
            .start();
    }

    /**
     * Reassigns the window after a forward commit: the previous bitmap
     * is dropped, the current becomes the previous, the next becomes the
     * current, and a fresh neighbour load is scheduled for the new next
     * slot.
     *
     * <p>Called from the commit animation's end action, on the main
     * thread. The slot ImageViews are updated with the reassigned
     * bitmaps before the next frame renders, so the strip's snap to rest
     * is invisible.</p>
     */
    private void reassignWindowForward() {
        if (mPlaylist.isEmpty()) {
            return;
        }

        mGeneration.incrementAndGet();
        if (mNeighbourLoadFuture != null) {
            mNeighbourLoadFuture.cancel(true);
            mNeighbourLoadFuture = null;
        }

        mPrevBitmap = mCurrentBitmap;
        mPrevPath = mCurrentPath;
        mCurrentBitmap = mNextBitmap;
        mCurrentPath = mNextPath;

        mCurrentIndex++;
        if (mCurrentIndex < 0 || mCurrentIndex >= mPlaylist.size()) {
            mCurrentIndex = mPlaylist.size() - 1;
        }

        if (mCurrentIndex + 1 < mPlaylist.size()) {
            final Song newNext = mPlaylist.get(mCurrentIndex + 1);
            mNextPath = (newNext != null) ? newNext.getPath() : null;
        } else {
            mNextPath = null;
        }
        mNextBitmap = null;

        installSlots(mPrevBitmap, mCurrentBitmap, null);
        loadWindow();
    }

    /**
     * Reassigns the window after a backward commit: the next bitmap is
     * dropped, the current becomes the next, the previous becomes the
     * current, and a fresh neighbour load is scheduled for the new
     * previous slot.
     *
     * <p>Called from the commit animation's end action, on the main
     * thread. The slot ImageViews are updated with the reassigned
     * bitmaps before the next frame renders, so the strip's snap to rest
     * is invisible.</p>
     */
    private void reassignWindowBackward() {
        if (mPlaylist.isEmpty()) {
            return;
        }

        mGeneration.incrementAndGet();
        if (mNeighbourLoadFuture != null) {
            mNeighbourLoadFuture.cancel(true);
            mNeighbourLoadFuture = null;
        }

        mNextBitmap = mCurrentBitmap;
        mNextPath = mCurrentPath;
        mCurrentBitmap = mPrevBitmap;
        mCurrentPath = mPrevPath;

        mCurrentIndex--;
        if (mCurrentIndex < 0) {
            mCurrentIndex = 0;
        }

        if (mCurrentIndex > 0) {
            final Song newPrev = mPlaylist.get(mCurrentIndex - 1);
            mPrevPath = (newPrev != null) ? newPrev.getPath() : null;
        } else {
            mPrevPath = null;
        }
        mPrevBitmap = null;

        installSlots(null, mCurrentBitmap, mNextBitmap);
        loadWindow();
    }

    // ============================================================================
    // Window Loading
    // ============================================================================

    /**
     * Schedules neighbour loads for the current window and installs any
     * bitmaps already in the cache.
     *
     * <p>Runs on the main thread. Increments the generation and cancels
     * any in-flight load before scheduling the new one, so a late
     * result from a previous window does not clobber the current one.</p>
     */
    private void loadWindow() {
        final long generation = mGeneration.get();

        if (mNeighbourLoadFuture != null) {
            mNeighbourLoadFuture.cancel(true);
            mNeighbourLoadFuture = null;
        }

        installSlots(mPrevBitmap, mCurrentBitmap, mNextBitmap);

        final ArrayList<String> pathsToLoad = new ArrayList<>();
        if (mPrevPath != null && mPrevBitmap == null) {
            final Bitmap cached = mCache.get(mPrevPath);
            if (cached != null) {
                mPrevBitmap = cached;
            } else {
                pathsToLoad.add(mPrevPath);
            }
        }
        if (mCurrentPath != null && mCurrentBitmap == null) {
            final Bitmap cached = mCache.get(mCurrentPath);
            if (cached != null) {
                mCurrentBitmap = cached;
            } else {
                pathsToLoad.add(mCurrentPath);
            }
        }
        if (mNextPath != null && mNextBitmap == null) {
            final Bitmap cached = mCache.get(mNextPath);
            if (cached != null) {
                mNextBitmap = cached;
            } else {
                pathsToLoad.add(mNextPath);
            }
        }

        installSlots(mPrevBitmap, mCurrentBitmap, mNextBitmap);

        if (pathsToLoad.isEmpty()) {
            return;
        }

        mNeighbourLoadFuture = mExecutor.submit(new Runnable() {
            @Override
            public void run() {
                for (String path : pathsToLoad) {
                    if (Thread.currentThread().isInterrupted()) {
                        return;
                    }
                    if (mGeneration.get() != generation) {
                        return;
                    }
                    final Bitmap decoded = decodeSlotBitmap(path);
                    if (decoded == null) {
                        continue;
                    }
                    if (mGeneration.get() != generation) {
                        return;
                    }
                    mCache.put(path, decoded);

                    final Bitmap finalDecoded = decoded;
                    mContainer.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mGeneration.get() != generation) {
                                return;
                            }
                            installDecodedPath(path, finalDecoded);
                        }
                    });
                }
            }
        });
    }

    /**
     * Installs the given decoded bitmap into whichever slot currently
     * holds its path, if any.
     *
     * <p>Runs on the main thread. A path that no slot holds is silently
     * dropped, which is the correct behaviour when a rapid sequence of
     * swipes has moved the window on.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     */
    private void installDecodedPath(@NonNull String path, @NonNull Bitmap bitmap) {
        if (path.equals(mPrevPath)) {
            mPrevBitmap = bitmap;
            if (mPrevView != null) {
                mPrevView.setImageBitmap(bitmap);
            }
        }
        if (path.equals(mCurrentPath)) {
            onCurrentArtReady(path, bitmap, true);
        }
        if (path.equals(mNextPath)) {
            mNextBitmap = bitmap;
            if (mNextView != null) {
                mNextView.setImageBitmap(bitmap);
            }
        }
    }

    /**
     * Decodes the art for the given path at slot resolution.
     *
     * <p>Runs on the executor. The {@link MediaMetadataRetriever} is
     * released in every exit path. The returned bitmap is a copy scaled
     * to at most {@link #SLOT_BITMAP_SIZE_PX} on the long side; the
     * shared cache can hold larger source bitmaps.</p>
     *
     * @param path Path of the song whose art should be decoded
     * @return The decoded bitmap, or null on failure
     */
    @Nullable
    private Bitmap decodeSlotBitmap(@NonNull String path) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(path);
            final byte[] bytes = retriever.getEmbeddedPicture();
            if (bytes == null || bytes.length == 0) {
                return null;
            }
            final BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            final int sampleSize = calculateSampleSize(
                bounds, SLOT_BITMAP_SIZE_PX, SLOT_BITMAP_SIZE_PX);
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to decode slot art for " + path, exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits release.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above the
     * requested bounds.
     *
     * @param options Options whose bounds have already been decoded
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateSampleSize(@NonNull BitmapFactory.Options options,
                                    int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Installs the given bitmaps into the three slot ImageViews.
     *
     * <p>Runs on the main thread. A null bitmap leaves the corresponding
     * slot empty. The current slot's alpha is reset to 1 so a
     * subsequent fade can run from zero when the art actually
     * arrives.</p>
     *
     * @param prev Bitmap for the left slot, or null
     * @param current Bitmap for the middle slot, or null
     * @param next Bitmap for the right slot, or null
     */
    private void installSlots(@Nullable Bitmap prev,
                              @Nullable Bitmap current,
                              @Nullable Bitmap next) {
        if (mPrevView != null) {
            mPrevView.setImageBitmap(prev);
        }
        if (mCurrentView != null) {
            mCurrentView.setImageBitmap(current);
            mCurrentView.setAlpha(1f);
        }
        if (mNextView != null) {
            mNextView.setImageBitmap(next);
        }
    }
}