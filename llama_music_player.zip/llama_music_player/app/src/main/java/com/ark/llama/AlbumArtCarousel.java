package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a viewport
 * one slot wide. The strip's middle slot is aligned to the viewport at
 * rest; the outer slots are clipped by the container. When the user
 * drags horizontally on the album art, the strip follows the finger,
 * revealing the previous or next song's art. On release the strip
 * either springs back to the middle slot or animates to a neighbour
 * slot and then asks {@link MusicPlayer} to request the corresponding
 * song change from {@link MusicService}. The new window arrives through
 * the standard playback broadcast and is adopted; the snap that follows
 * a successful commit is pixel-identical because the art is keyed by
 * path, not by slot.</p>
 *
 * <p>The same slide is driven from the transport buttons. Pressing
 * Next or Previous calls {@link #animateToNext()} or
 * {@link #animateToPrevious()} before the service request is
 * dispatched, so the strip slides while the audio transitions and
 * settles on the incoming art when the service's window arrives. The
 * carousel does not dispatch the service request itself in this case;
 * the caller does. The visual outcome is identical to a committed
 * swipe.</p>
 *
 * <h3>Authority</h3>
 * <p>The window the carousel displays is a value published by
 * {@link MusicService}. The carousel computes neither the window nor
 * its neighbours; it renders the three paths the service names and
 * consults the shared {@link LruCache} for each path's art. The
 * carousel holds no playlist, no index, and no bitmap as primary state.
 * Its entire state is the last window it was given, the generation of
 * that window, the current commit or restart or reveal state, the
 * pending confirmed window during a commit animation, and the shared
 * placeholder bitmap.</p>
 *
 * <p>Every path through the service produces an {@code UPDATE_PLAYER}
 * broadcast carrying a {@link PlaybackWindow}, and every window is
 * adopted by the same {@link #setWindow(PlaybackWindow)} method. There
 * is no second mutation path that could disagree with the service.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn:</p>
 * <ul>
 *   <li><b>Previous</b> — the path the service names as the previous
 *       neighbour, or empty when none.</li>
 *   <li><b>Current</b> — the path the service names as the current
 *       song.</li>
 *   <li><b>Next</b> — the path the service names as the next neighbour,
 *       or empty when none.</li>
 * </ul>
 *
 * <p>On a single-song playlist, or a shuffle re-pick that cannot avoid
 * the current index, the service names the current song as its own
 * neighbour — the request wraps to the same index and the service
 * restarts the song. The carousel renders the same art in the outer
 * slots, and the below-threshold nudge acknowledges the restart by
 * sliding toward that duplicate and returning.</p>
 *
 * <h3>Transitions</h3>
 * <p>Every song transition, whatever its cause, runs one of three
 * animations, plus a no-op when nothing changed:</p>
 * <ul>
 *   <li><b>Commit.</b> The incoming current path is one of the
 *       previous window's neighbours and differs from the current
 *       song. The strip slides a full slot width toward that neighbour
 *       and settles at rest on the incoming window. Reached by a
 *       committed swipe, by a transport button press through
 *       {@link #animateToNext()} or {@link #animateToPrevious()}, and
 *       by an automatic song change whose incoming window is a
 *       neighbour.</li>
 *   <li><b>Nudge.</b> The incoming current path is unchanged and the
 *       generation advanced — a repeat-one restart, or a wrap that
 *       lands on the current index on a single-song playlist. The
 *       strip slides a fraction of the middle zone toward the
 *       neighbour the window advertises, then returns to rest. The
 *       user sees the neighbour nudge into the viewport and
 *       retreat.</li>
 *   <li><b>Reveal.</b> The incoming current path is neither neighbour
 *       and differs from the current song. The reveal is a staggered
 *       cross-fade: the outgoing art fades out over the first portion
 *       of the transition with an accelerating curve, and the
 *       incoming art fades in over the rest with a decelerating curve
 *       and a subtle scale-up. There is no midpoint and no blank
 *       frame.</li>
 * </ul>
 *
 * <p>A window that re-publishes the same three paths with the same
 * generation — a pause, a resume, a seek, a metadata poke, a position
 * checkpoint — is adopted at rest with no animation.</p>
 *
 * <h3>Motion</h3>
 * <p>Every slide uses a decelerating interpolator over the same
 * {@link #SWIPE_ANIMATION_MS} duration. The strip leaves the finger or
 * the button immediately and settles into rest, which is what a slide
 * that acknowledges a button press should feel like. The reveal's two
 * legs use the pairing an entering-and-leaving pair calls for: an
 * accelerate curve on the outgoing art so it clears quickly, and a
 * decelerate curve on the incoming art so it settles gently. The
 * below-threshold nudge's outward leg runs for a duration proportional
 * to the distance it travels, so the strip's velocity matches a full
 * commit's.</p>
 *
 * <h3>The Commit Turn</h3>
 * <p>Every animation ends in a single main-thread turn: the strip's
 * snap to rest, the render of the incoming window, the removal of the
 * reveal overlay when one is running, and the
 * {@link #postOnSettle(Runnable)} queue are all flushed together.
 * Because view mutations are batched by the framework into the next
 * layout pass, the strip's new bitmaps and any work the caller
 * scheduled through {@link #postOnSettle(Runnable)} — the title, the
 * artist, the seek bar's range, the transport glyph, the notification,
 * the media session — reach their surfaces from one turn. The art does
 * not land before the text; both land together, on the frame the
 * transition is meant to be seen on.</p>
 *
 * <p>{@link #setWindow(PlaybackWindow)} reports whether the commit
 * landed synchronously. A return of {@code true} means the window was
 * adopted with no animation running afterwards; the caller may run its
 * remaining commit work in the current turn. A return of {@code false}
 * means an animation is running; the caller registers that work through
 * {@link #postOnSettle(Runnable)}, which runs on the frame the
 * animation ends. The two branches converge on the same commit turn,
 * so a caller writes one commit runnable and dispatches it through this
 * contract without inspecting the carousel's internal state.</p>
 *
 * <h3>Asynchronous Loading</h3>
 * <p>Whenever a window is adopted, {@link #render()} schedules a decode
 * for every path in the window whose art is not in the cache and not
 * already being decoded. Loads are deduplicated by path. When a decode
 * resolves, the bitmap is placed in the shared cache and the carousel
 * re-renders; a decode for a path that has since left the window is
 * placed in the cache and dropped. A decode that resolves while a
 * reveal is running and whose path is the one the overlay is
 * presenting is also installed into the overlay in place, so the
 * reveal continues with the resolved art rather than the placeholder
 * that was shown while the decode was in flight.</p>
 *
 * <p>Callers that have already decoded a song's art — the cold-start
 * preload, the metadata-editor path, and the incoming-file pre-decode
 * in {@link MusicPlayer} — hand the bitmap to the carousel through
 * {@link #onArtReady(String, Bitmap)}. The handoff is a cache write and
 * a render; the decode path and the identity rule are unchanged.</p>
 *
 * <h3>Threading</h3>
 * <p>Every public method runs on the main thread. Decoding runs on the
 * supplied executor; results are dispatched to the main thread before
 * touching any view or field.</p>
 *
 * @see MusicService
 * @see MusicPlayer
 * @see PlaybackWindow
 *
 * @author Richard Korbla Adzido
 * @version 1.2.5
 * @since 1.2.0
 */
public final class AlbumArtCarousel {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "AlbumArtCarousel";

    /**
     * Maximum dimension of a slot bitmap, in pixels.
     *
     * <p>Slot bitmaps are downsampled to this size when decoded. The
     * shared {@link LruCache} can hold higher-resolution source bitmaps
     * for other consumers; the carousel takes a copy at this size so
     * the three slots stay cheap to keep resident.</p>
     */
    private static final int SLOT_BITMAP_SIZE_PX = 512;

    /**
     * Duration of a full-slot commit, spring-back, or below-threshold
     * return leg, in milliseconds.
     *
     * <p>Used by three animations: the outward leg of a commit, the
     * return leg of a spring-back or refusal, and the return leg of the
     * below-threshold animation. The below-threshold animation's
     * outward leg uses a proportionally shorter duration, computed at
     * run time so the strip's velocity matches a full commit's. The
     * reveal's cross-fade uses {@link #REVEAL_DURATION_MS} instead,
     * because the reveal is not a spatial movement and does not share
     * the slide's velocity profile.</p>
     */
    private static final long SWIPE_ANIMATION_MS = 500L;

    /**
     * Duration of the one-way reveal used when the current song changed
     * to a path that was not one of the previous window's neighbours.
     *
     * <p>The reveal is a staggered cross-fade, not a spatial movement.
     * The staggered timing divides this duration into an outgoing leg
     * and an incoming leg, each with its own curve. The value stays
     * within the Material long band for complex choreography: enough
     * room for the two legs to overlap in the middle third, short
     * enough that the transition does not read as a wait.</p>
     */
    private static final long REVEAL_DURATION_MS = 600L;

    /**
     * Fraction of {@link #REVEAL_DURATION_MS} the outgoing art spends
     * fading out.
     *
     * <p>The outgoing art reaches zero opacity at this fraction of the
     * total duration, before the incoming art reaches full opacity. The
     * two tracks overlap in the middle third, which is where the
     * cross-fade reads as a dissolve rather than a collision. The
     * outgoing leg is the shorter of the two: a leaving element clears
     * quickly so the incoming element has room to arrive.</p>
     */
    private static final float REVEAL_OUTGOING_FRACTION = 0.45f;

    /**
     * Scale the incoming art starts at and grows from during the
     * reveal.
     *
     * <p>A small scale-up from this value to 1.0 accompanies the
     * fade-in. The difference is deliberately subtle — enough to give
     * the incoming art a sense of depth arriving over the outgoing art,
     * not enough to read as a zoom. Combined with the decelerate curve,
     * the incoming art decelerates into its resting size as it reaches
     * full opacity.</p>
     */
    private static final float REVEAL_INCOMING_START_SCALE = 0.96f;

    /**
     * Fraction of {@link #REVEAL_DURATION_MS} the incoming leg's start
     * is advanced into the outgoing leg.
     *
     * <p>The incoming leg begins before the outgoing leg has finished.
     * The overlap is deliberate: a hard handoff where the outgoing
     * reaches zero before the incoming starts leaves one frame where
     * the viewport is empty. The overlap keeps at least one image on
     * screen for every frame of the transition, and because the
     * incoming curve is decelerating from zero, the overlap region is
     * dim enough that the two images do not read as a muddy
     * double-exposure.</p>
     */
    private static final float REVEAL_OVERLAP_FRACTION = 0.15f;

    /**
     * Fraction of the middle zone the finger must travel before the
     * swipe commits.
     *
     * <p>The threshold is applied to the middle zone — the slot width
     * minus the two volume edge zones — not to the slot width. A
     * horizontal swipe is the carousel's gesture only in the middle
     * zone; the edge zones are the volume gesture's.</p>
     */
    private static final float COMMIT_THRESHOLD_FRACTION = 0.50f;

    /**
     * Fraction of the middle zone the below-threshold nudge travels.
     *
     * <p>Deliberately smaller than the commit threshold: it is an
     * acknowledgement that the song restarted, not the beginning of an
     * advance, so it reveals less of the neighbour than a swipe that
     * nearly committed would.</p>
     */
    private static final float RESTART_NUDGE_FRACTION = 0.25f;

    /**
     * Safety-net timeout for {@link SwipeState#AWAITING_SNAPSHOT}, in
     * milliseconds.
     *
     * <p>The commit guards close every ordinary path to a snapshot
     * arriving late. The timeout covers the unexpected — an activity
     * destroyed mid-transition, a service killed without broadcasting.
     * When it fires, the carousel springs back.</p>
     */
    private static final long SNAPSHOT_TIMEOUT_MS = 1500L;

    // ============================================================================
    // Commit State
    // ============================================================================

    /**
     * States of the commit protocol.
     */
    private enum SwipeState {

        /** No gesture, no pending commit. The resting state. */
        IDLE,

        /** Finger down, strip following the finger. */
        DRAGGING,

        /**
         * The strip is animating to a neighbour position. Entered by
         * the release of a swipe that passed its commit threshold, by
         * an external request through {@link #animateToNext()} or
         * {@link #animateToPrevious()}, or by an automatic song
         * transition whose incoming window arrives while the carousel
         * is idle.
         */
        COMMITTING,

        /** Animation done, commit under way, waiting for the service's window. */
        AWAITING_SNAPSHOT,

        /**
         * The strip is running the below-threshold animation: a
         * partial outward leg followed by a return to rest.
         */
        RESTARTING,

        /**
         * The carousel is running the one-way reveal used when the
         * current song changed to a path that was not one of the
         * previous window's neighbours.
         */
        REVEALING
    }

    // ============================================================================
    // Listener
    // ============================================================================

    /**
     * Receives a swipe commit request from the carousel.
     *
     * <p>The listener is dispatched only for commits that originated
     * from a swipe gesture. A commit that originated from
     * {@link #animateToNext()} or {@link #animateToPrevious()} does not
     * dispatch the listener, because the caller that started the
     * animation is responsible for dispatching the service request.</p>
     */
    public interface SwipeCommitListener {

        /**
         * Called when a swipe has committed and the carousel is waiting
         * for the service to confirm.
         *
         * @param direction +1 for a next commit, -1 for a previous commit
         */
        void onSwipeCommitted(int direction);
    }

    // ============================================================================
    // Collaborators
    // ============================================================================

    /** Context used for resource and density lookup. */
    @NonNull private final Context mContext;

    /** Viewport into which the strip is attached. */
    @NonNull private final FrameLayout mContainer;

    /** Shared album-art cache. */
    @NonNull private final LruCache<String, Bitmap> mCache;

    /** Executor for slot decodes. */
    @NonNull private final ExecutorService mExecutor;

    /** Main-thread handler for view mutation and the snapshot timeout. */
    @NonNull private final Handler mHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // View State
    // ============================================================================

    /** The three-slot strip. Null before {@link #attach()}. */
    @Nullable private LinearLayout mStrip;

    /** Left slot: previous song. Null before {@link #attach()}. */
    @Nullable private ImageView mPreviousView;

    /** Middle slot: current song. Null before {@link #attach()}. */
    @Nullable private ImageView mCurrentView;

    /** Right slot: next song. Null before {@link #attach()}. */
    @Nullable private ImageView mNextView;

    /**
     * Temporary overlay used by the one-way reveal, or null when no
     * reveal is running. Added to the viewport for the duration of the
     * reveal and removed on its end frame.
     */
    @Nullable private ImageView mFadeOverlayView = null;

    /**
     * Path whose art the reveal overlay is currently presenting, or
     * null when no reveal is running. Used to decide whether an
     * incoming broadcast or a decoded bitmap should retarget the
     * overlay's bitmap.
     */
    @Nullable private String mFadeOverlayPath = null;

    /** Width of one slot in pixels, or 0 before the first layout. */
    private int mSlotWidth = 0;

    /** Height of one slot in pixels, or 0 before the first layout. */
    private int mSlotHeight = 0;

    /** Width of one volume edge zone in pixels. */
    private int mEdgeZonePx = 0;

    // ============================================================================
    // Window and Placeholder
    // ============================================================================

    /** The window the carousel currently renders. Never null. */
    @NonNull private PlaybackWindow mWindow = PlaybackWindow.EMPTY;

    /**
     * Generation of {@link #mWindow}.
     *
     * <p>Updated by {@link #setWindow(PlaybackWindow)} on every
     * adoption. Used by {@link #adoptInIdle(PlaybackWindow, long)} to
     * tell a fresh transition apart from a broadcast that merely
     * re-publishes the same window.</p>
     */
    private long mLastWindowGeneration = -1L;

    /**
     * Bitmap currently shown as the placeholder in the current slot
     * whenever the current song's real art is unavailable, or null.
     */
    @Nullable private Bitmap mPlaceholderBitmap = null;

    /** Paths currently being decoded, so a decode is not scheduled twice. */
    @NonNull private final Set<String> mInflightDecodePaths =
        Collections.newSetFromMap(
            new ConcurrentHashMap<String, Boolean>());

    // ============================================================================
    // Commit State
    // ============================================================================

    /** Current state of the commit protocol. */
    @NonNull private SwipeState mSwipeState = SwipeState.IDLE;

    /** Direction of the current commit: +1 for next, -1 for previous. */
    private int mSwipeDirection = 0;

    /** Path the strip slid to, recorded when a commit starts. */
    @Nullable private String mExpectedCurrentPath = null;

    /**
     * Window that the service has published during a running commit
     * animation and that confirms the path the strip is sliding toward.
     */
    @Nullable private PlaybackWindow mConfirmedWindow = null;

    /** Listener that receives commit requests, or null. */
    @Nullable private SwipeCommitListener mSwipeCommitListener = null;

    /** Runnable that fires {@link #SNAPSHOT_TIMEOUT_MS} after a commit is dispatched. */
    @Nullable private Runnable mSnapshotTimeoutRunnable = null;

    /**
     * True while a return-to-rest animation is running.
     *
     * <p>The state enum is {@link SwipeState#IDLE} during a
     * return-to-rest — the commit is over and the strip is gliding home
     * — so the enum alone cannot report the strip as moving. This flag
     * carries that fact to {@link #isAnimating()}, so a caller that
     * gates work on the strip's motion, or that asks
     * {@link #setWindow(PlaybackWindow)} for the commit contract,
     * receives the honest answer.</p>
     */
    private boolean mReturningToRest = false;

    /**
     * Actions queued by {@link #postOnSettle(Runnable)}, run on the
     * frame the carousel returns to {@link SwipeState#IDLE} after a
     * commit, nudge, or reveal.
     */
    @NonNull private final List<Runnable> mPostSettleActions =
        new ArrayList<>();

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a carousel bound to the given viewport, cache, and
     * executor.
     *
     * @param context Context used for resource and density lookup
     * @param container Viewport the strip is attached to
     * @param cache Shared album-art cache
     * @param executor Executor for slot decodes
     */
    public AlbumArtCarousel(@NonNull Context context,
                            @NonNull FrameLayout container,
                            @NonNull LruCache<String, Bitmap> cache,
                            @NonNull ExecutorService executor) {
        mContext = context;
        mContainer = container;
        mCache = cache;
        mExecutor = executor;
    }

    // ============================================================================
    // Configuration
    // ============================================================================

    /**
     * Installs the width of one volume edge zone.
     *
     * @param edgeZonePx Width in pixels
     */
    public void setEdgeZonePx(int edgeZonePx) {
        mEdgeZonePx = Math.max(0, edgeZonePx);
    }

    /**
     * Installs the listener that receives swipe commit requests.
     *
     * @param listener Listener, or null to clear
     */
    public void setSwipeCommitListener(
            @Nullable SwipeCommitListener listener) {
        mSwipeCommitListener = listener;
    }

    // ============================================================================
    // Attachment and Layout
    // ============================================================================

    /**
     * Builds the strip and attaches it inside the viewport.
     *
     * <p>Idempotent. The three slots are constructed once and reused
     * for the lifetime of the carousel.</p>
     */
    public void attach() {
        if (mStrip != null) {
            return;
        }

        LinearLayout strip = new LinearLayout(mContext);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setClickable(false);
        strip.setFocusable(false);
        strip.setVisibility(View.INVISIBLE);

        ImageView previousView = createSlot();
        ImageView currentView = createSlot();
        ImageView nextView = createSlot();

        strip.addView(previousView);
        strip.addView(currentView);
        strip.addView(nextView);

        mContainer.addView(strip);
        mContainer.setClipChildren(true);

        mStrip = strip;
        mPreviousView = previousView;
        mCurrentView = currentView;
        mNextView = nextView;

        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            layoutSlots();
            mStrip.setVisibility(View.VISIBLE);
            render();
        });
    }

    /**
     * Creates one slot ImageView with the carousel's standard
     * configuration.
     *
     * @return A newly-created slot ImageView
     */
    @NonNull
    private ImageView createSlot() {
        ImageView view = new ImageView(mContext);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setClickable(false);
        view.setFocusable(false);
        view.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
        return view;
    }

    /**
     * Recomputes the slot dimensions from the viewport's current size
     * and re-lays out the strip.
     */
    public void onContainerResized() {
        if (mStrip == null) {
            return;
        }
        mContainer.post(() -> {
            if (mStrip == null) {
                return;
            }
            cancelSwipe();
            layoutSlots();
            render();
        });
    }

    /**
     * Resizes each slot and the strip to match the viewport's current
     * width, then snaps the strip to rest.
     */
    private void layoutSlots() {
        if (mStrip == null || mCurrentView == null
                || mPreviousView == null || mNextView == null) {
            return;
        }
        final int width = mContainer.getWidth();
        final int height = mContainer.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }

        mSlotWidth = width;
        mSlotHeight = height;

        for (ImageView slotView : new ImageView[] {
                mPreviousView, mCurrentView, mNextView}) {
            LinearLayout.LayoutParams layoutParams =
                (LinearLayout.LayoutParams) slotView.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = new LinearLayout.LayoutParams(
                    width, height);
            } else {
                layoutParams.width = width;
                layoutParams.height = height;
            }
            slotView.setLayoutParams(layoutParams);
        }

        ViewGroup.LayoutParams stripLayoutParams =
            mStrip.getLayoutParams();
        if (stripLayoutParams == null) {
            stripLayoutParams =
                new FrameLayout.LayoutParams(width * 3, height);
        } else {
            stripLayoutParams.width = width * 3;
            stripLayoutParams.height = height;
        }
        mStrip.setLayoutParams(stripLayoutParams);

        snapToRest();
    }

    /**
     * Sets the strip's {@code translationX} to {@code -mSlotWidth},
     * bringing the middle slot into the viewport, without animation.
     */
    private void snapToRest() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setTranslationX(-mSlotWidth);
        }
        mReturningToRest = false;
    }

    // ============================================================================
    // Main-Thread Work Contract
    // ============================================================================

    /**
     * Returns whether the strip is moving or awaiting a commit
     * confirmation.
     *
     * <p>True during a drag, a commit animation, a below-threshold
     * nudge, a reveal, a commit awaiting the service's confirming
     * window, and a return-to-rest glide. False only when the strip is
     * at rest and no commit is in flight.</p>
     *
     * @return True when the strip is animating or awaiting a commit
     *         confirmation
     */
    public boolean isAnimating() {
        return mSwipeState != SwipeState.IDLE || mReturningToRest;
    }

    /**
     * Queues an action to run on the frame the carousel settles.
     *
     * <p>When the carousel is at rest the action runs immediately.
     * Otherwise the action is queued and runs on the frame the carousel
     * snaps to rest and re-renders with the incoming window — the same
     * frame the strip's new bitmaps are installed. A caller that has
     * non-animation work to do — text updates that trigger
     * measure-and-layout passes, seek-bar layout passes, notification
     * and media-session commits — uses this hook to schedule that work
     * for the settle frame, so the work and the strip's own re-render
     * land in one layout pass.</p>
     *
     * <p>Actions run in the order they were queued. An action that
     * queues another action from inside its own body is deferred to a
     * later settle, not run in the same pass. When the carousel is
     * cancelled before it settles — a viewport resize, a drag that
     * supersedes the animation, a snapshot timeout — the queued actions
     * run on the cancellation path.</p>
     *
     * @param action Action to run on settle; never null
     */
    public void postOnSettle(@NonNull Runnable action) {
        if (!isAnimating()) {
            action.run();
            return;
        }
        mPostSettleActions.add(action);
    }

    /**
     * Runs and clears every action queued by
     * {@link #postOnSettle(Runnable)}.
     *
     * <p>Copies the queue before running so an action that queues
     * another action from its own body does not extend the pass it is
     * running in.</p>
     */
    private void runPostSettleActions() {
        if (mPostSettleActions.isEmpty()) {
            return;
        }
        final List<Runnable> pending =
            new ArrayList<>(mPostSettleActions);
        mPostSettleActions.clear();
        for (Runnable action : pending) {
            action.run();
        }
    }

    // ============================================================================
    // Window
    // ============================================================================

    /**
     * Adopts the given window and renders it.
     *
     * <p>The only entry point for changing what the carousel shows. The
     * service publishes a window on every {@code UPDATE_PLAYER}
     * broadcast; the activity forwards it here.</p>
     *
     * <p>The return value is the commit contract. A return of
     * {@code true} means the window was adopted with no animation
     * running afterwards — the strip is at rest — and the caller may
     * run its remaining commit work in the current turn. A return of
     * {@code false} means an animation is running; the caller registers
     * its remaining work through {@link #postOnSettle(Runnable)}, which
     * runs on the frame the animation ends. The two branches converge
     * on one commit turn, so a caller writes one commit runnable and
     * dispatches it through this contract without inspecting the
     * carousel's internal state.</p>
     *
     * @param window Window to adopt; never null
     * @return True when the window was committed synchronously; false
     *         when an animation is running and the caller's remaining
     *         work must be queued on the settle frame
     */
    public boolean setWindow(@NonNull PlaybackWindow window) {
        if (mStrip == null) {
            mWindow = window;
            mLastWindowGeneration = window.generation;
            return true;
        }

        final long previousGeneration = mLastWindowGeneration;
        mLastWindowGeneration = window.generation;

        switch (mSwipeState) {
            case AWAITING_SNAPSHOT: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                mWindow = window;
                mExpectedCurrentPath = null;
                cancelSnapshotTimeout();
                mSwipeState = SwipeState.IDLE;
                if (accepted) {
                    snapToRest();
                    render();
                    runPostSettleActions();
                    return true;
                }
                render();
                animateToRest(this::runPostSettleActions);
                return false;
            }
            case COMMITTING: {
                final boolean accepted = mExpectedCurrentPath != null
                    && mExpectedCurrentPath.equals(window.currentPath);
                if (accepted) {
                    // The service confirmed the slide while the
                    // animation is still running. Store the window
                    // and let the animation finish; its end action
                    // adopts the window, settles the strip at rest,
                    // and runs the settle queue.
                    mConfirmedWindow = window;
                } else {
                    // The window contradicts the slide. The service
                    // decided otherwise — a repeat-one restart is the
                    // ordinary case — so the strip glides back to
                    // rest from wherever the animation had reached,
                    // and the new window is adopted directly.
                    cancelSwipe();
                    mWindow = window;
                    render();
                    animateToRest(this::runPostSettleActions);
                }
                return false;
            }
            case RESTARTING: {
                // A restart does not change the current song. A window
                // that arrives during the nudge whose current path
                // matches the one the nudge is acknowledging — the
                // repeat-one restart's own broadcast — is stored, and
                // the nudge runs both legs. A window that names a
                // different current song is a genuine takeover: the
                // nudge is abandoned and the strip returns to rest
                // under the new window.
                final String incoming = window.currentPath;
                final boolean sameSong = incoming != null
                    && incoming.equals(mWindow.currentPath);
                if (sameSong) {
                    mWindow = window;
                    return false;
                }
                cancelSwipe();
                mWindow = window;
                render();
                animateToRest(this::runPostSettleActions);
                return false;
            }
            case REVEALING: {
                // A window arrived during the reveal. Store it and,
                // when its current path differs from the one the
                // overlay is presenting, retarget the overlay's
                // bitmap in place. The reveal continues toward the
                // newest current song rather than chaining a second
                // fade.
                mWindow = window;
                final String incoming = window.currentPath;
                if (mFadeOverlayView != null
                        && incoming != null
                        && !incoming.equals(mFadeOverlayPath)) {
                    installOverlayBitmap(incoming);
                }
                return false;
            }
            case DRAGGING: {
                cancelSwipe();
                mWindow = window;
                snapToRest();
                render();
                runPostSettleActions();
                return true;
            }
            case IDLE:
            default: {
                return adoptInIdle(window, previousGeneration);
            }
        }
    }

    /**
     * Adopts a window while the carousel is idle, animating the strip
     * when the window describes a song transition.
     *
     * <p>The automatic-transition case: a song completes and the
     * service advances, a headset media button arrives through the
     * media session, shuffle picks a new song on its own, a repeat-one
     * track restarts, a file is opened from another app and the service
     * rebuilds its playlist around it. In each of these the carousel is
     * idle when the new window arrives.</p>
     *
     * <p>Three forms of transition are recognised: a neighbour advance,
     * which runs the full commit slide and settles on the incoming
     * window; a restart, which runs the below-threshold nudge and
     * returns to rest; and a non-neighbour change, which runs the
     * one-way reveal. Every other window arrival — a broadcast that
     * re-publishes the same window, the first window after
     * {@link #clear()} — snaps the strip to rest and renders without
     * animation.</p>
     *
     * @param window Window to adopt; never null
     * @param previousGeneration Generation the carousel held before
     *        this call
     * @return True when the window was committed synchronously; false
     *         when an animation is running
     */
    private boolean adoptInIdle(@NonNull PlaybackWindow window,
                                long previousGeneration) {
        final String previousPath = mWindow.previousPath;
        final String currentPath = mWindow.currentPath;
        final String nextPath = mWindow.nextPath;
        final String incomingCurrent = window.currentPath;

        final boolean songChanged = (incomingCurrent != null)
            && !incomingCurrent.equals(currentPath);
        final boolean freshTransition =
            window.generation > previousGeneration;

        int direction = 0;
        if (songChanged) {
            if (incomingCurrent.equals(nextPath)) {
                direction = +1;
            } else if (incomingCurrent.equals(previousPath)) {
                direction = -1;
            }
        } else if (freshTransition) {
            if (nextPath != null) {
                direction = +1;
            } else if (previousPath != null) {
                direction = -1;
            }
        }

        if (direction == 0 || mSlotWidth <= 0) {
            mWindow = window;
            if (songChanged && mSlotWidth > 0) {
                startFade();
                return false;
            }
            snapToRest();
            render();
            return true;
        }

        if (songChanged) {
            mConfirmedWindow = window;
            startCommit(direction, false);
            return false;
        }

        mWindow = window;
        startBelowThreshold(direction);
        return false;
    }

    /**
     * Removes every slot's content and clears the window.
     *
     * <p>Used on library reset and when no song is playing.</p>
     */
    public void clear() {
        cancelSwipe();
        mWindow = PlaybackWindow.EMPTY;
        mLastWindowGeneration = -1L;
        if (mStrip != null) {
            snapToRest();
            render();
        }
    }

    // ============================================================================
    // Button-Driven Animation
    // ============================================================================

    /**
     * Animates the carousel to the next neighbour as if the user had
     * committed a forward swipe.
     *
     * @return True when the animation started
     */
    public boolean animateToNext() {
        return animateToNeighbour(+1);
    }

    /**
     * Animates the carousel to the previous neighbour as if the user
     * had committed a backward swipe.
     *
     * @return True when the animation started
     */
    public boolean animateToPrevious() {
        return animateToNeighbour(-1);
    }

    /**
     * Runs the below-threshold nudge toward the next neighbour.
     *
     * @return True when the animation started
     */
    public boolean nudgeToNext() {
        return nudgeToNeighbour(+1);
    }

    /**
     * Runs the below-threshold nudge toward the previous neighbour.
     *
     * @return True when the animation started
     */
    public boolean nudgeToPrevious() {
        return nudgeToNeighbour(-1);
    }

    /**
     * Starts a commit animation in the given direction when the
     * carousel is at rest and the direction's neighbour exists and
     * differs from the current song.
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean animateToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE || mReturningToRest) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null
                || neighbourPath.equals(mWindow.currentPath)) {
            return false;
        }
        startCommit(direction, false);
        return true;
    }

    /**
     * Starts the below-threshold nudge in the given direction when the
     * carousel is at rest and the direction's neighbour exists.
     *
     * <p>The neighbour may be the current song itself — a single-song
     * playlist, or a shuffle pick that cannot avoid the current index.
     * The nudge is the acknowledgement of a restart, and on a
     * single-song playlist the restart wraps onto the same song; the
     * nudge slides toward the same art and returns. The refusal is
     * limited to the case where the window names no neighbour at
     * all.</p>
     *
     * @param direction +1 for next, -1 for previous
     * @return True when the animation started
     */
    private boolean nudgeToNeighbour(int direction) {
        if (mSwipeState != SwipeState.IDLE || mReturningToRest) {
            return false;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return false;
        }
        final String neighbourPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;
        if (neighbourPath == null) {
            return false;
        }
        startBelowThreshold(direction);
        return true;
    }

    // ============================================================================
    // External Art Handoff
    // ============================================================================

    /**
     * Records a decoded bitmap for the given path in the shared cache
     * and re-renders.
     *
     * <p>When a reveal is running and the path is the one the overlay
     * is presenting, the overlay's bitmap is also updated in place so
     * the reveal continues with the resolved art rather than the
     * placeholder that was shown while the decode was in flight.</p>
     *
     * @param path Path the bitmap belongs to
     * @param bitmap Decoded bitmap
     */
    public void onArtReady(@NonNull String path, @NonNull Bitmap bitmap) {
        mCache.put(path, bitmap);
        if (mStrip == null) {
            return;
        }
        if (mSwipeState == SwipeState.REVEALING
                && path.equals(mFadeOverlayPath)) {
            installOverlayBitmap(path);
        }
        render();
    }

    /**
     * Removes the bitmap for the given path from the shared cache and
     * re-renders.
     *
     * @param path Path to invalidate
     */
    public void invalidatePath(@NonNull String path) {
        mCache.remove(path);
        if (mStrip != null) {
            render();
        }
    }

    /**
     * Installs the given bitmap as the themed placeholder.
     *
     * @param placeholderBitmap Themed placeholder bitmap, or null to clear
     */
    public void setPlaceholder(@Nullable Bitmap placeholderBitmap) {
        mPlaceholderBitmap = placeholderBitmap;
        if (mStrip != null) {
            render();
        }
    }

    // ============================================================================
    // Swipe
    // ============================================================================

    /**
     * Marks the start of a horizontal swipe on the album art.
     */
    public void beginSwipe() {
        if (mSwipeState != SwipeState.IDLE || mReturningToRest) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        mSwipeState = SwipeState.DRAGGING;
    }

    /**
     * Updates the strip's position from the finger's horizontal
     * displacement.
     *
     * @param horizontalDisplacement Horizontal displacement in pixels,
     *        positive to the right
     */
    public void updateSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));
        mStrip.setTranslationX(-mSlotWidth + clampedDisplacement);
    }

    /**
     * Ends the swipe and either commits to the neighbour or springs
     * back.
     *
     * @param horizontalDisplacement Total horizontal displacement in
     *        pixels, positive to the right
     */
    public void endSwipe(float horizontalDisplacement) {
        if (mSwipeState != SwipeState.DRAGGING) {
            mSwipeState = SwipeState.IDLE;
            return;
        }
        if (mStrip == null || mSlotWidth <= 0) {
            mSwipeState = SwipeState.IDLE;
            return;
        }

        final float middleZoneWidth = Math.max(
            1f, mSlotWidth - 2f * mEdgeZonePx);
        final float commitThreshold =
            middleZoneWidth * COMMIT_THRESHOLD_FRACTION;
        final float clampedDisplacement = Math.max(-mSlotWidth,
            Math.min(mSlotWidth, horizontalDisplacement));

        final boolean wantsForward =
            (clampedDisplacement <= -commitThreshold);
        final boolean wantsBackward =
            (clampedDisplacement >=  commitThreshold);

        final boolean canCommitForward = wantsForward
            && mWindow.nextPath != null
            && !mWindow.nextPath.equals(mWindow.currentPath);
        final boolean canCommitBackward = wantsBackward
            && mWindow.previousPath != null
            && !mWindow.previousPath.equals(mWindow.currentPath);

        if (canCommitForward) {
            startCommit(+1, true);
            return;
        }
        if (canCommitBackward) {
            startCommit(-1, true);
            return;
        }

        mSwipeState = SwipeState.IDLE;
        animateToRest(null);
    }

    // ============================================================================
    // Commit Animations
    // ============================================================================

    /**
     * Begins a commit in the given direction.
     *
     * <p>Sets the expected current path, animates the strip to the
     * neighbour position, and arranges the end action. The end action
     * either adopts a window the service published while the animation
     * was running — or, for an automatic song change, the window
     * {@link #adoptInIdle(PlaybackWindow, long)} stored before the
     * animation started — or enters
     * {@link SwipeState#AWAITING_SNAPSHOT} and, when the commit
     * originated from a swipe, dispatches
     * {@link SwipeCommitListener#onSwipeCommitted(int)}.</p>
     *
     * @param direction +1 for a next commit, -1 for a previous commit
     * @param fireListener True when the commit originated from a swipe
     */
    private void startCommit(int direction, final boolean fireListener) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.COMMITTING;
        mExpectedCurrentPath = (direction > 0)
            ? mWindow.nextPath
            : mWindow.previousPath;

        final float targetTranslationX = (direction > 0)
            ? (-2f * mSlotWidth)
            : 0f;

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(SWIPE_ANIMATION_MS)
            .setInterpolator(new DecelerateInterpolator(1.5f))
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.COMMITTING) {
                    return;
                }
                if (mConfirmedWindow != null) {
                    final PlaybackWindow confirmedWindow =
                        mConfirmedWindow;
                    mConfirmedWindow = null;
                    mWindow = confirmedWindow;
                    mExpectedCurrentPath = null;
                    mSwipeState = SwipeState.IDLE;
                    snapToRest();
                    render();
                    runPostSettleActions();
                    return;
                }
                mSwipeState = SwipeState.AWAITING_SNAPSHOT;
                if (fireListener && mSwipeCommitListener != null) {
                    mSwipeCommitListener.onSwipeCommitted(
                        mSwipeDirection);
                }
                scheduleSnapshotTimeout();
            })
            .start();
    }

    /**
     * Runs the below-threshold nudge: the strip slides out by a
     * fraction of the middle zone and then returns to rest.
     *
     * <p>Reached from three callers: the automatic restart when a track
     * loops, the wrap-restart on a single-song playlist, and the
     * transport buttons under repeat-one or on a wrap via
     * {@link #nudgeToNext()} and {@link #nudgeToPrevious()}. All
     * produce identical animations, so a press and an involuntary
     * restart look the same.</p>
     *
     * <p>The state stays {@link SwipeState#RESTARTING} across both
     * legs, so a window that arrives during the animation is handled by
     * {@link #setWindow(PlaybackWindow)}'s RESTARTING branch, which
     * absorbs the restart's own broadcast and aborts the animation only
     * for a genuine new transition.</p>
     *
     * @param direction +1 for a forward animation, -1 for a backward
     *        one
     */
    private void startBelowThreshold(int direction) {
        mSwipeDirection = direction;
        mSwipeState = SwipeState.RESTARTING;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final float middleZoneWidth = Math.max(1f,
            mSlotWidth - 2f * mEdgeZonePx);
        final float nudgePx =
            middleZoneWidth * RESTART_NUDGE_FRACTION;

        final float targetTranslationX = (direction > 0)
            ? (-mSlotWidth - nudgePx)
            : (-mSlotWidth + nudgePx);

        final long outwardDuration = Math.max(1L,
            (long) (SWIPE_ANIMATION_MS * nudgePx
                / Math.max(1f, mSlotWidth)));

        mStrip.animate()
            .translationX(targetTranslationX)
            .setDuration(outwardDuration)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.RESTARTING) {
                    return;
                }
                animateToRest(() -> {
                    if (mSwipeState != SwipeState.RESTARTING) {
                        return;
                    }
                    mSwipeState = SwipeState.IDLE;
                    mSwipeDirection = 0;
                    mExpectedCurrentPath = null;
                    mConfirmedWindow = null;
                    runPostSettleActions();
                });
            })
            .start();
    }

    /**
     * Runs the one-way reveal used when the current song changed to a
     * path that was not one of the previous window's neighbours.
     *
     * <p>The reveal is a staggered cross-fade, not a single-track fade.
     * The outgoing art fades from full opacity to zero over
     * {@link #REVEAL_OUTGOING_FRACTION} of {@link #REVEAL_DURATION_MS},
     * using an accelerating curve so it clears quickly. The incoming
     * art fades from zero to full opacity over the remaining portion of
     * the duration, using a decelerating curve so it settles gently,
     * and scales from {@link #REVEAL_INCOMING_START_SCALE} to 1.0
     * across the same window. The two legs overlap by
     * {@link #REVEAL_OVERLAP_FRACTION} of the total duration, so at
     * least one image is on screen for every frame of the
     * transition.</p>
     *
     * <p>The outgoing art is the strip itself, at rest, at full
     * opacity. The incoming art is a temporary {@link ImageView}
     * overlay added to the viewport with a hardware layer set for the
     * duration of the fade. The hardware layer lets the GPU composite
     * the overlay's alpha and scale without a software redraw each
     * frame; the layer is cleared on the fade's end frame.</p>
     *
     * <p>On the fade's end frame the overlay is removed, the strip is
     * re-rendered with the current {@link #mWindow} at full opacity,
     * and the settle hooks run — all in one frame. There is no midpoint
     * and no blank frame: the incoming art rises over the outgoing art
     * as the outgoing art recedes.</p>
     *
     * <p>A broadcast arriving during the reveal with a different
     * current path is handled by {@link #setWindow(PlaybackWindow)}'s
     * REVEALING branch, which retargets the overlay's bitmap in place
     * so the reveal continues toward the newest current song rather
     * than chaining a second fade.</p>
     */
    private void startFade() {
        if (mStrip == null || mSlotWidth <= 0 || mSlotHeight <= 0) {
            snapToRest();
            render();
            return;
        }

        mSwipeState = SwipeState.REVEALING;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;

        final String incomingPath = mWindow.currentPath;
        final Bitmap incomingBitmap = pathBitmap(incomingPath);

        final ImageView overlay = new ImageView(mContext);
        overlay.setScaleType(ImageView.ScaleType.FIT_CENTER);
        overlay.setClickable(false);
        overlay.setFocusable(false);

        final FrameLayout.LayoutParams overlayParams =
            new FrameLayout.LayoutParams(mSlotWidth, mSlotHeight);
        overlayParams.gravity = Gravity.CENTER;
        overlay.setLayoutParams(overlayParams);
        overlay.setImageBitmap(
            (incomingBitmap != null) ? incomingBitmap : mPlaceholderBitmap);
        overlay.setAlpha(0f);
        overlay.setScaleX(REVEAL_INCOMING_START_SCALE);
        overlay.setScaleY(REVEAL_INCOMING_START_SCALE);

        // A hardware layer for the duration of the fade. The overlay
        // is a full-size bitmap composited with alpha and scale every
        // frame; the layer keeps that compositing on the GPU instead
        // of re-rasterizing the bitmap through the software path. The
        // layer is cleared on the end frame so it does not linger as
        // memory.
        overlay.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        mContainer.addView(overlay);
        mFadeOverlayView = overlay;
        mFadeOverlayPath = incomingPath;

        // The outgoing leg: the strip fades from full opacity to zero
        // over the outgoing fraction, with an accelerating curve. A
        // leaving element accelerates out of view; this is the
        // complement of the incoming leg's decelerate, and the two
        // together read as one continuous dissolve.
        final long outgoingDuration = Math.max(1L,
            (long) (REVEAL_DURATION_MS * REVEAL_OUTGOING_FRACTION));
        mStrip.animate()
            .alpha(0f)
            .setDuration(outgoingDuration)
            .setInterpolator(new AccelerateInterpolator())
            .start();

        // The incoming leg: the overlay fades from zero to full
        // opacity and scales from its start value to 1.0, over the
        // remainder of the duration, with a decelerating curve. The
        // decelerate curve is what makes an entering element settle
        // into place rather than arrive at full speed.
        final long overlapDuration = Math.max(1L,
            (long) (REVEAL_DURATION_MS * REVEAL_OVERLAP_FRACTION));
        final long incomingDelay = Math.max(0L,
            outgoingDuration - overlapDuration);
        final long incomingDuration = Math.max(1L,
            REVEAL_DURATION_MS - incomingDelay);
        overlay.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(incomingDelay)
            .setDuration(incomingDuration)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                if (mSwipeState != SwipeState.REVEALING) {
                    return;
                }
                mContainer.removeView(overlay);
                mFadeOverlayView = null;
                mFadeOverlayPath = null;
                mSwipeState = SwipeState.IDLE;
                mSwipeDirection = 0;
                if (mStrip != null) {
                    mStrip.setAlpha(1f);
                }
                snapToRest();
                render();
                runPostSettleActions();
            })
            .start();
    }

    /**
     * Installs the cached art for the given path into the reveal
     * overlay, falling back to the placeholder when the art is not
     * cached.
     *
     * @param path Path whose art should be presented, or null
     */
    private void installOverlayBitmap(@Nullable String path) {
        if (mFadeOverlayView == null) {
            return;
        }
        final Bitmap art = (path != null) ? pathBitmap(path) : null;
        mFadeOverlayView.setImageBitmap(
            (art != null) ? art : mPlaceholderBitmap);
    }

    /**
     * Abandons any in-flight commit, nudge, or reveal and returns the
     * protocol to {@link SwipeState#IDLE}.
     *
     * <p>Cancels the strip animation, the snapshot timeout, removes
     * the reveal overlay when one is present, restores the strip's
     * alpha, clears every field the commit, nudge, or reveal was
     * tracking, and runs and clears the settle-hook queue. The queue is
     * flushed here so a queued action is never dropped when the
     * animation that was going to run it is abandoned. Does not move
     * the strip; callers that need the strip at rest call
     * {@link #snapToRest()} or {@link #animateToRest(Runnable)} after
     * this method.</p>
     */
    private void cancelSwipe() {
        if (mStrip != null) {
            mStrip.animate().cancel();
            mStrip.setAlpha(1f);
        }
        if (mFadeOverlayView != null) {
            mFadeOverlayView.animate().cancel();
            mFadeOverlayView.setLayerType(View.LAYER_TYPE_NONE, null);
            mContainer.removeView(mFadeOverlayView);
            mFadeOverlayView = null;
        }
        mFadeOverlayPath = null;
        cancelSnapshotTimeout();
        mSwipeState = SwipeState.IDLE;
        mSwipeDirection = 0;
        mExpectedCurrentPath = null;
        mConfirmedWindow = null;
        mReturningToRest = false;
        runPostSettleActions();
    }

    /**
     * Animates the strip to rest over {@link #SWIPE_ANIMATION_MS}
     * milliseconds and runs the given action when the animation ends.
     *
     * <p>Used by every return path: the spring-back after a
     * below-threshold swipe, the refusal path of a committed swipe or
     * button press, the mismatch path of an in-flight commit, and the
     * return leg of the below-threshold nudge.</p>
     *
     * @param endAction Action to run when the animation completes, or null
     */
    private void animateToRest(@Nullable final Runnable endAction) {
        if (mStrip == null) {
            if (endAction != null) {
                endAction.run();
            }
            return;
        }
        mReturningToRest = true;
        mStrip.animate()
            .translationX(-mSlotWidth)
            .setDuration(SWIPE_ANIMATION_MS)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                if (mStrip != null) {
                    mStrip.setTranslationX(-mSlotWidth);
                }
                mReturningToRest = false;
                if (endAction != null) {
                    endAction.run();
                }
            })
            .start();
    }

    /**
     * Schedules the safety-net timeout that fires when a commit is
     * dispatched but no window follows.
     */
    private void scheduleSnapshotTimeout() {
        cancelSnapshotTimeout();
        mSnapshotTimeoutRunnable = () -> {
            if (mSwipeState != SwipeState.AWAITING_SNAPSHOT) {
                return;
            }
            Log.w(TAG, "Snapshot timeout; springing back");
            mExpectedCurrentPath = null;
            mSwipeState = SwipeState.IDLE;
            animateToRest(this::runPostSettleActions);
        };
        mHandler.postDelayed(
            mSnapshotTimeoutRunnable, SNAPSHOT_TIMEOUT_MS);
    }

    /**
     * Cancels the safety-net snapshot timeout. Idempotent.
     */
    private void cancelSnapshotTimeout() {
        if (mSnapshotTimeoutRunnable != null) {
            mHandler.removeCallbacks(mSnapshotTimeoutRunnable);
            mSnapshotTimeoutRunnable = null;
        }
    }

    // ============================================================================
    // Rendering
    // ============================================================================

    /**
     * Renders the current window.
     *
     * <p>For each slot, consults the shared cache for the slot's path,
     * installs the bitmap when one is present, installs the placeholder
     * in the current slot when the current path's art is unavailable,
     * and schedules a decode for any path whose art is not cached and
     * not already being decoded.</p>
     */
    private void render() {
        if (mStrip == null || mSlotWidth <= 0) {
            return;
        }

        final Bitmap previousBitmap = pathBitmap(mWindow.previousPath);
        final Bitmap currentBitmap = pathBitmap(mWindow.currentPath);
        final Bitmap nextBitmap = pathBitmap(mWindow.nextPath);

        installImage(mPreviousView, previousBitmap);
        installImage(mCurrentView,
            (currentBitmap != null) ? currentBitmap : mPlaceholderBitmap);
        installImage(mNextView, nextBitmap);

        scheduleIfMissing(mWindow.previousPath, previousBitmap);
        scheduleIfMissing(mWindow.currentPath, currentBitmap);
        scheduleIfMissing(mWindow.nextPath, nextBitmap);
    }

    /**
     * Returns the cached bitmap for the given path, or null when none
     * is cached or the cached bitmap has been recycled.
     *
     * @param path Path to look up, or null
     * @return The cached bitmap, or null
     */
    @Nullable
    private Bitmap pathBitmap(@Nullable String path) {
        if (path == null) {
            return null;
        }
        final Bitmap cachedBitmap = mCache.get(path);
        return (cachedBitmap != null && !cachedBitmap.isRecycled())
            ? cachedBitmap : null;
    }

    /**
     * Installs the given bitmap into the given slot, or clears the
     * slot when the bitmap is null or recycled.
     *
     * @param slotView Slot to install into, or null
     * @param bitmap Bitmap to install, or null
     */
    private void installImage(@Nullable ImageView slotView,
                              @Nullable Bitmap bitmap) {
        if (slotView == null) {
            return;
        }
        if (bitmap != null && !bitmap.isRecycled()) {
            slotView.setImageBitmap(bitmap);
        } else {
            slotView.setImageDrawable(null);
        }
    }

    /**
     * Schedules a decode for the given path when its art is not cached
     * and not already being decoded.
     *
     * @param path Path to schedule, or null
     * @param alreadyLoadedBitmap Cached bitmap for the path, or null
     */
    private void scheduleIfMissing(@Nullable final String path,
                                   @Nullable Bitmap alreadyLoadedBitmap) {
        if (path == null || alreadyLoadedBitmap != null) {
            return;
        }
        if (!mInflightDecodePaths.add(path)) {
            return;
        }
        mExecutor.execute(() -> {
            final Bitmap decodedBitmap = decodeSlotBitmap(path);
            mContainer.post(() -> {
                mInflightDecodePaths.remove(path);
                if (decodedBitmap != null) {
                    mCache.put(path, decodedBitmap);
                }
                if (mStrip != null) {
                    render();
                }
            });
        });
    }

    /**
     * Decodes the art for the given path at slot resolution.
     *
     * @param path Path of the song whose art should be decoded
     * @return The decoded bitmap, or null on failure or when the file
     *         has no embedded art
     */
    @Nullable
    private Bitmap decodeSlotBitmap(@NonNull String path) {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(path);
            final byte[] embeddedPicture =
                retriever.getEmbeddedPicture();
            if (embeddedPicture == null
                    || embeddedPicture.length == 0) {
                return null;
            }
            final BitmapFactory.Options boundsOptions =
                new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length,
                boundsOptions);
            final int sampleSize = calculateSampleSize(
                boundsOptions, SLOT_BITMAP_SIZE_PX,
                SLOT_BITMAP_SIZE_PX);
            final BitmapFactory.Options decodeOptions =
                new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            decodeOptions.inPreferredConfig =
                Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(
                embeddedPicture, 0, embeddedPicture.length,
                decodeOptions);
        } catch (Exception exception) {
            Log.w(TAG, "Failed to decode slot art for " + path,
                exception);
            return null;
        } finally {
            if (retriever != null) {
                try {
                    retriever.release();
                } catch (Exception exception) {
                    // The retriever is not in a state that permits
                    // release.
                }
            }
        }
    }

    /**
     * Returns the sample size needed to decode an image at or above
     * the requested bounds.
     *
     * @param options Options whose bounds have already been decoded
     * @param requestedWidth Requested width in pixels
     * @param requestedHeight Requested height in pixels
     * @return The sample size, a power of two
     */
    private int calculateSampleSize(
            @NonNull BitmapFactory.Options options,
            int requestedWidth, int requestedHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > requestedHeight || width > requestedWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= requestedHeight
                    && (halfWidth / inSampleSize) >= requestedWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}