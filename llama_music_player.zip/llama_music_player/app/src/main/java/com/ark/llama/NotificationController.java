package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.media.session.MediaButtonReceiver;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Owns every notification surface the app produces.
 *
 * <p>Two notification identifiers sit on two channels.</p>
 * <ul>
 *   <li>{@link #ID_PLAYBACK} — the playback notification on
 *       {@code music_playback_channel}. Its state is bound to
 *       {@link MusicService} through a {@link ServiceStateSource}. It is
 *       the only surface eligible for foreground promotion. It is
 *       rendered by an awareness poll at
 *       {@link #AWARENESS_INTERVAL_MS} and a debounced atomic render at
 *       {@link #RENDERING_INTERVAL_MS}.</li>
 *   <li>{@link #ID_LIBRARY} — the library notification on
 *       {@code music_library_channel}. It mirrors
 *       {@link ToastManager}'s persistent-overlay lifecycle. It is never
 *       promoted to the foreground. It is independent of
 *       {@link MusicService}.</li>
 * </ul>
 *
 * <h3>State Ownership</h3>
 * <p>The controller owns both notification identifiers, both channels,
 * both notification builders, the perceived and rendered playback
 * snapshots, the transport {@link PendingIntent}s, the album art cache,
 * the themed placeholder bitmap, and the library notification's message
 * and operation ID. {@link MusicService} owns the playback state machine
 * and exposes it through a {@link ServiceStateSource} that the controller
 * polls.</p>
 *
 * <p>The controller does not hold the service's state machine. It reads
 * a complete {@link RenderSnapshot} from the source. Rendering is a
 * single atomic transition carrying title, artist, play flag, and art
 * together, so the notification manager never observes a partial
 * update.</p>
 *
 * <h3>Ordering</h3>
 * <p>Awareness runs on a fixed {@link #AWARENESS_INTERVAL_MS} cadence
 * regardless of service state. Its only job is to detect changes in the
 * service's committed snapshot. When the snapshot differs from what the
 * controller has perceived, the render timer is armed. When another
 * change arrives before the timer fires, the timer resets. When the
 * timer finally elapses, the controller renders the current perceived
 * snapshot, so a burst of rapid changes collapses into a single
 * render.</p>
 *
 * <p>The {@link RenderSnapshot#artResolved} flag distinguishes "art
 * decode still pending" from "art resolved to no art". While the decode
 * is in flight, the controller holds the outgoing song's art. When the
 * decode resolves, the controller commits the incoming song's art, or
 * the placeholder when the song has no embedded art, in one visible
 * swap. This makes the notification's large icon change at most once per
 * song transition.</p>
 *
 * <p>Whenever the current song has no embedded art, and also before any
 * song is bound, the notification's large icon falls back to the themed
 * placeholder produced by {@link #getThemedPlaceholder()}. This mirrors
 * {@code MusicPlayer.updatePlaceholderBitmap()}, so the two surfaces
 * render the same image in the same color.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The controller is a process-wide singleton.
 * {@link MusicService#onCreate()} calls {@link #attachService(Service)}
 * and {@link MusicService#onDestroy()} calls {@link #detachService()}.
 * The library surface operates independently of the media service being
 * attached.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All public methods run on the main thread. Awareness and render are
 * scheduled on the main handler. The playback surface is guarded by
 * {@link #mPlaybackLock}; the library surface is guarded by
 * {@link #mLibraryLock}. Bitmap work runs inline on the main thread and
 * is bounded by {@link #MAX_ART_SIZE}.</p>
 *
 * @see MusicService
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class NotificationController {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "NotificationController";

    /** Notification identifier for the playback notification. */
    public static final int ID_PLAYBACK = 1;

    /** Notification identifier for the library notification. */
    public static final int ID_LIBRARY = 2;

    /** Channel identifier for the playback notification. */
    private static final String CHANNEL_PLAYBACK = "music_playback_channel";

    /** Display name of the playback channel. */
    private static final String CHANNEL_PLAYBACK_NAME = "Playback";

    /** Description of the playback channel. */
    private static final String CHANNEL_PLAYBACK_DESC = "Music playback controls";

    /** Channel identifier for the library notification. */
    private static final String CHANNEL_LIBRARY = "music_library_channel";

    /** Display name of the library channel. */
    private static final String CHANNEL_LIBRARY_NAME = "Library";

    /** Description of the library channel. */
    private static final String CHANNEL_LIBRARY_DESC = "Music library updates";

    /** Small icon shared by both notifications. */
    private static final int SMALL_ICON_RES = R.drawable.ic_notification;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int MAX_ART_SIZE = 300;

    /** Size of the album art cache, in megabytes. */
    private static final int MAX_CACHE_MB = 25;

    /** Neutral tint for transport action icons. */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;

    /** Red tint for the close action icon. */
    private static final int RED_COLOR = 0xFFE53935;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Fallback icon size for themed action icons, in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;

    /** Placeholder title shown when no song is committed. */
    private static final String PLACEHOLDER_TITLE = "Title";

    /** Placeholder artist shown when no song is committed. */
    private static final String PLACEHOLDER_ARTIST = "Artist";

    /** Channel state string for the resting state. */
    private static final String STATE_RESTING = "Resting";

    /** Channel state string for the playing state. */
    private static final String STATE_PLAYING = "Playing";

    /** Channel state string for the paused state. */
    private static final String STATE_PAUSED = "Paused";

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /**
     * Awareness poll interval in milliseconds. Fast enough that a commit
     * is perceived within one frame of {@code onPlaybackStarted}.
     */
    private static final long AWARENESS_INTERVAL_MS = 100L;

    /**
     * Quiet period before a perceived change is rendered.
     *
     * <p>Greater than {@link #AWARENESS_INTERVAL_MS} so a rendered commit
     * is not re-rendered on the following awareness tick, and less than
     * the transport debounce (500 ms in both {@link MusicService} and
     * the activity) so a single tap is rendered before the next tap is
     * accepted.</p>
     */
    private static final long RENDERING_INTERVAL_MS = 200L;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    // ========================================================================
    // Collaborator Interfaces and Data Carriers
    // ========================================================================

    /**
     * Read-only view of {@link MusicService}'s committed state.
     *
     * <p>All calls run on the main thread. Implementations must not
     * block.</p>
     */
    public interface ServiceStateSource {

        /**
         * Returns a complete renderable snapshot, or null when the
         * service has nothing new to render.
         *
         * <p>Returns null while the service is in a state that has
         * nothing committed to render — PREPARING (a transition is in
         * flight) or IDLE with no song bound. In both cases the last
         * committed render is held.</p>
         *
         * @return A complete renderable snapshot, or null
         */
        @Nullable
        RenderSnapshot snapshotForNotification();

        /**
         * Returns whether the service is idle.
         *
         * @return True when the service has nothing renderable and the
         *         playback notification should clear
         */
        boolean isIdle();
    }

    /**
     * An immutable, complete picture of the service.
     *
     * <p>A non-null snapshot contains everything the playback
     * notification needs: title, artist, path, play flag, and art.
     * Rendering it is a single atomic transition.</p>
     *
     * <p>The {@link #artResolved} flag distinguishes two situations that
     * {@link #art} alone cannot:</p>
     * <ul>
     *   <li><b>Pending</b> — {@code artResolved} is false and
     *       {@code art} is null. The service is still decoding the art
     *       for this song. The controller holds the previous render
     *       rather than flashing a placeholder.</li>
     *   <li><b>Resolved</b> — {@code artResolved} is true. {@code art}
     *       is either a bitmap (the song has art) or null (the song has
     *       none). The controller commits this render; the single swap
     *       from the previous bitmap to this one is the only visible
     *       change.</li>
     * </ul>
     */
    public static final class RenderSnapshot {

        /** Song title. */
        @NonNull
        public final String title;

        /** Artist name. */
        @NonNull
        public final String artist;

        /** File path used as the album art cache key. */
        @NonNull
        public final String path;

        /** True while the state machine is in PLAYING. */
        public final boolean isPlaying;

        /**
         * Decoded art for this path, or null.
         *
         * <p>Null on its own is ambiguous: it may mean the decode is
         * still pending, or it may mean the song has no art.
         * {@link #artResolved} disambiguates.</p>
         */
        @Nullable
        public final Bitmap art;

        /**
         * True when {@link #art} is the final answer for this song —
         * either a bitmap or an explicit "no art". False while the
         * decode is in flight.
         */
        public final boolean artResolved;

        /**
         * Constructs a snapshot with the given values.
         *
         * @param title Song title
         * @param artist Artist name
         * @param path File path used as the album art cache key
         * @param isPlaying True when the state machine is in PLAYING
         * @param art Decoded art, or null
         * @param artResolved True when {@code art} is the final answer
         */
        public RenderSnapshot(@NonNull String title, @NonNull String artist,
                              @NonNull String path, boolean isPlaying,
                              @Nullable Bitmap art, boolean artResolved) {
            this.title = title;
            this.artist = artist;
            this.path = path;
            this.isPlaying = isPlaying;
            this.art = art;
            this.artResolved = artResolved;
        }

        @Override
        public boolean equals(@Nullable Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || getClass() != object.getClass()) {
                return false;
            }
            RenderSnapshot snapshot = (RenderSnapshot) object;
            return isPlaying == snapshot.isPlaying
                && artResolved == snapshot.artResolved
                && title.equals(snapshot.title)
                && artist.equals(snapshot.artist)
                && path.equals(snapshot.path)
                && art == snapshot.art;
        }

        @Override
        public int hashCode() {
            return Objects.hash(title, artist, path, isPlaying, artResolved);
        }
    }

    /**
     * Internal rendered state for the playback notification.
     *
     * <p>Written only inside {@link #applySnapshot(RenderSnapshot)} and
     * read only inside {@link #performPlaybackUpdate()} and
     * {@link #buildPlaybackNotification(PlaybackState)}.</p>
     *
     * <p>Carries only song-scoped fields. The themed placeholder bitmap
     * is resolved at build time by
     * {@link #getSafeLargeIcon(PlaybackState)} whenever the current
     * state has no art of its own.</p>
     */
    private static final class PlaybackState {

        /** Channel state string for the current render. */
        final String channelState;

        /** True when the render represents PLAYING. */
        final boolean isPlaying;

        /** Title currently displayed. */
        final String title;

        /** Artist currently displayed. */
        final String artist;

        /** Bitmap currently displayed as the large icon, or null. */
        @Nullable final Bitmap albumArt;

        /** Cache key of the currently displayed art, or null. */
        @Nullable final String artKey;

        /** Song path the render belongs to, or null. */
        @Nullable final String songPath;

        /**
         * Constructs a rendered state.
         *
         * @param channelState Channel state string
         * @param isPlaying True when playback is active
         * @param title Title to display
         * @param artist Artist to display
         * @param albumArt Large icon bitmap, or null
         * @param artKey Cache key of the art, or null
         * @param songPath Song path the render belongs to, or null
         */
        PlaybackState(String channelState, boolean isPlaying, String title,
                      String artist, @Nullable Bitmap albumArt,
                      @Nullable String artKey, @Nullable String songPath) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.artKey = artKey;
            this.songPath = songPath;
        }

        /**
         * Returns whether this render represents the resting state.
         *
         * @return True when {@link #channelState} equals
         *         {@link #STATE_RESTING}
         */
        boolean isResting() {
            return STATE_RESTING.equals(channelState);
        }
    }

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile NotificationController sInstance;

    /**
     * Returns the process-wide singleton, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static NotificationController getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (NotificationController.class) {
                if (sInstance == null) {
                    sInstance = new NotificationController(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Fields
    // ========================================================================

    /** Application context. */
    @NonNull
    private final Context mContext;

    /** System notification manager. */
    @Nullable
    private final NotificationManager mNotificationManager;

    /** Main-thread handler for awareness and render posts. */
    @NonNull
    private final Handler mMainHandler;

    /** Cache of decoded album art keyed by song path. */
    @NonNull
    private final LruCache<String, Bitmap> mAlbumArtCache;

    /**
     * Cached themed placeholder used as the notification large icon
     * whenever the current song has no art, or whenever no song is
     * bound. Built lazily on the main thread and rebuilt on theme
     * change.
     */
    @Nullable
    private volatile Bitmap mThemedPlaceholder;

    /**
     * Theme color the cached placeholder was built with. Zero means "not
     * yet built"; every real theme color has a non-zero alpha channel,
     * so the equality check in {@link #getThemedPlaceholder()} is
     * unambiguous.
     */
    private volatile int mThemedPlaceholderColor = 0;

    /** Receiver that invalidates the placeholder cache on theme change. */
    @Nullable
    private BroadcastReceiver mThemeReceiver;

    /** Lock for the playback notification IPC and foreground arbitration. */
    @NonNull
    private final Object mPlaybackLock = new Object();

    /** Lock for the library notification state and IPC. */
    @NonNull
    private final Object mLibraryLock = new Object();

    // ---- Playback surface ----

    /** Bound service, or null between detach and the next attach. */
    @Nullable
    private Service mService;

    /** Source of committed state, or null when no service is attached. */
    @Nullable
    private ServiceStateSource mStateSource;

    /** Provider of the active media session token, or null. */
    @Nullable
    private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;

    /** Cached transport PendingIntent for play and pause. */
    @Nullable
    private PendingIntent mPlayPauseIntent;

    /** Cached transport PendingIntent for skip-to-next. */
    @Nullable
    private PendingIntent mNextIntent;

    /** Cached transport PendingIntent for skip-to-previous. */
    @Nullable
    private PendingIntent mPreviousIntent;

    /** Current rendered playback state. */
    @NonNull
    private volatile PlaybackState mPlaybackState =
        new PlaybackState(STATE_RESTING, false, "", "", null, null, "");

    /** True while the service holds the foreground promotion. */
    @NonNull
    private final AtomicBoolean mPlaybackForeground = new AtomicBoolean(false);

    /** Last perceived snapshot from the state source, or null. */
    @Nullable
    private RenderSnapshot mPerceivedSnapshot;

    /** Last rendered snapshot, or null. */
    @Nullable
    private RenderSnapshot mLastRenderedSnapshot;

    /** Awareness runnable, or null when the poll is stopped. */
    @Nullable
    private Runnable mAwarenessRunnable;

    /** Render-timer runnable, or null when the timer is not armed. */
    @Nullable
    private Runnable mRenderRunnable;

    // ---- Library surface ----

    /** Current library notification text, or null when hidden. */
    @Nullable
    private String mLibraryMessage;

    /** Current library operation ID, or null when unowned. */
    @Nullable
    private String mLibraryOperationId;

    /** True while the library notification is showing. */
    private boolean mLibraryShowing;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs the singleton with the given application context.
     *
     * @param appContext Application context
     */
    private NotificationController(@NonNull Context appContext) {
        mContext = appContext;
        mNotificationManager = (NotificationManager)
            mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());

        final int cacheSize = MAX_CACHE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
        };

        createChannels();
        registerThemeReceiver();

        mPlayPauseIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mNextIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_NEXT);
        mPreviousIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
    }

    // ========================================================================
    // Playback — Service Binding
    // ========================================================================

    /**
     * Binds the playback surface to a service instance.
     *
     * <p>Called from {@link MusicService#onCreate()}. The controller may
     * be reused across service instances; a previous binding is replaced
     * by the new one.</p>
     *
     * @param service Service instance to bind
     */
    public void attachService(@NonNull Service service) {
        mService = service;
    }

    /**
     * Unbinds from the service and clears every playback render field.
     *
     * <p>Called from {@link MusicService#onDestroy()}. Runs synchronously
     * on the main thread; posting the cleanup would delay it past the
     * point at which the process may be torn down.</p>
     */
    public void detachService() {
        stopAwareness();
        stopRenderTimer();
        mStateSource = null;
        mSessionTokenProvider = null;
        mPerceivedSnapshot = null;
        mLastRenderedSnapshot = null;
        mPlaybackForeground.set(false);
        mPlaybackState = new PlaybackState(STATE_RESTING, false, "", "",
            null, null, "");
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
        mService = null;
    }

    /**
     * Installs the source of committed state.
     *
     * <p>Passing null stops the awareness poll.</p>
     *
     * @param source Source to install, or null to disable awareness
     */
    public void setStateSource(@Nullable ServiceStateSource source) {
        mStateSource = source;
        if (source == null) {
            stopAwareness();
        } else {
            startAwareness();
        }
    }

    /**
     * Installs the supplier that provides the active media session token
     * used to bind MediaStyle to the session.
     *
     * @param provider Token supplier, or null to clear
     */
    public void setSessionTokenProvider(@Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }

    /**
     * Posts the current playback notification and promotes the service
     * to the foreground.
     *
     * <p>Called from {@link MusicService#onStartCommand(Intent, int, int)}
     * and from the play-start continuations.
     * {@code startForeground} is idempotent; a repeat call with the same
     * identifier is treated as an update by the framework.</p>
     */
    public void startForegroundSync() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null || mNotificationManager == null) {
                return;
            }
            try {
                Notification notification = buildPlaybackNotification(mPlaybackState);
                mNotificationManager.notify(ID_PLAYBACK, notification);
                service.startForeground(ID_PLAYBACK, notification);
                mPlaybackForeground.set(true);
            } catch (Exception exception) {
                Log.e(TAG, "startForegroundSync failed", exception);
            }
        }
    }

    /**
     * Drops the foreground promotion while keeping the notification
     * posted.
     *
     * <p>Called from {@link MusicService#doPause()} so the paused
     * notification becomes dismissible.</p>
     */
    public void demoteFromForeground() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null) {
                return;
            }
            if (!mPlaybackForeground.getAndSet(false)) {
                return;
            }
            try {
                service.stopForeground(false);
            } catch (Exception exception) {
                Log.e(TAG, "demoteFromForeground failed", exception);
            }
        }
    }

    /**
     * Cancels the playback notification and resets the rendered state to
     * the resting state.
     *
     * <p>Called from {@link MusicService#transitionToIdle()} so a full
     * library wipe removes the playback notification immediately, without
     * waiting for the awareness poll to observe the idle service.</p>
     *
     * <p>The awareness poll and the service binding are left intact;
     * only the notification and the rendered state are cleared.</p>
     */
    public void clearPlaybackNotification() {
        synchronized (mPlaybackLock) {
            mPerceivedSnapshot = null;
            mLastRenderedSnapshot = null;
            mPlaybackForeground.set(false);
            mPlaybackState = new PlaybackState(STATE_RESTING, false, "", "",
                null, null, "");
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
    }

    // ========================================================================
    // Playback — Awareness Poll
    // ========================================================================

    /**
     * Starts the awareness poll. A second call while the poll is already
     * running does nothing.
     */
    private void startAwareness() {
        if (mAwarenessRunnable != null) {
            return;
        }
        mAwarenessRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    pollOnce();
                } catch (Exception exception) {
                    Log.e(TAG, "awareness poll failed", exception);
                }
                if (mAwarenessRunnable != null) {
                    mMainHandler.postDelayed(this, AWARENESS_INTERVAL_MS);
                }
            }
        };
        mMainHandler.post(mAwarenessRunnable);
    }

    /**
     * Runs a single awareness tick.
     *
     * <p>Reads the service's committed snapshot and arms the render
     * timer when the snapshot has changed. A null source and an idle
     * service are treated as no change.</p>
     */
    private void pollOnce() {
        ServiceStateSource source = mStateSource;
        if (source == null) {
            return;
        }

        if (source.isIdle()) {
            if (mPerceivedSnapshot != null || mLastRenderedSnapshot != null) {
                mPerceivedSnapshot = null;
                armRender();
            }
            return;
        }

        RenderSnapshot snapshot = source.snapshotForNotification();
        if (snapshot != null && !snapshot.equals(mPerceivedSnapshot)) {
            mPerceivedSnapshot = snapshot;
            armRender();
        }
    }

    /**
     * Stops the awareness poll. Idempotent.
     */
    private void stopAwareness() {
        if (mAwarenessRunnable != null) {
            mMainHandler.removeCallbacks(mAwarenessRunnable);
            mAwarenessRunnable = null;
        }
    }

    // ========================================================================
    // Playback — Debounced Atomic Render
    // ========================================================================

    /**
     * Arms the render timer.
     *
     * <p>A subsequent call before the timer fires resets it. When the
     * timer fires, it reads the current perceived snapshot, so a burst of
     * changes collapses to a single render of the final state.</p>
     */
    private void armRender() {
        stopRenderTimer();
        mRenderRunnable = new Runnable() {
            @Override
            public void run() {
                mRenderRunnable = null;
                RenderSnapshot snapshot = mPerceivedSnapshot;
                if (Objects.equals(snapshot, mLastRenderedSnapshot)) {
                    return;
                }
                applySnapshot(snapshot);
                mLastRenderedSnapshot = snapshot;
            }
        };
        mMainHandler.postDelayed(mRenderRunnable, RENDERING_INTERVAL_MS);
    }

    /**
     * Cancels any pending render. Idempotent.
     */
    private void stopRenderTimer() {
        if (mRenderRunnable != null) {
            mMainHandler.removeCallbacks(mRenderRunnable);
            mRenderRunnable = null;
        }
    }

    /**
     * Applies the given snapshot as the current rendered state.
     *
     * <p>Every field the playback notification draws is written in a
     * single atomic {@link PlaybackState} transition. No two-step
     * updates.</p>
     *
     * <p>When the snapshot's art is still being decoded, the previous
     * bitmap is held rather than replaced with a placeholder. The
     * notification continues to show the outgoing song's art until the
     * incoming song's art resolves, at which point the single swap to
     * the final bitmap, or to the placeholder when the song has no art,
     * is the only visible change.</p>
     *
     * @param snapshot Snapshot to render, or null to clear
     */
    private void applySnapshot(@Nullable RenderSnapshot snapshot) {
        PlaybackState previousState = mPlaybackState;
        PlaybackState nextState;

        if (snapshot == null) {
            nextState = new PlaybackState(STATE_RESTING, false, "", "",
                null, null, "");
        } else {
            boolean songChanged = previousState == null
                || !snapshot.path.equals(previousState.songPath);

            Bitmap albumArt = null;
            String artKey = null;

            if (snapshot.art != null && !snapshot.art.isRecycled()) {
                // The song's art is decoded and available. Cache it and use
                // it. This is the fast path for the incoming song when its
                // art was already in the LRU cache from a previous play.
                Bitmap cachedArt = mAlbumArtCache.get(snapshot.path);
                if (cachedArt != null && !cachedArt.isRecycled()) {
                    albumArt = cachedArt;
                } else {
                    Bitmap safeCopy = createSafeCopy(snapshot.art, MAX_ART_SIZE);
                    if (safeCopy != null) {
                        mAlbumArtCache.put(snapshot.path, safeCopy);
                        albumArt = safeCopy;
                    }
                }
                if (albumArt != null) {
                    artKey = snapshot.path;
                }
            } else if (!snapshot.artResolved) {
                // The decode for the incoming song is still in flight. Hold
                // the previous bitmap — whatever is currently on screen —
                // so the notification does not flash a placeholder and then
                // swap to the real art a moment later. The next snapshot,
                // with artResolved true, commits the final state in one
                // swap. The hold is independent of whether the song
                // changed: it is the resolution state, not the song
                // identity, that decides whether the render is final.
                albumArt = previousState.albumArt;
                artKey = previousState.artKey;
            } else if (!songChanged) {
                // Song unchanged and its art resolved to null. Hold the
                // previous bitmap, which is null in the common case, so an
                // idempotent render does not needlessly touch the
                // notification.
                albumArt = previousState.albumArt;
                artKey = previousState.artKey;
            }
            // Else: art resolved to null and the song changed. The new song
            // has no art. The notification builder falls back to the themed
            // placeholder, which is the honest final state for a song
            // without embedded art. This is the one case that
            // intentionally swaps the displayed bitmap, and it happens
            // exactly once per song without art.

            nextState = new PlaybackState(
                snapshot.isPlaying ? STATE_PLAYING : STATE_PAUSED,
                snapshot.isPlaying,
                snapshot.title,
                snapshot.artist,
                albumArt,
                artKey,
                snapshot.path);
        }

        mPlaybackState = nextState;
        performPlaybackUpdate();
    }

    /**
     * Posts or cancels the playback notification according to the
     * current rendered state, and arbitrates the foreground promotion.
     */
    private void performPlaybackUpdate() {
        synchronized (mPlaybackLock) {
            if (mNotificationManager == null) {
                return;
            }
            try {
                PlaybackState state = mPlaybackState;
                boolean valid = !state.isResting()
                    && state.title != null && !state.title.isEmpty();

                if (valid) {
                    Notification notification = buildPlaybackNotification(state);
                    mNotificationManager.notify(ID_PLAYBACK, notification);

                    if (STATE_PLAYING.equals(state.channelState)) {
                        Service service = mService;
                        if (service != null && !mPlaybackForeground.getAndSet(true)) {
                            service.startForeground(ID_PLAYBACK, notification);
                        }
                    } else {
                        if (mService != null) {
                            demoteFromForeground();
                        }
                    }
                } else {
                    mNotificationManager.cancel(ID_PLAYBACK);
                    if (mService != null) {
                        demoteFromForeground();
                    }
                }
            } catch (SecurityException exception) {
                Log.e(TAG, "Missing notification permission", exception);
            } catch (Exception exception) {
                Log.e(TAG, "performPlaybackUpdate failed", exception);
            }
        }
    }

    // ========================================================================
    // Playback — Notification Builder
    // ========================================================================

    /**
     * Builds the playback notification from the given state.
     *
     * <p>Transport actions are dispatched through
     * {@link MediaButtonReceiver#buildMediaButtonPendingIntent}, so a tap
     * flows through the active {@link MediaSessionCompat}. The close
     * action and the swipe-away delete intent both send
     * {@code ACTION_STOP} to the service.</p>
     *
     * <p>When the state carries no art of its own — the resting state on
     * cold start, or a song without embedded art — the large icon falls
     * back to the themed placeholder produced by
     * {@link #getThemedPlaceholder()}.</p>
     *
     * @param state Rendered state to build from
     * @return The built notification
     */
    @NonNull
    private Notification buildPlaybackNotification(@NonNull PlaybackState state) {
        final int themeColor = resolveThemeColor();
        final int pendingIntentFlags = buildPendingIntentFlags();

        PendingIntent contentIntent = buildContentIntent(pendingIntentFlags);
        PendingIntent closeIntent = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            pendingIntentFlags);
        PendingIntent deleteIntent = PendingIntent.getService(mContext, 5,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            pendingIntentFlags);

        final boolean isResting = state.isResting();
        String displayTitle  = isResting ? PLACEHOLDER_TITLE  : state.title;
        String displayArtist = isResting ? PLACEHOLDER_ARTIST : state.artist;

        if (displayTitle.length() > MAX_TITLE_LENGTH) {
            displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (displayArtist.length() > MAX_ARTIST_LENGTH) {
            displayArtist = displayArtist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_PLAYBACK);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle(displayTitle)
               .setContentText(displayArtist)
               .setColor(themeColor)
               .setContentIntent(contentIntent)
               .setDeleteIntent(deleteIntent)
               .setOngoing(state.isPlaying)
               .setVisibility(Notification.VISIBILITY_PUBLIC)
               .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(
                Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }

        if (mPreviousIntent != null) {
            addAction(builder, R.drawable.ic_notification_prev, "Prev",
                mPreviousIntent, NEUTRAL_COLOR);
        }
        if (mPlayPauseIntent != null) {
            int playPauseIcon = state.isPlaying
                ? R.drawable.ic_notification_pause
                : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying ? "Pause" : "Play";
            addAction(builder, playPauseIcon, playPauseLabel, mPlayPauseIntent, themeColor);
        }
        if (mNextIntent != null) {
            addAction(builder, R.drawable.ic_notification_next, "Next",
                mNextIntent, NEUTRAL_COLOR);
        }
        addAction(builder, R.drawable.ic_notification_close, "Close",
            closeIntent, RED_COLOR);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Notification.MediaStyle mediaStyle = new Notification.MediaStyle();
            mediaStyle.setShowActionsInCompactView(0, 1, 2);
            MediaSessionCompat.Token sessionToken =
                mSessionTokenProvider != null ? mSessionTokenProvider.get() : null;
            if (sessionToken != null) {
                Object rawToken = sessionToken.getToken();
                if (rawToken instanceof android.media.session.MediaSession.Token) {
                    mediaStyle.setMediaSession(
                        (android.media.session.MediaSession.Token) rawToken);
                }
            }
            builder.setStyle(mediaStyle);
        }

        return builder.build();
    }

    /**
     * Adds a themed action button to the notification.
     *
     * <p>On API 23 and later, the icon is converted to a themed
     * {@link Icon}; on earlier versions, the drawable resource is used
     * directly.</p>
     *
     * @param builder Notification builder to add the action to
     * @param iconRes Icon resource identifier
     * @param label Button label
     * @param intent Pending intent to fire on tap
     * @param color Icon tint
     */
    private void addAction(@NonNull Notification.Builder builder, int iconRes,
                           @NonNull String label, @NonNull PendingIntent intent,
                           int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon themedIcon = createThemedIcon(iconRes, color);
            if (themedIcon != null) {
                builder.addAction(
                    new Notification.Action.Builder(themedIcon, label, intent).build());
                return;
            }
        }
        //noinspection deprecation
        builder.addAction(new Notification.Action.Builder(iconRes, label, intent).build());
    }

    /**
     * Returns the large icon for the notification.
     *
     * <p>When the current song has art, that art is used. When it has
     * none, or when no song is bound, the app's themed placeholder is
     * used instead.</p>
     *
     * @param state Rendered state to build the icon for
     * @return The large icon, or null when the placeholder cannot be
     *         built
     */
    @Nullable
    private Bitmap getSafeLargeIcon(@NonNull PlaybackState state) {
        if (state.artKey != null) {
            Bitmap cachedArt = mAlbumArtCache.get(state.artKey);
            if (cachedArt != null && !cachedArt.isRecycled()) {
                return cachedArt;
            }
        }
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        return getThemedPlaceholder();
    }

    // ========================================================================
    // Playback — Themed Placeholder
    // ========================================================================

    /**
     * Returns the themed placeholder bitmap for the notification large
     * icon, building and caching it lazily.
     *
     * <p>The cache is keyed by theme color: a theme change invalidates
     * it and the next call rebuilds. Runs on the main thread; the bitmap
     * is bounded by {@link #MAX_ART_SIZE}.</p>
     *
     * @return The themed placeholder bitmap, or null when the drawable
     *         cannot be decoded
     */
    @Nullable
    private Bitmap getThemedPlaceholder() {
        final int themeColor = resolveThemeColor();
        final Bitmap cached = mThemedPlaceholder;
        if (cached != null && !cached.isRecycled()
                && mThemedPlaceholderColor == themeColor) {
            return cached;
        }
        final Bitmap built = buildThemedPlaceholder(themeColor);
        if (built != null) {
            mThemedPlaceholder = built;
            mThemedPlaceholderColor = themeColor;
        }
        return built;
    }

    /**
     * Builds a themed placeholder bitmap by decoding
     * {@code R.drawable.album_art_placeholder} and tinting it with the
     * given color.
     *
     * <p>Downsamples to {@link #MAX_ART_SIZE} on the longer side and uses
     * {@link PorterDuff.Mode#SRC_IN} so the tint replaces the drawable's
     * own color while preserving its alpha, the same mode
     * {@code MusicPlayer.updatePlaceholderBitmap()} uses.</p>
     *
     * @param themeColor Tint color
     * @return The tinted bitmap, or null when the drawable cannot be
     *         built
     */
    @Nullable
    private Bitmap buildThemedPlaceholder(int themeColor) {
        try {
            final Drawable drawable = ContextCompat.getDrawable(
                mContext, R.drawable.album_art_placeholder);
            if (drawable == null) {
                return null;
            }

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = MAX_ART_SIZE;
                height = MAX_ART_SIZE;
            }

            final float scale = Math.min(
                (float) MAX_ART_SIZE / width,
                (float) MAX_ART_SIZE / height);
            if (scale < 1f) {
                width = Math.max(1, Math.round(width * scale));
                height = Math.max(1, Math.round(height * scale));
            }

            final Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, width, height);
            drawable.setColorFilter(
                new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception exception) {
            Log.e(TAG, "buildThemedPlaceholder failed", exception);
            return null;
        }
    }

    // ========================================================================
    // Theme Receiver
    // ========================================================================

    /**
     * Registers a receiver for theme color changes so the placeholder
     * cache is invalidated and the currently displayed notification is
     * rebuilt with the new tint.
     *
     * <p>Registered on the application context; the singleton's lifetime
     * is the process's, so no explicit registration window is needed. The
     * receiver is torn down in {@link #shutdown()}.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    onThemeChanged();
                }
            }
        };
        mContext.registerReceiver(
            mThemeReceiver, new IntentFilter(ACTION_THEME_COLOR_CHANGED));
    }

    /**
     * Unregisters the theme receiver. Safe to call multiple times.
     */
    private void unregisterThemeReceiver() {
        if (mThemeReceiver != null) {
            try {
                mContext.unregisterReceiver(mThemeReceiver);
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reacts to a theme color change.
     *
     * <p>A song-backed notification is rebuilt through
     * {@link #performPlaybackUpdate()}, which preserves the foreground
     * arbitration the normal render path does. A resting notification is
     * rebuilt in place, since it is already in the foreground and the
     * rebuild must not touch foreground state.</p>
     *
     * <p>When no notification is showing, this method does nothing. The
     * stale placeholder in {@link #mThemedPlaceholder} is not a problem:
     * {@link #getThemedPlaceholder()} compares its cached color against
     * the current theme on the next call and rebuilds on mismatch.</p>
     */
    private void onThemeChanged() {
        if (mNotificationManager == null || mService == null) {
            return;
        }

        if (!mPlaybackState.isResting()) {
            performPlaybackUpdate();
            return;
        }

        if (!mPlaybackForeground.get()) {
            // Resting and not currently shown, so there is nothing to
            // refresh.
            return;
        }

        synchronized (mPlaybackLock) {
            try {
                Notification notification = buildPlaybackNotification(mPlaybackState);
                mNotificationManager.notify(ID_PLAYBACK, notification);
            } catch (Exception exception) {
                Log.e(TAG, "theme refresh of resting notification failed", exception);
            }
        }
    }

    // ========================================================================
    // Library Surface
    // ========================================================================

    /**
     * Shows or replaces the library notification with the given message
     * and operation ID.
     *
     * <p>Operation IDs are ownership tokens. A subsequent
     * {@link #dismissLibraryStatus(String)} with a mismatched ID is
     * refused so a later operation cannot be hidden by an earlier one
     * completing. Passing null as the operation ID shows the
     * notification without an owner; it can be dismissed only with a
     * null ID or by {@link #clearLibraryStatus()}.</p>
     *
     * @param message Text to display
     * @param operationId Owner token, or null
     */
    public void showLibraryStatus(@NonNull String message, @Nullable String operationId) {
        synchronized (mLibraryLock) {
            mLibraryMessage = message;
            mLibraryOperationId = operationId;
            mLibraryShowing = true;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Updates the text on an already-showing library notification when
     * the operation ID matches.
     *
     * @param message New text to display
     * @param operationId Owner token to match
     */
    public void updateLibraryStatus(@NonNull String message, @Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return;
            }
            mLibraryMessage = message;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Dismisses the library notification when the operation ID matches.
     *
     * <p>Ownership-respecting dismiss. A null operation ID matches only a
     * notification that has no current owner. Callers that need to tear
     * the notification down regardless of ownership use
     * {@link #clearLibraryStatus()}.</p>
     *
     * @param operationId Owner token to match
     * @return True when the notification was dismissed
     */
    public boolean dismissLibraryStatus(@Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return false;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return false;
            }
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return true;
        }
    }

    /**
     * Tears the library notification down unconditionally, ignoring any
     * current owner.
     *
     * <p>Used by {@link ToastManager}'s recovery path, which owns the
     * lifecycle of the persistent overlay and clears the mirrored
     * notification even when the owning operation is mid-flight or has
     * been replaced.</p>
     *
     * @return True when a notification was cancelled
     */
    public boolean clearLibraryStatus() {
        synchronized (mLibraryLock) {
            boolean wasShowing = mLibraryShowing;
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return wasShowing;
        }
    }

    /**
     * Returns whether the library notification is currently showing.
     *
     * @return True when the library notification is showing
     */
    public boolean isLibraryStatusShowing() {
        synchronized (mLibraryLock) {
            return mLibraryShowing;
        }
    }

    /**
     * Returns the current library operation ID.
     *
     * @return The operation ID, or null when the notification is
     *         unowned
     */
    @Nullable
    public String getLibraryOperationId() {
        synchronized (mLibraryLock) {
            return mLibraryOperationId;
        }
    }

    /**
     * Posts the library notification. Callers must hold
     * {@link #mLibraryLock}.
     */
    private void performLibraryUpdateLocked() {
        String message = mLibraryMessage;
        if (message == null || mNotificationManager == null) {
            return;
        }
        try {
            mNotificationManager.notify(ID_LIBRARY, buildLibraryNotification(message));
        } catch (SecurityException exception) {
            Log.e(TAG, "Missing notification permission (library)", exception);
        } catch (Exception exception) {
            Log.e(TAG, "performLibraryUpdate failed", exception);
        }
    }

    /**
     * Builds the library notification.
     *
     * @param message Text to display
     * @return The built notification
     */
    @NonNull
    private Notification buildLibraryNotification(@NonNull String message) {
        final int pendingIntentFlags = buildPendingIntentFlags();
        PendingIntent contentIntent = buildContentIntent(pendingIntentFlags);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_LIBRARY);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle("Llama Music Player")
               .setContentText(message)
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setOnlyAlertOnce(true)
               .setShowWhen(false)
               .setColor(resolveThemeColor())
               .setPriority(Notification.PRIORITY_LOW)
               .setCategory(Notification.CATEGORY_PROGRESS);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    // ========================================================================
    // Shared Helpers
    // ========================================================================

    /**
     * Returns the shared PendingIntent flags for the current API level.
     *
     * @return The flags
     */
    private int buildPendingIntentFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    /**
     * Builds the content intent that launches the app.
     *
     * @param flags PendingIntent flags
     * @return The content PendingIntent
     */
    @NonNull
    private PendingIntent buildContentIntent(int flags) {
        return PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);
    }

    /**
     * Resolves the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The theme color as an integer
     */
    private int resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                return themeManager.getCurrentColorInt();
            }
            return ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    /**
     * Returns a downscaled copy of the given bitmap.
     *
     * @param source Bitmap to copy, or null
     * @param maxSize Maximum dimension of the copy, in pixels
     * @return The downscaled copy, or null on failure
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            if (width <= 0 || height <= 0) {
                return null;
            }
            Bitmap.Config config = source.getConfig() != null
                ? source.getConfig()
                : Bitmap.Config.ARGB_8888;
            if (width <= maxSize && height <= maxSize) {
                return source.copy(config, false);
            }
            float scale = Math.min((float) maxSize / width, (float) maxSize / height);
            return Bitmap.createScaledBitmap(source,
                Math.round(width * scale), Math.round(height * scale), true);
        } catch (Exception exception) {
            Log.e(TAG, "createSafeCopy failed", exception);
            return null;
        }
    }

    /**
     * Creates a themed icon for a notification action.
     *
     * @param drawableRes Drawable resource identifier
     * @param color Tint color
     * @return The themed icon, or null on failure
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);
            if (drawable == null) {
                return null;
            }
            drawable.setColorFilter(
                new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }

            Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            }
            return null;
        } catch (Exception exception) {
            Log.e(TAG, "createThemedIcon failed", exception);
            return null;
        }
    }

    // ========================================================================
    // Channels
    // ========================================================================

    /**
     * Creates the two notification channels on API 26 and later.
     * Idempotent; a second call is a no-op for channels that already
     * exist.
     */
    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || mNotificationManager == null) {
            return;
        }

        if (mNotificationManager.getNotificationChannel(CHANNEL_PLAYBACK) == null) {
            NotificationChannel playbackChannel = new NotificationChannel(
                CHANNEL_PLAYBACK, CHANNEL_PLAYBACK_NAME,
                NotificationManager.IMPORTANCE_DEFAULT);
            playbackChannel.setDescription(CHANNEL_PLAYBACK_DESC);
            playbackChannel.setShowBadge(false);
            playbackChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            playbackChannel.setSound(null, null);
            playbackChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(playbackChannel);
        }

        if (mNotificationManager.getNotificationChannel(CHANNEL_LIBRARY) == null) {
            NotificationChannel libraryChannel = new NotificationChannel(
                CHANNEL_LIBRARY, CHANNEL_LIBRARY_NAME,
                NotificationManager.IMPORTANCE_LOW);
            libraryChannel.setDescription(CHANNEL_LIBRARY_DESC);
            libraryChannel.setShowBadge(false);
            libraryChannel.setSound(null, null);
            libraryChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(libraryChannel);
        }
    }

    // ========================================================================
    // Shutdown
    // ========================================================================

    /**
     * Releases the singleton.
     *
     * <p>Called only at process teardown; never from an activity or
     * service lifecycle callback. Unregisters the theme receiver,
     * cancels both notifications, and clears every field including the
     * cached placeholder. After this method returns,
     * {@link #getInstance(Context)} builds a fresh instance on the next
     * call.</p>
     */
    public void shutdown() {
        stopAwareness();
        stopRenderTimer();
        unregisterThemeReceiver();

        synchronized (mLibraryLock) {
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
        }
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
                mNotificationManager.cancel(ID_LIBRARY);
            }
        }
        mPlaybackForeground.set(false);
        mService = null;
        mStateSource = null;
        mThemedPlaceholder = null;
        mThemedPlaceholderColor = 0;
        sInstance = null;
    }
}