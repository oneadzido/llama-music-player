package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.media.session.MediaButtonReceiver;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * NotificationController — sole owner of every notification surface the app
 * produces.
 *
 * <p>Two notification IDs on two channels:</p>
 * <ul>
 *   <li><b>{@link #ID_PLAYBACK} — playback</b> ({@code music_playback_channel}).
 *       The playback notification. Bound to {@link MusicService}'s committed
 *       state through a {@link ServiceStateSource}. Foreground-eligible.
 *       Rendered by an awareness poll ({@code AWARENESS_INTERVAL_MS}) and a
 *       debounced atomic render ({@code SETTLE_MS}).</li>
 *   <li><b>{@link #ID_LIBRARY} — library</b> ({@code music_library_channel}).
 *       Mirrors {@link ToastManager}'s persistent-overlay lifecycle. Never
 *       foreground. Independent of {@link MusicService}.</li>
 * </ul>
 *
 * <h3>Playback Render Contract</h3>
 * <p>The playback notification never renders a state the service has not
 * committed to. During PREPARING the service has not committed to the
 * destination, so {@link ServiceStateSource#snapshotForNotification()}
 * returns null and the last complete render is held. Every render is a
 * single atomic transition carrying title, artist, play flag, and art
 * together — the notification manager never observes a partial update.</p>
 *
 * <h3>Awareness and Render</h3>
 * <p>Awareness runs on a fixed {@code AWARENESS_INTERVAL_MS} cadence
 * regardless of service state. Its only job is to detect changes in the
 * service's committed snapshot. When the snapshot differs from what the
 * controller has perceived, the render timer is armed. If another change
 * arrives before the timer fires, the timer resets. When the timer finally
 * elapses, the controller renders the <em>current</em> perceived snapshot
 * — not the one that armed the timer — so a burst of rapid changes
 * collapses into a single render.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Process-wide singleton. {@link MusicService} calls
 * {@link #attachService(Service)} in {@code onCreate} and
 * {@link #detachService()} in {@code onDestroy}. The library surface does
 * not depend on the media service being attached.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public final class NotificationController {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "NotificationController";

    /** Notification ID for the playback notification. */
    public static final int ID_PLAYBACK = 1;

    /** Notification ID for the library notification. */
    public static final int ID_LIBRARY = 2;

    /** Playback channel identifier. */
    private static final String CHANNEL_PLAYBACK = "music_playback_channel";

    /** Playback channel display name. */
    private static final String CHANNEL_PLAYBACK_NAME = "Playback";

    /** Playback channel description. */
    private static final String CHANNEL_PLAYBACK_DESC = "Music playback controls";

    /** Library channel identifier. */
    private static final String CHANNEL_LIBRARY = "music_library_channel";

    /** Library channel display name. */
    private static final String CHANNEL_LIBRARY_NAME = "Library";

    /** Library channel description. */
    private static final String CHANNEL_LIBRARY_DESC = "Music library updates";

    /** Small icon shared by both notifications. */
    private static final int SMALL_ICON_RES = R.drawable.ic_notification;

    /** Maximum size for album art in pixels. */
    private static final int MAX_ART_SIZE = 300;

    /** Cache size for album art in megabytes. */
    private static final int MAX_CACHE_MB = 25;

    /** Neutral tint for transport action icons. */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;

    /** Red tint for the close action icon. */
    private static final int RED_COLOR = 0xFFE53935;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;

    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";

    /** Fallback icon size for themed action icons. */
    private static final int DEFAULT_ICON_SIZE = 96;

    /** Placeholder title shown when no song is committed. */
    private static final String PLACEHOLDER_TITLE = "Title";

    /** Placeholder artist shown when no song is committed. */
    private static final String PLACEHOLDER_ARTIST = "Artist";

    /** Channel state string for the resting state. */
    private static final String STATE_RESTING = "Resting";

    /** Channel state string for the playing state. */
    private static final String STATE_PLAYING = "Playing";

    /** Channel state string for the paused state. */
    private static final String STATE_PAUSED = "Paused";

    /**
     * Awareness poll interval in milliseconds. Fast enough that a commit is
     * perceived within one frame of {@code onPlaybackStarted}.
     */
    private static final long AWARENESS_INTERVAL_MS = 100L;

    /**
     * Quiet period before a perceived change is rendered.
     *
     * <p>Must be greater than {@link #AWARENESS_INTERVAL_MS} so a settled
     * commit is not re-rendered on the following awareness tick, and less
     * than the transport debounce (500 ms in both {@code MusicService} and
     * the activity) so a single tap is rendered before the next tap is
     * accepted. 400 sits one tick above the former and one tick below the
     * latter.</p>
     */
    private static final long SETTLE_MS = 400L;

    /** Default theme color fallback (Royal Llama). */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    // ========================================================================
    // Collaborator Interfaces and Data Carriers
    // ========================================================================

    /**
     * Read-only view of {@link MusicService}'s committed state.
     *
     * <p>All calls run on the main thread. Implementations must not block.</p>
     */
    public interface ServiceStateSource {

        /**
         * A complete, renderable snapshot, or null when the service has
         * nothing new to render.
         *
         * <p>Returns null while the service is in a state that has nothing
         * committed to render — PREPARING (a transition is in flight) or
         * IDLE with no song bound. In both cases the last committed render
         * is held.</p>
         *
         * @return a complete renderable snapshot, or null
         */
        @Nullable
        RenderSnapshot snapshotForNotification();

        /**
         * True when the service has nothing renderable and the playback
         * notification should clear.
         *
         * @return true if the service is idle
         */
        boolean isIdle();
    }

    /**
     * Immutable, complete picture of the service.
     *
     * <p>A non-null snapshot is everything the playback notification
     * needs: title, artist, path, play flag, and art. Rendering it is a
     * single atomic transition.</p>
     */
    public static final class RenderSnapshot {

        /** Song title. */
        @NonNull
        public final String title;

        /** Artist name. */
        @NonNull
        public final String artist;

        /** File path used as the album art cache key. */
        @NonNull
        public final String path;

        /** True while the state machine is in PLAYING. */
        public final boolean isPlaying;

        /** Decoded art for this path, or null if the song has none. */
        @Nullable
        public final Bitmap art;

        /**
         * Constructs a new RenderSnapshot.
         *
         * @param title     the song title
         * @param artist    the artist name
         * @param path      the file path
         * @param isPlaying true if the state machine is in PLAYING
         * @param art       the decoded art, or null
         */
        public RenderSnapshot(@NonNull String title, @NonNull String artist,
                              @NonNull String path, boolean isPlaying,
                              @Nullable Bitmap art) {
            this.title = title;
            this.artist = artist;
            this.path = path;
            this.isPlaying = isPlaying;
            this.art = art;
        }

        @Override
        public boolean equals(@Nullable Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || getClass() != object.getClass()) {
                return false;
            }
            RenderSnapshot snapshot = (RenderSnapshot) object;
            return isPlaying == snapshot.isPlaying
                && title.equals(snapshot.title)
                && artist.equals(snapshot.artist)
                && path.equals(snapshot.path)
                && art == snapshot.art;
        }

        @Override
        public int hashCode() {
            return Objects.hash(title, artist, path, isPlaying);
        }
    }

    /**
     * Internal rendered state for the playback notification. Written only
     * inside {@link #applySnapshot(RenderSnapshot)}; read only inside
     * {@link #performPlaybackUpdate()} and
     * {@link #buildPlaybackNotification(PlaybackState)}.
     */
    private static final class PlaybackState {

        final String channelState;
        final boolean isPlaying;
        final String title;
        final String artist;
        @Nullable final Bitmap albumArt;
        @Nullable final Bitmap placeholder;
        @Nullable final String artKey;
        @Nullable final String songPath;

        PlaybackState(String channelState, boolean isPlaying, String title,
                      String artist, @Nullable Bitmap albumArt,
                      @Nullable Bitmap placeholder, @Nullable String artKey,
                      @Nullable String songPath) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.placeholder = placeholder;
            this.artKey = artKey;
            this.songPath = songPath;
        }

        boolean isResting() {
            return STATE_RESTING.equals(channelState);
        }
    }

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance (volatile for thread-safe double-checked locking). */
    @Nullable
    private static volatile NotificationController sInstance;

    /**
     * Returns the process-wide singleton.
     *
     * @param context any context (converted to application context)
     * @return the singleton instance
     */
    @NonNull
    public static NotificationController getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (NotificationController.class) {
                if (sInstance == null) {
                    sInstance = new NotificationController(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Fields
    // ========================================================================

    /** Application context. */
    @NonNull
    private final Context mContext;

    /** System notification manager. */
    @Nullable
    private final NotificationManager mNotificationManager;

    /** Main thread handler for awareness and render posts. */
    @NonNull
    private final Handler mMainHandler;

    /** Album art cache keyed by song path. */
    @NonNull
    private final LruCache<String, Bitmap> mAlbumArtCache;

    /** Lock for the playback notification IPC and foreground arbitration. */
    @NonNull
    private final Object mPlaybackLock = new Object();

    /** Lock for library notification state and IPC. */
    @NonNull
    private final Object mLibraryLock = new Object();

    // ---- Playback surface ----

    /** Bound service; non-null only between attach and detach. */
    @Nullable
    private Service mService;

    /** Source of committed state; null when no service is attached. */
    @Nullable
    private ServiceStateSource mStateSource;

    /** Session-token provider used to bind MediaStyle to the active session. */
    @Nullable
    private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;

    /** Cached transport PendingIntent for play/pause. */
    @Nullable
    private PendingIntent mPlayPauseIntent;

    /** Cached transport PendingIntent for skip-to-next. */
    @Nullable
    private PendingIntent mNextIntent;

    /** Cached transport PendingIntent for skip-to-previous. */
    @Nullable
    private PendingIntent mPreviousIntent;

    /** Current rendered playback state. */
    @NonNull
    private volatile PlaybackState mPlaybackState =
        new PlaybackState(STATE_RESTING, false, "", "", null, null, null, "");

    /** True while the service holds the foreground promotion. */
    @NonNull
    private final AtomicBoolean mPlaybackForeground = new AtomicBoolean(false);

    /** Last perceived snapshot from the state source. */
    @Nullable
    private RenderSnapshot mPerceivedSnapshot;

    /** Last rendered snapshot. */
    @Nullable
    private RenderSnapshot mLastRenderedSnapshot;

    /** Awareness runnable, null when stopped. */
    @Nullable
    private Runnable mAwarenessRunnable;

    /** Render timer runnable, null when not armed. */
    @Nullable
    private Runnable mRenderRunnable;

    // ---- Library surface ----

    /** Current library notification text. */
    @Nullable
    private String mLibraryMessage;

    /** Current library operation ID (ownership token). */
    @Nullable
    private String mLibraryOperationId;

    /** True while the library notification is showing. */
    private boolean mLibraryShowing;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Private constructor for singleton pattern.
     *
     * @param appContext the application context
     */
    private NotificationController(@NonNull Context appContext) {
        mContext = appContext;
        mNotificationManager = (NotificationManager)
            mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());

        final int cacheSize = MAX_CACHE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
        };

        createChannels();

        mPlayPauseIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mNextIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_NEXT);
        mPreviousIntent = MediaButtonReceiver.buildMediaButtonPendingIntent(
            mContext, PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
    }

    // ========================================================================
    // Playback — Service Binding
    // ========================================================================

    /**
     * Binds the playback surface to a service instance. Called from
     * {@code MusicService.onCreate}. The controller may be reused across
     * service instances; the previous binding is replaced.
     *
     * @param service the bound service instance
     */
    public void attachService(@NonNull Service service) {
        mService = service;
    }

    /**
     * Unbinds from the service and clears all playback render state.
     * Called from {@code MusicService.onDestroy}.
     *
     * <p>Runs synchronously. {@code MusicService.onDestroy} is always on
     * the main thread; posting the cleanup would delay it past the point
     * where the process might be torn down.</p>
     */
    public void detachService() {
        stopAwareness();
        stopRenderTimer();
        mStateSource = null;
        mSessionTokenProvider = null;
        mPerceivedSnapshot = null;
        mLastRenderedSnapshot = null;
        mPlaybackForeground.set(false);
        mPlaybackState = new PlaybackState(STATE_RESTING, false, "", "",
            null, null, null, "");
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
        mService = null;
    }

    /**
     * Installs the source of committed state. Passing null stops awareness.
     *
     * @param source the state source, or null to disable
     */
    public void setStateSource(@Nullable ServiceStateSource source) {
        mStateSource = source;
        if (source == null) {
            stopAwareness();
        } else {
            startAwareness();
        }
    }

    /**
     * Installs the supplier used to obtain the active
     * {@link MediaSessionCompat} token for MediaStyle binding.
     *
     * @param provider the token supplier, or null to clear
     */
    public void setSessionTokenProvider(@Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }

    /**
     * Synchronously posts the current playback notification and promotes
     * the service to foreground. Called from
     * {@code MusicService.onStartCommand} and from the play-start
     * continuations.
     *
     * <p>{@code startForeground} is idempotent; a repeat call with the same
     * ID is treated as an update by the framework.</p>
     */
    public void startForegroundSync() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null || mNotificationManager == null) {
                return;
            }
            try {
                Notification notification = buildPlaybackNotification(mPlaybackState);
                mNotificationManager.notify(ID_PLAYBACK, notification);
                service.startForeground(ID_PLAYBACK, notification);
                mPlaybackForeground.set(true);
            } catch (Exception exception) {
                Log.e(TAG, "startForegroundSync failed", exception);
            }
        }
    }

    /**
     * Drops the foreground promotion while keeping the notification posted.
     * Called from {@code MusicService.doPause} so the paused notification
     * is dismissible.
     */
    public void demoteFromForeground() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null) {
                return;
            }
            if (!mPlaybackForeground.getAndSet(false)) {
                return;
            }
            try {
                service.stopForeground(false);
            } catch (Exception exception) {
                Log.e(TAG, "demoteFromForeground failed", exception);
            }
        }
    }

    // ========================================================================
    // Playback — Awareness Poll
    // ========================================================================

    /**
     * Starts the awareness poll. Idempotent; a second call is a no-op.
     */
    private void startAwareness() {
        if (mAwarenessRunnable != null) {
            return;
        }
        mAwarenessRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    pollOnce();
                } catch (Exception exception) {
                    Log.e(TAG, "awareness poll failed", exception);
                }
                if (mAwarenessRunnable != null) {
                    mMainHandler.postDelayed(this, AWARENESS_INTERVAL_MS);
                }
            }
        };
        mMainHandler.post(mAwarenessRunnable);
    }

    /**
     * One awareness tick. Reads the service's committed snapshot and arms
     * the render timer when the snapshot has changed.
     */
    private void pollOnce() {
        ServiceStateSource source = mStateSource;
        if (source == null) {
            return;
        }

        if (source.isIdle()) {
            if (mPerceivedSnapshot != null || mLastRenderedSnapshot != null) {
                mPerceivedSnapshot = null;
                armRender();
            }
            return;
        }

        RenderSnapshot snapshot = source.snapshotForNotification();
        if (snapshot != null && !snapshot.equals(mPerceivedSnapshot)) {
            mPerceivedSnapshot = snapshot;
            armRender();
        }
    }

    /**
     * Stops the awareness poll. Idempotent.
     */
    private void stopAwareness() {
        if (mAwarenessRunnable != null) {
            mMainHandler.removeCallbacks(mAwarenessRunnable);
            mAwarenessRunnable = null;
        }
    }

    // ========================================================================
    // Playback — Debounced Atomic Render
    // ========================================================================

    /**
     * Arms the render timer. A subsequent call before the timer fires
     * resets it. The timer reads {@link #mPerceivedSnapshot} when it fires,
     * so a burst of changes collapses to a single render of the final
     * state.
     */
    private void armRender() {
        stopRenderTimer();
        mRenderRunnable = new Runnable() {
            @Override
            public void run() {
                mRenderRunnable = null;
                RenderSnapshot snapshot = mPerceivedSnapshot;
                if (Objects.equals(snapshot, mLastRenderedSnapshot)) {
                    return;
                }
                applySnapshot(snapshot);
                mLastRenderedSnapshot = snapshot;
            }
        };
        mMainHandler.postDelayed(mRenderRunnable, SETTLE_MS);
    }

    /**
     * Cancels any pending render. Idempotent.
     */
    private void stopRenderTimer() {
        if (mRenderRunnable != null) {
            mMainHandler.removeCallbacks(mRenderRunnable);
            mRenderRunnable = null;
        }
    }

    /**
     * Applies a snapshot as the current rendered state.
     *
     * <p>Every field the playback notification draws is written here, in
     * one atomic {@link PlaybackState} transition. No two-step updates.</p>
     *
     * @param snapshot the snapshot to render, or null to clear
     */
    private void applySnapshot(@Nullable RenderSnapshot snapshot) {
        PlaybackState previousState = mPlaybackState;
        PlaybackState nextState;

        if (snapshot == null) {
            nextState = new PlaybackState(STATE_RESTING, false, "", "",
                null,
                previousState != null ? previousState.placeholder : null,
                null, "");
        } else {
            boolean songChanged = previousState == null
                || !snapshot.path.equals(previousState.songPath);

            Bitmap albumArt = null;
            String artKey = null;

            if (snapshot.art != null && !snapshot.art.isRecycled()) {
                Bitmap cachedArt = mAlbumArtCache.get(snapshot.path);
                if (cachedArt != null && !cachedArt.isRecycled()) {
                    albumArt = cachedArt;
                } else {
                    Bitmap safeCopy = createSafeCopy(snapshot.art, MAX_ART_SIZE);
                    if (safeCopy != null) {
                        mAlbumArtCache.put(snapshot.path, safeCopy);
                        albumArt = safeCopy;
                    }
                }
                if (albumArt != null) {
                    artKey = snapshot.path;
                }
            } else if (!songChanged) {
                // No art provided and the song has not changed: hold the
                // previous bitmap so the notification does not flicker.
                albumArt = previousState.albumArt;
                artKey = previousState.artKey;
            }
            // Else: song changed and no art is available for it. The
            // notification will render the placeholder.

            nextState = new PlaybackState(
                snapshot.isPlaying ? STATE_PLAYING : STATE_PAUSED,
                snapshot.isPlaying,
                snapshot.title,
                snapshot.artist,
                albumArt,
                previousState != null ? previousState.placeholder : null,
                artKey,
                snapshot.path);
        }

        mPlaybackState = nextState;
        performPlaybackUpdate();
    }

    /**
     * Posts or cancels the playback notification according to the current
     * rendered state, and arbitrates the foreground promotion.
     */
    private void performPlaybackUpdate() {
        synchronized (mPlaybackLock) {
            if (mNotificationManager == null) {
                return;
            }
            try {
                PlaybackState state = mPlaybackState;
                boolean valid = !state.isResting()
                    && state.title != null && !state.title.isEmpty();

                if (valid) {
                    Notification notification = buildPlaybackNotification(state);
                    mNotificationManager.notify(ID_PLAYBACK, notification);

                    if (STATE_PLAYING.equals(state.channelState)) {
                        Service service = mService;
                        if (service != null && !mPlaybackForeground.getAndSet(true)) {
                            service.startForeground(ID_PLAYBACK, notification);
                        }
                    } else {
                        if (mService != null) {
                            demoteFromForeground();
                        }
                    }
                } else {
                    mNotificationManager.cancel(ID_PLAYBACK);
                    if (mService != null) {
                        demoteFromForeground();
                    }
                }
            } catch (SecurityException exception) {
                Log.e(TAG, "Missing notification permission", exception);
            } catch (Exception exception) {
                Log.e(TAG, "performPlaybackUpdate failed", exception);
            }
        }
    }

    // ========================================================================
    // Playback — Notification Builder
    // ========================================================================

    /**
     * Builds the playback notification from the given state.
     *
     * <p>Transport actions are dispatched through
     * {@link MediaButtonReceiver#buildMediaButtonPendingIntent}, so a tap
     * flows through the active {@link MediaSessionCompat}. The close action
     * and the swipe-away delete intent both send {@code ACTION_STOP} to the
     * service.</p>
     *
     * @param state the rendered state
     * @return the built notification
     */
    @NonNull
    private Notification buildPlaybackNotification(@NonNull PlaybackState state) {
        final int themeColor = resolveThemeColor();
        final int pendingIntentFlags = buildPendingIntentFlags();

        PendingIntent contentIntent = buildContentIntent(pendingIntentFlags);
        PendingIntent closeIntent = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            pendingIntentFlags);
        PendingIntent deleteIntent = PendingIntent.getService(mContext, 5,
            new Intent(mContext, MusicService.class).setAction("ACTION_STOP"),
            pendingIntentFlags);

        final boolean isResting = state.isResting();
        String displayTitle  = isResting ? PLACEHOLDER_TITLE  : state.title;
        String displayArtist = isResting ? PLACEHOLDER_ARTIST : state.artist;

        if (displayTitle.length() > MAX_TITLE_LENGTH) {
            displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (displayArtist.length() > MAX_ARTIST_LENGTH) {
            displayArtist = displayArtist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_PLAYBACK);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle(displayTitle)
               .setContentText(displayArtist)
               .setColor(themeColor)
               .setContentIntent(contentIntent)
               .setDeleteIntent(deleteIntent)
               .setOngoing(state.isPlaying)
               .setVisibility(Notification.VISIBILITY_PUBLIC)
               .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }

        if (mPreviousIntent != null) {
            addAction(builder, R.drawable.ic_notification_prev, "Prev",
                mPreviousIntent, NEUTRAL_COLOR);
        }
        if (mPlayPauseIntent != null) {
            int playPauseIcon = state.isPlaying
                ? R.drawable.ic_notification_pause
                : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying ? "Pause" : "Play";
            addAction(builder, playPauseIcon, playPauseLabel, mPlayPauseIntent, themeColor);
        }
        if (mNextIntent != null) {
            addAction(builder, R.drawable.ic_notification_next, "Next",
                mNextIntent, NEUTRAL_COLOR);
        }
        addAction(builder, R.drawable.ic_notification_close, "Close",
            closeIntent, RED_COLOR);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Notification.MediaStyle mediaStyle = new Notification.MediaStyle();
            mediaStyle.setShowActionsInCompactView(0, 1, 2);
            MediaSessionCompat.Token sessionToken =
                mSessionTokenProvider != null ? mSessionTokenProvider.get() : null;
            if (sessionToken != null) {
                Object rawToken = sessionToken.getToken();
                if (rawToken instanceof android.media.session.MediaSession.Token) {
                    mediaStyle.setMediaSession((android.media.session.MediaSession.Token) rawToken);
                }
            }
            builder.setStyle(mediaStyle);
        }

        return builder.build();
    }

    /**
     * Adds a themed action button to the notification.
     *
     * @param builder the notification builder
     * @param iconRes the icon resource
     * @param label   the button label
     * @param intent  the pending intent
     * @param color   the icon tint
     */
    private void addAction(@NonNull Notification.Builder builder, int iconRes,
                           @NonNull String label, @NonNull PendingIntent intent,
                           int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon themedIcon = createThemedIcon(iconRes, color);
            if (themedIcon != null) {
                builder.addAction(new Notification.Action.Builder(themedIcon, label, intent).build());
                return;
            }
        }
        //noinspection deprecation
        builder.addAction(new Notification.Action.Builder(iconRes, label, intent).build());
    }

    /**
     * Returns the large icon for the notification, falling back to the
     * placeholder when no album art is available.
     *
     * @param state the rendered state
     * @return the large icon, or null if none is available
     */
    @Nullable
    private Bitmap getSafeLargeIcon(@NonNull PlaybackState state) {
        if (state.artKey != null) {
            Bitmap cachedArt = mAlbumArtCache.get(state.artKey);
            if (cachedArt != null && !cachedArt.isRecycled()) {
                return cachedArt;
            }
        }
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        if (state.placeholder != null && !state.placeholder.isRecycled()) {
            return state.placeholder;
        }
        return null;
    }

    // ========================================================================
    // Library Surface
    // ========================================================================

    /**
     * Shows or replaces the library notification with the given message and
     * operation ID.
     *
     * <p>Operation IDs are ownership tokens. A subsequent
     * {@link #dismissLibraryStatus(String)} with a mismatched ID is refused
     * so a later operation cannot be hidden by an earlier one completing.
     * Passing null as the operation ID shows the notification without an
     * owner; it can only be dismissed with a null ID.</p>
     *
     * @param message     the text to display
     * @param operationId the owner token (may be null)
     */
    public void showLibraryStatus(@NonNull String message, @Nullable String operationId) {
        synchronized (mLibraryLock) {
            mLibraryMessage = message;
            mLibraryOperationId = operationId;
            mLibraryShowing = true;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Updates the text on an already-showing library notification if the
     * operation ID matches. No-op otherwise.
     *
     * @param message     the new text
     * @param operationId the owner token (must match the current token)
     */
    public void updateLibraryStatus(@NonNull String message, @Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return;
            }
            mLibraryMessage = message;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Dismisses the library notification if the operation ID matches.
     *
     * @param operationId the owner token (must match the current token)
     * @return true if the notification was dismissed
     */
    public boolean dismissLibraryStatus(@Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return false;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return false;
            }
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return true;
        }
    }

    /**
     * Checks whether the library notification is currently showing.
     *
     * @return true if the library notification is showing
     */
    public boolean isLibraryStatusShowing() {
        synchronized (mLibraryLock) {
            return mLibraryShowing;
        }
    }

    /**
     * Returns the current library operation ID.
     *
     * @return the operation ID, or null if none
     */
    @Nullable
    public String getLibraryOperationId() {
        synchronized (mLibraryLock) {
            return mLibraryOperationId;
        }
    }

    /**
     * Posts the library notification. Caller must hold {@link #mLibraryLock}.
     */
    private void performLibraryUpdateLocked() {
        String message = mLibraryMessage;
        if (message == null || mNotificationManager == null) {
            return;
        }
        try {
            mNotificationManager.notify(ID_LIBRARY, buildLibraryNotification(message));
        } catch (SecurityException exception) {
            Log.e(TAG, "Missing notification permission (library)", exception);
        } catch (Exception exception) {
            Log.e(TAG, "performLibraryUpdate failed", exception);
        }
    }

    /**
     * Builds the library notification.
     *
     * @param message the text to display
     * @return the built notification
     */
    @NonNull
    private Notification buildLibraryNotification(@NonNull String message) {
        final int pendingIntentFlags = buildPendingIntentFlags();
        PendingIntent contentIntent = buildContentIntent(pendingIntentFlags);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_LIBRARY);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle("Llama Music Player")
               .setContentText(message)
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setOnlyAlertOnce(true)
               .setShowWhen(false)
               .setColor(resolveThemeColor())
               .setPriority(Notification.PRIORITY_LOW)
               .setCategory(Notification.CATEGORY_PROGRESS);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    // ========================================================================
    // Shared Helpers
    // ========================================================================

    /**
     * Returns the shared PendingIntent flags for this API level.
     *
     * @return the flags
     */
    private int buildPendingIntentFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    /**
     * Builds the content intent that launches the app.
     *
     * @param flags the PendingIntent flags
     * @return the content PendingIntent
     */
    @NonNull
    private PendingIntent buildContentIntent(int flags) {
        return PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);
    }

    /**
     * Resolves the current theme color, falling back to the default.
     *
     * @return the theme color as an integer
     */
    private int resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                return themeManager.getCurrentColorInt();
            }
            return ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    /**
     * Creates a downscaled copy of a bitmap.
     *
     * @param source  the source bitmap
     * @param maxSize the maximum dimension in pixels
     * @return the downscaled copy, or null on failure
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            if (width <= 0 || height <= 0) {
                return null;
            }
            Bitmap.Config config = source.getConfig() != null
                ? source.getConfig()
                : Bitmap.Config.ARGB_8888;
            if (width <= maxSize && height <= maxSize) {
                return source.copy(config, false);
            }
            float scale = Math.min((float) maxSize / width, (float) maxSize / height);
            return Bitmap.createScaledBitmap(source,
                Math.round(width * scale), Math.round(height * scale), true);
        } catch (Exception exception) {
            Log.e(TAG, "createSafeCopy failed", exception);
            return null;
        }
    }

    /**
     * Creates a themed icon for a notification action.
     *
     * @param drawableRes the drawable resource
     * @param color       the tint color
     * @return the themed icon, or null on failure
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);
            if (drawable == null) {
                return null;
            }
            drawable.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            }
            return null;
        } catch (Exception exception) {
            Log.e(TAG, "createThemedIcon failed", exception);
            return null;
        }
    }

    // ========================================================================
    // Channels
    // ========================================================================

    /**
     * Creates the two notification channels on API 26+. Idempotent; a
     * second call is a no-op for channels that already exist.
     */
    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || mNotificationManager == null) {
            return;
        }

        if (mNotificationManager.getNotificationChannel(CHANNEL_PLAYBACK) == null) {
            NotificationChannel playbackChannel = new NotificationChannel(
                CHANNEL_PLAYBACK, CHANNEL_PLAYBACK_NAME,
                NotificationManager.IMPORTANCE_DEFAULT);
            playbackChannel.setDescription(CHANNEL_PLAYBACK_DESC);
            playbackChannel.setShowBadge(false);
            playbackChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            playbackChannel.setSound(null, null);
            playbackChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(playbackChannel);
        }

        if (mNotificationManager.getNotificationChannel(CHANNEL_LIBRARY) == null) {
            NotificationChannel libraryChannel = new NotificationChannel(
                CHANNEL_LIBRARY, CHANNEL_LIBRARY_NAME,
                NotificationManager.IMPORTANCE_LOW);
            libraryChannel.setDescription(CHANNEL_LIBRARY_DESC);
            libraryChannel.setShowBadge(false);
            libraryChannel.setSound(null, null);
            libraryChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(libraryChannel);
        }
    }

    // ========================================================================
    // Shutdown
    // ========================================================================

    /**
     * Releases the singleton. Called at process teardown only — never
     * from an activity or service lifecycle callback.
     */
    public void shutdown() {
        stopAwareness();
        stopRenderTimer();
        synchronized (mLibraryLock) {
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
        }
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
                mNotificationManager.cancel(ID_LIBRARY);
            }
        }
        mPlaybackForeground.set(false);
        mService = null;
        mStateSource = null;
        sInstance = null;
    }
}