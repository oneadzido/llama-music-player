// NotificationController.java
package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Owns every notification surface the app produces, and is the sole
 * writer of the {@link MediaSessionCompat} metadata and playback
 * state.
 *
 * <p>Two notification identifiers sit on two channels.</p>
 * <ul>
 *   <li>{@link #ID_PLAYBACK} — the playback notification on
 *       {@code music_playback_channel}.</li>
 *   <li>{@link #ID_LIBRARY} — the library notification on
 *       {@code music_library_channel}, mirroring
 *       {@link ToastManager}'s persistent-overlay lifecycle.</li>
 * </ul>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible label on both notifications reads from a
 * string resource through {@link #getLocaleContext()}, which carries
 * the app's selected language.</p>
 *
 * <h3>Theme Application</h3>
 * <p>When a {@code THEME_COLOR_CHANGED} broadcast arrives, this
 * controller does not repaint the notification in place. The
 * activity that hosts the notification recreates, and the
 * notification's chrome is rebuilt from the persisted theme on the
 * next commit.</p>
 *
 * <h3>Commit Model</h3>
 * <p>{@link #commitFromBroadcast(long, RenderSnapshot)} is the primary
 * commit path. {@link #commitNow()} is the secondary path, called from
 * the activity's own commit runnable when the transition it queued
 * lands. The awareness poll runs on {@link #AWARENESS_INTERVAL_MS} and
 * is the safety-net cadence.</p>
 *
 * <h3>Generation Filtering</h3>
 * <p>{@link ServiceStateSource#getGeneration()} returns the service's
 * monotonic transition counter. Both {@code commitFromBroadcast} and
 * {@code syncOnce} drop any read whose generation is strictly lower
 * than {@link #mLastCommittedGeneration}.</p>
 *
 * <h3>The Null Display Song</h3>
 * <p>When the service has no display song to render — an empty
 * playlist, a transient window during a prepare, or a missing path —
 * {@link ServiceStateSource#snapshotForNotification()} returns null.
 * Neither {@code commitFromBroadcast} nor {@code syncOnce} renders
 * that null as a clear. Both hold the last rendered snapshot, so the
 * notification does not disappear during a transition. The surface
 * clears only when the service is genuinely idle, which the
 * controller detects through
 * {@link ServiceStateSource#isIdle()}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All public methods run on the main thread. The playback surface
 * is guarded by {@link #mPlaybackLock}; the library surface is
 * guarded by {@link #mLibraryLock}. Bitmap work runs inline on the
 * main thread and is bounded by {@link #MAX_ART_SIZE}.</p>
 *
 * @see MusicService
 * @see ToastManager
 * @see LanguageManager
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.0.0
 */
public final class NotificationController {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "NotificationController";

    /** Notification identifier for the playback notification. */
    public static final int ID_PLAYBACK = 1;

    /** Notification identifier for the library notification. */
    public static final int ID_LIBRARY = 2;

    /** Channel identifier for the playback notification. */
    private static final String CHANNEL_PLAYBACK =
        "music_playback_channel";

    /** Channel identifier for the library notification. */
    private static final String CHANNEL_LIBRARY =
        "music_library_channel";

    /** Small icon shared by both notifications. */
    private static final int SMALL_ICON_RES =
        R.drawable.ic_notification;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int MAX_ART_SIZE = 300;

    /** Neutral tint for transport action icons. */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;

    /** Red tint for the close action icon. */
    private static final int RED_COLOR = 0xFFE53935;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /** Fallback icon size for themed action icons, in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;

    /** Channel state string for the resting state. */
    private static final String STATE_RESTING = "Resting";

    /** Channel state string for the playing state. */
    private static final String STATE_PLAYING = "Playing";

    /** Channel state string for the paused state. */
    private static final String STATE_PAUSED = "Paused";

    /** Service action for the play/pause transport button. */
    private static final String ACTION_PLAY_PAUSE =
        "ACTION_PLAY_PAUSE";

    /** Service action for the next transport button. */
    private static final String ACTION_NEXT = "ACTION_NEXT";

    /** Service action for the previous transport button. */
    private static final String ACTION_PREV = "ACTION_PREV";

    /** Awareness poll interval in milliseconds. */
    private static final long AWARENESS_INTERVAL_MS = 100L;

    /** Default theme color used when the theme manager is
     *  unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Request code for the content intent. */
    private static final int REQUEST_CONTENT = 0;

    /** Request code for the play/pause transport intent. */
    private static final int REQUEST_PLAY_PAUSE = 1;

    /** Request code for the next transport intent. */
    private static final int REQUEST_NEXT = 2;

    /** Request code for the previous transport intent. */
    private static final int REQUEST_PREVIOUS = 3;

    /** Request code for the close intent. */
    private static final int REQUEST_CLOSE = 4;

    /** Request code for the delete intent. */
    private static final int REQUEST_DELETE = 5;

    // ============================================================================
    // Collaborator Interfaces and Data Carriers
    // ============================================================================

    /**
     * Read-only view of {@link MusicService}'s committed state, and
     * the single entry point through which the service's media
     * session is updated.
     */
    public interface ServiceStateSource {

        /**
         * Returns a complete renderable snapshot, or null when the
         * service has nothing committed to render.
         *
         * @return A complete renderable snapshot, or null
         */
        @Nullable
        RenderSnapshot snapshotForNotification();

        /**
         * Returns whether the service is idle.
         *
         * @return True when the service has nothing renderable
         */
        boolean isIdle();

        /**
         * Applies the given snapshot's metadata to the media session.
         *
         * @param snapshot Committed snapshot, or null to clear
         */
        void applyToMediaSession(@Nullable RenderSnapshot snapshot);

        /**
         * Returns the playback state to write to the media session
         * for the current state machine state.
         *
         * @return One of the {@link PlaybackStateCompat} state
         *         constants
         */
        int sessionPlaybackState();

        /**
         * Writes the current playback state to the media session.
         */
        void updateSessionPlaybackState();

        /**
         * Returns the service's monotonic transition counter.
         *
         * @return The current generation
         */
        long getGeneration();

        /**
         * Returns true when the playback notification should remain
         * a foreground notification even though playback is not
         * currently running.
         *
         * @return True when the notification must stay foreground
         */
        boolean shouldRemainForeground();
    }

    /**
     * An immutable, complete picture of the service.
     */
    public static final class RenderSnapshot {

        /** Song title. */
        @NonNull
        public final String title;

        /** Artist name. */
        @NonNull
        public final String artist;

        /** Album name. */
        @NonNull
        public final String album;

        /** File path used as the album art cache key. */
        @NonNull
        public final String path;

        /** True while the state machine is in PLAYING. */
        public final boolean isPlaying;

        /** Duration of the track in milliseconds, or 0 when unknown. */
        public final int durationMs;

        /** Decoded art for this path, or null. */
        @Nullable
        public final Bitmap art;

        /** True when {@link #art} is the final answer for this
         *  song. */
        public final boolean artResolved;

        /**
         * Constructs a snapshot.
         *
         * @param title Song title
         * @param artist Artist name
         * @param album Album name
         * @param path File path used as the album art cache key
         * @param isPlaying True when the state machine is in PLAYING
         * @param durationMs Duration of the track in milliseconds
         * @param art Decoded art, or null
         * @param artResolved True when {@code art} is the final answer
         */
        public RenderSnapshot(@NonNull String title,
                              @NonNull String artist,
                              @NonNull String album,
                              @NonNull String path,
                              boolean isPlaying,
                              int durationMs,
                              @Nullable Bitmap art,
                              boolean artResolved) {
            this.title = title;
            this.artist = artist;
            this.album = album;
            this.path = path;
            this.isPlaying = isPlaying;
            this.durationMs = durationMs;
            this.art = art;
            this.artResolved = artResolved;
        }

        /**
         * Returns whether this snapshot equals the given object.
         *
         * @param object Object to compare against, or null
         * @return True when all rendered fields are equal
         */
        @Override
        public boolean equals(@Nullable Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || getClass() != object.getClass()) {
                return false;
            }
            RenderSnapshot snapshot = (RenderSnapshot) object;
            return isPlaying == snapshot.isPlaying
                && artResolved == snapshot.artResolved
                && durationMs == snapshot.durationMs
                && title.equals(snapshot.title)
                && artist.equals(snapshot.artist)
                && album.equals(snapshot.album)
                && path.equals(snapshot.path)
                && art == snapshot.art;
        }

        /**
         * Returns a hash code derived from the rendered fields.
         *
         * @return The hash code
         */
        @Override
        public int hashCode() {
            return Objects.hash(title, artist, album, path,
                isPlaying, durationMs, artResolved);
        }
    }

    /**
     * Internal rendered state for the playback notification.
     */
    private static final class PlaybackState {

        /** Channel state string for the current render. */
        final String channelState;

        /** True when the render represents PLAYING. */
        final boolean isPlaying;

        /** Title currently displayed. */
        final String title;

        /** Artist currently displayed. */
        final String artist;

        /** Bitmap currently displayed, or null. */
        @Nullable final Bitmap albumArt;

        /** Cache key of the currently displayed art, or null. */
        @Nullable final String artKey;

        /** Song path the render belongs to, or null. */
        @Nullable final String songPath;

        /**
         * Constructs a rendered playback state.
         *
         * @param channelState Channel state string
         * @param isPlaying True when the render represents PLAYING
         * @param title Title currently displayed
         * @param artist Artist currently displayed
         * @param albumArt Bitmap currently displayed, or null
         * @param artKey Cache key of the currently displayed art
         * @param songPath Song path the render belongs to
         */
        PlaybackState(String channelState, boolean isPlaying,
                      String title, String artist,
                      @Nullable Bitmap albumArt,
                      @Nullable String artKey,
                      @Nullable String songPath) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.artKey = artKey;
            this.songPath = songPath;
        }

        /**
         * Returns whether the state represents the resting state.
         *
         * @return True when the state is the resting state
         */
        boolean isResting() {
            return STATE_RESTING.equals(channelState);
        }
    }

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile NotificationController sInstance;

    /**
     * Returns the process-wide singleton, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static NotificationController getInstance(
            @NonNull Context context) {
        if (sInstance == null) {
            synchronized (NotificationController.class) {
                if (sInstance == null) {
                    sInstance = new NotificationController(
                        context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Fields
    // ============================================================================

    @NonNull private final Context mContext;
    @Nullable private final NotificationManager mNotificationManager;
    @NonNull private final Handler mMainHandler;
    @NonNull private final LruCache<String, Bitmap> mAlbumArtCache;

    @Nullable private volatile Bitmap mThemedPlaceholder;
    private volatile int mThemedPlaceholderColor = 0;

    @Nullable private BroadcastReceiver mThemeReceiver;

    @NonNull private final Object mPlaybackLock = new Object();
    @NonNull private final Object mLibraryLock = new Object();

    // ---- Playback surface ----

    @Nullable private Service mService;
    @Nullable private ServiceStateSource mStateSource;
    @Nullable
    private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;
    @Nullable private PendingIntent mPlayPauseIntent;
    @Nullable private PendingIntent mNextIntent;
    @Nullable private PendingIntent mPreviousIntent;
    @Nullable private PendingIntent mContentIntent;
    @Nullable private PendingIntent mCloseIntent;
    @Nullable private PendingIntent mDeleteIntent;

    @NonNull private final Map<Long, Icon> mThemedIconCache =
        new HashMap<>();

    @NonNull private volatile PlaybackState mPlaybackState =
        new PlaybackState(
            STATE_RESTING, false, "", "", null, null, "");

    @NonNull private final AtomicBoolean mPlaybackForeground =
        new AtomicBoolean(false);

    @Nullable private RenderSnapshot mLastRenderedSnapshot;

    private long mLastCommittedGeneration = -1L;

    @Nullable private Runnable mAwarenessRunnable;

    // ---- Library surface ----

    @Nullable private String mLibraryTitle;
    @Nullable private String mLibraryBody;
    @Nullable private String mLibraryOperationId;
    private boolean mLibraryShowing;
    private long mLibraryStartTime = 0L;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the singleton.
     *
     * @param appContext Application context
     */
    private NotificationController(@NonNull Context appContext) {
        mContext = appContext;
        mNotificationManager = (NotificationManager)
            mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());

        mAlbumArtCache = AlbumArtCache.getInstance(appContext)
            .asLruCache();

        createChannels();
        registerThemeReceiver();

        mPlayPauseIntent = buildTransportPendingIntent(
            REQUEST_PLAY_PAUSE, ACTION_PLAY_PAUSE);
        mNextIntent = buildTransportPendingIntent(
            REQUEST_NEXT, ACTION_NEXT);
        mPreviousIntent = buildTransportPendingIntent(
            REQUEST_PREVIOUS, ACTION_PREV);
    }

    // ============================================================================
    // Localization Helper
    // ============================================================================

    /**
     * Returns the app's locale-wrapped application context.
     *
     * @return A context whose resources resolve against the app's
     *         selected language
     */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context",
                exception);
            return mContext;
        }
    }

    // ============================================================================
    // Playback — Service Binding
    // ============================================================================

    /**
     * Binds the playback surface to a service instance.
     *
     * @param service Service instance to bind
     */
    public void attachService(@NonNull Service service) {
        mService = service;
    }

    /**
     * Unbinds from the service and clears every playback render
     * field.
     */
    public void detachService() {
        stopAwareness();
        mStateSource = null;
        mSessionTokenProvider = null;
        mLastRenderedSnapshot = null;
        mLastCommittedGeneration = -1L;
        mPlaybackForeground.set(false);
        mPlaybackState = new PlaybackState(
            STATE_RESTING, false, "", "", null, null, "");
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
        mService = null;
    }

    /**
     * Installs the source of committed state.
     *
     * @param source Source to install, or null to disable awareness
     */
    public void setStateSource(@Nullable ServiceStateSource source) {
        mStateSource = source;
        if (source == null) {
            stopAwareness();
        } else {
            startAwareness();
        }
    }

    /**
     * Installs the supplier that provides the active media session
     * token.
     *
     * @param provider Token supplier, or null to clear
     */
    public void setSessionTokenProvider(
            @Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }

    /**
     * Drops the foreground promotion while keeping the notification
     * posted.
     */
    public void demoteFromForeground() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null) {
                return;
            }
            if (!mPlaybackForeground.getAndSet(false)) {
                return;
            }
            try {
                service.stopForeground(false);
            } catch (Exception exception) {
                Log.e(TAG, "demoteFromForeground failed",
                    exception);
            }
        }
    }

    /**
     * Cancels the playback notification and resets the rendered
     * state to the resting state.
     */
    public void clearPlaybackNotification() {
        synchronized (mPlaybackLock) {
            mLastRenderedSnapshot = null;
            mLastCommittedGeneration = -1L;
            mPlaybackForeground.set(false);
            mPlaybackState = new PlaybackState(
                STATE_RESTING, false, "", "", null, null, "");
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
    }

    // ============================================================================
    // Playback — Commit and Awareness
    // ============================================================================

    /**
     * Commits the snapshot the service just published on its
     * {@code UPDATE_PLAYER} broadcast.
     *
     * <p>When the service has no display song to render — an empty
     * playlist, a transient window during a prepare, or a missing
     * path — the snapshot is null. The controller holds the last
     * rendered snapshot rather than tearing the notification down.
     * The surface clears only through the idle branch in
     * {@link #syncOnce()}, which reads
     * {@link ServiceStateSource#isIdle()}.</p>
     *
     * @param generation The transition counter the broadcast carries
     * @param snapshot The snapshot the broadcast describes, or null
     *        to hold
     */
    public void commitFromBroadcast(final long generation,
                                    @Nullable final RenderSnapshot snapshot) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    commitFromBroadcast(generation, snapshot);
                }
            });
            return;
        }

        if (generation >= 0
                && generation < mLastCommittedGeneration) {
            return;
        }

        // A null snapshot is "nothing to render right now", not
        // "clear the surface". The last rendered snapshot holds.
        if (snapshot == null) {
            return;
        }

        boolean rendered = false;
        if (!snapshot.equals(mLastRenderedSnapshot)) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot;
                rendered = true;
            }
        } else {
            rendered = true;
        }

        if (rendered && generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation;
        }

        if (mStateSource != null) {
            mStateSource.updateSessionPlaybackState();
        }
    }

    /**
     * Runs one sync on the calling thread when that thread is the
     * main thread, and posts to the main thread otherwise.
     */
    public void commitNow() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    commitNow();
                }
            });
            return;
        }
        if (mStateSource == null) {
            return;
        }
        try {
            syncOnce();
        } catch (Exception exception) {
            Log.e(TAG, "commitNow failed", exception);
        }
    }

    /**
     * Posts one sync to the main thread.
     */
    public void pokeAwareness() {
        if (mStateSource == null) {
            return;
        }
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    syncOnce();
                } catch (Exception exception) {
                    Log.e(TAG, "pokeAwareness poll failed",
                        exception);
                }
            }
        });
    }

    /**
     * Starts the awareness poll.
     */
    private void startAwareness() {
        if (mAwarenessRunnable != null) {
            return;
        }
        mAwarenessRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    syncOnce();
                } catch (Exception exception) {
                    Log.e(TAG, "awareness poll failed", exception);
                }
                if (mAwarenessRunnable != null) {
                    mMainHandler.postDelayed(
                        this, AWARENESS_INTERVAL_MS);
                }
            }
        };
        mMainHandler.post(mAwarenessRunnable);
    }

    /**
     * Stops the awareness poll. Idempotent.
     */
    private void stopAwareness() {
        if (mAwarenessRunnable != null) {
            mMainHandler.removeCallbacks(mAwarenessRunnable);
            mAwarenessRunnable = null;
        }
    }

    /**
     * Runs a single sync.
     *
     * <p>The idle branch is the only path that clears the surface.
     * A null snapshot from a non-idle service is a hold, not a
     * clear, so a transition that has not yet produced a renderable
     * song does not blank the notification.</p>
     */
    private void syncOnce() {
        ServiceStateSource source = mStateSource;
        if (source == null) {
            return;
        }

        final long generation = source.getGeneration();

        if (source.isIdle()) {
            final boolean transitionPending =
                (mService instanceof MusicService)
                    && ((MusicService) mService)
                        .isTransitionPending();
            if (!transitionPending
                    && mLastRenderedSnapshot != null) {
                if (applySnapshot(null)) {
                    mLastRenderedSnapshot = null;
                    mLastCommittedGeneration = generation;
                }
            } else if (!transitionPending
                    && mLastRenderedSnapshot == null) {
                mLastCommittedGeneration = generation;
            }
            source.updateSessionPlaybackState();
            return;
        }

        if (generation < mLastCommittedGeneration) {
            source.updateSessionPlaybackState();
            return;
        }

        RenderSnapshot snapshot = source.snapshotForNotification();

        // A null snapshot from a non-idle service is "nothing to
        // render right now". The last rendered snapshot holds.
        if (snapshot == null) {
            source.updateSessionPlaybackState();
            return;
        }

        if (!snapshot.equals(mLastRenderedSnapshot)) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot;
                if (generation > mLastCommittedGeneration) {
                    mLastCommittedGeneration = generation;
                }
            }
        } else if (generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation;
        }

        source.updateSessionPlaybackState();
    }

    // ============================================================================
    // Playback — Render
    // ============================================================================

    /**
     * Applies the given snapshot as the current rendered state.
     *
     * <p>A null snapshot here is a deliberate clear — the caller has
     * already decided that the surface should rest. The hold
     * behaviour for a missing display song lives in
     * {@link #commitFromBroadcast(long, RenderSnapshot)} and
     * {@link #syncOnce()}, not here.</p>
     *
     * @param snapshot Snapshot to render, or null to clear
     * @return True when the snapshot was committed
     */
    private boolean applySnapshot(
            @Nullable RenderSnapshot snapshot) {
        PlaybackState previousState = mPlaybackState;
        RenderSnapshot previousSnapshot = mLastRenderedSnapshot;
        PlaybackState nextState;

        if (snapshot == null) {
            nextState = new PlaybackState(
                STATE_RESTING, false, "", "", null, null, "");
        } else {
            boolean songChanged = previousState == null
                || !snapshot.path.equals(previousState.songPath);

            Bitmap albumArt = null;
            String artKey = null;

            if (snapshot.art != null
                    && !snapshot.art.isRecycled()) {
                Bitmap cachedArt =
                    mAlbumArtCache.get(snapshot.path);
                if (cachedArt != null
                        && !cachedArt.isRecycled()) {
                    albumArt = cachedArt;
                } else {
                    Bitmap safeCopy = createSafeCopy(
                        snapshot.art, MAX_ART_SIZE);
                    if (safeCopy != null) {
                        mAlbumArtCache.put(
                            snapshot.path, safeCopy);
                        albumArt = safeCopy;
                    }
                }
                if (albumArt != null) {
                    artKey = snapshot.path;
                }
            } else if (!songChanged && !snapshot.artResolved) {
                albumArt = previousState.albumArt;
                artKey = previousState.artKey;
            }

            nextState = new PlaybackState(
                snapshot.isPlaying
                    ? STATE_PLAYING : STATE_PAUSED,
                snapshot.isPlaying,
                snapshot.title,
                snapshot.artist,
                albumArt,
                artKey,
                snapshot.path);
        }

        mPlaybackState = nextState;
        boolean posted = performPlaybackUpdate();
        if (!posted) {
            mPlaybackState = previousState;
            if (mStateSource != null) {
                mStateSource.applyToMediaSession(previousSnapshot);
            }
            return false;
        }

        if (mStateSource != null) {
            mStateSource.applyToMediaSession(snapshot);
        }
        return true;
    }

    /**
     * Posts or cancels the playback notification according to the
     * current rendered state.
     *
     * @return True when the notification was posted
     */
    private boolean performPlaybackUpdate() {
        synchronized (mPlaybackLock) {
            if (mNotificationManager == null) {
                return false;
            }
            try {
                PlaybackState state = mPlaybackState;
                boolean valid = !state.isResting()
                    && state.title != null
                    && !state.title.isEmpty();

                if (valid) {
                    Notification notification =
                        buildPlaybackNotification(state);
                    try {
                        mNotificationManager.notify(
                            ID_PLAYBACK, notification);
                    } catch (SecurityException exception) {
                        Log.e(TAG,
                            "Missing notification permission",
                            exception);
                        return false;
                    }

                    final boolean promoteToForeground =
                        STATE_PLAYING.equals(state.channelState)
                            || (mStateSource != null
                                && mStateSource
                                    .shouldRemainForeground());

                    if (promoteToForeground) {
                        Service service = mService;
                        if (service != null
                                && !mPlaybackForeground.get()) {
                            try {
                                service.startForeground(
                                    ID_PLAYBACK, notification);
                                mPlaybackForeground.set(true);
                            } catch (SecurityException exception) {
                                Log.w(TAG,
                                    "Foreground promotion failed; "
                                        + "notification remains "
                                        + "posted",
                                    exception);
                            } catch (Exception exception) {
                                Log.e(TAG,
                                    "Foreground promotion failed",
                                    exception);
                            }
                        }
                    } else {
                        if (mService != null) {
                            demoteFromForeground();
                        }
                    }
                } else {
                    mNotificationManager.cancel(ID_PLAYBACK);
                    if (mService != null) {
                        demoteFromForeground();
                    }
                }
                return true;
            } catch (Exception exception) {
                Log.e(TAG, "performPlaybackUpdate failed",
                    exception);
                return false;
            }
        }
    }

    // ============================================================================
    // Playback — Notification Builder
    // ============================================================================

    /**
     * Builds the playback notification from the given state.
     *
     * @param state Rendered state to build from
     * @return The built notification
     */
    @NonNull
    private Notification buildPlaybackNotification(
            @NonNull PlaybackState state) {
        final int themeColor = resolveThemeColor();
        final Context localeContext = getLocaleContext();

        PendingIntent contentIntent = getContentIntent();
        PendingIntent closeIntent = getCloseIntent();
        PendingIntent deleteIntent = getDeleteIntent();

        final boolean isResting = state.isResting();
        String displayTitle = isResting
            ? localeContext.getString(
                R.string.notification_placeholder_title)
            : state.title;
        String displayArtist = isResting
            ? localeContext.getString(
                R.string.notification_placeholder_artist)
            : state.artist;

        if (displayTitle.length() > MAX_TITLE_LENGTH) {
            displayTitle = displayTitle.substring(
                0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (displayArtist.length() > MAX_ARTIST_LENGTH) {
            displayArtist = displayArtist.substring(
                0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(
                mContext, CHANNEL_PLAYBACK);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
            .setContentTitle(displayTitle)
            .setContentText(displayArtist)
            .setColor(themeColor)
            .setContentIntent(contentIntent)
            .setDeleteIntent(deleteIntent)
            .setOngoing(state.isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(
                Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }

        if (mPreviousIntent != null) {
            addAction(builder, R.drawable.ic_notification_prev,
                localeContext.getString(
                    R.string.notification_action_prev),
                mPreviousIntent, NEUTRAL_COLOR);
        }
        if (mPlayPauseIntent != null) {
            int playPauseIcon = state.isPlaying
                ? R.drawable.ic_notification_pause
                : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying
                ? localeContext.getString(
                    R.string.notification_action_pause)
                : localeContext.getString(
                    R.string.notification_action_play);
            addAction(builder, playPauseIcon, playPauseLabel,
                mPlayPauseIntent, themeColor);
        }
        if (mNextIntent != null) {
            addAction(builder, R.drawable.ic_notification_next,
                localeContext.getString(
                    R.string.notification_action_next),
                mNextIntent, NEUTRAL_COLOR);
        }
        addAction(builder, R.drawable.ic_notification_close,
            localeContext.getString(
                R.string.notification_action_close),
            closeIntent, RED_COLOR);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            Notification.MediaStyle mediaStyle =
                new Notification.MediaStyle();
            mediaStyle.setShowActionsInCompactView(0, 1, 2);
            MediaSessionCompat.Token sessionToken =
                mSessionTokenProvider != null
                    ? mSessionTokenProvider.get() : null;
            if (sessionToken != null) {
                Object rawToken = sessionToken.getToken();
                if (rawToken instanceof
                        android.media.session.MediaSession.Token) {
                    mediaStyle.setMediaSession(
                        (android.media.session.MediaSession.Token)
                            rawToken);
                }
            }
            builder.setStyle(mediaStyle);
        }

        return builder.build();
    }

    /**
     * Adds a themed action button to the notification.
     *
     * @param builder Notification builder
     * @param iconRes Icon resource identifier
     * @param label Button label
     * @param intent Pending intent to fire on tap
     * @param color Icon tint
     */
    private void addAction(@NonNull Notification.Builder builder,
                           int iconRes,
                           @NonNull String label,
                           @NonNull PendingIntent intent,
                           int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon themedIcon = getThemedIcon(iconRes, color);
            if (themedIcon != null) {
                builder.addAction(
                    new Notification.Action.Builder(
                        themedIcon, label, intent).build());
                return;
            }
        }
        //noinspection deprecation
        builder.addAction(
            new Notification.Action.Builder(
                iconRes, label, intent).build());
    }

    /**
     * Returns the large icon for the notification.
     *
     * @param state Rendered state to build the icon for
     * @return The large icon, or null when the placeholder cannot be
     *         built
     */
    @Nullable
    private Bitmap getSafeLargeIcon(
            @NonNull PlaybackState state) {
        if (state.artKey != null) {
            Bitmap cachedArt = mAlbumArtCache.get(state.artKey);
            if (cachedArt != null && !cachedArt.isRecycled()) {
                return cachedArt;
            }
        }
        if (state.albumArt != null
                && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        return getThemedPlaceholder();
    }

    // ============================================================================
    // Playback — Themed Placeholder
    // ============================================================================

    /**
     * Returns the themed placeholder bitmap for the notification
     * large icon, building and caching it lazily.
     *
     * @return The themed placeholder bitmap, or null when the
     *         drawable cannot be decoded
     */
    @Nullable
    private Bitmap getThemedPlaceholder() {
        final int themeColor = resolveThemeColor();
        final Bitmap cached = mThemedPlaceholder;
        if (cached != null && !cached.isRecycled()
                && mThemedPlaceholderColor == themeColor) {
            return cached;
        }
        final Bitmap built = buildThemedPlaceholder(themeColor);
        if (built != null) {
            mThemedPlaceholder = built;
            mThemedPlaceholderColor = themeColor;
        }
        return built;
    }

    /**
     * Returns the themed placeholder bitmap for the media session
     * metadata.
     *
     * @return The themed placeholder bitmap, or null when the
     *         drawable cannot be decoded
     */
    @Nullable
    public Bitmap getPlaceholderForMediaSession() {
        return getThemedPlaceholder();
    }

    /**
     * Builds a themed placeholder bitmap.
     *
     * @param themeColor Tint color
     * @return The tinted bitmap, or null when the drawable cannot be
     *         built
     */
    @Nullable
    private Bitmap buildThemedPlaceholder(int themeColor) {
        try {
            final Drawable drawable = ContextCompat.getDrawable(
                mContext, R.drawable.album_art_placeholder);
            if (drawable == null) {
                return null;
            }

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = MAX_ART_SIZE;
                height = MAX_ART_SIZE;
            }

            final float scale = Math.min(
                (float) MAX_ART_SIZE / width,
                (float) MAX_ART_SIZE / height);
            if (scale < 1f) {
                width = Math.max(1, Math.round(width * scale));
                height = Math.max(1, Math.round(height * scale));
            }

            final Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, width, height);
            drawable.setColorFilter(
                new PorterDuffColorFilter(
                    themeColor, PorterDuff.Mode.SRC_IN));
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception exception) {
            Log.e(TAG, "buildThemedPlaceholder failed",
                exception);
            return null;
        }
    }

    // ============================================================================
    // Theme Receiver
    // ============================================================================

    /**
     * Registers a receiver for theme color changes.
     *
     * <p>The receiver does not repaint the notification in place.
     * {@link ThemeManager#setThemeColor(int)} persists the value and
     * broadcasts {@link ThemeManager#ACTION_THEME_COLOR_CHANGED};
     * the activity that hosts the notification recreates, and the
     * notification's chrome is rebuilt from the persisted theme on
     * the next commit.</p>
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context,
                                  Intent intent) {
                if (!ThemeManager.ACTION_THEME_COLOR_CHANGED
                        .equals(intent.getAction())) {
                    return;
                }
                // No in-place repaint. The activity that owns the
                // notification recreates on the same broadcast, and
                // the notification is rebuilt from the persisted
                // theme on the next commit.
            }
        };
        ContextCompat.registerReceiver(
            mContext, mThemeReceiver,
            new IntentFilter(
                ThemeManager.ACTION_THEME_COLOR_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Unregisters the theme receiver. Safe to call multiple times.
     */
    private void unregisterThemeReceiver() {
        if (mThemeReceiver != null) {
            try {
                mContext.unregisterReceiver(mThemeReceiver);
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    // ============================================================================
    // Library Surface
    // ============================================================================

    /**
     * Shows or replaces the library notification with the given
     * title and body, and restarts the elapsed-time chronometer.
     *
     * @param title Text to display as the notification title
     * @param body Text to display as the notification body
     * @param operationId Owner token, or null
     */
    public void showLibraryStatus(@NonNull String title,
                                  @NonNull String body,
                                  @Nullable String operationId) {
        synchronized (mLibraryLock) {
            mLibraryTitle = title;
            mLibraryBody = body;
            mLibraryOperationId = operationId;
            mLibraryShowing = true;
            mLibraryStartTime = System.currentTimeMillis();
            performLibraryUpdateLocked();
        }
    }

    /**
     * Updates the title and body on an already-showing library
     * notification when the operation ID matches.
     *
     * @param title New title to display
     * @param body New body to display
     * @param operationId Owner token to match
     */
    public void updateLibraryStatus(@NonNull String title,
                                    @NonNull String body,
                                    @Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return;
            }
            if (!Objects.equals(mLibraryOperationId,
                    operationId)) {
                return;
            }
            mLibraryTitle = title;
            mLibraryBody = body;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Dismisses the library notification when the operation ID
     * matches.
     *
     * @param operationId Owner token to match
     * @return True when the notification was dismissed
     */
    public boolean dismissLibraryStatus(
            @Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return false;
            }
            if (!Objects.equals(mLibraryOperationId,
                    operationId)) {
                return false;
            }
            mLibraryShowing = false;
            mLibraryTitle = null;
            mLibraryBody = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return true;
        }
    }

    /**
     * Tears the library notification down unconditionally.
     *
     * @return True when a notification was cancelled
     */
    public boolean clearLibraryStatus() {
        synchronized (mLibraryLock) {
            boolean wasShowing = mLibraryShowing;
            mLibraryShowing = false;
            mLibraryTitle = null;
            mLibraryBody = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return wasShowing;
        }
    }

    /**
     * Returns whether the library notification is currently
     * showing.
     *
     * @return True when the library notification is showing
     */
    public boolean isLibraryStatusShowing() {
        synchronized (mLibraryLock) {
            return mLibraryShowing;
        }
    }

    /**
     * Returns the current library operation ID.
     *
     * @return The operation ID, or null when the notification is
     *         unowned
     */
    @Nullable
    public String getLibraryOperationId() {
        synchronized (mLibraryLock) {
            return mLibraryOperationId;
        }
    }

    /**
     * Posts the library notification. Callers must hold
     * {@link #mLibraryLock}.
     */
    private void performLibraryUpdateLocked() {
        String title = mLibraryTitle;
        if (title == null || mNotificationManager == null) {
            return;
        }
        String body = (mLibraryBody != null) ? mLibraryBody : "";
        try {
            mNotificationManager.notify(
                ID_LIBRARY,
                buildLibraryNotification(title, body));
        } catch (SecurityException exception) {
            Log.e(TAG,
                "Missing notification permission (library)",
                exception);
        } catch (Exception exception) {
            Log.e(TAG, "performLibraryUpdate failed", exception);
        }
    }

    /**
     * Builds the library notification from the given title and
     * body.
     *
     * @param title Text to display as the notification title
     * @param body Text to display as the notification body
     * @return The built notification
     */
    @NonNull
    private Notification buildLibraryNotification(
            @NonNull String title,
            @NonNull String body) {
        PendingIntent contentIntent = getContentIntent();

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(
                mContext, CHANNEL_LIBRARY);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(resolveThemeColor())
            .setPriority(Notification.PRIORITY_LOW)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setStyle(new Notification.BigTextStyle()
                .bigText(body));

        if (mLibraryStartTime > 0L) {
            builder.setWhen(mLibraryStartTime);
            builder.setUsesChronometer(true);
            builder.setChronometerCountDown(false);
            builder.setShowWhen(true);
        } else {
            builder.setShowWhen(false);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    // ============================================================================
    // Shared Helpers
    // ============================================================================

    /**
     * Returns the shared PendingIntent flags for the current API
     * level.
     *
     * @return The flags
     */
    private int buildPendingIntentFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    /**
     * Builds a transport PendingIntent.
     *
     * @param requestCode Unique request code for this action
     * @param action Action carried by the intent
     * @return The PendingIntent
     */
    @NonNull
    private PendingIntent buildTransportPendingIntent(
            int requestCode,
            @NonNull String action) {
        Intent intent = new Intent(mContext, MusicService.class);
        intent.setAction(action);
        return PendingIntent.getService(
            mContext, requestCode, intent,
            buildPendingIntentFlags());
    }

    /**
     * Returns the content intent, building and caching it on first
     * use.
     *
     * @return The content PendingIntent
     */
    @NonNull
    private PendingIntent getContentIntent() {
        if (mContentIntent == null) {
            mContentIntent = PendingIntent.getActivity(mContext,
                REQUEST_CONTENT,
                new Intent(mContext, MusicPlayer.class)
                    .setAction(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER),
                buildPendingIntentFlags());
        }
        return mContentIntent;
    }

    /**
     * Returns the transport Close intent, building and caching it
     * on first use.
     *
     * @return The Close PendingIntent
     */
    @NonNull
    private PendingIntent getCloseIntent() {
        if (mCloseIntent == null) {
            mCloseIntent = PendingIntent.getService(mContext,
                REQUEST_CLOSE,
                new Intent(mContext, MusicService.class)
                    .setAction("ACTION_STOP"),
                buildPendingIntentFlags());
        }
        return mCloseIntent;
    }

    /**
     * Returns the notification delete intent, building and caching
     * it on first use.
     *
     * @return The delete PendingIntent
     */
    @NonNull
    private PendingIntent getDeleteIntent() {
        if (mDeleteIntent == null) {
            mDeleteIntent = PendingIntent.getService(mContext,
                REQUEST_DELETE,
                new Intent(mContext, MusicService.class)
                    .setAction("ACTION_STOP"),
                buildPendingIntentFlags());
        }
        return mDeleteIntent;
    }

    /**
     * Resolves the current theme color, falling back to the default
     * when the theme manager is unavailable.
     *
     * @return The theme color as an integer
     */
    private int resolveThemeColor() {
        try {
            ThemeManager themeManager =
                ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                return themeManager.getCurrentColorInt();
            }
            return ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    /**
     * Returns a downscaled copy of the given bitmap.
     *
     * @param source Bitmap to copy, or null
     * @param maxSize Maximum dimension of the copy, in pixels
     * @return The downscaled copy, or null on failure
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source,
                                  int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            if (width <= 0 || height <= 0) {
                return null;
            }
            Bitmap.Config config = source.getConfig() != null
                ? source.getConfig()
                : Bitmap.Config.ARGB_8888;
            if (width <= maxSize && height <= maxSize) {
                return source.copy(config, false);
            }
            float scale = Math.min(
                (float) maxSize / width,
                (float) maxSize / height);
            return Bitmap.createScaledBitmap(source,
                Math.round(width * scale),
                Math.round(height * scale), true);
        } catch (Exception exception) {
            Log.e(TAG, "createSafeCopy failed", exception);
            return null;
        }
    }

    /**
     * Returns the themed action icon for the given drawable
     * resource and tint, building and caching it on first use.
     *
     * @param drawableRes Drawable resource identifier
     * @param color Tint color
     * @return The themed icon, or null when the drawable cannot be
     *         built
     */
    @Nullable
    private Icon getThemedIcon(int drawableRes, int color) {
        final long key = ((long) drawableRes << 32)
            | (color & 0xFFFFFFFFL);
        final Icon cached = mThemedIconCache.get(key);
        if (cached != null) {
            return cached;
        }
        final Icon built = createThemedIcon(drawableRes, color);
        if (built != null) {
            mThemedIconCache.put(key, built);
        }
        return built;
    }

    /**
     * Creates a themed icon for a notification action.
     *
     * @param drawableRes Drawable resource identifier
     * @param color Tint color
     * @return The themed icon, or null on failure
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(
                mContext, drawableRes);
            if (drawable == null) {
                return null;
            }
            drawable.setColorFilter(
                new PorterDuffColorFilter(
                    color, PorterDuff.Mode.SRC_IN));

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }

            Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(),
                canvas.getHeight());
            drawable.draw(canvas);

            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            }
            return null;
        } catch (Exception exception) {
            Log.e(TAG, "createThemedIcon failed", exception);
            return null;
        }
    }

    // ============================================================================
    // Channels
    // ============================================================================

    /**
     * Creates the two notification channels on API 26 and later.
     * Idempotent.
     */
    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || mNotificationManager == null) {
            return;
        }

        final Context localeContext = getLocaleContext();

        if (mNotificationManager.getNotificationChannel(
                CHANNEL_PLAYBACK) == null) {
            NotificationChannel playbackChannel =
                new NotificationChannel(
                    CHANNEL_PLAYBACK,
                    localeContext.getString(
                        R.string.notification_channel_playback),
                    NotificationManager.IMPORTANCE_DEFAULT);
            playbackChannel.setDescription(
                localeContext.getString(
                    R.string.notification_channel_playback_desc));
            playbackChannel.setShowBadge(false);
            playbackChannel.setLockscreenVisibility(
                Notification.VISIBILITY_PUBLIC);
            playbackChannel.setSound(null, null);
            playbackChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(
                playbackChannel);
        }

        if (mNotificationManager.getNotificationChannel(
                CHANNEL_LIBRARY) == null) {
            NotificationChannel libraryChannel =
                new NotificationChannel(
                    CHANNEL_LIBRARY,
                    localeContext.getString(
                        R.string.notification_channel_library),
                    NotificationManager.IMPORTANCE_LOW);
            libraryChannel.setDescription(
                localeContext.getString(
                    R.string.notification_channel_library_desc));
            libraryChannel.setShowBadge(false);
            libraryChannel.setSound(null, null);
            libraryChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(
                libraryChannel);
        }
    }

    // ============================================================================
    // Shutdown
    // ============================================================================

    /**
     * Releases the singleton.
     */
    public void shutdown() {
        stopAwareness();
        unregisterThemeReceiver();

        synchronized (mLibraryLock) {
            mLibraryShowing = false;
            mLibraryTitle = null;
            mLibraryBody = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
        }
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
                mNotificationManager.cancel(ID_LIBRARY);
            }
        }
        mPlaybackForeground.set(false);
        mService = null;
        mStateSource = null;
        mLastRenderedSnapshot = null;
        mLastCommittedGeneration = -1L;
        mThemedPlaceholder = null;
        mThemedPlaceholderColor = 0;

        mThemedIconCache.clear();
        mContentIntent = null;
        mCloseIntent = null;
        mDeleteIntent = null;
        mPlayPauseIntent = null;
        mNextIntent = null;
        mPreviousIntent = null;

        sInstance = null;
    }
}