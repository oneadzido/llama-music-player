// NotificationController.java
package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Owns every notification surface the app produces, and is the sole
 * writer of the {@link MediaSessionCompat} metadata and playback state.
 *
 * <p>Two notification identifiers sit on two channels.</p>
 * <ul>
 *   <li>{@link #ID_PLAYBACK} — the playback notification on
 *       {@code music_playback_channel}. Its state is bound to
 *       {@link MusicService} through a {@link ServiceStateSource}. It is
 *       the only surface eligible for foreground promotion.</li>
 *   <li>{@link #ID_LIBRARY} — the library notification on
 *       {@code music_library_channel}. It mirrors
 *       {@link ToastManager}'s persistent-overlay lifecycle. It is never
 *       promoted to the foreground. It is independent of
 *       {@link MusicService}.</li>
 * </ul>
 *
 * <h3>Localization</h3>
 * <p>Every user-visible label on both notifications reads from a string
 * resource through {@link #getLocaleContext()}, which carries the app's
 * selected language. The channel names and descriptions, the transport
 * action labels, and the placeholder title and artist all resolve
 * against the app's language rather than the system language. A
 * language change therefore affects the notification's next build; the
 * notification itself is rebuilt through {@link #onThemeChanged()}'s
 * sibling path on the next commit, and the app-side recreation that a
 * language change triggers brings the new locale into every subsequent
 * {@code getString} call.</p>
 *
 * <p>Channel names and descriptions are read at channel-creation time.
 * On API 26 and later, the platform captures a channel's name and
 * description the first time it is created and does not update them on
 * subsequent {@code createNotificationChannel} calls, so an install
 * whose channel was created before a language change continues to show
 * the original name in system settings. The channel IDs are unchanged,
 * so notification grouping, importance, and user customisations are
 * preserved. The notification content — action labels, placeholder
 * title and artist — is rebuilt on every post and follows the language
 * immediately.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The controller owns both notification identifiers, both channels,
 * both notification builders, the last rendered playback snapshot, the
 * transport {@link PendingIntent}s, the themed action icon cache, the
 * album art cache, and the themed placeholder bitmap.
 * {@link MusicService} owns the playback state machine and exposes it
 * through a {@link ServiceStateSource} that the controller reads.</p>
 *
 * <p>The controller is also the sole writer of the media session. Two
 * projections of the service are written by the controller, and they
 * have independent lifetimes.</p>
 *
 * <ul>
 *   <li><b>Metadata</b> is a projection of the render commit. It is
 *       written from {@link ServiceStateSource#applyToMediaSession}
 *       once per commit, in the same main-thread turn that commits the
 *       notification.</li>
 *   <li><b>Playback state</b> is a projection of the state machine. It
 *       is written from {@link ServiceStateSource#updateSessionPlaybackState}
 *       on every sync, regardless of whether a render committed.</li>
 * </ul>
 *
 * <h3>Commit Model</h3>
 * <p>{@link #commitFromBroadcast(long, RenderSnapshot)} is the primary
 * commit path. {@link MusicService#broadcastUpdate()} calls it with
 * the exact snapshot the {@code UPDATE_PLAYER} broadcast describes, on
 * the same main-thread turn the broadcast was dispatched. The
 * notification therefore commits the same state the activity adopts —
 * the same title, artist, art, playing flag, and generation — on the
 * same turn. This is the pattern {@code MusicPlayer}'s receiver uses
 * for the UI, applied to the notification.</p>
 *
 * <p>{@link #commitNow()} is the secondary path, called from the
 * activity's own commit runnable when the transition it queued lands.
 * It runs one {@link #syncOnce()} on the calling thread when that
 * thread is the main thread, and posts otherwise. When
 * {@link #commitFromBroadcast(long, RenderSnapshot)} has already
 * committed the same generation, this call is a no-op.</p>
 *
 * <p>The awareness poll runs on {@link #AWARENESS_INTERVAL_MS} and is
 * the safety-net cadence. Each tick is one {@link #syncOnce()}: it
 * reads the source's generation and committed snapshot, commits the
 * difference only when the generation is at or beyond the last
 * committed generation, and writes the session playback state
 * unconditionally.</p>
 *
 * <h3>Generation Filtering</h3>
 * <p>{@link ServiceStateSource#getGeneration()} returns the service's
 * monotonic transition counter. {@link #commitFromBroadcast(long,
 * RenderSnapshot)} and {@link #syncOnce()} both drop any read whose
 * generation is strictly lower than {@link #mLastCommittedGeneration}.
 * A poll that captured a snapshot before a broadcast but whose post
 * landed after it therefore cannot overwrite the newer commit. This
 * is what keeps the notification drawing the same song, artist, art,
 * and play/pause icon the activity is drawing at every instant.</p>
 *
 * <h3>Transport PendingIntents</h3>
 * <p>The three media transport buttons the playback notification
 * attaches to play/pause, next, and previous dispatch through
 * {@link PendingIntent#getService} with an explicit action
 * ({@code ACTION_PLAY_PAUSE}, {@code ACTION_NEXT}, {@code ACTION_PREV}).
 * {@link MusicService#onStartCommand(Intent, int, int)} handles each of
 * those actions synchronously on the main thread by calling
 * {@link MusicService#togglePlayPause()},
 * {@link MusicService#playNextSong()}, or
 * {@link MusicService#playPreviousSong()} directly. The notification
 * button therefore reaches the state machine in one hop, the same path
 * the close button uses.</p>
 *
 * <p>This is deliberately different from routing the notification's
 * buttons through the {@link MediaSessionCompat}. The media session
 * exists to receive input from sources the app cannot intercept
 * directly — the lockscreen, bluetooth, headset buttons. Those still
 * reach the service through {@code ACTION_MEDIA_BUTTON} and are
 * dispatched to the session. The notification's own buttons are
 * app-internal and reach the service directly. Routed through the
 * media session they would take three hops (broadcast receiver,
 * service start, media-session dispatch), each of which can post to
 * the main queue — which opens a window during which a player button
 * tap that arrived after the notification tap can execute first and
 * leave the final state disagreeing with the user's last tap.</p>
 *
 * <h3>Shared Icon and Intent Caches</h3>
 * <p>The four action icons use fixed tints except for the play/pause
 * icon, whose tint is the theme color. The icon set is cached by the
 * controller. The content intent, close intent, delete intent, and
 * the three transport intents are built once and cached.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All public methods run on the main thread. The awareness poll is
 * scheduled on the main handler. The playback surface is guarded by
 * {@link #mPlaybackLock}; the library surface is guarded by
 * {@link #mLibraryLock}. Bitmap work runs inline on the main thread and
 * is bounded by {@link #MAX_ART_SIZE}. The action icon cache and the
 * shared PendingIntents are read and written on the main thread
 * only.</p>
 *
 * @see MusicService
 * @see ToastManager
 * @see LanguageManager
 *
 * @author Richard Korbla Adzido
 * @version 1.3.8
 * @since 1.0.0
 */
public final class NotificationController {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "NotificationController";

    /** Notification identifier for the playback notification. */
    public static final int ID_PLAYBACK = 1;

    /** Notification identifier for the library notification. */
    public static final int ID_LIBRARY = 2;

    /** Channel identifier for the playback notification. */
    private static final String CHANNEL_PLAYBACK = "music_playback_channel";

    /** Channel identifier for the library notification. */
    private static final String CHANNEL_LIBRARY = "music_library_channel";

    /** Small icon shared by both notifications. */
    private static final int SMALL_ICON_RES = R.drawable.ic_notification;

    /** Maximum dimension of the notification album art, in pixels. */
    private static final int MAX_ART_SIZE = 300;

    /** Neutral tint for transport action icons. */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;

    /** Red tint for the close action icon. */
    private static final int RED_COLOR = 0xFFE53935;

    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;

    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;

    /** Ellipsis appended to truncated text. */
    private static final String ELLIPSIS = "...";

    /**
     * Separator used to split a library message into a primary line and
     * a secondary line. Every caller in this app formats its message as
     * {@code "<operation>... <detail>"}, so the split is structural
     * rather than heuristic.
     */
    private static final String LIBRARY_MESSAGE_SEPARATOR = "...";

    /** Fallback icon size for themed action icons, in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;

    /** Channel state string for the resting state. */
    private static final String STATE_RESTING = "Resting";

    /** Channel state string for the playing state. */
    private static final String STATE_PLAYING = "Playing";

    /** Channel state string for the paused state. */
    private static final String STATE_PAUSED = "Paused";

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /** Service action for the play/pause transport button. */
    private static final String ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE";

    /** Service action for the next transport button. */
    private static final String ACTION_NEXT = "ACTION_NEXT";

    /** Service action for the previous transport button. */
    private static final String ACTION_PREV = "ACTION_PREV";

    /**
     * Awareness poll interval in milliseconds.
     *
     * <p>The poll runs at this cadence as the safety-net clock for the
     * notification and the media session. Each tick is one
     * {@link #syncOnce()}.</p>
     */
    private static final long AWARENESS_INTERVAL_MS = 100L;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Request code for the content intent. */
    private static final int REQUEST_CONTENT = 0;

    /** Request code for the play/pause transport intent. */
    private static final int REQUEST_PLAY_PAUSE = 1;

    /** Request code for the next transport intent. */
    private static final int REQUEST_NEXT = 2;

    /** Request code for the previous transport intent. */
    private static final int REQUEST_PREVIOUS = 3;

    /** Request code for the close intent. */
    private static final int REQUEST_CLOSE = 4;

    /** Request code for the delete intent. */
    private static final int REQUEST_DELETE = 5;

    // ============================================================================
    // Collaborator Interfaces and Data Carriers
    // ============================================================================

    /**
     * Read-only view of {@link MusicService}'s committed state, and the
     * single entry point through which the service's media session is
     * updated.
     *
     * <p>All calls run on the main thread. Implementations must not
     * block.</p>
     */
    public interface ServiceStateSource {

        /**
         * Returns a complete renderable snapshot, or null when the
         * service has nothing committed to render.
         *
         * @return A complete renderable snapshot, or null
         */
        @Nullable
        RenderSnapshot snapshotForNotification();

        /**
         * Returns whether the service is idle.
         *
         * @return True when the service has nothing renderable and the
         *         playback notification should clear
         */
        boolean isIdle();

        /**
         * Applies the given snapshot's metadata to the media session.
         *
         * @param snapshot Committed snapshot, or null to clear
         */
        void applyToMediaSession(@Nullable RenderSnapshot snapshot);

        /**
         * Returns the playback state to write to the media session for
         * the current state machine state.
         *
         * @return One of the {@link PlaybackStateCompat} state constants
         */
        int sessionPlaybackState();

        /**
         * Writes the current playback state to the media session.
         */
        void updateSessionPlaybackState();

        /**
         * Returns the service's monotonic transition counter.
         *
         * <p>Used by the controller to drop any snapshot whose
         * generation has been superseded by a newer broadcast commit.
         * Without the filter, a poll whose snapshot was captured
         * before a broadcast could post after it and re-apply the
         * older state, leaving the notification showing a song or a
         * play/pause icon the activity has already moved past.</p>
         *
         * @return The current generation
         */
        long getGeneration();
    }

    /**
     * An immutable, complete picture of the service.
     */
    public static final class RenderSnapshot {

        /** Song title. */
        @NonNull
        public final String title;

        /** Artist name. */
        @NonNull
        public final String artist;

        /** Album name. */
        @NonNull
        public final String album;

        /** File path used as the album art cache key. */
        @NonNull
        public final String path;

        /** True while the state machine is in PLAYING. */
        public final boolean isPlaying;

        /** Duration of the track in milliseconds, or 0 when unknown. */
        public final int durationMs;

        /**
         * Decoded art for this path, or null.
         *
         * <p>Null on its own is ambiguous: it may mean the decode is
         * still pending, or it may mean the song has no art.
         * {@link #artResolved} disambiguates.</p>
         */
        @Nullable
        public final Bitmap art;

        /**
         * True when {@link #art} is the final answer for this song —
         * either a bitmap or an explicit "no art". False while the
         * decode is in flight.
         */
        public final boolean artResolved;

        /**
         * Constructs a snapshot with the given values.
         *
         * @param title Song title
         * @param artist Artist name
         * @param album Album name
         * @param path File path used as the album art cache key
         * @param isPlaying True when the state machine is in PLAYING
         * @param durationMs Duration of the track in milliseconds, or 0
         * @param art Decoded art, or null
         * @param artResolved True when {@code art} is the final answer
         */
        public RenderSnapshot(@NonNull String title, @NonNull String artist,
                              @NonNull String album, @NonNull String path,
                              boolean isPlaying, int durationMs,
                              @Nullable Bitmap art, boolean artResolved) {
            this.title = title;
            this.artist = artist;
            this.album = album;
            this.path = path;
            this.isPlaying = isPlaying;
            this.durationMs = durationMs;
            this.art = art;
            this.artResolved = artResolved;
        }

        @Override
        public boolean equals(@Nullable Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || getClass() != object.getClass()) {
                return false;
            }
            RenderSnapshot snapshot = (RenderSnapshot) object;
            return isPlaying == snapshot.isPlaying
                && artResolved == snapshot.artResolved
                && durationMs == snapshot.durationMs
                && title.equals(snapshot.title)
                && artist.equals(snapshot.artist)
                && album.equals(snapshot.album)
                && path.equals(snapshot.path)
                && art == snapshot.art;
        }

        @Override
        public int hashCode() {
            return Objects.hash(title, artist, album, path, isPlaying,
                durationMs, artResolved);
        }
    }

    /**
     * Internal rendered state for the playback notification.
     *
     * <p>Written only inside {@link #applySnapshot(RenderSnapshot)} and
     * read only inside {@link #performPlaybackUpdate()} and
     * {@link #buildPlaybackNotification(PlaybackState)}.</p>
     */
    private static final class PlaybackState {

        /** Channel state string for the current render. */
        final String channelState;

        /** True when the render represents PLAYING. */
        final boolean isPlaying;

        /** Title currently displayed. */
        final String title;

        /** Artist currently displayed. */
        final String artist;

        /** Bitmap currently displayed as the large icon, or null. */
        @Nullable final Bitmap albumArt;

        /** Cache key of the currently displayed art, or null. */
        @Nullable final String artKey;

        /** Song path the render belongs to, or null. */
        @Nullable final String songPath;

        PlaybackState(String channelState, boolean isPlaying, String title,
                      String artist, @Nullable Bitmap albumArt,
                      @Nullable String artKey, @Nullable String songPath) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.artKey = artKey;
            this.songPath = songPath;
        }

        boolean isResting() {
            return STATE_RESTING.equals(channelState);
        }
    }

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile NotificationController sInstance;

    /**
     * Returns the process-wide singleton, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    @NonNull
    public static NotificationController getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (NotificationController.class) {
                if (sInstance == null) {
                    sInstance = new NotificationController(
                        context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Fields
    // ============================================================================

    @NonNull private final Context mContext;
    @Nullable private final NotificationManager mNotificationManager;
    @NonNull private final Handler mMainHandler;
    @NonNull private final LruCache<String, Bitmap> mAlbumArtCache;

    @Nullable private volatile Bitmap mThemedPlaceholder;
    private volatile int mThemedPlaceholderColor = 0;

    @Nullable private BroadcastReceiver mThemeReceiver;

    @NonNull private final Object mPlaybackLock = new Object();
    @NonNull private final Object mLibraryLock = new Object();

    // ---- Playback surface ----

    @Nullable private Service mService;
    @Nullable private ServiceStateSource mStateSource;
    @Nullable private Supplier<MediaSessionCompat.Token> mSessionTokenProvider;
    @Nullable private PendingIntent mPlayPauseIntent;
    @Nullable private PendingIntent mNextIntent;
    @Nullable private PendingIntent mPreviousIntent;
    @Nullable private PendingIntent mContentIntent;
    @Nullable private PendingIntent mCloseIntent;
    @Nullable private PendingIntent mDeleteIntent;

    /**
     * Cache of themed action icons, keyed by the pair of the drawable
     * resource and the tint.
     *
     * <p>The key is
     * {@code ((long) drawableRes << 32) | (color & 0xFFFFFFFFL)}. The
     * theme-color dependency is expressed through the key rather than
     * through explicit invalidation.</p>
     */
    @NonNull private final Map<Long, Icon> mThemedIconCache =
        new HashMap<>();

    @NonNull private volatile PlaybackState mPlaybackState =
        new PlaybackState(STATE_RESTING, false, "", "", null, null, "");

    @NonNull private final AtomicBoolean mPlaybackForeground =
        new AtomicBoolean(false);

    @Nullable private RenderSnapshot mLastRenderedSnapshot;

    /**
     * The service's generation as of the last committed snapshot.
     *
     * <p>Set by {@link #commitFromBroadcast(long, RenderSnapshot)} and
     * by {@link #syncOnce()}. Any read whose generation is strictly
     * less than this value is dropped: it describes a state the
     * controller has already moved past.</p>
     */
    private long mLastCommittedGeneration = -1L;

    @Nullable private Runnable mAwarenessRunnable;

    // ---- Library surface ----

    @Nullable private String mLibraryMessage;
    @Nullable private String mLibraryOperationId;
    private boolean mLibraryShowing;
    private long mLibraryStartTime = 0L;

    // ============================================================================
    // Constructor
    // ============================================================================

    private NotificationController(@NonNull Context appContext) {
        mContext = appContext;
        mNotificationManager = (NotificationManager)
            mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());

        mAlbumArtCache =
            AlbumArtCache.getInstance(appContext).asLruCache();

        createChannels();
        registerThemeReceiver();

        // Direct-service transport intents. Each carries a
        // private action that MusicService.onStartCommand
        // handles synchronously on the main thread by calling
        // togglePlayPause() / playNextSong() / playPreviousSong()
        // directly. This is one hop — the same path the close
        // button uses — rather than the three-hop broadcast →
        // startService → media-session round-trip.
        mPlayPauseIntent = buildTransportPendingIntent(
            REQUEST_PLAY_PAUSE, ACTION_PLAY_PAUSE);
        mNextIntent = buildTransportPendingIntent(
            REQUEST_NEXT, ACTION_NEXT);
        mPreviousIntent = buildTransportPendingIntent(
            REQUEST_PREVIOUS, ACTION_PREV);
    }

    // ============================================================================
    // Localization Helper
    // ============================================================================

    /**
     * Returns the app's locale-wrapped application context.
     *
     * <p>Reads through {@link LanguageManager#getLocalizedContext()}
     * rather than {@link #mContext}. The application context resolves
     * against the system locale; the localized one resolves against the
     * app's selected language. Every user-visible string this class
     * produces — channel names and descriptions, notification action
     * labels, the placeholder title and artist — reads from the
     * localized context.</p>
     *
     * <p>When the language manager is unreachable — a first-call race
     * during process start — the raw application context is returned so
     * the string still resolves, in the system language rather than the
     * app's selection. That case is transient and self-correcting: the
     * next call reaches the manager.</p>
     *
     * @return A context whose resources resolve against the app's
     *         currently selected language
     */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context", exception);
            return mContext;
        }
    }

    // ============================================================================
    // Playback — Service Binding
    // ============================================================================

    /**
     * Binds the playback surface to a service instance.
     *
     * @param service Service instance to bind
     */
    public void attachService(@NonNull Service service) {
        mService = service;
    }

    /**
     * Unbinds from the service and clears every playback render field.
     */
    public void detachService() {
        stopAwareness();
        mStateSource = null;
        mSessionTokenProvider = null;
        mLastRenderedSnapshot = null;
        mLastCommittedGeneration = -1L;
        mPlaybackForeground.set(false);
        mPlaybackState = new PlaybackState(STATE_RESTING, false, "", "",
            null, null, "");
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
        mService = null;
    }

    /**
     * Installs the source of committed state.
     *
     * <p>Passing null stops the awareness poll.</p>
     *
     * @param source Source to install, or null to disable awareness
     */
    public void setStateSource(@Nullable ServiceStateSource source) {
        mStateSource = source;
        if (source == null) {
            stopAwareness();
        } else {
            startAwareness();
        }
    }

    /**
     * Installs the supplier that provides the active media session token
     * used to bind MediaStyle to the session.
     *
     * @param provider Token supplier, or null to clear
     */
    public void setSessionTokenProvider(
            @Nullable Supplier<MediaSessionCompat.Token> provider) {
        mSessionTokenProvider = provider;
    }

    /**
     * Drops the foreground promotion while keeping the notification
     * posted.
     */
    public void demoteFromForeground() {
        synchronized (mPlaybackLock) {
            Service service = mService;
            if (service == null) {
                return;
            }
            if (!mPlaybackForeground.getAndSet(false)) {
                return;
            }
            try {
                service.stopForeground(false);
            } catch (Exception exception) {
                Log.e(TAG, "demoteFromForeground failed", exception);
            }
        }
    }

    /**
     * Cancels the playback notification and resets the rendered state to
     * the resting state.
     */
    public void clearPlaybackNotification() {
        synchronized (mPlaybackLock) {
            mLastRenderedSnapshot = null;
            mLastCommittedGeneration = -1L;
            mPlaybackForeground.set(false);
            mPlaybackState = new PlaybackState(STATE_RESTING, false, "",
                "", null, null, "");
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
            }
        }
    }

    // ============================================================================
    // Playback — Commit and Awareness
    // ============================================================================

    /**
     * Commits the snapshot the service just published on its
     * {@code UPDATE_PLAYER} broadcast.
     *
     * <p>The primary commit path. {@link MusicService#broadcastUpdate()}
     * calls this with the exact snapshot the broadcast describes, in
     * the same main-thread turn the broadcast was dispatched. The
     * controller therefore commits the same state the activity adopts
     * — the same title, the same artist, the same art, the same
     * playing flag, the same generation — on the same turn. This is
     * the pattern {@code MusicPlayer}'s receiver uses for the UI,
     * applied to the notification.</p>
     *
     * <p>Stale generations are dropped: a broadcast whose generation
     * is strictly lower than {@link #mLastCommittedGeneration} was
     * already superseded and must not overwrite the newer commit.</p>
     *
     * <p>The method marshals to the main thread when called from any
     * other thread, so a caller that is not on the main thread still
     * produces a coherent commit.</p>
     *
     * @param generation The transition counter the broadcast carries
     * @param snapshot The snapshot the broadcast describes, or null
     *        to clear
     */
    public void commitFromBroadcast(long generation,
                                    @Nullable RenderSnapshot snapshot) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post(() -> commitFromBroadcast(
                generation, snapshot));
            return;
        }

        if (generation >= 0 && generation < mLastCommittedGeneration) {
            return;
        }
        if (generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation;
        }

        if (snapshot == null) {
            if (mLastRenderedSnapshot != null) {
                if (applySnapshot(null)) {
                    mLastRenderedSnapshot = null;
                }
            }
        } else if (!snapshot.equals(mLastRenderedSnapshot)) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot;
            }
        }

        if (mStateSource != null) {
            mStateSource.updateSessionPlaybackState();
        }
    }

    /**
     * Runs one sync on the calling thread when that thread is the main
     * thread, and posts to the main thread otherwise.
     *
     * <p>Idempotent. When the source's snapshot has not changed since
     * the last commit, the sync does nothing for the notification. The
     * media session's playback state is written unconditionally, as it
     * is on every sync.</p>
     */
    public void commitNow() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post(this::commitNow);
            return;
        }
        if (mStateSource == null) {
            return;
        }
        try {
            syncOnce();
        } catch (Exception exception) {
            Log.e(TAG, "commitNow failed", exception);
        }
    }

    /**
     * Posts one sync to the main thread.
     *
     * <p>Called by {@link MusicService} at the end of
     * {@code broadcastUpdate}, after the broadcast has been
     * dispatched.</p>
     */
    public void pokeAwareness() {
        if (mStateSource == null) {
            return;
        }
        mMainHandler.post(() -> {
            try {
                syncOnce();
            } catch (Exception exception) {
                Log.e(TAG, "pokeAwareness poll failed", exception);
            }
        });
    }

    /**
     * Starts the awareness poll. A second call while the poll is
     * already running does nothing.
     */
    private void startAwareness() {
        if (mAwarenessRunnable != null) {
            return;
        }
        mAwarenessRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    syncOnce();
                } catch (Exception exception) {
                    Log.e(TAG, "awareness poll failed", exception);
                }
                if (mAwarenessRunnable != null) {
                    mMainHandler.postDelayed(this, AWARENESS_INTERVAL_MS);
                }
            }
        };
        mMainHandler.post(mAwarenessRunnable);
    }

    /**
     * Stops the awareness poll. Idempotent.
     */
    private void stopAwareness() {
        if (mAwarenessRunnable != null) {
            mMainHandler.removeCallbacks(mAwarenessRunnable);
            mAwarenessRunnable = null;
        }
    }

    /**
     * Runs a single sync.
     *
     * <p>Reads the service's committed snapshot and commits the
     * difference directly. The generation filter is the guard against
     * stale reads: a poll whose generation is strictly lower than
     * {@link #mLastCommittedGeneration} is dropped, because a
     * broadcast has already committed a newer state. Without the
     * filter, a poll that ran before the broadcast but whose post
     * landed after it could re-apply the older state and leave the
     * notification drawing a song or icon the activity has already
     * moved past.</p>
     *
     * <p>{@link #mLastRenderedSnapshot} records what was actually
     * rendered, not what was last read; it is advanced only when the
     * notification post succeeded, so a transient failure is retried
     * on the next sync rather than being recorded as a commit.</p>
     */
    private void syncOnce() {
        ServiceStateSource source = mStateSource;
        if (source == null) {
            return;
        }

        final long generation = source.getGeneration();

        if (source.isIdle()) {
            if (mLastRenderedSnapshot != null) {
                if (applySnapshot(null)) {
                    mLastRenderedSnapshot = null;
                }
            }
            mLastCommittedGeneration = generation;
            source.updateSessionPlaybackState();
            return;
        }

        if (generation < mLastCommittedGeneration) {
            source.updateSessionPlaybackState();
            return;
        }
        if (generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation;
        }

        RenderSnapshot snapshot = source.snapshotForNotification();
        if (snapshot != null && !snapshot.equals(mLastRenderedSnapshot)) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot;
            }
        }

        source.updateSessionPlaybackState();
    }

    // ============================================================================
    // Playback — Render
    // ============================================================================

    /**
     * Applies the given snapshot as the current rendered state.
     *
     * <p>Every field the playback notification draws is written in a
     * single atomic {@link PlaybackState} transition. When the
     * transition commits, the controller calls
     * {@link ServiceStateSource#applyToMediaSession(RenderSnapshot)}
     * with the same snapshot.</p>
     *
     * @param snapshot Snapshot to render, or null to clear
     * @return True when the snapshot was committed
     */
    private boolean applySnapshot(@Nullable RenderSnapshot snapshot) {
        PlaybackState previousState = mPlaybackState;
        PlaybackState nextState;

        if (snapshot == null) {
            nextState = new PlaybackState(STATE_RESTING, false, "", "",
                null, null, "");
        } else {
            boolean songChanged = previousState == null
                || !snapshot.path.equals(previousState.songPath);

            Bitmap albumArt = null;
            String artKey = null;

            if (snapshot.art != null && !snapshot.art.isRecycled()) {
                Bitmap cachedArt = mAlbumArtCache.get(snapshot.path);
                if (cachedArt != null && !cachedArt.isRecycled()) {
                    albumArt = cachedArt;
                } else {
                    Bitmap safeCopy = createSafeCopy(
                        snapshot.art, MAX_ART_SIZE);
                    if (safeCopy != null) {
                        mAlbumArtCache.put(snapshot.path, safeCopy);
                        albumArt = safeCopy;
                    }
                }
                if (albumArt != null) {
                    artKey = snapshot.path;
                }
            } else if (!songChanged && !snapshot.artResolved) {
                albumArt = previousState.albumArt;
                artKey = previousState.artKey;
            }

            nextState = new PlaybackState(
                snapshot.isPlaying ? STATE_PLAYING : STATE_PAUSED,
                snapshot.isPlaying,
                snapshot.title,
                snapshot.artist,
                albumArt,
                artKey,
                snapshot.path);
        }

        mPlaybackState = nextState;
        boolean posted = performPlaybackUpdate();
        if (!posted) {
            mPlaybackState = previousState;
            return false;
        }

        if (mStateSource != null) {
            mStateSource.applyToMediaSession(snapshot);
        }
        return true;
    }

    /**
     * Posts or cancels the playback notification according to the
     * current rendered state, and arbitrates the foreground promotion.
     *
     * <p>The foreground flag is set only after
     * {@link Service#startForeground(int, Notification)} returns
     * successfully, so a failed promotion leaves the flag {@code false}
     * and the next sync retries.</p>
     *
     * @return True when the notification state was successfully
     *         committed, false when the post failed
     */
    private boolean performPlaybackUpdate() {
        synchronized (mPlaybackLock) {
            if (mNotificationManager == null) {
                return false;
            }
            try {
                PlaybackState state = mPlaybackState;
                boolean valid = !state.isResting()
                    && state.title != null && !state.title.isEmpty();

                if (valid) {
                    Notification notification =
                        buildPlaybackNotification(state);
                    mNotificationManager.notify(ID_PLAYBACK, notification);

                    if (STATE_PLAYING.equals(state.channelState)) {
                        Service service = mService;
                        if (service != null
                                && !mPlaybackForeground.get()) {
                            // Set the flag only after startForeground
                            // returns. Setting it before leaves it
                            // stuck at true if startForeground throws,
                            // and the next promotion skips
                            // startForeground on the strength of a
                            // flag that does not describe reality.
                            service.startForeground(
                                ID_PLAYBACK, notification);
                            mPlaybackForeground.set(true);
                        }
                    } else {
                        if (mService != null) {
                            demoteFromForeground();
                        }
                    }
                } else {
                    mNotificationManager.cancel(ID_PLAYBACK);
                    if (mService != null) {
                        demoteFromForeground();
                    }
                }
                return true;
            } catch (SecurityException exception) {
                Log.e(TAG, "Missing notification permission", exception);
                return false;
            } catch (Exception exception) {
                Log.e(TAG, "performPlaybackUpdate failed", exception);
                return false;
            }
        }
    }

    // ============================================================================
    // Playback — Notification Builder
    // ============================================================================

    /**
     * Builds the playback notification from the given state.
     *
     * <p>Every {@link PendingIntent} and every {@link Icon} this method
     * attaches is served from the controller's shared caches. Every
     * user-visible label resolves through {@link #getLocaleContext()},
     * which carries the app's selected language.</p>
     *
     * @param state Rendered state to build from
     * @return The built notification
     */
    @NonNull
    private Notification buildPlaybackNotification(@NonNull PlaybackState state) {
        final int themeColor = resolveThemeColor();
        final Context localeContext = getLocaleContext();

        PendingIntent contentIntent = getContentIntent();
        PendingIntent closeIntent = getCloseIntent();
        PendingIntent deleteIntent = getDeleteIntent();

        final boolean isResting = state.isResting();
        String displayTitle = isResting
            ? localeContext.getString(R.string.notification_placeholder_title)
            : state.title;
        String displayArtist = isResting
            ? localeContext.getString(R.string.notification_placeholder_artist)
            : state.artist;

        if (displayTitle.length() > MAX_TITLE_LENGTH) {
            displayTitle = displayTitle.substring(
                0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (displayArtist.length() > MAX_ARTIST_LENGTH) {
            displayArtist = displayArtist.substring(
                0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_PLAYBACK);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle(displayTitle)
               .setContentText(displayArtist)
               .setColor(themeColor)
               .setContentIntent(contentIntent)
               .setDeleteIntent(deleteIntent)
               .setOngoing(state.isPlaying)
               .setVisibility(Notification.VISIBILITY_PUBLIC)
               .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(
                Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }

        if (mPreviousIntent != null) {
            addAction(builder, R.drawable.ic_notification_prev,
                localeContext.getString(R.string.notification_action_prev),
                mPreviousIntent, NEUTRAL_COLOR);
        }
        if (mPlayPauseIntent != null) {
            int playPauseIcon = state.isPlaying
                ? R.drawable.ic_notification_pause
                : R.drawable.ic_notification_play;
            String playPauseLabel = state.isPlaying
                ? localeContext.getString(R.string.notification_action_pause)
                : localeContext.getString(R.string.notification_action_play);
            addAction(builder, playPauseIcon, playPauseLabel,
                mPlayPauseIntent, themeColor);
        }
        if (mNextIntent != null) {
            addAction(builder, R.drawable.ic_notification_next,
                localeContext.getString(R.string.notification_action_next),
                mNextIntent, NEUTRAL_COLOR);
        }
        addAction(builder, R.drawable.ic_notification_close,
            localeContext.getString(R.string.notification_action_close),
            closeIntent, RED_COLOR);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Notification.MediaStyle mediaStyle = new Notification.MediaStyle();
            mediaStyle.setShowActionsInCompactView(0, 1, 2);
            MediaSessionCompat.Token sessionToken =
                mSessionTokenProvider != null
                    ? mSessionTokenProvider.get() : null;
            if (sessionToken != null) {
                Object rawToken = sessionToken.getToken();
                if (rawToken instanceof
                        android.media.session.MediaSession.Token) {
                    mediaStyle.setMediaSession(
                        (android.media.session.MediaSession.Token) rawToken);
                }
            }
            builder.setStyle(mediaStyle);
        }

        return builder.build();
    }

    /**
     * Adds a themed action button to the notification.
     *
     * @param builder Notification builder to add the action to
     * @param iconRes Icon resource identifier
     * @param label Button label
     * @param intent Pending intent to fire on tap
     * @param color Icon tint
     */
    private void addAction(@NonNull Notification.Builder builder, int iconRes,
                           @NonNull String label,
                           @NonNull PendingIntent intent, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon themedIcon = getThemedIcon(iconRes, color);
            if (themedIcon != null) {
                builder.addAction(
                    new Notification.Action.Builder(
                        themedIcon, label, intent).build());
                return;
            }
        }
        //noinspection deprecation
        builder.addAction(
            new Notification.Action.Builder(iconRes, label, intent).build());
    }

    /**
     * Returns the large icon for the notification.
     *
     * @param state Rendered state to build the icon for
     * @return The large icon, or null when the placeholder cannot be
     *         built
     */
    @Nullable
    private Bitmap getSafeLargeIcon(@NonNull PlaybackState state) {
        if (state.artKey != null) {
            Bitmap cachedArt = mAlbumArtCache.get(state.artKey);
            if (cachedArt != null && !cachedArt.isRecycled()) {
                return cachedArt;
            }
        }
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        return getThemedPlaceholder();
    }

    // ============================================================================
    // Playback — Themed Placeholder
    // ============================================================================

    /**
     * Returns the themed placeholder bitmap for the notification large
     * icon, building and caching it lazily.
     *
     * @return The themed placeholder bitmap, or null when the drawable
     *         cannot be decoded
     */
    @Nullable
    private Bitmap getThemedPlaceholder() {
        final int themeColor = resolveThemeColor();
        final Bitmap cached = mThemedPlaceholder;
        if (cached != null && !cached.isRecycled()
                && mThemedPlaceholderColor == themeColor) {
            return cached;
        }
        final Bitmap built = buildThemedPlaceholder(themeColor);
        if (built != null) {
            mThemedPlaceholder = built;
            mThemedPlaceholderColor = themeColor;
        }
        return built;
    }

    /**
     * Returns the themed placeholder bitmap for the media session
     * metadata.
     *
     * @return The themed placeholder bitmap, or null when the
     *         drawable cannot be decoded
     */
    @Nullable
    public Bitmap getPlaceholderForMediaSession() {
        return getThemedPlaceholder();
    }

    /**
     * Builds a themed placeholder bitmap by decoding
     * {@code R.drawable.album_art_placeholder} and tinting it with the
     * given color.
     *
     * @param themeColor Tint color
     * @return The tinted bitmap, or null when the drawable cannot be
     *         built
     */
    @Nullable
    private Bitmap buildThemedPlaceholder(int themeColor) {
        try {
            final Drawable drawable = ContextCompat.getDrawable(
                mContext, R.drawable.album_art_placeholder);
            if (drawable == null) {
                return null;
            }

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = MAX_ART_SIZE;
                height = MAX_ART_SIZE;
            }

            final float scale = Math.min(
                (float) MAX_ART_SIZE / width,
                (float) MAX_ART_SIZE / height);
            if (scale < 1f) {
                width = Math.max(1, Math.round(width * scale));
                height = Math.max(1, Math.round(height * scale));
            }

            final Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, width, height);
            drawable.setColorFilter(
                new PorterDuffColorFilter(
                    themeColor, PorterDuff.Mode.SRC_IN));
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception exception) {
            Log.e(TAG, "buildThemedPlaceholder failed", exception);
            return null;
        }
    }

    // ============================================================================
    // Theme Receiver
    // ============================================================================

    /**
     * Registers a receiver for theme color changes.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    onThemeChanged();
                }
            }
        };
        ContextCompat.registerReceiver(
            mContext, mThemeReceiver,
            new IntentFilter(ACTION_THEME_COLOR_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Unregisters the theme receiver. Safe to call multiple times.
     */
    private void unregisterThemeReceiver() {
        if (mThemeReceiver != null) {
            try {
                mContext.unregisterReceiver(mThemeReceiver);
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
            mThemeReceiver = null;
        }
    }

    /**
     * Reacts to a theme color change.
     */
    private void onThemeChanged() {
        if (mNotificationManager == null || mService == null) {
            return;
        }

        if (mStateSource != null) {
            mStateSource.applyToMediaSession(mLastRenderedSnapshot);
        }

        if (!mPlaybackState.isResting()) {
            performPlaybackUpdate();
            return;
        }

        if (!mPlaybackForeground.get()) {
            return;
        }

        synchronized (mPlaybackLock) {
            try {
                Notification notification =
                    buildPlaybackNotification(mPlaybackState);
                mNotificationManager.notify(ID_PLAYBACK, notification);
            } catch (Exception exception) {
                Log.e(TAG,
                    "theme refresh of resting notification failed",
                    exception);
            }
        }
    }

    // ============================================================================
    // Library Surface
    // ============================================================================

    /**
     * Shows or replaces the library notification with the given message
     * and operation ID, and restarts the elapsed-time chronometer.
     *
     * @param message Text to display
     * @param operationId Owner token, or null
     */
    public void showLibraryStatus(@NonNull String message,
                                  @Nullable String operationId) {
        synchronized (mLibraryLock) {
            mLibraryMessage = message;
            mLibraryOperationId = operationId;
            mLibraryShowing = true;
            mLibraryStartTime = System.currentTimeMillis();
            performLibraryUpdateLocked();
        }
    }

    /**
     * Updates the text on an already-showing library notification when
     * the operation ID matches.
     *
     * @param message New text to display
     * @param operationId Owner token to match
     */
    public void updateLibraryStatus(@NonNull String message,
                                    @Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return;
            }
            mLibraryMessage = message;
            performLibraryUpdateLocked();
        }
    }

    /**
     * Dismisses the library notification when the operation ID matches.
     *
     * @param operationId Owner token to match
     * @return True when the notification was dismissed
     */
    public boolean dismissLibraryStatus(@Nullable String operationId) {
        synchronized (mLibraryLock) {
            if (!mLibraryShowing) {
                return false;
            }
            if (!Objects.equals(mLibraryOperationId, operationId)) {
                return false;
            }
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return true;
        }
    }

    /**
     * Tears the library notification down unconditionally, ignoring any
     * current owner.
     *
     * @return True when a notification was cancelled
     */
    public boolean clearLibraryStatus() {
        synchronized (mLibraryLock) {
            boolean wasShowing = mLibraryShowing;
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_LIBRARY);
            }
            return wasShowing;
        }
    }

    /**
     * Returns whether the library notification is currently showing.
     *
     * @return True when the library notification is showing
     */
    public boolean isLibraryStatusShowing() {
        synchronized (mLibraryLock) {
            return mLibraryShowing;
        }
    }

    /**
     * Returns the current library operation ID.
     *
     * @return The operation ID, or null when the notification is
     *         unowned
     */
    @Nullable
    public String getLibraryOperationId() {
        synchronized (mLibraryLock) {
            return mLibraryOperationId;
        }
    }

    /**
     * Posts the library notification. Callers must hold
     * {@link #mLibraryLock}.
     */
    private void performLibraryUpdateLocked() {
        String message = mLibraryMessage;
        if (message == null || mNotificationManager == null) {
            return;
        }
        try {
            mNotificationManager.notify(
                ID_LIBRARY, buildLibraryNotification(message));
        } catch (SecurityException exception) {
            Log.e(TAG, "Missing notification permission (library)",
                exception);
        } catch (Exception exception) {
            Log.e(TAG, "performLibraryUpdate failed", exception);
        }
    }

    /**
     * Builds the library notification.
     *
     * <p>The message's primary and secondary lines come from the caller
     * as a single string; the separator is structural. No user-visible
     * literal is produced here, so no locale resolution is needed.</p>
     *
     * @param message Text to display
     * @return The built notification
     */
    @NonNull
    private Notification buildLibraryNotification(@NonNull String message) {
        PendingIntent contentIntent = getContentIntent();

        String primaryLine = message;
        String secondaryLine = null;
        final int separatorIndex =
            message.indexOf(LIBRARY_MESSAGE_SEPARATOR);
        if (separatorIndex > 0
                && separatorIndex + LIBRARY_MESSAGE_SEPARATOR.length()
                    < message.length()) {
            final String afterSeparator = message.substring(
                separatorIndex + LIBRARY_MESSAGE_SEPARATOR.length())
                .trim();
            if (!afterSeparator.isEmpty()) {
                primaryLine = message.substring(
                    0, separatorIndex + LIBRARY_MESSAGE_SEPARATOR.length());
                secondaryLine = afterSeparator;
            }
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_LIBRARY);
        } else {
            //noinspection deprecation
            builder = new Notification.Builder(mContext);
        }

        builder.setSmallIcon(SMALL_ICON_RES)
               .setContentTitle(primaryLine)
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setOnlyAlertOnce(true)
               .setColor(resolveThemeColor())
               .setPriority(Notification.PRIORITY_LOW)
               .setCategory(Notification.CATEGORY_PROGRESS);

        if (secondaryLine != null) {
            builder.setContentText(secondaryLine);
        }

        if (mLibraryStartTime > 0L) {
            builder.setWhen(mLibraryStartTime);
            builder.setUsesChronometer(true);
            builder.setChronometerCountDown(false);
            builder.setShowWhen(true);
        } else {
            builder.setShowWhen(false);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    // ============================================================================
    // Shared Helpers
    // ============================================================================

    /**
     * Returns the shared PendingIntent flags for the current API level.
     *
     * @return The flags
     */
    private int buildPendingIntentFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    /**
     * Builds a transport PendingIntent that starts {@link MusicService}
     * with the given action.
     *
     * <p>{@code MusicService.onStartCommand} handles each of these
     * actions synchronously on the main thread by calling the
     * corresponding state-machine method directly. The notification
     * button reaches the state machine in one hop — the same path the
     * close button uses — rather than through the three-hop broadcast
     * receiver → service start → media-session dispatch that
     * {@code MediaButtonReceiver} introduces.</p>
     *
     * <p>Distinct request codes are required because the framework's
     * PendingIntent cache keys on request code plus
     * {@link Intent#filterEquals(Intent)}. Three intents that share the
     * same component and differ only in action could collide if they
     * share a request code on some Android versions; distinct codes
     * remove the possibility.</p>
     *
     * @param requestCode Unique request code for this transport action
     * @param action Action carried by the intent
     * @return The PendingIntent
     */
    @NonNull
    private PendingIntent buildTransportPendingIntent(int requestCode,
                                                      @NonNull String action) {
        Intent intent = new Intent(mContext, MusicService.class);
        intent.setAction(action);
        return PendingIntent.getService(
            mContext, requestCode, intent, buildPendingIntentFlags());
    }

    /**
     * Returns the content intent that launches the app, building and
     * caching it on first use.
     *
     * @return The content PendingIntent
     */
    @NonNull
    private PendingIntent getContentIntent() {
        if (mContentIntent == null) {
            mContentIntent = PendingIntent.getActivity(mContext,
                REQUEST_CONTENT,
                new Intent(mContext, MusicPlayer.class)
                    .setAction(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER),
                buildPendingIntentFlags());
        }
        return mContentIntent;
    }

    /**
     * Returns the transport Close intent, building and caching it on
     * first use.
     *
     * @return The Close PendingIntent
     */
    @NonNull
    private PendingIntent getCloseIntent() {
        if (mCloseIntent == null) {
            mCloseIntent = PendingIntent.getService(mContext,
                REQUEST_CLOSE,
                new Intent(mContext, MusicService.class)
                    .setAction("ACTION_STOP"),
                buildPendingIntentFlags());
        }
        return mCloseIntent;
    }

    /**
     * Returns the notification delete intent, building and caching it
     * on first use.
     *
     * @return The delete PendingIntent
     */
    @NonNull
    private PendingIntent getDeleteIntent() {
        if (mDeleteIntent == null) {
            mDeleteIntent = PendingIntent.getService(mContext,
                REQUEST_DELETE,
                new Intent(mContext, MusicService.class)
                    .setAction("ACTION_STOP"),
                buildPendingIntentFlags());
        }
        return mDeleteIntent;
    }

    /**
     * Resolves the current theme color, falling back to the default
     * when the theme manager is unavailable.
     *
     * @return The theme color as an integer
     */
    private int resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                return themeManager.getCurrentColorInt();
            }
            return ThemeHelper.getDefaultColor();
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    /**
     * Returns a downscaled copy of the given bitmap.
     *
     * @param source Bitmap to copy, or null
     * @param maxSize Maximum dimension of the copy, in pixels
     * @return The downscaled copy, or null on failure
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            if (width <= 0 || height <= 0) {
                return null;
            }
            Bitmap.Config config = source.getConfig() != null
                ? source.getConfig()
                : Bitmap.Config.ARGB_8888;
            if (width <= maxSize && height <= maxSize) {
                return source.copy(config, false);
            }
            float scale = Math.min(
                (float) maxSize / width, (float) maxSize / height);
            return Bitmap.createScaledBitmap(source,
                Math.round(width * scale),
                Math.round(height * scale), true);
        } catch (Exception exception) {
            Log.e(TAG, "createSafeCopy failed", exception);
            return null;
        }
    }

    /**
     * Returns the themed action icon for the given drawable resource
     * and tint, building and caching it on first use.
     *
     * @param drawableRes Drawable resource identifier
     * @param color Tint color
     * @return The themed icon, or null when the drawable cannot be
     *         built
     */
    @Nullable
    private Icon getThemedIcon(int drawableRes, int color) {
        final long key = ((long) drawableRes << 32)
            | (color & 0xFFFFFFFFL);
        final Icon cached = mThemedIconCache.get(key);
        if (cached != null) {
            return cached;
        }
        final Icon built = createThemedIcon(drawableRes, color);
        if (built != null) {
            mThemedIconCache.put(key, built);
        }
        return built;
    }

    /**
     * Creates a themed icon for a notification action.
     *
     * @param drawableRes Drawable resource identifier
     * @param color Tint color
     * @return The themed icon, or null on failure
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(
                mContext, drawableRes);
            if (drawable == null) {
                return null;
            }
            drawable.setColorFilter(
                new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));

            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }

            Bitmap bitmap = Bitmap.createBitmap(
                width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            }
            return null;
        } catch (Exception exception) {
            Log.e(TAG, "createThemedIcon failed", exception);
            return null;
        }
    }

    // ============================================================================
    // Channels
    // ============================================================================

    /**
     * Creates the two notification channels on API 26 and later.
     * Idempotent.
     *
     * <p>Channel names and descriptions resolve through
     * {@link #getLocaleContext()}, which carries the app's selected
     * language. On API 26 and later, the platform captures the name and
     * description the first time a channel is created and does not
     * update them on subsequent {@code createNotificationChannel}
     * calls, so a channel that was created before a language change
     * continues to display the earlier name in system settings. The
     * channel IDs are unchanged, so notification grouping, importance,
     * and user customisations are preserved.</p>
     */
    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || mNotificationManager == null) {
            return;
        }

        final Context localeContext = getLocaleContext();

        if (mNotificationManager.getNotificationChannel(CHANNEL_PLAYBACK)
                == null) {
            NotificationChannel playbackChannel = new NotificationChannel(
                CHANNEL_PLAYBACK,
                localeContext.getString(
                    R.string.notification_channel_playback),
                NotificationManager.IMPORTANCE_DEFAULT);
            playbackChannel.setDescription(localeContext.getString(
                R.string.notification_channel_playback_desc));
            playbackChannel.setShowBadge(false);
            playbackChannel.setLockscreenVisibility(
                Notification.VISIBILITY_PUBLIC);
            playbackChannel.setSound(null, null);
            playbackChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(playbackChannel);
        }

        if (mNotificationManager.getNotificationChannel(CHANNEL_LIBRARY)
                == null) {
            NotificationChannel libraryChannel = new NotificationChannel(
                CHANNEL_LIBRARY,
                localeContext.getString(
                    R.string.notification_channel_library),
                NotificationManager.IMPORTANCE_LOW);
            libraryChannel.setDescription(localeContext.getString(
                R.string.notification_channel_library_desc));
            libraryChannel.setShowBadge(false);
            libraryChannel.setSound(null, null);
            libraryChannel.enableVibration(false);
            mNotificationManager.createNotificationChannel(libraryChannel);
        }
    }

    // ============================================================================
    // Shutdown
    // ============================================================================

    /**
     * Releases the singleton.
     */
    public void shutdown() {
        stopAwareness();
        unregisterThemeReceiver();

        synchronized (mLibraryLock) {
            mLibraryShowing = false;
            mLibraryMessage = null;
            mLibraryOperationId = null;
            mLibraryStartTime = 0L;
        }
        synchronized (mPlaybackLock) {
            if (mNotificationManager != null) {
                mNotificationManager.cancel(ID_PLAYBACK);
                mNotificationManager.cancel(ID_LIBRARY);
            }
        }
        mPlaybackForeground.set(false);
        mService = null;
        mStateSource = null;
        mLastRenderedSnapshot = null;
        mLastCommittedGeneration = -1L;
        mThemedPlaceholder = null;
        mThemedPlaceholderColor = 0;

        mThemedIconCache.clear();
        mContentIntent = null;
        mCloseIntent = null;
        mDeleteIntent = null;
        mPlayPauseIntent = null;
        mNextIntent = null;
        mPreviousIntent = null;

        sInstance = null;
    }
}