// ToastManager.java
package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Owns every in-activity toast and persistent overlay the app shows,
 * and drives their lifecycle through an operation stack.
 *
 * <p>Persistent overlays are owned by operations. An operation is
 * registered on the stack by its operation ID. The stack renders the
 * operation at the top; a lower operation's message is retained but
 * not shown while a higher operation is active, and surfaces
 * automatically when the higher operation ends.</p>
 *
 * <p>Each activity maintains its own overlay view instances, tracked
 * in {@link #mOverlayMap}. An activity's overlays are removed only
 * when the activity is destroyed. A periodic health check treats a
 * persistent overlay whose owner has stopped heartbeating, or an
 * overlay whose view has been detached from its parent, as stuck and
 * runs a recovery pass.</p>
 *
 * <p>Every persistent overlay is mirrored to the status bar through
 * {@link NotificationController}. The mirror is bound to the
 * operation ID at the top of the stack at the moment the overlay is
 * rendered, so a hide or update that arrives after another operation
 * has taken over the top of the stack is refused by
 * {@link NotificationController}'s own ownership check. Temporary
 * toasts are not mirrored.</p>
 *
 * <h3>Width Ownership</h3>
 * <p>A persistent overlay's available width is a pure function of the
 * root view the overlay was attached to, computed by
 * {@link #resolveAvailableToastWidthPx(ViewGroup)}. Every render of a
 * persistent overlay's text re-reads that source.</p>
 *
 * <h3>Title and Body Ownership</h3>
 * <p>A persistent overlay's message is the title rendered in the
 * overlay's text view, joined with the body by a middle dot when the
 * body is not empty. The notification mirror receives the title and
 * the body as separate strings and places each in its own slot.</p>
 *
 * <h3>Two Overlay Kinds, Two Lifecycles</h3>
 * <p>Persistent overlays are owned by an operation on the stack.
 * Temporary toasts are owned by the manager and end when the timer
 * elapses. A temporary toast can be shown while a persistent overlay
 * is active; it is drawn on top of the persistent overlay and
 * disappears without touching it.</p>
 *
 * <h3>Theme Application</h3>
 * <p>When a {@code THEME_COLOR_CHANGED} broadcast arrives, every
 * persistent overlay's view is removed and re-created through
 * {@link #createOverlayInView(Activity, ViewGroup, String, boolean,
 * String, String)}, which reads the current theme color at
 * construction. No view is repainted in place. Temporary toasts are
 * not rebuilt; their lifetime is shorter than a rebuild would
 * require, and the next temporary toast is constructed against the
 * new color anyway.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The manager is a process-wide singleton initialised through
 * {@link #init(Context)}. It registers itself as an
 * {@link Application.ActivityLifecycleCallbacks} listener and a
 * receiver for theme color change broadcasts. The health check starts
 * with the instance and runs until {@link #shutdown()}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. State transitions
 * and view mutation run on {@link #mMainHandler}. The current state,
 * the activity flag, and the shutdown flag are atomic. The overlay
 * map, the message map, and the heartbeat map are
 * {@link ConcurrentHashMap}s and the order list is a
 * {@link CopyOnWriteArrayList}.</p>
 *
 * @see NotificationController
 * @see State
 * @see Event
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.0.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "ToastManager";

    /** Duration of a short toast, in milliseconds. */
    public static final long LENGTH_SHORT = 500L;

    /** Duration of a normal toast, in milliseconds. */
    public static final long LENGTH_NORMAL = 1000L;

    /** Duration of a long toast, in milliseconds. */
    public static final long LENGTH_LONG = 2000L;

    /** Duration of the fade-in and fade-out animation, in ms. */
    private static final int FADE_DURATION_MS = 150;

    /** Horizontal inset on each side of the window, in dp. */
    private static final int TOAST_HORIZONTAL_INSET_DP = 16;

    /** Horizontal padding inside a toast, in dp. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 8;

    /** Vertical padding inside a toast, in dp. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;

    /** Distance from the bottom edge (full layout), in dp. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;

    /** Distance from the bottom edge (compact layout), in dp. */
    private static final int TOAST_BOTTOM_MARGIN_COMPACT_DP = 68;

    /** Window height at or below which the compact margin is used. */
    private static final int COMPACT_LAYOUT_HEIGHT_DP = 400;

    /** Corner radius of the toast background, in dp. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;

    /** Stroke width of the toast border, in dp. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;

    /** Elevation of the toast, in dp. */
    private static final int TOAST_ELEVATION_DP = 6;

    /** Background color of the toast. */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;

    /** Stroke color of the toast border. */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500L;

    /** Inactivity timeout for persistent overlays, in milliseconds. */
    private static final long STUCK_TIMEOUT_MS = 1000L;

    /** Delay before running recovery, in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500L;

    /** Prefix for the per-activity key of a temporary toast. */
    private static final String KEY_TEMP_TOAST_PREFIX = "TEMP_TOAST_";

    /** Activity key used for root-view-only toasts. */
    private static final String KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY";

    /** Separator between a title and a body in a persistent overlay. */
    private static final String OVERLAY_SEPARATOR = " \u00B7 ";

    // ============================================================================
    // State Machine
    // ============================================================================

    /**
     * States of the toast state machine.
     */
    public enum State {

        /** No overlay is showing. */
        HIDDEN,

        /** At least one temporary toast is showing. */
        SHOWING_TEMPORARY,

        /** A persistent overlay is showing. */
        SHOWING_PERSISTENT,

        /** An overlay is being hidden. */
        HIDING,

        /** A persistent overlay is being reattached. */
        REATTACHING,

        /** A stuck overlay has been detected and recovery is running. */
        STUCK
    }

    /**
     * Events that drive the state machine.
     */
    public enum Event {

        /** Show a temporary toast. */
        SHOW_TEMPORARY,

        /** Show a persistent overlay. */
        SHOW_PERSISTENT,

        /** Update the text of the current persistent overlay. */
        UPDATE,

        /** Record a heartbeat. */
        HEARTBEAT,

        /** Hide the current persistent overlay. */
        HIDE,

        /** Hide every overlay. */
        FORCE_HIDE,

        /** Reattach the current persistent overlay. */
        REATTACH,

        /** Mark the current overlay as stuck. */
        STUCK_DETECTED,

        /** Complete recovery from a stuck state. */
        RECOVERED
    }

    /**
     * Returns whether the given state represents an active persistent
     * overlay.
     *
     * @param state State to test, or null
     * @return True when the state represents an active persistent
     *         overlay
     */
    private static boolean isPersistentActive(@Nullable State state) {
        return state == State.SHOWING_PERSISTENT
            || state == State.REATTACHING;
    }

    // ============================================================================
    // Listener Interfaces
    // ============================================================================

    /**
     * Receives toast state changes and stuck detection events.
     */
    public interface ToastStateListener {

        /**
         * Called when the toast state changes.
         *
         * @param oldState State before the transition
         * @param newState State after the transition
         */
        void onStateChanged(@NonNull State oldState,
                            @NonNull State newState);

        /**
         * Called when a stuck overlay is detected.
         *
         * @param reason Reason the overlay was considered stuck
         * @param ageMs Duration the overlay had been showing
         * @param inactiveTimeMs Time since the last heartbeat or update
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs,
                                  long inactiveTimeMs);
    }

    // ============================================================================
    // Per-Activity Overlay Tracking
    // ============================================================================

    /**
     * Holds the overlay views for a single overlay instance.
     */
    private static class OverlayHolder {

        /** Weak reference to the overlay container view. */
        final WeakReference<FrameLayout> overlayRef;

        /** Weak reference to the text view inside the overlay. */
        final WeakReference<TextView> textViewRef;

        /** Weak reference to the activity that owns the overlay. */
        final WeakReference<Activity> activityRef;

        /** Weak reference to the root view the overlay was attached to. */
        final WeakReference<ViewGroup> rootViewRef;

        /** Message the overlay was created with. */
        final String message;

        /** Operation ID the overlay was created with, or null. */
        final String operationId;

        /** True when the overlay is persistent. */
        final boolean isPersistent;

        /**
         * Constructs a holder.
         *
         * @param overlay Overlay container
         * @param textView Text view inside the overlay
         * @param activity Activity that owns the overlay
         * @param rootView Root view the overlay was attached to
         * @param message Message the overlay was created with
         * @param operationId Operation ID the overlay was created with
         * @param isPersistent True for persistent, false for temporary
         */
        OverlayHolder(FrameLayout overlay, TextView textView,
                      Activity activity, ViewGroup rootView,
                      String message, String operationId,
                      boolean isPersistent) {
            this.overlayRef = new WeakReference<>(overlay);
            this.textViewRef = new WeakReference<>(textView);
            this.activityRef = new WeakReference<>(activity);
            this.rootViewRef = new WeakReference<>(rootView);
            this.message = message;
            this.operationId = operationId;
            this.isPersistent = isPersistent;
        }

        /**
         * Returns whether both the overlay and its text view are still
         * reachable.
         *
         * @return True when the overlay and text view can be used
         */
        boolean isValid() {
            return overlayRef.get() != null
                && textViewRef.get() != null;
        }

        /**
         * Detaches the overlay view from its parent.
         */
        void cleanup() {
            FrameLayout overlay = overlayRef.get();
            if (overlay != null && overlay.getParent() != null) {
                try {
                    ((ViewGroup) overlay.getParent())
                        .removeView(overlay);
                } catch (Exception ignored) {
                    // The view was already detached.
                }
            }
        }
    }

    /**
     * Map of overlay key to overlay holder.
     */
    private final ConcurrentHashMap<String, OverlayHolder> mOverlayMap =
        new ConcurrentHashMap<>();

    // ============================================================================
    // Operation Stack
    // ============================================================================

    /** Operation IDs currently on the stack. */
    private final CopyOnWriteArrayList<String> mOperationOrder =
        new CopyOnWriteArrayList<>();

    /** Message currently held by each operation. */
    private final ConcurrentHashMap<String, String> mOperationMessages =
        new ConcurrentHashMap<>();

    /** Body currently held by each operation. */
    private final ConcurrentHashMap<String, String> mOperationBodies =
        new ConcurrentHashMap<>();

    /** Timestamp of the last heartbeat for each operation. */
    private final ConcurrentHashMap<String, Long> mOperationHeartbeats =
        new ConcurrentHashMap<>();

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;

    /** Application instance used for lifecycle callbacks. */
    @Nullable
    private static Application sApplication;

    /** Main-thread handler. */
    @NonNull
    private final Handler mMainHandler =
        new Handler(Looper.getMainLooper());

    /** Handler for the periodic health check. */
    @NonNull
    private final Handler mHealthHandler =
        new Handler(Looper.getMainLooper());

    // ============================================================================
    // State Machine Variables
    // ============================================================================

    /** Current state of the state machine. */
    private final AtomicReference<State> mState =
        new AtomicReference<>(State.HIDDEN);

    /** Timestamp at which the current state began. */
    private final AtomicLong mStateStartTime = new AtomicLong(0L);

    /** Timestamp of the last heartbeat or update. */
    private final AtomicLong mLastActivityTime = new AtomicLong(0L);

    /** Timestamp of the last valid overlay. */
    private final AtomicLong mLastValidOverlayTime =
        new AtomicLong(0L);

    /** True while recovery is running. */
    private final AtomicBoolean mIsRecovering =
        new AtomicBoolean(false);

    /** Runnable for the periodic health check. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Runnable for the current recovery. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock that serialises health checks. */
    private final Object mHealthLock = new Object();

    /** Lock that serialises stack mutations. */
    private final Object mStackLock = new Object();

    // ========================================================================
    // Auto-Dismiss Management
    // ========================================================================

    /** Pending auto-dismiss runnables. */
    private final ConcurrentHashMap<String, Runnable> mPendingAutoDismiss =
        new ConcurrentHashMap<>();

    /** Weak reference to the currently resumed activity. */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;

    /** True once the lifecycle callbacks have been registered. */
    private boolean mCallbacksRegistered = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Receiver for theme color change broadcasts, or null. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;

    // ========================================================================
    // Listeners
    // ========================================================================

    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners =
        new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor and Initialization
    // ========================================================================

    /**
     * Constructs the singleton.
     *
     * @param context A context; the application context is retained
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        mState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());
        Log.d(TAG, "ToastManager initialized");
    }

    /**
     * Initializes the singleton.
     *
     * @param context A context; the application context is retained
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance
     * @throws IllegalStateException When {@link #init(Context)} has
     *         not yet been called
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException(
                "ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ========================================================================
    // Public API - Operation Stack
    // ========================================================================

    /**
     * Returns whether the given operation is currently on the stack.
     *
     * @param operationId Operation ID to test, or null
     * @return True when the operation is on the stack
     */
    public static boolean isOperationRunning(
            @Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        return getInstance().mOperationOrder.contains(operationId);
    }

    /**
     * Removes the given operation from the stack.
     *
     * @param operationId Operation ID to cancel, or null
     */
    public static void cancelOperation(
            @Nullable String operationId) {
        if (operationId == null) {
            return;
        }
        getInstance().popOperationInternal(operationId);
    }

    /**
     * Returns the operation ID currently on top of the stack, or
     * null when the stack is empty.
     *
     * @return The top operation ID, or null
     */
    @Nullable
    public static String getCurrentOperationId() {
        ToastManager toastManager = getInstance();
        List<String> order = toastManager.mOperationOrder;
        if (order.isEmpty()) {
            return null;
        }
        return order.get(order.size() - 1);
    }

    /**
     * Returns the message currently held by the given operation, or
     * null when the operation is not on the stack.
     *
     * @param operationId Operation ID to inspect, or null
     * @return The operation's message, or null
     */
    @Nullable
    public static String getOperationMessage(
            @Nullable String operationId) {
        if (operationId == null) {
            return null;
        }
        return getInstance().mOperationMessages.get(operationId);
    }

    // ========================================================================
    // State Machine Methods
    // ========================================================================

    /**
     * Transitions to the given state and notifies every listener.
     *
     * @param newState State to transition to
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mState.getAndSet(newState);
        if (oldState == newState) {
            return;
        }
        Log.d(TAG, "State transition: " + oldState + " \u2192 "
            + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener",
                    exception);
            }
        }
    }

    /**
     * Recomputes the state machine's state from the current contents
     * of the overlay map and the operation stack.
     */
    private void recomputeStateFromMap() {
        State currentState = mState.get();
        if (currentState == State.REATTACHING) {
            return;
        }

        boolean hasPersistent = false;
        boolean hasTemporary = false;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                hasPersistent = true;
            } else {
                hasTemporary = true;
            }
        }

        boolean hasOperations;
        synchronized (mStackLock) {
            hasOperations = !mOperationOrder.isEmpty();
        }

        if (hasPersistent || hasOperations) {
            transitionTo(State.SHOWING_PERSISTENT);
        } else if (hasTemporary) {
            transitionTo(State.SHOWING_TEMPORARY);
        } else {
            transitionTo(State.HIDDEN);
        }
    }

    /**
     * Dispatches the given event through the state machine.
     *
     * @param event Event to dispatch
     * @return True when the event changed the state
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);

        switch (event) {
            case SHOW_TEMPORARY:  return handleShowTemporary(currentState);
            case SHOW_PERSISTENT: return handleShowPersistent(currentState);
            case UPDATE:          return handleUpdate(currentState);
            case HEARTBEAT:       return handleHeartbeat(currentState);
            case HIDE:            return handleHide(currentState);
            case FORCE_HIDE:      return handleForceHide(currentState);
            case REATTACH:        return handleReattach(currentState);
            case STUCK_DETECTED:  return handleStuckDetected(currentState);
            case RECOVERED:       return handleRecovered(currentState);
            default:              return false;
        }
    }

    /**
     * Handles a {@link Event#SHOW_TEMPORARY} event.
     *
     * @param currentState State before the event
     * @return True when the event was accepted
     */
    private boolean handleShowTemporary(State currentState) {
        if (currentState == State.HIDDEN
                || currentState == State.HIDING
                || currentState == State.SHOWING_TEMPORARY) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        Log.w(TAG, "SHOW_TEMPORARY in state " + currentState
            + " — refusing");
        return false;
    }

    /**
     * Handles a {@link Event#SHOW_PERSISTENT} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleShowPersistent(State currentState) {
        transitionTo(State.SHOWING_PERSISTENT);
        return true;
    }

    /**
     * Handles an {@link Event#UPDATE} event.
     *
     * @param currentState State before the event
     * @return True when the update was accepted
     */
    private boolean handleUpdate(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update persistent overlay in state: "
            + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#HEARTBEAT} event.
     *
     * @param currentState State before the event
     * @return True when the heartbeat was accepted
     */
    private boolean handleHeartbeat(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#HIDE} event.
     *
     * @param currentState State before the event
     * @return True when the hide was accepted
     */
    private boolean handleHide(State currentState) {
        if (isPersistentActive(currentState)) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true;
        }
        Log.w(TAG, "Cannot hide persistent overlay in state: "
            + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#FORCE_HIDE} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleForceHide(State currentState) {
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }

    /**
     * Handles a {@link Event#REATTACH} event.
     *
     * @param currentState State before the event
     * @return True when the reattach was accepted
     */
    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        if (currentState == State.REATTACHING) {
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#STUCK_DETECTED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleStuckDetected(State currentState) {
        if (isPersistentActive(currentState)
                || currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Overlay stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#RECOVERED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }

    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================

    /**
     * Registers the lifecycle callbacks with the application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) {
            return;
        }
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    @Override
    public void onActivityCreated(Activity activity,
                                  Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    /**
     * Sets the current activity reference and reattaches the top
     * operation's overlay to the newly resumed activity when a
     * persistent overlay is active or an operation is still on the
     * stack.
     *
     * @param activity Activity that resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);

        State currentState = mState.get();
        boolean hasOperations = !mOperationOrder.isEmpty();

        if (isPersistentActive(currentState) || hasOperations) {
            if (currentState == State.SHOWING_PERSISTENT) {
                handleEvent(Event.REATTACH);
            } else if (!isPersistentActive(currentState)) {
                transitionTo(State.SHOWING_PERSISTENT);
            }
            reattachToActivity(activity);
        } else if (currentState == State.SHOWING_TEMPORARY) {
            Log.d(TAG, "Temporary toast showing, not reattaching "
                + "(auto-dismiss will handle it)");
        }
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    /**
     * Clears the current activity reference and runs a health check.
     *
     * @param activity Activity that stopped
     */
    @Override
    public void onActivityStopped(Activity activity) {
        if (mCurrentActivityRef != null
                && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity,
                                            Bundle outState) {
    }

    /**
     * Clears the current activity reference, removes its overlay
     * holders, and runs a health check.
     *
     * @param activity Activity that was destroyed
     */
    @Override
    public void onActivityDestroyed(Activity activity) {
        if (mCurrentActivityRef != null
                && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }

        String activityKey = getActivityKey(activity);
        String tempKey = getTempToastKey(activity);

        OverlayHolder persistentHolder =
            mOverlayMap.remove(activityKey);
        if (persistentHolder != null) {
            persistentHolder.cleanup();
        }

        OverlayHolder tempHolder = mOverlayMap.remove(tempKey);
        if (tempHolder != null) {
            tempHolder.cleanup();
        }

        Runnable pending = mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            mMainHandler.removeCallbacks(pending);
        }

        recomputeStateFromMap();
        performHealthCheck();
    }

    // ========================================================================
    // Theme Management
    // ========================================================================

    /**
     * Registers a receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (sApplication == null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context,
                                  @NonNull Intent intent) {
                if (ThemeManager.ACTION_THEME_COLOR_CHANGED
                        .equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        ContextCompat.registerReceiver(
            sApplication, mThemeReceiver,
            new IntentFilter(
                ThemeManager.ACTION_THEME_COLOR_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Rebuilds every visible persistent overlay's view hierarchy so
     * the current theme color is applied to freshly constructed
     * views.
     *
     * <p>No view is repainted in place: each persistent overlay's
     * view is removed from the window and re-created through
     * {@link #createOverlayInView(Activity, ViewGroup, String,
     * boolean, String, String)}, which reads the current theme
     * color at construction. The operation stack is untouched, so
     * the message, its heartbeat, and the notification mirror's
     * ownership token all survive the rebuild.</p>
     *
     * <p>Temporary toasts are not rebuilt; their lifetime is
     * shorter than a rebuild would require, and the next temporary
     * toast is constructed against the new color anyway.</p>
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                toastManager.rebuildPersistentOverlaysForTheme();
            }
        });
    }

    /**
     * Removes every persistent overlay's view and re-creates it in
     * the currently resumed activity's window.
     *
     * <p>The message is read from the operation on top of the stack
     * before the teardown, so a concurrent update that lands
     * between the teardown and the re-attach is not overwritten by
     * the rebuild.</p>
     *
     * <p>No-op when no persistent overlays are attached, or when
     * no activity is resumed to attach to. In the latter case the
     * overlay stays on the stack and the next resume rebuilds it
     * through the ordinary reattach path.</p>
     */
    private void rebuildPersistentOverlaysForTheme() {
        final String topId = getCurrentOperationId();
        if (topId == null) {
            return;
        }
        final String title = mOperationMessages.get(topId);
        if (title == null) {
            return;
        }
        final String body = mOperationBodies.get(topId) != null
            ? mOperationBodies.get(topId) : "";
        final String message = composeOverlayText(title, body);

        boolean removedAny = false;
        for (Map.Entry<String, OverlayHolder> entry
                : new ArrayList<>(mOverlayMap.entrySet())) {
            if (entry.getValue().isPersistent) {
                entry.getValue().cleanup();
                mOverlayMap.remove(entry.getKey());
                removedAny = true;
            }
        }
        if (!removedAny) {
            return;
        }

        final Activity current = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        if (current == null
                || current.isFinishing() || current.isDestroyed()) {
            return;
        }

        final ViewGroup root = (ViewGroup) current.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            return;
        }

        final String key = getActivityKey(current);
        createOverlayInView(current, root, message, true, key, topId);
        mCurrentActivityRef = new WeakReference<>(current);
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());
    }

    /**
     * Returns the current theme color, falling back to the default
     * when the theme manager is unavailable.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) {
                return DEFAULT_THEME_COLOR;
            }
            ThemeManager themeManager =
                ThemeManager.getInstance(sApplication);
            return themeManager != null
                ? themeManager.getCurrentColorInt()
                : DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    // ========================================================================
    // Toast Position
    // ========================================================================

    /**
     * Returns the bottom margin the next toast should use, based on
     * the current window height.
     *
     * @return The bottom margin in density-independent pixels
     */
    private int resolveBottomMarginDp() {
        if (sApplication == null) {
            return TOAST_BOTTOM_MARGIN_DP;
        }
        try {
            final Configuration configuration =
                sApplication.getResources().getConfiguration();
            final int heightDp = configuration.screenHeightDp;
            if (heightDp > 0
                    && heightDp <= COMPACT_LAYOUT_HEIGHT_DP) {
                return TOAST_BOTTOM_MARGIN_COMPACT_DP;
            }
        } catch (Exception exception) {
            Log.w(TAG,
                "Failed to read window height for toast margin",
                exception);
        }
        return TOAST_BOTTOM_MARGIN_DP;
    }

    // ========================================================================
    // Health Check
    // ========================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new HealthCheckRunnable(this);
        mHealthHandler.postDelayed(
            mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: "
            + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Health-check runnable.
     */
    private static class HealthCheckRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run health checks against
         */
        HealthCheckRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }
            manager.performHealthCheck();
            if (manager.mHealthCheckRunnable != null) {
                manager.mHealthHandler.postDelayed(
                    this, HEALTH_CHECK_INTERVAL_MS);
            }
        }
    }

    /**
     * Runs the health check.
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mState.get();
            if (currentState != State.SHOWING_TEMPORARY
                    && !isPersistentActive(currentState)) {
                return;
            }

            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();

            boolean hasValidPersistent = false;
            for (OverlayHolder holder : mOverlayMap.values()) {
                if (holder.isPersistent && holder.isValid()) {
                    hasValidPersistent = true;
                    mLastValidOverlayTime.set(now);
                    break;
                }
            }

            boolean isStuck = false;
            String stuckReason = null;

            if (isPersistentActive(currentState)
                    && !hasValidPersistent) {
                long noOverlayDuration =
                    now - mLastValidOverlayTime.get();
                if (noOverlayDuration > STUCK_TIMEOUT_MS) {
                    isStuck = true;
                    stuckReason = "Persistent overlay missing for "
                        + noOverlayDuration
                        + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
                }
            } else if (isPersistentActive(currentState)) {
                String topId = getCurrentOperationId();
                if (topId != null) {
                    Long heartbeat = mOperationHeartbeats.get(topId);
                    long lastActivity = heartbeat != null
                        ? heartbeat : mStateStartTime.get();
                    long inactiveTime = now - lastActivity;
                    if (inactiveTime > STUCK_TIMEOUT_MS) {
                        isStuck = true;
                        stuckReason = "No heartbeat for operation '"
                            + topId + "' in " + inactiveTime
                            + "ms (timeout: " + STUCK_TIMEOUT_MS
                            + "ms)";
                    }
                }
            }

            if (isStuck) {
                Log.w(TAG, "STUCK OVERLAY DETECTED: " + stuckReason);

                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason,
                            age, now - mLastActivityTime.get());
                    } catch (Exception exception) {
                        Log.e(TAG,
                            "Error notifying stuck listener",
                            exception);
                    }
                }

                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }

    /**
     * Starts the recovery pass from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        Log.d(TAG, "Starting overlay recovery");
        cancelRecovery();

        mRecoveryRunnable = new RecoveryRunnable(this);
        mMainHandler.postDelayed(
            mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Recovery runnable.
     */
    private static class RecoveryRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run recovery against
         */
        RecoveryRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }
            Log.d(TAG, "Overlay recovery completed");
            manager.forceHideAllOverlays();
            manager.handleEvent(Event.RECOVERED);
            manager.mIsRecovering.set(false);
            manager.mRecoveryRunnable = null;
        }
    }

    /**
     * Cancels the pending recovery. Idempotent.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================

    /**
     * Returns the activity that is currently resumed.
     *
     * @return The current activity, or null when none is tracked
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }

    // ========================================================================
    // Public API - Heartbeat
    // ========================================================================

    /**
     * Records a heartbeat for the given operation.
     *
     * @param operationId Operation ID to heartbeat, or null
     * @return True when the heartbeat was accepted
     */
    public static boolean heartbeat(@Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        ToastManager toastManager = getInstance();
        if (!toastManager.mOperationOrder.contains(operationId)) {
            return false;
        }
        toastManager.mOperationHeartbeats.put(
            operationId, SystemClock.elapsedRealtime());
        toastManager.mLastActivityTime.set(
            SystemClock.elapsedRealtime());
        return toastManager.handleEvent(Event.HEARTBEAT);
    }

    // ========================================================================
    // Public API - Temporary Toasts
    // ========================================================================

    /**
     * Shows a temporary toast in the given activity for the given
     * duration.
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToast(@NonNull Activity activity,
                                 @NonNull String message,
                                 long duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG,
                "Cannot show toast in finishing/destroyed activity");
            return;
        }

        String tempKey = getTempToastKey(activity);

        OverlayHolder existingTemp =
            toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        Runnable pending =
            toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(
            SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG,
                "Content view not found, cannot show toast");
            return;
        }

        toastManager.createOverlayInView(activity, root, message,
            false, tempKey, null);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(
            tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(
            dismissRunnable, duration);
    }

    /**
     * Auto-dismiss runnable.
     */
    private static class AutoDismissRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /** The overlay key this dismissal is responsible for. */
        private final String key;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager that owns the toast
         * @param key Overlay key this dismissal is responsible for
         */
        AutoDismissRunnable(ToastManager manager, String key) {
            this.managerRef = new WeakReference<>(manager);
            this.key = key;
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }

            OverlayHolder holder = manager.mOverlayMap.remove(key);
            if (holder == null) {
                manager.mPendingAutoDismiss.remove(key);
                return;
            }

            holder.cleanup();
            manager.recomputeStateFromMap();
            manager.mPendingAutoDismiss.remove(key);
        }
    }

    /**
     * Shows a temporary toast in the given activity for the long
     * duration.
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     */
    public static void showToast(@NonNull Activity activity,
                                 @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }

    /**
     * Shows a temporary toast inside the given view hierarchy.
     *
     * @param rootView View group to attach the toast to
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView,
                                       @NonNull String message,
                                       long duration) {
        ToastManager toastManager = getInstance();

        String tempKey = getTempToastKey(null);

        OverlayHolder existingTemp =
            toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        Runnable pending =
            toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(
            SystemClock.elapsedRealtime());

        toastManager.createOverlayInView(
            null, rootView, message, false, tempKey, null);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(
            tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(
            dismissRunnable, duration);
    }

    // ========================================================================
    // Public API - Persistent Overlay
    // ========================================================================

    /**
     * Shows a persistent overlay with no operation ID.
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     */
    public static void showPersistentOverlay(
            @NonNull Activity activity,
            @NonNull String message) {
        showPersistentOverlay(activity, message, "", null);
    }

    /**
     * Shows a persistent overlay with the given operation ID and no
     * notification body.
     *
     * @param activity Activity to show the overlay in
     * @param message Overlay text and mirror title
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(
            @NonNull Activity activity,
            @NonNull String message,
            @Nullable String operationId) {
        showPersistentOverlay(activity, message, "", operationId);
    }

    /**
     * Shows a persistent overlay with the given title and body.
     *
     * @param activity Activity to show the overlay in
     * @param title Overlay text and mirror title
     * @param body Notification mirror's body
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(
            @NonNull Activity activity,
            @NonNull String title,
            @NonNull String body,
            @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG,
                "Cannot show persistent overlay in "
                    + "finishing/destroyed activity");
            return;
        }

        if (operationId != null) {
            toastManager.pushOperationInternal(
                operationId, title, body);
        }

        toastManager.removeAllOverlayViews();

        toastManager.handleEvent(Event.SHOW_PERSISTENT);

        toastManager.mLastActivityTime.set(
            SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG,
                "Content view not found, cannot show persistent "
                    + "overlay");
            return;
        }

        String key = getActivityKey(activity);
        String renderedOperationId = getCurrentOperationId();
        String renderedTitle = renderedOperationId != null
            ? toastManager.mOperationMessages.get(renderedOperationId)
            : title;
        if (renderedTitle == null) {
            renderedTitle = title;
        }
        String renderedBody = renderedOperationId != null
            ? toastManager.mOperationBodies.get(renderedOperationId)
            : body;
        if (renderedBody == null) {
            renderedBody = body;
        }
        String renderedMessage =
            composeOverlayText(renderedTitle, renderedBody);

        toastManager.createOverlayInView(activity, root,
            renderedMessage, true, key, renderedOperationId);
        toastManager.mCurrentActivityRef =
            new WeakReference<>(activity);

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .showLibraryStatus(title, body,
                    renderedOperationId);
        }

        Log.d(TAG, "Persistent overlay shown: " + renderedMessage
            + (renderedOperationId != null
                ? " (ID: " + renderedOperationId + ")" : ""));
    }

    /**
     * Updates the text of the given operation with an empty body.
     *
     * @param message New overlay text and mirror title
     * @param operationId Operation ID that must be on the stack
     */
    public static void updatePersistentOverlay(
            @NonNull String message,
            @NonNull String operationId) {
        updatePersistentOverlay(message, "", operationId);
    }

    /**
     * Updates the overlay and the notification mirror with the given
     * title and body when the given operation is on the stack and on
     * top.
     *
     * @param title New overlay text and mirror title
     * @param body Notification mirror's body
     * @param operationId Operation ID that must be on the stack
     */
    public static void updatePersistentOverlay(
            @NonNull String title,
            @NonNull String body,
            @NonNull String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();

        if (!isPersistentActive(currentState)) {
            Log.w(TAG,
                "Cannot update persistent overlay - no persistent "
                    + "overlay is showing");
            return;
        }

        if (!toastManager.mOperationOrder.contains(operationId)) {
            Log.d(TAG,
                "Update rejected - operation not on stack: "
                    + operationId);
            return;
        }

        toastManager.mOperationMessages.put(operationId, title);
        toastManager.mOperationBodies.put(operationId, body);
        toastManager.mOperationHeartbeats.put(
            operationId, SystemClock.elapsedRealtime());

        if (!toastManager.handleEvent(Event.UPDATE)) {
            return;
        }

        String topId = getCurrentOperationId();
        if (!Objects.equals(topId, operationId)) {
            Log.v(TAG,
                "Operation updated below top of stack: "
                    + operationId);
            return;
        }

        final String composedMessage =
            composeOverlayText(title, body);

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (OverlayHolder holder
                        : toastManager.mOverlayMap.values()) {
                    if (!holder.isPersistent) {
                        continue;
                    }
                    TextView textView = holder.textViewRef.get();
                    if (textView == null) {
                        continue;
                    }
                    ViewGroup rootView = holder.rootViewRef.get();
                    if (rootView != null) {
                        textView.setMaxWidth(
                            toastManager
                                .resolveAvailableToastWidthPx(
                                    rootView));
                    }
                    textView.setText(composedMessage);
                }
            }
        });

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .updateLibraryStatus(title, body, operationId);
        }
    }

    /**
     * Hides the current persistent overlay when the given operation
     * is on the stack.
     *
     * @param operationId Operation ID to remove, or null
     * @return True when the operation was on the stack and was removed
     */
    public static boolean hidePersistentOverlay(
            @Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        ToastManager toastManager = getInstance();
        return toastManager.popOperationInternal(operationId);
    }

    /**
     * Hides every overlay and ends every operation regardless of ID.
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            final String currentId = getCurrentOperationId();
            toastManager.handleEvent(Event.FORCE_HIDE);
            toastManager.removeAllOverlayViews();
            toastManager.clearOperationStack();

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        }
    }

    /**
     * Returns whether a persistent overlay is currently active.
     *
     * @return True when a persistent overlay is active
     */
    public static boolean hasPersistentToast() {
        return isPersistentActive(getInstance().mState.get());
    }

    /**
     * Returns the text of the current persistent overlay.
     *
     * @return The current message, or null when no persistent
     *         overlay is showing
     */
    @Nullable
    public static String getPersistentToastText() {
        String topId = getCurrentOperationId();
        if (topId != null) {
            return getInstance().mOperationMessages.get(topId);
        }
        return null;
    }

    // ========================================================================
    // Stack Internals
    // ========================================================================

    /**
     * Pushes an operation onto the stack.
     *
     * @param operationId Operation ID to push
     * @param message Initial message
     * @param body Initial body
     */
    private void pushOperationInternal(@NonNull String operationId,
                                       @NonNull String message,
                                       @NonNull String body) {
        synchronized (mStackLock) {
            mOperationOrder.remove(operationId);
            mOperationMessages.put(operationId, message);
            mOperationBodies.put(operationId, body);
            mOperationHeartbeats.put(
                operationId, SystemClock.elapsedRealtime());
            mOperationOrder.add(operationId);
        }
    }

    /**
     * Removes the given operation from the stack.
     *
     * @param operationId Operation ID to remove
     * @return True when the operation was on the stack
     */
    private boolean popOperationInternal(
            @NonNull String operationId) {
        String newTopId;
        boolean wasTop;

        synchronized (mStackLock) {
            if (!mOperationOrder.contains(operationId)) {
                return false;
            }
            wasTop = operationId.equals(
                mOperationOrder.get(mOperationOrder.size() - 1));
            mOperationOrder.remove(operationId);
            mOperationMessages.remove(operationId);
            mOperationBodies.remove(operationId);
            mOperationHeartbeats.remove(operationId);
            newTopId = mOperationOrder.isEmpty()
                ? null
                : mOperationOrder.get(mOperationOrder.size() - 1);
        }

        if (!wasTop) {
            Log.v(TAG,
                "Popped operation below top of stack: "
                    + operationId);
            return true;
        }

        if (newTopId == null) {
            handleEvent(Event.HIDE);
            final String currentId = operationId;
            removePersistentOverlayViews(true);
            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        } else {
            String newTitle = mOperationMessages.get(newTopId);
            if (newTitle == null) {
                newTitle = "";
            }
            String newBody = mOperationBodies.get(newTopId);
            if (newBody == null) {
                newBody = "";
            }
            final String finalMessage =
                composeOverlayText(newTitle, newBody);
            final String finalTitle = newTitle;
            final String finalBody = newBody;
            final String finalTopId = newTopId;
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    for (OverlayHolder holder
                            : mOverlayMap.values()) {
                        if (!holder.isPersistent) {
                            continue;
                        }
                        TextView textView =
                            holder.textViewRef.get();
                        if (textView == null) {
                            continue;
                        }
                        ViewGroup rootView =
                            holder.rootViewRef.get();
                        if (rootView != null) {
                            textView.setMaxWidth(
                                resolveAvailableToastWidthPx(
                                    rootView));
                        }
                        textView.setText(finalMessage);
                    }
                }
            });
            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .showLibraryStatus(
                        finalTitle, finalBody, finalTopId);
            }
        }
        return true;
    }

    /**
     * Clears every operation from the stack.
     */
    private void clearOperationStack() {
        synchronized (mStackLock) {
            mOperationOrder.clear();
            mOperationMessages.clear();
            mOperationBodies.clear();
            mOperationHeartbeats.clear();
        }
    }

    // ========================================================================
    // Reattach Methods
    // ========================================================================

    /**
     * Reattaches the current persistent overlay to the given
     * activity.
     *
     * @param activity Activity to reattach the overlay to
     */
    public static void reattachToCurrentActivity(
            @NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();

        if (!isPersistentActive(currentState)
                && toastManager.mOperationOrder.isEmpty()) {
            return;
        }

        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing()
                        || activity.isDestroyed()) {
                    return;
                }

                State currentStateCheck =
                    toastManager.mState.get();
                if (currentStateCheck == State.HIDDEN
                        && toastManager.mOperationOrder.isEmpty()) {
                    return;
                }

                if (isPersistentActive(currentStateCheck)) {
                    toastManager.handleEvent(Event.REATTACH);
                } else {
                    toastManager.transitionTo(
                        State.SHOWING_PERSISTENT);
                }
                toastManager.reattachToActivity(activity);
            }
        });
    }

    /**
     * Ensures the current persistent overlay is attached to the
     * given activity's window.
     *
     * @param activity Activity the overlay should be attached to
     */
    public static void ensureOverlayAttached(
            @NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)
                && toastManager.mOperationOrder.isEmpty()) {
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder holder = toastManager.mOverlayMap.get(key);
        if (holder == null || !holder.isValid()) {
            reattachToCurrentActivity(activity);
        }
    }

    // ========================================================================
    // State Listeners
    // ========================================================================

    /**
     * Adds a toast state listener.
     *
     * @param listener Listener to add
     */
    public static void addStateListener(
            @NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        State currentState = toastManager.mState.get();
        listener.onStateChanged(currentState, currentState);
    }

    /**
     * Removes a toast state listener.
     *
     * @param listener Listener to remove
     */
    public static void removeStateListener(
            @NonNull ToastStateListener listener) {
        getInstance().mStateListeners.remove(listener);
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Composes an overlay's visible text from a title and a body.
     *
     * @param title Overlay's title
     * @param body Overlay's body, or an empty string
     * @return The composed overlay text
     */
    @NonNull
    private static String composeOverlayText(
            @NonNull String title,
            @NonNull String body) {
        return body.isEmpty()
            ? title
            : title + OVERLAY_SEPARATOR + body;
    }

    /**
     * Returns a unique key for the given activity.
     *
     * @param activity Activity to build a key for, or null
     * @return The key
     */
    @NonNull
    private static String getActivityKey(
            @Nullable Activity activity) {
        if (activity == null) {
            return KEY_ROOT_VIEW_ONLY;
        }
        return activity.getClass().getName() + "@"
            + System.identityHashCode(activity);
    }

    /**
     * Returns the temporary-toast key for the given activity.
     *
     * @param activity Activity to build a key for, or null
     * @return The temporary-toast key
     */
    @NonNull
    private static String getTempToastKey(
            @Nullable Activity activity) {
        return KEY_TEMP_TOAST_PREFIX + getActivityKey(activity);
    }

    // ========================================================================
    // Overlay Removal Methods
    // ========================================================================

    /**
     * Removes every overlay view from the map and detaches every
     * view.
     */
    private void removeAllOverlayViews() {
        for (OverlayHolder holder : mOverlayMap.values()) {
            holder.cleanup();
        }
        mOverlayMap.clear();

        for (Runnable pending : mPendingAutoDismiss.values()) {
            mMainHandler.removeCallbacks(pending);
        }
        mPendingAutoDismiss.clear();

        transitionTo(State.HIDDEN);
    }

    /**
     * Removes every persistent overlay view from the map.
     *
     * @param animate True to fade the overlays out before removing
     *        them
     */
    private void removePersistentOverlayViews(boolean animate) {
        List<String> keysToRemove = new ArrayList<>();
        for (Map.Entry<String, OverlayHolder> entry
                : mOverlayMap.entrySet()) {
            if (entry.getValue().isPersistent) {
                keysToRemove.add(entry.getKey());
            }
        }

        for (String key : keysToRemove) {
            OverlayHolder holder = mOverlayMap.remove(key);
            if (holder == null) {
                continue;
            }
            if (animate) {
                FrameLayout overlay = holder.overlayRef.get();
                if (overlay != null) {
                    AlphaAnimation fadeOut =
                        new AlphaAnimation(1f, 0f);
                    fadeOut.setDuration(FADE_DURATION_MS);
                    fadeOut.setAnimationListener(
                        new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(
                                Animation animation) {
                        }

                        @Override
                        public void onAnimationEnd(
                                Animation animation) {
                            removeOverlayView(overlay);
                        }

                        @Override
                        public void onAnimationRepeat(
                                Animation animation) {
                        }
                    });
                    overlay.startAnimation(fadeOut);
                }
            } else {
                holder.cleanup();
            }
        }

        recomputeStateFromMap();
    }

    /**
     * Removes every overlay view immediately, clears the operation
     * stack, and tears down the mirrored library notification.
     */
    private void forceHideAllOverlays() {
        removeAllOverlayViews();
        clearOperationStack();

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .clearLibraryStatus();
        }
    }

    // ========================================================================
    // View Management
    // ========================================================================

    /**
     * Creates an overlay view and attaches it to the given root
     * view under the given key.
     *
     * @param activity Activity the overlay belongs to, or null for a
     *        root-view-only toast
     * @param rootView View group to attach the overlay to
     * @param message Text to display
     * @param isPersistent True for a persistent overlay
     * @param key Overlay map key for the new holder
     * @param operationId Operation ID the overlay is bound to, or
     *        null
     */
    private void createOverlayInView(
            @Nullable Activity activity,
            @NonNull ViewGroup rootView,
            @NonNull String message,
            boolean isPersistent,
            @NonNull String key,
            @Nullable String operationId) {
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        FrameLayout container =
            new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams =
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        containerParams.gravity =
            Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(
            rootView.getContext(), resolveBottomMarginDp());
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);

        final int availableWidthPx =
            resolveAvailableToastWidthPx(rootView);

        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(1);
        textView.setHorizontallyScrolling(false);
        textView.setMaxWidth(availableWidthPx);
        textView.setPadding(
            dpToPx(rootView.getContext(),
                TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(),
                TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(),
                TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(),
                TOAST_PADDING_VERTICAL_DP));
        textView.setTextColor(getThemeColor());

        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(),
            TOAST_CORNER_RADIUS_DP));
        background.setStroke(
            dpToPx(rootView.getContext(),
                TOAST_STROKE_WIDTH_DP),
            TOAST_STROKE_COLOR);
        textView.setBackground(background);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(),
                TOAST_ELEVATION_DP));
        }

        container.addView(textView);
        rootView.addView(container);

        mOverlayMap.put(key, new OverlayHolder(
            container, textView, activity, rootView, message,
            operationId, isPersistent));
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());

        if (activity != null) {
            mCurrentActivityRef = new WeakReference<>(activity);
        }

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }

    /**
     * Creates a fresh persistent overlay for the given activity and
     * installs the current top-of-stack message in it.
     *
     * @param activity Activity to attach the overlay to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        String topId = getCurrentOperationId();
        if (topId == null) {
            Log.w(TAG, "Cannot reattach - stack is empty");
            return;
        }

        String title = mOperationMessages.get(topId);
        if (title == null) {
            Log.w(TAG,
                "Cannot reattach - no message available");
            return;
        }
        String body = mOperationBodies.get(topId);
        if (body == null) {
            body = "";
        }
        String message = composeOverlayText(title, body);

        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG,
                "Content view not found for reattachment");
            return;
        }

        createOverlayInView(activity, root, message, true, key,
            topId);
        mCurrentActivityRef = new WeakReference<>(activity);

        State currentState = mState.get();
        if (currentState != State.SHOWING_PERSISTENT) {
            transitionTo(State.SHOWING_PERSISTENT);
        }
    }

    /**
     * Removes the given overlay view from its parent.
     *
     * @param overlay Overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent())
                    .removeView(overlay);
            } catch (Exception ignored) {
                // The view was already detached.
            }
        }
    }

    /**
     * Returns the available width a toast may occupy, in pixels.
     *
     * @param rootView Content view the toast will be attached to
     * @return The available width in pixels
     */
    private int resolveAvailableToastWidthPx(
            @NonNull ViewGroup rootView) {
        final Context context = rootView.getContext();
        final int measuredWidth = rootView.getWidth();
        final int baseWidth = measuredWidth > 0
            ? measuredWidth
            : rootView.getResources()
                .getDisplayMetrics().widthPixels;
        final int insetPx =
            dpToPx(context, TOAST_HORIZONTAL_INSET_DP);
        return Math.max(0, baseWidth - insetPx * 2);
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp
            * context.getResources().getDisplayMetrics().density);
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns a human-readable snapshot of the manager's current
     * state.
     *
     * @return A multi-line string describing the current state
     */
    @NonNull
    public String getDebugInfo() {
        Activity currentActivity = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        int persistentCount = 0;
        int tempCount = 0;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                persistentCount++;
            } else {
                tempCount++;
            }
        }
        return "ToastManager\n"
            + "State: " + mState.get() + "\n"
            + "State duration: "
            + (SystemClock.elapsedRealtime()
                - mStateStartTime.get()) + "ms\n"
            + "Last activity: "
            + (SystemClock.elapsedRealtime()
                - mLastActivityTime.get()) + "ms ago\n"
            + "Last valid overlay: "
            + (SystemClock.elapsedRealtime()
                - mLastValidOverlayTime.get()) + "ms ago\n"
            + "Operation stack size: " + mOperationOrder.size()
            + "\n"
            + "Top operation: " + getCurrentOperationId() + "\n"
            + "Current activity: "
            + (currentActivity != null
                ? currentActivity.getClass().getSimpleName()
                : "null") + "\n"
            + "Persistent overlays: " + persistentCount + "\n"
            + "Temporary toasts: " + tempCount + "\n"
            + "Pending dismissals: " + mPendingAutoDismiss.size()
            + "\n"
            + "Listeners: " + mStateListeners.size();
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Releases every resource held by the manager.
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");

        for (Runnable pending
                : toastManager.mPendingAutoDismiss.values()) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }
        toastManager.mPendingAutoDismiss.clear();

        toastManager.cancelRecovery();

        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(
                toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }

        if (toastManager.mCallbacksRegistered
                && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(
                    toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {
                // The callbacks were already unregistered.
            }
        }

        if (toastManager.mThemeReceiver != null
                && sApplication != null) {
            try {
                sApplication.unregisterReceiver(
                    toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
        }

        toastManager.forceHideAllOverlays();

        sInstance = null;
        sApplication = null;
        Log.d(TAG, "ToastManager shut down complete");
    }
}