package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Centralized Toast Manager with automatic stuck toast detection and cleanup.
 * 
 * <p>This manager provides a custom toast implementation using styled overlays
 * instead of system Toasts, with theme color integration and fade animations.
 * Following Google's recommendations, it includes automatic detection and
 * cleanup of stuck toasts to prevent UI blocking.</p>
 * 
 * <h3>Stuck Toast Detection - Progress Based (No Duration Limit)</h3>
 * <p>The manager automatically detects and cleans up stuck toasts through
 * a continuous health check that runs every 5 seconds:</p>
 * 
 * <ul>
 *   <li><b>5 Second Health Check:</b> Runs every 5 seconds to verify overlay health</li>
 *   <li><b>Heartbeat Required:</b> Long operations MUST call heartbeat() every 5 seconds</li>
 *   <li><b>No Max Duration:</b> Toasts can run indefinitely with heartbeats</li>
 *   <li><b>Window Attachment Verification:</b> Detects toasts detached from destroyed activities</li>
 *   <li><b>Automatic Cleanup:</b> Only stuck toasts (no heartbeat for 5+ seconds) are removed</li>
 * </ul>
 * 
 * <h3>What Makes a Toast "Stuck"?</h3>
 * <p>A toast is considered stuck ONLY when:</p>
 * <ul>
 *   <li>It's a persistent overlay AND no heartbeat received for 5+ seconds</li>
 *   <li>The overlay is no longer attached to any window (activity destroyed)</li>
 *   <li>A temporary toast exceeds its expected duration (3 seconds max)</li>
 * </ul>
 * 
 * <p><b>Legitimate long-running operations (5+ minutes) are NOT considered stuck
 * as long as they send heartbeats every 5 seconds.</b></p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The manager follows Google's recommended patterns:</p>
 * <ul>
 *   <li><b>Singleton Pattern</b> - Single instance throughout app lifecycle</li>
 *   <li><b>ActivityLifecycleCallbacks</b> - Tracks activities for automatic reattachment</li>
 *   <li><b>WeakReference Usage</b> - Prevents memory leaks for views and activities</li>
 *   <li><b>Atomic State Management</b> - Thread-safe operations across components</li>
 * </ul>
 * 
 * <h3>Integration Points</h3>
 * <ul>
 *   <li>{@link ThemeManager} - Dynamic theme color application</li>
 *   <li>{@link MusicPlayer} - Main playback activity</li>
 *   <li>{@link FolderManager} - Folder management activity</li>
 *   <li>{@link NavigationController} - Button state management during sync</li>
 * </ul>
 * 
 * <h3>Usage Examples</h3>
 * <pre>
 * // Initialize in MusicPlayer.onCreate() (MANDATORY)
 * ToastManager.init(this);
 * 
 * // Show temporary toast
 * ToastManager.showToast(activity, "Operation complete", ToastManager.LENGTH_SHORT);
 * 
 * // Show persistent overlay with operation ID (recommended)
 * ToastManager.showPersistentOverlay(activity, "Loading songs...", "PLAYLIST_SYNC");
 * 
 * // IMPORTANT: Send heartbeat every 5 seconds during long operations
 * ToastManager.heartbeat("PLAYLIST_SYNC");
 * 
 * // Update progress text (also resets heartbeat timer)
 * ToastManager.updatePersistentOverlay("Loading metadata... 150/500 songs");
 * 
 * // Hide when complete (operation ID must match)
 * ToastManager.hidePersistentOverlay("PLAYLIST_SYNC");
 * 
 * // Force hide (no ID check)
 * ToastManager.hidePersistentOverlay();
 * 
 * // Check if persistent toast exists
 * if (ToastManager.hasPersistentToast()) { ... }
 * 
 * // Reattach after activity rotation
 * ToastManager.reattachToCurrentActivity(activity);
 * 
 * // Ensure overlay attached
 * ToastManager.ensureOverlayAttached(activity);
 * 
 * // Refresh theme color
 * ToastManager.refreshThemeColor();
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>All methods are thread-safe. UI operations are automatically posted to
 * the main thread. State variables use AtomicBoolean and AtomicLong for
 * safe concurrent access.</p>
 * 
 * @see ThemeManager
 * @see NavigationController
 * @see Application.ActivityLifecycleCallbacks
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "ToastManager";
    
    /** Short duration: 500 milliseconds - for quick notifications. */
    public static final int LENGTH_SHORT = 500;
    
    /** Normal duration: 1000 milliseconds - standard toast length. */
    public static final int LENGTH_NORMAL = 1000;
    
    /** Long duration: 2000 milliseconds - for messages that need more reading time. */
    public static final int LENGTH_LONG = 2000;
    
    /** Duration for fade in/out animations in milliseconds. */
    private static final int FADE_DURATION_MS = 150;
    
    /** Maximum toast width in density-independent pixels. */
    private static final int MAX_TOAST_WIDTH_DP = 320;
    
    /** Horizontal padding for toast content in dp. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;
    
    /** Vertical padding for toast content in dp. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;
    
    /** Bottom margin from screen edge in dp. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;
    
    /** Corner radius for toast background in dp. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;
    
    /** Stroke width for toast border in dp. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;
    
    /** Elevation for toast on Lollipop+ in dp. */
    private static final int TOAST_ELEVATION_DP = 6;
    
    /** Toast background color (dark gray). */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;
    
    /** Toast stroke color (slightly lighter gray). */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;
    
    /** Default theme color fallback (Royal Llama). */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;
    
    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    // ========================================================================
    // Health Check & Stuck Detection Constants (Progress-Based)
    // ========================================================================
    
    /** 
     * Health check interval in milliseconds (5 seconds). 
     * The health checker runs at this frequency to detect and clean up stale overlays.
     */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000;
    
    /** 
     * Stuck detection timeout (5 seconds).
     * If a persistent overlay receives NO heartbeat or update for 5 seconds,
     * it is considered stuck and will be automatically cleaned up.
     * 
     * <p>There is NO maximum duration limit - operations can run for hours
     * as long as they send heartbeats every 5 seconds.</p>
     */
    private static final long STUCK_TIMEOUT_MS = 5000;
    
    /** 
     * Maximum duration for temporary toasts (3 seconds).
     * Temporary toasts auto-hide after their duration, but if they exceed
     * 3 seconds due to a bug, they are cleaned up.
     */
    private static final long TEMP_TOAST_MAX_MS = 3000;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;
    
    /** Application context. */
    @Nullable
    private static Application sApplication;
    
    /** Main thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Health check handler. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Overlay State (Thread-Safe)
    // ========================================================================
    
    /** Current overlay container view (weak reference to prevent memory leaks). */
    @Nullable
    private WeakReference<FrameLayout> mOverlayRef = null;
    
    /** Current text view inside overlay (weak reference). */
    @Nullable
    private WeakReference<TextView> mTextViewRef = null;
    
    /** Flag indicating if overlay is currently showing. */
    private final AtomicBoolean mIsShowing = new AtomicBoolean(false);
    
    /** Flag indicating if this is a persistent overlay vs temporary. */
    private final AtomicBoolean mIsPersistent = new AtomicBoolean(false);
    
    /** Current message text being displayed. */
    @Nullable
    private String mCurrentMessage = null;
    
    /** Current operation ID for persistent overlay matching. */
    @Nullable
    private String mCurrentOperationId = null;
    
    /** Current activity reference (weak to prevent leaks). */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;
    
    /** Flag indicating if lifecycle callbacks are registered. */
    private boolean mCallbacksRegistered = false;
    
    /** Hide runnable for temporary toast (to cancel if needed). */
    @Nullable
    private Runnable mHideRunnable = null;
    
    // ========================================================================
    // Watchdog State (Progress-Based Stuck Detection)
    // ========================================================================
    
    /** Start time of current persistent overlay (for debugging only). */
    private final AtomicLong mOverlayStartTime = new AtomicLong(0);
    
    /** 
     * Last activity time for persistent overlay.
     * Updated on every heartbeat() and updatePersistent() call.
     */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);
    
    /** Health check runnable. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;
    
    /** Broadcast receiver for theme changes. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;
    
    // ========================================================================
    // Stuck Toast Listeners (Optional - for debugging)
    // ========================================================================
    
    /**
     * Listener interface for stuck toast detection events.
     */
    public interface StuckToastListener {
        
        /**
         * Called when a stuck toast is detected and cleaned up.
         *
         * @param reason The reason the toast was considered stuck
         * @param ageMs How long the toast had been showing in milliseconds
         * @param inactiveTimeMs Time since last activity (heartbeat or update)
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs, long inactiveTimeMs);
    }
    
    /** List of registered stuck toast listeners. */
    private static final CopyOnWriteArrayList<StuckToastListener> sStuckToastListeners = 
        new CopyOnWriteArrayList<>();
    
    // ========================================================================
    // Constructor and Initialization
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Any context (will be converted to application context)
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        Log.d(TAG, "ToastManager initialized successfully");
    }
    
    /**
     * Initializes the ToastManager singleton.
     * 
     * <p>This method MUST be called once, typically in MusicPlayer.onCreate().</p>
     *
     * @param context Any context (will be converted to application context)
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }
    
    /**
     * Returns the singleton instance of ToastManager.
     *
     * @return The ToastManager singleton instance
     * @throws IllegalStateException if ToastManager has not been initialized
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }
    
    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================
    
    /**
     * Registers activity lifecycle callbacks with the Application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered) return;
        if (sApplication == null) return;
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }
    
    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {}
    
    @Override
    public void onActivityStarted(@NonNull Activity activity) {}
    
    /**
     * Called when an activity resumes.
     * Updates current activity reference and reattaches any showing overlay.
     *
     * @param activity The activity being resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        
        if (mIsShowing.get()) {
            reattachToActivity(activity);
        }
    }
    
    @Override
    public void onActivityPaused(@NonNull Activity activity) {}
    
    /**
     * Called when an activity stops.
     * Clears activity reference if it matches the current one.
     *
     * @param activity The activity being stopped
     */
    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
    }
    
    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}
    
    /**
     * Called when an activity is destroyed.
     * Clears reference and triggers health check.
     *
     * @param activity The activity being destroyed
     */
    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }
    
    // ========================================================================
    // Theme Management
    // ========================================================================
    
    /**
     * Registers a broadcast receiver to listen for theme color changes.
     */
    private void registerThemeReceiver() {
        if (sApplication == null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        sApplication.registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Refreshes the overlay text color to match the current theme.
     * 
     * <p>This static method can be called from any activity when the theme changes.</p>
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                TextView textView = toastManager.getTextView();
                if (textView != null && toastManager.mIsShowing.get()) {
                    textView.setTextColor(toastManager.getThemeColor());
                }
            }
        });
    }
    
    /**
     * Gets the current theme color from ThemeManager.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) return DEFAULT_THEME_COLOR;
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception e) {
            return DEFAULT_THEME_COLOR;
        }
    }
    
    // ========================================================================
    // Health Check (Primary Stuck Toast Prevention)
    // ========================================================================
    
    /**
     * Starts the periodic health check thread.
     * Runs every 5 seconds indefinitely to monitor toast health.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: " + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }
    
    /**
     * Performs a comprehensive health check to detect stuck toasts.
     * 
     * <p>A toast is considered stuck ONLY if:
     * <ul>
     *   <li>It's not attached to any window (activity was destroyed)</li>
     *   <li>It's persistent AND no activity for 5+ seconds</li>
     *   <li>It's a temporary toast that exceeded 3 seconds</li>
     * </ul>
     * </p>
     * 
     * <p>There is NO maximum duration limit for persistent toasts.</p>
     */
    private void performHealthCheck() {
        if (!mIsShowing.get()) {
            return;
        }
        
        FrameLayout overlay = getOverlay();
        TextView textView = getTextView();
        long now = SystemClock.elapsedRealtime();
        long age = now - mOverlayStartTime.get();
        long inactiveTime = now - mLastActivityTime.get();
        boolean isAttached = overlay != null && overlay.getParent() != null;
        
        boolean isStuck = false;
        String stuckReason = null;
        
        // Check 1: Overlay exists but is not attached to any window
        if (overlay != null && !isAttached && mIsShowing.get()) {
            isStuck = true;
            stuckReason = "Overlay not attached to window";
        }
        // Check 2: TextView reference is gone but overlay still showing
        else if (textView == null && mIsShowing.get()) {
            isStuck = true;
            stuckReason = "TextView reference lost";
        }
        // Check 3: Persistent overlay with no activity for 5+ seconds
        else if (mIsPersistent.get() && inactiveTime > STUCK_TIMEOUT_MS) {
            isStuck = true;
            stuckReason = "No activity for " + inactiveTime + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
        }
        // Check 4: Temporary toast exceeded expected duration
        else if (!mIsPersistent.get() && mIsShowing.get() && age > TEMP_TOAST_MAX_MS) {
            isStuck = true;
            stuckReason = "Temporary toast stuck (age: " + age + "ms)";
        }
        
        if (isStuck) {
            Log.w(TAG, "STUCK TOAST DETECTED: " + stuckReason);
            notifyStuckToastDetected(stuckReason, age, inactiveTime);
            forceHideInternal();
        }
    }
    
    // ========================================================================
    // Public API - Heartbeat (Static)
    // ========================================================================
    
    /**
     * Sends a heartbeat for the current persistent overlay.
     * 
     * <p><b>CRITICAL:</b> Long-running operations MUST call this method every
     * 5 seconds to prevent the toast from being considered stuck.
     * Operations can run for hours as long as heartbeats are sent.</p>
     *
     * @param operationId The operation ID to match (can be null for any operation)
     * @return True if the heartbeat was accepted, false if the operation ID didn't match
     */
    public static boolean heartbeat(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (operationId != null && toastManager.mCurrentOperationId != null && !toastManager.mCurrentOperationId.equals(operationId)) {
            return false;
        }
        
        if (toastManager.mIsPersistent.get() && toastManager.mIsShowing.get()) {
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received for operation: " + (operationId != null ? operationId : "unknown"));
            return true;
        }
        
        return false;
    }
    
    // ========================================================================
    // Public API - Temporary Toasts (Static)
    // ========================================================================
    
    /**
     * Shows a temporary toast message with the specified duration.
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     * @param duration The duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }
        
        // Cancel any previous hide runnable
        toastManager.cancelHideRunnable();
        
        toastManager.hideInternal(false);
        
        toastManager.mIsPersistent.set(false);
        toastManager.mCurrentMessage = message;
        toastManager.mCurrentOperationId = null;
        toastManager.mOverlayStartTime.set(SystemClock.elapsedRealtime());
        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
        
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show toast");
            return;
        }
        
        toastManager.createOverlayInView(root, message);
        toastManager.mIsShowing.set(true);
        
        // Store the hide runnable so we can cancel it if needed
        toastManager.mHideRunnable = new Runnable() {
            @Override
            public void run() {
                if (!toastManager.mIsPersistent.get() && toastManager.mIsShowing.get()) {
                    toastManager.hideInternal(true);
                }
                toastManager.mHideRunnable = null;
            }
        };
        toastManager.mMainHandler.postDelayed(toastManager.mHideRunnable, duration);
        
        Log.d(TAG, "Temporary toast shown: " + message + " (duration: " + duration + "ms)");
    }
    
    /**
     * Shows a temporary toast message with LONG duration (2000ms).
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }
    
    /**
     * Shows a temporary toast within a specific view container (e.g., a dialog).
     *
     * @param rootView The root view to attach the toast to
     * @param message The message to display
     * @param duration The duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();
        
        // Cancel any previous hide runnable
        toastManager.cancelHideRunnable();
        
        toastManager.hideInternal(false);
        
        toastManager.mIsPersistent.set(false);
        toastManager.mCurrentMessage = message;
        toastManager.mCurrentOperationId = null;
        toastManager.mOverlayStartTime.set(SystemClock.elapsedRealtime());
        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
        
        toastManager.createOverlayInView(rootView, message);
        toastManager.mIsShowing.set(true);
        
        toastManager.mHideRunnable = new Runnable() {
            @Override
            public void run() {
                if (!toastManager.mIsPersistent.get() && toastManager.mIsShowing.get()) {
                    toastManager.hideInternal(true);
                }
                toastManager.mHideRunnable = null;
            }
        };
        toastManager.mMainHandler.postDelayed(toastManager.mHideRunnable, duration);
        
        Log.d(TAG, "Temporary toast shown in view: " + message);
    }
    
    /**
     * Cancels the current hide runnable.
     */
    private void cancelHideRunnable() {
        if (mHideRunnable != null) {
            mMainHandler.removeCallbacks(mHideRunnable);
            mHideRunnable = null;
        }
    }
    
    // ========================================================================
    // Public API - Persistent Overlay (Static)
    // ========================================================================
    
    /**
     * Shows a persistent overlay message that stays until explicitly hidden.
     * 
     * <p><b>IMPORTANT:</b> Long-running operations MUST call heartbeat()
     * every 5 seconds to prevent the toast from being considered stuck.</p>
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }
    
    /**
     * Shows a persistent overlay message with an operation ID for matching.
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     * @param operationId Unique identifier for this operation (can be null)
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message, @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }
        
        // Cancel any hide runnable (persistent toasts don't auto-hide)
        toastManager.cancelHideRunnable();
        
        toastManager.hideInternal(false);
        
        toastManager.mIsPersistent.set(true);
        toastManager.mCurrentMessage = message;
        toastManager.mCurrentOperationId = operationId;
        long startTime = SystemClock.elapsedRealtime();
        toastManager.mOverlayStartTime.set(startTime);
        toastManager.mLastActivityTime.set(startTime);
        
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show persistent overlay");
            return;
        }
        
        toastManager.createOverlayInView(root, message);
        toastManager.mIsShowing.set(true);
        toastManager.mCurrentActivityRef = new WeakReference<>(activity);
        
        Log.d(TAG, "Persistent overlay shown: " + message + (operationId != null ? " (ID: " + operationId + ")" : ""));
    }
    
    /**
     * Updates the text of the persistent overlay without recreating the view.
     * 
     * <p>This also resets the inactivity timer, keeping the toast alive.</p>
     *
     * @param message The new message to display
     */
    public static void updatePersistentOverlay(@NonNull String message) {
        ToastManager toastManager = getInstance();
        if (!toastManager.mIsShowing.get() || !toastManager.mIsPersistent.get()) {
            Log.w(TAG, "Cannot update persistent overlay - no persistent overlay is showing");
            return;
        }
        
        toastManager.mCurrentMessage = message;
        
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                TextView textView = toastManager.getTextView();
                if (textView != null) {
                    textView.setText(message);
                    toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
                    Log.v(TAG, "Persistent overlay updated: " + message);
                }
            }
        });
    }
    
    /**
     * Hides the persistent overlay if the operation ID matches.
     *
     * @param operationId The operation ID that should match the current overlay
     * @return True if the overlay was hidden, false if ID mismatch or no overlay
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (!toastManager.mIsShowing.get()) {
            return false;
        }
        
        if (operationId != null && toastManager.mCurrentOperationId != null && !toastManager.mCurrentOperationId.equals(operationId)) {
            Log.d(TAG, "Hide rejected - operation ID mismatch: expected " + toastManager.mCurrentOperationId + ", got " + operationId);
            return false;
        }
        
        toastManager.hideInternal(true);
        Log.d(TAG, "Persistent overlay hidden" + (operationId != null ? " (ID: " + operationId + ")" : ""));
        return true;
    }
    
    /**
     * Hides the persistent overlay regardless of operation ID.
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        if (toastManager.mIsShowing.get() && toastManager.mIsPersistent.get()) {
            Log.w(TAG, "Force hiding persistent overlay");
            toastManager.hideInternal(true);
        }
    }
    
    /**
     * Checks if a persistent overlay is currently showing.
     *
     * @return True if a persistent overlay is visible
     */
    public static boolean hasPersistentToast() {
        ToastManager toastManager = getInstance();
        return toastManager.mIsShowing.get() && toastManager.mIsPersistent.get();
    }
    
    /**
     * Gets the current persistent toast text.
     *
     * @return The current message text, or null if no persistent overlay exists
     */
    @Nullable
    public static String getPersistentToastText() {
        ToastManager toastManager = getInstance();
        return toastManager.mCurrentMessage;
    }
    
    /**
     * Gets the current operation ID for the persistent overlay.
     *
     * @return The operation ID, or null if none
     */
    @Nullable
    public static String getCurrentOperationId() {
        ToastManager toastManager = getInstance();
        return toastManager.mCurrentOperationId;
    }
    
    /**
     * Reattaches the persistent toast to a new activity.
     * Call this in onRestart() or onResume() of activities when a persistent
     * toast should persist across activity transitions.
     *
     * @param activity The activity to attach the toast to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        if (!toastManager.mIsShowing.get() || !toastManager.mIsPersistent.get()) {
            return;
        }
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    Log.w(TAG, "Cannot reattach to finishing/destroyed activity");
                    return;
                }
                
                ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
                if (root == null) {
                    Log.w(TAG, "Content view not found for reattachment");
                    return;
                }
                
                toastManager.reattachToActivity(activity);
            }
        });
    }
    
    /**
     * Ensures the persistent overlay is attached to the current window.
     * Call this in onRestart() to reattach if needed after configuration changes.
     *
     * @param activity The current activity
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        if (toastManager.mOverlayRef == null || toastManager.mOverlayRef.get() == null) {
            return;
        }
        
        FrameLayout overlay = toastManager.mOverlayRef.get();
        if (overlay != null && overlay.getParent() == null) {
            reattachToCurrentActivity(activity);
        }
    }
    
    // ========================================================================
    // Stuck Toast Listeners (Static)
    // ========================================================================
    
    /**
     * Adds a listener for stuck toast detection events.
     *
     * @param listener The listener to add
     */
    public static void addStuckToastListener(@NonNull StuckToastListener listener) {
        sStuckToastListeners.add(listener);
    }
    
    /**
     * Removes a stuck toast listener.
     *
     * @param listener The listener to remove
     */
    public static void removeStuckToastListener(@NonNull StuckToastListener listener) {
        sStuckToastListeners.remove(listener);
    }
    
    /**
     * Notifies all registered listeners that a stuck toast was detected.
     */
    private static void notifyStuckToastDetected(@NonNull String reason, long ageMs, long inactiveTimeMs) {
        for (StuckToastListener listener : sStuckToastListeners) {
            try {
                listener.onStuckToastDetected(reason, ageMs, inactiveTimeMs);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying stuck toast listener", e);
            }
        }
    }
    
    // ========================================================================
    // View Management (Internal)
    // ========================================================================
    
    /**
     * Creates the overlay view and attaches it to the specified root view.
     *
     * @param rootView The parent view to attach the overlay to
     * @param message The message to display
     */
    private void createOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP);
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);
        
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        
        textView.setTextColor(getThemeColor());
        
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), TOAST_STROKE_COLOR);
        textView.setBackground(background);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        mOverlayRef = new WeakReference<>(container);
        mTextViewRef = new WeakReference<>(textView);
        
        // Store activity reference if rootView is from an Activity
        if (rootView.getContext() instanceof Activity) {
            mCurrentActivityRef = new WeakReference<>((Activity) rootView.getContext());
        }
        
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }
    
    /**
     * Reattaches the existing overlay to a new activity.
     *
     * @param activity The activity to reattach to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        
        FrameLayout overlay = getOverlay();
        if (overlay == null) {
            mIsShowing.set(false);
            return;
        }
        
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {}
        }
        
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            return;
        }
        
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.bottomMargin = dpToPx(activity, TOAST_BOTTOM_MARGIN_DP);
        overlay.setLayoutParams(params);
        overlay.setPadding(0, 0, 0, 0);
        
        root.addView(overlay);
        overlay.bringToFront();
        mCurrentActivityRef = new WeakReference<>(activity);
        
        if (mIsPersistent.get()) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
        }
        
        Log.d(TAG, "Overlay reattached to new activity");
    }
    
    /**
     * Hides the current overlay.
     *
     * @param animate Whether to animate the fade-out
     */
    private void hideInternal(boolean animate) {
        final FrameLayout overlay = getOverlay();
        if (overlay == null) {
            mIsShowing.set(false);
            mOverlayRef = null;
            mTextViewRef = null;
            mCurrentActivityRef = null;
            return;
        }
        
        if (animate) {
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(FADE_DURATION_MS);
            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {}
                
                @Override
                public void onAnimationEnd(Animation animation) {
                    removeOverlayView(overlay);
                }
                
                @Override
                public void onAnimationRepeat(Animation animation) {}
            });
            overlay.startAnimation(fadeOut);
        } else {
            removeOverlayView(overlay);
        }
        
        mIsShowing.set(false);
        mIsPersistent.set(false);
        mCurrentOperationId = null;
        mCurrentMessage = null;
        mCurrentActivityRef = null;
        
        Log.d(TAG, "Overlay hidden" + (animate ? " with animation" : " immediately"));
    }
    
    /**
     * Forces immediate hide without animation.
     */
    private void forceHideInternal() {
        FrameLayout overlay = getOverlay();
        if (overlay != null) {
            removeOverlayView(overlay);
        }
        
        mIsShowing.set(false);
        mIsPersistent.set(false);
        mCurrentOperationId = null;
        mCurrentMessage = null;
        mOverlayRef = null;
        mTextViewRef = null;
        mCurrentActivityRef = null;
        
        Log.d(TAG, "Overlay force-hidden");
    }
    
    /**
     * Removes the overlay view from its parent.
     *
     * @param overlay The overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {}
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Gets the current overlay container view from the WeakReference.
     *
     * @return The overlay FrameLayout, or null if the reference has been cleared
     */
    @Nullable
    private FrameLayout getOverlay() {
        return mOverlayRef != null ? mOverlayRef.get() : null;
    }
    
    /**
     * Gets the current text view from the WeakReference.
     *
     * @return The TextView, or null if the reference has been cleared
     */
    @Nullable
    private TextView getTextView() {
        return mTextViewRef != null ? mTextViewRef.get() : null;
    }
    
    /**
     * Converts density-independent pixels (dp) to absolute pixels (px).
     *
     * @param context The context for accessing display metrics
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
    
    // ========================================================================
    // Cleanup
    // ========================================================================
    
    /**
     * Shuts down the ToastManager and releases all resources.
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");
        
        toastManager.cancelHideRunnable();
        
        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }
        
        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {}
        }
        
        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {}
        }
        
        toastManager.forceHideInternal();
        sInstance = null;
        sApplication = null;
        
        Log.d(TAG, "ToastManager shut down complete");
    }
}