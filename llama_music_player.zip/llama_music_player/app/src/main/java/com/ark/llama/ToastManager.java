package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Owns every in-activity toast and persistent overlay the app shows,
 * and drives their lifecycle through a state machine.
 *
 * <p>Each activity maintains its own overlay view instances, tracked in
 * {@link #mOverlayMap}. An activity's overlays are removed only when the
 * activity is destroyed, so a stopped activity keeps its overlays
 * attached until the activity actually goes away. A periodic health
 * check treats a persistent overlay whose owner has stopped
 * heartbeating, or an overlay whose view has been detached from its
 * parent, as stuck and runs a recovery pass.</p>
 *
 * <p>Every persistent overlay is mirrored to the status bar through
 * {@link NotificationController}. The mirror uses the same operation ID
 * as the overlay, so a hide or update that arrives after another
 * operation has taken over the overlay is refused. Temporary toasts
 * are not mirrored. Recovery from a stuck overlay tears the mirror
 * down unconditionally.</p>
 *
 * <h3>Two overlay kinds, two lifecycles</h3>
 * <p>The manager holds two kinds of overlay that never share a
 * lifecycle.</p>
 * <ul>
 *   <li><b>Persistent overlays</b> are owned by an operation. They are
 *       shown with an operation ID, kept alive by the owner's heartbeat,
 *       and hidden by the owner through
 *       {@link #hidePersistentOverlay(String)}. Their lifetime ends when
 *       the owner says so.</li>
 *   <li><b>Temporary toasts</b> are owned by the manager. They are shown
 *       for a fixed duration, auto-dismiss, and are never reattached.
 *       Their lifetime ends when the timer elapses.</li>
 * </ul>
 *
 * <p>A temporary toast can be shown while a persistent overlay is
 * active. The temporary toast is drawn on top of the persistent overlay
 * (added later to the same content view, so drawn last), stays for its
 * duration, and disappears without touching the persistent. Showing a
 * temporary toast does not transition the state machine away from
 * {@link State#SHOWING_PERSISTENT}; only the state of "no persistent
 * overlay" is a precondition for the temporary-toast state.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns the current state of the state machine, the
 * per-activity overlay map, the current persistent message and
 * operation ID, the pending temporary-toast dismissals, and the weak
 * reference to the currently resumed activity. The notification mirror
 * is owned by {@link NotificationController}, which uses the operation
 * ID as an ownership token.</p>
 *
 * <h3>Ordering</h3>
 * <p>A temporary toast is shown by adding it to {@link #mOverlayMap}
 * under a temporary-toast key that cannot collide with any persistent
 * overlay key. Showing a temporary toast never removes the persistent
 * overlay's holder.</p>
 *
 * <p>When a temporary toast is shown and no persistent overlay is
 * active, the state machine transitions to
 * {@link State#SHOWING_TEMPORARY}. When a temporary toast is shown and
 * a persistent overlay is active, the state machine stays in
 * {@link State#SHOWING_PERSISTENT}. The state that the temporary toast
 * belongs to is a function of what else is showing, not of the
 * temporary toast itself.</p>
 *
 * <p>The "no valid overlay" branch of the health check is only
 * considered a fault once the map has been empty for longer than
 * {@link #STUCK_TIMEOUT_MS}. This tolerates the transient windows in
 * which the map legitimately has no valid holder.</p>
 *
 * <p>{@link #mCurrentActivityRef} answers one question: which activity
 * is currently resumed. It is a lifecycle property, not a visibility
 * property. It is set in {@link #onActivityResumed(Activity)} and
 * cleared in {@link #onActivityStopped(Activity)} and
 * {@link #onActivityDestroyed(Activity)}, and nowhere else. Hide paths
 * leave it untouched so a follow-up overlay show posted in the same
 * main-thread turn can still find the current activity.</p>
 *
 * <h3>Operation Ownership</h3>
 * <p>{@link #updatePersistentOverlay(String, String)} and
 * {@link #hidePersistentOverlay(String)} both take an operation ID and
 * refuse the call when the current overlay has a different owner. This
 * prevents a stale progress callback from a dead operation from
 * refreshing an overlay that a newer operation has taken over, or from
 * hiding an overlay it does not own.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The manager is a process-wide singleton initialised through
 * {@link #init(Context)}. It registers itself as an
 * {@link Application.ActivityLifecycleCallbacks} listener and a
 * receiver for theme color change broadcasts. The health check starts
 * with the instance and runs until {@link #shutdown()}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. State transitions and
 * view mutation run on {@link #mMainHandler}. The current state, the
 * activity flag, and the shutdown flag are atomic. The overlay map is a
 * {@link ConcurrentHashMap} and the listener lists are
 * {@link CopyOnWriteArrayList}s.</p>
 *
 * @see NotificationController
 * @see State
 * @see Event
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "ToastManager";

    /** Duration of a short toast, in milliseconds. */
    public static final int LENGTH_SHORT = 500;

    /** Duration of a normal toast, in milliseconds. */
    public static final int LENGTH_NORMAL = 1000;

    /** Duration of a long toast, in milliseconds. */
    public static final int LENGTH_LONG = 2000;

    /** Duration of the fade-in and fade-out animation, in milliseconds. */
    private static final int FADE_DURATION_MS = 150;

    /** Maximum width of a toast, in density-independent pixels. */
    private static final int MAX_TOAST_WIDTH_DP = 320;

    /** Horizontal padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;

    /** Distance from the bottom edge of the window, in density-independent pixels. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;

    /** Corner radius of the toast background, in density-independent pixels. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;

    /** Stroke width of the toast border, in density-independent pixels. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;

    /** Elevation of the toast on API 21 and later, in density-independent pixels. */
    private static final int TOAST_ELEVATION_DP = 6;

    /** Background color of the toast. */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;

    /** Stroke color of the toast border. */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500;

    /** Inactivity timeout for persistent overlays, in milliseconds. */
    private static final long STUCK_TIMEOUT_MS = 1000;

    /** Delay before running recovery, in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500;

    /**
     * Prefix for the per-activity key of a temporary toast. Every
     * temporary toast for a given activity uses the same key, so a new
     * temporary toast replaces the previous one for that activity. The
     * prefix guarantees that a temporary key never collides with a
     * persistent overlay key, which is the activity key on its own.
     */
    private static final String KEY_TEMP_TOAST_PREFIX = "TEMP_TOAST_";

    /** Activity key used for root-view-only toasts shown outside an activity. */
    private static final String KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY";

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * States of the toast state machine.
     */
    public enum State {

        /** No overlay is showing. */
        HIDDEN,

        /**
         * At least one temporary toast is showing and no persistent
         * overlay is active.
         */
        SHOWING_TEMPORARY,

        /**
         * A persistent overlay is showing. Temporary toasts may also be
         * showing on top of it; their presence does not change this
         * state.
         */
        SHOWING_PERSISTENT,

        /** An overlay is being hidden and the fade-out animation is running. */
        HIDING,

        /** A persistent overlay is being reattached to a new activity. */
        REATTACHING,

        /** A stuck overlay has been detected and recovery is running. */
        STUCK
    }

    /**
     * Events that drive the state machine.
     */
    public enum Event {

        /** Show a temporary toast. */
        SHOW_TEMPORARY,

        /** Show a persistent overlay. */
        SHOW_PERSISTENT,

        /** Update the text of the current persistent overlay. */
        UPDATE,

        /** Record a heartbeat, resetting the stuck timer. */
        HEARTBEAT,

        /** Hide the current persistent overlay, respecting ownership. */
        HIDE,

        /** Hide every overlay, ignoring ownership. */
        FORCE_HIDE,

        /** Reattach the current persistent overlay to a new activity. */
        REATTACH,

        /** Mark the current overlay as stuck. */
        STUCK_DETECTED,

        /** Complete recovery from a stuck state. */
        RECOVERED
    }

    /**
     * Returns whether the given state represents an active persistent
     * overlay.
     *
     * <p>{@link State#SHOWING_PERSISTENT} is the resting state.
     * {@link State#REATTACHING} is the transient state during which a
     * fresh view is being installed in a new activity's window. Both
     * are treated as active by every public API.</p>
     *
     * @param state State to test, or null
     * @return True when the state represents an active persistent overlay
     */
    private static boolean isPersistentActive(@Nullable State state) {
        return state == State.SHOWING_PERSISTENT || state == State.REATTACHING;
    }

    // ========================================================================
    // Listener Interfaces
    // ========================================================================

    /**
     * Receives toast state changes and stuck detection events.
     */
    public interface ToastStateListener {

        /**
         * Called when the toast state changes.
         *
         * @param oldState State before the transition
         * @param newState State after the transition
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);

        /**
         * Called when a stuck overlay is detected and recovery is about
         * to run.
         *
         * @param reason Reason the overlay was considered stuck
         * @param ageMs Duration the overlay had been showing, in
         *        milliseconds
         * @param inactiveTimeMs Time since the last heartbeat or update,
         *        in milliseconds
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs,
                                  long inactiveTimeMs);
    }

    // ========================================================================
    // Per-Activity Overlay Tracking
    // ========================================================================

    /**
     * Holds the overlay views for a single overlay instance.
     *
     * <p>All references are weak, so the holder does not prevent the
     * activity or its views from being collected.</p>
     */
    private static class OverlayHolder {

        /** Weak reference to the overlay container view. */
        final WeakReference<FrameLayout> overlayRef;

        /** Weak reference to the text view inside the overlay. */
        final WeakReference<TextView> textViewRef;

        /** Weak reference to the activity that owns the overlay. */
        final WeakReference<Activity> activityRef;

        /** Message the overlay was created with. */
        final String message;

        /** Operation ID the overlay was created with, or null. */
        final String operationId;

        /** True when the overlay is persistent; false when it is temporary. */
        final boolean isPersistent;

        /**
         * Constructs a holder for the given overlay.
         *
         * @param overlay Overlay container
         * @param textView Text view inside the overlay
         * @param activity Activity that owns the overlay
         * @param message Message the overlay was created with
         * @param operationId Operation ID the overlay was created with,
         *        or null
         * @param isPersistent True for a persistent overlay, false for a
         *        temporary toast
         */
        OverlayHolder(FrameLayout overlay, TextView textView, Activity activity,
                      String message, String operationId, boolean isPersistent) {
            this.overlayRef = new WeakReference<>(overlay);
            this.textViewRef = new WeakReference<>(textView);
            this.activityRef = new WeakReference<>(activity);
            this.message = message;
            this.operationId = operationId;
            this.isPersistent = isPersistent;
        }

        /**
         * Returns whether both the overlay and its text view are still
         * reachable.
         *
         * @return True when the overlay and text view can be used
         */
        boolean isValid() {
            return overlayRef.get() != null && textViewRef.get() != null;
        }

        /**
         * Detaches the overlay view from its parent when it is still
         * attached.
         */
        void cleanup() {
            FrameLayout overlay = overlayRef.get();
            if (overlay != null && overlay.getParent() != null) {
                try {
                    ((ViewGroup) overlay.getParent()).removeView(overlay);
                } catch (Exception ignored) {
                    // The view was already detached.
                }
            }
        }
    }

    /**
     * Map of overlay key to overlay holder.
     *
     * <p>Persistent overlays are keyed by the activity key alone.
     * Temporary toasts are keyed by {@link #KEY_TEMP_TOAST_PREFIX}
     * concatenated with the activity key. The two namespaces do not
     * overlap, so a temporary toast and a persistent overlay for the
     * same activity occupy distinct slots.</p>
     */
    private final ConcurrentHashMap<String, OverlayHolder> mOverlayMap =
        new ConcurrentHashMap<>();

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;

    /** Application instance used for lifecycle callbacks and broadcasts. */
    @Nullable
    private static Application sApplication;

    /** Main-thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for the periodic health check. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // State Machine Variables
    // ========================================================================

    /** Current state of the state machine. */
    private final AtomicReference<State> mCurrentState =
        new AtomicReference<>(State.HIDDEN);

    /** Timestamp at which the current state began. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);

    /** Timestamp of the last heartbeat or update. */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);

    /**
     * Timestamp of the last health check that found a valid overlay.
     *
     * <p>The "no valid overlay" branch of the health check is only
     * considered a fault once this timestamp is older than
     * {@link #STUCK_TIMEOUT_MS}, so a transient window with no holder
     * does not trip recovery.</p>
     */
    private final AtomicLong mLastValidOverlayTime = new AtomicLong(0);

    /** True while recovery is running. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);

    /** Runnable for the periodic health check, or null when stopped. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Runnable for the current recovery, or null when none is pending. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock that serialises health checks. */
    private final Object mHealthLock = new Object();

    // ========================================================================
    // Auto-Dismiss Management
    // ========================================================================

    /**
     * Pending auto-dismiss runnables, keyed by the temporary-toast key
     * they belong to. A new temporary toast for the same key cancels the
     * pending dismissal for that key and schedules a fresh one. A
     * temporary toast in a different activity has its own key and its
     * own pending dismissal, and is not affected.
     */
    private final ConcurrentHashMap<String, Runnable> mPendingAutoDismiss =
        new ConcurrentHashMap<>();

    // ========================================================================
    // Persistent Overlay State
    // ========================================================================

    /**
     * Message currently held by the persistent overlay, or null when no
     * persistent overlay is showing. Never touched by a temporary toast.
     */
    @Nullable
    private String mCurrentPersistentMessage = null;

    /**
     * Operation ID of the current persistent overlay, or null when none
     * is showing. Never touched by a temporary toast.
     */
    @Nullable
    private String mCurrentOperationId = null;

    /**
     * Weak reference to the currently resumed activity.
     *
     * <p>Lifecycle property, not overlay-visibility property. Written
     * only by {@link #onActivityResumed(Activity)}; cleared only by
     * {@link #onActivityStopped(Activity)} and
     * {@link #onActivityDestroyed(Activity)} when the stopped or
     * destroyed activity is the one being tracked. Never touched by any
     * hide path.</p>
     */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;

    /** True once the lifecycle callbacks have been registered. */
    private boolean mCallbacksRegistered = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Receiver for theme color change broadcasts, or null. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;

    // ========================================================================
    // Listeners
    // ========================================================================

    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners =
        new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor and Initialization
    // ========================================================================

    /**
     * Constructs the singleton, registers lifecycle callbacks and the
     * theme receiver, and starts the health check.
     *
     * @param context A context; the application context is retained
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        mCurrentState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());
        Log.d(TAG, "ToastManager initialized (two-namespace overlay management)");
    }

    /**
     * Initializes the singleton.
     *
     * <p>Calling this method more than once with the same process has no
     * effect.</p>
     *
     * @param context A context; the application context is retained
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance
     * @throws IllegalStateException When {@link #init(Context)} has not
     *         yet been called
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ========================================================================
    // State Machine Methods
    // ========================================================================

    /**
     * Transitions to the given state and notifies every registered
     * listener.
     *
     * <p>A transition to the current state does nothing.</p>
     *
     * @param newState State to transition to
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);
        if (oldState == newState) {
            return;
        }
        Log.d(TAG, "State transition: " + oldState + " \u2192 " + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener", exception);
            }
        }
    }

    /**
     * Recomputes the state machine's state from the current contents of
     * the overlay map.
     *
     * <p>Called after an overlay is removed, so the state machine tracks
     * what is actually showing rather than what was asked to show. The
     * rule is a direct function of the map:</p>
     * <ul>
     *   <li>A persistent overlay is present → {@link State#SHOWING_PERSISTENT}.</li>
     *   <li>No persistent overlay, at least one temporary toast → {@link State#SHOWING_TEMPORARY}.</li>
     *   <li>No overlays at all → {@link State#HIDDEN}. The persistent
     *       message and operation ID are cleared.</li>
     * </ul>
     *
     * <p>The {@link State#REATTACHING} state is left alone. It is a
     * transient state during which the map is being rebuilt for a new
     * activity; recomputation would race the reattach.</p>
     */
    private void recomputeStateFromMap() {
        State currentState = mCurrentState.get();
        if (currentState == State.REATTACHING) {
            return;
        }

        boolean hasPersistent = false;
        boolean hasTemporary = false;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                hasPersistent = true;
            } else {
                hasTemporary = true;
            }
        }

        if (hasPersistent) {
            transitionTo(State.SHOWING_PERSISTENT);
        } else if (hasTemporary) {
            transitionTo(State.SHOWING_TEMPORARY);
        } else {
            transitionTo(State.HIDDEN);
            mCurrentPersistentMessage = null;
            mCurrentOperationId = null;
        }
    }

    /**
     * Dispatches the given event through the state machine.
     *
     * @param event Event to dispatch
     * @return True when the event changed the state
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mCurrentState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);

        switch (event) {
            case SHOW_TEMPORARY:  return handleShowTemporary(currentState);
            case SHOW_PERSISTENT: return handleShowPersistent(currentState);
            case UPDATE:          return handleUpdate(currentState);
            case HEARTBEAT:       return handleHeartbeat(currentState);
            case HIDE:            return handleHide(currentState);
            case FORCE_HIDE:      return handleForceHide(currentState);
            case REATTACH:        return handleReattach(currentState);
            case STUCK_DETECTED:  return handleStuckDetected(currentState);
            case RECOVERED:       return handleRecovered(currentState);
            default:              return false;
        }
    }

    /**
     * Handles a {@link Event#SHOW_TEMPORARY} event.
     *
     * <p>Only fired when no persistent overlay is active. When the
     * current state is {@link State#SHOWING_PERSISTENT} or
     * {@link State#REATTACHING}, the caller bypasses this event and
     * leaves the state machine alone.</p>
     *
     * @param currentState State before the event
     * @return True when the event was accepted
     */
    private boolean handleShowTemporary(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING
                || currentState == State.SHOWING_TEMPORARY) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        Log.w(TAG, "SHOW_TEMPORARY in state " + currentState + " — refusing");
        return false;
    }

    /**
     * Handles a {@link Event#SHOW_PERSISTENT} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleShowPersistent(State currentState) {
        transitionTo(State.SHOWING_PERSISTENT);
        return true;
    }

    /**
     * Handles an {@link Event#UPDATE} event.
     *
     * @param currentState State before the event
     * @return True when the update was accepted
     */
    private boolean handleUpdate(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update persistent overlay in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#HEARTBEAT} event.
     *
     * @param currentState State before the event
     * @return True when the heartbeat was accepted
     */
    private boolean handleHeartbeat(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#HIDE} event.
     *
     * @param currentState State before the event
     * @return True when the hide was accepted
     */
    private boolean handleHide(State currentState) {
        if (isPersistentActive(currentState)) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true;
        }
        Log.w(TAG, "Cannot hide persistent overlay in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#FORCE_HIDE} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleForceHide(State currentState) {
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }

    /**
     * Handles a {@link Event#REATTACH} event.
     *
     * @param currentState State before the event
     * @return True when the reattach was accepted
     */
    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        if (currentState == State.REATTACHING) {
            // Already reattaching. A second activity resume during the
            // reattach window is not an error.
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#STUCK_DETECTED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleStuckDetected(State currentState) {
        if (isPersistentActive(currentState)
                || currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Overlay stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#RECOVERED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }

    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================

    /**
     * Registers the lifecycle callbacks with the application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) {
            return;
        }
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    /**
     * Sets the current activity reference and, when a persistent overlay
     * is active, reattaches it to the newly resumed activity.
     *
     * <p>{@link State#REATTACHING} is treated as active, so a resume
     * that lands during an in-flight reattach completes the reattach in
     * the newly visible activity.</p>
     *
     * @param activity Activity that resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        State currentState = mCurrentState.get();
        if (isPersistentActive(currentState)) {
            handleEvent(Event.REATTACH);
            reattachToActivity(activity);
        } else if (currentState == State.SHOWING_TEMPORARY) {
            Log.d(TAG, "Temporary toast showing, not reattaching "
                + "(auto-dismiss will handle it)");
        }
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    /**
     * Clears the current activity reference when the stopped activity is
     * the one being tracked, and runs a health check.
     *
     * <p>The stopped activity's overlay holders are not removed. A
     * stopped activity's view hierarchy is still alive, its overlays are
     * still attached, and the holders' weak references are still valid.
     * Holder cleanup is deferred to
     * {@link #onActivityDestroyed(Activity)}, which is the point at
     * which the view hierarchy actually goes away.</p>
     *
     * @param activity Activity that stopped
     */
    @Override
    public void onActivityStopped(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    /**
     * Clears the current activity reference when the destroyed activity
     * is the one being tracked, removes its overlay holders, and runs a
     * health check.
     *
     * <p>Removes every overlay keyed by the destroyed activity, both the
     * persistent key and the temporary key. Any pending auto-dismiss for
     * the removed temporary toast is cancelled.</p>
     *
     * @param activity Activity that was destroyed
     */
    @Override
    public void onActivityDestroyed(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }

        String activityKey = getActivityKey(activity);
        String tempKey = getTempToastKey(activity);

        OverlayHolder persistentHolder = mOverlayMap.remove(activityKey);
        if (persistentHolder != null) {
            persistentHolder.cleanup();
            Log.v(TAG, "Cleaned up persistent overlay for destroyed activity: "
                + activity.getClass().getSimpleName());
        }

        OverlayHolder tempHolder = mOverlayMap.remove(tempKey);
        if (tempHolder != null) {
            tempHolder.cleanup();
            Log.v(TAG, "Cleaned up temporary toast for destroyed activity: "
                + activity.getClass().getSimpleName());
        }

        Runnable pending = mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            mMainHandler.removeCallbacks(pending);
        }

        recomputeStateFromMap();
        performHealthCheck();
    }

    // ========================================================================
    // Theme Management
    // ========================================================================

    /**
     * Registers a receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (sApplication == null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        ContextCompat.registerReceiver(
            sApplication, mThemeReceiver,
            new IntentFilter(ACTION_THEME_COLOR_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Reapplies the current theme color to every visible overlay's text
     * view.
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        final int themeColor = toastManager.getThemeColor();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                State currentState = toastManager.mCurrentState.get();
                if (currentState != State.SHOWING_TEMPORARY
                        && !isPersistentActive(currentState)) {
                    return;
                }
                for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                    TextView textView = holder.textViewRef.get();
                    if (textView != null) {
                        textView.setTextColor(themeColor);
                    }
                }
            }
        });
    }

    /**
     * Returns the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) {
                return DEFAULT_THEME_COLOR;
            }
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null
                ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    // ========================================================================
    // Health Check
    // ========================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new HealthCheckRunnable(this);
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: "
            + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Health-check runnable that holds the manager through a weak
     * reference.
     */
    private static class HealthCheckRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run health checks against
         */
        HealthCheckRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Health check runnable: ToastManager was "
                    + "garbage collected, stopping");
                return;
            }
            manager.performHealthCheck();
            if (manager.mHealthCheckRunnable != null) {
                manager.mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
            }
        }
    }

    /**
     * Runs the health check.
     *
     * <p>Treats a persistent overlay with no valid holder as stuck only
     * once the map has been empty of persistent holders for longer than
     * {@link #STUCK_TIMEOUT_MS}. Treats a persistent overlay with no
     * heartbeat within {@link #STUCK_TIMEOUT_MS} as stuck. The temporary
     * toasts are self-dismissing and are not checked for age; if their
     * auto-dismiss fails, they will be removed by the next recovery pass
     * or by {@link #shutdown()}.</p>
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mCurrentState.get();
            if (currentState != State.SHOWING_TEMPORARY
                    && !isPersistentActive(currentState)) {
                return;
            }

            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();
            long inactiveTime = now - mLastActivityTime.get();

            boolean hasValidPersistent = false;
            for (OverlayHolder holder : mOverlayMap.values()) {
                if (holder.isPersistent && holder.isValid()) {
                    hasValidPersistent = true;
                    mLastValidOverlayTime.set(now);
                    break;
                }
            }

            boolean isStuck = false;
            String stuckReason = null;

            if (isPersistentActive(currentState) && !hasValidPersistent) {
                long noOverlayDuration = now - mLastValidOverlayTime.get();
                if (noOverlayDuration > STUCK_TIMEOUT_MS) {
                    isStuck = true;
                    stuckReason = "Persistent overlay missing for " + noOverlayDuration
                        + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
                }
            } else if (isPersistentActive(currentState)
                    && inactiveTime > STUCK_TIMEOUT_MS) {
                isStuck = true;
                stuckReason = "No heartbeat for " + inactiveTime
                    + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
            }

            if (isStuck) {
                Log.w(TAG, "STUCK OVERLAY DETECTED: " + stuckReason);

                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason, age, inactiveTime);
                    } catch (Exception exception) {
                        Log.e(TAG, "Error notifying stuck listener", exception);
                    }
                }

                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }

    /**
     * Starts the recovery pass from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        Log.d(TAG, "Starting overlay recovery");
        cancelRecovery();

        mRecoveryRunnable = new RecoveryRunnable(this);
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Recovery runnable that holds the manager through a weak reference.
     */
    private static class RecoveryRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run recovery against
         */
        RecoveryRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Recovery runnable: ToastManager was garbage collected");
                return;
            }
            Log.d(TAG, "Overlay recovery completed");
            manager.forceHideAll();
            manager.handleEvent(Event.RECOVERED);
            manager.mIsRecovering.set(false);
            manager.mRecoveryRunnable = null;
        }
    }

    /**
     * Cancels the pending recovery. Idempotent.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================

    /**
     * Returns the activity that is currently resumed.
     *
     * @return The current activity, or null when none is tracked
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }

    // ========================================================================
    // Public API - Heartbeat
    // ========================================================================

    /**
     * Records a heartbeat for the current persistent overlay.
     *
     * <p>A heartbeat resets the stuck timer. When the given operation ID
     * is non-null and the current overlay has a different operation ID,
     * the heartbeat is refused so a component that does not own the
     * overlay cannot extend its lifetime.</p>
     *
     * @param operationId Operation ID to match, or null to accept any
     * @return True when the heartbeat was accepted
     */
    public static boolean heartbeat(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (operationId != null && toastManager.mCurrentOperationId != null
                && !toastManager.mCurrentOperationId.equals(operationId)) {
            return false;
        }
        return toastManager.handleEvent(Event.HEARTBEAT);
    }

    // ========================================================================
    // Public API - Temporary Toasts
    // ========================================================================

    /**
     * Shows a temporary toast in the given activity for the given
     * duration.
     *
     * <p>The temporary toast coexists with a persistent overlay. When a
     * persistent overlay is showing, the state machine stays in
     * {@link State#SHOWING_PERSISTENT} and the persistent overlay's
     * message and operation ID are not touched. When no persistent
     * overlay is showing, the state machine transitions to
     * {@link State#SHOWING_TEMPORARY}.</p>
     *
     * <p>A new temporary toast for the same activity replaces the
     * previous one for that activity, and cancels the previous one's
     * pending auto-dismiss. A temporary toast in a different activity
     * is independent.</p>
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message,
                                 int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }

        String tempKey = getTempToastKey(activity);

        // Remove any previous temporary toast for this activity.
        OverlayHolder existingTemp = toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        // Cancel the pending auto-dismiss for this key, if any.
        Runnable pending = toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        // Only transition the state machine when no persistent overlay
        // is active. When a persistent overlay is showing, its state is
        // preserved and the temporary toast is drawn on top.
        State currentState = toastManager.mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show toast");
            return;
        }

        toastManager.createOverlayInView(activity, root, message, false, tempKey);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
        Log.d(TAG, "Temporary toast shown: " + message
            + " (duration: " + duration + "ms, key=" + tempKey + ")");
    }

    /**
     * Auto-dismiss runnable that holds the manager through a weak
     * reference and removes only the temporary overlay it was created
     * for.
     */
    private static class AutoDismissRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /** The overlay key this dismissal is responsible for. */
        private final String key;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager that owns the toast
         * @param key Overlay key this dismissal is responsible for
         */
        AutoDismissRunnable(ToastManager manager, String key) {
            this.managerRef = new WeakReference<>(manager);
            this.key = key;
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Auto-dismiss runnable: ToastManager was garbage collected");
                return;
            }

            OverlayHolder holder = manager.mOverlayMap.remove(key);
            if (holder == null) {
                // The holder was already removed by another path (activity
                // destroyed, force hide). Nothing to do.
                manager.mPendingAutoDismiss.remove(key);
                return;
            }

            holder.cleanup();
            manager.recomputeStateFromMap();
            manager.mPendingAutoDismiss.remove(key);

            Log.d(TAG, "Auto-dismissed temporary toast (key=" + key + ")");
        }
    }

    /**
     * Shows a temporary toast in the given activity for the long
     * duration.
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }

    /**
     * Shows a temporary toast inside the given view hierarchy.
     *
     * <p>Used when a toast needs to appear inside a dialog or another
     * surface that does not have an activity window of its own. The
     * temporary toast coexists with a persistent overlay the same way
     * {@link #showToast(Activity, String, int)} does.</p>
     *
     * @param rootView View group to attach the toast to
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView,
                                       @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();

        // Root-view-only toasts use a dedicated key. Activity is null,
        // which is what getTempToastKey expects.
        String tempKey = getTempToastKey(null);

        OverlayHolder existingTemp = toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        Runnable pending = toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        State currentState = toastManager.mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        toastManager.createOverlayInView(null, rootView, message, false, tempKey);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
        Log.d(TAG, "Temporary toast shown in view: " + message
            + " (duration: " + duration + "ms, key=" + tempKey + ")");
    }

    // ========================================================================
    // Public API - Persistent Overlay
    // ========================================================================

    /**
     * Shows a persistent overlay in the given activity with no operation
     * ID.
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }

    /**
     * Shows a persistent overlay in the given activity with the given
     * operation ID.
     *
     * <p>The overlay remains visible until a caller hides it by
     * matching ID or the health check recovers it. Every persistent
     * overlay is mirrored to the status bar through
     * {@link NotificationController}, and the operation ID is passed
     * through to the controller as an ownership token.</p>
     *
     * <p>Showing a persistent overlay removes any existing temporary
     * toasts and any existing persistent overlay, and replaces them with
     * the new persistent overlay. A temporary toast that is showing when
     * a persistent overlay is requested is dismissed; the persistent
     * overlay is the higher-priority surface.</p>
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message,
                                             @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }

        // Remove every overlay: any existing persistent and any
        // temporary toasts for this and other activities. The persistent
        // overlay is the higher-priority surface and takes the window
        // alone.
        toastManager.removeAllOverlays();

        toastManager.handleEvent(Event.SHOW_PERSISTENT);

        toastManager.mCurrentPersistentMessage = message;
        toastManager.mCurrentOperationId = operationId;
        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show persistent overlay");
            return;
        }

        String key = getActivityKey(activity);
        toastManager.createOverlayInView(activity, root, message, true, key);
        toastManager.mCurrentActivityRef = new WeakReference<>(activity);

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .showLibraryStatus(message, operationId);
        }

        Log.d(TAG, "Persistent overlay shown: " + message
            + (operationId != null ? " (ID: " + operationId + ")" : ""));
    }

    /**
     * Updates the text of the current persistent overlay when the given
     * operation ID matches the current owner.
     *
     * @param message New text to display
     * @param operationId Operation ID that must match the current owner
     */
    public static void updatePersistentOverlay(@NonNull String message,
                                               @NonNull String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (!isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot update persistent overlay - no persistent overlay is showing");
            return;
        }

        if (!operationId.equals(toastManager.mCurrentOperationId)) {
            Log.d(TAG, "Update rejected - operation ID mismatch: expected "
                + toastManager.mCurrentOperationId + ", got " + operationId);
            return;
        }

        if (toastManager.handleEvent(Event.UPDATE)) {
            toastManager.mCurrentPersistentMessage = message;
            toastManager.mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                        if (!holder.isPersistent) {
                            continue;
                        }
                        TextView textView = holder.textViewRef.get();
                        if (textView != null) {
                            textView.setText(message);
                        }
                    }
                    Log.v(TAG, "Persistent overlay updated: " + message);
                }
            });

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .updateLibraryStatus(message, operationId);
            }
        }
    }

    /**
     * Hides the current persistent overlay when the operation ID
     * matches.
     *
     * <p>Ownership-respecting hide. Removes only the persistent
     * overlay(s); a temporary toast that was drawn on top of the
     * persistent overlay stays and dismisses on its own timer.</p>
     *
     * @param operationId Operation ID that must match the current
     *        overlay's owner
     * @return True when the overlay was hidden
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (!isPersistentActive(currentState)) {
            return false;
        }

        if (operationId != null && toastManager.mCurrentOperationId != null
                && !toastManager.mCurrentOperationId.equals(operationId)) {
            Log.d(TAG, "Hide rejected - operation ID mismatch: expected "
                + toastManager.mCurrentOperationId + ", got " + operationId);
            return false;
        }

        if (toastManager.handleEvent(Event.HIDE)) {
            final String currentId = toastManager.mCurrentOperationId;
            toastManager.removePersistentOverlays(true);

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }

            Log.d(TAG, "Persistent overlay hidden"
                + (operationId != null ? " (ID: " + operationId + ")" : ""));
            return true;
        }
        return false;
    }

    /**
     * Hides every overlay regardless of operation ID.
     *
     * <p>Force hide. Intended for recovery paths such as a stuck overlay
     * that no live operation still owns, or a full library wipe where
     * the operation that showed the overlay is no longer running.
     * Callers that own their overlay should use
     * {@link #hidePersistentOverlay(String)}.</p>
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            final String currentId = toastManager.mCurrentOperationId;
            toastManager.handleEvent(Event.FORCE_HIDE);
            toastManager.removeAllOverlays();

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        }
    }

    /**
     * Returns whether a persistent overlay is currently active.
     *
     * @return True when a persistent overlay is active
     */
    public static boolean hasPersistentToast() {
        return isPersistentActive(getInstance().mCurrentState.get());
    }

    /**
     * Returns the text of the current persistent overlay.
     *
     * @return The current message, or null when no persistent overlay is
     *         showing
     */
    @Nullable
    public static String getPersistentToastText() {
        return getInstance().mCurrentPersistentMessage;
    }

    /**
     * Returns the operation ID of the current persistent overlay.
     *
     * @return The operation ID, or null when the overlay has no owner or
     *         no persistent overlay is showing
     */
    @Nullable
    public static String getCurrentOperationId() {
        return getInstance().mCurrentOperationId;
    }

    // ========================================================================
    // Reattach Methods
    // ========================================================================

    /**
     * Reattaches the current persistent overlay to the given activity.
     *
     * @param activity Activity to reattach the overlay to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (!isPersistentActive(currentState)) {
            Log.d(TAG, "Not reattaching - state is " + currentState);
            return;
        }

        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    return;
                }

                State currentStateCheck = toastManager.mCurrentState.get();
                if (currentStateCheck == State.HIDDEN
                        || currentStateCheck == State.HIDING) {
                    return;
                }

                toastManager.handleEvent(Event.REATTACH);
                toastManager.reattachToActivity(activity);
            }
        });
    }

    /**
     * Ensures the current persistent overlay is attached to the given
     * activity's window.
     *
     * @param activity Activity the overlay should be attached to
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder holder = toastManager.mOverlayMap.get(key);
        if (holder == null || !holder.isValid()) {
            reattachToCurrentActivity(activity);
        }
    }

    // ========================================================================
    // State Listeners
    // ========================================================================

    /**
     * Adds a toast state listener.
     *
     * <p>The listener receives the current state immediately after
     * registration.</p>
     *
     * @param listener Listener to add
     */
    public static void addStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        State currentState = toastManager.mCurrentState.get();
        listener.onStateChanged(currentState, currentState);
    }

    /**
     * Removes a toast state listener.
     *
     * @param listener Listener to remove
     */
    public static void removeStateListener(@NonNull ToastStateListener listener) {
        getInstance().mStateListeners.remove(listener);
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns a unique key for the given activity.
     *
     * <p>Returns {@link #KEY_ROOT_VIEW_ONLY} when the activity is null,
     * so a root-view-only toast has its own slot in the overlay map.</p>
     *
     * @param activity Activity to build a key for, or null
     * @return The key
     */
    @NonNull
    private static String getActivityKey(@Nullable Activity activity) {
        if (activity == null) {
            return KEY_ROOT_VIEW_ONLY;
        }
        return activity.getClass().getName() + "@" + System.identityHashCode(activity);
    }

    /**
     * Returns the temporary-toast key for the given activity.
     *
     * <p>The temporary key is the activity key with a fixed prefix, so
     * it can never collide with the persistent overlay's key for the
     * same activity.</p>
     *
     * @param activity Activity to build a key for, or null
     * @return The temporary-toast key
     */
    @NonNull
    private static String getTempToastKey(@Nullable Activity activity) {
        return KEY_TEMP_TOAST_PREFIX + getActivityKey(activity);
    }

    // ========================================================================
    // Overlay Removal Methods
    // ========================================================================

    /**
     * Removes every overlay from the map and detaches every view. Used
     * by {@code showPersistentOverlay} before installing a new
     * persistent overlay, by {@code hidePersistentOverlay()} (force
     * hide), and by the recovery pass.
     *
     * <p>Cancels every pending auto-dismiss, clears the persistent
     * message and operation ID, and transitions the state to
     * {@link State#HIDDEN}.</p>
     */
    private void removeAllOverlays() {
        for (OverlayHolder holder : mOverlayMap.values()) {
            holder.cleanup();
        }
        mOverlayMap.clear();

        for (Runnable pending : mPendingAutoDismiss.values()) {
            mMainHandler.removeCallbacks(pending);
        }
        mPendingAutoDismiss.clear();

        transitionTo(State.HIDDEN);
        mCurrentPersistentMessage = null;
        mCurrentOperationId = null;
    }

    /**
     * Removes every persistent overlay from the map.
     *
     * <p>Temporary toasts, if any, are left in place. After the
     * removal, the state is recomputed from what remains.</p>
     *
     * @param animate True to fade the overlays out before removing them
     */
    private void removePersistentOverlays(boolean animate) {
        List<String> keysToRemove = new ArrayList<>();
        for (Map.Entry<String, OverlayHolder> entry : mOverlayMap.entrySet()) {
            if (entry.getValue().isPersistent) {
                keysToRemove.add(entry.getKey());
            }
        }

        for (String key : keysToRemove) {
            OverlayHolder holder = mOverlayMap.remove(key);
            if (holder == null) {
                continue;
            }
            if (animate) {
                FrameLayout overlay = holder.overlayRef.get();
                if (overlay != null) {
                    AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
                    fadeOut.setDuration(FADE_DURATION_MS);
                    fadeOut.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {
                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            removeOverlayView(overlay);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {
                        }
                    });
                    overlay.startAnimation(fadeOut);
                }
            } else {
                holder.cleanup();
            }
        }

        recomputeStateFromMap();
    }

    /**
     * Removes every overlay immediately, without animation, and tears
     * down the mirrored library notification unconditionally.
     *
     * <p>This is the recovery path: the state machine has decided the
     * overlay is dead, and the notification mirror must follow
     * regardless of which operation owned it.</p>
     *
     * <p>The current activity reference is left untouched.</p>
     */
    private void forceHideAll() {
        removeAllOverlays();

        if (sApplication != null) {
            NotificationController.getInstance(sApplication).clearLibraryStatus();
        }
    }

    // ========================================================================
    // View Management
    // ========================================================================

    /**
     * Creates an overlay view and attaches it to the given root view
     * under the given key.
     *
     * <p>Replaces any existing holder for the same key. The overlay is
     * positioned above the bottom edge of the window and fades in.</p>
     *
     * @param activity Activity the overlay belongs to, or null for a
     *        root-view-only toast
     * @param rootView View group to attach the overlay to
     * @param message Text to display
     * @param isPersistent True for a persistent overlay, false for a
     *        temporary toast
     * @param key Overlay map key for the new holder
     */
    private void createOverlayInView(@Nullable Activity activity,
                                     @NonNull ViewGroup rootView,
                                     @NonNull String message,
                                     boolean isPersistent,
                                     @NonNull String key) {
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP);
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);

        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        textView.setTextColor(getThemeColor());

        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(
            dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP),
            TOAST_STROKE_COLOR);
        textView.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }

        container.addView(textView);
        rootView.addView(container);

        mOverlayMap.put(key, new OverlayHolder(
            container, textView, activity, message, mCurrentOperationId, isPersistent));
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());

        if (activity != null) {
            mCurrentActivityRef = new WeakReference<>(activity);
        }

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }

    /**
     * Creates a fresh persistent overlay for the given activity and
     * installs the current message in it.
     *
     * <p>Refused when the state is not a persistent one or when the
     * current message is null.</p>
     *
     * @param activity Activity to attach the overlay to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        State currentState = mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot reattach - only persistent overlays are supported");
            return;
        }

        if (mCurrentPersistentMessage == null) {
            Log.w(TAG, "Cannot reattach - no message available");
            transitionTo(State.HIDDEN);
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found for reattachment");
            return;
        }

        createOverlayInView(activity, root, mCurrentPersistentMessage, true, key);
        mCurrentActivityRef = new WeakReference<>(activity);

        if (isPersistentActive(currentState)) {
            transitionTo(State.SHOWING_PERSISTENT);
        }

        Log.d(TAG, "Overlay reattached to activity: "
            + activity.getClass().getSimpleName());
    }

    /**
     * Removes the given overlay view from its parent.
     *
     * @param overlay Overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {
                // The view was already detached.
            }
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns a human-readable snapshot of the manager's current state.
     *
     * @return A multi-line string describing the state machine, the
     *         persistent message and operation ID, the current activity,
     *         the number of active overlays, and the listener count
     */
    @NonNull
    public String getDebugInfo() {
        Activity currentActivity = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        int persistentCount = 0;
        int tempCount = 0;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                persistentCount++;
            } else {
                tempCount++;
            }
        }
        return "ToastManager\n"
                + "State: " + mCurrentState.get() + "\n"
                + "State duration: "
                + (SystemClock.elapsedRealtime() - mStateStartTime.get()) + "ms\n"
                + "Last activity: "
                + (SystemClock.elapsedRealtime() - mLastActivityTime.get()) + "ms ago\n"
                + "Last valid overlay: "
                + (SystemClock.elapsedRealtime() - mLastValidOverlayTime.get()) + "ms ago\n"
                + "Persistent message: " + mCurrentPersistentMessage + "\n"
                + "Operation ID: " + mCurrentOperationId + "\n"
                + "Current activity: "
                + (currentActivity != null
                    ? currentActivity.getClass().getSimpleName() : "null") + "\n"
                + "Persistent overlays: " + persistentCount + "\n"
                + "Temporary toasts: " + tempCount + "\n"
                + "Pending dismissals: " + mPendingAutoDismiss.size() + "\n"
                + "Listeners: " + mStateListeners.size();
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Releases every resource held by the manager.
     *
     * <p>Stops the health check, cancels recovery and every pending
     * auto-dismiss, unregisters lifecycle callbacks and the theme
     * receiver, hides any active overlay, and clears the singleton
     * reference.</p>
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");

        for (Runnable pending : toastManager.mPendingAutoDismiss.values()) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }
        toastManager.mPendingAutoDismiss.clear();

        toastManager.cancelRecovery();

        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }

        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {
                // The callbacks were already unregistered.
            }
        }

        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
        }

        toastManager.forceHideAll();
        sInstance = null;
        sApplication = null;
        Log.d(TAG, "ToastManager shut down complete");
    }
}