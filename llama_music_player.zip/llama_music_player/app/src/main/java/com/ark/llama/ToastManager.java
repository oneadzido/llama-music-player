package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Centralized Toast Manager with State Machine for reliable toast lifecycle management.
 *
 * <p>This manager provides a custom toast implementation using styled overlays
 * with a state machine to ensure reliable lifecycle management. The state machine
 * prevents race conditions and provides clear visibility into toast state.</p>
 *
 * <h3>Per-Activity Overlay Management</h3>
 * <p>Each activity maintains its own overlay view instance. This prevents the
 * "stuck toast" problem when navigating between activities because each activity's
 * overlay is tracked independently and cleaned up when the activity is destroyed.</p>
 *
 * <h3>Temporary Toast Auto-Dismiss</h3>
 * <p>Temporary toasts are automatically dismissed after their duration expires.
 * They are NOT reattached on activity lifecycle events - once they auto-dismiss,
 * they stay dismissed. This is critical for toasts shown in {@code onActivityResult()}
 * after returning from Storage Access Framework (SAF) folder selection, where
 * lifecycle events could otherwise cause the toast to become stuck.</p>
 *
 * <h3>Single Toast Policy</h3>
 * <p>Only one toast (temporary or persistent) is ever shown at any given time.
 * Showing a new toast automatically hides any existing toast immediately,
 * preventing multiple overlays from stacking on top of each other.</p>
 *
 * <h3>States</h3>
 * <ul>
 *   <li><b>HIDDEN</b> - No toast is showing</li>
 *   <li><b>SHOWING_TEMPORARY</b> - A temporary toast is being shown (auto-dismisses)</li>
 *   <li><b>SHOWING_PERSISTENT</b> - A persistent toast is being shown (requires explicit hide)</li>
 *   <li><b>HIDING</b> - Toast is in the process of hiding (animation in progress)</li>
 *   <li><b>REATTACHING</b> - Toast is being reattached to a new activity</li>
 *   <li><b>STUCK</b> - Toast has been detected as stuck and is being recovered</li>
 * </ul>
 *
 * @author Richard Korbla Adzido
 * @version 1.1.5
 * @since 1.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "ToastManager";

    /** Short duration: 500 milliseconds - for quick notifications. */
    public static final int LENGTH_SHORT = 500;

    /** Normal duration: 1000 milliseconds - standard toast length. */
    public static final int LENGTH_NORMAL = 1000;

    /** Long duration: 2000 milliseconds - for messages that need more reading time. */
    public static final int LENGTH_LONG = 2000;

    /** Duration for fade in/out animations in milliseconds. */
    private static final int FADE_DURATION_MS = 150;

    /** Maximum toast width in density-independent pixels. */
    private static final int MAX_TOAST_WIDTH_DP = 320;

    /** Horizontal padding for toast content in dp. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding for toast content in dp. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;

    /** Bottom margin from screen edge in dp. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;

    /** Corner radius for toast background in dp. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;

    /** Stroke width for toast border in dp. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;

    /** Elevation for toast on Lollipop+ in dp. */
    private static final int TOAST_ELEVATION_DP = 6;

    /** Toast background color (dark gray). */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;

    /** Toast stroke color (slightly lighter gray). */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;

    /** Default theme color fallback (Royal Llama). */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    // ========================================================================
    // Health Check Constants
    // ========================================================================

    /** Health check interval in milliseconds (5 seconds). */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000;

    /** Stuck detection timeout for persistent toasts (5 seconds). */
    private static final long STUCK_TIMEOUT_MS = 5000;

    /** Maximum duration for temporary toasts (3 seconds). */
    private static final long TEMP_TOAST_MAX_MS = 3000;

    /** Recovery delay in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500;

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * States of the toast state machine.
     */
    public enum State {
        /** No toast is showing. */
        HIDDEN,

        /** A temporary toast is being shown (auto-dismisses after duration). */
        SHOWING_TEMPORARY,

        /** A persistent toast is being shown (requires explicit hide). */
        SHOWING_PERSISTENT,

        /** Toast is in the process of hiding (animation in progress). */
        HIDING,

        /** Toast is being reattached to a new activity. */
        REATTACHING,

        /** Toast has been detected as stuck and is being recovered. */
        STUCK
    }

    /**
     * Events that trigger state transitions.
     */
    public enum Event {
        /** Show a temporary toast. */
        SHOW_TEMPORARY,

        /** Show a persistent toast. */
        SHOW_PERSISTENT,

        /** Update the toast text. */
        UPDATE,

        /** Heartbeat received (resets stuck timer). */
        HEARTBEAT,

        /** Hide the toast. */
        HIDE,

        /** Force hide the toast. */
        FORCE_HIDE,

        /** Reattach to a new activity. */
        REATTACH,

        /** Stuck detected by health check. */
        STUCK_DETECTED,

        /** Recovery completed. */
        RECOVERED
    }

    // ========================================================================
    // Listener Interfaces
    // ========================================================================

    /**
     * Listener for toast state changes and stuck detection events.
     */
    public interface ToastStateListener {

        /**
         * Called when the toast state changes.
         *
         * @param oldState Previous state
         * @param newState New state
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);

        /**
         * Called when a stuck toast is detected.
         *
         * @param reason        The reason the toast was considered stuck
         * @param ageMs         How long the toast had been showing
         * @param inactiveTimeMs Time since last activity (heartbeat or update)
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs, long inactiveTimeMs);
    }

    // ========================================================================
    // Per-Activity Overlay Tracking
    // ========================================================================

    /**
     * Holds the overlay views for each activity.
     * This allows each activity to have its own overlay instance.
     */
    private static class OverlayHolder {
        final WeakReference<FrameLayout> overlayRef;
        final WeakReference<TextView> textViewRef;
        final WeakReference<Activity> activityRef;
        final String message;
        final String operationId;
        final boolean isPersistent;

        OverlayHolder(FrameLayout overlay, TextView textView, Activity activity,
                      String message, String operationId, boolean isPersistent) {
            this.overlayRef = new WeakReference<>(overlay);
            this.textViewRef = new WeakReference<>(textView);
            this.activityRef = new WeakReference<>(activity);
            this.message = message;
            this.operationId = operationId;
            this.isPersistent = isPersistent;
        }

        boolean isValid() {
            return overlayRef.get() != null && textViewRef.get() != null;
        }

        void cleanup() {
            FrameLayout overlay = overlayRef.get();
            if (overlay != null && overlay.getParent() != null) {
                try { ((ViewGroup) overlay.getParent()).removeView(overlay); } catch (Exception ignored) {}
            }
        }
    }

    /** Map of activity -> overlay holder. */
    private final ConcurrentHashMap<String, OverlayHolder> mOverlayMap = new ConcurrentHashMap<>();

    /** Special key for rootView-only toasts (no activity). */
    private static final String KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY";

    // ========================================================================
    // Singleton Pattern
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;

    /** Application context. */
    @Nullable
    private static Application sApplication;

    /** Main thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Health check handler. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // State Machine Variables
    // ========================================================================

    /** Current state of the state machine. */
    private final AtomicReference<State> mCurrentState = new AtomicReference<>(State.HIDDEN);

    /** Timestamp when the current state started. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);

    /** Timestamp of the last activity (heartbeat or update). */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);

    /** Flag indicating if recovery is in progress. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);

    /** Health check runnable. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Recovery runnable. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock for health check operations. */
    private final Object mHealthLock = new Object();

    // ========================================================================
    // Auto-Dismiss Management
    // ========================================================================

    /** Runnable for auto-dismissing temporary toasts. */
    @Nullable
    private Runnable mAutoDismissRunnable = null;

    /** Duration of the current temporary toast in milliseconds. */
    private long mTemporaryToastDuration = 0;

    /** Flag indicating if a temporary toast has been dismissed. */
    private final AtomicBoolean mTemporaryToastDismissed = new AtomicBoolean(false);

    // ========================================================================
    // Global Toast State
    // ========================================================================

    /** Current message text being displayed globally. */
    @Nullable
    private String mCurrentMessage = null;

    /** Current operation ID for persistent overlay matching. */
    @Nullable
    private String mCurrentOperationId = null;

    /** Current activity reference (weak to prevent leaks). */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;

    /** Flag indicating if lifecycle callbacks are registered. */
    private boolean mCallbacksRegistered = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Broadcast receiver for theme changes. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;

    // ========================================================================
    // Listeners
    // ========================================================================

    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners =
            new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor and Initialization
    // ========================================================================

    /**
     * Private constructor for singleton pattern.
     *
     * @param context Any context (will be converted to application context)
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        mCurrentState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        Log.d(TAG, "ToastManager initialized (per-activity overlay management)");
    }

    /**
     * Initializes the ToastManager singleton.
     *
     * <p>This method MUST be called once, typically in the Application
     * or main Activity's {@code onCreate()}.</p>
     *
     * @param context Any context (will be converted to application context)
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }

    /**
     * Returns the singleton instance of ToastManager.
     *
     * @return The ToastManager singleton instance
     * @throws IllegalStateException if ToastManager has not been initialized
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ========================================================================
    // State Machine Methods
    // ========================================================================

    /**
     * Transitions to a new state and notifies listeners.
     *
     * @param newState The new state
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);
        if (oldState == newState) {
            return;
        }
        Log.d(TAG, "State transition: " + oldState + " → " + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying state listener", e);
            }
        }
    }

    /**
     * Handles an event in the state machine.
     *
     * @param event The event to process
     * @return True if the event was handled
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mCurrentState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);

        switch (event) {
            case SHOW_TEMPORARY:  return handleShowTemporary(currentState);
            case SHOW_PERSISTENT: return handleShowPersistent(currentState);
            case UPDATE:          return handleUpdate(currentState);
            case HEARTBEAT:       return handleHeartbeat(currentState);
            case HIDE:            return handleHide(currentState);
            case FORCE_HIDE:      return handleForceHide(currentState);
            case REATTACH:        return handleReattach(currentState);
            case STUCK_DETECTED:  return handleStuckDetected(currentState);
            case RECOVERED:       return handleRecovered(currentState);
            default:              return false;
        }
    }

    private boolean handleShowTemporary(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        forceHideInternal();
        transitionTo(State.SHOWING_TEMPORARY);
        return true;
    }

    private boolean handleShowPersistent(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_PERSISTENT);
            return true;
        }
        forceHideInternal();
        transitionTo(State.SHOWING_PERSISTENT);
        return true;
    }

    private boolean handleUpdate(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update toast in state: " + currentState);
        return false;
    }

    private boolean handleHeartbeat(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }

    private boolean handleHide(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true;
        }
        Log.w(TAG, "Cannot hide toast in state: " + currentState);
        return false;
    }

    private boolean handleForceHide(State currentState) {
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }

    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState + " (only persistent toasts are reattached)");
        return false;
    }

    private boolean handleStuckDetected(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT || currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Toast stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }

    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }

    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================

    /**
     * Registers activity lifecycle callbacks with the Application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) return;
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}
    @Override public void onActivityStarted(Activity activity) {}

    /**
     * Called when an activity resumes. Updates current activity reference
     * and reattaches any showing persistent overlay.
     *
     * <p>Temporary toasts are NOT reattached - they auto-dismiss and stay dismissed.
     * This prevents the "stuck toast" issue that occurred when temporary toasts
     * shown in {@code onActivityResult()} after SAF folder selection would become
     * persistent due to lifecycle race conditions.</p>
     *
     * @param activity The activity being resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        State currentState = mCurrentState.get();
        // Only reattach persistent toasts - temporary toasts should not survive activity transitions
        if (currentState == State.SHOWING_PERSISTENT) {
            handleEvent(Event.REATTACH);
            reattachToActivity(activity);
        } else if (currentState == State.SHOWING_TEMPORARY) {
            // Temporary toast should not be reattached - it auto-dismisses
            Log.d(TAG, "Temporary toast showing, not reattaching (auto-dismiss will handle it)");
        }
    }

    @Override public void onActivityPaused(Activity activity) {}

    /**
     * Called when an activity stops. Clears activity reference if it matches.
     *
     * @param activity The activity being stopped
     */
    @Override
    public void onActivityStopped(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        // Clean up overlay for this activity if it exists
        String key = getActivityKey(activity);
        OverlayHolder holder = mOverlayMap.remove(key);
        if (holder != null) {
            holder.cleanup();
            Log.v(TAG, "Cleaned up overlay for stopped activity: " + activity.getClass().getSimpleName());
        }
        performHealthCheck();
    }

    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

    /**
     * Called when an activity is destroyed. Clears reference and triggers health check.
     *
     * @param activity The activity being destroyed
     */
    @Override
    public void onActivityDestroyed(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        // Clean up overlay for this activity
        String key = getActivityKey(activity);
        OverlayHolder holder = mOverlayMap.remove(key);
        if (holder != null) {
            holder.cleanup();
            Log.v(TAG, "Cleaned up overlay for destroyed activity: " + activity.getClass().getSimpleName());
        }
        performHealthCheck();
    }

    // ========================================================================
    // Theme Management
    // ========================================================================

    /**
     * Registers a broadcast receiver to listen for theme color changes.
     */
    private void registerThemeReceiver() {
        if (sApplication == null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        sApplication.registerReceiver(mThemeReceiver, new IntentFilter(ACTION_THEME_COLOR_CHANGED));
    }

    /**
     * Refreshes the overlay text color to match the current theme.
     * This method is safe to call from any thread.
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        final int themeColor = toastManager.getThemeColor();
        toastManager.mMainHandler.post(() -> {
            State currentState = toastManager.mCurrentState.get();
            if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
                return;
            }
            // Update all overlays
            for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                TextView tv = holder.textViewRef.get();
                if (tv != null) {
                    tv.setTextColor(themeColor);
                }
            }
        });
    }

    /**
     * Gets the current theme color from ThemeManager.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) return DEFAULT_THEME_COLOR;
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception e) {
            return DEFAULT_THEME_COLOR;
        }
    }

    // ========================================================================
    // Health Check
    // ========================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new HealthCheckRunnable(this);
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: " + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Static health check runnable with weak reference to ToastManager.
     * Prevents memory leaks if the manager is garbage collected.
     */
    private static class HealthCheckRunnable implements Runnable {
        private final WeakReference<ToastManager> managerRef;

        HealthCheckRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Health check runnable: ToastManager was garbage collected, stopping");
                return;
            }
            manager.performHealthCheck();
            if (manager.mHealthCheckRunnable != null) {
                manager.mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
            }
        }
    }

    /**
     * Performs a comprehensive health check to detect stuck toasts.
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mCurrentState.get();
            if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
                return;
            }

            // Check if we have any valid overlay
            boolean hasValidOverlay = false;
            for (OverlayHolder holder : mOverlayMap.values()) {
                if (holder.isValid()) {
                    hasValidOverlay = true;
                    break;
                }
            }

            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();
            long inactiveTime = now - mLastActivityTime.get();

            boolean isStuck = false;
            String stuckReason = null;

            // Check 1: No valid overlays but state says showing
            if (!hasValidOverlay) {
                isStuck = true;
                stuckReason = "No valid overlay found";
            }
            // Check 2: Persistent overlay with no activity for 5+ seconds
            else if (currentState == State.SHOWING_PERSISTENT && inactiveTime > STUCK_TIMEOUT_MS) {
                isStuck = true;
                stuckReason = "No heartbeat for " + inactiveTime + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
            }
            // Check 3: Temporary toast exceeded expected duration
            else if (currentState == State.SHOWING_TEMPORARY && age > TEMP_TOAST_MAX_MS) {
                // Check if we still have a temporary toast in the map
                boolean hasTemporary = false;
                for (OverlayHolder holder : mOverlayMap.values()) {
                    if (!holder.isPersistent) {
                        hasTemporary = true;
                        break;
                    }
                }
                if (hasTemporary) {
                    isStuck = true;
                    stuckReason = "Temporary toast stuck (age: " + age + "ms)";
                }
            }

            if (isStuck) {
                Log.w(TAG, "STUCK TOAST DETECTED: " + stuckReason);

                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason, age, inactiveTime);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying stuck listener", e);
                    }
                }

                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }

    /**
     * Starts recovery from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        Log.d(TAG, "Starting toast recovery");
        cancelRecovery();

        mRecoveryRunnable = new RecoveryRunnable(this);
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Static recovery runnable with weak reference to ToastManager.
     * Prevents memory leaks if the manager is garbage collected.
     */
    private static class RecoveryRunnable implements Runnable {
        private final WeakReference<ToastManager> managerRef;

        RecoveryRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Recovery runnable: ToastManager was garbage collected");
                return;
            }
            Log.d(TAG, "Toast recovery completed");
            manager.forceHideInternal();
            manager.handleEvent(Event.RECOVERED);
            manager.mIsRecovering.set(false);
            manager.mRecoveryRunnable = null;
        }
    }

    /**
     * Cancels any pending recovery.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================

    /**
     * Returns the currently active activity tracked by ToastManager.
     *
     * @return The current activity, or null if none is available
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }

    // ========================================================================
    // Public API - Heartbeat
    // ========================================================================

    /**
     * Sends a heartbeat for the current persistent overlay.
     *
     * <p><b>IMPORTANT:</b> Long-running operations MUST call this method every
     * 5 seconds to prevent the toast from being considered stuck.</p>
     *
     * @param operationId The operation ID to match (can be null for any operation)
     * @return True if the heartbeat was accepted, false if the operation ID didn't match
     */
    public static boolean heartbeat(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (operationId != null && toastManager.mCurrentOperationId != null && !toastManager.mCurrentOperationId.equals(operationId)) {
            return false;
        }
        return toastManager.handleEvent(Event.HEARTBEAT);
    }

    // ========================================================================
    // Public API - Temporary Toasts
    // ========================================================================

    /**
     * Shows a temporary toast message with the specified duration.
     * Any existing toast (temporary or persistent) is immediately hidden.
     *
     * <p>Temporary toasts auto-dismiss after the specified duration and are
     * NOT reattached on activity lifecycle events. This prevents the "stuck toast"
     * issue that occurred when temporary toasts shown in {@code onActivityResult()}
     * after SAF folder selection would become persistent due to lifecycle race
     * conditions.</p>
     *
     * @param activity The activity to show the toast in
     * @param message  The message to display
     * @param duration The duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }

        // Cancel any pending auto-dismiss
        toastManager.cancelAutoDismiss();

        // Hide any existing toast
        toastManager.hideCurrentToast(false);

        // Reset temporary toast state
        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = duration;

        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show toast");
                return;
            }

            toastManager.createOverlayInView(activity, root, message, false);

            // Schedule auto-dismiss
            final AutoDismissRunnable dismissRunnable = new AutoDismissRunnable(toastManager, duration);
            toastManager.mAutoDismissRunnable = dismissRunnable;
            toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
            Log.d(TAG, "Temporary toast shown: " + message + " (duration: " + duration + "ms)");
        }
    }

    /**
     * Static auto-dismiss runnable with weak reference to ToastManager.
     * Prevents memory leaks if the manager is garbage collected.
     */
    private static class AutoDismissRunnable implements Runnable {
        private final WeakReference<ToastManager> managerRef;
        private final long duration;

        AutoDismissRunnable(ToastManager manager, long duration) {
            this.managerRef = new WeakReference<>(manager);
            this.duration = duration;
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Auto-dismiss runnable: ToastManager was garbage collected");
                return;
            }
            State currentState = manager.mCurrentState.get();
            if (currentState == State.SHOWING_TEMPORARY && !manager.mTemporaryToastDismissed.get()) {
                Log.d(TAG, "Auto-dismissing temporary toast after " + duration + "ms");
                manager.mTemporaryToastDismissed.set(true);
                manager.hideCurrentToast(true);
                manager.transitionTo(State.HIDDEN);
            }
            if (manager.mAutoDismissRunnable == this) {
                manager.mAutoDismissRunnable = null;
            }
        }
    }

    /**
     * Shows a temporary toast message with LONG duration (2000ms).
     *
     * @param activity The activity to show the toast in
     * @param message  The message to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }

    /**
     * Shows a temporary toast within a specific view container (e.g., a dialog).
     * Any existing toast is hidden immediately.
     *
     * @param rootView The root view to attach the toast to
     * @param message  The message to display
     * @param duration The duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();

        toastManager.cancelAutoDismiss();
        toastManager.hideCurrentToast(false);

        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = duration;

        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            toastManager.createOverlayInView(null, rootView, message, false);

            final AutoDismissRunnable dismissRunnable = new AutoDismissRunnable(toastManager, duration);
            toastManager.mAutoDismissRunnable = dismissRunnable;
            toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
            Log.d(TAG, "Temporary toast shown in view: " + message + " (duration: " + duration + "ms)");
        }
    }

    // ========================================================================
    // Public API - Persistent Overlay
    // ========================================================================

    /**
     * Shows a persistent overlay message that stays until explicitly hidden.
     *
     * <p><b>IMPORTANT:</b> Long-running operations MUST call {@link #heartbeat(String)}
     * every 5 seconds to prevent the toast from being considered stuck.</p>
     *
     * <p>Any existing toast (temporary or persistent) is immediately hidden.</p>
     *
     * @param activity The activity to show the overlay in
     * @param message  The message to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }

    /**
     * Shows a persistent overlay message with an operation ID for matching.
     *
     * <p>This is the preferred method for long-running operations because it
     * allows {@link #heartbeat(String)} and {@link #hidePersistentOverlay(String)}
     * to match the operation.</p>
     *
     * @param activity    The activity to show the overlay in
     * @param message     The message to display
     * @param operationId Unique identifier for this operation (can be null)
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message, @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }

        toastManager.cancelAutoDismiss();
        toastManager.hideCurrentToast(false);

        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = 0;

        if (toastManager.handleEvent(Event.SHOW_PERSISTENT)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = operationId;
            toastManager.mStateStartTime.set(SystemClock.elapsedRealtime());
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show persistent overlay");
                return;
            }

            toastManager.createOverlayInView(activity, root, message, true);
            toastManager.mCurrentActivityRef = new WeakReference<>(activity);

            Log.d(TAG, "Persistent overlay shown: " + message + (operationId != null ? " (ID: " + operationId + ")" : ""));
        }
    }

    /**
     * Updates the text of the persistent overlay without recreating the view.
     *
     * <p>This also resets the inactivity timer, keeping the toast alive.</p>
     *
     * @param message The new message to display
     */
    public static void updatePersistentOverlay(@NonNull String message) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            Log.w(TAG, "Cannot update persistent overlay - no overlay is showing");
            return;
        }

        if (toastManager.handleEvent(Event.UPDATE)) {
            toastManager.mCurrentMessage = message;
            toastManager.mMainHandler.post(() -> {
                for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                    TextView tv = holder.textViewRef.get();
                    if (tv != null) {
                        tv.setText(message);
                    }
                }
                Log.v(TAG, "Persistent overlay updated: " + message);
            });
        }
    }

    /**
     * Hides the persistent overlay if the operation ID matches.
     *
     * @param operationId The operation ID that should match the current overlay
     * @return True if the overlay was hidden, false if ID mismatch or no overlay
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            return false;
        }

        if (operationId != null && toastManager.mCurrentOperationId != null && !toastManager.mCurrentOperationId.equals(operationId)) {
            Log.d(TAG, "Hide rejected - operation ID mismatch: expected " + toastManager.mCurrentOperationId + ", got " + operationId);
            return false;
        }

        if (toastManager.handleEvent(Event.HIDE)) {
            toastManager.hideCurrentToast(true);
            Log.d(TAG, "Persistent overlay hidden" + (operationId != null ? " (ID: " + operationId + ")" : ""));
            return true;
        }
        return false;
    }

    /**
     * Hides the persistent overlay regardless of operation ID.
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            toastManager.handleEvent(Event.FORCE_HIDE);
            toastManager.hideCurrentToast(true);
        }
    }

    /**
     * Checks if a persistent toast is currently showing.
     *
     * @return True if a persistent toast is visible
     */
    public static boolean hasPersistentToast() {
        return getInstance().mCurrentState.get() == State.SHOWING_PERSISTENT;
    }

    /**
     * Gets the current persistent toast text.
     *
     * @return The current message text, or null if no persistent toast exists
     */
    @Nullable
    public static String getPersistentToastText() {
        return getInstance().mCurrentMessage;
    }

    /**
     * Gets the current operation ID for the persistent overlay.
     *
     * @return The operation ID, or null if none
     */
    @Nullable
    public static String getCurrentOperationId() {
        return getInstance().mCurrentOperationId;
    }

    // ========================================================================
    // Reattach Methods
    // ========================================================================

    /**
     * Reattaches a PERSISTENT toast to the current activity.
     *
     * <p>Temporary toasts are NOT reattached - they auto-dismiss and stay dismissed.
     * This is a critical design decision that prevents temporary toasts from becoming
     * persistent due to lifecycle race conditions. For example, when a toast is shown
     * in {@code onActivityResult()} after returning from SAF folder selection, the
     * activity lifecycle events could otherwise cause the toast to become stuck.</p>
     *
     * <p>This method should be called from {@code onResume()} and {@code onRestart()}
     * of activities that need to preserve persistent toasts across configuration changes.</p>
     *
     * @param activity The current activity
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        // Only reattach PERSISTENT toasts
        if (currentState != State.SHOWING_PERSISTENT) {
            Log.d(TAG, "Not reattaching - only persistent toasts are reattached");
            return;
        }

        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        toastManager.mMainHandler.post(() -> {
            if (activity.isFinishing() || activity.isDestroyed()) return;

            // Verify we're still in a showing state
            State currentStateCheck = toastManager.mCurrentState.get();
            if (currentStateCheck == State.HIDDEN || currentStateCheck == State.HIDING) {
                return;
            }

            toastManager.handleEvent(Event.REATTACH);
            toastManager.reattachToActivity(activity);
        });
    }

    /**
     * Ensures the persistent overlay is attached to the current window.
     * If the overlay exists but is not attached, recreate it.
     *
     * @param activity The current activity
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (currentState != State.SHOWING_PERSISTENT) {
            return;
        }

        // Check if this activity has a valid overlay
        String key = getActivityKey(activity);
        OverlayHolder holder = toastManager.mOverlayMap.get(key);
        if (holder == null || !holder.isValid()) {
            // Recreate overlay for this activity
            reattachToCurrentActivity(activity);
        }
    }

    // ========================================================================
    // State Listeners
    // ========================================================================

    /**
     * Adds a toast state listener.
     * The listener will immediately receive the current state.
     *
     * @param listener The listener to add
     */
    public static void addStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        State currentState = toastManager.mCurrentState.get();
        listener.onStateChanged(currentState, currentState);
    }

    /**
     * Removes a toast state listener.
     *
     * @param listener The listener to remove
     */
    public static void removeStateListener(@NonNull ToastStateListener listener) {
        getInstance().mStateListeners.remove(listener);
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Gets a unique key for an activity.
     *
     * @param activity The activity
     * @return A unique key string
     */
    @NonNull
    private static String getActivityKey(@Nullable Activity activity) {
        if (activity == null) {
            return KEY_ROOT_VIEW_ONLY;
        }
        return activity.getClass().getName() + "@" + System.identityHashCode(activity);
    }

    /**
     * Cancels any pending auto-dismiss runnable.
     */
    private void cancelAutoDismiss() {
        if (mAutoDismissRunnable != null) {
            mMainHandler.removeCallbacks(mAutoDismissRunnable);
            mAutoDismissRunnable = null;
        }
        mTemporaryToastDismissed.set(false);
        mTemporaryToastDuration = 0;
    }

    // ========================================================================
    // View Management
    // ========================================================================

    /**
     * Creates the overlay view and attaches it to the specified root view.
     * Any existing overlay for this activity is removed first.
     *
     * @param activity     The activity (can be null for rootView-only usage)
     * @param rootView     The parent view to attach the overlay to
     * @param message      The message to display
     * @param isPersistent True if this is a persistent overlay
     */
    private void createOverlayInView(@Nullable Activity activity, @NonNull ViewGroup rootView,
                                     @NonNull String message, boolean isPersistent) {
        // Clean up any existing overlay for this activity
        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP);
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);

        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        textView.setTextColor(getThemeColor());

        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), TOAST_STROKE_COLOR);
        textView.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }

        container.addView(textView);
        rootView.addView(container);

        // Store the overlay for this activity
        mOverlayMap.put(key, new OverlayHolder(container, textView, activity, message, mCurrentOperationId, isPersistent));

        if (activity != null) {
            mCurrentActivityRef = new WeakReference<>(activity);
        }

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }

    /**
     * Reattaches the toast to a new activity by creating a fresh overlay.
     *
     * <p>Only persistent toasts are reattached. Temporary toasts are not
     * reattached as they auto-dismiss and should not survive activity
     * transitions.</p>
     *
     * @param activity The activity to reattach to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        State currentState = mCurrentState.get();
        if (currentState != State.SHOWING_PERSISTENT) {
            Log.w(TAG, "Cannot reattach - only persistent toasts are supported");
            return;
        }

        if (mCurrentMessage == null) {
            Log.w(TAG, "Cannot reattach - no message available");
            transitionTo(State.HIDDEN);
            return;
        }

        // Clean up any existing overlay for this activity
        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found for reattachment");
            return;
        }

        // Persistent toast only
        createOverlayInView(activity, root, mCurrentMessage, true);
        mCurrentActivityRef = new WeakReference<>(activity);

        // Transition back to appropriate state
        if (currentState == State.REATTACHING || currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.SHOWING_PERSISTENT);
        }

        Log.d(TAG, "Overlay reattached to activity: " + activity.getClass().getSimpleName());
    }

    /**
     * Unified method to hide the current toast.
     *
     * @param animate whether to perform a fade-out animation
     */
    private void hideCurrentToast(boolean animate) {
        cancelAutoDismiss();
        mTemporaryToastDuration = 0;

        if (animate) {
            // Animate all overlays out
            for (OverlayHolder holder : mOverlayMap.values()) {
                final FrameLayout overlay = holder.overlayRef.get();
                if (overlay != null) {
                    AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
                    fadeOut.setDuration(FADE_DURATION_MS);
                    fadeOut.setAnimationListener(new Animation.AnimationListener() {
                        @Override public void onAnimationStart(Animation animation) {}
                        @Override public void onAnimationEnd(Animation animation) {
                            removeOverlayView(overlay);
                        }
                        @Override public void onAnimationRepeat(Animation animation) {}
                    });
                    overlay.startAnimation(fadeOut);
                }
            }
        } else {
            // Remove all overlays immediately
            for (OverlayHolder holder : mOverlayMap.values()) {
                holder.cleanup();
            }
        }

        mOverlayMap.clear();
        transitionTo(State.HIDDEN);
        mCurrentMessage = null;
        mCurrentOperationId = null;
        mCurrentActivityRef = null;
        mAutoDismissRunnable = null;
        mTemporaryToastDismissed.set(false);
    }

    /**
     * Forces an immediate hide without animation.
     */
    private void forceHideInternal() {
        cancelAutoDismiss();
        mTemporaryToastDuration = 0;

        for (OverlayHolder holder : mOverlayMap.values()) {
            holder.cleanup();
        }
        mOverlayMap.clear();
        transitionTo(State.HIDDEN);
        mCurrentMessage = null;
        mCurrentOperationId = null;
        mCurrentActivityRef = null;
        mAutoDismissRunnable = null;
        mTemporaryToastDismissed.set(false);
    }

    /**
     * Removes the overlay view from its parent.
     *
     * @param overlay The overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {}
        }
    }

    /**
     * Converts density-independent pixels (dp) to absolute pixels (px).
     *
     * @param context The context for accessing display metrics
     * @param dp      The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns debug information about the current state.
     *
     * @return Debug string
     */
    @NonNull
    public String getDebugInfo() {
        return "ToastManager\n" +
                "State: " + mCurrentState.get() + "\n" +
                "State duration: " + (SystemClock.elapsedRealtime() - mStateStartTime.get()) + "ms\n" +
                "Last activity: " + (SystemClock.elapsedRealtime() - mLastActivityTime.get()) + "ms ago\n" +
                "Message: " + mCurrentMessage + "\n" +
                "Operation ID: " + mCurrentOperationId + "\n" +
                "Active overlays: " + mOverlayMap.size() + "\n" +
                "Listeners: " + mStateListeners.size();
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Shuts down the ToastManager and releases all resources.
     * This should be called when the application is terminating.
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");

        toastManager.cancelAutoDismiss();
        toastManager.cancelRecovery();

        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }

        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {}
        }

        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {}
        }

        toastManager.forceHideInternal();
        sInstance = null;
        sApplication = null;
        Log.d(TAG, "ToastManager shut down complete");
    }
}