package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Custom toast notification manager with theme support and watchdog protection.
 * 
 * <p>This class provides a custom toast implementation using styled overlays
 * instead of system Toasts, with theme color integration and fade animations.
 * Includes a watchdog timer to automatically clear stale persistent overlays.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Custom‑styled overlays matching app theme</li>
 *   <li>Persistent overlay support with operation ID tracking</li>
 *   <li>Watchdog protection: automatic timeout after 30s (or 45s heartbeat) and 2min absolute</li>
 *   <li>Activity reattachment after configuration change (with LayoutParams reset fix)</li>
 *   <li>Theme colour integration and live updates</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class ToastManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    public static final int LENGTH_SHORT = 500;
    public static final int LENGTH_NORMAL = 1000;
    public static final int LENGTH_LONG = 2000;
    
    private static final int FADE_DURATION_MS = 150;
    private static final int MAX_TOAST_WIDTH_DP = 320;
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;
    private static final int TOAST_PADDING_VERTICAL_DP = 8;
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;
    private static final int TOAST_CORNER_RADIUS_DP = 5;
    private static final int TOAST_STROKE_WIDTH_DP = 1;
    private static final int TOAST_ELEVATION_DP = 6;
    private static final String TOAST_BACKGROUND_COLOR = "#1A1A1A";
    private static final String TOAST_STROKE_COLOR = "#1E1E1E";
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    private static final long WATCHDOG_TIMEOUT_MS = 30000;
    private static final long MAX_PERSISTENT_DURATION_MS = 120000;
    private static final long HEARTBEAT_TIMEOUT_MS = 45000;
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    private static final Handler sHandler = new Handler(Looper.getMainLooper());
    @Nullable private static View sPersistentOverlay = null;
    @Nullable private static TextView sPersistentTextView = null;
    @Nullable private static Runnable sHideRunnable = null;
    @Nullable private static BroadcastReceiver sThemeReceiver = null;
    private static boolean sReceiverRegistered = false;
    @Nullable private static Context sAppContext = null;
    private static boolean sIsPersistentToast = false;
    @Nullable private static Runnable sWatchdogRunnable = null;
    private static boolean sWatchdogActive = false;
    private static final Object sWatchdogLock = new Object();
    private static long sLastHeartbeatTime = 0;
    private static long sOverlayStartTime = 0;
    @Nullable private static String sCurrentOperationId = null;
    private static final ConcurrentHashMap<String, Long> sOperationStartTimes = new ConcurrentHashMap<>();
    
    // ========================================================================
    // Initialisation
    // ========================================================================
    
    public static void init(@NonNull Context context) {
        sAppContext = context.getApplicationContext();
        registerGlobalThemeReceiver();
    }
    
    private static void registerGlobalThemeReceiver() {
        if (sReceiverRegistered || sAppContext == null) return;
        sThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        try {
            sAppContext.registerReceiver(sThemeReceiver, new IntentFilter(ACTION_THEME_COLOR_CHANGED));
            sReceiverRegistered = true;
        } catch (Exception e) {
            Log.e("ToastManager", "Failed to register theme receiver", e);
        }
    }
    
    // ========================================================================
    // Watchdog
    // ========================================================================
    
    private static void startWatchdog() {
        synchronized (sWatchdogLock) {
            cancelWatchdogLocked();
            final long start = SystemClock.elapsedRealtime();
            sOverlayStartTime = start;
            sLastHeartbeatTime = start;
            sWatchdogRunnable = new Runnable() {
                @Override
                public void run() {
                    synchronized (sWatchdogLock) {
                        if (!sIsPersistentToast || sPersistentOverlay == null) {
                            sWatchdogActive = false;
                            return;
                        }
                        long now = SystemClock.elapsedRealtime();
                        long age = now - start;
                        long sinceHeartbeat = now - sLastHeartbeatTime;
                        if (age > MAX_PERSISTENT_DURATION_MS || sinceHeartbeat > HEARTBEAT_TIMEOUT_MS) {
                            Log.w("ToastManager", "Watchdog forcing hide (age=" + age + ", heartbeat=" + sinceHeartbeat + ")");
                            forceHidePersistentOverlayLocked();
                            return;
                        }
                        if (age > WATCHDOG_TIMEOUT_MS) {
                            Log.d("ToastManager", "Watchdog rescheduling");
                        }
                        sHandler.postDelayed(this, WATCHDOG_TIMEOUT_MS);
                    }
                }
            };
            sWatchdogActive = true;
            sHandler.postDelayed(sWatchdogRunnable, WATCHDOG_TIMEOUT_MS);
        }
    }
    
    private static void cancelWatchdogLocked() {
        if (sWatchdogRunnable != null) {
            sHandler.removeCallbacks(sWatchdogRunnable);
            sWatchdogRunnable = null;
        }
        sWatchdogActive = false;
    }
    
    private static void resetWatchdog() {
        synchronized (sWatchdogLock) {
            if (sIsPersistentToast && sPersistentOverlay != null) {
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
                cancelWatchdogLocked();
                startWatchdog();
            }
        }
    }
    
    public static void heartbeat() {
        synchronized (sWatchdogLock) {
            if (sIsPersistentToast && sPersistentOverlay != null) {
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
            }
        }
    }
    
    private static void forceHidePersistentOverlayLocked() {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {}
        }
        sPersistentOverlay = null;
        sPersistentTextView = null;
        sIsPersistentToast = false;
        sWatchdogActive = false;
        if (sWatchdogRunnable != null) {
            sHandler.removeCallbacks(sWatchdogRunnable);
            sWatchdogRunnable = null;
        }
    }
    
    // ========================================================================
    // Public API – Temporary Toasts
    // ========================================================================
    
    public static void showToast(@Nullable Activity activity, @NonNull String message, int duration) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        if (sAppContext == null) init(activity);
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root != null) showToastInView(root, message, duration);
    }
    
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }
    
    // ========================================================================
    // Public API – Persistent Overlay
    // ========================================================================
    
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }
    
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message, @Nullable String operationId) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (sAppContext == null) init(activity);
        synchronized (sWatchdogLock) {
            if (operationId != null && operationId.equals(sCurrentOperationId)) cancelWatchdogLocked();
            if (sCurrentOperationId != null) sOperationStartTimes.remove(sCurrentOperationId);
            sCurrentOperationId = operationId;
            if (operationId != null) sOperationStartTimes.put(operationId, SystemClock.elapsedRealtime());
            sIsPersistentToast = true;
            hidePersistentOverlayInternalLocked(false);
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root != null) createPersistentOverlayInView(root, message);
            startWatchdog();
        }
    }
    
    public static void showPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        if (sAppContext == null) sAppContext = rootView.getContext().getApplicationContext();
        synchronized (sWatchdogLock) {
            cancelWatchdogLocked();
            sIsPersistentToast = true;
            createPersistentOverlayInView(rootView, message);
            startWatchdog();
        }
    }
    
    private static void createPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try { ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay); } catch (Exception ignored) {}
        }
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        int themeColor;
        try {
            ThemeManager tm = ThemeManager.getInstance(rootView.getContext());
            themeColor = (tm != null) ? tm.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        bg.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        bg.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(bg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        sLastHeartbeatTime = SystemClock.elapsedRealtime();
        sOverlayStartTime = sLastHeartbeatTime;
    }
    
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        if (!sIsPersistentToast) return;
        if (sPersistentTextView == null || sPersistentOverlay == null) return;
        if (activity.isFinishing() || activity.isDestroyed()) return;
        resetWatchdog();
        activity.runOnUiThread(() -> {
            if (sPersistentOverlay.getParent() != null) {
                try { ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay); } catch (Exception ignored) {}
            }
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root != null && sPersistentOverlay != null) {
                // FIX P2: Reset LayoutParams to be compatible with any parent
                sPersistentOverlay.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                root.addView(sPersistentOverlay);
                sPersistentOverlay.setVisibility(View.VISIBLE);
                if (sPersistentTextView != null) sPersistentTextView.setVisibility(View.VISIBLE);
            }
        });
    }
    
    public static void updatePersistentOverlay(@NonNull String message) {
        synchronized (sWatchdogLock) {
            if (sPersistentTextView != null) {
                sPersistentTextView.setText(message);
                refreshThemeColorLocked();
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
                resetWatchdog();
            }
        }
    }
    
    public static void hidePersistentOverlay() {
        hidePersistentOverlay(null);
    }
    
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        synchronized (sWatchdogLock) {
            if (operationId != null && sCurrentOperationId != null && !sCurrentOperationId.equals(operationId)) {
                return false;
            }
            sIsPersistentToast = false;
            if (sCurrentOperationId != null) sOperationStartTimes.remove(sCurrentOperationId);
            sCurrentOperationId = null;
            cancelWatchdogLocked();
            hidePersistentOverlayInternalLocked(true);
            return true;
        }
    }
    
    public static void forceHidePersistentOverlay() {
        synchronized (sWatchdogLock) {
            forceHidePersistentOverlayLocked();
        }
    }
    
    public static boolean hasPersistentToast() {
        return sIsPersistentToast && sPersistentTextView != null;
    }
    
    @Nullable
    public static String getPersistentToastText() {
        return (sPersistentTextView != null && sIsPersistentToast) ? sPersistentTextView.getText().toString() : null;
    }
    
    @Nullable
    public static String getCurrentOperationId() {
        return sCurrentOperationId;
    }
    
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        if (sPersistentOverlay == null) return;
        boolean attached = false;
        View parent = (View) sPersistentOverlay.getParent();
        while (parent != null) {
            if (parent.isAttachedToWindow()) { attached = true; break; }
            parent = (View) parent.getParent();
        }
        if (!attached && sPersistentTextView != null) {
            String msg = sPersistentTextView.getText().toString();
            sPersistentOverlay = null;
            sPersistentTextView = null;
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root != null) showPersistentOverlayInView(root, msg);
        }
    }
    
    // ========================================================================
    // View‑based Toast
    // ========================================================================
    
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int durationMs) {
        synchronized (sWatchdogLock) {
            sIsPersistentToast = false;
            cancelWatchdogLocked();
        }
        if (sAppContext == null) sAppContext = rootView.getContext().getApplicationContext();
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try { ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay); } catch (Exception ignored) {}
        }
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        int themeColor;
        try {
            ThemeManager tm = ThemeManager.getInstance(rootView.getContext());
            themeColor = (tm != null) ? tm.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        bg.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        bg.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(bg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        
        sHandler.removeCallbacks(sHideRunnable);
        sHideRunnable = () -> hidePersistentOverlayInternal(false);
        sHandler.postDelayed(sHideRunnable, durationMs);
    }
    
    // ========================================================================
    // Theme Updates
    // ========================================================================
    
    public static void refreshThemeColor() {
        synchronized (sWatchdogLock) {
            refreshThemeColorLocked();
        }
    }
    
    private static void refreshThemeColorLocked() {
        if (sPersistentTextView != null && sAppContext != null) {
            try {
                int color = ThemeManager.getInstance(sAppContext).getCurrentColorInt();
                sPersistentTextView.setTextColor(ColorStateList.valueOf(color));
            } catch (Exception ignored) {}
        }
    }
    
    // ========================================================================
    // Internal Helpers
    // ========================================================================
    
    private static void hidePersistentOverlayInternal(boolean removeCallbacks) {
        synchronized (sWatchdogLock) {
            hidePersistentOverlayInternalLocked(removeCallbacks);
        }
    }
    
    private static void hidePersistentOverlayInternalLocked(boolean removeCallbacks) {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            final View overlay = sPersistentOverlay;
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(FADE_DURATION_MS);
            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override public void onAnimationStart(Animation a) {}
                @Override public void onAnimationEnd(Animation a) {
                    if (overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
                }
                @Override public void onAnimationRepeat(Animation a) {}
            });
            overlay.startAnimation(fadeOut);
        }
        sPersistentOverlay = null;
        sPersistentTextView = null;
        if (removeCallbacks && sHideRunnable != null) {
            sHandler.removeCallbacks(sHideRunnable);
            sHideRunnable = null;
        }
    }
    
    private static int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }
}