package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Centralized Toast Manager with State Machine for reliable toast lifecycle management.
 * 
 * <p>This manager provides a custom toast implementation using styled overlays
 * with a state machine to ensure reliable lifecycle management. The state machine
 * prevents race conditions and provides clear visibility into toast state.</p>
 * 
 * <h3>States</h3>
 * <ul>
 *   <li><b>HIDDEN</b> - No toast is showing</li>
 *   <li><b>SHOWING_TEMPORARY</b> - A temporary toast is being shown (auto-hides)</li>
 *   <li><b>SHOWING_PERSISTENT</b> - A persistent toast is being shown (requires hide)</li>
 *   <li><b>HIDING</b> - Toast is in the process of hiding (animation in progress)</li>
 *   <li><b>REATTACHING</b> - Toast is being reattached to a new activity</li>
 *   <li><b>STUCK</b> - Toast has been detected as stuck and is being recovered</li>
 * </ul>
 * 
 * <h3>Auto-Recovery</h3>
 * <p>If a persistent toast receives NO heartbeat for 5 seconds, it enters STUCK state
 * and is automatically recovered.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.0
 * @since 1.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "ToastManager";
    
    /** Short duration: 500 milliseconds - for quick notifications. */
    public static final int LENGTH_SHORT = 500;
    
    /** Normal duration: 1000 milliseconds - standard toast length. */
    public static final int LENGTH_NORMAL = 1000;
    
    /** Long duration: 2000 milliseconds - for messages that need more reading time. */
    public static final int LENGTH_LONG = 2000;
    
    /** Duration for fade in/out animations in milliseconds. */
    private static final int FADE_DURATION_MS = 150;
    
    /** Maximum toast width in density-independent pixels. */
    private static final int MAX_TOAST_WIDTH_DP = 320;
    
    /** Horizontal padding for toast content in dp. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;
    
    /** Vertical padding for toast content in dp. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;
    
    /** Bottom margin from screen edge in dp. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;
    
    /** Corner radius for toast background in dp. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;
    
    /** Stroke width for toast border in dp. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;
    
    /** Elevation for toast on Lollipop+ in dp. */
    private static final int TOAST_ELEVATION_DP = 6;
    
    /** Toast background color (dark gray). */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;
    
    /** Toast stroke color (slightly lighter gray). */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;
    
    /** Default theme color fallback (Royal Llama). */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;
    
    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    // ========================================================================
    // Health Check & Stuck Detection Constants
    // ========================================================================
    
    /** Health check interval in milliseconds (5 seconds). */
    private static final long HEALTH_CHECK_INTERVAL_MS = 5000;
    
    /** Stuck detection timeout (5 seconds). */
    private static final long STUCK_TIMEOUT_MS = 5000;
    
    /** Maximum duration for temporary toasts (3 seconds). */
    private static final long TEMP_TOAST_MAX_MS = 3000;
    
    /** Recovery delay in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500;
    
    // ========================================================================
    // State Machine
    // ========================================================================
    
    /**
     * States of the toast state machine.
     */
    public enum State {
        /** No toast is showing. */
        HIDDEN,
        
        /** A temporary toast is being shown (auto-hides after duration). */
        SHOWING_TEMPORARY,
        
        /** A persistent toast is being shown (requires explicit hide). */
        SHOWING_PERSISTENT,
        
        /** Toast is in the process of hiding (animation in progress). */
        HIDING,
        
        /** Toast is being reattached to a new activity. */
        REATTACHING,
        
        /** Toast has been detected as stuck and is being recovered. */
        STUCK
    }
    
    /**
     * Events that trigger state transitions.
     */
    public enum Event {
        /** Show a temporary toast. */
        SHOW_TEMPORARY,
        
        /** Show a persistent toast. */
        SHOW_PERSISTENT,
        
        /** Update the toast text. */
        UPDATE,
        
        /** Heartbeat received (resets stuck timer). */
        HEARTBEAT,
        
        /** Hide the toast. */
        HIDE,
        
        /** Force hide the toast. */
        FORCE_HIDE,
        
        /** Reattach to a new activity. */
        REATTACH,
        
        /** Stuck detected by health check. */
        STUCK_DETECTED,
        
        /** Recovery completed. */
        RECOVERED
    }
    
    // ========================================================================
    // Listener Interfaces
    // ========================================================================
    
    /**
     * Listener for toast state changes.
     */
    public interface ToastStateListener {
        
        /**
         * Called when the toast state changes.
         *
         * @param oldState Previous state
         * @param newState New state
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);
        
        /**
         * Called when a stuck toast is detected.
         *
         * @param reason The reason the toast was considered stuck
         * @param ageMs How long the toast had been showing
         * @param inactiveTimeMs Time since last activity
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs, long inactiveTimeMs);
    }
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;
    
    /** Application context. */
    @Nullable
    private static Application sApplication;
    
    /** Main thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Health check handler. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // State Machine Variables
    // ========================================================================
    
    /** Current state of the state machine. */
    private final AtomicReference<State> mCurrentState = new AtomicReference<>(State.HIDDEN);
    
    /** Timestamp when the current state started. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);
    
    /** Timestamp of the last activity (heartbeat or update). */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);
    
    /** Flag indicating if recovery is in progress. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);
    
    /** Health check runnable. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;
    
    /** Recovery runnable. */
    @Nullable
    private Runnable mRecoveryRunnable = null;
    
    /** Lock for health check operations. */
    private final Object mHealthLock = new Object();
    
    // ========================================================================
    // Overlay State (Thread-Safe)
    // ========================================================================
    
    /** Current overlay container view (weak reference to prevent memory leaks). */
    @Nullable
    private WeakReference<FrameLayout> mOverlayRef = null;
    
    /** Current text view inside overlay (weak reference). */
    @Nullable
    private WeakReference<TextView> mTextViewRef = null;
    
    /** Current message text being displayed. */
    @Nullable
    private String mCurrentMessage = null;
    
    /** Current operation ID for persistent overlay matching. */
    @Nullable
    private String mCurrentOperationId = null;
    
    /** Current activity reference (weak to prevent leaks). */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;
    
    /** Flag indicating if lifecycle callbacks are registered. */
    private boolean mCallbacksRegistered = false;
    
    /** Hide runnable for temporary toast (to cancel if needed). */
    @Nullable
    private Runnable mHideRunnable = null;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Broadcast receiver for theme changes. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;
    
    // ========================================================================
    // Listeners
    // ========================================================================
    
    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners = 
        new CopyOnWriteArrayList<>();
    
    // ========================================================================
    // Constructor and Initialization
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Any context (will be converted to application context)
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        
        // Initialize state
        mCurrentState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        
        Log.d(TAG, "ToastManager initialized successfully");
    }
    
    /**
     * Initializes the ToastManager singleton.
     * 
     * <p>This method MUST be called once, typically in MusicPlayer.onCreate().</p>
     *
     * @param context Any context (will be converted to application context)
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }
    
    /**
     * Returns the singleton instance of ToastManager.
     *
     * @return The ToastManager singleton instance
     * @throws IllegalStateException if ToastManager has not been initialized
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }
    
    // ========================================================================
    // State Machine Methods
    // ========================================================================
    
    /**
     * Transitions to a new state and notifies listeners.
     *
     * @param newState The new state
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);
        
        if (oldState == newState) {
            return;
        }
        
        Log.d(TAG, "State transition: " + oldState + " → " + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        
        // Notify listeners
        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying state listener", e);
            }
        }
    }
    
    /**
     * Handles an event in the state machine.
     *
     * @param event The event to process
     * @return True if the event was handled
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mCurrentState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);
        
        switch (event) {
            case SHOW_TEMPORARY:
                return handleShowTemporary(currentState);
                
            case SHOW_PERSISTENT:
                return handleShowPersistent(currentState);
                
            case UPDATE:
                return handleUpdate(currentState);
                
            case HEARTBEAT:
                return handleHeartbeat(currentState);
                
            case HIDE:
                return handleHide(currentState);
                
            case FORCE_HIDE:
                return handleForceHide(currentState);
                
            case REATTACH:
                return handleReattach(currentState);
                
            case STUCK_DETECTED:
                return handleStuckDetected(currentState);
                
            case RECOVERED:
                return handleRecovered(currentState);
                
            default:
                Log.w(TAG, "Unknown event: " + event);
                return false;
        }
    }
    
    // ========================================================================
    // Event Handlers
    // ========================================================================
    
    private boolean handleShowTemporary(State currentState) {
        // Can show temporary toast from HIDDEN or HIDING states
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        // If already showing, hide current and show new
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            forceHideInternal();
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        Log.w(TAG, "Cannot show temporary toast in state: " + currentState);
        return false;
    }
    
    private boolean handleShowPersistent(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_PERSISTENT);
            return true;
        }
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            forceHideInternal();
            transitionTo(State.SHOWING_PERSISTENT);
            return true;
        }
        Log.w(TAG, "Cannot show persistent toast in state: " + currentState);
        return false;
    }
    
    private boolean handleUpdate(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update toast in state: " + currentState);
        return false;
    }
    
    private boolean handleHeartbeat(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }
    
    private boolean handleHide(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true; // Already hidden
        }
        Log.w(TAG, "Cannot hide toast in state: " + currentState);
        return false;
    }
    
    private boolean handleForceHide(State currentState) {
        // Can force hide from any state
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }
    
    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState);
        return false;
    }
    
    private boolean handleStuckDetected(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT || 
            currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Toast stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }
    
    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }
    
    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================
    
    /**
     * Registers activity lifecycle callbacks with the Application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered) return;
        if (sApplication == null) return;
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }
    
    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {}
    
    @Override
    public void onActivityStarted(@NonNull Activity activity) {}
    
    /**
     * Called when an activity resumes.
     * Updates current activity reference and reattaches any showing overlay.
     *
     * @param activity The activity being resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        
        State currentState = mCurrentState.get();
        if (currentState == State.SHOWING_TEMPORARY || currentState == State.SHOWING_PERSISTENT) {
            handleEvent(Event.REATTACH);
            reattachToActivity(activity);
        }
    }
    
    @Override
    public void onActivityPaused(@NonNull Activity activity) {}
    
    /**
     * Called when an activity stops.
     * Clears activity reference if it matches the current one.
     *
     * @param activity The activity being stopped
     */
    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
    }
    
    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}
    
    /**
     * Called when an activity is destroyed.
     * Clears reference and triggers health check.
     *
     * @param activity The activity being destroyed
     */
    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }
    
    // ========================================================================
    // Theme Management
    // ========================================================================
    
    /**
     * Registers a broadcast receiver to listen for theme color changes.
     */
    private void registerThemeReceiver() {
        if (sApplication == null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        sApplication.registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Refreshes the overlay text color to match the current theme.
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                TextView textView = toastManager.getTextView();
                State currentState = toastManager.mCurrentState.get();
                if (textView != null && (currentState == State.SHOWING_TEMPORARY || 
                    currentState == State.SHOWING_PERSISTENT)) {
                    textView.setTextColor(toastManager.getThemeColor());
                }
            }
        });
    }
    
    /**
     * Gets the current theme color from ThemeManager.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) return DEFAULT_THEME_COLOR;
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception e) {
            return DEFAULT_THEME_COLOR;
        }
    }
    
    // ========================================================================
    // Health Check (Primary Stuck Toast Prevention)
    // ========================================================================
    
    /**
     * Starts the periodic health check thread.
     * Runs every 5 seconds indefinitely to monitor toast health.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                performHealthCheck();
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: " + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }
    
    /**
     * Performs a comprehensive health check to detect stuck toasts.
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mCurrentState.get();
            
            // Only check if showing
            if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
                return;
            }
            
            FrameLayout overlay = getOverlay();
            TextView textView = getTextView();
            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();
            long inactiveTime = now - mLastActivityTime.get();
            boolean isAttached = overlay != null && overlay.getParent() != null;
            
            boolean isStuck = false;
            String stuckReason = null;
            
            // Check 1: Overlay exists but is not attached to any window
            if (overlay != null && !isAttached) {
                isStuck = true;
                stuckReason = "Overlay not attached to window";
            }
            // Check 2: TextView reference is gone
            else if (textView == null) {
                isStuck = true;
                stuckReason = "TextView reference lost";
            }
            // Check 3: Persistent overlay with no activity for 5+ seconds
            else if (currentState == State.SHOWING_PERSISTENT && inactiveTime > STUCK_TIMEOUT_MS) {
                isStuck = true;
                stuckReason = "No activity for " + inactiveTime + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
            }
            // Check 4: Temporary toast exceeded expected duration
            else if (currentState == State.SHOWING_TEMPORARY && age > TEMP_TOAST_MAX_MS) {
                isStuck = true;
                stuckReason = "Temporary toast stuck (age: " + age + "ms)";
            }
            
            if (isStuck) {
                Log.w(TAG, "STUCK TOAST DETECTED: " + stuckReason);
                
                // Notify listeners
                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason, age, inactiveTime);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying stuck listener", e);
                    }
                }
                
                // Enter stuck state and recover
                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }
    
    /**
     * Starts recovery from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        
        Log.d(TAG, "Starting toast recovery");
        
        // Cancel any existing recovery
        cancelRecovery();
        
        // Schedule recovery
        mRecoveryRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Toast recovery completed");
                forceHideInternal();
                handleEvent(Event.RECOVERED);
                mIsRecovering.set(false);
                mRecoveryRunnable = null;
            }
        };
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }
    
    /**
     * Cancels any pending recovery.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }
    
    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================
    
    /**
     * Returns the currently active activity tracked by ToastManager.
     *
     * @return The current activity, or null if none is available
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }
    
    // ========================================================================
    // Public API - Heartbeat (Static)
    // ========================================================================
    
    /**
     * Sends a heartbeat for the current persistent overlay.
     * 
     * <p><b>CRITICAL:</b> Long-running operations MUST call this method every
     * 5 seconds to prevent the toast from being considered stuck.</p>
     *
     * @param operationId The operation ID to match (can be null for any operation)
     * @return True if the heartbeat was accepted, false if the operation ID didn't match
     */
    public static boolean heartbeat(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        
        if (operationId != null && toastManager.mCurrentOperationId != null && 
            !toastManager.mCurrentOperationId.equals(operationId)) {
            return false;
        }
        
        return toastManager.handleEvent(Event.HEARTBEAT);
    }
    
    // ========================================================================
    // Public API - Temporary Toasts (Static)
    // ========================================================================
    
    /**
     * Shows a temporary toast message with the specified duration.
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     * @param duration The duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }
        
        // Cancel any previous hide runnable
        toastManager.cancelHideRunnable();
        
        // Hide existing toast
        toastManager.hideInternal(false);
        
        // Show new temporary toast
        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
            
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show toast");
                return;
            }
            
            toastManager.createOverlayInView(root, message);
            
            // Schedule auto-hide
            toastManager.mHideRunnable = new Runnable() {
                @Override
                public void run() {
                    if (toastManager.mCurrentState.get() == State.SHOWING_TEMPORARY) {
                        toastManager.hideInternal(true);
                    }
                    toastManager.mHideRunnable = null;
                }
            };
            toastManager.mMainHandler.postDelayed(toastManager.mHideRunnable, duration);
            
            Log.d(TAG, "Temporary toast shown: " + message + " (duration: " + duration + "ms)");
        }
    }
    
    /**
     * Shows a temporary toast message with LONG duration (2000ms).
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }
    
    /**
     * Shows a temporary toast within a specific view container (e.g., a dialog).
     *
     * @param rootView The root view to attach the toast to
     * @param message The message to display
     * @param duration The duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();
        
        toastManager.cancelHideRunnable();
        toastManager.hideInternal(false);
        
        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
            
            toastManager.createOverlayInView(rootView, message);
            
            toastManager.mHideRunnable = new Runnable() {
                @Override
                public void run() {
                    if (toastManager.mCurrentState.get() == State.SHOWING_TEMPORARY) {
                        toastManager.hideInternal(true);
                    }
                    toastManager.mHideRunnable = null;
                }
            };
            toastManager.mMainHandler.postDelayed(toastManager.mHideRunnable, duration);
            
            Log.d(TAG, "Temporary toast shown in view: " + message);
        }
    }
    
    /**
     * Cancels the current hide runnable.
     */
    private void cancelHideRunnable() {
        if (mHideRunnable != null) {
            mMainHandler.removeCallbacks(mHideRunnable);
            mHideRunnable = null;
        }
    }
    
    // ========================================================================
    // Public API - Persistent Overlay (Static)
    // ========================================================================
    
    /**
     * Shows a persistent overlay message that stays until explicitly hidden.
     * 
     * <p><b>IMPORTANT:</b> Long-running operations MUST call heartbeat()
     * every 5 seconds to prevent the toast from being considered stuck.</p>
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }
    
    /**
     * Shows a persistent overlay message with an operation ID for matching.
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     * @param operationId Unique identifier for this operation (can be null)
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message, @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }
        
        toastManager.cancelHideRunnable();
        toastManager.hideInternal(false);
        
        if (toastManager.handleEvent(Event.SHOW_PERSISTENT)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = operationId;
            toastManager.mStateStartTime.set(SystemClock.elapsedRealtime());
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
            
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show persistent overlay");
                return;
            }
            
            toastManager.createOverlayInView(root, message);
            toastManager.mCurrentActivityRef = new WeakReference<>(activity);
            
            Log.d(TAG, "Persistent overlay shown: " + message + (operationId != null ? " (ID: " + operationId + ")" : ""));
        }
    }
    
    /**
     * Updates the text of the persistent overlay without recreating the view.
     * 
     * <p>This also resets the inactivity timer, keeping the toast alive.</p>
     *
     * @param message The new message to display
     */
    public static void updatePersistentOverlay(@NonNull String message) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        
        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            Log.w(TAG, "Cannot update persistent overlay - no overlay is showing");
            return;
        }
        
        if (toastManager.handleEvent(Event.UPDATE)) {
            toastManager.mCurrentMessage = message;
            
            toastManager.mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    TextView textView = toastManager.getTextView();
                    if (textView != null) {
                        textView.setText(message);
                        Log.v(TAG, "Persistent overlay updated: " + message);
                    }
                }
            });
        }
    }
    
    /**
     * Hides the persistent overlay if the operation ID matches.
     *
     * @param operationId The operation ID that should match the current overlay
     * @return True if the overlay was hidden, false if ID mismatch or no overlay
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        
        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            return false;
        }
        
        if (operationId != null && toastManager.mCurrentOperationId != null && 
            !toastManager.mCurrentOperationId.equals(operationId)) {
            Log.d(TAG, "Hide rejected - operation ID mismatch: expected " + 
                  toastManager.mCurrentOperationId + ", got " + operationId);
            return false;
        }
        
        if (toastManager.handleEvent(Event.HIDE)) {
            toastManager.hideInternal(true);
            Log.d(TAG, "Persistent overlay hidden" + (operationId != null ? " (ID: " + operationId + ")" : ""));
            return true;
        }
        return false;
    }
    
    /**
     * Hides the persistent overlay regardless of operation ID.
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        
        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            return;
        }
        
        Log.w(TAG, "Force hiding persistent overlay");
        toastManager.handleEvent(Event.FORCE_HIDE);
        toastManager.hideInternal(true);
    }
    
    /**
     * Checks if a persistent overlay is currently showing.
     *
     * @return True if a persistent overlay is visible
     */
    public static boolean hasPersistentToast() {
        ToastManager toastManager = getInstance();
        return toastManager.mCurrentState.get() == State.SHOWING_PERSISTENT;
    }
    
    /**
     * Gets the current persistent toast text.
     *
     * @return The current message text, or null if no persistent overlay exists
     */
    @Nullable
    public static String getPersistentToastText() {
        ToastManager toastManager = getInstance();
        return toastManager.mCurrentMessage;
    }
    
    /**
     * Gets the current operation ID for the persistent overlay.
     *
     * @return The operation ID, or null if none
     */
    @Nullable
    public static String getCurrentOperationId() {
        ToastManager toastManager = getInstance();
        return toastManager.mCurrentOperationId;
    }
    
    // ========================================================================
    // Reattach Methods
    // ========================================================================
    
    /**
     * Reattaches the persistent toast to a new activity.
     *
     * @param activity The activity to attach the toast to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        
        if (currentState != State.SHOWING_TEMPORARY && currentState != State.SHOWING_PERSISTENT) {
            return;
        }
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    Log.w(TAG, "Cannot reattach to finishing/destroyed activity");
                    return;
                }
                
                ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
                if (root == null) {
                    Log.w(TAG, "Content view not found for reattachment");
                    return;
                }
                
                toastManager.handleEvent(Event.REATTACH);
                toastManager.reattachToActivity(activity);
            }
        });
    }
    
    /**
     * Ensures the persistent overlay is attached to the current window.
     *
     * @param activity The current activity
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        if (toastManager.mOverlayRef == null || toastManager.mOverlayRef.get() == null) {
            return;
        }
        
        FrameLayout overlay = toastManager.mOverlayRef.get();
        if (overlay != null && overlay.getParent() == null) {
            reattachToCurrentActivity(activity);
        }
    }
    
    // ========================================================================
    // State Listeners
    // ========================================================================
    
    /**
     * Adds a toast state listener.
     *
     * @param listener The listener to add
     */
    public static void addStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        
        // Immediately notify current state
        State currentState = toastManager.mCurrentState.get();
        listener.onStateChanged(currentState, currentState);
    }
    
    /**
     * Removes a toast state listener.
     *
     * @param listener The listener to remove
     */
    public static void removeStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.remove(listener);
    }
    
    // ========================================================================
    // View Management (Internal)
    // ========================================================================
    
    /**
     * Creates the overlay view and attaches it to the specified root view.
     *
     * @param rootView The parent view to attach the overlay to
     * @param message The message to display
     */
    private void createOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP);
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);
        
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        
        textView.setTextColor(getThemeColor());
        
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), TOAST_STROKE_COLOR);
        textView.setBackground(background);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        mOverlayRef = new WeakReference<>(container);
        mTextViewRef = new WeakReference<>(textView);
        
        if (rootView.getContext() instanceof Activity) {
            mCurrentActivityRef = new WeakReference<>((Activity) rootView.getContext());
        }
        
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }
    
    /**
     * Reattaches the existing overlay to a new activity.
     *
     * @param activity The activity to reattach to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        
        FrameLayout overlay = getOverlay();
        if (overlay == null) {
            mCurrentState.set(State.HIDDEN);
            return;
        }
        
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {}
        }
        
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            return;
        }
        
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.bottomMargin = dpToPx(activity, TOAST_BOTTOM_MARGIN_DP);
        overlay.setLayoutParams(params);
        overlay.setPadding(0, 0, 0, 0);
        
        root.addView(overlay);
        overlay.bringToFront();
        mCurrentActivityRef = new WeakReference<>(activity);
        
        // After reattach, transition back to appropriate showing state
        State currentState = mCurrentState.get();
        if (currentState == State.REATTACHING) {
            if (mIsPersistent()) {
                transitionTo(State.SHOWING_PERSISTENT);
            } else {
                transitionTo(State.SHOWING_TEMPORARY);
            }
        }
        
        Log.d(TAG, "Overlay reattached to new activity");
    }
    
    /**
     * Checks if the current toast is persistent.
     */
    private boolean mIsPersistent() {
        State currentState = mCurrentState.get();
        return currentState == State.SHOWING_PERSISTENT;
    }
    
    /**
     * Hides the current overlay.
     *
     * @param animate Whether to animate the fade-out
     */
    private void hideInternal(boolean animate) {
        final FrameLayout overlay = getOverlay();
        if (overlay == null) {
            mCurrentState.set(State.HIDDEN);
            mOverlayRef = null;
            mTextViewRef = null;
            mCurrentActivityRef = null;
            return;
        }
        
        if (animate) {
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(FADE_DURATION_MS);
            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {}
                
                @Override
                public void onAnimationEnd(Animation animation) {
                    removeOverlayView(overlay);
                    if (mCurrentState.get() == State.HIDING) {
                        transitionTo(State.HIDDEN);
                    }
                }
                
                @Override
                public void onAnimationRepeat(Animation animation) {}
            });
            overlay.startAnimation(fadeOut);
        } else {
            removeOverlayView(overlay);
            if (mCurrentState.get() == State.HIDING || mCurrentState.get() == State.REATTACHING) {
                transitionTo(State.HIDDEN);
            }
        }
        
        mCurrentOperationId = null;
        mCurrentMessage = null;
        mCurrentActivityRef = null;
        
        Log.d(TAG, "Overlay hidden" + (animate ? " with animation" : " immediately"));
    }
    
    /**
     * Forces immediate hide without animation.
     */
    private void forceHideInternal() {
        FrameLayout overlay = getOverlay();
        if (overlay != null) {
            removeOverlayView(overlay);
        }
        
        mCurrentState.set(State.HIDDEN);
        mCurrentOperationId = null;
        mCurrentMessage = null;
        mOverlayRef = null;
        mTextViewRef = null;
        mCurrentActivityRef = null;
        
        Log.d(TAG, "Overlay force-hidden");
    }
    
    /**
     * Removes the overlay view from its parent.
     *
     * @param overlay The overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {}
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Gets the current overlay container view from the WeakReference.
     *
     * @return The overlay FrameLayout, or null if the reference has been cleared
     */
    @Nullable
    private FrameLayout getOverlay() {
        return mOverlayRef != null ? mOverlayRef.get() : null;
    }
    
    /**
     * Gets the current text view from the WeakReference.
     *
     * @return The TextView, or null if the reference has been cleared
     */
    @Nullable
    private TextView getTextView() {
        return mTextViewRef != null ? mTextViewRef.get() : null;
    }
    
    /**
     * Converts density-independent pixels (dp) to absolute pixels (px).
     *
     * @param context The context for accessing display metrics
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
    
    // ========================================================================
    // Debug
    // ========================================================================
    
    /**
     * Returns debug information about the current state.
     *
     * @return Debug string
     */
    @NonNull
    public String getDebugInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("ToastManager Debug Info:\n");
        sb.append("  State: ").append(mCurrentState.get()).append("\n");
        sb.append("  State duration: ").append(SystemClock.elapsedRealtime() - mStateStartTime.get()).append("ms\n");
        sb.append("  Last activity: ").append(SystemClock.elapsedRealtime() - mLastActivityTime.get()).append("ms ago\n");
        sb.append("  Message: ").append(mCurrentMessage).append("\n");
        sb.append("  Operation ID: ").append(mCurrentOperationId).append("\n");
        sb.append("  Is recovering: ").append(mIsRecovering.get()).append("\n");
        sb.append("  State listeners: ").append(mStateListeners.size()).append("\n");
        return sb.toString();
    }
    
    // ========================================================================
    // Cleanup
    // ========================================================================
    
    /**
     * Shuts down the ToastManager and releases all resources.
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");
        
        toastManager.cancelHideRunnable();
        toastManager.cancelRecovery();
        
        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }
        
        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {}
        }
        
        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {}
        }
        
        toastManager.forceHideInternal();
        sInstance = null;
        sApplication = null;
        
        Log.d(TAG, "ToastManager shut down complete");
    }
}