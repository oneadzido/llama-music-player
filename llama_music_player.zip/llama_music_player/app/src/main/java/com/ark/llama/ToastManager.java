package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Custom toast notification manager with theme support and watchdog protection.
 * 
 * <p>This class provides a custom toast implementation using styled overlays
 * instead of system Toasts, with theme color integration and fade animations.
 * Includes a watchdog timer to automatically clear stale persistent overlays.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Custom‑styled overlays matching app theme</li>
 *   <li>Persistent overlay support with operation ID tracking</li>
 *   <li>Watchdog protection: automatic timeout after 30s (or 45s heartbeat) and 2min absolute</li>
 *   <li>Activity reattachment after configuration change (with LayoutParams reset fix)</li>
 *   <li>Theme colour integration and live updates</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class ToastManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Short duration: 500 milliseconds */
    public static final int LENGTH_SHORT = 500;
    
    /** Normal duration: 1000 milliseconds */
    public static final int LENGTH_NORMAL = 1000;
    
    /** Long duration: 2000 milliseconds */
    public static final int LENGTH_LONG = 2000;
    
    /** Duration for fade in/out animations (milliseconds) */
    private static final int FADE_DURATION_MS = 150;
    
    /** Maximum toast width in density-independent pixels */
    private static final int MAX_TOAST_WIDTH_DP = 320;
    
    /** Horizontal padding for toast content (dp) */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;
    
    /** Vertical padding for toast content (dp) */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;
    
    /** Bottom margin from screen edge (dp) */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;
    
    /** Corner radius for toast background (dp) */
    private static final int TOAST_CORNER_RADIUS_DP = 5;
    
    /** Stroke width for toast border (dp) */
    private static final int TOAST_STROKE_WIDTH_DP = 1;
    
    /** Elevation for toast on Lollipop+ (dp) */
    private static final int TOAST_ELEVATION_DP = 6;
    
    /** Default toast background color (dark gray) */
    private static final String TOAST_BACKGROUND_COLOR = "#1A1A1A";
    
    /** Default toast stroke color (slightly lighter gray) */
    private static final String TOAST_STROKE_COLOR = "#1E1E1E";
    
    /** Default theme color when ThemeManager is unavailable (gold/amber) */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    
    /** Broadcast action for theme color change notifications */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    /** Watchdog timeout in milliseconds (30 seconds) */
    private static final long WATCHDOG_TIMEOUT_MS = 30000;
    
    /** Absolute maximum duration for any persistent overlay (2 minutes) */
    private static final long MAX_PERSISTENT_DURATION_MS = 120000;
    
    /** Heartbeat timeout - if no heartbeat received within this time, consider stale (45 seconds) */
    private static final long HEARTBEAT_TIMEOUT_MS = 45000;
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    /** Main thread handler for delayed operations. */
    private static final Handler sHandler = new Handler(Looper.getMainLooper());
    
    /** Reference to the current persistent overlay view. */
    @Nullable private static View sPersistentOverlay = null;
    
    /** Reference to the text view inside the persistent overlay. */
    @Nullable private static TextView sPersistentTextView = null;
    
    /** Runnable for auto-hiding temporary toasts. */
    @Nullable private static Runnable sHideRunnable = null;
    
    /** Broadcast receiver for theme color change events. */
    @Nullable private static BroadcastReceiver sThemeReceiver = null;
    
    /** Flag indicating whether the theme receiver is registered. */
    private static boolean sReceiverRegistered = false;
    
    /** Application context reference. */
    @Nullable private static Context sAppContext = null;
    
    /** Flag indicating if the current toast is persistent. */
    private static boolean sIsPersistentToast = false;
    
    /** Runnable for watchdog timer. */
    @Nullable private static Runnable sWatchdogRunnable = null;
    
    /** Flag indicating if watchdog is active. */
    private static boolean sWatchdogActive = false;
    
    /** Lock object for watchdog operations. */
    private static final Object sWatchdogLock = new Object();
    
    /** Timestamp of last heartbeat for watchdog. */
    private static long sLastHeartbeatTime = 0;
    
    /** Timestamp when overlay was created. */
    private static long sOverlayStartTime = 0;
    
    /** Current operation ID for persistent overlay (used for matching hide calls). */
    @Nullable private static String sCurrentOperationId = null;
    
    /** Map of operation start times for debugging. */
    private static final ConcurrentHashMap<String, Long> sOperationStartTimes = new ConcurrentHashMap<>();
    
    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the ToastManager with application context.
     * 
     * <p>This method should be called early in the application lifecycle,
     * typically in the Application class onCreate() method. If not called
     * explicitly, it will be called automatically when showing the first toast.</p>
     *
     * @param context Application context (will be converted to application context)
     */
    public static void init(@NonNull Context context) {
        sAppContext = context.getApplicationContext();
        registerGlobalThemeReceiver();
    }
    
    /**
     * Registers a global broadcast receiver to listen for theme color changes.
     * The receiver updates the active toast's text color when the theme changes.
     */
    private static void registerGlobalThemeReceiver() {
        if (sReceiverRegistered || sAppContext == null) return;
        
        sThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        
        try {
            sAppContext.registerReceiver(sThemeReceiver, new IntentFilter(ACTION_THEME_COLOR_CHANGED));
            sReceiverRegistered = true;
        } catch (Exception e) {
            Log.e("ToastManager", "Failed to register theme receiver", e);
        }
    }
    
    // ========================================================================
    // Watchdog Methods
    // ========================================================================
    
    /**
     * Starts the watchdog timer for the persistent overlay.
     * The watchdog will automatically hide the overlay if it exceeds the maximum duration
     * or if no heartbeat is received within the heartbeat timeout.
     */
    private static void startWatchdog() {
        synchronized (sWatchdogLock) {
            cancelWatchdogLocked();
            final long start = SystemClock.elapsedRealtime();
            sOverlayStartTime = start;
            sLastHeartbeatTime = start;
            sWatchdogRunnable = new Runnable() {
                @Override
                public void run() {
                    synchronized (sWatchdogLock) {
                        if (!sIsPersistentToast || sPersistentOverlay == null) {
                            sWatchdogActive = false;
                            return;
                        }
                        long now = SystemClock.elapsedRealtime();
                        long age = now - start;
                        long sinceHeartbeat = now - sLastHeartbeatTime;
                        
                        // Check absolute timeout
                        if (age > MAX_PERSISTENT_DURATION_MS || sinceHeartbeat > HEARTBEAT_TIMEOUT_MS) {
                            Log.w("ToastManager", "Watchdog forcing hide (age=" + age + 
                                  ", heartbeat=" + sinceHeartbeat + ")");
                            forceHidePersistentOverlayLocked();
                            return;
                        }
                        
                        // Reschedule if still within limits
                        if (age > WATCHDOG_TIMEOUT_MS) {
                            Log.d("ToastManager", "Watchdog rescheduling");
                        }
                        sHandler.postDelayed(this, WATCHDOG_TIMEOUT_MS);
                    }
                }
            };
            sWatchdogActive = true;
            sHandler.postDelayed(sWatchdogRunnable, WATCHDOG_TIMEOUT_MS);
        }
    }
    
    /**
     * Cancels the watchdog timer (must be called with lock held).
     */
    private static void cancelWatchdogLocked() {
        if (sWatchdogRunnable != null) {
            sHandler.removeCallbacks(sWatchdogRunnable);
            sWatchdogRunnable = null;
        }
        sWatchdogActive = false;
    }
    
    /**
     * Resets the watchdog timer, extending the overlay's lifetime.
     * Called when the overlay is updated or reattached.
     */
    private static void resetWatchdog() {
        synchronized (sWatchdogLock) {
            if (sIsPersistentToast && sPersistentOverlay != null) {
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
                cancelWatchdogLocked();
                startWatchdog();
            }
        }
    }
    
    /**
     * Sends a heartbeat for the current persistent overlay, resetting the watchdog timer.
     * Call this periodically during long-running operations to prevent premature timeout.
     */
    public static void heartbeat() {
        synchronized (sWatchdogLock) {
            if (sIsPersistentToast && sPersistentOverlay != null) {
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
            }
        }
    }
    
    /**
     * Forces immediate hiding of the persistent overlay (must be called with lock held).
     */
    private static void forceHidePersistentOverlayLocked() {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {}
        }
        sPersistentOverlay = null;
        sPersistentTextView = null;
        sIsPersistentToast = false;
        sWatchdogActive = false;
        if (sWatchdogRunnable != null) {
            sHandler.removeCallbacks(sWatchdogRunnable);
            sWatchdogRunnable = null;
        }
    }
    
    // ========================================================================
    // Public API – Temporary Toasts
    // ========================================================================
    
    /**
     * Shows a temporary toast message with the specified duration.
     * The toast will auto-hide after the duration expires.
     *
     * @param activity The activity to show the toast in (must be non-null and active)
     * @param message The message to display
     * @param duration The duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToast(@Nullable Activity activity, @NonNull String message, int duration) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        if (sAppContext == null) init(activity);
        ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root != null) showToastInView(root, message, duration);
    }
    
    /**
     * Shows a temporary toast message with LONG duration (2000ms).
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }
    
    // ========================================================================
    // Public API – Persistent Overlay
    // ========================================================================
    
    /**
     * Shows a persistent overlay message that stays until explicitly hidden.
     * No auto-hide timer is set. Useful for long-running operations like
     * file syncing, loading indicators, or progress notifications.
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }
    
    /**
     * Shows a persistent overlay message with an operation ID for matching hide calls.
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     * @param operationId Unique identifier for this operation (used to prevent mismatched hides)
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message, @Nullable String operationId) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (sAppContext == null) init(activity);
        synchronized (sWatchdogLock) {
            if (operationId != null && operationId.equals(sCurrentOperationId)) cancelWatchdogLocked();
            if (sCurrentOperationId != null) sOperationStartTimes.remove(sCurrentOperationId);
            sCurrentOperationId = operationId;
            if (operationId != null) sOperationStartTimes.put(operationId, SystemClock.elapsedRealtime());
            sIsPersistentToast = true;
            hidePersistentOverlayInternalLocked(false);
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root != null) createPersistentOverlayInView(root, message);
            startWatchdog();
        }
    }
    
    /**
     * Shows a persistent overlay message in a specific view container.
     * No auto-hide timer is set. Useful for showing toasts within dialogs
     * or custom view hierarchies.
     *
     * @param rootView The root view to attach the overlay to (must be a ViewGroup)
     * @param message The message to display
     */
    public static void showPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        if (sAppContext == null) sAppContext = rootView.getContext().getApplicationContext();
        synchronized (sWatchdogLock) {
            cancelWatchdogLocked();
            sIsPersistentToast = true;
            createPersistentOverlayInView(rootView, message);
            startWatchdog();
        }
    }
    
    /**
     * Creates the persistent overlay view and attaches it to the rootView.
     * This method handles view creation, styling, and fade-in animation.
     *
     * @param rootView The parent view to attach the overlay to
     * @param message The message to display
     */
    private static void createPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        // Remove existing overlay if present
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {}
        }
        
        // Create container frame
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        // Create text view with ToastManager styling
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        // Set theme color using ColorStateList to override theme defaults
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(rootView.getContext());
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        // Apply background
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), 
            Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(background);
        
        // Add elevation for Android Lollipop and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        // Store references for theme updates
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        // Fade in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        
        // Record start time for watchdog
        sLastHeartbeatTime = SystemClock.elapsedRealtime();
        sOverlayStartTime = sLastHeartbeatTime;
    }
    
    // ========================================================================
    // Reattachment Methods
    // ========================================================================
    
    /**
     * Reattaches the persistent toast to a new activity.
     * Call this in onRestart() or onResume() of activities when a persistent
     * toast should persist across activity transitions.
     * 
     * <p><b>Important:</b> This method now resets layout parameters to avoid
     * constraint issues when moving between different parent views. It also
     * retries if the content view is not yet ready.</p>
     *
     * @param activity The activity to attach the toast to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        if (!sIsPersistentToast || sPersistentTextView == null || sPersistentOverlay == null) return;
        if (activity.isFinishing() || activity.isDestroyed()) return;
        resetWatchdog();
        
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Detach from any previous parent
                if (sPersistentOverlay.getParent() != null) {
                    try {
                        ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
                    } catch (Exception ignored) {}
                }
                
                ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
                if (root == null) {
                    // Content not ready, retry after short delay
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!activity.isFinishing() && !activity.isDestroyed()) {
                                reattachToCurrentActivity(activity);
                            }
                        }
                    }, 100);
                    return;
                }
                
                // Reset layout params to avoid constraint issues from previous parent
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                params.bottomMargin = dpToPx(activity, TOAST_BOTTOM_MARGIN_DP);
                sPersistentOverlay.setLayoutParams(params);
                
                root.addView(sPersistentOverlay);
                sPersistentOverlay.setVisibility(View.VISIBLE);
                if (sPersistentTextView != null) {
                    sPersistentTextView.setVisibility(View.VISIBLE);
                    refreshThemeColor();
                }
                
                // Bring to front to ensure visibility
                sPersistentOverlay.bringToFront();
            }
        });
    }
    
    /**
     * Ensures the persistent overlay is attached to the current window.
     * Call this in onRestart() to reattach if needed after configuration changes.
     *
     * @param activity The current activity
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        if (sPersistentOverlay == null) return;
        boolean attached = false;
        View parent = (View) sPersistentOverlay.getParent();
        while (parent != null) {
            if (parent.isAttachedToWindow()) { attached = true; break; }
            parent = (View) parent.getParent();
        }
        if (!attached && sPersistentTextView != null) {
            String msg = sPersistentTextView.getText().toString();
            sPersistentOverlay = null;
            sPersistentTextView = null;
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root != null) showPersistentOverlayInView(root, msg);
        }
    }
    
    // ========================================================================
    // Update and Hide Methods
    // ========================================================================
    
    /**
     * Updates the text of the persistent overlay without recreating the view.
     * Also refreshes the theme color to ensure consistency.
     *
     * @param message The new message to display
     */
    public static void updatePersistentOverlay(@NonNull String message) {
        synchronized (sWatchdogLock) {
            if (sPersistentTextView != null) {
                sPersistentTextView.setText(message);
                refreshThemeColorLocked();
                sLastHeartbeatTime = SystemClock.elapsedRealtime();
                resetWatchdog();
            }
        }
    }
    
    /**
     * Hides the persistent overlay immediately with fade-out animation.
     * After hiding, the toast state is reset and can be shown again.
     */
    public static void hidePersistentOverlay() {
        hidePersistentOverlay(null);
    }
    
    /**
     * Hides the persistent overlay if the operation ID matches.
     *
     * @param operationId The operation ID that should match the current overlay
     * @return True if the overlay was hidden, false if ID mismatch
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        synchronized (sWatchdogLock) {
            if (operationId != null && sCurrentOperationId != null && !sCurrentOperationId.equals(operationId)) {
                return false;
            }
            sIsPersistentToast = false;
            if (sCurrentOperationId != null) sOperationStartTimes.remove(sCurrentOperationId);
            sCurrentOperationId = null;
            cancelWatchdogLocked();
            hidePersistentOverlayInternalLocked(true);
            return true;
        }
    }
    
    /**
     * Forces immediate hiding of the persistent overlay without animation.
     */
    public static void forceHidePersistentOverlay() {
        synchronized (sWatchdogLock) {
            forceHidePersistentOverlayLocked();
        }
    }
    
    /**
     * Checks if a persistent toast is currently active and visible.
     *
     * @return true if a persistent toast exists, false otherwise
     */
    public static boolean hasPersistentToast() {
        return sIsPersistentToast && sPersistentTextView != null;
    }
    
    /**
     * Gets the current persistent toast text.
     *
     * @return The current message text, or null if no persistent toast exists
     */
    @Nullable
    public static String getPersistentToastText() {
        return (sPersistentTextView != null && sIsPersistentToast) ? sPersistentTextView.getText().toString() : null;
    }
    
    /**
     * Gets the current operation ID for the persistent overlay.
     *
     * @return The operation ID, or null if none
     */
    @Nullable
    public static String getCurrentOperationId() {
        return sCurrentOperationId;
    }
    
    // ========================================================================
    // View-Based Toast Method (For Dialogs, etc.)
    // ========================================================================
    
    /**
     * Shows a themed toast within a specific view container (e.g., a dialog).
     * This toast auto-hides after the specified duration.
     *
     * @param rootView The root view to attach the toast to (must be a ViewGroup)
     * @param message The message to display
     * @param durationMs Duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int durationMs) {
        // Mark as non-persistent
        synchronized (sWatchdogLock) {
            sIsPersistentToast = false;
            cancelWatchdogLocked();
        }
        
        if (sAppContext == null) sAppContext = rootView.getContext().getApplicationContext();
        
        // Remove existing toast if any in this view
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {}
        }
        
        // Create container frame
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        // Create text view with ToastManager styling
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        // Set theme color using ColorStateList to override theme defaults
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(rootView.getContext());
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        // Apply background
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), 
            Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(background);
        
        // Add elevation for Android Lollipop and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        // Store references for theme updates (though this is temporary, we still store)
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        // Fade in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        
        // Auto hide after duration
        sHandler.removeCallbacks(sHideRunnable);
        sHideRunnable = () -> hidePersistentOverlayInternal(false);
        sHandler.postDelayed(sHideRunnable, durationMs);
    }
    
    // ========================================================================
    // Theme Management Methods
    // ========================================================================
    
    /**
     * Refreshes the theme color of the active toast overlay.
     * Called automatically when the theme color changes via broadcast.
     * Also available for manual refresh if needed.
     */
    public static void refreshThemeColor() {
        synchronized (sWatchdogLock) {
            refreshThemeColorLocked();
        }
    }
    
    /**
     * Refreshes the theme color (must be called with lock held).
     */
    private static void refreshThemeColorLocked() {
        if (sPersistentTextView != null && sAppContext != null) {
            try {
                int color = ThemeManager.getInstance(sAppContext).getCurrentColorInt();
                sPersistentTextView.setTextColor(ColorStateList.valueOf(color));
            } catch (Exception ignored) {}
        }
    }
    
    // ========================================================================
    // Internal Helper Methods
    // ========================================================================
    
    /**
     * Hides the persistent overlay with fade-out animation.
     *
     * @param removeCallbacks Whether to remove the hide runnable from the handler
     */
    private static void hidePersistentOverlayInternal(boolean removeCallbacks) {
        synchronized (sWatchdogLock) {
            hidePersistentOverlayInternalLocked(removeCallbacks);
        }
    }
    
    /**
     * Internal method to hide the persistent overlay (must be called with lock held).
     *
     * @param removeCallbacks Whether to remove the hide runnable from the handler
     */
    private static void hidePersistentOverlayInternalLocked(boolean removeCallbacks) {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            final View overlay = sPersistentOverlay;
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(FADE_DURATION_MS);
            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override public void onAnimationStart(Animation a) {}
                @Override public void onAnimationEnd(Animation a) {
                    if (overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
                }
                @Override public void onAnimationRepeat(Animation a) {}
            });
            overlay.startAnimation(fadeOut);
        }
        sPersistentOverlay = null;
        sPersistentTextView = null;
        if (removeCallbacks && sHideRunnable != null) {
            sHandler.removeCallbacks(sHideRunnable);
            sHideRunnable = null;
        }
    }
    
    /**
     * Converts density-independent pixels (dp) to absolute pixels (px).
     *
     * @param context The context for accessing display metrics
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private static int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }
}