package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Owns every in-activity toast and persistent overlay the app shows,
 * and drives their lifecycle through a state machine.
 *
 * <p>Each activity maintains its own overlay view instance, tracked in
 * {@link #mOverlayMap}. An activity's overlay is removed only when the
 * activity is destroyed, so a stopped activity keeps its overlay
 * attached until the activity actually goes away. A periodic health
 * check treats a persistent overlay whose owner has stopped
 * heartbeating, or an overlay whose view has been detached from its
 * parent, as stuck and runs a recovery pass.</p>
 *
 * <p>Every persistent overlay is mirrored to the status bar through
 * {@link NotificationController}. The mirror uses the same operation ID
 * as the overlay, so a hide or update that arrives after another
 * operation has taken over the overlay is refused. Temporary toasts
 * are not mirrored. Recovery from a stuck overlay tears the mirror
 * down unconditionally.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns the current state of the state machine, the
 * per-activity overlay map, the current message and operation ID, and
 * the weak reference to the currently resumed activity. The
 * notification mirror is owned by {@link NotificationController}, which
 * uses the operation ID as an ownership token.</p>
 *
 * <h3>Ordering</h3>
 * <p>At most one toast is showing at any time. Showing a new toast
 * immediately hides the currently visible one, whether it is temporary
 * or persistent.</p>
 *
 * <p>A persistent overlay is active in two states:
 * {@link State#SHOWING_PERSISTENT} (resting, with the view installed in
 * the current activity's window) and {@link State#REATTACHING} (a fresh
 * view is being installed in a new activity's window). Public API
 * methods treat both states identically, so navigation between
 * activities does not strand the overlay.</p>
 *
 * <p>Temporary toasts auto-dismiss after their duration. They are not
 * reattached on activity lifecycle events.</p>
 *
 * <p>The "no valid overlay" branch of the health check is only
 * considered a fault once the map has been empty for longer than
 * {@link #STUCK_TIMEOUT_MS}. This tolerates the transient windows in
 * which the map legitimately has no valid holder.</p>
 *
 * <p>{@link #mCurrentActivityRef} answers one question: which activity
 * is currently resumed. It is a lifecycle property, not a visibility
 * property. It is set in {@link #onActivityResumed(Activity)} and
 * cleared in {@link #onActivityStopped(Activity)} and
 * {@link #onActivityDestroyed(Activity)}, and nowhere else. Hide paths
 * leave it untouched so a follow-up overlay show posted in the same
 * main-thread turn can still find the current activity.</p>
 *
 * <h3>Operation Ownership</h3>
 * <p>{@link #updatePersistentOverlay(String, String)} and
 * {@link #hidePersistentOverlay(String)} both take an operation ID and
 * refuse the call when the current overlay has a different owner. This
 * prevents a stale progress callback from a dead operation from
 * refreshing an overlay that a newer operation has taken over, or from
 * hiding an overlay it does not own.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The manager is a process-wide singleton initialised through
 * {@link #init(Context)}. It registers itself as an
 * {@link Application.ActivityLifecycleCallbacks} listener and a
 * receiver for theme color change broadcasts. The health check starts
 * with the instance and runs until {@link #shutdown()}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. State transitions and
 * view mutation run on {@link #mMainHandler}. The current state, the
 * activity flag, and the shutdown flag are atomic. The overlay map is a
 * {@link ConcurrentHashMap} and the listener lists are
 * {@link CopyOnWriteArrayList}s.</p>
 *
 * @see NotificationController
 * @see State
 * @see Event
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "ToastManager";

    /** Duration of a short toast, in milliseconds. */
    public static final int LENGTH_SHORT = 500;

    /** Duration of a normal toast, in milliseconds. */
    public static final int LENGTH_NORMAL = 1000;

    /** Duration of a long toast, in milliseconds. */
    public static final int LENGTH_LONG = 2000;

    /** Duration of the fade-in and fade-out animation, in milliseconds. */
    private static final int FADE_DURATION_MS = 150;

    /** Maximum width of a toast, in density-independent pixels. */
    private static final int MAX_TOAST_WIDTH_DP = 320;

    /** Horizontal padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;

    /** Distance from the bottom edge of the window, in density-independent pixels. */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;

    /** Corner radius of the toast background, in density-independent pixels. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;

    /** Stroke width of the toast border, in density-independent pixels. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;

    /** Elevation of the toast on API 21 and later, in density-independent pixels. */
    private static final int TOAST_ELEVATION_DP = 6;

    /** Background color of the toast. */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;

    /** Stroke color of the toast border. */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500;

    /** Inactivity timeout for persistent overlays, in milliseconds. */
    private static final long STUCK_TIMEOUT_MS = 1000;

    /** Maximum age for a temporary toast before it is considered stuck, in milliseconds. */
    private static final long TEMP_TOAST_MAX_MS = 2000;

    /** Delay before running recovery, in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500;

    // ========================================================================
    // State Machine
    // ========================================================================

    /**
     * States of the toast state machine.
     */
    public enum State {

        /** No toast is showing. */
        HIDDEN,

        /** A temporary toast is showing and will auto-dismiss after its duration. */
        SHOWING_TEMPORARY,

        /** A persistent overlay is showing and requires an explicit hide. */
        SHOWING_PERSISTENT,

        /** A toast is being hidden and the fade-out animation is running. */
        HIDING,

        /** A persistent overlay is being reattached to a new activity. */
        REATTACHING,

        /** A stuck toast has been detected and recovery is running. */
        STUCK
    }

    /**
     * Events that drive the state machine.
     */
    public enum Event {

        /** Show a temporary toast. */
        SHOW_TEMPORARY,

        /** Show a persistent overlay. */
        SHOW_PERSISTENT,

        /** Update the text of the current toast. */
        UPDATE,

        /** Record a heartbeat, resetting the stuck timer. */
        HEARTBEAT,

        /** Hide the current toast, respecting ownership. */
        HIDE,

        /** Hide the current toast, ignoring ownership. */
        FORCE_HIDE,

        /** Reattach the current persistent overlay to a new activity. */
        REATTACH,

        /** Mark the current toast as stuck. */
        STUCK_DETECTED,

        /** Complete recovery from a stuck state. */
        RECOVERED
    }

    /**
     * Returns whether the given state represents an active persistent
     * overlay.
     *
     * <p>{@link State#SHOWING_PERSISTENT} is the resting state.
     * {@link State#REATTACHING} is the transient state during which a
     * fresh view is being installed in a new activity's window. Both
     * are treated as active by every public API.</p>
     *
     * @param state State to test, or null
     * @return True when the state represents an active persistent overlay
     */
    private static boolean isPersistentActive(@Nullable State state) {
        return state == State.SHOWING_PERSISTENT || state == State.REATTACHING;
    }

    // ========================================================================
    // Listener Interfaces
    // ========================================================================

    /**
     * Receives toast state changes and stuck detection events.
     */
    public interface ToastStateListener {

        /**
         * Called when the toast state changes.
         *
         * @param oldState State before the transition
         * @param newState State after the transition
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);

        /**
         * Called when a stuck toast is detected and recovery is about to
         * run.
         *
         * @param reason Reason the toast was considered stuck
         * @param ageMs Duration the toast had been showing, in
         *        milliseconds
         * @param inactiveTimeMs Time since the last heartbeat or update,
         *        in milliseconds
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs,
                                  long inactiveTimeMs);
    }

    // ========================================================================
    // Per-Activity Overlay Tracking
    // ========================================================================

    /**
     * Holds the overlay views for a single activity.
     *
     * <p>All references are weak, so the holder does not prevent the
     * activity or its views from being collected.</p>
     */
    private static class OverlayHolder {

        /** Weak reference to the overlay container view. */
        final WeakReference<FrameLayout> overlayRef;

        /** Weak reference to the text view inside the overlay. */
        final WeakReference<TextView> textViewRef;

        /** Weak reference to the activity that owns the overlay. */
        final WeakReference<Activity> activityRef;

        /** Message the overlay was created with. */
        final String message;

        /** Operation ID the overlay was created with, or null. */
        final String operationId;

        /** True when the overlay is persistent; false when it is temporary. */
        final boolean isPersistent;

        /**
         * Constructs a holder for the given overlay.
         *
         * @param overlay Overlay container
         * @param textView Text view inside the overlay
         * @param activity Activity that owns the overlay
         * @param message Message the overlay was created with
         * @param operationId Operation ID the overlay was created with,
         *        or null
         * @param isPersistent True for a persistent overlay, false for a
         *        temporary toast
         */
        OverlayHolder(FrameLayout overlay, TextView textView, Activity activity,
                      String message, String operationId, boolean isPersistent) {
            this.overlayRef = new WeakReference<>(overlay);
            this.textViewRef = new WeakReference<>(textView);
            this.activityRef = new WeakReference<>(activity);
            this.message = message;
            this.operationId = operationId;
            this.isPersistent = isPersistent;
        }

        /**
         * Returns whether both the overlay and its text view are still
         * reachable.
         *
         * @return True when the overlay and text view can be used
         */
        boolean isValid() {
            return overlayRef.get() != null && textViewRef.get() != null;
        }

        /**
         * Detaches the overlay view from its parent when it is still
         * attached.
         */
        void cleanup() {
            FrameLayout overlay = overlayRef.get();
            if (overlay != null && overlay.getParent() != null) {
                try {
                    ((ViewGroup) overlay.getParent()).removeView(overlay);
                } catch (Exception ignored) {
                    // The view was already detached.
                }
            }
        }
    }

    /** Map of activity key to overlay holder. */
    private final ConcurrentHashMap<String, OverlayHolder> mOverlayMap =
        new ConcurrentHashMap<>();

    /** Activity key used for root-view-only toasts shown outside an activity. */
    private static final String KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY";

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;

    /** Application instance used for lifecycle callbacks and broadcasts. */
    @Nullable
    private static Application sApplication;

    /** Main-thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for the periodic health check. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // State Machine Variables
    // ========================================================================

    /** Current state of the state machine. */
    private final AtomicReference<State> mCurrentState =
        new AtomicReference<>(State.HIDDEN);

    /** Timestamp at which the current state began. */
    private final AtomicLong mStateStartTime = new AtomicLong(0);

    /** Timestamp of the last heartbeat or update. */
    private final AtomicLong mLastActivityTime = new AtomicLong(0);

    /**
     * Timestamp of the last health check that found a valid overlay.
     *
     * <p>The "no valid overlay" branch of the health check is only
     * considered a fault once this timestamp is older than
     * {@link #STUCK_TIMEOUT_MS}, so a transient window with no holder
     * does not trip recovery.</p>
     */
    private final AtomicLong mLastValidOverlayTime = new AtomicLong(0);

    /** True while recovery is running. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);

    /** Runnable for the periodic health check, or null when stopped. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Runnable for the current recovery, or null when none is pending. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock that serialises health checks. */
    private final Object mHealthLock = new Object();

    // ========================================================================
    // Auto-Dismiss Management
    // ========================================================================

    /** Runnable that auto-dismisses the current temporary toast, or null. */
    @Nullable
    private Runnable mAutoDismissRunnable = null;

    /** Duration of the current temporary toast, in milliseconds. */
    private long mTemporaryToastDuration = 0;

    /** True once the current temporary toast has been dismissed. */
    private final AtomicBoolean mTemporaryToastDismissed = new AtomicBoolean(false);

    // ========================================================================
    // Global Toast State
    // ========================================================================

    /** Message currently being displayed, or null when no toast is showing. */
    @Nullable
    private String mCurrentMessage = null;

    /** Operation ID of the current persistent overlay, or null. */
    @Nullable
    private String mCurrentOperationId = null;

    /**
     * Weak reference to the currently resumed activity.
     *
     * <p>Lifecycle property, not overlay-visibility property. Written
     * only by {@link #onActivityResumed(Activity)}; cleared only by
     * {@link #onActivityStopped(Activity)} and
     * {@link #onActivityDestroyed(Activity)} when the stopped or
     * destroyed activity is the one being tracked. Never touched by any
     * hide path.</p>
     */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;

    /** True once the lifecycle callbacks have been registered. */
    private boolean mCallbacksRegistered = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Receiver for theme color change broadcasts, or null. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;

    // ========================================================================
    // Listeners
    // ========================================================================

    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners =
        new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor and Initialization
    // ========================================================================

    /**
     * Constructs the singleton, registers lifecycle callbacks and the
     * theme receiver, and starts the health check.
     *
     * @param context A context; the application context is retained
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        mCurrentState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());
        Log.d(TAG, "ToastManager initialized (per-activity overlay management)");
    }

    /**
     * Initializes the singleton.
     *
     * <p>Calling this method more than once with the same process has no
     * effect.</p>
     *
     * @param context A context; the application context is retained
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance
     * @throws IllegalStateException When {@link #init(Context)} has not
     *         yet been called
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ========================================================================
    // State Machine Methods
    // ========================================================================

    /**
     * Transitions to the given state and notifies every registered
     * listener.
     *
     * <p>A transition to the current state does nothing.</p>
     *
     * @param newState State to transition to
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mCurrentState.getAndSet(newState);
        if (oldState == newState) {
            return;
        }
        Log.d(TAG, "State transition: " + oldState + " \u2192 " + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener", exception);
            }
        }
    }

    /**
     * Dispatches the given event through the state machine.
     *
     * @param event Event to dispatch
     * @return True when the event changed the state
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mCurrentState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);

        switch (event) {
            case SHOW_TEMPORARY:  return handleShowTemporary(currentState);
            case SHOW_PERSISTENT: return handleShowPersistent(currentState);
            case UPDATE:          return handleUpdate(currentState);
            case HEARTBEAT:       return handleHeartbeat(currentState);
            case HIDE:            return handleHide(currentState);
            case FORCE_HIDE:      return handleForceHide(currentState);
            case REATTACH:        return handleReattach(currentState);
            case STUCK_DETECTED:  return handleStuckDetected(currentState);
            case RECOVERED:       return handleRecovered(currentState);
            default:              return false;
        }
    }

    /**
     * Handles a {@link Event#SHOW_TEMPORARY} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleShowTemporary(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        forceHideInternal();
        transitionTo(State.SHOWING_TEMPORARY);
        return true;
    }

    /**
     * Handles a {@link Event#SHOW_PERSISTENT} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleShowPersistent(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING) {
            transitionTo(State.SHOWING_PERSISTENT);
            return true;
        }
        forceHideInternal();
        transitionTo(State.SHOWING_PERSISTENT);
        return true;
    }

    /**
     * Handles an {@link Event#UPDATE} event.
     *
     * @param currentState State before the event
     * @return True when the update was accepted
     */
    private boolean handleUpdate(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update toast in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#HEARTBEAT} event.
     *
     * @param currentState State before the event
     * @return True when the heartbeat was accepted
     */
    private boolean handleHeartbeat(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#HIDE} event.
     *
     * @param currentState State before the event
     * @return True when the hide was accepted
     */
    private boolean handleHide(State currentState) {
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true;
        }
        Log.w(TAG, "Cannot hide toast in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#FORCE_HIDE} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleForceHide(State currentState) {
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }

    /**
     * Handles a {@link Event#REATTACH} event.
     *
     * @param currentState State before the event
     * @return True when the reattach was accepted
     */
    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        if (currentState == State.REATTACHING) {
            // Already reattaching. A second activity resume during the
            // reattach window is not an error.
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#STUCK_DETECTED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleStuckDetected(State currentState) {
        if (isPersistentActive(currentState)
                || currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Toast stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#RECOVERED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }

    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================

    /**
     * Registers the lifecycle callbacks with the application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) {
            return;
        }
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    /**
     * Sets the current activity reference and, when a persistent overlay
     * is active, reattaches it to the newly resumed activity.
     *
     * <p>{@link State#REATTACHING} is treated as active, so a resume
     * that lands during an in-flight reattach completes the reattach in
     * the newly visible activity.</p>
     *
     * @param activity Activity that resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);
        State currentState = mCurrentState.get();
        if (isPersistentActive(currentState)) {
            handleEvent(Event.REATTACH);
            reattachToActivity(activity);
        } else if (currentState == State.SHOWING_TEMPORARY) {
            Log.d(TAG, "Temporary toast showing, not reattaching "
                + "(auto-dismiss will handle it)");
        }
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    /**
     * Clears the current activity reference when the stopped activity is
     * the one being tracked, and runs a health check.
     *
     * <p>The stopped activity's overlay holder is not removed. A stopped
     * activity's view hierarchy is still alive, its overlay is still
     * attached, and the holder's weak references are still valid.
     * Holder cleanup is deferred to
     * {@link #onActivityDestroyed(Activity)}, which is the point at
     * which the view hierarchy actually goes away.</p>
     *
     * @param activity Activity that stopped
     */
    @Override
    public void onActivityStopped(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    /**
     * Clears the current activity reference when the destroyed activity
     * is the one being tracked, removes its overlay holder, and runs a
     * health check.
     *
     * @param activity Activity that was destroyed
     */
    @Override
    public void onActivityDestroyed(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        String key = getActivityKey(activity);
        OverlayHolder holder = mOverlayMap.remove(key);
        if (holder != null) {
            holder.cleanup();
            Log.v(TAG, "Cleaned up overlay for destroyed activity: "
                + activity.getClass().getSimpleName());
        }
        performHealthCheck();
    }

    // ========================================================================
    // Theme Management
    // ========================================================================

    /**
     * Registers a receiver for theme color change broadcasts.
     */
    private void registerThemeReceiver() {
        if (sApplication == null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        sApplication.registerReceiver(
            mThemeReceiver, new IntentFilter(ACTION_THEME_COLOR_CHANGED));
    }

    /**
     * Reapplies the current theme color to every visible toast's text
     * view.
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        final int themeColor = toastManager.getThemeColor();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                State currentState = toastManager.mCurrentState.get();
                if (currentState != State.SHOWING_TEMPORARY
                        && !isPersistentActive(currentState)) {
                    return;
                }
                for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                    TextView textView = holder.textViewRef.get();
                    if (textView != null) {
                        textView.setTextColor(themeColor);
                    }
                }
            }
        });
    }

    /**
     * Returns the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) {
                return DEFAULT_THEME_COLOR;
            }
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null
                ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    // ========================================================================
    // Health Check
    // ========================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new HealthCheckRunnable(this);
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: "
            + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Health-check runnable that holds the manager through a weak
     * reference.
     */
    private static class HealthCheckRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run health checks against
         */
        HealthCheckRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Health check runnable: ToastManager was "
                    + "garbage collected, stopping");
                return;
            }
            manager.performHealthCheck();
            if (manager.mHealthCheckRunnable != null) {
                manager.mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
            }
        }
    }

    /**
     * Runs the health check.
     *
     * <p>Treats a persistent overlay with no valid holder as stuck only
     * once the map has been empty for longer than
     * {@link #STUCK_TIMEOUT_MS}. Treats a persistent overlay with no
     * heartbeat within {@link #STUCK_TIMEOUT_MS} as stuck. Treats a
     * temporary toast that has survived past {@link #TEMP_TOAST_MAX_MS}
     * as stuck when a temporary overlay is still present.</p>
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mCurrentState.get();
            if (currentState != State.SHOWING_TEMPORARY
                    && !isPersistentActive(currentState)) {
                return;
            }

            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();
            long inactiveTime = now - mLastActivityTime.get();

            boolean hasValidOverlay = false;
            for (OverlayHolder holder : mOverlayMap.values()) {
                if (holder.isValid()) {
                    hasValidOverlay = true;
                    mLastValidOverlayTime.set(now);
                    break;
                }
            }

            boolean isStuck = false;
            String stuckReason = null;

            if (!hasValidOverlay) {
                long noOverlayDuration = now - mLastValidOverlayTime.get();
                if (noOverlayDuration > STUCK_TIMEOUT_MS) {
                    isStuck = true;
                    stuckReason = "No valid overlay for " + noOverlayDuration
                        + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
                }
            } else if (isPersistentActive(currentState)
                    && inactiveTime > STUCK_TIMEOUT_MS) {
                isStuck = true;
                stuckReason = "No heartbeat for " + inactiveTime
                    + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
            } else if (currentState == State.SHOWING_TEMPORARY
                    && age > TEMP_TOAST_MAX_MS) {
                boolean hasTemporary = false;
                for (OverlayHolder holder : mOverlayMap.values()) {
                    if (!holder.isPersistent) {
                        hasTemporary = true;
                        break;
                    }
                }
                if (hasTemporary) {
                    isStuck = true;
                    stuckReason = "Temporary toast stuck (age: " + age + "ms)";
                }
            }

            if (isStuck) {
                Log.w(TAG, "STUCK TOAST DETECTED: " + stuckReason);

                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason, age, inactiveTime);
                    } catch (Exception exception) {
                        Log.e(TAG, "Error notifying stuck listener", exception);
                    }
                }

                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }

    /**
     * Starts the recovery pass from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        Log.d(TAG, "Starting toast recovery");
        cancelRecovery();

        mRecoveryRunnable = new RecoveryRunnable(this);
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Recovery runnable that holds the manager through a weak reference.
     */
    private static class RecoveryRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run recovery against
         */
        RecoveryRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Recovery runnable: ToastManager was garbage collected");
                return;
            }
            Log.d(TAG, "Toast recovery completed");
            manager.forceHideInternal();
            manager.handleEvent(Event.RECOVERED);
            manager.mIsRecovering.set(false);
            manager.mRecoveryRunnable = null;
        }
    }

    /**
     * Cancels the pending recovery. Idempotent.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================

    /**
     * Returns the activity that is currently resumed.
     *
     * <p>Returns whichever activity last reported
     * {@link #onActivityResumed(Activity)} and has not since reported
     * {@link #onActivityStopped(Activity)} or
     * {@link #onActivityDestroyed(Activity)}. The value is independent
     * of whether any toast is showing: hiding a toast leaves the
     * reference untouched.</p>
     *
     * @return The current activity, or null when none is tracked
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }

    // ========================================================================
    // Public API - Heartbeat
    // ========================================================================

    /**
     * Records a heartbeat for the current persistent overlay.
     *
     * <p>A heartbeat resets the stuck timer. When the given operation ID
     * is non-null and the current overlay has a different operation ID,
     * the heartbeat is refused so a component that does not own the
     * overlay cannot extend its lifetime.</p>
     *
     * @param operationId Operation ID to match, or null to accept any
     * @return True when the heartbeat was accepted
     */
    public static boolean heartbeat(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (operationId != null && toastManager.mCurrentOperationId != null
                && !toastManager.mCurrentOperationId.equals(operationId)) {
            return false;
        }
        return toastManager.handleEvent(Event.HEARTBEAT);
    }

    // ========================================================================
    // Public API - Temporary Toasts
    // ========================================================================

    /**
     * Shows a temporary toast in the given activity for the given
     * duration.
     *
     * <p>Any currently visible toast is hidden first. A toast is not
     * shown when the activity is finishing or already destroyed.</p>
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     * @param duration Duration in milliseconds, such as
     *        {@link #LENGTH_SHORT}, {@link #LENGTH_NORMAL}, or
     *        {@link #LENGTH_LONG}
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message,
                                 int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }

        toastManager.cancelAutoDismiss();
        toastManager.hideCurrentToast(false);

        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = duration;

        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            ViewGroup root = (ViewGroup) activity.getWindow()
                .getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show toast");
                return;
            }

            toastManager.createOverlayInView(activity, root, message, false);

            final AutoDismissRunnable dismissRunnable =
                new AutoDismissRunnable(toastManager, duration);
            toastManager.mAutoDismissRunnable = dismissRunnable;
            toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
            Log.d(TAG, "Temporary toast shown: " + message
                + " (duration: " + duration + "ms)");
        }
    }

    /**
     * Auto-dismiss runnable that holds the manager through a weak
     * reference.
     */
    private static class AutoDismissRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /** Duration the toast was shown for, in milliseconds. */
        private final long duration;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager that owns the toast
         * @param duration Duration the toast was shown for, in
         *        milliseconds
         */
        AutoDismissRunnable(ToastManager manager, long duration) {
            this.managerRef = new WeakReference<>(manager);
            this.duration = duration;
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                Log.d(TAG, "Auto-dismiss runnable: ToastManager was garbage collected");
                return;
            }
            State currentState = manager.mCurrentState.get();
            if (currentState == State.SHOWING_TEMPORARY
                    && !manager.mTemporaryToastDismissed.get()) {
                Log.d(TAG, "Auto-dismissing temporary toast after " + duration + "ms");
                manager.mTemporaryToastDismissed.set(true);
                manager.hideCurrentToast(true);
                manager.transitionTo(State.HIDDEN);
            }
            if (manager.mAutoDismissRunnable == this) {
                manager.mAutoDismissRunnable = null;
            }
        }
    }

    /**
     * Shows a temporary toast in the given activity for the long
     * duration.
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }

    /**
     * Shows a temporary toast inside the given view hierarchy.
     *
     * <p>Used when a toast needs to appear inside a dialog or another
     * surface that does not have an activity window of its own. Any
     * currently visible toast is hidden first.</p>
     *
     * @param rootView View group to attach the toast to
     * @param message Text to display
     * @param duration Duration in milliseconds, such as
     *        {@link #LENGTH_SHORT}, {@link #LENGTH_NORMAL}, or
     *        {@link #LENGTH_LONG}
     */
    public static void showToastInView(@NonNull ViewGroup rootView,
                                       @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();

        toastManager.cancelAutoDismiss();
        toastManager.hideCurrentToast(false);

        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = duration;

        if (toastManager.handleEvent(Event.SHOW_TEMPORARY)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = null;
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            toastManager.createOverlayInView(null, rootView, message, false);

            final AutoDismissRunnable dismissRunnable =
                new AutoDismissRunnable(toastManager, duration);
            toastManager.mAutoDismissRunnable = dismissRunnable;
            toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
            Log.d(TAG, "Temporary toast shown in view: " + message
                + " (duration: " + duration + "ms)");
        }
    }

    // ========================================================================
    // Public API - Persistent Overlay
    // ========================================================================

    /**
     * Shows a persistent overlay in the given activity with no operation
     * ID.
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message) {
        showPersistentOverlay(activity, message, null);
    }

    /**
     * Shows a persistent overlay in the given activity with the given
     * operation ID.
     *
     * <p>The overlay remains visible until a caller hides it by
     * matching ID or the health check recovers it. Every persistent
     * overlay is mirrored to the status bar through
     * {@link NotificationController}, and the operation ID is passed
     * through to the controller as an ownership token so a hide that
     * arrives after another operation has taken over the overlay is
     * refused.</p>
     *
     * <p>Any currently visible toast is hidden first. The overlay is
     * not shown when the activity is finishing or already destroyed.</p>
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message,
                                             @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }

        toastManager.cancelAutoDismiss();
        toastManager.hideCurrentToast(false);

        toastManager.mTemporaryToastDismissed.set(false);
        toastManager.mTemporaryToastDuration = 0;

        if (toastManager.handleEvent(Event.SHOW_PERSISTENT)) {
            toastManager.mCurrentMessage = message;
            toastManager.mCurrentOperationId = operationId;
            toastManager.mStateStartTime.set(SystemClock.elapsedRealtime());
            toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

            ViewGroup root = (ViewGroup) activity.getWindow()
                .getDecorView().findViewById(android.R.id.content);
            if (root == null) {
                Log.w(TAG, "Content view not found, cannot show persistent overlay");
                return;
            }

            toastManager.createOverlayInView(activity, root, message, true);
            toastManager.mCurrentActivityRef = new WeakReference<>(activity);

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .showLibraryStatus(message, operationId);
            }

            Log.d(TAG, "Persistent overlay shown: " + message
                + (operationId != null ? " (ID: " + operationId + ")" : ""));
        }
    }

    /**
     * Updates the text of the current persistent overlay when the given
     * operation ID matches the current owner.
     *
     * <p>A mismatched ID is refused, so a stale callback from a dead
     * operation cannot refresh an overlay that a newer operation has
     * taken over. In particular, the stuck timer is only reset by the
     * operation that currently owns the overlay.</p>
     *
     * @param message New text to display
     * @param operationId Operation ID that must match the current owner
     */
    public static void updatePersistentOverlay(@NonNull String message,
                                               @NonNull String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (currentState != State.SHOWING_TEMPORARY
                && !isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot update persistent overlay - no overlay is showing");
            return;
        }

        if (!operationId.equals(toastManager.mCurrentOperationId)) {
            Log.d(TAG, "Update rejected - operation ID mismatch: expected "
                + toastManager.mCurrentOperationId + ", got " + operationId);
            return;
        }

        if (toastManager.handleEvent(Event.UPDATE)) {
            toastManager.mCurrentMessage = message;
            toastManager.mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                        TextView textView = holder.textViewRef.get();
                        if (textView != null) {
                            textView.setText(message);
                        }
                    }
                    Log.v(TAG, "Persistent overlay updated: " + message);
                }
            });

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .updateLibraryStatus(message, operationId);
            }
        }
    }

    /**
     * Hides the current persistent overlay when the operation ID
     * matches.
     *
     * <p>Ownership-respecting hide. Refuses to hide an overlay whose
     * operation ID differs from the given ID, so a stale caller cannot
     * tear down an overlay that a newer operation has taken over.
     * Callers that own the overlay they are hiding should always pass
     * their operation ID.</p>
     *
     * @param operationId Operation ID that must match the current
     *        overlay's owner
     * @return True when the overlay was hidden
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (currentState != State.SHOWING_TEMPORARY
                && !isPersistentActive(currentState)) {
            return false;
        }

        if (operationId != null && toastManager.mCurrentOperationId != null
                && !toastManager.mCurrentOperationId.equals(operationId)) {
            Log.d(TAG, "Hide rejected - operation ID mismatch: expected "
                + toastManager.mCurrentOperationId + ", got " + operationId);
            return false;
        }

        if (toastManager.handleEvent(Event.HIDE)) {
            final String currentId = toastManager.mCurrentOperationId;
            toastManager.hideCurrentToast(true);

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }

            Log.d(TAG, "Persistent overlay hidden"
                + (operationId != null ? " (ID: " + operationId + ")" : ""));
            return true;
        }
        return false;
    }

    /**
     * Hides the current persistent overlay regardless of operation ID.
     *
     * <p>Force hide. Intended for recovery paths such as a stuck overlay
     * that no live operation still owns, or a full library wipe where
     * the operation that showed the overlay is no longer running.
     * Callers that own their overlay should use
     * {@link #hidePersistentOverlay(String)}.</p>
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            final String currentId = toastManager.mCurrentOperationId;
            toastManager.handleEvent(Event.FORCE_HIDE);
            toastManager.hideCurrentToast(true);

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        }
    }

    /**
     * Returns whether a persistent overlay is currently active.
     *
     * <p>{@link State#REATTACHING} counts as active, so callers that
     * gate on this to decide whether to re-request an overlay do not
     * fall through during an in-flight reattach.</p>
     *
     * @return True when a persistent overlay is active
     */
    public static boolean hasPersistentToast() {
        return isPersistentActive(getInstance().mCurrentState.get());
    }

    /**
     * Returns the text of the current persistent overlay.
     *
     * @return The current message, or null when no persistent overlay is
     *         showing
     */
    @Nullable
    public static String getPersistentToastText() {
        return getInstance().mCurrentMessage;
    }

    /**
     * Returns the operation ID of the current persistent overlay.
     *
     * @return The operation ID, or null when the overlay has no owner or
     *         no persistent overlay is showing
     */
    @Nullable
    public static String getCurrentOperationId() {
        return getInstance().mCurrentOperationId;
    }

    // ========================================================================
    // Reattach Methods
    // ========================================================================

    /**
     * Reattaches the current persistent overlay to the given activity.
     *
     * <p>When the state is not a persistent one, this method does
     * nothing. When the activity is finishing or destroyed, the reattach
     * is refused.</p>
     *
     * @param activity Activity to reattach the overlay to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();

        if (!isPersistentActive(currentState)) {
            Log.d(TAG, "Not reattaching - state is " + currentState);
            return;
        }

        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    return;
                }

                State currentStateCheck = toastManager.mCurrentState.get();
                if (currentStateCheck == State.HIDDEN
                        || currentStateCheck == State.HIDING) {
                    return;
                }

                toastManager.handleEvent(Event.REATTACH);
                toastManager.reattachToActivity(activity);
            }
        });
    }

    /**
     * Ensures the current persistent overlay is attached to the given
     * activity's window.
     *
     * <p>Reattaches only when the activity's holder is missing or its
     * views are no longer valid.</p>
     *
     * @param activity Activity the overlay should be attached to
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder holder = toastManager.mOverlayMap.get(key);
        if (holder == null || !holder.isValid()) {
            reattachToCurrentActivity(activity);
        }
    }

    // ========================================================================
    // State Listeners
    // ========================================================================

    /**
     * Adds a toast state listener.
     *
     * <p>The listener receives the current state immediately after
     * registration.</p>
     *
     * @param listener Listener to add
     */
    public static void addStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        State currentState = toastManager.mCurrentState.get();
        listener.onStateChanged(currentState, currentState);
    }

    /**
     * Removes a toast state listener.
     *
     * @param listener Listener to remove
     */
    public static void removeStateListener(@NonNull ToastStateListener listener) {
        getInstance().mStateListeners.remove(listener);
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns a unique key for the given activity.
     *
     * <p>Returns {@link #KEY_ROOT_VIEW_ONLY} when the activity is null,
     * so a root-view-only toast has its own slot in the overlay map.</p>
     *
     * @param activity Activity to build a key for, or null
     * @return The key
     */
    @NonNull
    private static String getActivityKey(@Nullable Activity activity) {
        if (activity == null) {
            return KEY_ROOT_VIEW_ONLY;
        }
        return activity.getClass().getName() + "@" + System.identityHashCode(activity);
    }

    /**
     * Cancels the pending auto-dismiss and clears its associated state.
     * Idempotent.
     */
    private void cancelAutoDismiss() {
        if (mAutoDismissRunnable != null) {
            mMainHandler.removeCallbacks(mAutoDismissRunnable);
            mAutoDismissRunnable = null;
        }
        mTemporaryToastDismissed.set(false);
        mTemporaryToastDuration = 0;
    }

    // ========================================================================
    // View Management
    // ========================================================================

    /**
     * Creates a toast view and attaches it to the given root view.
     *
     * <p>Replaces any existing holder for the same activity key. The
     * toast is positioned above the bottom edge of the window and fades
     * in.</p>
     *
     * @param activity Activity the toast belongs to, or null for a
     *        root-view-only toast
     * @param rootView View group to attach the toast to
     * @param message Text to display
     * @param isPersistent True for a persistent overlay, false for a
     *        temporary toast
     */
    private void createOverlayInView(@Nullable Activity activity,
                                     @NonNull ViewGroup rootView,
                                     @NonNull String message,
                                     boolean isPersistent) {
        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP);
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);

        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        textView.setTextColor(getThemeColor());

        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(
            dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP),
            TOAST_STROKE_COLOR);
        textView.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }

        container.addView(textView);
        rootView.addView(container);

        mOverlayMap.put(key, new OverlayHolder(
            container, textView, activity, message, mCurrentOperationId, isPersistent));
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());

        if (activity != null) {
            mCurrentActivityRef = new WeakReference<>(activity);
        }

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }

    /**
     * Creates a fresh overlay for the given activity and installs the
     * current message in it.
     *
     * <p>Refused when the state is not a persistent one or when the
     * current message is null.</p>
     *
     * @param activity Activity to attach the overlay to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        State currentState = mCurrentState.get();
        if (!isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot reattach - only persistent toasts are supported");
            return;
        }

        if (mCurrentMessage == null) {
            Log.w(TAG, "Cannot reattach - no message available");
            transitionTo(State.HIDDEN);
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found for reattachment");
            return;
        }

        createOverlayInView(activity, root, mCurrentMessage, true);
        mCurrentActivityRef = new WeakReference<>(activity);

        if (isPersistentActive(currentState)) {
            transitionTo(State.SHOWING_PERSISTENT);
        }

        Log.d(TAG, "Overlay reattached to activity: "
            + activity.getClass().getSimpleName());
    }

    /**
     * Hides every overlay and transitions to {@link State#HIDDEN}.
     *
     * <p>The current activity reference is left untouched. Hiding an
     * overlay is a visibility change; the reference answers a lifecycle
     * question and must survive a hide so a follow-up overlay show
     * posted in the same main-thread turn can still find the current
     * activity.</p>
     *
     * @param animate True to fade the overlays out before removing them
     */
    private void hideCurrentToast(boolean animate) {
        cancelAutoDismiss();
        mTemporaryToastDuration = 0;

        if (animate) {
            for (OverlayHolder holder : mOverlayMap.values()) {
                final FrameLayout overlay = holder.overlayRef.get();
                if (overlay != null) {
                    AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
                    fadeOut.setDuration(FADE_DURATION_MS);
                    fadeOut.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {
                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            removeOverlayView(overlay);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {
                        }
                    });
                    overlay.startAnimation(fadeOut);
                }
            }
        } else {
            for (OverlayHolder holder : mOverlayMap.values()) {
                holder.cleanup();
            }
        }

        mOverlayMap.clear();
        transitionTo(State.HIDDEN);
        mCurrentMessage = null;
        mCurrentOperationId = null;
        mAutoDismissRunnable = null;
        mTemporaryToastDismissed.set(false);
    }

    /**
     * Hides every overlay immediately, without animation, and tears down
     * the mirrored library notification unconditionally.
     *
     * <p>This is the recovery path: the state machine has decided the
     * overlay is dead, and the notification mirror must follow
     * regardless of which operation owned it.</p>
     *
     * <p>The current activity reference is left untouched. Hiding an
     * overlay is a visibility change; the reference answers a lifecycle
     * question and must survive a hide so a follow-up overlay show
     * posted in the same main-thread turn can still find the current
     * activity.</p>
     */
    private void forceHideInternal() {
        cancelAutoDismiss();
        mTemporaryToastDuration = 0;

        for (OverlayHolder holder : mOverlayMap.values()) {
            holder.cleanup();
        }
        mOverlayMap.clear();
        transitionTo(State.HIDDEN);
        mCurrentMessage = null;
        mCurrentOperationId = null;
        mAutoDismissRunnable = null;
        mTemporaryToastDismissed.set(false);

        if (sApplication != null) {
            NotificationController.getInstance(sApplication).clearLibraryStatus();
        }
    }

    /**
     * Removes the given overlay view from its parent.
     *
     * @param overlay Overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {
                // The view was already detached.
            }
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns a human-readable snapshot of the manager's current state.
     *
     * @return A multi-line string describing the state machine, the
     *         message and operation ID, the current activity, the number
     *         of active overlays, and the listener count
     */
    @NonNull
    public String getDebugInfo() {
        Activity currentActivity = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        return "ToastManager\n"
                + "State: " + mCurrentState.get() + "\n"
                + "State duration: "
                + (SystemClock.elapsedRealtime() - mStateStartTime.get()) + "ms\n"
                + "Last activity: "
                + (SystemClock.elapsedRealtime() - mLastActivityTime.get()) + "ms ago\n"
                + "Last valid overlay: "
                + (SystemClock.elapsedRealtime() - mLastValidOverlayTime.get()) + "ms ago\n"
                + "Message: " + mCurrentMessage + "\n"
                + "Operation ID: " + mCurrentOperationId + "\n"
                + "Current activity: "
                + (currentActivity != null
                    ? currentActivity.getClass().getSimpleName() : "null") + "\n"
                + "Active overlays: " + mOverlayMap.size() + "\n"
                + "Listeners: " + mStateListeners.size();
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Releases every resource held by the manager.
     *
     * <p>Stops the health check, cancels recovery and auto-dismiss,
     * unregisters lifecycle callbacks and the theme receiver, hides any
     * active overlay, and clears the singleton reference.</p>
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");

        toastManager.cancelAutoDismiss();
        toastManager.cancelRecovery();

        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }

        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {
                // The callbacks were already unregistered.
            }
        }

        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
        }

        toastManager.forceHideInternal();
        sInstance = null;
        sApplication = null;
        Log.d(TAG, "ToastManager shut down complete");
    }
}