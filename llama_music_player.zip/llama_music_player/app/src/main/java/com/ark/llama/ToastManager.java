// ToastManager.java
package com.ark.llama;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Owns every in-activity toast and persistent overlay the app shows,
 * and drives their lifecycle through an operation stack.
 *
 * <p>Persistent overlays are owned by operations. An operation is
 * registered on the stack by its operation ID. The stack renders the
 * operation at the top; a lower operation's message is retained but not
 * shown while a higher operation is active, and surfaces automatically
 * when the higher operation ends. Cancelling an operation is removing
 * its entry from the stack, which is indistinguishable from an
 * operation that ran to completion and removed itself; callers that
 * need to distinguish those two cases carry their own terminal state,
 * as {@link PlaylistManager} does for its genre load and its reset.</p>
 *
 * <p>Each activity maintains its own overlay view instances, tracked in
 * {@link #mOverlayMap}. An activity's overlays are removed only when the
 * activity is destroyed, so a stopped activity keeps its overlays
 * attached until the activity actually goes away. A periodic health
 * check treats a persistent overlay whose owner has stopped
 * heartbeating, or an overlay whose view has been detached from its
 * parent, as stuck and runs a recovery pass.</p>
 *
 * <p>Every persistent overlay is mirrored to the status bar through
 * {@link NotificationController}. The mirror is bound to the operation
 * ID at the top of the stack at the moment the overlay is rendered, so
 * a hide or update that arrives after another operation has taken over
 * the top of the stack is refused by {@link NotificationController}'s
 * own ownership check. Temporary toasts are not mirrored. Recovery from
 * a stuck overlay tears the mirror down unconditionally.</p>
 *
 * <h3>Width ownership</h3>
 * <p>A persistent overlay's available width is a pure function of the
 * root view the overlay was attached to, computed by
 * {@link #resolveAvailableToastWidthPx(ViewGroup)}. Every render of a
 * persistent overlay's text re-reads that source. The width is never
 * carried from the creation call to a later update as a snapshot.</p>
 *
 * <h3>Title and body ownership</h3>
 * <p>A persistent overlay's message is the title rendered in the
 * overlay's text view. The notification mirror's body is a separate
 * string carried alongside the title, so neither the overlay nor the
 * mirror has to split a joined message. The single-argument
 * {@code showPersistentOverlay} and {@code updatePersistentOverlay}
 * overloads forward to the two-argument forms with an empty body; a
 * caller whose operation has a detail line passes both strings.</p>
 *
 * <h3>Two overlay kinds, two lifecycles</h3>
 * <p>The manager holds two kinds of overlay that never share a
 * lifecycle.</p>
 * <ul>
 *   <li><b>Persistent overlays</b> are owned by an operation on the
 *       stack. They are kept alive by the owner's heartbeat, and their
 *       visibility ends when the owner's entry is popped from the
 *       stack. Their lifetime is not the overlay's; it is the
 *       operation's.</li>
 *   <li><b>Temporary toasts</b> are owned by the manager. They are shown
 *       for a fixed duration, auto-dismiss, and are never reattached.
 *       Their lifetime ends when the timer elapses.</li>
 * </ul>
 *
 * <p>A temporary toast can be shown while a persistent overlay is
 * active. The temporary toast is drawn on top of the persistent overlay
 * (added later to the same content view, so drawn last), stays for its
 * duration, and disappears without touching the persistent. Showing a
 * temporary toast does not transition the state machine away from
 * {@link State#SHOWING_PERSISTENT}; only the state of "no persistent
 * overlay" is a precondition for the temporary-toast state.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns the current state of the state machine, the
 * per-activity overlay map, the operation stack (an ordered list of
 * operation IDs, a message map, and a heartbeat-timestamp map), the
 * pending temporary-toast dismissals, and the weak reference to the
 * currently resumed activity. The notification mirror is owned by
 * {@link NotificationController}, which uses the operation ID at the
 * top of the stack as an ownership token.</p>
 *
 * <p>The overlay map and the operation stack are distinct stores with
 * distinct lifetimes. The map holds the views that are currently
 * attached; removing an overlay view does not remove its operation
 * from the stack, and removing an operation from the stack does not
 * by itself remove any view. The two are separated because they answer
 * different questions — "what is on screen?" and "what operations are
 * running?" — and the answers can legitimately differ.</p>
 *
 * <h3>Ordering</h3>
 * <p>The operation stack is an ordered list. An operation is pushed by
 * {@link #showPersistentOverlay(Activity, String, String)}. The
 * operation on top is the last element; the message it carries is the
 * one rendered. Operations below the top have their messages retained
 * and will surface if the operations above them end without a
 * replacement. An operation may be pushed while another is already on
 * top; the new operation is recorded but does not render until it
 * reaches the top.</p>
 *
 * <p>{@link #updatePersistentOverlay(String, String)} and
 * {@link #heartbeat(String)} both take an operation ID and refuse the
 * call when no operation with that ID is on the stack.</p>
 *
 * <p>{@link #isOperationRunning(String)} returns whether an operation
 * ID is on the stack. {@link #cancelOperation(String)} removes an
 * operation from the stack; it is identical to the removal performed by
 * {@link #hidePersistentOverlay(String)}. Callers that need to
 * distinguish "cancelled" from "completed" carry their own terminal
 * state.</p>
 *
 * <h3>Toast Position</h3>
 * <p>A toast sits above the bottom rows of the current activity, in
 * the visible gap between the transport controls and the metadata
 * buttons in the player, or above the bottom controls in any other
 * activity. The gap is not the same height in every window: below
 * {@link #COMPACT_LAYOUT_HEIGHT_DP} the player compresses its
 * transport row's bottom padding, and the gap the toast sits in
 * becomes sixteen dp shorter. A single fixed margin cannot be centred
 * in both gaps, so the margin is chosen at toast-creation time from
 * the window's current height. The choice is made from
 * {@code Configuration.screenHeightDp}, a value every activity shares
 * for the same window.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>The manager is a process-wide singleton initialised through
 * {@link #init(Context)}. It registers itself as an
 * {@link Application.ActivityLifecycleCallbacks} listener and a
 * receiver for theme color change broadcasts. The health check starts
 * with the instance and runs until {@link #shutdown()}.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. State transitions and
 * view mutation run on {@link #mMainHandler}. The current state, the
 * activity flag, and the shutdown flag are atomic. The overlay map, the
 * message map, and the heartbeat map are
 * {@link ConcurrentHashMap}s and the order list is a
 * {@link CopyOnWriteArrayList}; the listener lists are
 * {@link CopyOnWriteArrayList}s.</p>
 *
 * @see NotificationController
 * @see State
 * @see Event
 *
 * @author Richard Korbla Adzido
 * @version 1.4.5
 * @since 1.0.0
 */
public class ToastManager implements Application.ActivityLifecycleCallbacks {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "ToastManager";

    /** Duration of a short toast, in milliseconds. */
    public static final int LENGTH_SHORT = 500;

    /** Duration of a normal toast, in milliseconds. */
    public static final int LENGTH_NORMAL = 1000;

    /** Duration of a long toast, in milliseconds. */
    public static final int LENGTH_LONG = 2000;

    /** Duration of the fade-in and fade-out animation, in milliseconds. */
    private static final int FADE_DURATION_MS = 150;

    /**
     * Horizontal inset on each side of the window that a toast may
     * not cross, in density-independent pixels.
     *
     * <p>This is the app's standard screen inset — the same 16dp
     * every screen uses to keep its content clear of the window
     * edges. The toast's available width is the window width minus
     * this inset on each side, so a long message is only
     * ellipsized once its content genuinely exceeds the display's
     * usable width.</p>
     */
    private static final int TOAST_HORIZONTAL_INSET_DP = 16;

    /** Horizontal padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding inside a toast, in density-independent pixels. */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;

    /**
     * Distance from the bottom edge of the window when the window is
     * tall enough for the full layout, in density-independent pixels.
     */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;

    /**
     * Distance from the bottom edge of the window when the window is
     * too short for the full layout, in density-independent pixels.
     */
    private static final int TOAST_BOTTOM_MARGIN_COMPACT_DP = 68;

    /**
     * Window height at or below which the compact margin is used, in
     * density-independent pixels.
     */
    private static final int COMPACT_LAYOUT_HEIGHT_DP = 400;

    /** Corner radius of the toast background, in density-independent pixels. */
    private static final int TOAST_CORNER_RADIUS_DP = 8;

    /** Stroke width of the toast border, in density-independent pixels. */
    private static final int TOAST_STROKE_WIDTH_DP = 1;

    /** Elevation of the toast on API 21 and later, in density-independent pixels. */
    private static final int TOAST_ELEVATION_DP = 6;

    /** Background color of the toast. */
    private static final int TOAST_BACKGROUND_COLOR = 0xFF1A1A1A;

    /** Stroke color of the toast border. */
    private static final int TOAST_STROKE_COLOR = 0xFF2A2A2A;

    /** Default theme color used when the theme manager is unavailable. */
    private static final int DEFAULT_THEME_COLOR = 0xFFB8A86E;

    /** Broadcast action for theme color changes. */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    /** Interval between health checks, in milliseconds. */
    private static final long HEALTH_CHECK_INTERVAL_MS = 500L;

    /** Inactivity timeout for persistent overlays, in milliseconds. */
    private static final long STUCK_TIMEOUT_MS = 1000L;

    /** Delay before running recovery, in milliseconds. */
    private static final long RECOVERY_DELAY_MS = 500L;

    /**
     * Prefix for the per-activity key of a temporary toast. Every
     * temporary toast for a given activity uses the same key, so a new
     * temporary toast replaces the previous one for that activity. The
     * prefix guarantees that a temporary key never collides with a
     * persistent overlay key, which is the activity key on its own.
     */
    private static final String KEY_TEMP_TOAST_PREFIX = "TEMP_TOAST_";

    /** Activity key used for root-view-only toasts shown outside an activity. */
    private static final String KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY";

    // ============================================================================
    // State Machine
    // ============================================================================

    /**
     * States of the toast state machine.
     */
    public enum State {

        /** No overlay is showing. */
        HIDDEN,

        /**
         * At least one temporary toast is showing and no persistent
         * overlay is active.
         */
        SHOWING_TEMPORARY,

        /**
         * A persistent overlay is showing. Temporary toasts may also be
         * showing on top of it; their presence does not change this
         * state.
         */
        SHOWING_PERSISTENT,

        /** An overlay is being hidden and the fade-out animation is running. */
        HIDING,

        /** A persistent overlay is being reattached to a new activity. */
        REATTACHING,

        /** A stuck overlay has been detected and recovery is running. */
        STUCK
    }

    /**
     * Events that drive the state machine.
     */
    public enum Event {

        /** Show a temporary toast. */
        SHOW_TEMPORARY,

        /** Show a persistent overlay. */
        SHOW_PERSISTENT,

        /** Update the text of the current persistent overlay. */
        UPDATE,

        /** Record a heartbeat, resetting the stuck timer. */
        HEARTBEAT,

        /** Hide the current persistent overlay, respecting ownership. */
        HIDE,

        /** Hide every overlay, ignoring ownership. */
        FORCE_HIDE,

        /** Reattach the current persistent overlay to a new activity. */
        REATTACH,

        /** Mark the current overlay as stuck. */
        STUCK_DETECTED,

        /** Complete recovery from a stuck state. */
        RECOVERED
    }

    /**
     * Returns whether the given state represents an active persistent
     * overlay.
     *
     * <p>{@link State#SHOWING_PERSISTENT} is the resting state.
     * {@link State#REATTACHING} is the transient state during which a
     * fresh view is being installed in a new activity's window. Both
     * are treated as active by every public API.</p>
     *
     * @param state State to test, or null
     * @return True when the state represents an active persistent overlay
     */
    private static boolean isPersistentActive(@Nullable State state) {
        return state == State.SHOWING_PERSISTENT || state == State.REATTACHING;
    }

    // ============================================================================
    // Listener Interfaces
    // ============================================================================

    /**
     * Receives toast state changes and stuck detection events.
     */
    public interface ToastStateListener {

        /**
         * Called when the toast state changes.
         *
         * @param oldState State before the transition
         * @param newState State after the transition
         */
        void onStateChanged(@NonNull State oldState, @NonNull State newState);

        /**
         * Called when a stuck overlay is detected and recovery is about
         * to run.
         *
         * @param reason Reason the overlay was considered stuck
         * @param ageMs Duration the overlay had been showing, in
         *        milliseconds
         * @param inactiveTimeMs Time since the last heartbeat or update,
         *        in milliseconds
         */
        void onStuckToastDetected(@NonNull String reason, long ageMs,
                                  long inactiveTimeMs);
    }

    // ============================================================================
    // Per-Activity Overlay Tracking
    // ============================================================================

    /**
     * Holds the overlay views for a single overlay instance.
     *
     * <p>All view references are weak, so the holder does not prevent
     * the activity or its views from being collected. The root view is
     * retained so every render of the overlay's text can re-read the
     * available width from the same source the creation call used.</p>
     */
    private static class OverlayHolder {

        /** Weak reference to the overlay container view. */
        final WeakReference<FrameLayout> overlayRef;

        /** Weak reference to the text view inside the overlay. */
        final WeakReference<TextView> textViewRef;

        /** Weak reference to the activity that owns the overlay. */
        final WeakReference<Activity> activityRef;

        /** Weak reference to the root view the overlay was attached to. */
        final WeakReference<ViewGroup> rootViewRef;

        /** Message the overlay was created with. */
        final String message;

        /** Operation ID the overlay was created with, or null. */
        final String operationId;

        /** True when the overlay is persistent; false when it is temporary. */
        final boolean isPersistent;

        /**
         * Constructs a holder for the given overlay.
         *
         * @param overlay Overlay container
         * @param textView Text view inside the overlay
         * @param activity Activity that owns the overlay
         * @param rootView Root view the overlay was attached to
         * @param message Message the overlay was created with
         * @param operationId Operation ID the overlay was created with,
         *        or null
         * @param isPersistent True for a persistent overlay, false for a
         *        temporary toast
         */
        OverlayHolder(FrameLayout overlay, TextView textView, Activity activity,
                      ViewGroup rootView, String message, String operationId,
                      boolean isPersistent) {
            this.overlayRef = new WeakReference<>(overlay);
            this.textViewRef = new WeakReference<>(textView);
            this.activityRef = new WeakReference<>(activity);
            this.rootViewRef = new WeakReference<>(rootView);
            this.message = message;
            this.operationId = operationId;
            this.isPersistent = isPersistent;
        }

        /**
         * Returns whether both the overlay and its text view are still
         * reachable.
         *
         * @return True when the overlay and text view can be used
         */
        boolean isValid() {
            return overlayRef.get() != null && textViewRef.get() != null;
        }

        /**
         * Detaches the overlay view from its parent when it is still
         * attached.
         */
        void cleanup() {
            FrameLayout overlay = overlayRef.get();
            if (overlay != null && overlay.getParent() != null) {
                try {
                    ((ViewGroup) overlay.getParent()).removeView(overlay);
                } catch (Exception ignored) {
                    // The view was already detached.
                }
            }
        }
    }

    /**
     * Map of overlay key to overlay holder.
     *
     * <p>Persistent overlays are keyed by the activity key alone.
     * Temporary toasts are keyed by {@link #KEY_TEMP_TOAST_PREFIX}
     * concatenated with the activity key. The two namespaces do not
     * overlap, so a temporary toast and a persistent overlay for the
     * same activity occupy distinct slots.</p>
     */
    private final ConcurrentHashMap<String, OverlayHolder> mOverlayMap =
        new ConcurrentHashMap<>();

    // ============================================================================
    // Operation Stack
    // ============================================================================

    /**
     * Operation IDs currently on the stack, in admission order. The
     * last element is the operation on top; its message is the one
     * rendered.
     */
    private final CopyOnWriteArrayList<String> mOperationOrder =
        new CopyOnWriteArrayList<>();

    /**
     * Message currently held by each operation on the stack, keyed by
     * operation ID. Removed when the operation is popped.
     */
    private final ConcurrentHashMap<String, String> mOperationMessages =
        new ConcurrentHashMap<>();

    /**
     * Timestamp of the last heartbeat or update for each operation on
     * the stack, keyed by operation ID.
     */
    private final ConcurrentHashMap<String, Long> mOperationHeartbeats =
        new ConcurrentHashMap<>();

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static ToastManager sInstance;

    /** Application instance used for lifecycle callbacks and broadcasts. */
    @Nullable
    private static Application sApplication;

    /** Main-thread handler for UI operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /** Handler for the periodic health check. */
    @NonNull
    private final Handler mHealthHandler = new Handler(Looper.getMainLooper());

    // ============================================================================
    // State Machine Variables
    // ============================================================================

    /** Current state of the state machine. */
    private final AtomicReference<State> mState =
        new AtomicReference<>(State.HIDDEN);

    /** Timestamp at which the current state began. */
    private final AtomicLong mStateStartTime = new AtomicLong(0L);

    /** Timestamp of the last heartbeat or update for the top operation. */
    private final AtomicLong mLastActivityTime = new AtomicLong(0L);

    /**
     * Timestamp of the last health check that found a valid overlay.
     */
    private final AtomicLong mLastValidOverlayTime = new AtomicLong(0L);

    /** True while recovery is running. */
    private final AtomicBoolean mIsRecovering = new AtomicBoolean(false);

    /** Runnable for the periodic health check, or null when stopped. */
    @Nullable
    private Runnable mHealthCheckRunnable = null;

    /** Runnable for the current recovery, or null when none is pending. */
    @Nullable
    private Runnable mRecoveryRunnable = null;

    /** Lock that serialises health checks. */
    private final Object mHealthLock = new Object();

    /** Lock that serialises stack mutations. */
    private final Object mStackLock = new Object();

    // ========================================================================
    // Auto-Dismiss Management
    // ========================================================================

    /**
     * Pending auto-dismiss runnables, keyed by the temporary-toast key
     * they belong to. A new temporary toast for the same key cancels the
     * pending dismissal for that key and schedules a fresh one. A
     * temporary toast in a different activity has its own key and its
     * own pending dismissal, and is not affected.
     */
    private final ConcurrentHashMap<String, Runnable> mPendingAutoDismiss =
        new ConcurrentHashMap<>();

    /**
     * Weak reference to the currently resumed activity.
     */
    @Nullable
    private WeakReference<Activity> mCurrentActivityRef = null;

    /** True once the lifecycle callbacks have been registered. */
    private boolean mCallbacksRegistered = false;

    // ========================================================================
    // Theme Components
    // ========================================================================

    /** Receiver for theme color change broadcasts, or null. */
    @Nullable
    private BroadcastReceiver mThemeReceiver = null;

    // ========================================================================
    // Listeners
    // ========================================================================

    /** Registered toast state listeners. */
    private final CopyOnWriteArrayList<ToastStateListener> mStateListeners =
        new CopyOnWriteArrayList<>();

    // ========================================================================
    // Constructor and Initialization
    // ========================================================================

    /**
     * Constructs the singleton, registers lifecycle callbacks and the
     * theme receiver, and starts the health check.
     *
     * @param context A context; the application context is retained
     */
    private ToastManager(@NonNull Context context) {
        sApplication = (Application) context.getApplicationContext();
        registerLifecycleCallbacks();
        registerThemeReceiver();
        startHealthCheck();
        mState.set(State.HIDDEN);
        mStateStartTime.set(SystemClock.elapsedRealtime());
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());
        Log.d(TAG, "ToastManager initialized (operation-stack overlay management)");
    }

    /**
     * Initializes the singleton.
     *
     * @param context A context; the application context is retained
     */
    public static synchronized void init(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new ToastManager(context);
        }
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance
     * @throws IllegalStateException When {@link #init(Context)} has not
     *         yet been called
     */
    @NonNull
    private static ToastManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException("ToastManager not initialized. Call init() first.");
        }
        return sInstance;
    }

    // ========================================================================
    // Public API - Operation Stack
    // ========================================================================

    /**
     * Returns whether the given operation is currently on the stack.
     *
     * @param operationId Operation ID to test, or null
     * @return True when the operation is on the stack
     */
    public static boolean isOperationRunning(@Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        return getInstance().mOperationOrder.contains(operationId);
    }

    /**
     * Removes the given operation from the stack.
     *
     * @param operationId Operation ID to cancel, or null
     */
    public static void cancelOperation(@Nullable String operationId) {
        if (operationId == null) {
            return;
        }
        getInstance().popOperationInternal(operationId);
    }

    /**
     * Returns the operation ID currently on top of the stack, or null
     * when the stack is empty.
     *
     * @return The top operation ID, or null
     */
    @Nullable
    public static String getCurrentOperationId() {
        ToastManager toastManager = getInstance();
        List<String> order = toastManager.mOperationOrder;
        if (order.isEmpty()) {
            return null;
        }
        return order.get(order.size() - 1);
    }

    /**
     * Returns the message currently held by the given operation, or null
     * when the operation is not on the stack.
     *
     * @param operationId Operation ID to inspect, or null
     * @return The operation's message, or null
     */
    @Nullable
    public static String getOperationMessage(@Nullable String operationId) {
        if (operationId == null) {
            return null;
        }
        return getInstance().mOperationMessages.get(operationId);
    }

    // ========================================================================
    // State Machine Methods
    // ========================================================================

    /**
     * Transitions to the given state and notifies every registered
     * listener.
     *
     * @param newState State to transition to
     */
    private void transitionTo(@NonNull State newState) {
        State oldState = mState.getAndSet(newState);
        if (oldState == newState) {
            return;
        }
        Log.d(TAG, "State transition: " + oldState + " \u2192 " + newState);
        mStateStartTime.set(SystemClock.elapsedRealtime());

        for (ToastStateListener listener : mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState);
            } catch (Exception exception) {
                Log.e(TAG, "Error notifying state listener", exception);
            }
        }
    }

    /**
     * Recomputes the state machine's state from the current contents of
     * the overlay map and the operation stack.
     *
     * <p>The rule is a direct function of the map and the stack:</p>
     * <ul>
     *   <li>A persistent overlay is present, or the operation stack is
     *       non-empty → {@link State#SHOWING_PERSISTENT}.</li>
     *   <li>No persistent overlay, no operations, at least one temporary
     *       toast → {@link State#SHOWING_TEMPORARY}.</li>
     *   <li>No overlays and no operations → {@link State#HIDDEN}.</li>
     * </ul>
     *
     * <p>The operation stack is not touched by this method. The
     * {@link State#REATTACHING} state is left alone; it is a transient
     * state during which the map is being rebuilt for a new
     * activity.</p>
     */
    private void recomputeStateFromMap() {
        State currentState = mState.get();
        if (currentState == State.REATTACHING) {
            return;
        }

        boolean hasPersistent = false;
        boolean hasTemporary = false;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                hasPersistent = true;
            } else {
                hasTemporary = true;
            }
        }

        boolean hasOperations;
        synchronized (mStackLock) {
            hasOperations = !mOperationOrder.isEmpty();
        }

        if (hasPersistent || hasOperations) {
            transitionTo(State.SHOWING_PERSISTENT);
        } else if (hasTemporary) {
            transitionTo(State.SHOWING_TEMPORARY);
        } else {
            transitionTo(State.HIDDEN);
        }
    }

    /**
     * Dispatches the given event through the state machine.
     *
     * @param event Event to dispatch
     * @return True when the event changed the state
     */
    private boolean handleEvent(@NonNull Event event) {
        State currentState = mState.get();
        Log.v(TAG, "Event: " + event + " in state: " + currentState);

        switch (event) {
            case SHOW_TEMPORARY:  return handleShowTemporary(currentState);
            case SHOW_PERSISTENT: return handleShowPersistent(currentState);
            case UPDATE:          return handleUpdate(currentState);
            case HEARTBEAT:       return handleHeartbeat(currentState);
            case HIDE:            return handleHide(currentState);
            case FORCE_HIDE:      return handleForceHide(currentState);
            case REATTACH:        return handleReattach(currentState);
            case STUCK_DETECTED:  return handleStuckDetected(currentState);
            case RECOVERED:       return handleRecovered(currentState);
            default:              return false;
        }
    }

    /**
     * Handles a {@link Event#SHOW_TEMPORARY} event.
     *
     * <p>Only fired when no persistent overlay is active. When the
     * current state is {@link State#SHOWING_PERSISTENT} or
     * {@link State#REATTACHING}, the caller bypasses this event and
     * leaves the state machine alone.</p>
     *
     * @param currentState State before the event
     * @return True when the event was accepted
     */
    private boolean handleShowTemporary(State currentState) {
        if (currentState == State.HIDDEN || currentState == State.HIDING
                || currentState == State.SHOWING_TEMPORARY) {
            transitionTo(State.SHOWING_TEMPORARY);
            return true;
        }
        Log.w(TAG, "SHOW_TEMPORARY in state " + currentState + " — refusing");
        return false;
    }

    /**
     * Handles a {@link Event#SHOW_PERSISTENT} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleShowPersistent(State currentState) {
        transitionTo(State.SHOWING_PERSISTENT);
        return true;
    }

    /**
     * Handles an {@link Event#UPDATE} event.
     *
     * @param currentState State before the event
     * @return True when the update was accepted
     */
    private boolean handleUpdate(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            return true;
        }
        Log.w(TAG, "Cannot update persistent overlay in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#HEARTBEAT} event.
     *
     * @param currentState State before the event
     * @return True when the heartbeat was accepted
     */
    private boolean handleHeartbeat(State currentState) {
        if (isPersistentActive(currentState)) {
            mLastActivityTime.set(SystemClock.elapsedRealtime());
            Log.v(TAG, "Heartbeat received");
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#HIDE} event.
     *
     * @param currentState State before the event
     * @return True when the hide was accepted
     */
    private boolean handleHide(State currentState) {
        if (isPersistentActive(currentState)) {
            transitionTo(State.HIDING);
            return true;
        }
        if (currentState == State.HIDDEN) {
            return true;
        }
        Log.w(TAG, "Cannot hide persistent overlay in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#FORCE_HIDE} event.
     *
     * @param currentState State before the event
     * @return Always true
     */
    private boolean handleForceHide(State currentState) {
        if (currentState != State.HIDDEN) {
            transitionTo(State.HIDING);
            return true;
        }
        return true;
    }

    /**
     * Handles a {@link Event#REATTACH} event.
     *
     * @param currentState State before the event
     * @return True when the reattach was accepted
     */
    private boolean handleReattach(State currentState) {
        if (currentState == State.SHOWING_PERSISTENT) {
            transitionTo(State.REATTACHING);
            return true;
        }
        if (currentState == State.REATTACHING) {
            return true;
        }
        Log.w(TAG, "Cannot reattach in state: " + currentState);
        return false;
    }

    /**
     * Handles a {@link Event#STUCK_DETECTED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleStuckDetected(State currentState) {
        if (isPersistentActive(currentState)
                || currentState == State.SHOWING_TEMPORARY) {
            Log.w(TAG, "Overlay stuck detected, transitioning to STUCK");
            transitionTo(State.STUCK);
            return true;
        }
        return false;
    }

    /**
     * Handles a {@link Event#RECOVERED} event.
     *
     * @param currentState State before the event
     * @return True when the state accepted the transition
     */
    private boolean handleRecovered(State currentState) {
        if (currentState == State.STUCK) {
            transitionTo(State.HIDDEN);
            return true;
        }
        return false;
    }

    // ========================================================================
    // Activity Lifecycle Callbacks
    // ========================================================================

    /**
     * Registers the lifecycle callbacks with the application.
     */
    private void registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) {
            return;
        }
        sApplication.registerActivityLifecycleCallbacks(this);
        mCallbacksRegistered = true;
        Log.d(TAG, "Activity lifecycle callbacks registered");
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    /**
     * Sets the current activity reference and, when a persistent overlay
     * is active or an operation is still on the stack, reattaches the
     * top operation's overlay to the newly resumed activity.
     *
     * @param activity Activity that resumed
     */
    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        mCurrentActivityRef = new WeakReference<>(activity);

        State currentState = mState.get();
        boolean hasOperations = !mOperationOrder.isEmpty();

        if (isPersistentActive(currentState) || hasOperations) {
            if (currentState == State.SHOWING_PERSISTENT) {
                handleEvent(Event.REATTACH);
            } else if (!isPersistentActive(currentState)) {
                transitionTo(State.SHOWING_PERSISTENT);
            }
            reattachToActivity(activity);
        } else if (currentState == State.SHOWING_TEMPORARY) {
            Log.d(TAG, "Temporary toast showing, not reattaching "
                + "(auto-dismiss will handle it)");
        }
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    /**
     * Clears the current activity reference when the stopped activity is
     * the one being tracked, and runs a health check.
     *
     * @param activity Activity that stopped
     */
    @Override
    public void onActivityStopped(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }
        performHealthCheck();
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    /**
     * Clears the current activity reference when the destroyed activity
     * is the one being tracked, removes its overlay holders, and runs a
     * health check.
     *
     * @param activity Activity that was destroyed
     */
    @Override
    public void onActivityDestroyed(Activity activity) {
        if (mCurrentActivityRef != null && mCurrentActivityRef.get() == activity) {
            mCurrentActivityRef = null;
        }

        String activityKey = getActivityKey(activity);
        String tempKey = getTempToastKey(activity);

        OverlayHolder persistentHolder = mOverlayMap.remove(activityKey);
        if (persistentHolder != null) {
            persistentHolder.cleanup();
        }

        OverlayHolder tempHolder = mOverlayMap.remove(tempKey);
        if (tempHolder != null) {
            tempHolder.cleanup();
        }

        Runnable pending = mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            mMainHandler.removeCallbacks(pending);
        }

        recomputeStateFromMap();
        performHealthCheck();
    }

    // ========================================================================
    // Theme Management
    // ========================================================================

    /**
     * Registers a receiver for theme color change broadcasts.
     *
     * <p>The receiver listens only for broadcasts sent by the app
     * itself, so it is registered with
     * {@code RECEIVER_NOT_EXPORTED}.</p>
     */
    private void registerThemeReceiver() {
        if (sApplication == null) {
            return;
        }
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        ContextCompat.registerReceiver(
            sApplication, mThemeReceiver,
            new IntentFilter(ACTION_THEME_COLOR_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    /**
     * Reapplies the current theme color to every visible overlay's text
     * view.
     */
    public static void refreshThemeColor() {
        ToastManager toastManager = getInstance();
        final int themeColor = toastManager.getThemeColor();
        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                State currentState = toastManager.mState.get();
                if (currentState != State.SHOWING_TEMPORARY
                        && !isPersistentActive(currentState)) {
                    return;
                }
                for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                    TextView textView = holder.textViewRef.get();
                    if (textView != null) {
                        textView.setTextColor(themeColor);
                    }
                }
            }
        });
    }

    /**
     * Returns the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The current theme color as an integer
     */
    private int getThemeColor() {
        try {
            if (sApplication == null) {
                return DEFAULT_THEME_COLOR;
            }
            ThemeManager themeManager = ThemeManager.getInstance(sApplication);
            return themeManager != null
                ? themeManager.getCurrentColorInt() : DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }

    // ========================================================================
    // Toast Position
    // ========================================================================

    /**
     * Returns the bottom margin the next toast should use, based on the
     * current window height.
     *
     * <p>Reads {@code Configuration.screenHeightDp} from the application
     * resources at the moment the toast is created. Below
     * {@link #COMPACT_LAYOUT_HEIGHT_DP} the player hides its album art
     * and reduces its transport row's bottom padding, so the gap the
     * toast sits in is shorter and the compact margin is returned. At or
     * above that height the padding is the layout's declared value and
     * the full margin is returned.</p>
     *
     * @return The bottom margin in density-independent pixels
     */
    private int resolveBottomMarginDp() {
        if (sApplication == null) {
            return TOAST_BOTTOM_MARGIN_DP;
        }
        try {
            final Configuration configuration =
                sApplication.getResources().getConfiguration();
            final int heightDp = configuration.screenHeightDp;
            if (heightDp > 0
                    && heightDp <= COMPACT_LAYOUT_HEIGHT_DP) {
                return TOAST_BOTTOM_MARGIN_COMPACT_DP;
            }
        } catch (Exception exception) {
            Log.w(TAG, "Failed to read window height for toast margin",
                exception);
        }
        return TOAST_BOTTOM_MARGIN_DP;
    }

    // ========================================================================
    // Health Check
    // ========================================================================

    /**
     * Starts the periodic health check.
     */
    private void startHealthCheck() {
        mHealthCheckRunnable = new HealthCheckRunnable(this);
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started (interval: "
            + HEALTH_CHECK_INTERVAL_MS + "ms)");
    }

    /**
     * Health-check runnable that holds the manager through a weak
     * reference.
     */
    private static class HealthCheckRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run health checks against
         */
        HealthCheckRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }
            manager.performHealthCheck();
            if (manager.mHealthCheckRunnable != null) {
                manager.mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
            }
        }
    }

    /**
     * Runs the health check.
     *
     * <p>Treats a persistent overlay with no valid holder as stuck only
     * once the map has been empty of persistent holders for longer than
     * {@link #STUCK_TIMEOUT_MS}. Treats a persistent overlay whose top
     * operation has not heartbeated within {@link #STUCK_TIMEOUT_MS} as
     * stuck. The temporary toasts are self-dismissing and are not
     * checked for age.</p>
     */
    private void performHealthCheck() {
        synchronized (mHealthLock) {
            State currentState = mState.get();
            if (currentState != State.SHOWING_TEMPORARY
                    && !isPersistentActive(currentState)) {
                return;
            }

            long now = SystemClock.elapsedRealtime();
            long age = now - mStateStartTime.get();

            boolean hasValidPersistent = false;
            for (OverlayHolder holder : mOverlayMap.values()) {
                if (holder.isPersistent && holder.isValid()) {
                    hasValidPersistent = true;
                    mLastValidOverlayTime.set(now);
                    break;
                }
            }

            boolean isStuck = false;
            String stuckReason = null;

            if (isPersistentActive(currentState) && !hasValidPersistent) {
                long noOverlayDuration = now - mLastValidOverlayTime.get();
                if (noOverlayDuration > STUCK_TIMEOUT_MS) {
                    isStuck = true;
                    stuckReason = "Persistent overlay missing for " + noOverlayDuration
                        + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
                }
            } else if (isPersistentActive(currentState)) {
                String topId = getCurrentOperationId();
                if (topId != null) {
                    Long heartbeat = mOperationHeartbeats.get(topId);
                    long lastActivity = heartbeat != null
                        ? heartbeat : mStateStartTime.get();
                    long inactiveTime = now - lastActivity;
                    if (inactiveTime > STUCK_TIMEOUT_MS) {
                        isStuck = true;
                        stuckReason = "No heartbeat for operation '" + topId
                            + "' in " + inactiveTime
                            + "ms (timeout: " + STUCK_TIMEOUT_MS + "ms)";
                    }
                }
            }

            if (isStuck) {
                Log.w(TAG, "STUCK OVERLAY DETECTED: " + stuckReason);

                for (ToastStateListener listener : mStateListeners) {
                    try {
                        listener.onStuckToastDetected(stuckReason, age,
                            now - mLastActivityTime.get());
                    } catch (Exception exception) {
                        Log.e(TAG, "Error notifying stuck listener", exception);
                    }
                }

                if (handleEvent(Event.STUCK_DETECTED)) {
                    startRecovery();
                }
            }
        }
    }

    /**
     * Starts the recovery pass from a stuck state.
     */
    private void startRecovery() {
        if (mIsRecovering.getAndSet(true)) {
            return;
        }
        Log.d(TAG, "Starting overlay recovery");
        cancelRecovery();

        mRecoveryRunnable = new RecoveryRunnable(this);
        mMainHandler.postDelayed(mRecoveryRunnable, RECOVERY_DELAY_MS);
    }

    /**
     * Recovery runnable that holds the manager through a weak reference.
     */
    private static class RecoveryRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager to run recovery against
         */
        RecoveryRunnable(ToastManager manager) {
            this.managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }
            Log.d(TAG, "Overlay recovery completed");
            manager.forceHideAllOverlays();
            manager.handleEvent(Event.RECOVERED);
            manager.mIsRecovering.set(false);
            manager.mRecoveryRunnable = null;
        }
    }

    /**
     * Cancels the pending recovery. Idempotent.
     */
    private void cancelRecovery() {
        if (mRecoveryRunnable != null) {
            mMainHandler.removeCallbacks(mRecoveryRunnable);
            mRecoveryRunnable = null;
        }
        mIsRecovering.set(false);
    }

    // ========================================================================
    // Public API - Get Current Activity
    // ========================================================================

    /**
     * Returns the activity that is currently resumed.
     *
     * @return The current activity, or null when none is tracked
     */
    @Nullable
    public static Activity getCurrentActivity() {
        ToastManager toastManager = getInstance();
        if (toastManager.mCurrentActivityRef != null) {
            return toastManager.mCurrentActivityRef.get();
        }
        return null;
    }

    // ========================================================================
    // Public API - Heartbeat
    // ========================================================================

    /**
     * Records a heartbeat for the given operation.
     *
     * <p>A heartbeat resets the stuck timer for the operation. When the
     * given operation ID is not on the stack, the heartbeat is refused
     * so a component that does not own an operation cannot extend its
     * lifetime.</p>
     *
     * @param operationId Operation ID to heartbeat, or null
     * @return True when the heartbeat was accepted
     */
    public static boolean heartbeat(@Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        ToastManager toastManager = getInstance();
        if (!toastManager.mOperationOrder.contains(operationId)) {
            return false;
        }
        toastManager.mOperationHeartbeats.put(
            operationId, SystemClock.elapsedRealtime());
        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());
        return toastManager.handleEvent(Event.HEARTBEAT);
    }

    // ========================================================================
    // Public API - Temporary Toasts
    // ========================================================================

    /**
     * Shows a temporary toast in the given activity for the given
     * duration.
     *
     * <p>The temporary toast coexists with a persistent overlay. When a
     * persistent overlay is showing, the state machine stays in
     * {@link State#SHOWING_PERSISTENT} and the operation stack is not
     * touched. When no persistent overlay is showing, the state machine
     * transitions to {@link State#SHOWING_TEMPORARY}.</p>
     *
     * <p>A new temporary toast for the same activity replaces the
     * previous one for that activity, and cancels the previous one's
     * pending auto-dismiss.</p>
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message,
                                 int duration) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity");
            return;
        }

        String tempKey = getTempToastKey(activity);

        OverlayHolder existingTemp = toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        Runnable pending = toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show toast");
            return;
        }

        toastManager.createOverlayInView(activity, root, message, false,
            tempKey, null);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
    }

    /**
     * Auto-dismiss runnable that holds the manager through a weak
     * reference and removes only the temporary overlay it was created
     * for.
     */
    private static class AutoDismissRunnable implements Runnable {

        /** Weak reference to the manager. */
        private final WeakReference<ToastManager> managerRef;

        /** The overlay key this dismissal is responsible for. */
        private final String key;

        /**
         * Constructs the runnable.
         *
         * @param manager Manager that owns the toast
         * @param key Overlay key this dismissal is responsible for
         */
        AutoDismissRunnable(ToastManager manager, String key) {
            this.managerRef = new WeakReference<>(manager);
            this.key = key;
        }

        @Override
        public void run() {
            ToastManager manager = managerRef.get();
            if (manager == null) {
                return;
            }

            OverlayHolder holder = manager.mOverlayMap.remove(key);
            if (holder == null) {
                manager.mPendingAutoDismiss.remove(key);
                return;
            }

            holder.cleanup();
            manager.recomputeStateFromMap();
            manager.mPendingAutoDismiss.remove(key);
        }
    }

    /**
     * Shows a temporary toast in the given activity for the long
     * duration.
     *
     * @param activity Activity to show the toast in
     * @param message Text to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }

    /**
     * Shows a temporary toast inside the given view hierarchy.
     *
     * <p>Used when a toast needs to appear inside a dialog or another
     * surface that does not have an activity window of its own.</p>
     *
     * @param rootView View group to attach the toast to
     * @param message Text to display
     * @param duration Duration in milliseconds
     */
    public static void showToastInView(@NonNull ViewGroup rootView,
                                       @NonNull String message, int duration) {
        ToastManager toastManager = getInstance();

        String tempKey = getTempToastKey(null);

        OverlayHolder existingTemp = toastManager.mOverlayMap.remove(tempKey);
        if (existingTemp != null) {
            existingTemp.cleanup();
        }

        Runnable pending = toastManager.mPendingAutoDismiss.remove(tempKey);
        if (pending != null) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }

        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)) {
            toastManager.handleEvent(Event.SHOW_TEMPORARY);
        }

        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        toastManager.createOverlayInView(null, rootView, message, false,
            tempKey, null);

        final AutoDismissRunnable dismissRunnable =
            new AutoDismissRunnable(toastManager, tempKey);
        toastManager.mPendingAutoDismiss.put(tempKey, dismissRunnable);
        toastManager.mMainHandler.postDelayed(dismissRunnable, duration);
    }

    // ========================================================================
    // Public API - Persistent Overlay
    // ========================================================================

    /**
     * Shows a persistent overlay in the given activity with no operation
     * ID.
     *
     * @param activity Activity to show the overlay in
     * @param message Text to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message) {
        showPersistentOverlay(activity, message, "", null);
    }

    /**
     * Shows a persistent overlay in the given activity with the given
     * operation ID and no notification body.
     *
     * @param activity Activity to show the overlay in
     * @param message Overlay text, and the notification mirror's title
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String message,
                                             @Nullable String operationId) {
        showPersistentOverlay(activity, message, "", operationId);
    }

    /**
     * Shows a persistent overlay in the given activity with the given
     * title and body, using the title as the overlay's visible text and
     * carrying both to the notification mirror.
     *
     * <p>Pushes the operation onto the stack. When the operation reaches
     * the top of the stack, its message is rendered and the notification
     * mirror is opened with the operation ID as the ownership token. An
     * operation pushed while another is already on top is recorded but
     * does not render until the operations above it end. When the
     * operation is already on the stack with a different message, the
     * message is updated in place rather than a second entry being
     * pushed.</p>
     *
     * <p>Showing a persistent overlay removes any existing temporary
     * toasts and any existing persistent overlay, and replaces them with
     * the new persistent overlay.</p>
     *
     * @param activity Activity to show the overlay in
     * @param title Overlay text, and the notification mirror's title
     * @param body Notification mirror's body
     * @param operationId Ownership token, or null
     */
    public static void showPersistentOverlay(@NonNull Activity activity,
                                             @NonNull String title,
                                             @NonNull String body,
                                             @Nullable String operationId) {
        ToastManager toastManager = getInstance();
        if (activity.isFinishing() || activity.isDestroyed()) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity");
            return;
        }

        if (operationId != null) {
            toastManager.pushOperationInternal(operationId, title);
        }

        toastManager.removeAllOverlayViews();

        toastManager.handleEvent(Event.SHOW_PERSISTENT);

        toastManager.mLastActivityTime.set(SystemClock.elapsedRealtime());

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found, cannot show persistent overlay");
            return;
        }

        String key = getActivityKey(activity);
        String renderedOperationId = getCurrentOperationId();
        String renderedMessage = renderedOperationId != null
            ? toastManager.mOperationMessages.get(renderedOperationId)
            : title;
        if (renderedMessage == null) {
            renderedMessage = title;
        }

        toastManager.createOverlayInView(activity, root, renderedMessage, true,
            key, renderedOperationId);
        toastManager.mCurrentActivityRef = new WeakReference<>(activity);

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .showLibraryStatus(title, body, renderedOperationId);
        }

        Log.d(TAG, "Persistent overlay shown: " + renderedMessage
            + (renderedOperationId != null
                ? " (ID: " + renderedOperationId + ")" : ""));
    }

    /**
     * Updates the text of the given operation when it is on the stack,
     * with an empty notification body.
     *
     * @param message New overlay text, and the notification mirror's
     *        title
     * @param operationId Operation ID that must be on the stack
     */
    public static void updatePersistentOverlay(@NonNull String message,
                                               @NonNull String operationId) {
        updatePersistentOverlay(message, "", operationId);
    }

    /**
     * Updates the overlay and the notification mirror with the given
     * title and body when the given operation is on the stack and on
     * top.
     *
     * <p>If the operation is the one on top of the stack, the on-screen
     * overlay and the notification mirror are refreshed. If the
     * operation is below the top, only the message map is updated; the
     * message will surface when the operation reaches the top.</p>
     *
     * <p>The on-screen overlay re-reads its available width from
     * {@link #resolveAvailableToastWidthPx(ViewGroup)} on every render.
     * A message that grows past the width the overlay was created with
     * ellipsizes at the current window's usable width.</p>
     *
     * <p>The call is refused when no operation with the given ID is on
     * the stack. This prevents a stale progress callback from a dead
     * operation from refreshing an overlay that a newer operation has
     * taken over.</p>
     *
     * @param title New overlay text, and the notification mirror's
     *        title
     * @param body Notification mirror's body
     * @param operationId Operation ID that must be on the stack
     */
    public static void updatePersistentOverlay(@NonNull String title,
                                               @NonNull String body,
                                               @NonNull String operationId) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();

        if (!isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot update persistent overlay - no persistent overlay is showing");
            return;
        }

        if (!toastManager.mOperationOrder.contains(operationId)) {
            Log.d(TAG, "Update rejected - operation not on stack: " + operationId);
            return;
        }

        toastManager.mOperationMessages.put(operationId, title);
        toastManager.mOperationHeartbeats.put(
            operationId, SystemClock.elapsedRealtime());

        if (!toastManager.handleEvent(Event.UPDATE)) {
            return;
        }

        String topId = getCurrentOperationId();
        if (!Objects.equals(topId, operationId)) {
            Log.v(TAG, "Operation updated below top of stack: " + operationId);
            return;
        }

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (OverlayHolder holder : toastManager.mOverlayMap.values()) {
                    if (!holder.isPersistent) {
                        continue;
                    }
                    TextView textView = holder.textViewRef.get();
                    if (textView == null) {
                        continue;
                    }
                    ViewGroup rootView = holder.rootViewRef.get();
                    if (rootView != null) {
                        textView.setMaxWidth(
                            toastManager.resolveAvailableToastWidthPx(rootView));
                    }
                    textView.setText(title);
                }
            }
        });

        if (sApplication != null) {
            NotificationController.getInstance(sApplication)
                .updateLibraryStatus(title, body, operationId);
        }
    }

    /**
     * Hides the current persistent overlay when the given operation is
     * on the stack.
     *
     * <p>Removes the operation from the stack. When the removed
     * operation was on top, the new top's message is rendered and the
     * notification mirror is refreshed. When the removed operation was
     * below the top, only the stack entry is removed.</p>
     *
     * @param operationId Operation ID to remove, or null
     * @return True when the operation was on the stack and was removed
     */
    public static boolean hidePersistentOverlay(@Nullable String operationId) {
        if (operationId == null) {
            return false;
        }
        ToastManager toastManager = getInstance();
        return toastManager.popOperationInternal(operationId);
    }

    /**
     * Hides every overlay and ends every operation regardless of ID.
     */
    public static void hidePersistentOverlay() {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();
        if (currentState == State.SHOWING_TEMPORARY
                || isPersistentActive(currentState)) {
            final String currentId = getCurrentOperationId();
            toastManager.handleEvent(Event.FORCE_HIDE);
            toastManager.removeAllOverlayViews();
            toastManager.clearOperationStack();

            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        }
    }

    /**
     * Returns whether a persistent overlay is currently active.
     *
     * @return True when a persistent overlay is active
     */
    public static boolean hasPersistentToast() {
        return isPersistentActive(getInstance().mState.get());
    }

    /**
     * Returns the text of the current persistent overlay.
     *
     * @return The current message, or null when no persistent overlay is
     *         showing
     */
    @Nullable
    public static String getPersistentToastText() {
        String topId = getCurrentOperationId();
        if (topId != null) {
            return getInstance().mOperationMessages.get(topId);
        }
        return null;
    }

    // ========================================================================
    // Stack Internals
    // ========================================================================

    /**
     * Pushes an operation onto the stack.
     *
     * <p>When the operation is already on the stack, the existing entry
     * is moved to the top and its message is replaced.</p>
     *
     * @param operationId Operation ID to push
     * @param message Initial message to associate with the operation
     */
    private void pushOperationInternal(@NonNull String operationId,
                                       @NonNull String message) {
        synchronized (mStackLock) {
            mOperationOrder.remove(operationId);
            mOperationMessages.put(operationId, message);
            mOperationHeartbeats.put(operationId, SystemClock.elapsedRealtime());
            mOperationOrder.add(operationId);
        }
    }

    /**
     * Removes the given operation from the stack and re-renders the new
     * top when the removed operation was on top.
     *
     * @param operationId Operation ID to remove
     * @return True when the operation was on the stack
     */
    private boolean popOperationInternal(@NonNull String operationId) {
        String newTopId;
        boolean wasTop;

        synchronized (mStackLock) {
            if (!mOperationOrder.contains(operationId)) {
                return false;
            }
            wasTop = operationId.equals(
                mOperationOrder.get(mOperationOrder.size() - 1));
            mOperationOrder.remove(operationId);
            mOperationMessages.remove(operationId);
            mOperationHeartbeats.remove(operationId);
            newTopId = mOperationOrder.isEmpty()
                ? null
                : mOperationOrder.get(mOperationOrder.size() - 1);
        }

        if (!wasTop) {
            Log.v(TAG, "Popped operation below top of stack: " + operationId);
            return true;
        }

        if (newTopId == null) {
            handleEvent(Event.HIDE);
            final String currentId = operationId;
            removePersistentOverlayViews(true);
            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .dismissLibraryStatus(currentId);
            }
        } else {
            String newMessage = mOperationMessages.get(newTopId);
            if (newMessage == null) {
                newMessage = "";
            }
            final String finalMessage = newMessage;
            final String finalTopId = newTopId;
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    for (OverlayHolder holder : mOverlayMap.values()) {
                        if (!holder.isPersistent) {
                            continue;
                        }
                        TextView textView = holder.textViewRef.get();
                        if (textView == null) {
                            continue;
                        }
                        ViewGroup rootView = holder.rootViewRef.get();
                        if (rootView != null) {
                            textView.setMaxWidth(
                                resolveAvailableToastWidthPx(rootView));
                        }
                        textView.setText(finalMessage);
                    }
                }
            });
            if (sApplication != null) {
                NotificationController.getInstance(sApplication)
                    .showLibraryStatus(finalMessage, "", finalTopId);
            }
        }
        return true;
    }

    /**
     * Clears every operation from the stack, its message, and its
     * heartbeat timestamp.
     */
    private void clearOperationStack() {
        synchronized (mStackLock) {
            mOperationOrder.clear();
            mOperationMessages.clear();
            mOperationHeartbeats.clear();
        }
    }

    // ========================================================================
    // Reattach Methods
    // ========================================================================

    /**
     * Reattaches the current persistent overlay to the given activity.
     *
     * @param activity Activity to reattach the overlay to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();

        if (!isPersistentActive(currentState)
                && toastManager.mOperationOrder.isEmpty()) {
            return;
        }

        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        toastManager.mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    return;
                }

                State currentStateCheck = toastManager.mState.get();
                if (currentStateCheck == State.HIDDEN
                        && toastManager.mOperationOrder.isEmpty()) {
                    return;
                }

                if (isPersistentActive(currentStateCheck)) {
                    toastManager.handleEvent(Event.REATTACH);
                } else {
                    toastManager.transitionTo(State.SHOWING_PERSISTENT);
                }
                toastManager.reattachToActivity(activity);
            }
        });
    }

    /**
     * Ensures the current persistent overlay is attached to the given
     * activity's window.
     *
     * @param activity Activity the overlay should be attached to
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        ToastManager toastManager = getInstance();
        State currentState = toastManager.mState.get();
        if (!isPersistentActive(currentState)
                && toastManager.mOperationOrder.isEmpty()) {
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder holder = toastManager.mOverlayMap.get(key);
        if (holder == null || !holder.isValid()) {
            reattachToCurrentActivity(activity);
        }
    }

    // ========================================================================
    // State Listeners
    // ========================================================================

    /**
     * Adds a toast state listener.
     *
     * <p>The listener receives the current state immediately after
     * registration.</p>
     *
     * @param listener Listener to add
     */
    public static void addStateListener(@NonNull ToastStateListener listener) {
        ToastManager toastManager = getInstance();
        toastManager.mStateListeners.add(listener);
        State currentState = toastManager.mState.get();
        listener.onStateChanged(currentState, currentState);
    }

    /**
     * Removes a toast state listener.
     *
     * @param listener Listener to remove
     */
    public static void removeStateListener(@NonNull ToastStateListener listener) {
        getInstance().mStateListeners.remove(listener);
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /**
     * Returns a unique key for the given activity.
     *
     * <p>Returns {@link #KEY_ROOT_VIEW_ONLY} when the activity is null,
     * so a root-view-only toast has its own slot in the overlay map.</p>
     *
     * @param activity Activity to build a key for, or null
     * @return The key
     */
    @NonNull
    private static String getActivityKey(@Nullable Activity activity) {
        if (activity == null) {
            return KEY_ROOT_VIEW_ONLY;
        }
        return activity.getClass().getName() + "@" + System.identityHashCode(activity);
    }

    /**
     * Returns the temporary-toast key for the given activity.
     *
     * @param activity Activity to build a key for, or null
     * @return The temporary-toast key
     */
    @NonNull
    private static String getTempToastKey(@Nullable Activity activity) {
        return KEY_TEMP_TOAST_PREFIX + getActivityKey(activity);
    }

    // ========================================================================
    // Overlay Removal Methods
    // ========================================================================

    /**
     * Removes every overlay view from the map and detaches every view.
     *
     * <p>Does not touch the operation stack. Cancels every pending
     * auto-dismiss and transitions the state to
     * {@link State#HIDDEN}.</p>
     */
    private void removeAllOverlayViews() {
        for (OverlayHolder holder : mOverlayMap.values()) {
            holder.cleanup();
        }
        mOverlayMap.clear();

        for (Runnable pending : mPendingAutoDismiss.values()) {
            mMainHandler.removeCallbacks(pending);
        }
        mPendingAutoDismiss.clear();

        transitionTo(State.HIDDEN);
    }

    /**
     * Removes every persistent overlay view from the map.
     *
     * @param animate True to fade the overlays out before removing them
     */
    private void removePersistentOverlayViews(boolean animate) {
        List<String> keysToRemove = new ArrayList<>();
        for (Map.Entry<String, OverlayHolder> entry : mOverlayMap.entrySet()) {
            if (entry.getValue().isPersistent) {
                keysToRemove.add(entry.getKey());
            }
        }

        for (String key : keysToRemove) {
            OverlayHolder holder = mOverlayMap.remove(key);
            if (holder == null) {
                continue;
            }
            if (animate) {
                FrameLayout overlay = holder.overlayRef.get();
                if (overlay != null) {
                    AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
                    fadeOut.setDuration(FADE_DURATION_MS);
                    fadeOut.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {
                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            removeOverlayView(overlay);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {
                        }
                    });
                    overlay.startAnimation(fadeOut);
                }
            } else {
                holder.cleanup();
            }
        }

        recomputeStateFromMap();
    }

    /**
     * Removes every overlay view immediately, without animation, clears
     * the operation stack, and tears down the mirrored library
     * notification unconditionally.
     */
    private void forceHideAllOverlays() {
        removeAllOverlayViews();
        clearOperationStack();

        if (sApplication != null) {
            NotificationController.getInstance(sApplication).clearLibraryStatus();
        }
    }

    // ========================================================================
    // View Management
    // ========================================================================

    /**
     * Creates an overlay view and attaches it to the given root view
     * under the given key.
     *
     * <p>Replaces any existing holder for the same key. The overlay is
     * positioned above the bottom edge of the window and fades in. The
     * vertical position is chosen by {@link #resolveBottomMarginDp()}.
     * The horizontal span is chosen by
     * {@link #resolveAvailableToastWidthPx(ViewGroup)}; the text view is
     * measured against that span and ellipsizes only when its content
     * genuinely exceeds it.</p>
     *
     * @param activity Activity the overlay belongs to, or null for a
     *        root-view-only toast
     * @param rootView View group to attach the overlay to
     * @param message Text to display
     * @param isPersistent True for a persistent overlay, false for a
     *        temporary toast
     * @param key Overlay map key for the new holder
     * @param operationId Operation ID the overlay is bound to, or null
     */
    private void createOverlayInView(@Nullable Activity activity,
                                     @NonNull ViewGroup rootView,
                                     @NonNull String message,
                                     boolean isPersistent,
                                     @NonNull String key,
                                     @Nullable String operationId) {
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        containerParams.bottomMargin = dpToPx(
                rootView.getContext(), resolveBottomMarginDp());
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, 0);

        final int availableWidthPx =
            resolveAvailableToastWidthPx(rootView);

        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(1);
        textView.setHorizontallyScrolling(false);
        textView.setMaxWidth(availableWidthPx);
        textView.setPadding(
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP)
        );
        textView.setTextColor(getThemeColor());

        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(TOAST_BACKGROUND_COLOR);
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(
            dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP),
            TOAST_STROKE_COLOR);
        textView.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }

        container.addView(textView);
        rootView.addView(container);

        mOverlayMap.put(key, new OverlayHolder(
            container, textView, activity, rootView, message, operationId,
            isPersistent));
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime());

        if (activity != null) {
            mCurrentActivityRef = new WeakReference<>(activity);
        }

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
    }

    /**
     * Creates a fresh persistent overlay for the given activity and
     * installs the current top-of-stack message in it.
     *
     * @param activity Activity to attach the overlay to
     */
    private void reattachToActivity(@NonNull Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        String topId = getCurrentOperationId();
        if (topId == null) {
            Log.w(TAG, "Cannot reattach - stack is empty");
            return;
        }

        String message = mOperationMessages.get(topId);
        if (message == null) {
            Log.w(TAG, "Cannot reattach - no message available");
            return;
        }

        String key = getActivityKey(activity);
        OverlayHolder existing = mOverlayMap.remove(key);
        if (existing != null) {
            existing.cleanup();
        }

        ViewGroup root = (ViewGroup) activity.getWindow()
            .getDecorView().findViewById(android.R.id.content);
        if (root == null) {
            Log.w(TAG, "Content view not found for reattachment");
            return;
        }

        createOverlayInView(activity, root, message, true, key, topId);
        mCurrentActivityRef = new WeakReference<>(activity);

        State currentState = mState.get();
        if (currentState != State.SHOWING_PERSISTENT) {
            transitionTo(State.SHOWING_PERSISTENT);
        }
    }

    /**
     * Removes the given overlay view from its parent.
     *
     * @param overlay Overlay view to remove
     */
    private void removeOverlayView(@NonNull FrameLayout overlay) {
        if (overlay.getParent() != null) {
            try {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            } catch (Exception ignored) {
                // The view was already detached.
            }
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param context Context used to read the display metrics
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    /**
     * Returns the available width a toast may occupy, in pixels.
     *
     * <p>Reads the content view's measured width when it has been laid
     * out, so a toast in a split-screen window is bounded by the window
     * rather than by the display. Falls back to the display width when
     * the content view has not yet been measured.</p>
     *
     * <p>The app's standard 16dp inset is subtracted on each side. The
     * width returned is the maximum the toast may occupy; the toast
     * itself wraps to its content, so a short message produces a short
     * toast and a long message uses the full span before it
     * ellipsizes.</p>
     *
     * @param rootView Content view the toast will be attached to
     * @return The available width in pixels
     */
    private int resolveAvailableToastWidthPx(@NonNull ViewGroup rootView) {
        final Context context = rootView.getContext();
        final int measuredWidth = rootView.getWidth();
        final int baseWidth = measuredWidth > 0
            ? measuredWidth
            : rootView.getResources().getDisplayMetrics().widthPixels;
        final int insetPx = dpToPx(context, TOAST_HORIZONTAL_INSET_DP);
        return Math.max(0, baseWidth - insetPx * 2);
    }

    // ========================================================================
    // Debug
    // ========================================================================

    /**
     * Returns a human-readable snapshot of the manager's current state.
     *
     * @return A multi-line string describing the state machine, the
     *         operation stack, the current activity, the number of
     *         active overlays, and the listener count
     */
    @NonNull
    public String getDebugInfo() {
        Activity currentActivity = mCurrentActivityRef != null
            ? mCurrentActivityRef.get() : null;
        int persistentCount = 0;
        int tempCount = 0;
        for (OverlayHolder holder : mOverlayMap.values()) {
            if (holder.isPersistent) {
                persistentCount++;
            } else {
                tempCount++;
            }
        }
        return "ToastManager\n"
                + "State: " + mState.get() + "\n"
                + "State duration: "
                + (SystemClock.elapsedRealtime() - mStateStartTime.get()) + "ms\n"
                + "Last activity: "
                + (SystemClock.elapsedRealtime() - mLastActivityTime.get()) + "ms ago\n"
                + "Last valid overlay: "
                + (SystemClock.elapsedRealtime() - mLastValidOverlayTime.get()) + "ms ago\n"
                + "Operation stack size: " + mOperationOrder.size() + "\n"
                + "Top operation: " + getCurrentOperationId() + "\n"
                + "Current activity: "
                + (currentActivity != null
                    ? currentActivity.getClass().getSimpleName() : "null") + "\n"
                + "Persistent overlays: " + persistentCount + "\n"
                + "Temporary toasts: " + tempCount + "\n"
                + "Pending dismissals: " + mPendingAutoDismiss.size() + "\n"
                + "Listeners: " + mStateListeners.size();
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Releases every resource held by the manager.
     *
     * <p>Stops the health check, cancels recovery and every pending
     * auto-dismiss, unregisters lifecycle callbacks and the theme
     * receiver, hides any active overlay, clears the operation stack,
     * and clears the singleton reference.</p>
     */
    public static void shutdown() {
        ToastManager toastManager = getInstance();
        Log.d(TAG, "Shutting down ToastManager");

        for (Runnable pending : toastManager.mPendingAutoDismiss.values()) {
            toastManager.mMainHandler.removeCallbacks(pending);
        }
        toastManager.mPendingAutoDismiss.clear();

        toastManager.cancelRecovery();

        if (toastManager.mHealthCheckRunnable != null) {
            toastManager.mHealthHandler.removeCallbacks(toastManager.mHealthCheckRunnable);
            toastManager.mHealthCheckRunnable = null;
        }

        if (toastManager.mCallbacksRegistered && sApplication != null) {
            try {
                sApplication.unregisterActivityLifecycleCallbacks(toastManager);
                toastManager.mCallbacksRegistered = false;
            } catch (Exception ignored) {
                // The callbacks were already unregistered.
            }
        }

        if (toastManager.mThemeReceiver != null && sApplication != null) {
            try {
                sApplication.unregisterReceiver(toastManager.mThemeReceiver);
                toastManager.mThemeReceiver = null;
            } catch (Exception ignored) {
                // The receiver was already unregistered.
            }
        }

        toastManager.forceHideAllOverlays();

        sInstance = null;
        sApplication = null;
        Log.d(TAG, "ToastManager shut down complete");
    }
}