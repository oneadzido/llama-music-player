package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Adapter for displaying the playlist in a RecyclerView.
 *
 * <p>This adapter binds song data to list items and handles visual styling
 * for the currently playing song. It provides smooth scrolling, touch feedback,
 * and theme color integration.</p>
 *
 * <h3>RecyclerView Best Practices</h3>
 * <p>This adapter implements several Android RecyclerView best practices to ensure
 * smooth scrolling and a responsive user interface:</p>
 *
 * <ul>
 *   <li><b>Stable IDs:</b> Uses setHasStableIds(true) with song paths as stable
 *       identifiers, allowing RecyclerView to track items correctly across updates
 *       and maintain proper animation state.</li>
 *   <li><b>DiffUtil for List Updates:</b> Instead of calling notifyDataSetChanged(),
 *       the adapter uses DiffUtil to calculate minimal changes between old and new
 *       lists, resulting in smooth animations and better performance.</li>
 *   <li><b>Payload-Based Partial Updates:</b> Genre updates use notifyItemChanged()
 *       with a PAYLOAD_GENRE payload, which updates only the subtitle TextView
 *       without causing a full item rebind or layout re-measurement.</li>
 *   <li><b>Fixed Row Heights:</b> Uses maxLines="1" and ellipsize="end" in the
 *       item layout to ensure consistent row height even when text changes,
 *       preventing layout shifts during updates.</li>
 *   <li><b>Queue Sorting:</b> Batches genre updates during loading, applying all
 *       at once when loading completes to prevent multiple UI refreshes.</li>
 * </ul>
 *
 * <h3>State Ownership</h3>
 * <p>The adapter holds two pieces of presentation state, both set by the
 * owning activity:</p>
 * <ul>
 *   <li><b>{@code mCurrentPlayingPath}</b> — set via
 *       {@link #setCurrentPlayingPath(String)} or
 *       {@link #setCurrentPlayingIndex(int)}. The adapter does not read or
 *       write {@code SharedPreferences}; the activity pushes the state.</li>
 *   <li><b>Genre loading flag</b> — set via {@link #setGenreLoading(boolean)}.
 *       The adapter does not query the source of this flag.</li>
 * </ul>
 * <p>The theme color is not cached; it is queried from
 * {@link ThemeManager} on every full bind. Theme changes trigger a rebind
 * from the activity, and the query reflects the new value.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>This adapter uses CopyOnWriteArrayList for thread-safe list access, allowing
 * updates from background threads without concurrent modification exceptions.
 * All UI operations are performed on the main thread as required by RecyclerView.</p>
 *
 * <h3>Visual Styling</h3>
 * <p>The adapter provides distinct visual states for different item types:</p>
 * <ul>
 *   <li><b>Currently Playing Song:</b> Dark background (#1E1E1E), theme-colored title,
 *       light gray subtitle, divider hidden</li>
 *   <li><b>Non-Playing Songs:</b> Transparent background, light gray title (#C0C0C0),
 *       dark gray subtitle (#808080), divider visible</li>
 * </ul>
 *
 * @see PlaylistActivity
 * @see Song
 * @see ThemeManager
 * @see DiffUtil
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Default theme color (Royal Llama) used when ThemeManager is unavailable. */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";

    /** Background color for the currently playing song item (dark gray). */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";

    /** Touch highlight color when pressing a list item (lighter gray). */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for song titles in non-current items. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Dark gray text color for subtitle text in non-current items. */
    private static final String TEXT_COLOR_DARK = "#808080";

    /** Separator string used between metadata fields (artist, album, genre). */
    private static final String METADATA_SEPARATOR = " \u2022 ";

    /** Debounce delay for song click events to prevent rapid multiple clicks. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;

    /** Payload identifier for genre-only updates (partial refresh without relayout). */
    private static final String PAYLOAD_GENRE = "genre_update";

    // ========================================================================
    // Member Variables (Thread-Safe)
    // ========================================================================

    /** Thread-safe list of songs displayed in the playlist. */
    private final CopyOnWriteArrayList<Song> mSongs;

    /** Application context for accessing resources. */
    private final Context mContext;

    /** Listener for song click events, or null if not set. */
    @Nullable private final OnSongClickListener mListener;

    /** Path of the currently playing/selected song (null if none). */
    @Nullable private volatile String mCurrentPlayingPath = null;

    // ========================================================================
    // Genre Loading Batching
    // ========================================================================

    /** Flag indicating if genre loading is in progress (Phase 2). */
    private volatile boolean mIsGenreLoading = false;

    /** Pending genre updates to apply after loading completes. */
    private final Map<String, String> mPendingGenreUpdates = new HashMap<>();

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Listener interface for song click events.
     */
    public interface OnSongClickListener {

        /**
         * Called when a song item is clicked.
         *
         * @param position The position of the clicked song in the adapter
         * @param song The Song object representing the clicked song
         */
        void onSongClick(int position, @NonNull Song song);
    }

    // ========================================================================
    // ViewHolder Class
    // ========================================================================

    /**
     * ViewHolder for song items in the playlist.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        /** Container layout for the entire list item. */
        final LinearLayout mContentLayout;

        /** TextView displaying the song title (android.R.id.text1). */
        final TextView mTitle;

        /** TextView displaying the subtitle (android.R.id.text2). */
        final TextView mSubtitle;

        /** Divider view between list items. */
        final View mDivider;

        /**
         * Constructs a new ViewHolder.
         *
         * @param view The item view inflated from item_song.xml
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }

    // ========================================================================
    // DiffUtil Callback for Smooth Updates
    // ========================================================================

    /**
     * DiffUtil callback for calculating differences between old and new song lists.
     */
    private static class SongDiffCallback extends DiffUtil.Callback {

        /** The old song list. */
        private final List<Song> oldList;

        /** The new song list. */
        private final List<Song> newList;

        /**
         * Constructs a new SongDiffCallback.
         *
         * @param oldList The old song list
         * @param newList The new song list
         */
        SongDiffCallback(List<Song> oldList, List<Song> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        /**
         * Returns the size of the old list.
         *
         * @return Old list size
         */
        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        /**
         * Returns the size of the new list.
         *
         * @return New list size
         */
        @Override
        public int getNewListSize() {
            return newList.size();
        }

        /**
         * Checks if two items represent the same song.
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return True if both positions refer to the same song
         */
        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            String oldPath = oldList.get(oldItemPosition).getPath();
            String newPath = newList.get(newItemPosition).getPath();
            return oldPath.equals(newPath);
        }

        /**
         * Checks if the content of two items is the same.
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return True if all content fields are the same
         */
        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            return oldSong.getGenre().equals(newSong.getGenre());
        }

        /**
         * Returns a payload for items that are content-different.
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return The payload (PAYLOAD_GENRE) for genre-only updates
         */
        @Nullable
        @Override
        public Object getChangePayload(int oldItemPosition, int newItemPosition) {
            return PAYLOAD_GENRE;
        }
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new PlaylistAdapter.
     *
     * <p>The adapter starts with no current-playing path. The owning
     * activity pushes the initial and subsequent values through
     * {@link #setCurrentPlayingIndex(int)} or
     * {@link #setCurrentPlayingPath(String)}.</p>
     *
     * @param context The application context
     * @param songs The initial list of songs to display
     * @param listener Listener for song click events (can be null)
     */
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs,
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;

        setHasStableIds(true);
    }

    // ========================================================================
    // RecyclerView.Adapter Methods (Called on UI Thread)
    // ========================================================================

    /**
     * Returns a stable ID for the item at the given position.
     *
     * @param position The position in the list
     * @return A stable ID for the item
     */
    @Override
    public long getItemId(int position) {
        Song song = mSongs.get(position);
        return song != null ? song.getPath().hashCode() : position;
    }

    /**
     * Creates a new ViewHolder for a song item.
     *
     * @param parent The parent ViewGroup into which the new view will be added
     * @param viewType The view type (not used, all items are the same)
     * @return A new ViewHolder for the song item
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Binds song data to a ViewHolder at the specified position (fallback).
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        onBindViewHolder(holder, position, null);
    }

    /**
     * Binds song data to a ViewHolder with payload support for partial updates.
     *
     * <p>When a payload (e.g., PAYLOAD_GENRE) is provided, only the subtitle
     * TextView is updated. This prevents the RecyclerView from re-measuring
     * the entire item, which would cause scroll position jumps when text
     * length changes during genre updates.</p>
     *
     * <p>On a full bind, the theme color is queried from {@link ThemeManager}
     * rather than read from a cache. Theme changes trigger a rebind from the
     * activity, so the query reflects the current value.</p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     * @param payloads List of payload objects for partial updates
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull List<Object> payloads) {
        if (position < 0 || position >= mSongs.size()) return;

        final Song song = mSongs.get(position);
        if (song == null) return;

        boolean isGenreOnlyUpdate = payloads != null && !payloads.isEmpty() && payloads.contains(PAYLOAD_GENRE);

        if (!isGenreOnlyUpdate) {
            String title = song.getTitle();
            holder.mTitle.setText((title != null && !title.isEmpty()) ? title : "Unknown Title");

            String currentPath = mCurrentPlayingPath;
            boolean isCurrent = (currentPath != null && currentPath.equals(song.getPath()));

            String themeColor = resolveThemeColor();

            if (isCurrent) {
                holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                holder.mTitle.setTextColor(Color.parseColor(themeColor));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mDivider.setVisibility(View.GONE);
            } else {
                holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
                holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
                holder.mDivider.setVisibility(View.VISIBLE);
            }

            final boolean isCurrentForTouch = isCurrent;
            holder.mContentLayout.setOnTouchListener((view, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isCurrentForTouch) {
                            view.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                        } else {
                            view.setBackgroundColor(Color.TRANSPARENT);
                        }
                        break;
                }
                return false;
            });

            holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
                private long lastClickTime = 0;

                @Override
                public void onClick(final View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    lastClickTime = currentTime;

                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition == RecyclerView.NO_POSITION || adapterPosition >= mSongs.size()) return;

                    final Song clickedSong = mSongs.get(adapterPosition);
                    if (clickedSong == null) return;

                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                               .scaleY(ANIMATION_SCALE_DOWN)
                               .setDuration(ANIMATION_DURATION_MS)
                               .withEndAction(() -> {
                                   view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                             .scaleY(ANIMATION_SCALE_NORMAL)
                                             .setDuration(ANIMATION_DURATION_MS)
                                             .start();
                               }).start();

                    if (mListener != null) {
                        mListener.onSongClick(adapterPosition, clickedSong);
                    }
                }
            });
        }

        StringBuilder subtitle = new StringBuilder();

        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }

        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }

        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }

        holder.mSubtitle.setText(subtitle.toString());
    }

    /**
     * Returns the total number of items in the playlist.
     *
     * @return The number of songs in the adapter
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }

    // ========================================================================
    // Public Methods (Thread-Safe)
    // ========================================================================

    /**
     * Replaces the entire song list with a new list using DiffUtil for smooth updates.
     *
     * @param newSongs The new list of songs to display
     */
    public void updateList(@NonNull List<Song> newSongs) {
        List<Song> oldList = new ArrayList<>(mSongs);
        List<Song> newList = new ArrayList<>(newSongs);

        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new SongDiffCallback(oldList, newList));

        mSongs.clear();
        mSongs.addAll(newList);

        diffResult.dispatchUpdatesTo(this);
    }

    /**
     * Sets the currently playing song by its path.
     *
     * <p>The adapter does not persist this value. It is a presentation hint
     * pushed by the owning activity; the activity is responsible for
     * obtaining the value from the authoritative source
     * ({@link MusicService}).</p>
     *
     * @param songPath The path of the currently playing song (null for none)
     */
    public void setCurrentPlayingPath(@Nullable String songPath) {
        String oldPath = mCurrentPlayingPath;
        mCurrentPlayingPath = songPath;

        if (oldPath != null) {
            int oldPosition = findPositionByPath(oldPath);
            if (oldPosition >= 0 && oldPosition < mSongs.size()) {
                notifyItemChanged(oldPosition);
            }
        }
        if (songPath != null) {
            int newPosition = findPositionByPath(songPath);
            if (newPosition >= 0 && newPosition < mSongs.size()) {
                notifyItemChanged(newPosition);
            }
        }
    }

    /**
     * Returns the path of the currently playing song.
     *
     * @return The current playing path, or null if none
     */
    @Nullable
    public String getCurrentPlayingPath() {
        return mCurrentPlayingPath;
    }

    /**
     * Finds a song's position by its file path.
     *
     * @param songPath The path to search for
     * @return The position index, or -1 if not found
     */
    private int findPositionByPath(@Nullable String songPath) {
        if (songPath == null || mSongs == null) {
            return -1;
        }
        for (int index = 0; index < mSongs.size(); index++) {
            Song song = mSongs.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Returns the song at the specified position.
     *
     * @param position The position in the list
     * @return The Song object, or null if position is invalid
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }

    /**
     * Sets whether genre loading is in progress.
     *
     * @param loading True if genre loading is in progress
     */
    public void setGenreLoading(boolean loading) {
        mIsGenreLoading = loading;
        if (!loading && !mPendingGenreUpdates.isEmpty()) {
            for (Map.Entry<String, String> entry : mPendingGenreUpdates.entrySet()) {
                applyGenreUpdate(entry.getKey(), entry.getValue(), true);
            }
            mPendingGenreUpdates.clear();
        }
    }

    /**
     * Applies a genre update to a specific song with payload-based partial update.
     *
     * @param songPath The path of the song to update
     * @param newGenre The new genre value
     * @param notify True to notify the adapter with payload
     */
    private void applyGenreUpdate(String songPath, String newGenre, boolean notify) {
        int position = findPositionByPath(songPath);
        if (position >= 0 && position < mSongs.size()) {
            Song song = mSongs.get(position);
            if (song != null) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    if (notify) {
                        notifyItemChanged(position, PAYLOAD_GENRE);
                    }
                }
            }
        }
    }

    /**
     * Updates the genre of a specific song.
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value from ID3 tags
     */
    public void updateSongGenre(String songPath, String newGenre) {
        if (mIsGenreLoading) {
            mPendingGenreUpdates.put(songPath, newGenre);
        } else {
            applyGenreUpdate(songPath, newGenre, true);
        }
    }

    // ========================================================================
    // Backward Compatibility Methods
    // ========================================================================

    /**
     * @deprecated Use {@link #setCurrentPlayingPath(String)} instead.
     * Kept for backward compatibility with older code.
     */
    @Deprecated
    public void setCurrentPlayingIndex(int index) {
        if (index >= 0 && index < mSongs.size()) {
            Song song = mSongs.get(index);
            if (song != null) {
                setCurrentPlayingPath(song.getPath());
            }
        } else {
            setCurrentPlayingPath(null);
        }
    }

    /**
     * @deprecated Use {@link #getCurrentPlayingPath()} instead.
     * Kept for backward compatibility with older code.
     */
    @Deprecated
    public int getCurrentPlayingIndex() {
        if (mCurrentPlayingPath != null) {
            return findPositionByPath(mCurrentPlayingPath);
        }
        return -1;
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Resolves the current theme color, falling back to the default.
     *
     * @return the theme color as a hex string
     */
    @NonNull
    private String resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                String color = themeManager.getCurrentColor();
                if (color != null && !color.isEmpty()) {
                    return color;
                }
            }
            return DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }
}