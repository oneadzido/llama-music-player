package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Adapter for displaying the playlist in a RecyclerView.
 * 
 * <p>This adapter binds song data to list items and handles visual styling
 * for the currently playing song. It provides smooth scrolling, touch feedback,
 * and theme color integration.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This adapter uses CopyOnWriteArrayList for thread-safe list access.
 * All UI operations are performed on the main thread as required by RecyclerView.
 * Theme color caching uses volatile for visibility.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Thread-safe song list using CopyOnWriteArrayList</li>
 *   <li>Visual highlighting for currently playing song (dark background, theme-colored title)</li>
 *   <li>Touch feedback with background color changes on press</li>
 *   <li>Click debouncing to prevent rapid repeated clicks</li>
 *   <li>Theme color caching for performance</li>
 *   <li>Real-time genre updates using payload-based partial updates to prevent scroll jumps</li>
 *   <li>Divider visibility control for current song</li>
 *   <li>Genre loading batching to prevent scroll jitter during Phase 2</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name for storing playback state. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index in SharedPreferences. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Default theme color (Royal Llama) used when ThemeManager is unavailable. */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    
    /** Background color for the currently playing song item (dark gray). */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";
    
    /** Touch highlight color when pressing a list item (lighter gray). */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    /** Light gray text color for song titles in non-current items. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Dark gray text color for subtitle text in non-current items. */
    private static final String TEXT_COLOR_DARK = "#808080";
    
    /** Separator string used between metadata fields (artist, album, genre). */
    private static final String METADATA_SEPARATOR = " • ";
    
    /** Debounce delay for song click events to prevent rapid multiple clicks. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;
    
    /** Payload identifier for genre-only updates (partial refresh without relayout). */
    private static final String PAYLOAD_GENRE = "genre_update";
    
    // ========================================================================
    // Member Variables (Thread-Safe)
    // ========================================================================
    
    /** Thread-safe list of songs displayed in the playlist. */
    private final CopyOnWriteArrayList<Song> mSongs;
    
    /** Application context for accessing resources and SharedPreferences. */
    private final Context mContext;
    
    /** Listener for song click events, or null if not set. */
    @Nullable private final OnSongClickListener mListener;
    
    /** Index of the currently playing/selected song (-1 if none). */
    private volatile int mCurrentPlayingIndex = -1;
    
    /** Cached theme color string for performance (avoids repeated ThemeManager lookups). */
    private volatile String mCachedThemeColor = DEFAULT_THEME_COLOR;
    
    // ========================================================================
    // Genre Loading Batching (Prevents Scroll Jitter During Phase 2)
    // ========================================================================
    
    /** 
     * Flag indicating if genre loading is in progress (Phase 2).
     * When true, individual genre updates are batched to prevent multiple
     * adapter notifications that would cause scroll jitter.
     */
    private volatile boolean mIsGenreLoading = false;
    
    /** 
     * Pending genre updates to apply after loading completes.
     * Maps song path -> new genre value.
     */
    private final Map<String, String> mPendingGenreUpdates = new HashMap<>();
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for song click events.
     * 
     * <p>Activities using this adapter must implement this interface
     * to handle song selection and playback.</p>
     */
    public interface OnSongClickListener {
        
        /**
         * Called when a song item is clicked.
         *
         * @param position The position of the clicked song in the adapter
         * @param song The Song object representing the clicked song
         */
        void onSongClick(int position, @NonNull Song song);
    }
    
    // ========================================================================
    // ViewHolder Class
    // ========================================================================
    
    /**
     * ViewHolder for song items in the playlist.
     * 
     * <p>Caches references to the views within each item layout to
     * improve performance during scrolling.</p>
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        
        /** Container layout for the entire list item (handles background and touch). */
        final LinearLayout mContentLayout;
        
        /** TextView displaying the song title (android.R.id.text1). */
        final TextView mTitle;
        
        /** TextView displaying the subtitle (artist, album, genre) (android.R.id.text2). */
        final TextView mSubtitle;
        
        /** Divider view between list items (hidden for the currently playing song). */
        final View mDivider;
        
        /**
         * Constructs a new ViewHolder.
         *
         * @param view The item view inflated from item_song.xml
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }
    
    // ========================================================================
    // DiffUtil Callback for Smooth Updates
    // ========================================================================
    
    /**
     * DiffUtil callback for calculating differences between old and new song lists.
     * 
     * <p>This class enables efficient RecyclerView updates by calculating exactly
     * which items have changed, moved, or been added/removed. During Phase 2
     * (genre loading), only the genre field changes, so items are considered
     * content-different but with a payload that triggers only subtitle updates.</p>
     */
    private static class SongDiffCallback extends DiffUtil.Callback {
        
        /** The old song list. */
        private final List<Song> oldList;
        
        /** The new song list. */
        private final List<Song> newList;

        /**
         * Constructs a new SongDiffCallback.
         *
         * @param oldList The old song list
         * @param newList The new song list
         */
        SongDiffCallback(List<Song> oldList, List<Song> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        /**
         * Returns the size of the old list.
         *
         * @return Old list size
         */
        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        /**
         * Returns the size of the new list.
         *
         * @return New list size
         */
        @Override
        public int getNewListSize() {
            return newList.size();
        }

        /**
         * Checks if two items represent the same song.
         * Uses the file path as the stable identifier.
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return True if both positions refer to the same song
         */
        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            return oldList.get(oldItemPosition).getPath()
                    .equals(newList.get(newItemPosition).getPath());
        }

        /**
         * Checks if the content of two items is the same.
         * During Phase 2, only the genre field changes.
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return True if all content fields are the same
         */
        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            return oldSong.getGenre().equals(newSong.getGenre());
        }

        /**
         * Returns a payload for items that are content-different.
         * This payload tells the adapter to update only the subtitle (genre).
         *
         * @param oldItemPosition Position in old list
         * @param newItemPosition Position in new list
         * @return The payload (PAYLOAD_GENRE) for genre-only updates
         */
        @Nullable
        @Override
        public Object getChangePayload(int oldItemPosition, int newItemPosition) {
            return PAYLOAD_GENRE;
        }
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PlaylistAdapter.
     *
     * @param context The application context
     * @param songs The initial list of songs to display
     * @param listener Listener for song click events (can be null)
     */
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs, 
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;
        setHasStableIds(true);
        loadCurrentPlayingIndex();
        loadThemeColor();
    }
    
    // ========================================================================
    // RecyclerView.Adapter Methods (Called on UI Thread)
    // ========================================================================
    
    /**
     * Returns a stable ID for the item at the given position.
     * Uses the song's path hash code as the stable ID for better RecyclerView behavior.
     *
     * @param position The position in the list
     * @return A stable ID for the item
     */
    @Override
    public long getItemId(int position) {
        Song song = mSongs.get(position);
        return song != null ? song.getPath().hashCode() : position;
    }
    
    /**
     * Creates a new ViewHolder for a song item.
     * 
     * <p>Called by RecyclerView when it needs a new ViewHolder.
     * Inflates the item_song layout and creates a new ViewHolder instance.</p>
     *
     * @param parent The parent ViewGroup into which the new view will be added
     * @param viewType The view type (not used, all items are the same)
     * @return A new ViewHolder for the song item
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }
    
    /**
     * Binds song data to a ViewHolder at the specified position (fallback).
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        onBindViewHolder(holder, position, null);
    }
    
    /**
     * Binds song data to a ViewHolder with payload support for partial updates.
     * 
     * <p>This method is called by RecyclerView to display data at a specific position.
     * It sets the song title, builds the subtitle string (Artist • Album • Genre),
     * applies appropriate styling based on whether this is the currently playing song,
     * and sets up touch feedback and click listeners.</p>
     * 
     * <p><b>Payload Support:</b> When a payload (e.g., PAYLOAD_GENRE) is provided,
     * only the subtitle TextView is updated. This prevents the RecyclerView from
     * re-measuring the entire item, which would cause scroll position jumps when
     * text length changes during genre updates.</p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     * @param payloads List of payload objects for partial updates (e.g., "genre_update")
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull List<Object> payloads) {
        if (position < 0 || position >= mSongs.size()) return;
        
        final Song song = mSongs.get(position);
        if (song == null) return;
        
        // Check if this is a partial update (genre only)
        boolean isGenreOnlyUpdate = payloads != null && !payloads.isEmpty() && payloads.contains(PAYLOAD_GENRE);
        
        if (!isGenreOnlyUpdate) {
            // ====================================================================
            // FULL BIND - Set title and all styling (only happens on initial bind or sort)
            // ====================================================================
            
            // Set song title with fallback for null/empty values
            String title = song.getTitle();
            holder.mTitle.setText((title != null && !title.isEmpty()) ? title : "Unknown Title");
            
            final boolean isCurrent = (position == mCurrentPlayingIndex);
            
            // Update and apply theme color for the current song's title
            updateThemeColor();
            String themeColor = mCachedThemeColor;
            
            if (isCurrent) {
                // Currently playing song: dark background, theme-colored title, hide divider
                holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                holder.mTitle.setTextColor(Color.parseColor(themeColor));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mDivider.setVisibility(View.GONE);
            } else {
                // Non-current song: transparent background, light gray title, show divider
                holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
                holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
                holder.mDivider.setVisibility(View.VISIBLE);
            }
            
            // Touch feedback: highlight background on press, revert on release
            final boolean isCurrentForTouch = (position == mCurrentPlayingIndex);
            holder.mContentLayout.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isCurrentForTouch) {
                            v.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                        } else {
                            v.setBackgroundColor(Color.TRANSPARENT);
                        }
                        break;
                }
                return false;
            });
            
            // Click listener with debouncing to prevent rapid multiple clicks
            holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
                private long lastClickTime = 0;
                
                @Override
                public void onClick(final View v) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                    lastClickTime = currentTime;
                    
                    int pos = holder.getAdapterPosition();
                    if (pos == RecyclerView.NO_POSITION || pos >= mSongs.size()) return;
                    
                    final Song clickedSong = mSongs.get(pos);
                    if (clickedSong == null) return;
                    
                    // Bounce animation on click
                    v.animate().scaleX(ANIMATION_SCALE_DOWN)
                               .scaleY(ANIMATION_SCALE_DOWN)
                               .setDuration(ANIMATION_DURATION_MS)
                               .withEndAction(() -> {
                                   v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                             .scaleY(ANIMATION_SCALE_NORMAL)
                                             .setDuration(ANIMATION_DURATION_MS)
                                             .start();
                               }).start();
                    
                    if (mListener != null) {
                        mListener.onSongClick(pos, clickedSong);
                    }
                }
            });
        }
        
        // ====================================================================
        // SUBTITLE UPDATE (Always performed for both full and partial binds)
        // ====================================================================
        
        // Build subtitle string: Artist • Album • Genre
        StringBuilder subtitle = new StringBuilder();
        
        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }
        
        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }
        
        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }
        
        holder.mSubtitle.setText(subtitle.toString());
    }
    
    /**
     * Returns the total number of items in the playlist.
     *
     * @return The number of songs in the adapter
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }
    
    // ========================================================================
    // Public Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Replaces the entire song list with a new list using DiffUtil for smooth updates.
     * This prevents scroll jitter during genre loading by batching all notifications
     * into a single layout pass.
     *
     * @param newSongs The new list of songs to display
     */
    public void updateList(@NonNull List<Song> newSongs) {
        List<Song> oldList = new ArrayList<>(mSongs);
        List<Song> newList = new ArrayList<>(newSongs);
        
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new SongDiffCallback(oldList, newList));
        
        mSongs.clear();
        mSongs.addAll(newList);
        
        diffResult.dispatchUpdatesTo(this);
    }
    
    /**
     * Sets the index of the currently playing song.
     * 
     * <p>This method updates the visual highlighting for both the old and new
     * current song positions. It saves the index to SharedPreferences for
     * persistence across app restarts.</p>
     *
     * @param index The new current playing index (-1 for none)
     */
    public void setCurrentPlayingIndex(int index) {
        int oldIndex = mCurrentPlayingIndex;
        mCurrentPlayingIndex = index;
        saveCurrentPlayingIndex(index);
        
        // Notify both old and new positions to update their visual styling
        if (oldIndex >= 0 && oldIndex < mSongs.size()) {
            notifyItemChanged(oldIndex);
        }
        if (index >= 0 && index < mSongs.size()) {
            notifyItemChanged(index);
        }
    }
    
    /**
     * Returns the index of the currently playing song.
     *
     * @return The current playing index (-1 if none)
     */
    public int getCurrentPlayingIndex() {
        return mCurrentPlayingIndex;
    }
    
    /**
     * Returns the song at the specified position.
     *
     * @param position The position in the list
     * @return The Song object, or null if position is invalid
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }
    
    /**
     * Updates the cached theme color if it has changed.
     * 
     * <p>This method is called during onBindViewHolder to ensure the current
     * song's title uses the correct theme color. If the theme has changed,
     * it updates the cache and refreshes the current song item.</p>
     */
    public void updateThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            String newColor = themeManager.getCurrentColor();
            if (!newColor.equals(mCachedThemeColor)) {
                mCachedThemeColor = newColor;
                // Refresh the current song item to apply the new theme color
                if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
                    notifyItemChanged(mCurrentPlayingIndex);
                }
            }
        } catch (Exception e) {
            // Keep cached color on error - falls back to default
        }
    }
    
    /**
     * Sets whether genre loading is in progress.
     * 
     * <p>When true, individual genre updates are batched into a map instead of
     * notifying the adapter. When loading completes (false), all pending updates
     * are applied INDIVIDUALLY with payload-based partial updates, NOT with
     * notifyDataSetChanged(). This completely eliminates scroll jitter during
     * Phase 2 genre loading.</p>
     *
     * @param loading True if genre loading is in progress
     */
    public void setGenreLoading(boolean loading) {
        mIsGenreLoading = loading;
        if (!loading && !mPendingGenreUpdates.isEmpty()) {
            // Apply all pending genre updates INDIVIDUALLY with payload
            // DO NOT use notifyDataSetChanged() - it causes scroll jitter
            for (Map.Entry<String, String> entry : mPendingGenreUpdates.entrySet()) {
                applyGenreUpdate(entry.getKey(), entry.getValue(), true);
            }
            mPendingGenreUpdates.clear();
        }
    }
    
    /**
     * Applies a genre update to a specific song with payload-based partial update.
     *
     * @param songPath The path of the song to update
     * @param newGenre The new genre value
     * @param notify True to notify the adapter with payload
     */
    private void applyGenreUpdate(String songPath, String newGenre, boolean notify) {
        // Get the path of the currently playing song to skip notifying it
        String currentSongPath = null;
        if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
            Song currentSong = mSongs.get(mCurrentPlayingIndex);
            if (currentSong != null) {
                currentSongPath = currentSong.getPath();
            }
        }
        
        for (int i = 0; i < mSongs.size(); i++) {
            Song song = mSongs.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    if (notify && (currentSongPath == null || !songPath.equals(currentSongPath))) {
                        // Use payload-based partial update - only subtitle changes, no relayout
                        notifyItemChanged(i, PAYLOAD_GENRE);
                    }
                }
                break;
            }
        }
    }
    
    /**
     * Updates the genre of a specific song.
     * 
     * <p>During genre loading (Phase 2), updates are batched to prevent multiple
     * adapter notifications that would cause scroll jitter. When not loading,
     * updates are applied immediately with payload-based partial updates that
     * only refresh the subtitle text without relayout.</p>
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value from ID3 tags
     */
    public void updateSongGenre(String songPath, String newGenre) {
        if (mIsGenreLoading) {
            // Batch during loading phase - prevents scroll jitter
            mPendingGenreUpdates.put(songPath, newGenre);
        } else {
            // Apply immediately when not loading
            applyGenreUpdate(songPath, newGenre, true);
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Loads the saved current playing index from SharedPreferences.
     * 
     * <p>This method is called during adapter construction to restore
     * the playback position from a previous app session.</p>
     */
    private void loadCurrentPlayingIndex() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentPlayingIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     * 
     * <p>This method is called whenever the playing index changes to ensure
     * the playback position is preserved across app restarts and orientation changes.</p>
     *
     * @param index The current playing index to save
     */
    private void saveCurrentPlayingIndex(int index) {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply();
    }
    
    /**
     * Loads the current theme color from ThemeManager.
     * 
     * <p>This method is called during adapter construction to initialize
     * the cached theme color. If ThemeManager is unavailable, falls back
     * to the default Royal Llama color.</p>
     */
    private void loadThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            mCachedThemeColor = themeManager.getCurrentColor();
        } catch (Exception e) {
            mCachedThemeColor = DEFAULT_THEME_COLOR;
        }
    }
}