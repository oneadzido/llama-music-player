// PlaylistAdapter.java
package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Renders playlist rows and highlights the row that matches the current
 * song.
 *
 * <p>Each row shows the song title on the first line and the artist,
 * album, and genre joined by a bullet on the second line. The row whose
 * path matches {@link #mCurrentPlayingPath} uses the current theme color
 * for the title, a dark background, a light subtitle, and no divider.
 * Every other row uses the standard color scheme.</p>
 *
 * <p>The adapter applies minimal updates through {@link DiffUtil} and
 * requests partial rebinds through a payload when only the genre
 * changes, so the list does not re-measure rows while it is being
 * scrolled. When the difference between the old and new list is large
 * — a cold start, a first import, a full rebuild — the adapter replaces
 * the whole list in one step rather than running the diff. See
 * {@link #shouldBulkReplace(List, List)} for the threshold. A caller
 * that already knows the update is a pure reorder can opt out of the
 * diff entirely by calling {@link #updateList(List, boolean)} with
 * {@code reorderOnly = true}; see that method for the reasoning.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The adapter owns three pieces of presentation state, all set by
 * the owning activity:</p>
 * <ul>
 *   <li><b>{@link #mCurrentPlayingPath}</b> — set through
 *       {@link #setCurrentPlayingPath(String)} or
 *       {@link #setCurrentPlayingIndex(int)}. The activity supplies the
 *       value; the adapter holds no copy of it elsewhere.</li>
 *   <li><b>Genre loading flag</b> — set through
 *       {@link #setGenreLoading(boolean)}. The activity supplies the
 *       value.</li>
 *   <li><b>Scroll flag</b> — set through
 *       {@link #setScrolling(boolean)}. The activity supplies the value
 *       from its scroll listener.</li>
 * </ul>
 * <p>The theme color is queried from {@link ThemeManager} on every full
 * bind. Theme changes trigger a rebind from the activity, and the query
 * reflects the new value.</p>
 *
 * <h3>Placeholders and Subtitle Assembly</h3>
 * <p>The subtitle joins the artist, album, and genre with a bullet
 * separator. A field that carries the app's current placeholder for
 * its kind — the value produced by {@link CharacterMapper} when the
 * corresponding tag was absent — is not shown as a real value; the
 * adapter detects it with the corresponding
 * {@code CharacterMapper.isUnknownX(String)} predicate and renders
 * the placeholder in its place. The subtitle therefore never shows
 * a placeholder as if it were an artist, an album, or a genre, and
 * it never loses the space that field occupies.</p>
 *
 * <p>The placeholder's text resolves from
 * {@code R.string.common_unknown_artist} and its siblings in the
 * app's selected language. A German playlist reads "Unbekannter
 * Künstler", an Arabic one reads "فنان غير معروف", and the code path
 * that assembles the subtitle is identical.</p>
 *
 * <h3>Deferred Genre Updates</h3>
 * <p>While the user is scrolling, incoming genre updates are queued
 * rather than applied. Applying a payload-based rebind mid-scroll
 * would call {@link #notifyItemChanged(int)} on a visible row while the
 * scroll animation is still settling, and the current row would appear
 * to jump out of its own position. When scrolling ends, the queue is
 * flushed after {@link #SCROLL_SETTLE_MS} milliseconds.</p>
 *
 * <h3>Idempotent Highlight</h3>
 * <p>{@link #setCurrentPlayingPath(String)} returns early when the
 * requested path is the one already highlighted. The path is the
 * identity of the highlighted row; a repeated assignment would
 * otherwise rebind that row twice — once on the old position and once
 * on the new — for no visible change, and two full-item change
 * animations per call would disturb any in-flight RecyclerView scroll.
 * The guard makes the invariant "a highlight change is signalled at most
 * once per actual change", which is what the RecyclerView expects.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The song list is a {@link CopyOnWriteArrayList}, so reads from the
 * main thread are safe while a background thread adds or removes
 * entries. Every other method runs on the main thread, which is where
 * the RecyclerView expects its adapter operations to run.</p>
 *
 * @see PlaylistActivity
 * @see Song
 * @see ThemeManager
 * @see DiffUtil
 *
 * @author Richard Korbla Adzido
 * @version 1.4.0
 * @since 1.0.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Duration of the button press animation, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after the animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Default theme color used when {@link ThemeManager} is unavailable. */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";

    /** Background color for the currently playing row. */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";

    /** Touch highlight color applied to a pressed row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for song titles in non-current rows. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Dark gray text color for subtitles in non-current rows. */
    private static final String TEXT_COLOR_DARK = "#808080";

    /** Separator used between metadata fields in the subtitle. */
    private static final String METADATA_SEPARATOR = " \u2022 ";

    /** Debounce delay for song click events, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 250;

    /** Payload identifier for genre-only updates. */
    private static final String PAYLOAD_GENRE = "genre_update";

    /**
     * Delay after the scroll settles before queued genre updates are
     * flushed, in milliseconds. Gives the scroll-settling animation
     * time to complete so a rebind does not appear to move the current
     * row.
     */
    private static final long SCROLL_SETTLE_MS = 100L;

    // ============================================================================
    // Member Variables
    // ============================================================================

    /** Songs displayed by the adapter. */
    private final CopyOnWriteArrayList<Song> mSongs;

    /** Context used to inflate rows and resolve resources. */
    private final Context mContext;

    /** Listener notified on row taps, or null when none is set. */
    @Nullable private final OnSongClickListener mListener;

    /** Listener notified on favorite toggles, or null when none is set. */
    @Nullable private FavoriteListener mFavoriteListener;

    /** Path of the song highlighted as currently playing, or null. */
    @Nullable private volatile String mCurrentPlayingPath = null;

    // ============================================================================
    // Genre Loading Batching
    // ============================================================================

    /** True while genre loading is in progress. */
    private volatile boolean mIsGenreLoading = false;

    /** Pending genre updates applied once the list is stable. */
    private final Map<String, String> mPendingGenreUpdates = new HashMap<>();

    /**
     * True while the owning recycler view is being scrolled by the user.
     * Genre updates are queued while this is true and flushed once the
     * scroll settles.
     */
    private volatile boolean mIsScrolling = false;

    // ============================================================================
    // Listener Interface
    // ============================================================================

    /**
     * Receives row taps.
     */
    public interface OnSongClickListener {

        /**
         * Called when a song row is tapped.
         *
         * @param position Adapter position of the tapped row
         * @param song Song associated with the tapped row
         */
        void onSongClick(int position, @NonNull Song song);
    }

    /**
     * Receives a favorite-toggle tap from a playlist row.
     *
     * <p>Fired by the heart icon on each row, once per tap, after the
     * in-memory {@link Song} has already had its favorite flag
     * flipped and the row has been rebound. The listener's job is to
     * persist the change — the adapter does not — so an owner that
     * batches changes can accumulate them here and flush later.</p>
     */
    public interface FavoriteListener {

        /**
         * Called when the user taps a row's favorite icon.
         *
         * @param songPath Path of the song whose flag changed
         * @param favorite New value of the flag
         */
        void onFavoriteToggle(@NonNull String songPath, boolean favorite);
    }

    // ============================================================================
    // ViewHolder Class
    // ============================================================================

    /**
     * Caches references to the child views of a playlist row.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        /** Container layout that receives the row background and touches. */
        final LinearLayout mContentLayout;

        /** TextView for the title line. */
        final TextView mTitle;

        /** TextView for the subtitle line. */
        final TextView mSubtitle;

        /** TextView that renders the favorite heart. */
        final TextView mFavoriteIcon;

        /** Divider below the row. */
        final View mDivider;

        /**
         * Resolves the child views of the given row.
         *
         * @param view Inflated row view
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mFavoriteIcon = view.findViewById(R.id.favoriteIcon);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }

    // ============================================================================
    // DiffUtil Callback
    // ============================================================================

    /**
     * Computes the differences between the old and new song lists.
     *
     * <p>Two rows are the same item when their paths match. They have
     * the same contents when their genres match; a genre-only change is
     * reported through {@link #getChangePayload(int, int)} as
     * {@link #PAYLOAD_GENRE}.</p>
     */
    private static class SongDiffCallback extends DiffUtil.Callback {

        /** Song list before the update. */
        private final List<Song> oldList;

        /** Song list after the update. */
        private final List<Song> newList;

        /**
         * Constructs a callback for the given list pair.
         *
         * @param oldList Song list before the update
         * @param newList Song list after the update
         */
        SongDiffCallback(List<Song> oldList, List<Song> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        /**
         * Returns the size of the old list.
         *
         * @return Number of songs in the old list
         */
        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        /**
         * Returns the size of the new list.
         *
         * @return Number of songs in the new list
         */
        @Override
        public int getNewListSize() {
            return newList.size();
        }

        /**
         * Returns whether the two positions refer to the same song.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return True when the two songs have the same path
         */
        @Override
        public boolean areItemsTheSame(int oldItemPosition,
                                       int newItemPosition) {
            String oldPath = oldList.get(oldItemPosition).getPath();
            String newPath = newList.get(newItemPosition).getPath();
            return oldPath.equals(newPath);
        }

        /**
         * Returns whether the two positions have the same content.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return True when the two songs have the same genre
         */
        @Override
        public boolean areContentsTheSame(int oldItemPosition,
                                          int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            return oldSong.getGenre().equals(newSong.getGenre());
        }

        /**
         * Returns the payload delivered to a partial rebind when the
         * two positions have different content.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return {@link #PAYLOAD_GENRE} when the genre differs,
         *         otherwise null
         */
        @Nullable
        @Override
        public Object getChangePayload(int oldItemPosition,
                                       int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            if (!oldSong.getGenre().equals(newSong.getGenre())) {
                return PAYLOAD_GENRE;
            }
            return null;
        }
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs a new adapter.
     *
     * <p>The adapter starts with no current-playing path. The owning
     * activity supplies the initial and subsequent values through
     * {@link #setCurrentPlayingIndex(int)} or
     * {@link #setCurrentPlayingPath(String)}.</p>
     *
     * @param context Context used to inflate rows and resolve resources
     * @param songs Initial list of songs to display
     * @param listener Listener notified on row taps, or null
     */
    public PlaylistAdapter(@NonNull Context context,
                           @NonNull List<Song> songs,
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;

        setHasStableIds(true);
    }

    // ============================================================================
    // RecyclerView.Adapter Methods
    // ============================================================================

    /**
     * Returns the stable identifier of the song at the given position.
     *
     * <p>The identifier is derived from the song's path, so it remains
     * the same across insertions, removals, and reorders that preserve
     * the song. RecyclerView uses this value to animate row changes.</p>
     *
     * @param position Adapter position
     * @return Stable identifier derived from the song's path, or the
     *         position when the song is null
     */
    @Override
    public long getItemId(int position) {
        Song song = mSongs.get(position);
        return song != null ? song.getPath().hashCode() : position;
    }

    /**
     * Creates a view holder for a playlist row.
     *
     * @param parent Parent view group into which the new view is added
     * @param viewType View type; identical for every row
     * @return A new view holder for the row
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                         int viewType) {
        View view = LayoutInflater.from(mContext)
            .inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Binds the song at the given position to the view holder.
     *
     * <p>{@link RecyclerView.Adapter} declares this two-argument form
     * abstract and the three-argument form as the payload-aware
     * overload. This override delegates to the payload-aware form
     * with no payload, so a plain bind and a partial rebind share one
     * implementation body.</p>
     *
     * @param holder View holder to bind
     * @param position Adapter position
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder,
                                 int position) {
        onBindViewHolder(holder, position, null);
    }

    /**
     * Binds the song at the given position to the view holder, with
     * partial-update support.
     *
     * <p>When the payload contains {@link #PAYLOAD_GENRE}, only the
     * subtitle is updated. This prevents the RecyclerView from
     * re-measuring the entire item, which would cause scroll position
     * jumps when text length changes during genre updates.</p>
     *
     * <p>On a full bind, the theme color is queried from
     * {@link ThemeManager}. Theme changes trigger a rebind from the
     * activity, so the query reflects the current value. The heart
     * icon is bound here too: its tint follows the current theme
     * color when the song is favorited and a muted grey when it is
     * not.</p>
     *
     * <p>The heart's tap listener flips the in-memory favorite flag
     * on the row's {@link Song}, notifies the adapter so the row
     * redraws, and forwards the change to
     * {@link #mFavoriteListener} for persistence. The adapter
     * does not persist; the listener owns that.</p>
     *
     * @param holder View holder to bind
     * @param position Adapter position
     * @param payloads Payload objects supplied by
     *        {@link DiffUtil.DiffResult#dispatchUpdatesTo(RecyclerView.Adapter)},
     *        or null when no payload is present
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder,
                                 int position,
                                 @Nullable List<Object> payloads) {
        if (position < 0 || position >= mSongs.size()) {
            return;
        }

        final Song song = mSongs.get(position);
        if (song == null) {
            return;
        }

        boolean isGenreOnlyUpdate = payloads != null
            && !payloads.isEmpty()
            && payloads.contains(PAYLOAD_GENRE);

        if (!isGenreOnlyUpdate) {
            String title = song.getTitle();
            holder.mTitle.setText(
                (title != null && !title.isEmpty())
                    ? title
                    : CharacterMapper.getUnknownTitle());

            String currentPath = mCurrentPlayingPath;
            boolean isCurrent = (currentPath != null
                && currentPath.equals(song.getPath()));

            String themeColor = resolveThemeColor();

            if (isCurrent) {
                holder.mContentLayout.setBackgroundColor(
                    Color.parseColor(CURRENT_SONG_BACKGROUND));
                holder.mTitle.setTextColor(Color.parseColor(themeColor));
                holder.mSubtitle.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mDivider.setVisibility(View.GONE);
            } else {
                holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
                holder.mTitle.setTextColor(
                    Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mSubtitle.setTextColor(
                    Color.parseColor(TEXT_COLOR_DARK));
                holder.mDivider.setVisibility(View.VISIBLE);
            }

            if (holder.mFavoriteIcon != null) {
                holder.mFavoriteIcon.setTypeface(FontAwesome.getTypeface());
                holder.mFavoriteIcon.setText(FontAwesome.HEART);
                holder.mFavoriteIcon.setTextColor(song.isFavorite()
                    ? Color.parseColor(themeColor)
                    : Color.parseColor(TEXT_COLOR_DARK));
                holder.mFavoriteIcon.setContentDescription(
                    mContext.getString(song.isFavorite()
                        ? R.string.playlist_favorite_remove
                        : R.string.playlist_favorite_add));
                holder.mFavoriteIcon.setOnClickListener(v -> {
                    int adapterPos = holder.getAdapterPosition();
                    if (adapterPos == RecyclerView.NO_POSITION
                            || adapterPos >= mSongs.size()) {
                        return;
                    }
                    Song tapped = mSongs.get(adapterPos);
                    if (tapped == null) {
                        return;
                    }
                    boolean newValue = !tapped.isFavorite();
                    tapped.setFavorite(newValue);
                    notifyItemChanged(adapterPos);
                    if (mFavoriteListener != null
                            && tapped.getPath() != null) {
                        mFavoriteListener.onFavoriteToggle(
                            tapped.getPath(), newValue);
                    }
                });
            }

            final boolean isCurrentForTouch = isCurrent;
            holder.mContentLayout.setOnTouchListener((view, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(
                            Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isCurrentForTouch) {
                            view.setBackgroundColor(
                                Color.parseColor(
                                    CURRENT_SONG_BACKGROUND));
                        } else {
                            view.setBackgroundColor(Color.TRANSPARENT);
                        }
                        break;
                    default:
                        break;
                }
                return false;
            });

            holder.mContentLayout.setOnClickListener(
                new View.OnClickListener() {
                private long lastClickTime = 0;

                @Override
                public void onClick(final View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - lastClickTime
                            < CLICK_DEBOUNCE_DELAY_MS) {
                        return;
                    }
                    lastClickTime = currentTime;

                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition == RecyclerView.NO_POSITION
                            || adapterPosition >= mSongs.size()) {
                        return;
                    }

                    final Song clickedSong = mSongs.get(adapterPosition);
                    if (clickedSong == null) {
                        return;
                    }

                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                               .scaleY(ANIMATION_SCALE_DOWN)
                               .setDuration(ANIMATION_DURATION_MS)
                               .withEndAction(() -> {
                                   view.animate()
                                       .scaleX(ANIMATION_SCALE_NORMAL)
                                       .scaleY(ANIMATION_SCALE_NORMAL)
                                       .setDuration(ANIMATION_DURATION_MS)
                                       .start();
                               }).start();

                    if (mListener != null) {
                        mListener.onSongClick(adapterPosition,
                            clickedSong);
                    }
                }
            });
        }

        StringBuilder subtitle = new StringBuilder();

        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty()
                && !CharacterMapper.isUnknownArtist(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append(CharacterMapper.getUnknownArtist());
        }

        String album = song.getAlbum();
        if (album != null && !album.isEmpty()
                && !CharacterMapper.isUnknownAlbum(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR)
                .append(CharacterMapper.getUnknownAlbum());
        }

        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty()
                && !CharacterMapper.isUnknownGenre(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR)
                .append(CharacterMapper.getUnknownGenre());
        }

        holder.mSubtitle.setText(subtitle.toString());
    }

    /**
     * Returns the number of songs currently displayed.
     *
     * @return The number of songs in the adapter
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }

    // ============================================================================
    // Public Methods
    // ============================================================================

    /**
     * Replaces the current song list with the given list.
     *
     * <p>When the difference between the two lists is large — a cold
     * start, a first import, a full rebuild — the entire list is
     * replaced in one step. Otherwise, the minimal set of updates
     * computed by {@link DiffUtil} is dispatched. See
     * {@link #shouldBulkReplace(List, List)} for the threshold.</p>
     *
     * @param newSongs New list of songs to display
     */
    public void updateList(@NonNull List<Song> newSongs) {
        updateList(newSongs, false);
    }

    /**
     * Replaces the current song list with the given list, optionally
     * declaring the update a pure reorder.
     *
     * <p>A caller that knows the two lists contain the same songs in a
     * different order passes {@code reorderOnly = true}. This is what
     * the playlist activity does after a sort cycle: every song is
     * still present, only the ordering changed. {@link DiffUtil} is
     * the wrong tool for that shape — its Myers pass degenerates to
     * O(n²) when the edit distance approaches the list size, which is
     * exactly what a full reorder produces — so the adapter replaces
     * the whole list in one step and lets the RecyclerView rebind. On
     * a large library the alternative is a multi-hundred-millisecond
     * main-thread stall inside the operation the sort overlay is
     * displaying progress for.</p>
     *
     * <p>The flag is a hint, not a contract. A caller that is not
     * certain can pass {@code false} and let
     * {@link #shouldBulkReplace(List, List)} decide.</p>
     *
     * @param newSongs New list of songs to display
     * @param reorderOnly True when the caller knows the two lists
     *        contain the same songs in a different order
     */
    public void updateList(@NonNull List<Song> newSongs,
                           boolean reorderOnly) {
        List<Song> oldList = new ArrayList<>(mSongs);
        List<Song> newList = new ArrayList<>(newSongs);

        if (reorderOnly || shouldBulkReplace(oldList, newList)) {
            mSongs.clear();
            mSongs.addAll(newList);
            notifyDataSetChanged();
            return;
        }

        DiffUtil.DiffResult diffResult =
            DiffUtil.calculateDiff(new SongDiffCallback(oldList, newList));

        mSongs.clear();
        mSongs.addAll(newList);

        diffResult.dispatchUpdatesTo(this);
    }

    /**
     * Returns whether the difference between the two lists is large
     * enough that {@link DiffUtil} would cost more than a full rebind.
     *
     * <p>DiffUtil's Myers pass is O(n·d). It is the right tool when the
     * edit distance d is small — a genre update, a metadata edit — and
     * the wrong tool when d approaches n, which is what happens on a
     * cold start, a first import, or a full library rebuild. The
     * threshold is structural, not tuned: when more than half the rows
     * are added, removed, or reordered, the animation DiffUtil buys
     * costs more than it is worth, and {@code notifyDataSetChanged} is
     * the honest answer.</p>
     *
     * @param oldList List before the update
     * @param newList List after the update
     * @return True when the caller should use notifyDataSetChanged
     */
    private static boolean shouldBulkReplace(@NonNull List<Song> oldList,
                                              @NonNull List<Song> newList) {
        if (oldList.isEmpty() || newList.isEmpty()) {
            return true;
        }

        if (Math.abs(oldList.size() - newList.size())
                > oldList.size() / 2) {
            return true;
        }

        Set<String> newPaths = new HashSet<>(newList.size());
        for (Song song : newList) {
            if (song != null && song.getPath() != null) {
                newPaths.add(song.getPath());
            }
        }

        int overlap = 0;
        for (Song song : oldList) {
            if (song != null && song.getPath() != null
                    && newPaths.contains(song.getPath())) {
                overlap++;
            }
        }
        return overlap < oldList.size() / 2;
    }

    /**
     * Sets the path of the song highlighted as currently playing.
     *
     * <p>The adapter holds no copy of this value elsewhere. It is a
     * presentation hint supplied by the owning activity, which reads the
     * authoritative value from {@link MusicService}.</p>
     *
     * <p>A call with the same path as the current one is a no-op. The
     * path is the identity of the highlighted row; a repeated
     * assignment would otherwise rebind that row twice — once on the old
     * position and once on the new — for no visible change, and two
     * full-item change animations per call would disturb any in-flight
     * RecyclerView scroll. The guard makes the invariant "a highlight
     * change is signalled at most once per actual change", which is what
     * the RecyclerView expects.</p>
     *
     * @param songPath Path of the currently playing song, or null for
     *        none
     */
    public void setCurrentPlayingPath(@Nullable String songPath) {
        String oldPath = mCurrentPlayingPath;

        if (oldPath == null ? songPath == null : oldPath.equals(songPath)) {
            return;
        }

        mCurrentPlayingPath = songPath;

        if (oldPath != null) {
            int oldPosition = findPositionByPath(oldPath);
            if (oldPosition >= 0 && oldPosition < mSongs.size()) {
                notifyItemChanged(oldPosition);
            }
        }
        if (songPath != null) {
            int newPosition = findPositionByPath(songPath);
            if (newPosition >= 0 && newPosition < mSongs.size()) {
                notifyItemChanged(newPosition);
            }
        }
    }

    /**
     * Returns the path of the song highlighted as currently playing.
     *
     * @return The current playing path, or null when none is set
     */
    @Nullable
    public String getCurrentPlayingPath() {
        return mCurrentPlayingPath;
    }

    /**
     * Returns the song at the given adapter position.
     *
     * @param position Adapter position
     * @return The song at the given position, or null when the position
     *         is out of range
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }

    /**
     * Sets the listener notified when a row's favorite icon is
     * tapped.
     *
     * <p>The listener is called after the row's in-memory favorite
     * flag has been flipped, so the adapter is already consistent
     * with the new state when the listener observes the change.</p>
     *
     * @param listener Receiver of favorite toggles, or null to clear
     */
    public void setFavoriteListener(@Nullable FavoriteListener listener) {
        mFavoriteListener = listener;
    }

    /**
     * Records whether the owning recycler view is being scrolled by the
     * user.
     *
     * <p>While scrolling is in progress, genre updates are queued rather
     * than applied immediately. Applying them mid-scroll would call
     * {@link #notifyItemChanged(int)} on visible rows while the scroll
     * animation is still settling, and the current row would appear to
     * jump out of its own position. When scrolling ends, the queue is
     * flushed after {@link #SCROLL_SETTLE_MS} milliseconds.</p>
     *
     * @param scrolling True while the user is scrolling
     */
    public void setScrolling(boolean scrolling) {
        mIsScrolling = scrolling;
        if (!scrolling && !mIsGenreLoading
                && !mPendingGenreUpdates.isEmpty()) {
            new Handler(Looper.getMainLooper()).postDelayed(
                this::flushPendingGenreUpdates, SCROLL_SETTLE_MS);
        }
    }

    /**
     * Applies every queued genre update through the payload path and
     * clears the queue. No-op while scrolling or while genre loading is
     * in flight.
     */
    private void flushPendingGenreUpdates() {
        if (mIsScrolling || mIsGenreLoading
                || mPendingGenreUpdates.isEmpty()) {
            return;
        }
        for (Map.Entry<String, String> entry
                : mPendingGenreUpdates.entrySet()) {
            applyGenreUpdate(entry.getKey(), entry.getValue(), true);
        }
        mPendingGenreUpdates.clear();
    }

    /**
     * Sets whether genre loading is in progress.
     *
     * <p>When genre loading ends and the recycler view is not being
     * scrolled, every queued genre update is applied and the queue is
     * cleared. When the user is scrolling, the queue is held until
     * scroll ends.</p>
     *
     * @param loading True while genre loading is in progress
     */
    public void setGenreLoading(boolean loading) {
        mIsGenreLoading = loading;
        if (!loading && !mIsScrolling) {
            flushPendingGenreUpdates();
        }
    }

    /**
     * Applies a genre update to the song with the given path.
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     * @param notify True to notify the adapter with the
     *        {@link #PAYLOAD_GENRE} payload
     */
    private void applyGenreUpdate(String songPath, String newGenre,
                                  boolean notify) {
        int position = findPositionByPath(songPath);
        if (position >= 0 && position < mSongs.size()) {
            Song song = mSongs.get(position);
            if (song != null) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    if (notify) {
                        notifyItemChanged(position, PAYLOAD_GENRE);
                    }
                }
            }
        }
    }

    /**
     * Updates the genre of the song with the given path.
     *
     * <p>While genre loading is in progress or the user is scrolling,
     * the update is queued and applied once the list is stable, so the
     * visible rows are not modified mid-scroll.</p>
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     */
    public void updateSongGenre(String songPath, String newGenre) {
        if (mIsGenreLoading || mIsScrolling) {
            mPendingGenreUpdates.put(songPath, newGenre);
        } else {
            applyGenreUpdate(songPath, newGenre, true);
        }
    }

    // ============================================================================
    // Backward Compatibility Methods
    // ============================================================================

    /**
     * Sets the currently playing song from its adapter position.
     *
     * @param index Adapter position of the currently playing song, or a
     *        negative value to clear
     * @deprecated Use {@link #setCurrentPlayingPath(String)}. This
     *             method requires the caller to know the adapter
     *             position, which can change between calls when the
     *             list is re-sorted or filtered.
     */
    @Deprecated
    public void setCurrentPlayingIndex(int index) {
        if (index >= 0 && index < mSongs.size()) {
            Song song = mSongs.get(index);
            if (song != null) {
                setCurrentPlayingPath(song.getPath());
            }
        } else {
            setCurrentPlayingPath(null);
        }
    }

    /**
     * Returns the adapter position of the currently playing song.
     *
     * @return Adapter position of the currently playing song, or -1
     *         when none is set
     * @deprecated Use {@link #getCurrentPlayingPath()}. The position can
     *             change between calls when the list is re-sorted or
     *             filtered.
     */
    @Deprecated
    public int getCurrentPlayingIndex() {
        if (mCurrentPlayingPath != null) {
            return findPositionByPath(mCurrentPlayingPath);
        }
        return -1;
    }

    // ============================================================================
    // Private Helper Methods
    // ============================================================================

    /**
     * Returns the adapter position of the song with the given path, or
     * -1 when it is not present.
     *
     * @param songPath Path to search for, or null
     * @return Adapter position of the matching song, or -1
     */
    private int findPositionByPath(@Nullable String songPath) {
        if (songPath == null || mSongs == null) {
            return -1;
        }
        for (int index = 0; index < mSongs.size(); index++) {
            Song song = mSongs.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Resolves the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The theme color as a hex string, such as
     *         {@code "#B8A86E"}
     */
    @NonNull
    private String resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                String color = themeManager.getCurrentColor();
                if (color != null && !color.isEmpty()) {
                    return color;
                }
            }
            return DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }
}