package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Adapter for displaying the playlist in a RecyclerView.
 * 
 * <h3>Thread Safety</h3>
 * <p>This adapter uses CopyOnWriteArrayList for thread-safe list access.
 * All UI operations are performed on the main thread as required by RecyclerView.
 * Theme color caching uses volatile for visibility.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final int ANIMATION_DURATION_MS = 80;
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    private static final String TEXT_COLOR_DARK = "#808080";
    private static final String METADATA_SEPARATOR = " • ";
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;
    
    // ========================================================================
    // Member Variables (Thread-Safe)
    // ========================================================================
    
    /** Thread-safe list for songs. */
    private final CopyOnWriteArrayList<Song> mSongs;
    
    private final Context mContext;
    @Nullable private final OnSongClickListener mListener;
    private volatile int mCurrentPlayingIndex = -1;
    private volatile String mCachedThemeColor = DEFAULT_THEME_COLOR;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    public interface OnSongClickListener {
        void onSongClick(int position, @NonNull Song song);
    }
    
    // ========================================================================
    // ViewHolder Class
    // ========================================================================
    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final LinearLayout mContentLayout;
        final TextView mTitle;
        final TextView mSubtitle;
        final View mDivider;
        
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs, 
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;
        loadCurrentPlayingIndex();
        loadThemeColor();
    }
    
    // ========================================================================
    // RecyclerView.Adapter Methods (Called on UI Thread)
    // ========================================================================
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        if (position < 0 || position >= mSongs.size()) return;
        
        final Song song = mSongs.get(position);
        if (song == null) return;
        
        // Set song title
        String title = song.getTitle();
        holder.mTitle.setText((title != null && !title.isEmpty()) ? title : "Unknown Title");
        
        // Build subtitle string: Artist • Album • Genre
        StringBuilder subtitle = new StringBuilder();
        
        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }
        
        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }
        
        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }
        
        holder.mSubtitle.setText(subtitle.toString());
        
        final boolean isCurrent = (position == mCurrentPlayingIndex);
        
        // Update theme color (cached for performance)
        updateThemeColor();
        String themeColor = mCachedThemeColor;
        
        if (isCurrent) {
            holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
            holder.mTitle.setTextColor(Color.parseColor(themeColor));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            holder.mDivider.setVisibility(View.GONE);
        } else {
            holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
            holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
            holder.mDivider.setVisibility(View.VISIBLE);
        }
        
        // Touch feedback
        holder.mContentLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (isCurrent) {
                        v.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                    } else {
                        v.setBackgroundColor(Color.TRANSPARENT);
                    }
                    break;
            }
            return false;
        });
        
        // Click listener with debouncing
        holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
            private long lastClickTime = 0;
            
            @Override
            public void onClick(final View v) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                lastClickTime = currentTime;
                
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION || pos >= mSongs.size()) return;
                
                final Song clickedSong = mSongs.get(pos);
                if (clickedSong == null) return;
                
                v.animate().scaleX(ANIMATION_SCALE_DOWN)
                           .scaleY(ANIMATION_SCALE_DOWN)
                           .setDuration(ANIMATION_DURATION_MS)
                           .withEndAction(() -> {
                               v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                         .scaleY(ANIMATION_SCALE_NORMAL)
                                         .setDuration(ANIMATION_DURATION_MS)
                                         .start();
                           }).start();
                
                if (mListener != null) {
                    mListener.onSongClick(pos, clickedSong);
                }
            }
        });
    }
    
    @Override
    public int getItemCount() {
        return mSongs.size();
    }
    
    // ========================================================================
    // Public Methods (Thread-Safe)
    // ========================================================================
    
    public void updateList(@NonNull List<Song> newSongs) {
        mSongs.clear();
        mSongs.addAll(newSongs);
        notifyDataSetChanged();
    }
    
    public void setCurrentPlayingIndex(int index) {
        int oldIndex = mCurrentPlayingIndex;
        mCurrentPlayingIndex = index;
        saveCurrentPlayingIndex(index);
        
        if (oldIndex >= 0 && oldIndex < mSongs.size()) {
            notifyItemChanged(oldIndex);
        }
        if (index >= 0 && index < mSongs.size()) {
            notifyItemChanged(index);
        }
    }
    
    public int getCurrentPlayingIndex() {
        return mCurrentPlayingIndex;
    }
    
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }
    
    public void updateThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            String newColor = themeManager.getCurrentColor();
            if (!newColor.equals(mCachedThemeColor)) {
                mCachedThemeColor = newColor;
                if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
                    notifyItemChanged(mCurrentPlayingIndex);
                }
            }
        } catch (Exception e) {
            // Keep cached color on error
        }
    }
    
    public void updateSongGenre(String songPath, String newGenre) {
        for (int i = 0; i < mSongs.size(); i++) {
            Song song = mSongs.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    notifyItemChanged(i);
                }
                break;
            }
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    private void loadCurrentPlayingIndex() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentPlayingIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
    }
    
    private void saveCurrentPlayingIndex(int index) {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply();
    }
    
    private void loadThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            mCachedThemeColor = themeManager.getCurrentColor();
        } catch (Exception e) {
            mCachedThemeColor = DEFAULT_THEME_COLOR;
        }
    }
}