package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Adapter for displaying the playlist in a RecyclerView.
 * 
 * <p>This adapter binds song data to list items and handles visual styling
 * for the currently playing song. It provides smooth scrolling, touch feedback,
 * and theme color integration.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This adapter uses CopyOnWriteArrayList for thread-safe list access.
 * All UI operations are performed on the main thread as required by RecyclerView.
 * Theme color caching uses volatile for visibility.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Thread-safe song list using CopyOnWriteArrayList</li>
 *   <li>Visual highlighting for currently playing song (dark background, theme-colored title)</li>
 *   <li>Touch feedback with background color changes on press</li>
 *   <li>Click debouncing to prevent rapid repeated clicks</li>
 *   <li>Theme color caching for performance</li>
 *   <li>Real-time genre updates without scroll interruption</li>
 *   <li>Divider visibility control for current song</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name for storing playback state. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index in SharedPreferences. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Default theme color (Royal Llama) used when ThemeManager is unavailable. */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    
    /** Background color for the currently playing song item (dark gray). */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";
    
    /** Touch highlight color when pressing a list item (lighter gray). */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    /** Light gray text color for song titles in non-current items. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Dark gray text color for subtitle text in non-current items. */
    private static final String TEXT_COLOR_DARK = "#808080";
    
    /** Separator string used between metadata fields (artist, album, genre). */
    private static final String METADATA_SEPARATOR = " • ";
    
    /** Debounce delay for song click events to prevent rapid multiple clicks. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;
    
    // ========================================================================
    // Member Variables (Thread-Safe)
    // ========================================================================
    
    /** Thread-safe list of songs displayed in the playlist. */
    private final CopyOnWriteArrayList<Song> mSongs;
    
    /** Application context for accessing resources and SharedPreferences. */
    private final Context mContext;
    
    /** Listener for song click events, or null if not set. */
    @Nullable private final OnSongClickListener mListener;
    
    /** Index of the currently playing/selected song (-1 if none). */
    private volatile int mCurrentPlayingIndex = -1;
    
    /** Cached theme color string for performance (avoids repeated ThemeManager lookups). */
    private volatile String mCachedThemeColor = DEFAULT_THEME_COLOR;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for song click events.
     * 
     * <p>Activities using this adapter must implement this interface
     * to handle song selection and playback.</p>
     */
    public interface OnSongClickListener {
        
        /**
         * Called when a song item is clicked.
         *
         * @param position The position of the clicked song in the adapter
         * @param song The Song object representing the clicked song
         */
        void onSongClick(int position, @NonNull Song song);
    }
    
    // ========================================================================
    // ViewHolder Class
    // ========================================================================
    
    /**
     * ViewHolder for song items in the playlist.
     * 
     * <p>Caches references to the views within each item layout to
     * improve performance during scrolling.</p>
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        
        /** Container layout for the entire list item (handles background and touch). */
        final LinearLayout mContentLayout;
        
        /** TextView displaying the song title (android.R.id.text1). */
        final TextView mTitle;
        
        /** TextView displaying the subtitle (artist, album, genre) (android.R.id.text2). */
        final TextView mSubtitle;
        
        /** Divider view between list items (hidden for the currently playing song). */
        final View mDivider;
        
        /**
         * Constructs a new ViewHolder.
         *
         * @param view The item view inflated from item_song.xml
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PlaylistAdapter.
     *
     * @param context The application context
     * @param songs The initial list of songs to display
     * @param listener Listener for song click events (can be null)
     */
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs, 
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;
        loadCurrentPlayingIndex();
        loadThemeColor();
    }
    
    // ========================================================================
    // RecyclerView.Adapter Methods (Called on UI Thread)
    // ========================================================================
    
    /**
     * Creates a new ViewHolder for a song item.
     * 
     * <p>Called by RecyclerView when it needs a new ViewHolder.
     * Inflates the item_song layout and creates a new ViewHolder instance.</p>
     *
     * @param parent The parent ViewGroup into which the new view will be added
     * @param viewType The view type (not used, all items are the same)
     * @return A new ViewHolder for the song item
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }
    
    /**
     * Binds song data to a ViewHolder at the specified position.
     * 
     * <p>This method is called by RecyclerView to display data at a specific position.
     * It sets the song title, builds the subtitle string (Artist • Album • Genre),
     * applies appropriate styling based on whether this is the currently playing song,
     * and sets up touch feedback and click listeners.</p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        if (position < 0 || position >= mSongs.size()) return;
        
        final Song song = mSongs.get(position);
        if (song == null) return;
        
        // Set song title with fallback for null/empty values
        String title = song.getTitle();
        holder.mTitle.setText((title != null && !title.isEmpty()) ? title : "Unknown Title");
        
        // Build subtitle string: Artist • Album • Genre
        StringBuilder subtitle = new StringBuilder();
        
        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }
        
        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }
        
        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }
        
        holder.mSubtitle.setText(subtitle.toString());
        
        final boolean isCurrent = (position == mCurrentPlayingIndex);
        
        // Update and apply theme color for the current song's title
        updateThemeColor();
        String themeColor = mCachedThemeColor;
        
        if (isCurrent) {
            // Currently playing song: dark background, theme-colored title, hide divider
            holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
            holder.mTitle.setTextColor(Color.parseColor(themeColor));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            holder.mDivider.setVisibility(View.GONE);
        } else {
            // Non-current song: transparent background, light gray title, show divider
            holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
            holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
            holder.mDivider.setVisibility(View.VISIBLE);
        }
        
        // Touch feedback: highlight background on press, revert on release
        holder.mContentLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (isCurrent) {
                        v.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                    } else {
                        v.setBackgroundColor(Color.TRANSPARENT);
                    }
                    break;
            }
            return false;
        });
        
        // Click listener with debouncing to prevent rapid multiple clicks
        holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
            private long lastClickTime = 0;
            
            @Override
            public void onClick(final View v) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return;
                lastClickTime = currentTime;
                
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION || pos >= mSongs.size()) return;
                
                final Song clickedSong = mSongs.get(pos);
                if (clickedSong == null) return;
                
                // Bounce animation on click
                v.animate().scaleX(ANIMATION_SCALE_DOWN)
                           .scaleY(ANIMATION_SCALE_DOWN)
                           .setDuration(ANIMATION_DURATION_MS)
                           .withEndAction(() -> {
                               v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                         .scaleY(ANIMATION_SCALE_NORMAL)
                                         .setDuration(ANIMATION_DURATION_MS)
                                         .start();
                           }).start();
                
                if (mListener != null) {
                    mListener.onSongClick(pos, clickedSong);
                }
            }
        });
    }
    
    /**
     * Returns the total number of items in the playlist.
     *
     * @return The number of songs in the adapter
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }
    
    // ========================================================================
    // Public Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Replaces the entire song list with a new list.
     * 
     * <p>This method clears the existing list and adds all items from the new list,
     * then notifies the adapter that the entire data set has changed.
     * This triggers a full refresh of the RecyclerView.</p>
     *
     * @param newSongs The new list of songs to display
     */
    public void updateList(@NonNull List<Song> newSongs) {
        mSongs.clear();
        mSongs.addAll(newSongs);
        notifyDataSetChanged();
    }
    
    /**
     * Sets the index of the currently playing song.
     * 
     * <p>This method updates the visual highlighting for both the old and new
     * current song positions. It saves the index to SharedPreferences for
     * persistence across app restarts.</p>
     *
     * @param index The new current playing index (-1 for none)
     */
    public void setCurrentPlayingIndex(int index) {
        int oldIndex = mCurrentPlayingIndex;
        mCurrentPlayingIndex = index;
        saveCurrentPlayingIndex(index);
        
        // Notify both old and new positions to update their visual styling
        if (oldIndex >= 0 && oldIndex < mSongs.size()) {
            notifyItemChanged(oldIndex);
        }
        if (index >= 0 && index < mSongs.size()) {
            notifyItemChanged(index);
        }
    }
    
    /**
     * Returns the index of the currently playing song.
     *
     * @return The current playing index (-1 if none)
     */
    public int getCurrentPlayingIndex() {
        return mCurrentPlayingIndex;
    }
    
    /**
     * Returns the song at the specified position.
     *
     * @param position The position in the list
     * @return The Song object, or null if position is invalid
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }
    
    /**
     * Updates the cached theme color if it has changed.
     * 
     * <p>This method is called during onBindViewHolder to ensure the current
     * song's title uses the correct theme color. If the theme has changed,
     * it updates the cache and refreshes the current song item.</p>
     */
    public void updateThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            String newColor = themeManager.getCurrentColor();
            if (!newColor.equals(mCachedThemeColor)) {
                mCachedThemeColor = newColor;
                // Refresh the current song item to apply the new theme color
                if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
                    notifyItemChanged(mCurrentPlayingIndex);
                }
            }
        } catch (Exception e) {
            // Keep cached color on error - falls back to default
        }
    }
    
    /**
     * Updates the genre of a specific song and refreshes its display.
     * 
     * <p>This method is called during Phase 2 genre loading when a real genre
     * is discovered from ID3 tags. It updates the song data in memory and
     * notifies the adapter to refresh that specific item.
     * 
     * <b>IMPORTANT:</b> This method skips calling notifyItemChanged() for the
     * currently playing song to prevent the RecyclerView from resetting scroll
     * position. The currently playing song's genre is still updated in memory,
     * but the visual refresh happens when the user scrolls back to it.</p>
     *
     * @param songPath The file path of the song to update
     * @param newGenre The new genre value from ID3 tags
     */
    public void updateSongGenre(String songPath, String newGenre) {
        // Get the path of the currently playing song to skip refreshing it
        String currentSongPath = null;
        if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
            Song currentSong = mSongs.get(mCurrentPlayingIndex);
            if (currentSong != null) {
                currentSongPath = currentSong.getPath();
            }
        }
        
        for (int i = 0; i < mSongs.size(); i++) {
            Song song = mSongs.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    // Only refresh if this is NOT the currently playing song
                    // Refreshing the current song would cause RecyclerView to relayout
                    // and potentially reset the user's scroll position
                    if (currentSongPath == null || !songPath.equals(currentSongPath)) {
                        notifyItemChanged(i);
                    }
                }
                break;
            }
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Loads the saved current playing index from SharedPreferences.
     * 
     * <p>This method is called during adapter construction to restore
     * the playback position from a previous app session.</p>
     */
    private void loadCurrentPlayingIndex() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentPlayingIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     * 
     * <p>This method is called whenever the playing index changes to ensure
     * the playback position is preserved across app restarts and orientation changes.</p>
     *
     * @param index The current playing index to save
     */
    private void saveCurrentPlayingIndex(int index) {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply();
    }
    
    /**
     * Loads the current theme color from ThemeManager.
     * 
     * <p>This method is called during adapter construction to initialize
     * the cached theme color. If ThemeManager is unavailable, falls back
     * to the default Royal Llama color.</p>
     */
    private void loadThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            mCachedThemeColor = themeManager.getCurrentColor();
        } catch (Exception e) {
            mCachedThemeColor = DEFAULT_THEME_COLOR;
        }
    }
}