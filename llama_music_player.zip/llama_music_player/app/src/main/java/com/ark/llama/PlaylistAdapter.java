package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Renders playlist rows and highlights the row that matches the current
 * song.
 *
 * <p>Each row shows the song title on the first line and the artist,
 * album, and genre joined by a bullet on the second line. The row whose
 * path matches {@link #mCurrentPlayingPath} uses the current theme color
 * for the title, a dark background, a light subtitle, and no divider.
 * Every other row uses the standard color scheme.</p>
 *
 * <p>The adapter applies minimal updates through {@link DiffUtil} and
 * requests partial rebinds through a payload when only the genre
 * changes, so the list does not re-measure rows while it is being
 * scrolled.</p>
 *
 * <h3>State Ownership</h3>
 * <p>The adapter owns three pieces of presentation state, all set by
 * the owning activity:</p>
 * <ul>
 *   <li><b>{@link #mCurrentPlayingPath}</b> — set through
 *       {@link #setCurrentPlayingPath(String)} or
 *       {@link #setCurrentPlayingIndex(int)}. The activity supplies the
 *       value; the adapter holds no copy of it elsewhere.</li>
 *   <li><b>Genre loading flag</b> — set through
 *       {@link #setGenreLoading(boolean)}. The activity supplies the
 *       value.</li>
 *   <li><b>Scroll flag</b> — set through
 *       {@link #setScrolling(boolean)}. The activity supplies the value
 *       from its scroll listener.</li>
 * </ul>
 * <p>The theme color is queried from {@link ThemeManager} on every full
 * bind. Theme changes trigger a rebind from the activity, and the query
 * reflects the new value.</p>
 *
 * <h3>Deferred Genre Updates</h3>
 * <p>While the user is scrolling, incoming genre updates are queued
 * rather than applied. Applying a payload-based rebind mid-scroll
 * would call {@link #notifyItemChanged(int)} on a visible row while the
 * scroll animation is still settling, and the current row would appear
 * to jump out of its own position. When scrolling ends, the queue is
 * flushed after {@link #SCROLL_SETTLE_MS} milliseconds.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The song list is a {@link CopyOnWriteArrayList}, so reads from the
 * main thread are safe while a background thread adds or removes
 * entries. Every other method runs on the main thread, which is where
 * the RecyclerView expects its adapter operations to run.</p>
 *
 * @see PlaylistActivity
 * @see Song
 * @see ThemeManager
 * @see DiffUtil
 *
 * @author Richard Korbla Adzido
 * @version 1.1.8
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Duration of the button press animation, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for the button press animation. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after the animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    /** Default theme color used when {@link ThemeManager} is unavailable. */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";

    /** Background color for the currently playing row. */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";

    /** Touch highlight color applied to a pressed row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for song titles in non-current rows. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Dark gray text color for subtitles in non-current rows. */
    private static final String TEXT_COLOR_DARK = "#808080";

    /** Separator used between metadata fields in the subtitle. */
    private static final String METADATA_SEPARATOR = " \u2022 ";

    /** Debounce delay for song click events, in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;

    /** Payload identifier for genre-only updates. */
    private static final String PAYLOAD_GENRE = "genre_update";

    /**
     * Delay after the scroll settles before queued genre updates are
     * flushed, in milliseconds. Gives the scroll-settling animation
     * time to complete so a rebind does not appear to move the current
     * row.
     */
    private static final long SCROLL_SETTLE_MS = 100L;

    // ========================================================================
    // Member Variables
    // ========================================================================

    /** Songs displayed by the adapter. */
    private final CopyOnWriteArrayList<Song> mSongs;

    /** Context used to inflate rows and resolve resources. */
    private final Context mContext;

    /** Listener notified on row taps, or null when none is set. */
    @Nullable private final OnSongClickListener mListener;

    /** Path of the song highlighted as currently playing, or null. */
    @Nullable private volatile String mCurrentPlayingPath = null;

    // ========================================================================
    // Genre Loading Batching
    // ========================================================================

    /** True while genre loading is in progress. */
    private volatile boolean mIsGenreLoading = false;

    /** Pending genre updates applied once the list is stable. */
    private final Map<String, String> mPendingGenreUpdates = new HashMap<>();

    /**
     * True while the owning recycler view is being scrolled by the user.
     * Genre updates are queued while this is true and flushed once the
     * scroll settles.
     */
    private volatile boolean mIsScrolling = false;

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Receives row taps.
     */
    public interface OnSongClickListener {

        /**
         * Called when a song row is tapped.
         *
         * @param position Adapter position of the tapped row
         * @param song Song associated with the tapped row
         */
        void onSongClick(int position, @NonNull Song song);
    }

    // ========================================================================
    // ViewHolder Class
    // ========================================================================

    /**
     * Caches references to the child views of a playlist row.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        /** Container layout that receives the row background and touches. */
        final LinearLayout mContentLayout;

        /** TextView for the title line. */
        final TextView mTitle;

        /** TextView for the subtitle line. */
        final TextView mSubtitle;

        /** Divider below the row. */
        final View mDivider;

        /**
         * Resolves the child views of the given row.
         *
         * @param view Inflated row view
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = view.findViewById(R.id.contentLayout);
            mTitle = view.findViewById(android.R.id.text1);
            mSubtitle = view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }

    // ========================================================================
    // DiffUtil Callback
    // ========================================================================

    /**
     * Computes the differences between the old and new song lists.
     *
     * <p>Two rows are the same item when their paths match. They have
     * the same contents when their genres match; a genre-only change is
     * reported through {@link #getChangePayload(int, int)} as
     * {@link #PAYLOAD_GENRE}.</p>
     */
    private static class SongDiffCallback extends DiffUtil.Callback {

        /** Song list before the update. */
        private final List<Song> oldList;

        /** Song list after the update. */
        private final List<Song> newList;

        /**
         * Constructs a callback for the given list pair.
         *
         * @param oldList Song list before the update
         * @param newList Song list after the update
         */
        SongDiffCallback(List<Song> oldList, List<Song> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        /**
         * Returns the size of the old list.
         *
         * @return Number of songs in the old list
         */
        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        /**
         * Returns the size of the new list.
         *
         * @return Number of songs in the new list
         */
        @Override
        public int getNewListSize() {
            return newList.size();
        }

        /**
         * Returns whether the two positions refer to the same song.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return True when the two songs have the same path
         */
        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            String oldPath = oldList.get(oldItemPosition).getPath();
            String newPath = newList.get(newItemPosition).getPath();
            return oldPath.equals(newPath);
        }

        /**
         * Returns whether the two positions have the same content.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return True when the two songs have the same genre
         */
        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            return oldSong.getGenre().equals(newSong.getGenre());
        }

        /**
         * Returns the payload delivered to a partial rebind when the two
         * positions have different content.
         *
         * @param oldItemPosition Position in the old list
         * @param newItemPosition Position in the new list
         * @return {@link #PAYLOAD_GENRE} when the genre differs, otherwise null
         */
        @Nullable
        @Override
        public Object getChangePayload(int oldItemPosition, int newItemPosition) {
            Song oldSong = oldList.get(oldItemPosition);
            Song newSong = newList.get(newItemPosition);
            if (!oldSong.getGenre().equals(newSong.getGenre())) {
                return PAYLOAD_GENRE;
            }
            return null;
        }
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new adapter.
     *
     * <p>The adapter starts with no current-playing path. The owning
     * activity supplies the initial and subsequent values through
     * {@link #setCurrentPlayingIndex(int)} or
     * {@link #setCurrentPlayingPath(String)}.</p>
     *
     * @param context Context used to inflate rows and resolve resources
     * @param songs Initial list of songs to display
     * @param listener Listener notified on row taps, or null
     */
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs,
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new CopyOnWriteArrayList<>(songs);
        mListener = listener;

        setHasStableIds(true);
    }

    // ========================================================================
    // RecyclerView.Adapter Methods
    // ========================================================================

    /**
     * Returns the stable identifier of the song at the given position.
     *
     * <p>The identifier is derived from the song's path, so it remains
     * the same across insertions, removals, and reorders that preserve
     * the song. RecyclerView uses this value to animate row changes.</p>
     *
     * @param position Adapter position
     * @return Stable identifier derived from the song's path, or the
     *         position when the song is null
     */
    @Override
    public long getItemId(int position) {
        Song song = mSongs.get(position);
        return song != null ? song.getPath().hashCode() : position;
    }

    /**
     * Creates a view holder for a playlist row.
     *
     * @param parent Parent view group into which the new view is added
     * @param viewType View type; identical for every row
     * @return A new view holder for the row
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Binds the song at the given position to the view holder.
     *
     * @param holder View holder to bind
     * @param position Adapter position
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        onBindViewHolder(holder, position, null);
    }

    /**
     * Binds the song at the given position to the view holder, with
     * partial-update support.
     *
     * <p>When the payload contains {@link #PAYLOAD_GENRE}, only the
     * subtitle is updated. This prevents the RecyclerView from
     * re-measuring the entire item, which would cause scroll position
     * jumps when text length changes during genre updates.</p>
     *
     * <p>On a full bind, the theme color is queried from
     * {@link ThemeManager}. Theme changes trigger a rebind from the
     * activity, so the query reflects the current value.</p>
     *
     * @param holder View holder to bind
     * @param position Adapter position
     * @param payloads Payload objects supplied by
     *        {@link DiffUtil.DiffResult#dispatchUpdatesTo(RecyclerView.Adapter)},
     *        or null when no payload is present
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position,
                                 @Nullable List<Object> payloads) {
        if (position < 0 || position >= mSongs.size()) {
            return;
        }

        final Song song = mSongs.get(position);
        if (song == null) {
            return;
        }

        boolean isGenreOnlyUpdate = payloads != null
            && !payloads.isEmpty()
            && payloads.contains(PAYLOAD_GENRE);

        if (!isGenreOnlyUpdate) {
            String title = song.getTitle();
            holder.mTitle.setText((title != null && !title.isEmpty())
                ? title : "Unknown Title");

            String currentPath = mCurrentPlayingPath;
            boolean isCurrent = (currentPath != null && currentPath.equals(song.getPath()));

            String themeColor = resolveThemeColor();

            if (isCurrent) {
                holder.mContentLayout.setBackgroundColor(
                    Color.parseColor(CURRENT_SONG_BACKGROUND));
                holder.mTitle.setTextColor(Color.parseColor(themeColor));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mDivider.setVisibility(View.GONE);
            } else {
                holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
                holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
                holder.mDivider.setVisibility(View.VISIBLE);
            }

            final boolean isCurrentForTouch = isCurrent;
            holder.mContentLayout.setOnTouchListener((view, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isCurrentForTouch) {
                            view.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                        } else {
                            view.setBackgroundColor(Color.TRANSPARENT);
                        }
                        break;
                    default:
                        break;
                }
                return false;
            });

            holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
                private long lastClickTime = 0;

                @Override
                public void onClick(final View view) {
                    long currentTime = SystemClock.elapsedRealtime();
                    if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                        return;
                    }
                    lastClickTime = currentTime;

                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition == RecyclerView.NO_POSITION
                            || adapterPosition >= mSongs.size()) {
                        return;
                    }

                    final Song clickedSong = mSongs.get(adapterPosition);
                    if (clickedSong == null) {
                        return;
                    }

                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                               .scaleY(ANIMATION_SCALE_DOWN)
                               .setDuration(ANIMATION_DURATION_MS)
                               .withEndAction(() -> {
                                   view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                             .scaleY(ANIMATION_SCALE_NORMAL)
                                             .setDuration(ANIMATION_DURATION_MS)
                                             .start();
                               }).start();

                    if (mListener != null) {
                        mListener.onSongClick(adapterPosition, clickedSong);
                    }
                }
            });
        }

        StringBuilder subtitle = new StringBuilder();

        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }

        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }

        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }

        holder.mSubtitle.setText(subtitle.toString());
    }

    /**
     * Returns the number of songs currently displayed.
     *
     * @return The number of songs in the adapter
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Replaces the current song list with the given list and dispatches
     * the minimal set of updates computed by {@link DiffUtil}.
     *
     * @param newSongs New list of songs to display
     */
    public void updateList(@NonNull List<Song> newSongs) {
        List<Song> oldList = new ArrayList<>(mSongs);
        List<Song> newList = new ArrayList<>(newSongs);

        DiffUtil.DiffResult diffResult =
            DiffUtil.calculateDiff(new SongDiffCallback(oldList, newList));

        mSongs.clear();
        mSongs.addAll(newList);

        diffResult.dispatchUpdatesTo(this);
    }

    /**
     * Sets the path of the song highlighted as currently playing.
     *
     * <p>The adapter holds no copy of this value elsewhere. It is a
     * presentation hint supplied by the owning activity, which reads the
     * authoritative value from {@link MusicService}.</p>
     *
     * @param songPath Path of the currently playing song, or null for
     *        none
     */
    public void setCurrentPlayingPath(@Nullable String songPath) {
        String oldPath = mCurrentPlayingPath;
        mCurrentPlayingPath = songPath;

        if (oldPath != null) {
            int oldPosition = findPositionByPath(oldPath);
            if (oldPosition >= 0 && oldPosition < mSongs.size()) {
                notifyItemChanged(oldPosition);
            }
        }
        if (songPath != null) {
            int newPosition = findPositionByPath(songPath);
            if (newPosition >= 0 && newPosition < mSongs.size()) {
                notifyItemChanged(newPosition);
            }
        }
    }

    /**
     * Returns the path of the song highlighted as currently playing.
     *
     * @return The current playing path, or null when none is set
     */
    @Nullable
    public String getCurrentPlayingPath() {
        return mCurrentPlayingPath;
    }

    /**
     * Returns the song at the given adapter position.
     *
     * @param position Adapter position
     * @return The song at the given position, or null when the position
     *         is out of range
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }

    /**
     * Records whether the owning recycler view is being scrolled by the
     * user.
     *
     * <p>While scrolling is in progress, genre updates are queued rather
     * than applied immediately. Applying them mid-scroll would call
     * {@link #notifyItemChanged(int)} on visible rows while the scroll
     * animation is still settling, and the current row would appear to
     * jump out of its own position. When scrolling ends, the queue is
     * flushed after {@link #SCROLL_SETTLE_MS} milliseconds.</p>
     *
     * @param scrolling True while the user is scrolling
     */
    public void setScrolling(boolean scrolling) {
        mIsScrolling = scrolling;
        if (!scrolling && !mIsGenreLoading && !mPendingGenreUpdates.isEmpty()) {
            new Handler(Looper.getMainLooper()).postDelayed(
                this::flushPendingGenreUpdates, SCROLL_SETTLE_MS);
        }
    }

    /**
     * Applies every queued genre update through the payload path and
     * clears the queue. No-op while scrolling or while genre loading is
     * in flight.
     */
    private void flushPendingGenreUpdates() {
        if (mIsScrolling || mIsGenreLoading || mPendingGenreUpdates.isEmpty()) {
            return;
        }
        for (Map.Entry<String, String> entry : mPendingGenreUpdates.entrySet()) {
            applyGenreUpdate(entry.getKey(), entry.getValue(), true);
        }
        mPendingGenreUpdates.clear();
    }

    /**
     * Sets whether genre loading is in progress.
     *
     * <p>When genre loading ends and the recycler view is not being
     * scrolled, every queued genre update is applied and the queue is
     * cleared. When the user is scrolling, the queue is held until
     * scroll ends.</p>
     *
     * @param loading True while genre loading is in progress
     */
    public void setGenreLoading(boolean loading) {
        mIsGenreLoading = loading;
        if (!loading && !mIsScrolling) {
            flushPendingGenreUpdates();
        }
    }

    /**
     * Applies a genre update to the song with the given path.
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     * @param notify True to notify the adapter with the
     *        {@link #PAYLOAD_GENRE} payload
     */
    private void applyGenreUpdate(String songPath, String newGenre, boolean notify) {
        int position = findPositionByPath(songPath);
        if (position >= 0 && position < mSongs.size()) {
            Song song = mSongs.get(position);
            if (song != null) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    if (notify) {
                        notifyItemChanged(position, PAYLOAD_GENRE);
                    }
                }
            }
        }
    }

    /**
     * Updates the genre of the song with the given path.
     *
     * <p>While genre loading is in progress or the user is scrolling,
     * the update is queued and applied once the list is stable, so the
     * visible rows are not modified mid-scroll.</p>
     *
     * @param songPath Path of the song to update
     * @param newGenre New genre value
     */
    public void updateSongGenre(String songPath, String newGenre) {
        if (mIsGenreLoading || mIsScrolling) {
            mPendingGenreUpdates.put(songPath, newGenre);
        } else {
            applyGenreUpdate(songPath, newGenre, true);
        }
    }

    // ========================================================================
    // Backward Compatibility Methods
    // ========================================================================

    /**
     * Sets the currently playing song from its adapter position.
     *
     * @param index Adapter position of the currently playing song, or a
     *        negative value to clear
     * @deprecated Use {@link #setCurrentPlayingPath(String)}. This method
     *             requires the caller to know the adapter position,
     *             which can change between calls when the list is
     *             re-sorted or filtered.
     */
    @Deprecated
    public void setCurrentPlayingIndex(int index) {
        if (index >= 0 && index < mSongs.size()) {
            Song song = mSongs.get(index);
            if (song != null) {
                setCurrentPlayingPath(song.getPath());
            }
        } else {
            setCurrentPlayingPath(null);
        }
    }

    /**
     * Returns the adapter position of the currently playing song.
     *
     * @return Adapter position of the currently playing song, or -1 when
     *         none is set
     * @deprecated Use {@link #getCurrentPlayingPath()}. The position can
     *             change between calls when the list is re-sorted or
     *             filtered.
     */
    @Deprecated
    public int getCurrentPlayingIndex() {
        if (mCurrentPlayingPath != null) {
            return findPositionByPath(mCurrentPlayingPath);
        }
        return -1;
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Returns the adapter position of the song with the given path, or
     * -1 when it is not present.
     *
     * @param songPath Path to search for, or null
     * @return Adapter position of the matching song, or -1
     */
    private int findPositionByPath(@Nullable String songPath) {
        if (songPath == null || mSongs == null) {
            return -1;
        }
        for (int index = 0; index < mSongs.size(); index++) {
            Song song = mSongs.get(index);
            if (song != null && songPath.equals(song.getPath())) {
                return index;
            }
        }
        return -1;
    }

    /**
     * Resolves the current theme color, falling back to the default when
     * the theme manager is unavailable.
     *
     * @return The theme color as a hex string, such as
     *         {@code "#B8A86E"}
     */
    @NonNull
    private String resolveThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            if (themeManager != null) {
                String color = themeManager.getCurrentColor();
                if (color != null && !color.isEmpty()) {
                    return color;
                }
            }
            return DEFAULT_THEME_COLOR;
        } catch (Exception exception) {
            return DEFAULT_THEME_COLOR;
        }
    }
}