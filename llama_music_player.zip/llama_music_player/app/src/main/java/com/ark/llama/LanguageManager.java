package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Locale;

/**
 * Stores the application's current display language and exposes the
 * set of available languages.
 *
 * <p>The current language is selected by BCP 47 tag and persisted to
 * {@link SharedPreferences}, and read back on the next process launch.
 * The class is the single source of truth for which language is
 * applied; {@link LanguageDialog} writes the selection through
 * {@link #setLanguage(String)}, and every activity applies it by
 * wrapping its base context through {@link #wrap(Context)} in
 * {@code attachBaseContext}.</p>
 *
 * <h3>Available Languages</h3>
 * <p>The supported set is a curated list of the most widely used
 * languages in global streaming markets. Each language's display name
 * is its endonym — the name of the language in that language — so the
 * picker is legible to a speaker of any of the listed languages
 * without requiring the app to first switch locales. The set is
 * declared once, in {@link #LANGUAGE_TAGS}; the display names are
 * declared in {@link #LANGUAGE_NAMES} at the same index.</p>
 *
 * <h3>Locale Application</h3>
 * <p>Android applies a locale through the activity's base context. The
 * {@link #wrap(Context)} method produces a context whose configuration
 * carries the selected locale; an activity that overrides
 * {@code attachBaseContext(Context)} with a call to that method
 * receives the selected locale throughout its lifetime, and every
 * string resolved through {@code getString} is read from the matching
 * resource folder. Changing the selection requires the activity to be
 * recreated so the new base context takes effect.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The singleton instance is created under double-checked locking.
 * Every read returns the value held in memory at that moment;
 * {@link #setLanguage(String)} updates the in-memory value before
 * scheduling the preference write, so a subsequent read observes the
 * new value even when the write has not yet been flushed.</p>
 *
 * @see LanguageDialog
 * @see SharedPreferences
 *
 * @author Richard Korbla Adzido
 * @version 1.3.0
 * @since 1.3.0
 */
public class LanguageManager {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for the persisted language tag. */
    private static final String KEY_LANGUAGE_TAG = "app_language_tag";

    /** Default language tag, corresponding to English. */
    private static final String DEFAULT_LANGUAGE_TAG = "en";

    // ============================================================================
    // Language Data
    // ============================================================================

    /**
     * BCP 47 tags of the supported languages.
     *
     * <p>Index-aligned with {@link #LANGUAGE_NAMES} and
     * {@link #LANGUAGE_NAMES_EN}. The same set is declared in
     * {@code res/xml/locales_config.xml} for the platform's per-app
     * language picker and in the app module's
     * {@code resourceConfigurations} for the release artifact's bound
     * set; adding or removing a language means editing all three.</p>
     *
     * <p>The tag for Indonesian is {@code "in"} rather than the current
     * BCP 47 form {@code "id"}, matching the folder convention Android
     * uses for {@code values-in/}. The platform accepts both forms, and
     * this form is the one that resolves to the bundled resources. The
     * same split applies to Hebrew ({@code iw} / {@code he}) and Yiddish
     * ({@code ji} / {@code yi}) if they are ever added; neither is in
     * the current set.</p>
     */
    private static final String[] LANGUAGE_TAGS = {
        "en",  // 0  English
        "es",  // 1  Spanish
        "fr",  // 2  French
        "de",  // 3  German
        "it",  // 4  Italian
        "pt",  // 5  Portuguese
        "ru",  // 6  Russian
        "zh",  // 7  Chinese
        "ja",  // 8  Japanese
        "ko",  // 9  Korean
        "hi",  // 10 Hindi
        "ar",  // 11 Arabic
        "tr",  // 12 Turkish
        "in",  // 13 Indonesian (folder code; current BCP 47 tag is "id")
        "nl",  // 14 Dutch
        "pl",  // 15 Polish
    };

    /**
     * Endonyms — the names of each language in that language —
     * index-aligned with {@link #LANGUAGE_TAGS}.
     *
     * <p>Deliberately not translatable: a speaker browsing the picker
     * for their language should recognise it in its own script, not in
     * the currently-applied locale's approximation of it.</p>
     */
    private static final String[] LANGUAGE_NAMES = {
        "English",           // 0
        "Español",           // 1
        "Français",          // 2
        "Deutsch",           // 3
        "Italiano",          // 4
        "Português",         // 5
        "Русский",           // 6
        "中文",               // 7
        "日本語",             // 8
        "한국어",             // 9
        "हिन्दी",              // 10
        "العربية",            // 11
        "Türkçe",            // 12
        "Bahasa Indonesia",  // 13
        "Nederlands",        // 14
        "Polski",            // 15
    };

    /**
     * English exonyms — the names of each language in English —
     * index-aligned with {@link #LANGUAGE_TAGS}. Used for logging and
     * for any surface that needs the English name regardless of the
     * app's current locale.
     */
    private static final String[] LANGUAGE_NAMES_EN = {
        "English",     // 0
        "Spanish",     // 1
        "French",      // 2
        "German",      // 3
        "Italian",     // 4
        "Portuguese",  // 5
        "Russian",     // 6
        "Chinese",     // 7
        "Japanese",    // 8
        "Korean",      // 9
        "Hindi",       // 10
        "Arabic",      // 11
        "Turkish",     // 12
        "Indonesian",  // 13
        "Dutch",       // 14
        "Polish",      // 15
    };

    // ============================================================================
    // Singleton
    // ============================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile LanguageManager sInstance;

    /** Application context used for preference access and locale application. */
    @NonNull
    private final Context mContext;

    /** Current language tag. */
    @NonNull
    private String mCurrentLanguageTag;

    /**
     * Constructs the singleton and reads the persisted language into
     * memory.
     *
     * @param context A context; the application context is retained
     */
    private LanguageManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadLanguage();
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static LanguageManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (LanguageManager.class) {
                if (sInstance == null) {
                    sInstance = new LanguageManager(context);
                }
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Language Loading and Saving
    // ============================================================================

    /**
     * Reads the persisted language tag into memory.
     *
     * <p>When the stored tag is missing or refers to a language that
     * is no longer in the supported set, the default tag is used.</p>
     */
    private void loadLanguage() {
        SharedPreferences preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE);
        String savedTag = preferences.getString(
            KEY_LANGUAGE_TAG, DEFAULT_LANGUAGE_TAG);
        if (savedTag == null || !isSupportedTag(savedTag)) {
            savedTag = DEFAULT_LANGUAGE_TAG;
        }
        mCurrentLanguageTag = savedTag;
    }

    /**
     * Applies the language with the given tag and persists the
     * selection.
     *
     * <p>A tag that is not in the supported set is ignored. A supported
     * tag updates the in-memory value before the preference write is
     * scheduled, so a subsequent read observes the new language even
     * when the write has not yet been flushed.</p>
     *
     * @param languageTag BCP 47 tag of the language to apply
     */
    public void setLanguage(@NonNull String languageTag) {
        if (!isSupportedTag(languageTag)) {
            return;
        }
        mCurrentLanguageTag = languageTag;
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE_TAG, languageTag)
            .apply();
    }

    /**
     * Returns whether the given tag refers to a supported language.
     *
     * @param languageTag Tag to test
     * @return True when the tag is in the supported set
     */
    private boolean isSupportedTag(@NonNull String languageTag) {
        for (String candidateTag : LANGUAGE_TAGS) {
            if (candidateTag.equals(languageTag)) {
                return true;
            }
        }
        return false;
    }

    // ============================================================================
    // Getters
    // ============================================================================

    /**
     * Returns the current language tag.
     *
     * @return The current BCP 47 language tag, such as {@code "en"}
     */
    @NonNull
    public String getCurrentLanguageTag() {
        return mCurrentLanguageTag;
    }

    /**
     * Returns the index of the current language in the supported set.
     *
     * @return The index into the language arrays, or 0 when the current
     *         tag is not found
     */
    public int getCurrentLanguageIndex() {
        for (int index = 0; index < LANGUAGE_TAGS.length; index++) {
            if (LANGUAGE_TAGS[index].equals(mCurrentLanguageTag)) {
                return index;
            }
        }
        return 0;
    }

    /**
     * Returns the endonym of the current language.
     *
     * @return The name of the current language in its own language,
     *         such as {@code "Español"} for Spanish
     */
    @NonNull
    public String getCurrentLanguageName() {
        return LANGUAGE_NAMES[getCurrentLanguageIndex()];
    }

    /**
     * Returns a copy of every supported language's endonym.
     *
     * @return A new array containing every language name
     */
    @NonNull
    public String[] getLanguageNames() {
        return LANGUAGE_NAMES.clone();
    }

    /**
     * Returns a copy of every supported language's English name.
     *
     * @return A new array containing every English language name
     */
    @NonNull
    public String[] getLanguageNamesEn() {
        return LANGUAGE_NAMES_EN.clone();
    }

    /**
     * Returns a copy of every supported language's BCP 47 tag.
     *
     * @return A new array containing every language tag
     */
    @NonNull
    public String[] getLanguageTags() {
        return LANGUAGE_TAGS.clone();
    }

    /**
     * Returns the number of supported languages.
     *
     * @return The size of the supported set
     */
    public int getLanguageCount() {
        return LANGUAGE_TAGS.length;
    }

    /**
     * Returns the display name of the language at the given index.
     *
     * @param languageIndex Index into the language arrays
     * @return The language's endonym, or null when the index is out of
     *         range
     */
    @Nullable
    public String getLanguageName(int languageIndex) {
        if (languageIndex < 0 || languageIndex >= LANGUAGE_NAMES.length) {
            return null;
        }
        return LANGUAGE_NAMES[languageIndex];
    }

    /**
     * Returns the BCP 47 tag of the language at the given index.
     *
     * @param languageIndex Index into the language arrays
     * @return The language tag, or null when the index is out of range
     */
    @Nullable
    public String getLanguageTag(int languageIndex) {
        if (languageIndex < 0 || languageIndex >= LANGUAGE_TAGS.length) {
            return null;
        }
        return LANGUAGE_TAGS[languageIndex];
    }

    // ============================================================================
    // Locale Application
    // ============================================================================

    /**
     * Returns the current language as a {@link Locale}.
     *
     * @return The current locale
     */
    @NonNull
    public Locale getCurrentLocale() {
        return Locale.forLanguageTag(mCurrentLanguageTag);
    }

    /**
     * Wraps the given context with the currently selected locale.
     *
     * <p>Called from an activity's
     * {@code attachBaseContext(Context)} override. The wrapped context
     * carries the selected locale in its configuration, so every
     * string resolved from it is read from the matching resource
     * folder and every layout direction is resolved under the
     * locale's rules.</p>
     *
     * <p>Below {@link Build.VERSION_CODES#N} the configuration carries
     * a single {@link Locale} field rather than a {@link LocaleList};
     * the two branches set the same value in the two shapes the
     * framework supports.</p>
     *
     * @param context Base context to wrap
     * @return A context whose configuration carries the current locale
     */
    @NonNull
    public Context wrap(@NonNull Context context) {
        Locale locale = getCurrentLocale();
        Locale.setDefault(locale);
        Configuration configuration = new Configuration(
            context.getResources().getConfiguration());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            configuration.setLocales(new LocaleList(locale));
        } else {
            configuration.locale = locale;
        }
        return context.createConfigurationContext(configuration);
    }
}