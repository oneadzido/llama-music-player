package com.ark.llama;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * An immutable snapshot of the three paths the album-art carousel
 * renders, together with the transition counter that produced it.
 *
 * <p>A window names the previous neighbour, the current song, and the
 * next neighbour, and carries {@link MusicService}'s monotonic
 * transition counter. It is a value: equality compares the three paths
 * and the generation, and the same window published twice is a no-op
 * for every consumer. The window is computed by {@link MusicService}
 * and carried on every {@code UPDATE_PLAYER} broadcast.</p>
 *
 * <h3>Authority</h3>
 * <p>{@link MusicService} is the sole producer of a window.
 * {@link AlbumArtCarousel} is the sole consumer. Nothing else computes
 * a window, and no consumer computes neighbours from a playlist. Every
 * path through the service — a transport button, a headset key, a
 * notification action, a Bluetooth resume, a shuffle re-pick, a sort
 * reorder, a library reset — produces a window, and every window is
 * adopted through the same method. This is what keeps the carousel in
 * sync with the service unconditionally.</p>
 *
 * <h3>Null Semantics</h3>
 * <p>{@link #previousPath} and {@link #nextPath} are the neighbours the
 * service's next and previous requests would advance to, under the
 * current repeat mode and shuffle setting. They are null only when the
 * playlist has no such neighbour — a single-song playlist, or a
 * shuffle re-pick that cannot avoid the current index. Under repeat-one
 * the window still publishes the positional or shuffle-chosen
 * neighbours while the service restarts the current song, so the
 * carousel has somewhere to slide and the spring-back that follows is
 * the visible acknowledgement of the restart. {@link #currentPath} is
 * null only when the service is idle; in every other state the service
 * names a display song, and the current path is that song's path.</p>
 *
 * <h3>Generation</h3>
 * <p>{@link #generation} is the service's transition counter at the
 * moment the window was produced. It advances only when a fresh
 * transition begins: a prepare for a new song, a reprepare that
 * restarts the current song, a transition to idle. It does not advance
 * for a pause, a resume, a seek, a metadata poke, or a position
 * checkpoint, each of which re-publishes an otherwise unchanged
 * window. The carousel compares the generation of an incoming window
 * against the generation of the window it last held to distinguish a
 * fresh transition from a re-publication. This is what lets a
 * repeat-one restart — whose three paths are unchanged — be animated
 * exactly as a song change is.</p>
 *
 * @see MusicService
 * @see AlbumArtCarousel
 *
 * @author Richard Korbla Adzido
 * @version 1.2.1
 * @since 1.2.0
 */
public final class PlaybackWindow {

    /** Path of the previous neighbour, or null when none. */
    @Nullable public final String previousPath;

    /** Path of the current song, or null when the service is idle. */
    @Nullable public final String currentPath;

    /** Path of the next neighbour, or null when none. */
    @Nullable public final String nextPath;

    /**
     * The service's transition counter at the moment this window was
     * produced.
     */
    public final long generation;

    /** The empty window, published when the service is idle. */
    @NonNull public static final PlaybackWindow EMPTY =
        new PlaybackWindow(null, null, null, 0L);

    /**
     * Constructs a window from the three paths and the service's
     * transition counter.
     *
     * @param previousPath Path of the previous neighbour, or null
     * @param currentPath Path of the current song, or null
     * @param nextPath Path of the next neighbour, or null
     * @param generation The service's transition counter
     */
    public PlaybackWindow(@Nullable String previousPath,
                          @Nullable String currentPath,
                          @Nullable String nextPath,
                          long generation) {
        this.previousPath = previousPath;
        this.currentPath = currentPath;
        this.nextPath = nextPath;
        this.generation = generation;
    }

    /**
     * Constructs a window from the three paths, with a generation of
     * zero.
     *
     * <p>Provided for callers that do not have a service generation to
     * hand — the empty sentinel, test fixtures, and any code that
     * builds a window outside the service. A window constructed this
     * way cannot animate a same-song restart, because the carousel
     * cannot tell it apart from a re-publication.</p>
     *
     * @param previousPath Path of the previous neighbour, or null
     * @param currentPath Path of the current song, or null
     * @param nextPath Path of the next neighbour, or null
     */
    public PlaybackWindow(@Nullable String previousPath,
                          @Nullable String currentPath,
                          @Nullable String nextPath) {
        this(previousPath, currentPath, nextPath, 0L);
    }

    /**
     * Returns whether the given path is named by this window.
     *
     * @param path Path to test, or null
     * @return True when the path equals one of the three window paths
     */
    public boolean contains(@Nullable String path) {
        if (path == null) {
            return false;
        }
        return path.equals(previousPath)
            || path.equals(currentPath)
            || path.equals(nextPath);
    }

    /**
     * Returns whether this window and the given object describe the
     * same three paths and the same generation.
     *
     * @param object Object to compare against, or null
     * @return True when the given object is a window with the same
     *         three paths and generation
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof PlaybackWindow)) {
            return false;
        }
        PlaybackWindow otherWindow = (PlaybackWindow) object;
        return generation == otherWindow.generation
            && pathsEqual(previousPath, otherWindow.previousPath)
            && pathsEqual(currentPath, otherWindow.currentPath)
            && pathsEqual(nextPath, otherWindow.nextPath);
    }

    /**
     * Returns a hash code derived from the three paths and the
     * generation.
     *
     * @return The hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(previousPath, currentPath, nextPath, generation);
    }

    /**
     * Returns a debug representation of this window.
     *
     * @return A string containing the three paths and the generation
     */
    @NonNull
    @Override
    public String toString() {
        return "PlaybackWindow{previous=" + previousPath
            + ", current=" + currentPath
            + ", next=" + nextPath
            + ", generation=" + generation + '}';
    }

    /**
     * Returns whether two nullable paths are equal.
     *
     * @param firstPath First path, or null
     * @param secondPath Second path, or null
     * @return True when both are null or both are equal
     */
    private static boolean pathsEqual(@Nullable String firstPath,
                                      @Nullable String secondPath) {
        return firstPath == null
            ? secondPath == null
            : firstPath.equals(secondPath);
    }
}