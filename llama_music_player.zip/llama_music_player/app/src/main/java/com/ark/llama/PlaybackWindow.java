package com.ark.llama;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * An immutable snapshot of the three paths the album-art carousel
 * renders.
 *
 * <p>A window names the previous neighbour, the current song, and the
 * next neighbour. It is a value: equality compares the three paths, and
 * the same window published twice is a no-op for every consumer. The
 * window is computed by {@link MusicService} and carried on every
 * {@code UPDATE_PLAYER} broadcast.</p>
 *
 * <h3>Authority</h3>
 * <p>{@link MusicService} is the sole producer of a window.
 * {@link AlbumArtCarousel} is the sole consumer. Nothing else computes
 * a window, and no consumer computes neighbours from a playlist. Every
 * path through the service — a transport button, a headset key, a
 * notification action, a Bluetooth resume, a shuffle re-pick, a sort
 * reorder, a library reset — produces a window, and every window is
 * adopted through the same method. This is what keeps the carousel in
 * sync with the service unconditionally.</p>
 *
 * <h3>Null Semantics</h3>
 * <p>{@link #previousPath} and {@link #nextPath} are null when the
 * corresponding neighbour does not exist, or when the neighbour the
 * service would pick equals the current song — the repeat-one case, the
 * single-song case, and the case in which a shuffle re-pick lands on
 * the current index. {@link #currentPath} is null only when the service
 * is idle; in every other state the service names a display song, and
 * the current path is that song's path.</p>
 *
 * @see MusicService
 * @see AlbumArtCarousel
 *
 * @author Richard Korbla Adzido
 * @version 1.2.0
 * @since 1.2.0
 */
public final class PlaybackWindow {

    /** Path of the previous neighbour, or null when none. */
    @Nullable public final String previousPath;

    /** Path of the current song, or null when the service is idle. */
    @Nullable public final String currentPath;

    /** Path of the next neighbour, or null when none. */
    @Nullable public final String nextPath;

    /** The empty window, published when the service is idle. */
    @NonNull public static final PlaybackWindow EMPTY =
        new PlaybackWindow(null, null, null);

    /**
     * Constructs a window from the three paths.
     *
     * @param previousPath Path of the previous neighbour, or null
     * @param currentPath Path of the current song, or null
     * @param nextPath Path of the next neighbour, or null
     */
    public PlaybackWindow(@Nullable String previousPath,
                          @Nullable String currentPath,
                          @Nullable String nextPath) {
        this.previousPath = previousPath;
        this.currentPath = currentPath;
        this.nextPath = nextPath;
    }

    /**
     * Returns whether the given path is named by this window.
     *
     * @param path Path to test, or null
     * @return True when the path equals one of the three window paths
     */
    public boolean contains(@Nullable String path) {
        if (path == null) {
            return false;
        }
        return path.equals(previousPath)
            || path.equals(currentPath)
            || path.equals(nextPath);
    }

    /**
     * Returns whether this window and the given object describe the
     * same three paths.
     *
     * @param object Object to compare against, or null
     * @return True when the given object is a window with the same three
     *         paths
     */
    @Override
    public boolean equals(@Nullable Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof PlaybackWindow)) {
            return false;
        }
        PlaybackWindow otherWindow = (PlaybackWindow) object;
        return pathsEqual(previousPath, otherWindow.previousPath)
            && pathsEqual(currentPath, otherWindow.currentPath)
            && pathsEqual(nextPath, otherWindow.nextPath);
    }

    /**
     * Returns a hash code derived from the three paths.
     *
     * @return The hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(previousPath, currentPath, nextPath);
    }

    /**
     * Returns a debug representation of this window.
     *
     * @return A string containing the three paths
     */
    @NonNull
    @Override
    public String toString() {
        return "PlaybackWindow{previous=" + previousPath
            + ", current=" + currentPath
            + ", next=" + nextPath + '}';
    }

    /**
     * Returns whether two nullable paths are equal.
     *
     * @param firstPath First path, or null
     * @param secondPath Second path, or null
     * @return True when both are null or both are equal
     */
    private static boolean pathsEqual(@Nullable String firstPath,
                                      @Nullable String secondPath) {
        return firstPath == null
            ? secondPath == null
            : firstPath.equals(secondPath);
    }
}