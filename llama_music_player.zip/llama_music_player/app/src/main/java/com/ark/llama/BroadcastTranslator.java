// BroadcastTranslator.java
package com.ark.llama;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.util.Log;

import androidx.core.content.ContextCompat;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.EventBusException;

import java.util.ArrayList;
import java.util.List;

/**
 * Sole registrar of every in-process broadcast receiver in the app,
 * and sole translator from {@link Intent} to typed events on the
 * greenrobot EventBus.
 *
 * <p>Before the migration each of the ten receiver-owning classes
 * registered its own {@link BroadcastReceiver} instances, unregistered
 * them in the matching lifecycle method, and dispatched on
 * {@code intent.getAction()} inside {@code onReceive}. That pattern
 * was duplicated ten times, was invisible to the compiler, and
 * silently lost events whenever a class forgot to register or
 * unregister in the right place. This class replaces it with one
 * registrar, one receiver per action, and one event class per
 * action.</p>
 *
 * <h3>State Ownership</h3>
 * <p>This class owns three pieces of state: the started flag, the
 * list of registered receivers, and the singleton itself. It owns
 * no playback state, no UI state, and no persisted state. Every
 * action and every extra it reads is declared as a {@code public}
 * constant on this class, so every sender in the app can reference
 * the string symbolically instead of duplicating a literal. The
 * action set is the single source of truth for the string values;
 * a future change to any stem propagates to every sender at compile
 * time.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Started once from {@link LlamaMusicPlayer#onCreate()} and stopped
 * from {@link LlamaMusicPlayer#onTerminate()}. Both entry points are
 * idempotent. Do not start or stop from any other class.</p>
 *
 * <h3>Threading</h3>
 * <p>Every receiver is registered on the application context and
 * invoked on the main thread, matching the delivery of the
 * in-process broadcasts it replaces. Subscribers use the default
 * {@code ThreadMode.POSTING} and therefore run on the same
 * main-thread turn the broadcast itself was dispatched on. Do not
 * add a {@code ThreadMode} to any subscriber: the subscriber bodies
 * assume they are on the main thread.</p>
 *
 * <h3>Event Classes</h3>
 * <p>Every event class below carries exactly the fields its sender
 * writes. Fields a subscriber does not read are still carried, for
 * wire fidelity. If a future sender writes a new extra, add the
 * field here — do not have subscribers read extras out of a
 * reconstructed Intent. The event class is the single point at
 * which a new extra enters the app.</p>
 *
 * <h3>Security</h3>
 * <p>Every receiver is registered with
 * {@code ContextCompat.RECEIVER_NOT_EXPORTED} on API 33+, and with
 * the legacy {@code registerReceiver} overload on earlier releases.
 * These are strictly in-process broadcasts, so the not-exported
 * flag is the correct mode. A stem that needs to be received from
 * outside the app is not migrated here and stays as a manifest
 * receiver (for example {@code BluetoothReceiver} and
 * {@code MediaButtonReceiver}).</p>
 *
 * <h3>Failure Handling</h3>
 * <p>A receiver that throws from {@code translate(...)} logs the
 * failure and continues; a receiver that returns null from
 * {@code translate(...)} is ignored. A registration that throws is
 * logged and the receiver is not tracked, so {@link #stop()} does
 * not attempt to unregister it. The intent is that a single broken
 * stem never takes down the rest of the translator.</p>
 *
 * @see LlamaMusicPlayer
 * @see MusicService
 * @see MusicPlayer
 * @see PlaylistManager
 * @see NotificationController
 * @see ToastManager
 *
 * @author Richard Korbla Adzido
 * @version 1.5.1
 * @since 1.5.0
 */
public final class BroadcastTranslator {

    private static final String TAG = "BroadcastTranslator";

    // ============================================================================
    // Actions
    // ============================================================================

    // ----- Playback -----

    /** Sent by {@link MusicService#broadcastUpdate()} to publish the
     *  full playback snapshot. */
    public static final String ACTION_UPDATE_PLAYER = "UPDATE_PLAYER";

    /** Sent to ask {@link MusicService} to play the song at a given
     *  path. */
    public static final String ACTION_PLAY_SONG = "PLAY_SONG";

    /** Sent by {@link MusicService} when playback was recovered after
     *  a failure. */
    public static final String ACTION_PLAYBACK_RECOVERED = "PLAYBACK_RECOVERED";

    // ----- Bluetooth -----

    /** Sent by {@link BluetoothReceiver} when a headset connects. */
    public static final String ACTION_BLUETOOTH_CONNECTED = "BLUETOOTH_CONNECTED";

    /** Sent by {@link BluetoothReceiver} and {@link MetadataEditor}
     *  to request a pause ahead of the disconnect / write. */
    public static final String ACTION_BLUETOOTH_PAUSE = "BLUETOOTH_PAUSE";

    /** Sent by {@link MetadataEditor} to request a resume after a
     *  metadata write. */
    public static final String ACTION_BLUETOOTH_PLAY = "BLUETOOTH_PLAY";

    // ----- Playlist and sync -----

    /** Sent to ask the player screen to redraw its playlist. */
    public static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";

    /** Sent to ask playlist consumers to refresh their view from the
     *  songs table. */
    public static final String ACTION_REFRESH_PLAYLIST = "REFRESH_PLAYLIST";

    /** Sent by {@link FolderManager} to ask the service to persist
     *  its player state before the folder-update cycle begins. */
    public static final String ACTION_SAVE_PLAYER_STATE_NOW = "SAVE_PLAYER_STATE_NOW";

    /** Sent by {@link FolderManager} and {@link PlaylistManager} when
     *  a sync scan finishes. */
    public static final String ACTION_SYNC_COMPLETE = "SYNC_COMPLETE";

    /** Sent by {@link FolderManager} when a sync scan begins. */
    public static final String ACTION_SYNC_STARTED = "SYNC_STARTED";

    /** Sent by {@link PlaylistManager}, {@link StorageObserver}, and
     *  {@link FolderManager} to ask every {@link MusicLibrary}
     *  instance to reload from the songs table. */
    public static final String ACTION_UPDATE_PLAYLIST = "UPDATE_PLAYLIST";

    /** Sent by {@link FolderManager} and {@link MusicPlayer} to ask
     *  every consumer to rebuild its playlist from the current
     *  folder set. */
    public static final String ACTION_UPDATE_PLAYLIST_FROM_FOLDERS = "UPDATE_PLAYLIST_FROM_FOLDERS";

    // ----- Metadata, sort, scope -----

    /** Sent by {@link FolderManager} to apply a new
     *  {@link PlaybackScope}. */
    public static final String ACTION_APPLY_PLAYBACK_SCOPE = "APPLY_PLAYBACK_SCOPE";

    /** Sent by {@link MetadataEditor} after a successful tag write. */
    public static final String ACTION_METADATA_UPDATED = "METADATA_UPDATED";

    /** Sent to ask {@link MusicService} to park a song path as the
     *  target of the next transition. */
    public static final String ACTION_SET_PENDING_SONG = "SET_PENDING_SONG";

    /** Sent by {@link PlaylistActivity} when the user cycles the
     *  sort mode. */
    public static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    // ----- Language and theme -----

    /** Sent by {@link CreditsDialog} when the user selects a
     *  language. Every activity recreates in response. */
    public static final String ACTION_LANGUAGE_CHANGED = "LANGUAGE_CHANGED";

    /** Sent by {@link ThemeManager} when the user selects a theme
     *  color. Every activity, dialog, and singleton that renders
     *  chrome rebuilds in response. */
    public static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";

    // ----- Audio -----

    /** Sent by {@link MusicService} whenever a new audio session is
     *  attached to the equalizer. */
    public static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Sent by {@link EqualizerActivity} after a pitch or speed
     *  change, to ask {@link MusicService} to refresh the
     *  MediaPlayer's PlaybackParams. */
    public static final String ACTION_UPDATE_PLAYBACK_PARAMS = "UPDATE_PLAYBACK_PARAMS";

    // ----- Playing-state query -----

    /** Sent by {@link MetadataEditor} to ask {@link MusicService} for
     *  its current playing state. */
    public static final String ACTION_GET_PLAYING_STATE = "GET_PLAYING_STATE";

    /** Sent by {@link MusicService} in reply to
     *  {@link #ACTION_GET_PLAYING_STATE}. */
    public static final String ACTION_PLAYING_STATE_RESPONSE = "PLAYING_STATE_RESPONSE";

    // ----- External triggers -----

    /** Sent to ask the app to clear its playlist. */
    public static final String ACTION_CLEAR_PLAYLIST = "CLEAR_PLAYLIST";

    /** Sent by {@link PlaylistManager} during a genre load to publish
     *  per-song progress. */
    public static final String ACTION_GENRE_UPDATE = "GENRE_UPDATE";

    /** Sent when the loose-tracks table changes. */
    public static final String ACTION_LOOSE_TRACKS_UPDATED = "LOOSE_TRACKS_UPDATED";

    /** Sent to ask {@link MusicPlayer} to restart itself after an
     *  update. */
    public static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";

    /** Sent by {@link MusicPlayer} and {@link StorageObserver} after a
     *  folder-scan settles, to trigger a genre load. */
    public static final String ACTION_TRIGGER_GENRE_LOADING = "com.ark.llama.TRIGGER_GENRE_LOADING";

    // ============================================================================
    // Extra keys
    // ============================================================================

    /** Extra carrying the sort mode an {@link #ACTION_UPDATE_SORT_MODE}
     *  broadcast requests. */
    public static final String EXTRA_SORT_MODE = "sort_mode";

    /** Extra carrying the serialized {@link PlaybackScope} an
     *  {@link #ACTION_APPLY_PLAYBACK_SCOPE} broadcast requests. */
    public static final String EXTRA_SCOPE_JSON = "scope_json";

    /** Extra carrying the caller-supplied overlay message for
     *  {@link #ACTION_TRIGGER_GENRE_LOADING}. */
    public static final String EXTRA_TRIGGER_MESSAGE = "trigger_message";

    // ============================================================================
    // Singleton
    // ============================================================================

    private static volatile BroadcastTranslator sInstance;
    private final Context mApplicationContext;
    private final Object mRegistrationLock = new Object();
    private boolean mStarted = false;
    private final List<BroadcastReceiver> mRegisteredReceivers = new ArrayList<>();

    /**
     * Constructs the singleton. Private: use
     * {@link #getInstance(Context)}.
     *
     * @param context A context; the application context is retained
     */
    private BroadcastTranslator(Context context) {
        mApplicationContext = context.getApplicationContext();
    }

    /**
     * Returns the process-wide singleton, creating it on first call.
     *
     * @param context A context; the application context is retained
     * @return The singleton instance
     */
    public static BroadcastTranslator getInstance(Context context) {
        if (sInstance == null) {
            synchronized (BroadcastTranslator.class) {
                if (sInstance == null) sInstance = new BroadcastTranslator(context);
            }
        }
        return sInstance;
    }

    // ============================================================================
    // Lifecycle
    // ============================================================================

    /**
     * Registers one receiver per stem, in the order the stems appear
     * in the constant block. Idempotent: a second call while
     * {@code mStarted} is true returns without registering anything
     * twice.
     */
    public void start() {
        synchronized (mRegistrationLock) {
            if (mStarted) return;
            mStarted = true;
        }

        reg(ACTION_UPDATE_PLAYER, UpdatePlayerEvent::from);
        reg(ACTION_PLAY_SONG, PlaySongEvent::from);
        reg(ACTION_BLUETOOTH_PLAY, BluetoothPlayEvent::from);
        reg(ACTION_BLUETOOTH_PAUSE, BluetoothPauseEvent::from);
        reg(ACTION_BLUETOOTH_CONNECTED, BluetoothConnectedEvent::from);
        reg(ACTION_SAVE_PLAYER_STATE_NOW, SavePlayerStateNowEvent::from);
        reg(ACTION_SYNC_STARTED, SyncStartedEvent::from);
        reg(ACTION_SYNC_COMPLETE, SyncCompleteEvent::from);
        reg(ACTION_UPDATE_PLAYLIST, UpdatePlaylistEvent::from);
        reg(ACTION_UPDATE_PLAYLIST_FROM_FOLDERS, UpdatePlaylistFromFoldersEvent::from);
        reg(ACTION_DISPLAY_PLAYLIST, DisplayPlaylistEvent::from);
        reg(ACTION_METADATA_UPDATED, MetadataUpdatedEvent::from);
        reg(ACTION_PLAYBACK_RECOVERED, PlaybackRecoveredEvent::from);
        reg(ACTION_UPDATE_SORT_MODE, UpdateSortModeEvent::from);
        reg(ACTION_SET_PENDING_SONG, SetPendingSongEvent::from);
        reg(ACTION_LANGUAGE_CHANGED, LanguageChangedEvent::from);
        reg(ACTION_RESTART_APP, RestartAppEvent::from);
        reg(ACTION_UPDATE_PLAYBACK_PARAMS, UpdatePlaybackParamsEvent::from);
        reg(ACTION_CLEAR_PLAYLIST, ClearPlaylistEvent::from);
        reg(ACTION_GENRE_UPDATE, GenreUpdateEvent::from);
        reg(ACTION_GET_PLAYING_STATE, GetPlayingStateEvent::from);
        reg(ACTION_PLAYING_STATE_RESPONSE, PlayingStateResponseEvent::from);
        reg(ACTION_APPLY_PLAYBACK_SCOPE, ApplyPlaybackScopeEvent::from);
        reg(ACTION_TRIGGER_GENRE_LOADING, TriggerGenreLoadingEvent::from);
        reg(ACTION_REFRESH_PLAYLIST, RefreshPlaylistEvent::from);
        reg(ACTION_AUDIO_SESSION_CHANGED, AudioSessionChangedEvent::from);
        reg(ACTION_LOOSE_TRACKS_UPDATED, LooseTracksUpdatedEvent::from);
        reg(ACTION_THEME_COLOR_CHANGED, ThemeColorChangedEvent::from);

        reg(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS,
            PlaylistLoadProgressEvent::from);

        registerStemTranslator(
            new IntentFilter(PlaylistManager.ACTION_LIBRARY_RESET),
            LibraryResetEvent::from);
    }

    /**
     * Unregisters every receiver this translator registered.
     * Idempotent: a second call while {@code mStarted} is false
     * returns without doing anything.
     */
    public void stop() {
        final List<BroadcastReceiver> receiversToUnregister;
        synchronized (mRegistrationLock) {
            if (!mStarted) return;
            mStarted = false;
            receiversToUnregister = new ArrayList<>(mRegisteredReceivers);
            mRegisteredReceivers.clear();
        }
        for (BroadcastReceiver receiver : receiversToUnregister) {
            unregisterReceiver(receiver);
        }
    }

    // ============================================================================
    // EventBus delegation
    // ============================================================================

    /**
     * Registers the given subscriber with the default EventBus.
     * Idempotent: a subscriber that is already registered is not
     * registered a second time.
     *
     * @param subscriber Subscriber to register, or null
     */
    public void register(Object subscriber) {
        if (subscriber == null) return;
        try {
            if (!EventBus.getDefault().isRegistered(subscriber)) {
                EventBus.getDefault().register(subscriber);
            }
        } catch (EventBusException exception) {
            Log.e(TAG, "register failed", exception);
        }
    }

    /**
     * Unregisters the given subscriber from the default EventBus.
     * Idempotent: a subscriber that is not registered is a no-op.
     *
     * @param subscriber Subscriber to unregister, or null
     */
    public void unregister(Object subscriber) {
        if (subscriber == null) return;
        try {
            if (EventBus.getDefault().isRegistered(subscriber)) {
                EventBus.getDefault().unregister(subscriber);
            }
        } catch (EventBusException exception) {
            Log.e(TAG, "unregister failed", exception);
        }
    }

    /**
     * Returns whether the given subscriber is registered with the
     * default EventBus.
     *
     * @param subscriber Subscriber to query, or null
     * @return True when the subscriber is registered
     */
    public boolean isRegistered(Object subscriber) {
        return subscriber != null && EventBus.getDefault().isRegistered(subscriber);
    }

    /**
     * Posts an event to the default EventBus.
     *
     * @param event Event to post, or null
     */
    public void post(Object event) {
        if (event != null) EventBus.getDefault().post(event);
    }

    /**
     * Posts a sticky event to the default EventBus.
     *
     * @param event Event to post, or null
     */
    public void postSticky(Object event) {
        if (event != null) EventBus.getDefault().postSticky(event);
    }

    /**
     * Returns the most recent sticky event of the given type, or
     * null when none has been posted.
     *
     * @param eventType Event type to query, or null
     * @param <EventType> Event type
     * @return The sticky event, or null
     */
    public <EventType> EventType getSticky(Class<EventType> eventType) {
        return eventType == null
            ? null
            : EventBus.getDefault().getStickyEvent(eventType);
    }

    /**
     * Removes the sticky event of the given type.
     *
     * @param eventType Event type to remove, or null
     */
    public void removeSticky(Class<?> eventType) {
        if (eventType != null) EventBus.getDefault().removeStickyEvent(eventType);
    }

    // ============================================================================
    // Registration plumbing
    // ============================================================================

    /**
     * Translates one {@link Intent} into one typed event.
     *
     * @param <EventType> Event type
     */
    private interface Translator<EventType> {
        EventType translate(Intent intent);
    }

    /**
     * One receiver per stem. Translates on {@code onReceive} and
     * posts to the default EventBus. Failures in translation are
     * logged; null events are dropped.
     *
     * @param <EventType> Event type
     */
    private final class StemBroadcastReceiver<EventType> extends BroadcastReceiver {
        private final Translator<EventType> mTranslator;
        StemBroadcastReceiver(Translator<EventType> translator) {
            mTranslator = translator;
        }
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            final EventType event;
            try {
                event = mTranslator.translate(intent);
            } catch (RuntimeException exception) {
                Log.e(TAG, "translate failed for " + intent.getAction(), exception);
                return;
            }
            if (event != null) EventBus.getDefault().post(event);
        }
    }

    /**
     * Registers a receiver for the given action using the given
     * translator.
     *
     * @param action Action to listen for
     * @param translator Translator that converts the intent to an event
     * @param <EventType> Event type
     */
    private <EventType> void reg(String action, Translator<EventType> translator) {
        registerStemTranslator(new IntentFilter(action), translator);
    }

    /**
     * Registers a receiver for the given filter using the given
     * translator.
     *
     * @param intentFilter Filter to register with
     * @param translator Translator that converts the intent to an event
     * @param <EventType> Event type
     */
    private <EventType> void registerStemTranslator(
            IntentFilter intentFilter,
            Translator<EventType> translator) {
        if (intentFilter == null || translator == null) return;
        registerReceiver(new StemBroadcastReceiver<EventType>(translator),
            intentFilter);
    }

    /**
     * Registers the given receiver with the application context.
     * Uses {@code RECEIVER_NOT_EXPORTED} on API 33+ and the legacy
     * overload below. Adds the receiver to
     * {@link #mRegisteredReceivers} so {@link #stop()} can
     * unregister it.
     *
     * @param receiver Receiver to register
     * @param intentFilter Filter to register with
     */
    private void registerReceiver(BroadcastReceiver receiver,
                                  IntentFilter intentFilter) {
        if (receiver == null || intentFilter == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.registerReceiver(mApplicationContext, receiver,
                    intentFilter, ContextCompat.RECEIVER_NOT_EXPORTED);
            } else {
                mApplicationContext.registerReceiver(receiver, intentFilter);
            }
            synchronized (mRegistrationLock) { mRegisteredReceivers.add(receiver); }
        } catch (Exception exception) {
            Log.e(TAG, "registerReceiver failed for " + intentFilter, exception);
        }
    }

    /**
     * Unregisters the given receiver from the application context.
     *
     * @param receiver Receiver to unregister
     */
    private void unregisterReceiver(BroadcastReceiver receiver) {
        if (receiver == null) return;
        try {
            mApplicationContext.unregisterReceiver(receiver);
        } catch (IllegalArgumentException ignored) {
            // The receiver was already unregistered.
        } catch (Exception exception) {
            Log.e(TAG, "unregisterReceiver failed", exception);
        }
    }

    // ==================================================================
    // EVENT CLASSES
    // ==================================================================

    /**
     * Payload of the {@code UPDATE_PLAYER} stem.
     */
    public static final class UpdatePlayerEvent {
        public final long generation;
        public final String state;
        public final int currentIndex;
        public final int targetIndex;
        public final String songPath;
        public final String targetSongPath;
        public final boolean isPlaying;
        public final int positionMs;
        public final int durationMs;
        public final String windowPreviousPath;
        public final String windowCurrentPath;
        public final String windowNextPath;
        public final int transitionDirection;
        public final boolean transitionRestart;
        public final String displayTitle;
        public final String displayArtist;
        public final boolean isFavorite;
        public final String scopeKind;
        public final int scopeCount;

        private UpdatePlayerEvent(long generationValue, String stateValue,
                int currentIndexValue, int targetIndexValue,
                String songPathValue, String targetSongPathValue,
                boolean isPlayingValue, int positionMsValue, int durationMsValue,
                String windowPreviousPathValue, String windowCurrentPathValue,
                String windowNextPathValue, int transitionDirectionValue,
                boolean transitionRestartValue, String displayTitleValue,
                String displayArtistValue, boolean isFavoriteValue,
                String scopeKindValue, int scopeCountValue) {
            this.generation = generationValue;
            this.state = stateValue;
            this.currentIndex = currentIndexValue;
            this.targetIndex = targetIndexValue;
            this.songPath = songPathValue;
            this.targetSongPath = targetSongPathValue;
            this.isPlaying = isPlayingValue;
            this.positionMs = positionMsValue;
            this.durationMs = durationMsValue;
            this.windowPreviousPath = windowPreviousPathValue;
            this.windowCurrentPath = windowCurrentPathValue;
            this.windowNextPath = windowNextPathValue;
            this.transitionDirection = transitionDirectionValue;
            this.transitionRestart = transitionRestartValue;
            this.displayTitle = displayTitleValue;
            this.displayArtist = displayArtistValue;
            this.isFavorite = isFavoriteValue;
            this.scopeKind = scopeKindValue;
            this.scopeCount = scopeCountValue;
        }

        static UpdatePlayerEvent from(Intent intent) {
            if (intent == null) return null;
            return new UpdatePlayerEvent(
                intent.getLongExtra("generation", 0L),
                intent.getStringExtra("state"),
                intent.getIntExtra("current_index", -1),
                intent.getIntExtra("target_index", -1),
                intent.getStringExtra("song_path"),
                intent.getStringExtra("target_song_path"),
                intent.getBooleanExtra("is_playing", false),
                intent.getIntExtra("position_ms", 0),
                intent.getIntExtra("duration_ms", 0),
                intent.getStringExtra("window_previous_path"),
                intent.getStringExtra("window_current_path"),
                intent.getStringExtra("window_next_path"),
                intent.getIntExtra("transition_direction", 0),
                intent.getBooleanExtra("transition_restart", false),
                intent.getStringExtra("display_title"),
                intent.getStringExtra("display_artist"),
                intent.getBooleanExtra("is_favorite", false),
                intent.getStringExtra("scope_kind"),
                intent.getIntExtra("scope_count", 0));
        }
    }

    /**
     * Payload of the {@code PLAY_SONG} stem.
     */
    public static final class PlaySongEvent {
        public final String songPath;
        private PlaySongEvent(String songPathValue) { this.songPath = songPathValue; }
        static PlaySongEvent from(Intent intent) {
            if (intent == null) return null;
            final String path = intent.getStringExtra("song_path");
            return path == null ? null : new PlaySongEvent(path);
        }
    }

    /**
     * Payload of the {@code BLUETOOTH_PLAY} stem.
     */
    public static final class BluetoothPlayEvent {
        private BluetoothPlayEvent() {}
        static BluetoothPlayEvent from(Intent intent) {
            return intent == null ? null : new BluetoothPlayEvent();
        }
    }

    /**
     * Payload of the {@code BLUETOOTH_PAUSE} stem.
     */
    public static final class BluetoothPauseEvent {
        public final String profileAction;
        public final int profileState;
        private BluetoothPauseEvent(String profileActionValue,
                                    int profileStateValue) {
            this.profileAction = profileActionValue;
            this.profileState = profileStateValue;
        }
        static BluetoothPauseEvent from(Intent intent) {
            if (intent == null) return null;
            return new BluetoothPauseEvent(
                intent.getStringExtra("profile_action"),
                intent.getIntExtra("profile_state", -1));
        }
    }

    /**
     * Payload of the {@code BLUETOOTH_CONNECTED} stem.
     */
    public static final class BluetoothConnectedEvent {
        public final boolean connected;
        private BluetoothConnectedEvent(boolean connectedValue) {
            this.connected = connectedValue;
        }
        static BluetoothConnectedEvent from(Intent intent) {
            if (intent == null) return null;
            return new BluetoothConnectedEvent(
                intent.getBooleanExtra("connected", false));
        }
    }

    /**
     * Payload of the {@code SAVE_PLAYER_STATE_NOW} stem.
     */
    public static final class SavePlayerStateNowEvent {
        private SavePlayerStateNowEvent() {}
        static SavePlayerStateNowEvent from(Intent intent) {
            return intent == null ? null : new SavePlayerStateNowEvent();
        }
    }

    /**
     * Payload of the {@code SYNC_STARTED} stem.
     */
    public static final class SyncStartedEvent {
        public final String customText;
        public final String customDetail;
        public final String operationId;
        private SyncStartedEvent(String customTextValue,
                                 String customDetailValue,
                                 String operationIdValue) {
            this.customText = customTextValue;
            this.customDetail = customDetailValue;
            this.operationId = operationIdValue;
        }
        static SyncStartedEvent from(Intent intent) {
            if (intent == null) return null;
            return new SyncStartedEvent(
                intent.getStringExtra("custom_text"),
                intent.getStringExtra("custom_detail"),
                intent.getStringExtra("operation_id"));
        }
    }

    /**
     * Payload of the {@code SYNC_COMPLETE} stem.
     */
    public static final class SyncCompleteEvent {
        private SyncCompleteEvent() {}
        static SyncCompleteEvent from(Intent intent) {
            return intent == null ? null : new SyncCompleteEvent();
        }
    }

    /**
     * Payload of the {@code UPDATE_PLAYLIST} stem.
     */
    public static final class UpdatePlaylistEvent {
        public final boolean preserveCurrentSong;
        private UpdatePlaylistEvent(boolean preserveCurrentSongValue) {
            this.preserveCurrentSong = preserveCurrentSongValue;
        }
        static UpdatePlaylistEvent from(Intent intent) {
            if (intent == null) return null;
            return new UpdatePlaylistEvent(
                intent.getBooleanExtra("preserve_current_song", true));
        }
    }

    /**
     * Payload of the {@code UPDATE_PLAYLIST_FROM_FOLDERS} stem.
     */
    public static final class UpdatePlaylistFromFoldersEvent {
        private UpdatePlaylistFromFoldersEvent() {}
        static UpdatePlaylistFromFoldersEvent from(Intent intent) {
            return intent == null ? null : new UpdatePlaylistFromFoldersEvent();
        }
    }

    /**
     * Payload of the {@code DISPLAY_PLAYLIST} stem.
     */
    public static final class DisplayPlaylistEvent {
        private DisplayPlaylistEvent() {}
        static DisplayPlaylistEvent from(Intent intent) {
            return intent == null ? null : new DisplayPlaylistEvent();
        }
    }

    /**
     * Payload of the {@code METADATA_UPDATED} stem.
     */
    public static final class MetadataUpdatedEvent {
        public final String songPath;
        public final String songUri;
        public final String title;
        public final String artist;
        public final String album;
        public final String genre;
        public final boolean hasAlbumArt;
        public final boolean albumArtRemoved;
        public final byte[] albumArtBytes;

        private MetadataUpdatedEvent(String songPathValue, String songUriValue,
                String titleValue, String artistValue, String albumValue,
                String genreValue, boolean hasAlbumArtValue,
                boolean albumArtRemovedValue, byte[] albumArtBytesValue) {
            this.songPath = songPathValue;
            this.songUri = songUriValue;
            this.title = titleValue;
            this.artist = artistValue;
            this.album = albumValue;
            this.genre = genreValue;
            this.hasAlbumArt = hasAlbumArtValue;
            this.albumArtRemoved = albumArtRemovedValue;
            this.albumArtBytes = albumArtBytesValue;
        }

        static MetadataUpdatedEvent from(Intent intent) {
            if (intent == null) return null;
            final String path = intent.getStringExtra("song_path");
            final String uri = intent.getStringExtra("song_uri");
            if ((path == null || path.isEmpty())
                    && (uri == null || uri.isEmpty())) return null;
            return new MetadataUpdatedEvent(path, uri,
                intent.getStringExtra("title"),
                intent.getStringExtra("artist"),
                intent.getStringExtra("album"),
                intent.getStringExtra("genre"),
                intent.getBooleanExtra("has_album_art", false),
                intent.getBooleanExtra("album_art_removed", false),
                intent.getByteArrayExtra("album_art_bytes"));
        }
    }

    /**
     * Payload of the {@code PLAYBACK_RECOVERED} stem.
     */
    public static final class PlaybackRecoveredEvent {
        private PlaybackRecoveredEvent() {}
        static PlaybackRecoveredEvent from(Intent intent) {
            return intent == null ? null : new PlaybackRecoveredEvent();
        }
    }

    /**
     * Payload of the {@code UPDATE_SORT_MODE} stem.
     */
    public static final class UpdateSortModeEvent {
        public final int sortMode;
        private UpdateSortModeEvent(int sortModeValue) { this.sortMode = sortModeValue; }
        static UpdateSortModeEvent from(Intent intent) {
            if (intent == null) return null;
            return new UpdateSortModeEvent(intent.getIntExtra(EXTRA_SORT_MODE, 0));
        }
    }

    /**
     * Payload of the {@code SET_PENDING_SONG} stem.
     */
    public static final class SetPendingSongEvent {
        public final String songPath;
        private SetPendingSongEvent(String songPathValue) { this.songPath = songPathValue; }
        static SetPendingSongEvent from(Intent intent) {
            if (intent == null) return null;
            final String path = intent.getStringExtra("song_path");
            return path == null ? null : new SetPendingSongEvent(path);
        }
    }

    /**
     * Payload of the {@code LANGUAGE_CHANGED} stem.
     */
    public static final class LanguageChangedEvent {
        private LanguageChangedEvent() {}
        public static LanguageChangedEvent create() {
            return new LanguageChangedEvent();
        }
        static LanguageChangedEvent from(Intent intent) {
            return intent == null ? null : new LanguageChangedEvent();
        }
    }

    /**
     * Payload of the {@code com.ark.llama.RESTART_APP} stem.
     */
    public static final class RestartAppEvent {
        private RestartAppEvent() {}
        static RestartAppEvent from(Intent intent) {
            return intent == null ? null : new RestartAppEvent();
        }
    }

    /**
     * Payload of the {@code UPDATE_PLAYBACK_PARAMS} stem.
     */
    public static final class UpdatePlaybackParamsEvent {
        private UpdatePlaybackParamsEvent() {}
        static UpdatePlaybackParamsEvent from(Intent intent) {
            return intent == null ? null : new UpdatePlaybackParamsEvent();
        }
    }

    /**
     * Payload of the {@code CLEAR_PLAYLIST} stem.
     */
    public static final class ClearPlaylistEvent {
        private ClearPlaylistEvent() {}
        static ClearPlaylistEvent from(Intent intent) {
            return intent == null ? null : new ClearPlaylistEvent();
        }
    }

    /**
     * Payload of the {@code GENRE_UPDATE} stem.
     */
    public static final class GenreUpdateEvent {
        public final String status;
        public final String songPath;
        public final String genre;
        public final int current;
        public final int total;
        private GenreUpdateEvent(String statusValue, String songPathValue,
                String genreValue, int currentValue, int totalValue) {
            this.status = statusValue;
            this.songPath = songPathValue;
            this.genre = genreValue;
            this.current = currentValue;
            this.total = totalValue;
        }
        static GenreUpdateEvent from(Intent intent) {
            if (intent == null) return null;
            return new GenreUpdateEvent(
                intent.getStringExtra("status"),
                intent.getStringExtra("song_path"),
                intent.getStringExtra("genre"),
                intent.getIntExtra("current", 0),
                intent.getIntExtra("total", 0));
        }
    }

    /**
     * Payload of the {@code GET_PLAYING_STATE} stem.
     */
    public static final class GetPlayingStateEvent {
        private GetPlayingStateEvent() {}
        static GetPlayingStateEvent from(Intent intent) {
            return intent == null ? null : new GetPlayingStateEvent();
        }
    }

    /**
     * Payload of the {@code PLAYING_STATE_RESPONSE} stem.
     */
    public static final class PlayingStateResponseEvent {
        public final boolean isPlaying;
        private PlayingStateResponseEvent(boolean isPlayingValue) {
            this.isPlaying = isPlayingValue;
        }
        static PlayingStateResponseEvent from(Intent intent) {
            if (intent == null) return null;
            return new PlayingStateResponseEvent(
                intent.getBooleanExtra("is_playing", false));
        }
    }

    /**
     * Payload of the {@code APPLY_PLAYBACK_SCOPE} stem.
     */
    public static final class ApplyPlaybackScopeEvent {
        public final String scopeJson;
        private ApplyPlaybackScopeEvent(String scopeJsonValue) {
            this.scopeJson = scopeJsonValue;
        }
        static ApplyPlaybackScopeEvent from(Intent intent) {
            if (intent == null) return null;
            final String serializedScope = intent.getStringExtra(EXTRA_SCOPE_JSON);
            return serializedScope == null
                ? null
                : new ApplyPlaybackScopeEvent(serializedScope);
        }
    }

    /**
     * Payload of the {@code com.ark.llama.TRIGGER_GENRE_LOADING} stem.
     */
    public static final class TriggerGenreLoadingEvent {
        public final String message;
        private TriggerGenreLoadingEvent(String messageValue) {
            this.message = messageValue;
        }
        static TriggerGenreLoadingEvent from(Intent intent) {
            return intent == null
                ? null
                : new TriggerGenreLoadingEvent(
                    intent.getStringExtra(EXTRA_TRIGGER_MESSAGE));
        }
    }

    /**
     * Payload of the {@code REFRESH_PLAYLIST} stem.
     */
    public static final class RefreshPlaylistEvent {
        private RefreshPlaylistEvent() {}
        static RefreshPlaylistEvent from(Intent intent) {
            return intent == null ? null : new RefreshPlaylistEvent();
        }
    }

    /**
     * Payload of the {@code com.ark.llama.AUDIO_SESSION_CHANGED} stem.
     */
    public static final class AudioSessionChangedEvent {
        public final int audioSessionId;
        private AudioSessionChangedEvent(int audioSessionIdValue) {
            this.audioSessionId = audioSessionIdValue;
        }
        static AudioSessionChangedEvent from(Intent intent) {
            return intent == null
                ? null
                : new AudioSessionChangedEvent(
                    intent.getIntExtra("audio_session_id", -1));
        }
    }

    /**
     * Payload of the {@code LOOSE_TRACKS_UPDATED} stem.
     */
    public static final class LooseTracksUpdatedEvent {
        private LooseTracksUpdatedEvent() {}
        static LooseTracksUpdatedEvent from(Intent intent) {
            return intent == null ? null : new LooseTracksUpdatedEvent();
        }
    }

    /**
     * Payload of the {@code THEME_COLOR_CHANGED} stem.
     */
    public static final class ThemeColorChangedEvent {
        private ThemeColorChangedEvent() {}
        static ThemeColorChangedEvent from(Intent intent) {
            return intent == null ? null : new ThemeColorChangedEvent();
        }
    }

    /**
     * Payload of the
     * {@code com.ark.llama.PLAYLIST_LOAD_PROGRESS} stem.
     */
    public static final class PlaylistLoadProgressEvent {
        public final String songPath;
        public final String title;
        public final String artist;
        public final String album;
        public final String genre;
        public final long duration;
        public final int currentCount;
        private PlaylistLoadProgressEvent(String songPathValue,
                String titleValue, String artistValue, String albumValue,
                String genreValue, long durationValue, int currentCountValue) {
            this.songPath = songPathValue;
            this.title = titleValue;
            this.artist = artistValue;
            this.album = albumValue;
            this.genre = genreValue;
            this.duration = durationValue;
            this.currentCount = currentCountValue;
        }
        static PlaylistLoadProgressEvent from(Intent intent) {
            if (intent == null) return null;
            return new PlaylistLoadProgressEvent(
                intent.getStringExtra("song_path"),
                intent.getStringExtra("song_title"),
                intent.getStringExtra("song_artist"),
                intent.getStringExtra("song_album"),
                intent.getStringExtra("song_genre"),
                intent.getLongExtra("song_duration", 0L),
                intent.getIntExtra("current_count", 0));
        }
    }

    /**
     * Payload of the {@code LIBRARY_RESET} stem.
     */
    public static final class LibraryResetEvent {
        public final boolean preserveSettings;
        private LibraryResetEvent(boolean preserveSettingsValue) {
            this.preserveSettings = preserveSettingsValue;
        }
        static LibraryResetEvent from(Intent intent) {
            return intent == null
                ? null
                : new LibraryResetEvent(
                    intent.getBooleanExtra(
                        PlaylistManager.EXTRA_PRESERVE_SETTINGS, true));
        }
    }
}