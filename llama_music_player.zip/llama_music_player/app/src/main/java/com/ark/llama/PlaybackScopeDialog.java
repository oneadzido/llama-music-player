// PlaybackScopeDialog.java
package com.ark.llama;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Presents the seven scope modes as a single flat list and reports
 * the user's selection through {@link OnScopeAppliedListener}.
 *
 * <p>One {@link RecyclerView} carries both the seven mode rows and
 * the filter rows that belong to the currently expanded mode. A
 * single scroll means a single edge fast-scroll
 * ({@link EdgeScrollHelper}) and a single divider chain, matching
 * the playlist's list feel.</p>
 *
 * <p>Mode rows use a custom-drawn radio indicator; filter rows use
 * a custom-drawn checkbox indicator. Both are {@link TextView}
 * instances themed by {@link ThemeHelper#updateRadio} and
 * {@link ThemeHelper#updateCheckbox}. Tapping anywhere on a row
 * triggers the action; the framework's default widgets are never
 * shown.</p>
 *
 * <h3>Expand / Collapse</h3>
 * <p>All seven radios are always visible and mutually exclusive.
 * Selecting a mode with children — Folders, Genres, Artists,
 * Albums — expands its filter list below the mode row. Selecting a
 * mode without children — All, Favorites, Loose Tracks — collapses
 * any expanded list. Re-tapping an already-selected mode with
 * children collapses its list without changing the selection.
 * Unticking the last filter value in the active category leaves the
 * mode selected and its list expanded: an empty set is a scope that
 * matches nothing, shown as a count of zero. Only a mode tap
 * changes the mode.</p>
 *
 * <h3>Header</h3>
 * <p>The header line reads {@code SCOPE MODE: <label>} on the left
 * and updates live as the radio selection changes. Once the filter
 * lists have loaded, the header also carries the count of songs the
 * current selection would yield, right-aligned — {@code 12 songs}
 * — computed through {@link PlaybackScope#matches(Song, Set)} so
 * the number is exactly what APPLY would hand to the listener. The
 * count follows every radio tap and every checkbox toggle. A filter
 * mode with no values checked is a scope that matches nothing, so
 * the count reads zero; it is not rewritten into All Songs. Before
 * the filter lists finish loading, the count is omitted.</p>
 *
 * <h3>Apply Enablement</h3>
 * <p>APPLY is enabled exactly when the draft scope differs from the
 * scope the dialog opened with, compared over the kind and all four
 * filter sets. An empty filter selection from a different starting
 * scope is therefore a change the user can commit; a selection
 * identical to the one already applied is not. The button starts in
 * the state the given scope warrants and follows every mode tap and
 * checkbox toggle. A preference change made during the commit window
 * cancels the queued commit and restores the button through the same
 * comparison.</p>
 *
 * <h3>Dynamic Lists</h3>
 * <p>The folder list is supplied by the caller as
 * {@link FolderAdapter.FolderItem} rows; each row's path resolves
 * through {@link StorageAccessHelper#getFolderPathFromUri(Uri)},
 * which handles both primary and removable storage. The genre,
 * artist, and album lists are enumerated from the songs table on
 * {@link #mLoader} and posted back to the main thread; the
 * placeholder values are filtered out using
 * {@link CharacterMapper#isUnknownGenre(String)} and its siblings,
 * so a user is never offered "Unknown Artist" as a scope. The
 * loader also caches the full song list and the loose-track path
 * set for the header's count; those caches are the only additional
 * state it carries.</p>
 *
 * <h3>Dismissal</h3>
 * <p>Apply waits {@link #DISMISS_DELAY_MS} before dismissing, so
 * the button's press animation completes and the disabled state
 * is visible before the dialog leaves the screen. Cancel dismisses
 * immediately. Both buttons are terminal: the dialog has exactly
 * two exits, and neither of them leaves it on screen.</p>
 *
 * <p>APPLY is disabled for the whole window between the tap and
 * the dismissal, so a second tap cannot queue a second commit. If
 * the user changes a preference during that window — a mode tap or
 * a filter toggle — the queued commit is cancelled and the button
 * is restored through the same comparison that governs its resting
 * state, because the queued commit captured a scope the user has
 * already moved past. The commit is also removed from the handler
 * in {@link #dismiss()}, so a listener that throws cannot leave the
 * dialog on screen with the button disabled.</p>
 *
 * <p>A successful apply fires a scope toast just before dismissal,
 * reading {@code Scope: <label>}. The toast is the persistent
 * confirmation that the change happened; the dialog closes, the
 * playlist refreshes, and the toast names the scope the playlist
 * is now in. The toast uses the same label resource as the header,
 * so the two cannot drift apart.</p>
 *
 * <h3>Resilience</h3>
 * <p>If the dynamic enumerations fail, the dialog stays usable —
 * the folder list still renders — and a toast names the failure.
 * A filter kind with an empty set is returned as that scope, not
 * rewritten into {@link PlaybackScope#ALL_SONGS}. APPLY is enabled
 * only when the returned scope differs from the one the dialog
 * opened with, so an empty selection is committable only when it is
 * a change.</p>
 *
 * <h3>Theme Application</h3>
 * <p>This dialog does not react to {@code THEME_COLOR_CHANGED}. It is
 * hosted by {@link FolderManager}, whose recreation dismisses the
 * dialog; the next open constructs a new {@code PlaybackScopeDialog}
 * against the new theme.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.4.6
 * @since 1.4.0
 */
public class PlaybackScopeDialog extends Dialog {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaybackScopeDialog";

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Header background color, slightly lighter than the main
     *  background. */
    private static final String HEADER_BACKGROUND_COLOR = "#1A1A1A";

    /** Background color of the currently selected mode row. */
    private static final String SELECTED_BACKGROUND_COLOR = "#1E1E1E";

    /** Touch highlight color applied to a pressed row. */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";

    /** Light gray text color for headers and row labels. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Debounce delay for the apply and cancel buttons, in
     *  milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    /** Delay before dismissing the dialog after a selection, in
     *  milliseconds. */
    private static final long DISMISS_DELAY_MS = 500L;

    /** Height of the top action bar, in density-independent
     *  pixels. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of the header bar, in density-independent pixels. */
    private static final int HEADER_BAR_HEIGHT_DP = 40;

    /** Height of action buttons, in density-independent pixels. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Standard padding for the top bar, in density-independent
     *  pixels. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Horizontal padding of the header, in density-independent
     *  pixels. */
    private static final int HEADER_PADDING_HORIZONTAL_DP = 16;

    /** Vertical padding of the header, in density-independent
     *  pixels. */
    private static final int HEADER_PADDING_VERTICAL_DP = 4;

    /** Start margin applied to the song count, in dp. */
    private static final int HEADER_COUNT_MARGIN_START_DP = 8;

    /** Duration of button press animations, in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;

    /** Scale factor for button press animations. */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;

    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;

    // ============================================================================
    // Row Model
    // ============================================================================

    /**
     * One row in the dialog's RecyclerView.
     *
     * <p>Two sub-types share this class. A {@link #TYPE_MODE} row
     * carries one of the seven {@link PlaybackScope.Kind} values
     * and no filter value; it renders a radio indicator. A
     * {@link #TYPE_FILTER} row carries one of the four filter
     * kinds and the specific string value it represents — a
     * folder path, a genre name, an artist name, or an album name
     * — and renders a checkbox indicator.</p>
     */
    private static final class Row {

        /** Row type: a mode radio row. */
        static final int TYPE_MODE = 0;

        /** Row type: a filter checkbox row. */
        static final int TYPE_FILTER = 1;

        /** Row type of this row. */
        final int type;

        /** Scope kind this row belongs to. */
        final PlaybackScope.Kind kind;

        /** Filter value this row represents, or null for a mode
         *  row. */
        @Nullable final String value;

        /** Text displayed in the row's label. */
        @NonNull final String label;

        /**
         * Constructs a row.
         *
         * @param type Row type
         * @param kind Scope kind this row belongs to
         * @param value Filter value, or null for a mode row
         * @param label Display label
         */
        Row(int type, PlaybackScope.Kind kind,
            @Nullable String value, @NonNull String label) {
            this.type = type;
            this.kind = kind;
            this.value = value;
            this.label = label;
        }

        /**
         * Constructs a mode row.
         *
         * @param kind Scope kind
         * @param label Display label
         * @return A new mode row
         */
        static Row mode(PlaybackScope.Kind kind, @NonNull String label) {
            return new Row(TYPE_MODE, kind, null, label);
        }

        /**
         * Constructs a filter row.
         *
         * @param kind Scope kind
         * @param value Filter value
         * @param label Display label
         * @return A new filter row
         */
        static Row filter(PlaybackScope.Kind kind,
                          @NonNull String value,
                          @NonNull String label) {
            return new Row(TYPE_FILTER, kind, value, label);
        }
    }

    /**
     * A resolved folder entry ready to be displayed as a filter
     * checkbox.
     */
    private static final class FolderEntry {

        /** Filesystem path of the folder. */
        final String path;

        /** Display name of the folder. */
        final String displayName;

        /**
         * Constructs a folder entry.
         *
         * @param path Filesystem path of the folder
         * @param displayName Display name of the folder
         */
        FolderEntry(String path, String displayName) {
            this.path = path;
            this.displayName = displayName;
        }
    }

    // ============================================================================
    // Listener Interface
    // ============================================================================

    /**
     * Receives the scope the user selected.
     */
    public interface OnScopeAppliedListener {

        /**
         * Called when the user taps APPLY.
         *
         * @param scope The selected scope; never null
         */
        void onScopeApplied(@NonNull PlaybackScope scope);
    }

    // ============================================================================
    // Fields
    // ============================================================================

    /** Context used to resolve resources and construct views. */
    @NonNull private final Context mContext;

    /** Scope currently applied when the dialog opened. */
    @NonNull private final PlaybackScope mInitialScope;

    /** Folder rows supplied by the caller. */
    @NonNull private final List<FolderAdapter.FolderItem> mFolderItems;

    /** Listener notified on apply, or null. */
    @Nullable private final OnScopeAppliedListener mListener;

    /** Executor for enumerating the genre, artist, and album
     *  lists. */
    @NonNull private final ExecutorService mLoader =
        Executors.newSingleThreadExecutor();

    /** Handler for delayed work on the main thread. */
    @NonNull private final Handler mMain =
        new Handler(Looper.getMainLooper());

    /** Manager that supplies the current theme color. */
    @NonNull private final ThemeManager mThemeManager;

    /** Helper that applies theme colors to UI components. */
    @NonNull private final ThemeHelper mThemeHelper;

    /** RecyclerView that renders both mode rows and filter
     *  rows. */
    @Nullable private RecyclerView mRecyclerView;

    /** Header text showing {@code SCOPE MODE: <label>}. */
    @Nullable private TextView mHeaderText;

    /** Header text showing the song count, right-aligned. */
    @Nullable private TextView mCountText;

    /** Adapter that renders the dialog's row model. */
    @Nullable private ScopeAdapter mAdapter;

    /** Current row model. */
    @NonNull private final List<Row> mRows = new ArrayList<>();

    /** Resolved folder entries. */
    @NonNull private final List<FolderEntry> mFolderEntries =
        new ArrayList<>();

    /** Enumerated genre values. */
    @NonNull private final List<String> mGenreValues =
        new ArrayList<>();

    /** Enumerated artist values. */
    @NonNull private final List<String> mArtistValues =
        new ArrayList<>();

    /** Enumerated album values. */
    @NonNull private final List<String> mAlbumValues =
        new ArrayList<>();

    /** Selected folder paths. */
    @NonNull private final Set<String> mSelectedPaths =
        new HashSet<>();

    /** Selected genre names. */
    @NonNull private final Set<String> mSelectedGenres =
        new HashSet<>();

    /** Selected artist names. */
    @NonNull private final Set<String> mSelectedArtists =
        new HashSet<>();

    /** Selected album names. */
    @NonNull private final Set<String> mSelectedAlbums =
        new HashSet<>();

    /**
     * Full song list, cached for computing the current scope's
     * song count. Null until {@link #loadDynamicFilterLists()}
     * completes.
     *
     * <p>The list is the same one the loader already walks to
     * enumerate genres, artists, and albums; caching it costs
     * the reference, not a second read. The UI thread reads it
     * under {@link #computeScopeCount()}, which runs on every
     * header refresh — a radio tap, a checkbox toggle, or the
     * loader's completion.</p>
     */
    @Nullable private volatile ArrayList<Song> mAllSongs = null;

    /**
     * Paths of the loose tracks, cached for computing the
     * current scope's song count. Null until
     * {@link #loadDynamicFilterLists()} completes.
     */
    @Nullable private volatile Set<String> mLooseTrackPaths = null;

    /** Currently selected scope kind. */
    @NonNull private PlaybackScope.Kind mSelectedKind;

    /** True when the currently selected mode's filter list is
     *  expanded. */
    private boolean mFilterExpanded;

    /** Timestamp of the last apply click, for debouncing. */
    private long mLastApplyTime = 0L;

    /** Timestamp of the last cancel click, for debouncing. */
    private long mLastCancelTime = 0L;

    /** The APPLY button, held so it can be disabled during a
     *  pending commit and restored to its resting state if that
     *  commit is cancelled. */
    @Nullable private Button mApplyButton;

    /** True while a commit is queued but has not yet run. */
    private boolean mApplyInProgress = false;

    /**
     * The commit runnable queued by {@link #commitAndDismiss()},
     * held so it can be removed when the user changes a
     * preference before the commit fires.
     */
    @Nullable private Runnable mPendingCommit = null;

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the dialog.
     *
     * @param context Context used to resolve resources and
     *        construct views
     * @param initialScope Scope currently applied
     * @param folderItems Folder rows to present in the Folders
     *        section; the Loose Tracks pseudo-item is ignored
     * @param listener Listener notified on apply, or null
     */
    public PlaybackScopeDialog(@NonNull Context context,
                               @NonNull PlaybackScope initialScope,
                               @NonNull List<FolderAdapter.FolderItem> folderItems,
                               @Nullable OnScopeAppliedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mInitialScope = initialScope;
        mFolderItems = folderItems;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
        mSelectedKind = initialScope.kind;
        mFilterExpanded = supportsFilters(mSelectedKind);
        mSelectedPaths.addAll(initialScope.paths);
        mSelectedGenres.addAll(initialScope.genres);
        mSelectedArtists.addAll(initialScope.artists);
        mSelectedAlbums.addAll(initialScope.albums);
    }

    // ============================================================================
    // Dialog Lifecycle
    // ============================================================================

    /**
     * Initializes the dialog's window, content view, and dynamic
     * lists.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(buildContentView());

        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        populateFolderEntries();
        rebuildRows();
        loadDynamicFilterLists();
        updateApplyEnabled();
        forceRedraw();
    }

    /**
     * Dismisses the dialog and releases every resource it holds.
     *
     * <p>Any queued commit is removed from the handler before the
     * dialog goes away, so a commit that would have fired after
     * the user dismissed the dialog by other means cannot run
     * against a dismissed dialog. The apply-in-progress flag is
     * cleared so a dialog instance reused after a cancel does not
     * carry a stale disabled state.</p>
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMain.removeCallbacksAndMessages(null);
        mPendingCommit = null;
        mApplyInProgress = false;
        if (!mLoader.isShutdown()) {
            mLoader.shutdownNow();
        }
    }

    // ============================================================================
    // Localization Helper
    // ============================================================================

    /**
     * Returns a context that resolves resources against the app's
     * selected language.
     *
     * @return The locale-wrapped context, or the activity context
     *         on failure
     */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context",
                exception);
            return mContext;
        }
    }

    // ============================================================================
    // Window Configuration
    // ============================================================================

    /**
     * Configures the dialog window for a full-screen, bottom-
     * anchored presentation with the slide-up animation.
     *
     * @param window Window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(
                WindowManager.LayoutParams
                    .FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(
                WindowManager.LayoutParams
                    .FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(
                Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(
                Color.parseColor(BACKGROUND_COLOR));
        }
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(
            android.R.color.transparent);
        window.setWindowAnimations(
            R.style.PlaybackScopeDialogAnimation);
    }

    // ============================================================================
    // Content Construction
    // ============================================================================

    /**
     * Builds the dialog's content view.
     *
     * @return The root view
     */
    @NonNull
    private View buildContentView() {
        LinearLayout root = new LinearLayout(mContext);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(
            new float[] {20, 20, 20, 20, 0, 0, 0, 0});
        root.setBackground(background);

        root.addView(buildTopBar());
        root.addView(buildHeader());

        mRecyclerView = new RecyclerView(mContext);
        mRecyclerView.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams recyclerParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        mRecyclerView.setLayoutParams(recyclerParams);
        mRecyclerView.setLayoutManager(
            new LinearLayoutManager(mContext));
        DividerItemDecoration divider = new DividerItemDecoration(
            mContext, DividerItemDecoration.VERTICAL);
        divider.setDrawable(ContextCompat.getDrawable(
            mContext, R.drawable.divider_custom));
        mRecyclerView.addItemDecoration(divider);
        mAdapter = new ScopeAdapter();
        mRecyclerView.setAdapter(mAdapter);
        EdgeScrollHelper.attach(mRecyclerView);

        root.addView(mRecyclerView);
        return root;
    }

    /**
     * Builds the top action bar: cancel, title, apply.
     *
     * @return The top bar layout
     */
    @NonNull
    private LinearLayout buildTopBar() {
        LinearLayout bar = new LinearLayout(mContext);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(TOP_BAR_HEIGHT_DP)));
        bar.setPadding(dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP),
            dpToPx(PADDING_STANDARD_DP));
        bar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        Button cancel = new Button(mContext);
        cancel.setText(getLocaleContext().getString(
            R.string.action_cancel));
        cancel.setTextSize(14);
        cancel.setLetterSpacing(0.1f);
        cancel.setBackgroundResource(
            R.drawable.button_border_selector);
        cancel.setMinHeight(0);
        cancel.setMinWidth(0);
        cancel.setIncludeFontPadding(false);
        cancel.setSingleLine(true);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));
        cancel.setOnClickListener(view -> {
            long now = SystemClock.elapsedRealtime();
            if (now - mLastCancelTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelTime = now;
                dismiss();
            }
        });
        mThemeHelper.updateButton(cancel, true);
        animateButton(cancel);

        TextView title = new TextView(mContext);
        title.setText(getLocaleContext().getString(
            R.string.scope_dialog_title));
        title.setTextSize(14);
        title.setLetterSpacing(0.1f);
        title.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        title.setGravity(Gravity.CENTER);
        title.setIncludeFontPadding(false);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(0, 0, 0, 0);
        final LinearLayout.LayoutParams titleParams =
            new LinearLayout.LayoutParams(
                0, dpToPx(BUTTON_HEIGHT_DP), 1f);
        titleParams.setMarginStart(dpToPx(8));
        titleParams.setMarginEnd(dpToPx(8));
        title.setLayoutParams(titleParams);

        Button apply = new Button(mContext);
        apply.setText(getLocaleContext().getString(
            R.string.action_apply));
        apply.setTextSize(14);
        apply.setLetterSpacing(0.1f);
        apply.setBackgroundResource(
            R.drawable.button_border_selector);
        apply.setMinHeight(0);
        apply.setMinWidth(0);
        apply.setIncludeFontPadding(false);
        apply.setSingleLine(true);
        apply.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dpToPx(BUTTON_HEIGHT_DP)));
        apply.setOnClickListener(view -> {
            if (mApplyInProgress) {
                return;
            }
            if (!apply.isEnabled()) {
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (now - mLastApplyTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastApplyTime = now;
                commitAndDismiss();
            }
        });
        mApplyButton = apply;
        mThemeHelper.updateButton(apply, true);
        animateButton(apply);

        bar.addView(cancel);
        bar.addView(title);
        bar.addView(apply);
        return bar;
    }

    /**
     * Attaches a scale animation to the button for touch feedback.
     *
     * @param button Button to animate
     */
    private void animateButton(@NonNull final Button button) {
        button.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS)
                        .start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS)
                        .start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    /**
     * Builds the header bar showing {@code SCOPE MODE: <label>}
     * on the left and the song count right-aligned.
     *
     * @return The header layout
     */
    @NonNull
    private LinearLayout buildHeader() {
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(HEADER_BAR_HEIGHT_DP)));
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP),
            dpToPx(HEADER_PADDING_HORIZONTAL_DP),
            dpToPx(HEADER_PADDING_VERTICAL_DP));
        header.setBackgroundColor(
            Color.parseColor(HEADER_BACKGROUND_COLOR));

        mHeaderText = new TextView(mContext);
        mHeaderText.setTextSize(12);
        mHeaderText.setLetterSpacing(0.1f);
        mHeaderText.setTextColor(
            Color.parseColor(TEXT_COLOR_LIGHT));
        mHeaderText.setMaxLines(1);
        mHeaderText.setEllipsize(
            android.text.TextUtils.TruncateAt.END);
        mHeaderText.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(mHeaderText);

        mCountText = new TextView(mContext);
        mCountText.setTextSize(12);
        mCountText.setLetterSpacing(0.1f);
        mCountText.setTextColor(
            Color.parseColor(TEXT_COLOR_LIGHT));
        mCountText.setMaxLines(1);
        mCountText.setEllipsize(
            android.text.TextUtils.TruncateAt.END);
        final LinearLayout.LayoutParams countParams =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        countParams.setMarginStart(
            dpToPx(HEADER_COUNT_MARGIN_START_DP));
        mCountText.setLayoutParams(countParams);
        header.addView(mCountText);

        return header;
    }

    // ============================================================================
    // Row Assembly
    // ============================================================================

    /**
     * Rebuilds {@link #mRows} from the current state and notifies
     * the adapter.
     */
    private void rebuildRows() {
        mRows.clear();
        appendMode(PlaybackScope.Kind.ALL_SONGS,
            R.string.scope_dialog_option_all_songs);
        appendMode(PlaybackScope.Kind.FAVORITES,
            R.string.scope_dialog_option_favorites);
        appendMode(PlaybackScope.Kind.LOOSE_TRACKS,
            R.string.scope_dialog_option_loose_tracks);
        appendMode(PlaybackScope.Kind.SPECIFIC_FOLDERS,
            R.string.scope_dialog_option_specific_folders);
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_FOLDERS);
        appendMode(PlaybackScope.Kind.SPECIFIC_GENRES,
            R.string.scope_dialog_option_specific_genres);
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_GENRES);
        appendMode(PlaybackScope.Kind.SPECIFIC_ARTISTS,
            R.string.scope_dialog_option_specific_artists);
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_ARTISTS);
        appendMode(PlaybackScope.Kind.SPECIFIC_ALBUMS,
            R.string.scope_dialog_option_specific_albums);
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_ALBUMS);

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateHeader();
    }

    /**
     * Appends one mode row to the row model.
     *
     * @param kind Scope kind of the mode
     * @param stringResource String resource identifier for the
     *        label
     */
    private void appendMode(PlaybackScope.Kind kind,
                            @StringRes int stringResource) {
        mRows.add(Row.mode(kind,
            getLocaleContext().getString(stringResource)));
    }

    /**
     * Appends the filter rows for the given kind, but only when
     * that kind is currently selected and its filter list is
     * expanded.
     *
     * @param kind Filter kind to consider
     */
    private void appendFiltersIf(PlaybackScope.Kind kind) {
        if (mSelectedKind != kind || !mFilterExpanded) {
            return;
        }
        switch (kind) {
            case SPECIFIC_FOLDERS:
                for (FolderEntry folderEntry : mFolderEntries) {
                    mRows.add(Row.filter(kind, folderEntry.path,
                        folderEntry.displayName));
                }
                break;
            case SPECIFIC_GENRES:
                for (String genreValue : mGenreValues) {
                    mRows.add(Row.filter(kind, genreValue,
                        genreValue));
                }
                break;
            case SPECIFIC_ARTISTS:
                for (String artistValue : mArtistValues) {
                    mRows.add(Row.filter(kind, artistValue,
                        artistValue));
                }
                break;
            case SPECIFIC_ALBUMS:
                for (String albumValue : mAlbumValues) {
                    mRows.add(Row.filter(kind, albumValue,
                        albumValue));
                }
                break;
            default:
                break;
        }
    }

    /**
     * Refreshes the header text from the current selected mode
     * and the count of songs the current selection would yield.
     *
     * <p>The count is computed through
     * {@link PlaybackScope#matches(Song, Set)} against the full
     * song list, so the number shown is exactly the number
     * {@link #buildScope()} would hand to the listener if APPLY
     * were tapped now. The two cannot disagree, because both
     * read the same selection through the same matcher.</p>
     *
     * <p>A filter mode with no filter values checked is a scope
     * that matches nothing, so the count reads zero. That is the
     * honest number — it is what APPLY would return — and it
     * tells the user that the filter has not been given any
     * values yet.</p>
     *
     * <p>Before {@link #loadDynamicFilterLists()} completes,
     * {@link #mAllSongs} is null and the count is omitted; the
     * header reads {@code SCOPE MODE: <label>} alone.</p>
     */
    private void updateHeader() {
        if (mHeaderText == null || mCountText == null) {
            return;
        }
        String modeLabel = getLocaleContext().getString(
            modeLabelResource(mSelectedKind));
        String header = getLocaleContext().getString(
            R.string.scope_dialog_mode_prefix) + " " + modeLabel;
        mHeaderText.setText(header);

        int count = computeScopeCount();
        if (count >= 0) {
            mCountText.setText(
                getLocaleContext().getResources().getQuantityString(
                    R.plurals.song_count, count, count));
            mCountText.setVisibility(View.VISIBLE);
        } else {
            mCountText.setVisibility(View.GONE);
        }
    }

    /**
     * Counts the songs the current selection would yield.
     *
     * <p>Runs one {@link PlaybackScope#matches(Song, Set)} pass
     * over the cached song list — the same matcher the service
     * uses to build the playlist. At dialog scale (a tap, on a
     * library the dialog has already enumerated) this is a few
     * milliseconds and does not need a background thread.</p>
     *
     * @return The count, or {@code -1} when the song list has
     *         not finished loading
     */
    private int computeScopeCount() {
        final ArrayList<Song> songs = mAllSongs;
        final Set<String> loose = mLooseTrackPaths;
        if (songs == null || loose == null) {
            return -1;
        }
        final PlaybackScope scope = buildScope();
        int count = 0;
        for (Song song : songs) {
            if (scope.matches(song, loose)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Returns the label resource for the given scope kind.
     *
     * @param kind Scope kind to resolve
     * @return The label's string resource identifier
     */
    @StringRes
    private static int modeLabelResource(PlaybackScope.Kind kind) {
        switch (kind) {
            case ALL_SONGS:
                return R.string.scope_dialog_option_all_songs;
            case FAVORITES:
                return R.string.scope_dialog_option_favorites;
            case LOOSE_TRACKS:
                return R.string.scope_dialog_option_loose_tracks;
            case SPECIFIC_FOLDERS:
                return R.string.scope_dialog_option_specific_folders;
            case SPECIFIC_GENRES:
                return R.string.scope_dialog_option_specific_genres;
            case SPECIFIC_ARTISTS:
                return R.string.scope_dialog_option_specific_artists;
            case SPECIFIC_ALBUMS:
                return R.string.scope_dialog_option_specific_albums;
            default:
                return R.string.scope_dialog_option_all_songs;
        }
    }

    /**
     * Returns whether the given kind carries a filter list.
     *
     * @param kind Scope kind to test
     * @return True for Folders, Genres, Artists, Albums
     */
    private static boolean supportsFilters(PlaybackScope.Kind kind) {
        return kind == PlaybackScope.Kind.SPECIFIC_FOLDERS
            || kind == PlaybackScope.Kind.SPECIFIC_GENRES
            || kind == PlaybackScope.Kind.SPECIFIC_ARTISTS
            || kind == PlaybackScope.Kind.SPECIFIC_ALBUMS;
    }

    // ============================================================================
    // Filter Data Loading
    // ============================================================================

    /**
     * Resolves each folder item's filesystem path and stores the
     * successfully resolved entries.
     */
    private void populateFolderEntries() {
        mFolderEntries.clear();
        for (FolderAdapter.FolderItem folderItem : mFolderItems) {
            if (folderItem == null || folderItem.isLooseTracks) {
                continue;
            }
            String folderPath;
            try {
                folderPath = StorageAccessHelper
                    .getInstance(mContext)
                    .getFolderPathFromUri(
                        Uri.parse(folderItem.uriString));
            } catch (Exception exception) {
                Log.w(TAG, "resolveFolderPath failed for "
                    + folderItem.uriString, exception);
                folderPath = null;
            }
            if (folderPath != null && !folderPath.isEmpty()) {
                mFolderEntries.add(new FolderEntry(
                    folderPath, folderItem.displayName));
            }
        }
        Collections.sort(mFolderEntries, (f1, f2) ->
            String.CASE_INSENSITIVE_ORDER.compare(
                f1.displayName, f2.displayName));
    }

    /**
     * Loads the genre, artist, and album lists on a background
     * executor and posts the populated rows back to the main
     * thread.
     *
     * <p>The loader also caches the full song list and the
     * loose-track path set on the main thread. Those caches feed
     * {@link #computeScopeCount()}, which needs the same inputs
     * {@link PlaybackScope#matches(Song, Set)} requires. They
     * are published only after the loader has finished, so the
     * header's count is omitted until then — the count appears
     * on the same frame the filter lists do.</p>
     */
    private void loadDynamicFilterLists() {
        mLoader.execute(() -> {
            final Set<String> genreValues = new HashSet<>();
            final Set<String> artistValues = new HashSet<>();
            final Set<String> albumValues = new HashSet<>();
            final Set<String> loosePaths = new HashSet<>();
            ArrayList<Song> songs = null;
            boolean failed = false;
            try {
                songs = SongDatabase.getInstance(mContext)
                    .getAllSongs();
                for (Song song : songs) {
                    if (song == null) {
                        continue;
                    }
                    String genreValue = song.getGenre();
                    if (genreValue != null
                            && !CharacterMapper.isUnknownGenre(
                                genreValue)) {
                        genreValues.add(genreValue);
                    }
                    String artistValue = song.getArtist();
                    if (artistValue != null
                            && !CharacterMapper.isUnknownArtist(
                                artistValue)) {
                        artistValues.add(artistValue);
                    }
                    String albumValue = song.getAlbum();
                    if (albumValue != null
                            && !CharacterMapper.isUnknownAlbum(
                                albumValue)) {
                        albumValues.add(albumValue);
                    }
                }
                ArrayList<Song> looseSongs =
                    SongDatabase.getInstance(mContext).getLooseSongs();
                if (looseSongs != null) {
                    for (Song looseSong : looseSongs) {
                        if (looseSong != null
                                && looseSong.getPath() != null) {
                            loosePaths.add(looseSong.getPath());
                        }
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "Failed to enumerate filter values",
                    exception);
                failed = true;
            }
            final boolean finalFailed = failed;
            final ArrayList<Song> loadedSongs = songs;
            final Set<String> loadedLoose = loosePaths;
            mMain.post(() -> {
                if (!isShowing()) {
                    return;
                }
                if (finalFailed) {
                    View content = findViewById(
                        android.R.id.content);
                    if (content instanceof ViewGroup) {
                        ToastManager.showToastInView(
                            (ViewGroup) content,
                            getLocaleContext().getString(
                                R.string.scope_dialog_load_error),
                            ToastManager.LENGTH_NORMAL);
                    }
                    return;
                }
                mAllSongs = loadedSongs;
                mLooseTrackPaths = loadedLoose;
                mGenreValues.clear();
                mGenreValues.addAll(genreValues);
                Collections.sort(mGenreValues,
                    String.CASE_INSENSITIVE_ORDER);
                mArtistValues.clear();
                mArtistValues.addAll(artistValues);
                Collections.sort(mArtistValues,
                    String.CASE_INSENSITIVE_ORDER);
                mAlbumValues.clear();
                mAlbumValues.addAll(albumValues);
                Collections.sort(mAlbumValues,
                    String.CASE_INSENSITIVE_ORDER);
                rebuildRows();
            });
        });
    }

    // ============================================================================
    // Selection Handling
    // ============================================================================

    /**
     * Handles a tap on a mode row.
     *
     * <p>A queued commit is cancelled first. A commit in progress
     * captured the scope at the moment APPLY was tapped; a mode
     * tap during the dismissal window means the user has moved
     * past that scope, so letting the commit fire would apply a
     * selection they no longer want and close the dialog on it.
     * Cancelling restores the APPLY button and leaves the dialog
     * open so the user can confirm the new selection.</p>
     *
     * @param kind Kind of the tapped mode
     */
    private void onModeTapped(PlaybackScope.Kind kind) {
        cancelPendingCommit();
        if (mSelectedKind == kind) {
            if (supportsFilters(kind)) {
                mFilterExpanded = !mFilterExpanded;
            }
        } else {
            mSelectedKind = kind;
            clearAllFilters();
            mFilterExpanded = supportsFilters(kind);
        }
        rebuildRows();
        updateApplyEnabled();
    }

    /**
     * Handles a tap on a filter row.
     *
     * <p>A queued commit is cancelled first, for the same reason
     * as {@link #onModeTapped(PlaybackScope.Kind)}: the commit
     * captured a filter set the user has just changed, so it
     * must not be allowed to fire.</p>
     *
     * <p>The mode and its expansion state are not touched here.
     * An empty set is a valid selection — the scope simply
     * matches nothing — and the dialog shows that as it is,
     * with a count of zero. Only a mode tap changes the mode.</p>
     *
     * @param kind Kind of the filter row's category
     * @param value Filter value to toggle
     */
    private void onFilterToggled(PlaybackScope.Kind kind,
                                 @NonNull String value) {
        cancelPendingCommit();
        Set<String> targetSet = setFor(kind);
        if (targetSet.contains(value)) {
            targetSet.remove(value);
        } else {
            targetSet.add(value);
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateHeader();
        updateApplyEnabled();
    }

    /**
     * Cancels a queued commit and restores the APPLY button to
     * the state the current draft warrants, if a commit is
     * currently in progress.
     *
     * <p>Called when the user changes a preference — a mode tap
     * or a filter toggle — after tapping APPLY but before the
     * delayed commit fires. The queued commit captured the scope
     * at the moment APPLY was tapped; letting it run would apply
     * a scope the user has already moved past, and would also
     * dismiss the dialog on a selection they did not confirm.
     * Cancelling it here means the user's next APPLY captures
     * the scope they actually want.</p>
     *
     * <p>When no commit is in progress this method does
     * nothing, so it is safe to call unconditionally from the
     * tap handlers.</p>
     */
    private void cancelPendingCommit() {
        if (!mApplyInProgress) {
            return;
        }
        mApplyInProgress = false;
        if (mPendingCommit != null) {
            mMain.removeCallbacks(mPendingCommit);
            mPendingCommit = null;
        }
        updateApplyEnabled();
    }

    /**
     * Enables or disables APPLY from the current draft scope.
     *
     * <p>APPLY is enabled exactly when the draft differs from
     * the scope the dialog opened with. A filter kind with an
     * empty set is a real scope — it matches nothing — so
     * selecting one from a different starting scope is a change
     * and APPLY is enabled; selecting the scope that is already
     * applied is not a change and APPLY is disabled. Emptiness
     * alone is never the deciding factor.</p>
     *
     * <p>Called from every handler that can change the draft —
     * a mode tap, a filter toggle, a cancelled commit — and
     * once at the end of {@link #onCreate(Bundle)} so a
     * freshly-opened dialog starts with APPLY in the right
     * state. A no-op before the button exists.</p>
     */
    private void updateApplyEnabled() {
        if (mApplyButton == null) {
            return;
        }
        boolean changed = !buildScope().equals(mInitialScope);
        mApplyButton.setEnabled(changed);
        mThemeHelper.updateButton(mApplyButton, changed);
    }

    /**
     * Returns the set that backs the given filter kind.
     *
     * @param kind Filter kind
     * @return The selected values for that kind
     */
    @NonNull
    private Set<String> setFor(PlaybackScope.Kind kind) {
        switch (kind) {
            case SPECIFIC_FOLDERS: return mSelectedPaths;
            case SPECIFIC_GENRES:  return mSelectedGenres;
            case SPECIFIC_ARTISTS: return mSelectedArtists;
            case SPECIFIC_ALBUMS:  return mSelectedAlbums;
            default:      return new HashSet<>();
        }
    }

    /**
     * Clears every filter selection.
     */
    private void clearAllFilters() {
        mSelectedPaths.clear();
        mSelectedGenres.clear();
        mSelectedArtists.clear();
        mSelectedAlbums.clear();
    }

    // ============================================================================
    // Commit
    // ============================================================================

    /**
     * Builds the scope from the current selection, disables the
     * APPLY button, hands the scope to the listener after
     * {@link #DISMISS_DELAY_MS}, shows the scope toast, then
     * dismisses.
     *
     * <p>The button is disabled for the whole window between
     * the tap and the dismissal, so a second tap cannot queue
     * a second commit behind the first. The runnable is held on
     * {@link #mPendingCommit} so a preference change made
     * during the window can cancel it through
     * {@link #cancelPendingCommit()}.</p>
     *
     * <p>The listener is invoked inside a {@code try} whose
     * {@code finally} dismisses, so a listener that throws
     * cannot leave the dialog on screen with the button
     * disabled. The toast is shown after the listener has
     * returned and inside the same {@code try}, so a listener
     * that throws suppresses the toast along with the rest of
     * the commit.</p>
     */
    private void commitAndDismiss() {
        mApplyInProgress = true;
        if (mApplyButton != null) {
            mApplyButton.setEnabled(false);
            mThemeHelper.updateButton(mApplyButton, false);
        }
        final PlaybackScope scope = buildScope();
        final String scopeLabel = getLocaleContext().getString(
            modeLabelResource(scope.kind));
        mPendingCommit = () -> {
            mPendingCommit = null;
            try {
                if (mListener != null) {
                    mListener.onScopeApplied(scope);
                }
                if (mContext instanceof Activity) {
                    ToastManager.showToast((Activity) mContext,
                        getLocaleContext().getString(
                            R.string.scope_toast_applied, scopeLabel),
                        ToastManager.LENGTH_NORMAL);
                }
            } finally {
                dismiss();
            }
        };
        mMain.postDelayed(mPendingCommit, DISMISS_DELAY_MS);
    }

    /**
     * Builds the scope the user has selected.
     *
     * <p>A filter kind returns its real scope even when its set
     * is empty. An empty set is a scope that matches nothing —
     * "limit to these artists" with no artists named — and the
     * dialog reports it as such: the header count reads zero
     * and APPLY is enabled only when the draft differs from the
     * applied scope. The empty scope is never rewritten into
     * {@link PlaybackScope#ALL_SONGS}; that scope is reached by
     * selecting the All Songs mode, not by emptying another.</p>
     *
     * @return The selected scope
     */
    @NonNull
    private PlaybackScope buildScope() {
        switch (mSelectedKind) {
            case FAVORITES:
                return PlaybackScope.favorites();
            case LOOSE_TRACKS:
                return PlaybackScope.looseTracks();
            case SPECIFIC_FOLDERS:
                return PlaybackScope.folders(mSelectedPaths);
            case SPECIFIC_GENRES:
                return PlaybackScope.genres(mSelectedGenres);
            case SPECIFIC_ARTISTS:
                return PlaybackScope.artists(mSelectedArtists);
            case SPECIFIC_ALBUMS:
                return PlaybackScope.albums(mSelectedAlbums);
            case ALL_SONGS:
            default:
                return PlaybackScope.ALL_SONGS;
        }
    }

    // ============================================================================
    // Adapter
    // ============================================================================

    /**
     * Binds the dialog's row model to the RecyclerView,
     * dispatching to the radio or checkbox indicator based on the
     * row type.
     */
    private class ScopeAdapter
            extends RecyclerView.Adapter<ScopeHolder> {

        /**
         * Returns the view type of the row at the given position.
         *
         * @param position Adapter position
         * @return {@link Row#TYPE_MODE} or
         *         {@link Row#TYPE_FILTER}
         */
        @Override
        public int getItemViewType(int position) {
            return mRows.get(position).type;
        }

        /**
         * Creates a view holder for a scope row.
         *
         * @param parent Parent view group into which the new
         *        view is added
         * @param viewType View type
         * @return A new view holder for the row
         */
        @NonNull
        @Override
        public ScopeHolder onCreateViewHolder(
                @NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_scope_row, parent, false);
            return new ScopeHolder(view);
        }

        /**
         * Binds the row at the given position to the view
         * holder.
         *
         * @param holder View holder to bind
         * @param position Adapter position
         */
        @Override
        public void onBindViewHolder(@NonNull ScopeHolder holder,
                                     int position) {
            Row row = mRows.get(position);
            holder.mLabel.setText(row.label);

            if (row.type == Row.TYPE_MODE) {
                boolean selected = row.kind == mSelectedKind;
                mThemeHelper.updateRadio(
                    holder.mIndicator, selected, true);
                applyRowBackground(holder.itemView, selected);
                holder.itemView.setOnClickListener(view ->
                    onModeTapped(row.kind));
                attachPressHighlight(holder.itemView, selected);
            } else {
                Set<String> selectedSet = setFor(row.kind);
                boolean checked = row.value != null
                    && selectedSet.contains(row.value);
                mThemeHelper.updateCheckbox(
                    holder.mIndicator, checked, true);
                applyRowBackground(holder.itemView, false);
                holder.itemView.setOnClickListener(view ->
                    onFilterToggled(row.kind, row.value));
                attachPressHighlight(holder.itemView, false);
            }
        }

        /**
         * Returns the number of rows currently displayed.
         *
         * @return The number of rows in the dialog
         */
        @Override
        public int getItemCount() {
            return mRows.size();
        }
    }

    /**
     * Caches the child views of a scope row.
     */
    private static class ScopeHolder extends RecyclerView.ViewHolder {

        /** TextView that shows the row's label. */
        final TextView mLabel;

        /** TextView that draws the radio or checkbox. */
        final TextView mIndicator;

        /**
         * Constructs a view holder and resolves its child
         * views.
         *
         * @param itemView Inflated row view
         */
        ScopeHolder(@NonNull View itemView) {
            super(itemView);
            mLabel = itemView.findViewById(R.id.scopeRowLabel);
            mIndicator = itemView.findViewById(
                R.id.scopeRowIndicator);
        }
    }

    // ============================================================================
    // Row Background and Highlight
    // ============================================================================

    /**
     * Applies the selection background or clears it.
     *
     * @param row The row view
     * @param selected True when the row is the currently
     *        selected mode
     */
    private void applyRowBackground(@NonNull View row,
                                    boolean selected) {
        row.setBackgroundColor(selected
            ? Color.parseColor(SELECTED_BACKGROUND_COLOR)
            : Color.TRANSPARENT);
    }

    /**
     * Attaches a press highlight to the row.
     *
     * @param row The row view
     * @param staySelected True when the row keeps its
     *        selection background after release
     */
    private void attachPressHighlight(@NonNull View row,
                                      boolean staySelected) {
        row.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.setBackgroundColor(
                        Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.setBackgroundColor(staySelected
                        ? Color.parseColor(
                            SELECTED_BACKGROUND_COLOR)
                        : Color.TRANSPARENT);
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    // ============================================================================
    // Helper Methods
    // ============================================================================

    /**
     * Forces the dialog content to re-measure, re-layout, and re-draw.
     */
    private void forceRedraw() {
        Window window = getWindow();
        if (window == null) {
            return;
        }
        View root = window.getDecorView().findViewById(
            android.R.id.content);
        if (root == null) {
            return;
        }
        root.requestLayout();
        root.invalidate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation();
        }
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * mContext.getResources()
            .getDisplayMetrics().density);
    }
}