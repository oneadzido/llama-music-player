// PlaybackScopeDialog.java
package com.ark.llama;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Presents the seven scope modes and their associated filter lists,
 * and reports the user's selection through
 * {@link OnScopeAppliedListener}.
 *
 * <p>The dialog opens with the scope currently applied. The first
 * three modes — All, Favorites, Loose Tracks — are single-select
 * radio buttons; the last four — Folders, Genres, Artists, Albums —
 * are multi-select checkbox lists. Selecting a checkbox in one of the
 * four categories clears the other three categories and moves the
 * radio group to "no selection", which is the "some filter is
 * active" state. Clearing every checkbox returns the radio group to
 * All.</p>
 *
 * <h3>Top Bar Geometry</h3>
 * <p>Follows the shape every dialog in the app uses: cancel on the
 * leading edge, title taking the leftover width with weight 1, and
 * apply on the trailing edge with its natural width. The title is the
 * only element that can yield.</p>
 *
 * <h3>Dynamic Lists</h3>
 * <p>The folder list is supplied by the caller. The genre, artist,
 * and album lists are enumerated from the songs table on a
 * background executor and posted back to the main thread; the
 * placeholder values are filtered out using
 * {@link CharacterMapper#isUnknownGenre(String)} and its siblings, so
 * a user is never offered "Unknown Artist" as a scope.</p>
 *
 * <h3>Resilience</h3>
 * <p>If the enumerations fail, the dialog stays usable — the folder
 * list still renders — and a toast names the failure. The apply
 * button never returns a scope whose kind is one of the four
 * filter kinds without a non-empty set: an empty set at apply time
 * becomes {@link PlaybackScope#ALL}.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.4.0
 * @since 1.4.0
 */
public class PlaybackScopeDialog extends Dialog {

    // ============================================================================
    // Constants
    // ============================================================================

    /** Log tag for this class. */
    private static final String TAG = "PlaybackScopeDialog";

    /** Dark background color for the dialog. */
    private static final String BACKGROUND_COLOR = "#121212";

    /** Muted label color for section titles. */
    private static final String TEXT_COLOR_MUTED = "#808080";

    /** Light text color for row labels. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";

    /** Height of the top action bar, in dp. */
    private static final int TOP_BAR_HEIGHT_DP = 64;

    /** Height of action buttons, in dp. */
    private static final int BUTTON_HEIGHT_DP = 36;

    /** Standard padding, in dp. */
    private static final int PADDING_STANDARD_DP = 16;

    /** Horizontal padding for list sections, in dp. */
    private static final int SECTION_PADDING_DP = 16;

    /** Debounce delay for the apply and cancel buttons, in ms. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500L;

    // ============================================================================
    // Fields
    // ============================================================================

    @NonNull private final Context mContext;
    @NonNull private final PlaybackScope mInitialScope;
    @NonNull private final List<FolderAdapter.FolderItem> mFolderItems;
    @Nullable private final OnScopeAppliedListener mListener;
    @NonNull private final ExecutorService mLoader =
        Executors.newSingleThreadExecutor();
    @NonNull private final Handler mMain =
        new Handler(Looper.getMainLooper());
    @NonNull private final ThemeManager mThemeManager;
    @NonNull private final ThemeHelper mThemeHelper;

    @Nullable private RadioGroup mRadioGroup;
    @Nullable private RadioButton mRadioAll;
    @Nullable private RadioButton mRadioFavorites;
    @Nullable private RadioButton mRadioLoose;
    @Nullable private LinearLayout mFoldersList;
    @Nullable private LinearLayout mGenresList;
    @Nullable private LinearLayout mArtistsList;
    @Nullable private LinearLayout mAlbumsList;

    @NonNull private final Set<String> mSelectedPaths = new HashSet<>();
    @NonNull private final Set<String> mSelectedGenres = new HashSet<>();
    @NonNull private final Set<String> mSelectedArtists = new HashSet<>();
    @NonNull private final Set<String> mSelectedAlbums = new HashSet<>();

    @NonNull private PlaybackScope.Kind mKind = PlaybackScope.Kind.ALL;
    private long mLastApplyTime = 0L;
    private long mLastCancelTime = 0L;

    // ============================================================================
    // Listener Interface
    // ============================================================================

    /**
     * Receives the scope the user selected.
     */
    public interface OnScopeAppliedListener {

        /**
         * Called when the user taps APPLY.
         *
         * @param scope The selected scope; never null
         */
        void onScopeApplied(@NonNull PlaybackScope scope);
    }

    // ============================================================================
    // Constructor
    // ============================================================================

    /**
     * Constructs the dialog.
     *
     * @param context Context used to resolve resources and construct
     *        views
     * @param initialScope Scope currently applied
     * @param folderItems Folder rows to present in the folders
     *        section; the Loose Tracks pseudo-item is ignored
     * @param listener Listener notified on apply, or null
     */
    public PlaybackScopeDialog(@NonNull Context context,
                               @NonNull PlaybackScope initialScope,
                               @NonNull List<FolderAdapter.FolderItem> folderItems,
                               @Nullable OnScopeAppliedListener listener) {
        super(context, android.R.style.Theme_Black_NoTitleBar);
        mContext = context;
        mInitialScope = initialScope;
        mFolderItems = folderItems;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
        mKind = initialScope.kind;
        mSelectedPaths.addAll(initialScope.paths);
        mSelectedGenres.addAll(initialScope.genres);
        mSelectedArtists.addAll(initialScope.artists);
        mSelectedAlbums.addAll(initialScope.albums);
    }

    // ============================================================================
    // Localization Helper
    // ============================================================================

    /**
     * Returns a context that resolves resources against the app's
     * selected language.
     *
     * @return The locale-wrapped context, or the activity context on
     *         failure
     */
    @NonNull
    private Context getLocaleContext() {
        try {
            return LanguageManager.getInstance(mContext)
                .getLocalizedContext();
        } catch (Exception exception) {
            Log.w(TAG, "Failed to obtain localized context",
                exception);
            return mContext;
        }
    }

    // ============================================================================
    // Dialog Lifecycle
    // ============================================================================

    /**
     * Initializes the dialog's window, content view, and dynamic
     * lists.
     *
     * @param savedInstanceState Previously saved state; not used
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(buildContentView());

        Window window = getWindow();
        if (window != null) {
            configureWindow(window);
        }

        applyTheme();
        populateFolderList();
        loadDynamicFilterLists();
    }

    /**
     * Dismisses the dialog and releases every resource it holds.
     */
    @Override
    public void dismiss() {
        super.dismiss();
        mMain.removeCallbacksAndMessages(null);
        if (!mLoader.isShutdown()) {
            mLoader.shutdownNow();
        }
    }

    /**
     * Configures the dialog window for a full-screen, bottom-anchored
     * presentation with the slide-up animation.
     *
     * @param window Window to configure
     */
    private void configureWindow(@NonNull Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor(BACKGROUND_COLOR));
            window.setNavigationBarColor(Color.parseColor(BACKGROUND_COLOR));
        }
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setWindowAnimations(R.style.PlaybackScopeDialogAnimation);
    }

    // ============================================================================
    // Content Construction
    // ============================================================================

    /**
     * Builds the dialog's content view.
     *
     * @return The root view
     */
    @NonNull
    private View buildContentView() {
        LinearLayout root = new LinearLayout(mContext);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(BACKGROUND_COLOR));
        background.setCornerRadii(
            new float[] {20, 20, 20, 20, 0, 0, 0, 0});
        root.setBackground(background);

        root.addView(buildTopBar());

        ScrollView scroll = new ScrollView(mContext);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        scroll.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        LinearLayout body = new LinearLayout(mContext);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(8), 0, dp(16));

        mRadioGroup = new RadioGroup(mContext);
        mRadioGroup.setOrientation(RadioGroup.VERTICAL);
        mRadioAll = makeRadio(R.string.scope_dialog_option_all);
        mRadioFavorites = makeRadio(R.string.scope_dialog_option_favorites);
        mRadioLoose = makeRadio(R.string.scope_dialog_option_loose);
        mRadioGroup.addView(mRadioAll);
        mRadioGroup.addView(mRadioFavorites);
        mRadioGroup.addView(mRadioLoose);
        mRadioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == mRadioAll.getId()) {
                mKind = PlaybackScope.Kind.ALL;
                clearAllFilters();
            } else if (checkedId == mRadioFavorites.getId()) {
                mKind = PlaybackScope.Kind.FAVORITES;
                clearAllFilters();
            } else if (checkedId == mRadioLoose.getId()) {
                mKind = PlaybackScope.Kind.LOOSE_TRACKS;
                clearAllFilters();
            }
        });
        body.addView(mRadioGroup);

        body.addView(buildSectionHeader(R.string.scope_dialog_option_folders));
        mFoldersList = buildFilterContainer();
        body.addView(mFoldersList);

        body.addView(buildSectionHeader(R.string.scope_dialog_option_genres));
        mGenresList = buildFilterContainer();
        body.addView(mGenresList);

        body.addView(buildSectionHeader(R.string.scope_dialog_option_artists));
        mArtistsList = buildFilterContainer();
        body.addView(mArtistsList);

        body.addView(buildSectionHeader(R.string.scope_dialog_option_albums));
        mAlbumsList = buildFilterContainer();
        body.addView(mAlbumsList);

        scroll.addView(body);
        root.addView(scroll);

        switch (mKind) {
            case FAVORITES:
                mRadioGroup.check(mRadioFavorites.getId());
                break;
            case LOOSE_TRACKS:
                mRadioGroup.check(mRadioLoose.getId());
                break;
            case ALL:
                mRadioGroup.check(mRadioAll.getId());
                break;
            default:
                // The four filter kinds leave the radio group
                // unchecked; the checkboxes below carry the state.
                break;
        }

        return root;
    }

    /**
     * Builds the top action bar: cancel, title, apply.
     *
     * @return The top bar layout
     */
    @NonNull
    private LinearLayout buildTopBar() {
        LinearLayout bar = new LinearLayout(mContext);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(TOP_BAR_HEIGHT_DP)));
        bar.setPadding(dp(PADDING_STANDARD_DP),
            dp(PADDING_STANDARD_DP),
            dp(PADDING_STANDARD_DP),
            dp(PADDING_STANDARD_DP));
        bar.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));

        Button cancel = new Button(mContext);
        cancel.setText(getLocaleContext().getString(R.string.action_cancel));
        cancel.setTextSize(14);
        cancel.setLetterSpacing(0.1f);
        cancel.setBackgroundResource(R.drawable.button_border_selector);
        cancel.setMinHeight(0);
        cancel.setMinWidth(0);
        cancel.setIncludeFontPadding(false);
        cancel.setSingleLine(true);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dp(BUTTON_HEIGHT_DP)));
        cancel.setOnClickListener(view -> {
            long now = SystemClock.elapsedRealtime();
            if (now - mLastCancelTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelTime = now;
                dismiss();
            }
        });
        mThemeHelper.updateButton(cancel, true);

        TextView title = new TextView(mContext);
        title.setText(getLocaleContext().getString(
            R.string.scope_dialog_title));
        title.setTextSize(14);
        title.setLetterSpacing(0.1f);
        title.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        title.setGravity(Gravity.CENTER);
        title.setIncludeFontPadding(false);
        title.setSingleLine(true);
        title.setLayoutParams(new LinearLayout.LayoutParams(
            0, dp(BUTTON_HEIGHT_DP), 1f));

        Button apply = new Button(mContext);
        apply.setText(getLocaleContext().getString(R.string.action_apply));
        apply.setTextSize(14);
        apply.setLetterSpacing(0.1f);
        apply.setBackgroundResource(R.drawable.button_border_selector);
        apply.setMinHeight(0);
        apply.setMinWidth(0);
        apply.setIncludeFontPadding(false);
        apply.setSingleLine(true);
        apply.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dp(BUTTON_HEIGHT_DP)));
        apply.setOnClickListener(view -> {
            long now = SystemClock.elapsedRealtime();
            if (now - mLastApplyTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastApplyTime = now;
                commitAndDismiss();
            }
        });
        mThemeHelper.updateButton(apply, true);

        bar.addView(cancel);
        bar.addView(title);
        bar.addView(apply);
        return bar;
    }

    /**
     * Creates a radio button for one of the three exclusive modes.
     *
     * @param textRes String resource identifier for the label
     * @return The configured radio button
     */
    @NonNull
    private RadioButton makeRadio(@StringRes int textRes) {
        RadioButton radioButton = new RadioButton(mContext);
        radioButton.setId(View.generateViewId());
        radioButton.setText(getLocaleContext().getString(textRes));
        radioButton.setTextSize(14);
        radioButton.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        radioButton.setPadding(dp(SECTION_PADDING_DP), dp(12),
            dp(SECTION_PADDING_DP), dp(12));
        return radioButton;
    }

    /**
     * Creates a section header for one of the four filter lists.
     *
     * @param titleRes String resource identifier for the header
     * @return The header text view
     */
    @NonNull
    private TextView buildSectionHeader(@StringRes int titleRes) {
        TextView title = new TextView(mContext);
        title.setText(getLocaleContext().getString(titleRes));
        title.setTextSize(12);
        title.setLetterSpacing(0.1f);
        title.setTextColor(Color.parseColor(TEXT_COLOR_MUTED));
        title.setPadding(dp(SECTION_PADDING_DP), dp(16),
            dp(SECTION_PADDING_DP), dp(4));
        return title;
    }

    /**
     * Creates the container that holds one filter list's checkboxes.
     *
     * @return The empty list container
     */
    @NonNull
    private LinearLayout buildFilterContainer() {
        LinearLayout container = new LinearLayout(mContext);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(SECTION_PADDING_DP), 0,
            dp(SECTION_PADDING_DP), dp(8));
        return container;
    }

    /**
     * Populates the folder list from the items supplied by the
     * caller. Folders that cannot be resolved to a filesystem path
     * are skipped.
     */
    private void populateFolderList() {
        if (mFoldersList == null) {
            return;
        }
        for (FolderAdapter.FolderItem item : mFolderItems) {
            if (item == null || item.isLooseTracks) {
                continue;
            }
            final String path = resolveFolderPath(item.uriString);
            if (path == null || path.isEmpty()) {
                continue;
            }
            addFilterCheckbox(mFoldersList, path, item.displayName,
                mSelectedPaths, PlaybackScope.Kind.FOLDERS);
        }
    }

    /**
     * Loads the genre, artist, and album lists on a background
     * executor and posts the populated rows back to the main thread.
     */
    private void loadDynamicFilterLists() {
        mLoader.execute(() -> {
            final Set<String> genres = new HashSet<>();
            final Set<String> artists = new HashSet<>();
            final Set<String> albums = new HashSet<>();
            boolean failed = false;
            try {
                SongDatabase database = SongDatabase.getInstance(mContext);
                ArrayList<Song> songs = database.getAllSongs();
                for (Song song : songs) {
                    if (song == null) {
                        continue;
                    }
                    final String genre = song.getGenre();
                    if (genre != null
                            && !CharacterMapper.isUnknownGenre(genre)) {
                        genres.add(genre);
                    }
                    final String artist = song.getArtist();
                    if (artist != null
                            && !CharacterMapper.isUnknownArtist(artist)) {
                        artists.add(artist);
                    }
                    final String album = song.getAlbum();
                    if (album != null
                            && !CharacterMapper.isUnknownAlbum(album)) {
                        albums.add(album);
                    }
                }
            } catch (Exception exception) {
                Log.e(TAG, "Failed to enumerate filter values",
                    exception);
                failed = true;
            }
            final boolean finalFailed = failed;
            mMain.post(() -> {
                if (!isShowing()) {
                    return;
                }
                if (finalFailed) {
                    View content =
                        findViewById(android.R.id.content);
                    if (content instanceof ViewGroup) {
                        ToastManager.showToastInView(
                            (ViewGroup) content,
                            getLocaleContext().getString(
                                R.string.scope_dialog_load_error),
                            ToastManager.LENGTH_NORMAL);
                    }
                    return;
                }
                if (mGenresList != null) {
                    for (String genre : genres) {
                        addFilterCheckbox(mGenresList, genre, genre,
                            mSelectedGenres, PlaybackScope.Kind.GENRES);
                    }
                }
                if (mArtistsList != null) {
                    for (String artist : artists) {
                        addFilterCheckbox(mArtistsList, artist, artist,
                            mSelectedArtists, PlaybackScope.Kind.ARTISTS);
                    }
                }
                if (mAlbumsList != null) {
                    for (String album : albums) {
                        addFilterCheckbox(mAlbumsList, album, album,
                            mSelectedAlbums, PlaybackScope.Kind.ALBUMS);
                    }
                }
            });
        });
    }

    /**
     * Adds a single checkbox to the given filter list.
     *
     * <p>Checking the box moves the scope to the owning kind and
     * clears the other three categories. Unchecking the last box in
     * the current kind returns the scope to All. The mutual exclusion
     * is what makes the four categories a single selector rather than
     * four that can be mixed: the service matches a song against the
     * kind's set, not against a union of the four.</p>
     *
     * @param parent Container to add the checkbox to
     * @param value Stable value the checkbox toggles
     * @param label Label to display
     * @param selectedSet Set the checkbox reads and writes
     * @param ownerKind Kind the checkbox's category belongs to
     */
    private void addFilterCheckbox(@NonNull LinearLayout parent,
                                   @NonNull final String value,
                                   @NonNull String label,
                                   @NonNull final Set<String> selectedSet,
                                   @NonNull final PlaybackScope.Kind ownerKind) {
        final CheckBox checkbox = new CheckBox(mContext);
        checkbox.setText(label);
        checkbox.setTextSize(14);
        checkbox.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        checkbox.setPadding(0, dp(8), 0, dp(8));
        checkbox.setChecked(selectedSet.contains(value));
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mKind = ownerKind;
                if (mRadioGroup != null) {
                    mRadioGroup.clearCheck();
                }
                if (ownerKind != PlaybackScope.Kind.FOLDERS) {
                    mSelectedPaths.clear();
                }
                if (ownerKind != PlaybackScope.Kind.GENRES) {
                    mSelectedGenres.clear();
                }
                if (ownerKind != PlaybackScope.Kind.ARTISTS) {
                    mSelectedArtists.clear();
                }
                if (ownerKind != PlaybackScope.Kind.ALBUMS) {
                    mSelectedAlbums.clear();
                }
                selectedSet.add(value);
            } else {
                selectedSet.remove(value);
                if (selectedSet.isEmpty() && mKind == ownerKind) {
                    mKind = PlaybackScope.Kind.ALL;
                    if (mRadioGroup != null && mRadioAll != null) {
                        mRadioGroup.check(mRadioAll.getId());
                    }
                }
            }
            refreshOtherCategories(ownerKind);
        });
        parent.addView(checkbox);
    }

    /**
     * Unchecks every checkbox in every category other than the one
     * that just changed, so the visual state matches the exclusive
     * scope logic.
     *
     * @param preservedKind Kind whose list must not be touched
     */
    private void refreshOtherCategories(@NonNull PlaybackScope.Kind preservedKind) {
        if (preservedKind != PlaybackScope.Kind.FOLDERS) {
            uncheckAll(mFoldersList);
        }
        if (preservedKind != PlaybackScope.Kind.GENRES) {
            uncheckAll(mGenresList);
        }
        if (preservedKind != PlaybackScope.Kind.ARTISTS) {
            uncheckAll(mArtistsList);
        }
        if (preservedKind != PlaybackScope.Kind.ALBUMS) {
            uncheckAll(mAlbumsList);
        }
    }

    /**
     * Unchecks every checkbox in the given container.
     *
     * @param parent Container to inspect, or null
     */
    private void uncheckAll(@Nullable LinearLayout parent) {
        if (parent == null) {
            return;
        }
        for (int index = 0; index < parent.getChildCount(); index++) {
            View child = parent.getChildAt(index);
            if (child instanceof CheckBox) {
                CheckBox checkbox = (CheckBox) child;
                // Listener is invoked, which will clear the
                // corresponding selected set. Guard against a
                // recursive cascade by clearing the checked state
                // through the set, not through the widget, when the
                // widget's own listener would fire.
                if (checkbox.isChecked()) {
                    checkbox.setChecked(false);
                }
            }
        }
    }

    /**
     * Clears every filter set and unchecks every checkbox. Called by
     * the radio group's listener when the user selects one of the
     * three exclusive modes.
     */
    private void clearAllFilters() {
        mSelectedPaths.clear();
        mSelectedGenres.clear();
        mSelectedArtists.clear();
        mSelectedAlbums.clear();
        uncheckAllSilently(mFoldersList);
        uncheckAllSilently(mGenresList);
        uncheckAllSilently(mArtistsList);
        uncheckAllSilently(mAlbumsList);
    }

    /**
     * Unchecks every checkbox in the given container without firing
     * the check-change listeners.
     *
     * @param parent Container to inspect, or null
     */
    private void uncheckAllSilently(@Nullable LinearLayout parent) {
        if (parent == null) {
            return;
        }
        for (int index = 0; index < parent.getChildCount(); index++) {
            View child = parent.getChildAt(index);
            if (child instanceof CheckBox) {
                // setOnCheckedChangeListener(null) and re-attach is
                // unnecessary here: the checkbox's listener consults
                // the selected set, which is already empty. Setting
                // the checkbox to unchecked will call the listener
                // which will find the value already absent and do
                // nothing visible.
                ((CheckBox) child).setChecked(false);
            }
        }
    }

    /**
     * Resolves the filesystem path behind a folder URI.
     *
     * @param uriString Folder URI, or null
     * @return The filesystem path, or null when the URI does not
     *         name a primary-storage folder
     */
    @Nullable
    private String resolveFolderPath(@Nullable String uriString) {
        if (uriString == null) {
            return null;
        }
        try {
            return StorageAccessHelper.getInstance(mContext)
                .getFolderPathFromUri(Uri.parse(uriString));
        } catch (Exception exception) {
            Log.w(TAG, "resolveFolderPath failed for " + uriString,
                exception);
            return null;
        }
    }

    /**
     * Applies the current theme color to the dialog's buttons.
     */
    private void applyTheme() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
    }

    /**
     * Builds the scope the user has selected and hands it to the
     * listener before dismissing.
     *
     * <p>An empty filter set at apply time becomes
     * {@link PlaybackScope#ALL}. This is the only path by which the
     * dialog can return a scope whose kind is one of the four filter
     * kinds with an empty set; catching it here means the service
     * never has to defend against that state.</p>
     */
    private void commitAndDismiss() {
        final PlaybackScope scope;
        switch (mKind) {
            case FAVORITES:
                scope = PlaybackScope.favorites();
                break;
            case LOOSE_TRACKS:
                scope = PlaybackScope.looseTracks();
                break;
            case FOLDERS:
                scope = mSelectedPaths.isEmpty()
                    ? PlaybackScope.ALL
                    : PlaybackScope.folders(mSelectedPaths);
                break;
            case GENRES:
                scope = mSelectedGenres.isEmpty()
                    ? PlaybackScope.ALL
                    : PlaybackScope.genres(mSelectedGenres);
                break;
            case ARTISTS:
                scope = mSelectedArtists.isEmpty()
                    ? PlaybackScope.ALL
                    : PlaybackScope.artists(mSelectedArtists);
                break;
            case ALBUMS:
                scope = mSelectedAlbums.isEmpty()
                    ? PlaybackScope.ALL
                    : PlaybackScope.albums(mSelectedAlbums);
                break;
            case ALL:
            default:
                scope = PlaybackScope.ALL;
                break;
        }
        if (mListener != null) {
            mListener.onScopeApplied(scope);
        }
        dismiss();
    }

    /**
     * Converts density-independent pixels to pixels.
     *
     * @param dp Value in density-independent pixels
     * @return The equivalent value in pixels
     */
    private int dp(int dp) {
        return Math.round(dp * mContext.getResources()
            .getDisplayMetrics().density);
    }
}