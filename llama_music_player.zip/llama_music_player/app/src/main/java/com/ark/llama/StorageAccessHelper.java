package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Centralized helper for Storage Access Framework (SAF) operations.
 * 
 * <p>This class provides a complete solution for managing document URIs,
 * persisting folder permissions, and resolving file paths to URIs for
 * scoped storage access on Android 10+.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Persistent storage of folder permissions across app restarts</li>
 *   <li>Path-to-URI resolution for files in imported folders</li>
 *   <li>Permission reacquisition for existing URIs</li>
 *   <li>Validation of write permissions for URIs</li>
 *   <li>Folder path extraction from URIs</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class uses {@link ReentrantReadWriteLock} for thread-safe access to
 * SharedPreferences and URI mappings. Read operations can occur concurrently,
 * while write operations are mutually exclusive.</p>
 * 
 * <h3>Locking Strategy</h3>
 * <ul>
 *   <li><b>Read Lock:</b> Used for getAllFolderUris(), getFolderUri(), getFolderPathFromUri()</li>
 *   <li><b>Write Lock:</b> Used for storeFolderPermission(), removeFolderPermission(), clearAll()</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public final class StorageAccessHelper {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "StorageAccessHelper";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key prefix for storing folder URI to path mappings. */
    private static final String KEY_FOLDER_URI_PREFIX = "folder_uri_";
    
    /** Key prefix for storing path to URI mappings. */
    private static final String KEY_PATH_URI_PREFIX = "path_uri_";
    
    /** Set of known folder URI strings. */
    private static final String KEY_KNOWN_FOLDER_URIS = "known_folder_uris";
    
    /** Intent flags for taking URI permissions. */
    private static final int URI_PERMISSION_FLAGS = 
        Intent.FLAG_GRANT_READ_URI_PERMISSION | 
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
    
    /** Maximum number of folder URIs to store (safety limit). */
    private static final int MAX_FOLDER_URIS = 100;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance (volatile for thread-safe double-checked locking). */
    @Nullable
    private static volatile StorageAccessHelper sInstance;
    
    /** Application context. */
    @NonNull
    private final Context mContext;
    
    /** SharedPreferences for persistent storage. */
    @NonNull
    private final SharedPreferences mPreferences;
    
    /** Read/write lock for thread-safe operations. */
    @NonNull
    private final ReentrantReadWriteLock mRwLock = new ReentrantReadWriteLock();
    
    /** Read lock for concurrent read operations. */
    @NonNull
    private final ReentrantReadWriteLock.ReadLock mReadLock = mRwLock.readLock();
    
    /** Write lock for exclusive write operations. */
    @NonNull
    private final ReentrantReadWriteLock.WriteLock mWriteLock = mRwLock.writeLock();
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private StorageAccessHelper(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mPreferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    /**
     * Returns the singleton instance of StorageAccessHelper.
     * Thread-safe with double-checked locking.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static StorageAccessHelper getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (StorageAccessHelper.class) {
                if (sInstance == null) {
                    sInstance = new StorageAccessHelper(context);
                }
            }
        }
        return sInstance;
    }
    
    // ========================================================================
    // Folder Permission Management (Write Operations with Write Lock)
    // ========================================================================
    
    /**
     * Stores a folder URI permission and maps it to its file path.
     * Thread-safe: uses write lock for exclusive access.
     *
     * @param folderUri The folder URI from SAF
     * @param folderPath The absolute file path of the folder
     * @return True if the permission was stored successfully
     */
    public boolean storeFolderPermission(@NonNull final Uri folderUri, 
                                          @Nullable final String folderPath) {
        final String uriString = folderUri.toString();
        
        try {
            try {
                mContext.getContentResolver().takePersistableUriPermission(
                    folderUri, URI_PERMISSION_FLAGS);
            } catch (SecurityException exception) {
                Log.e(TAG, "Failed to take persistable URI permission", exception);
                return false;
            }
            
            mWriteLock.lock();
            try {
                final Set<String> knownUris = getKnownFolderUrisLocked();
                if (knownUris.size() >= MAX_FOLDER_URIS) {
                    Log.w(TAG, "Maximum folder URIS reached (" + MAX_FOLDER_URIS + "), cannot store more");
                    return false;
                }
                
                final SharedPreferences.Editor editor = mPreferences.edit();
                editor.putString(KEY_FOLDER_URI_PREFIX + uriString, folderPath);
                
                if (folderPath != null) {
                    editor.putString(KEY_PATH_URI_PREFIX + folderPath, uriString);
                }
                
                knownUris.add(uriString);
                editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
                editor.apply();
                
                Log.d(TAG, "Stored folder permission for: " + folderPath);
                return true;
                
            } finally {
                mWriteLock.unlock();
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to store folder permission", exception);
            return false;
        }
    }
    
    /**
     * Removes a folder permission mapping.
     * Thread-safe: uses write lock for exclusive access.
     *
     * @param folderUri The folder URI to remove
     */
    public void removeFolderPermission(@NonNull final Uri folderUri) {
        final String uriString = folderUri.toString();
        final String folderPath = getFolderPathFromUri(folderUri);
        
        mWriteLock.lock();
        try {
            final SharedPreferences.Editor editor = mPreferences.edit();
            editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
            if (folderPath != null) {
                editor.remove(KEY_PATH_URI_PREFIX + folderPath);
            }
            
            final Set<String> knownUris = getKnownFolderUrisLocked();
            knownUris.remove(uriString);
            editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
            editor.apply();
            
            Log.d(TAG, "Removed folder permission for: " + folderPath);
        } finally {
            mWriteLock.unlock();
        }
    }
    
    /**
     * Removes all stored folder permissions.
     * Thread-safe: uses write lock for exclusive access.
     */
    public void clearAll() {
        mWriteLock.lock();
        try {
            final SharedPreferences.Editor editor = mPreferences.edit();
            final Set<String> knownUris = getKnownFolderUrisLocked();
            
            for (String uriString : knownUris) {
                editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
                final String folderPath = getFolderPathFromUriLocked(Uri.parse(uriString));
                if (folderPath != null) {
                    editor.remove(KEY_PATH_URI_PREFIX + folderPath);
                }
            }
            
            editor.remove(KEY_KNOWN_FOLDER_URIS);
            editor.apply();
            Log.d(TAG, "Cleared all folder permissions");
        } finally {
            mWriteLock.unlock();
        }
    }
    
    /**
     * Gets the set of known folder URIs (must be called with read or write lock held).
     */
    @NonNull
    private Set<String> getKnownFolderUrisLocked() {
        final Set<String> savedUris = mPreferences.getStringSet(KEY_KNOWN_FOLDER_URIS, null);
        final Set<String> result = new HashSet<String>();
        if (savedUris != null) {
            result.addAll(savedUris);
        }
        return result;
    }
    
    /**
     * Gets all stored folder URIs (public version).
     * Thread-safe: uses read lock for concurrent access.
     *
     * @return Set of folder URI strings
     */
    @NonNull
    public Set<String> getAllFolderUris() {
        mReadLock.lock();
        try {
            return getKnownFolderUrisLocked();
        } finally {
            mReadLock.unlock();
        }
    }
    
    /**
     * Gets the folder URI for a given file path.
     * Thread-safe: uses read lock for concurrent access.
     *
     * @param filePath The absolute file path
     * @return The folder URI, or null if not found
     */
    @Nullable
    public Uri getFolderUri(@NonNull final String filePath) {
        mReadLock.lock();
        try {
            String bestMatch = null;
            String bestUri = null;
            
            final Map<String, ?> allEntries = mPreferences.getAll();
            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                final String key = entry.getKey();
                if (key.startsWith(KEY_PATH_URI_PREFIX) && entry.getValue() instanceof String) {
                    final String storedPath = key.substring(KEY_PATH_URI_PREFIX.length());
                    if (filePath.startsWith(storedPath) && (bestMatch == null || storedPath.length() > bestMatch.length())) {
                        bestMatch = storedPath;
                        bestUri = (String) entry.getValue();
                    }
                }
            }
            
            return bestUri != null ? Uri.parse(bestUri) : null;
        } finally {
            mReadLock.unlock();
        }
    }
    
    /**
     * Gets a writeable URI for a file.
     * Thread-safe: uses read lock for concurrent access.
     *
     * @param filePath The absolute file path
     * @return The document URI, or null if not found
     */
    @Nullable
    public Uri getWriteableUriForFile(@NonNull final String filePath) {
        final Uri folderUri = getFolderUri(filePath);
        if (folderUri == null) {
            Log.d(TAG, "No folder URI found for: " + filePath);
            return null;
        }
        
        final String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            Log.d(TAG, "Could not extract folder path from URI: " + folderUri);
            return null;
        }
        
        final String relativePath = filePath.substring(folderPath.length() + 1);
        return getDocumentUriForFile(folderUri, relativePath);
    }
    
    /**
     * Gets a document URI for a file within a folder.
     *
     * @param folderUri The parent folder URI
     * @param relativePath The relative path from the folder
     * @return The document URI for the file
     */
    @Nullable
    private Uri getDocumentUriForFile(@NonNull final Uri folderUri, 
                                      @NonNull final String relativePath) {
        try {
            DocumentFile current = DocumentFile.fromTreeUri(mContext, folderUri);
            if (current == null || !current.canRead()) {
                Log.w(TAG, "Cannot read folder: " + folderUri);
                return null;
            }
            
            final String[] parts = relativePath.split("/");
            for (String part : parts) {
                final DocumentFile child = current.findFile(part);
                if (child == null) {
                    Log.w(TAG, "File not found: " + part + " in path " + relativePath);
                    return null;
                }
                current = child;
            }
            
            return current.getUri();
            
        } catch (Exception exception) {
            Log.e(TAG, "Failed to get document URI", exception);
            return null;
        }
    }
    
    /**
     * Takes persistable permission for a file URI.
     * Thread-safe: this method only performs system calls, no shared state.
     *
     * @param fileUri The file URI
     * @return True if permission was taken
     */
    public boolean takeFilePermission(@NonNull final Uri fileUri) {
        try {
            mContext.getContentResolver().takePersistableUriPermission(fileUri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Took persistable permission for: " + fileUri);
            return true;
        } catch (SecurityException exception) {
            Log.e(TAG, "Failed to take persistable permission", exception);
            return false;
        }
    }
    
    /**
     * Reacquires permission for a URI.
     * Thread-safe: uses read lock for validation, writes only on permission refresh.
     *
     * @param uri The URI to reacquire permission for
     * @return True if permission was reacquired
     */
    public boolean reacquirePermission(@NonNull final Uri uri) {
        try {
            try {
                final DocumentFile document = DocumentFile.fromSingleUri(mContext, uri);
                if (document != null && document.canWrite()) {
                    Log.d(TAG, "Already have write permission for: " + uri);
                    return true;
                }
            } catch (Exception exception) {
                Log.w(TAG, "Permission check failed, attempting to reacquire", exception);
            }
            
            mContext.getContentResolver().takePersistableUriPermission(uri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Reacquired permission for: " + uri);
            return true;
            
        } catch (SecurityException exception) {
            Log.e(TAG, "Failed to reacquire permission", exception);
            return false;
        }
    }
    
    /**
     * Validates that write permission is available for a URI.
     * Thread-safe: read-only operation.
     *
     * @param uri The URI to validate
     * @return True if write permission is available
     */
    public boolean validatePermission(@NonNull final Uri uri) {
        try {
            final DocumentFile document = DocumentFile.fromSingleUri(mContext, uri);
            final boolean hasPermission = document != null && document.canWrite();
            Log.d(TAG, "Permission validation for " + uri + ": " + hasPermission);
            return hasPermission;
        } catch (Exception exception) {
            Log.w(TAG, "Permission validation failed", exception);
            return false;
        }
    }
    
    // ========================================================================
    // URI Path Extraction Methods (Read-Only, Thread-Safe)
    // ========================================================================
    
    /**
     * Extracts the file system path from a folder URI.
     * Thread-safe: uses read lock for stored mapping, then fallback to parsing.
     *
     * @param uri The folder URI (can be null)
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    public String getFolderPathFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }
        
        mReadLock.lock();
        try {
            return getFolderPathFromUriLocked(uri);
        } finally {
            mReadLock.unlock();
        }
    }
    
    /**
     * Extracts the file system path from a folder URI (must be called with read or write lock held).
     *
     * @param uri The folder URI (can be null)
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUriLocked(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }
        
        final String storedPath = mPreferences.getString(KEY_FOLDER_URI_PREFIX + uri.toString(), null);
        if (storedPath != null) {
            return storedPath;
        }
        
        final String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/");
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                }
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to extract folder path", exception);
                return null;
            }
        }
        return null;
    }
    
    /**
     * Gets the display name of a folder from its URI.
     * Thread-safe: read-only operation with proper cursor cleanup.
     *
     * @param uri The folder URI (can be null)
     * @return The folder name, or null if extraction fails
     */
    @Nullable
    public String getFolderNameFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }
        
        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }
        
        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
    
    /**
     * Gets the storage type indicator for a folder URI.
     * Thread-safe: pure function, no shared state.
     *
     * @param uriString The folder URI string
     * @return "[Internal]" for internal storage, "[SD Card]" for external storage, or empty string
     */
    @NonNull
    public String getStorageType(@NonNull final String uriString) {
        final String uriLower = uriString.toLowerCase();
        
        if (uriLower.contains("primary") || uriLower.contains("emulated")) {
            return " [Internal]";
        } else if (uriLower.contains("external") || uriLower.contains("sdcard") || 
                   uriLower.contains("extsdcard") || uriLower.contains("extsd") || 
                   uriLower.matches(".*[0-9a-f]{4}-[0-9a-f]{4}.*")) {
            return " [SD Card]";
        }
        
        return "";
    }
    
    // ========================================================================
    // Scanning Methods (Read-Only, Thread-Safe)
    // ========================================================================
    
    /**
     * Scans a folder for audio files using DocumentFile.
     * Thread-safe: read-only operation with local state only.
     *
     * @param folderUri The folder URI to scan
     * @return List of DocumentFile objects representing audio files
     */
    @NonNull
    public List<DocumentFile> scanFolderForAudioFiles(@NonNull final Uri folderUri) {
        final List<DocumentFile> audioFiles = new ArrayList<DocumentFile>();
        
        try {
            final DocumentFile folder = DocumentFile.fromTreeUri(mContext, folderUri);
            if (folder == null || !folder.exists() || !folder.canRead()) {
                Log.w(TAG, "Cannot read folder: " + folderUri);
                return audioFiles;
            }
            
            scanDocumentFileForAudioFiles(folder, audioFiles);
            
        } catch (Exception exception) {
            Log.e(TAG, "Failed to scan folder", exception);
        }
        
        return audioFiles;
    }
    
    /**
     * Recursively scans a DocumentFile for audio files.
     * Thread-safe: recursive method with local state only.
     *
     * @param document The DocumentFile to scan
     * @param results The list to add audio files to
     */
    private void scanDocumentFileForAudioFiles(@NonNull final DocumentFile document, 
                                               @NonNull final List<DocumentFile> results) {
        if (document.isFile() && isAudioFile(document.getName())) {
            results.add(document);
        } else if (document.isDirectory()) {
            final DocumentFile[] children = document.listFiles();
            for (DocumentFile child : children) {
                if (child != null) {
                    scanDocumentFileForAudioFiles(child, results);
                }
            }
        }
    }
    
    /**
     * Checks if a filename indicates an audio file.
     * Thread-safe: pure function, no shared state.
     *
     * @param name The filename (can be null)
     * @return True if the file is an audio file
     */
    private boolean isAudioFile(@Nullable final String name) {
        if (name == null) {
            return false;
        }
        final String lower = name.toLowerCase();
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || 
               lower.endsWith(".ogg") || lower.endsWith(".m4a") || 
               lower.endsWith(".mp4") || lower.endsWith(".wav") ||
               lower.endsWith(".aac") || lower.endsWith(".wma");
    }
    
    // ========================================================================
    // Utility Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Returns the number of stored folder permissions.
     * Thread-safe: uses read lock for concurrent access.
     *
     * @return The count of stored folders
     */
    public int getStoredFolderCount() {
        mReadLock.lock();
        try {
            return getKnownFolderUrisLocked().size();
        } finally {
            mReadLock.unlock();
        }
    }
    
    /**
     * Checks if a folder URI is already stored.
     * Thread-safe: uses read lock for concurrent access.
     *
     * @param folderUri The folder URI to check
     * @return True if the folder is already stored
     */
    public boolean isFolderStored(@NonNull final Uri folderUri) {
        final String uriString = folderUri.toString();
        mReadLock.lock();
        try {
            return mPreferences.contains(KEY_FOLDER_URI_PREFIX + uriString);
        } finally {
            mReadLock.unlock();
        }
    }
    
    /**
     * Gets debug information about stored permissions.
     * Thread-safe: uses read lock for concurrent access.
     *
     * @return Debug string
     */
    @NonNull
    public String getDebugInfo() {
        final StringBuilder builder = new StringBuilder();
        builder.append("StorageAccessHelper Debug Info:\n");
        builder.append("  Stored folder URIs: ").append(getStoredFolderCount()).append("\n");
        
        mReadLock.lock();
        try {
            final Set<String> knownUris = getKnownFolderUrisLocked();
            for (String uriString : knownUris) {
                final String folderPath = mPreferences.getString(KEY_FOLDER_URI_PREFIX + uriString, null);
                builder.append("    - URI: ").append(uriString).append("\n");
                builder.append("      Path: ").append(folderPath).append("\n");
            }
        } finally {
            mReadLock.unlock();
        }
        
        return builder.toString();
    }
}