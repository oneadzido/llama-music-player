package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Manages Storage Access Framework permissions, document URIs, and
 * folder-to-URI mappings.
 *
 * <p>Stores the folder permissions the user has granted through the
 * system folder picker, resolves file paths to their writeable document
 * URIs, reacquires permissions on URIs that already exist, and extracts
 * a folder's display name and filesystem path from a tree URI.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Access to the shared preference store and the URI mappings is
 * guarded by a {@link ReentrantReadWriteLock}. Read operations
 * ({@link #getAllFolderUris()}, {@link #getFolderUri(String)},
 * {@link #getFolderPathFromUri(Uri)}) acquire the read lock, so they can
 * run concurrently. Write operations
 * ({@link #storeFolderPermission(Uri, String)},
 * {@link #removeFolderPermission(Uri)}, {@link #clearAll()}) acquire the
 * write lock and are mutually exclusive with every other operation.</p>
 *
 * @see DocumentFile
 * @see ReentrantReadWriteLock
 *
 * @author Richard Korbla Adzido
 * @version 1.1.7
 * @since 1.0
 */
public final class StorageAccessHelper {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for this class. */
    private static final String TAG = "StorageAccessHelper";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key prefix used to store folder URI to path mappings. */
    private static final String KEY_FOLDER_URI_PREFIX = "folder_uri_";

    /** Key prefix used to store path to URI mappings. */
    private static final String KEY_PATH_URI_PREFIX = "path_uri_";

    /** Shared preferences key holding the set of known folder URI strings. */
    private static final String KEY_KNOWN_FOLDER_URIS = "known_folder_uris";

    /** Intent flags used when taking a persistable URI permission. */
    private static final int URI_PERMISSION_FLAGS =
        Intent.FLAG_GRANT_READ_URI_PERMISSION |
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION;

    /** Maximum number of folder URI mappings stored at once. */
    private static final int MAX_FOLDER_URIS = 100;

    // ========================================================================
    // Singleton
    // ========================================================================

    /** Singleton instance. */
    @Nullable
    private static volatile StorageAccessHelper sInstance;

    /** Application context. */
    @NonNull
    private final Context mContext;

    /** Shared preference store that holds the URI mappings. */
    @NonNull
    private final SharedPreferences mPreferences;

    /** Lock that guards every read and write against the mappings. */
    @NonNull
    private final ReentrantReadWriteLock mReadWriteLock = new ReentrantReadWriteLock();

    /** Read lock. */
    @NonNull
    private final ReentrantReadWriteLock.ReadLock mReadLock = mReadWriteLock.readLock();

    /** Write lock. */
    @NonNull
    private final ReentrantReadWriteLock.WriteLock mWriteLock = mReadWriteLock.writeLock();

    /**
     * Constructs the singleton.
     *
     * @param context A context; the application context is retained
     */
    private StorageAccessHelper(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mPreferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Returns the singleton instance, creating it on first call.
     *
     * <p>Safe for concurrent use through double-checked locking.</p>
     *
     * @param context A context used only when the instance is created
     * @return The singleton instance
     */
    @NonNull
    public static StorageAccessHelper getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (StorageAccessHelper.class) {
                if (sInstance == null) {
                    sInstance = new StorageAccessHelper(context);
                }
            }
        }
        return sInstance;
    }

    // ========================================================================
    // Folder Permission Management
    // ========================================================================

    /**
     * Persists the given folder URI permission and maps it to its
     * filesystem path.
     *
     * <p>Takes a persistable URI permission from the content resolver,
     * then records the URI and path in the preference store. When the
     * store already holds the maximum number of folder URIs, the request
     * is refused.</p>
     *
     * @param folderUri Folder URI granted by the system picker
     * @param folderPath Filesystem path the URI maps to, or null
     * @return True when the permission was stored
     */
    public boolean storeFolderPermission(@NonNull final Uri folderUri,
                                          @Nullable final String folderPath) {
        final String uriString = folderUri.toString();

        try {
            try {
                mContext.getContentResolver().takePersistableUriPermission(
                    folderUri, URI_PERMISSION_FLAGS);
            } catch (SecurityException exception) {
                Log.e(TAG, "Failed to take persistable URI permission", exception);
                return false;
            }

            mWriteLock.lock();
            try {
                final Set<String> knownUris = getKnownFolderUrisLocked();
                if (knownUris.size() >= MAX_FOLDER_URIS) {
                    Log.w(TAG, "Maximum folder URIS reached (" + MAX_FOLDER_URIS
                        + "), cannot store more");
                    return false;
                }

                final SharedPreferences.Editor editor = mPreferences.edit();
                editor.putString(KEY_FOLDER_URI_PREFIX + uriString, folderPath);

                if (folderPath != null) {
                    editor.putString(KEY_PATH_URI_PREFIX + folderPath, uriString);
                }

                knownUris.add(uriString);
                editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
                editor.apply();

                Log.d(TAG, "Stored folder permission for: " + folderPath);
                return true;

            } finally {
                mWriteLock.unlock();
            }
        } catch (Exception exception) {
            Log.e(TAG, "Failed to store folder permission", exception);
            return false;
        }
    }

    /**
     * Removes the mapping for the given folder URI.
     *
     * @param folderUri Folder URI to remove
     */
    public void removeFolderPermission(@NonNull final Uri folderUri) {
        final String uriString = folderUri.toString();
        final String folderPath = getFolderPathFromUri(folderUri);

        mWriteLock.lock();
        try {
            final SharedPreferences.Editor editor = mPreferences.edit();
            editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
            if (folderPath != null) {
                editor.remove(KEY_PATH_URI_PREFIX + folderPath);
            }

            final Set<String> knownUris = getKnownFolderUrisLocked();
            knownUris.remove(uriString);
            editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
            editor.apply();

            Log.d(TAG, "Removed folder permission for: " + folderPath);
        } finally {
            mWriteLock.unlock();
        }
    }

    /**
     * Removes every stored folder URI mapping.
     */
    public void clearAll() {
        mWriteLock.lock();
        try {
            final SharedPreferences.Editor editor = mPreferences.edit();
            final Set<String> knownUris = getKnownFolderUrisLocked();

            for (String uriString : knownUris) {
                editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
                final String folderPath = getFolderPathFromUriLocked(Uri.parse(uriString));
                if (folderPath != null) {
                    editor.remove(KEY_PATH_URI_PREFIX + folderPath);
                }
            }

            editor.remove(KEY_KNOWN_FOLDER_URIS);
            editor.apply();
            Log.d(TAG, "Cleared all folder permissions");
        } finally {
            mWriteLock.unlock();
        }
    }

    /**
     * Returns the set of known folder URI strings.
     *
     * <p>Callers must hold the read or write lock.</p>
     *
     * @return A copy of the persisted set, or an empty set when none is
     *         stored
     */
    @NonNull
    private Set<String> getKnownFolderUrisLocked() {
        final Set<String> savedUris = mPreferences.getStringSet(
            KEY_KNOWN_FOLDER_URIS, null);
        final Set<String> result = new HashSet<String>();
        if (savedUris != null) {
            result.addAll(savedUris);
        }
        return result;
    }

    /**
     * Returns a copy of every stored folder URI.
     *
     * @return A set containing every known folder URI
     */
    @NonNull
    public Set<String> getAllFolderUris() {
        mReadLock.lock();
        try {
            return getKnownFolderUrisLocked();
        } finally {
            mReadLock.unlock();
        }
    }

    /**
     * Returns the folder URI whose path is the longest prefix of the
     * given file path.
     *
     * @param filePath Absolute filesystem path
     * @return The matching folder URI, or null when no mapping applies
     */
    @Nullable
    public Uri getFolderUri(@NonNull final String filePath) {
        mReadLock.lock();
        try {
            String bestMatch = null;
            String bestUri = null;

            final Map<String, ?> allEntries = mPreferences.getAll();
            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                final String key = entry.getKey();
                if (key.startsWith(KEY_PATH_URI_PREFIX)
                        && entry.getValue() instanceof String) {
                    final String storedPath = key.substring(KEY_PATH_URI_PREFIX.length());
                    if (filePath.startsWith(storedPath)
                            && (bestMatch == null || storedPath.length() > bestMatch.length())) {
                        bestMatch = storedPath;
                        bestUri = (String) entry.getValue();
                    }
                }
            }

            return bestUri != null ? Uri.parse(bestUri) : null;
        } finally {
            mReadLock.unlock();
        }
    }

    /**
     * Returns the document URI for the file at the given path, resolved
     * through the folder mapping that covers it.
     *
     * @param filePath Absolute filesystem path
     * @return The document URI, or null when no mapping applies or the
     *         file cannot be found
     */
    @Nullable
    public Uri getWriteableUriForFile(@NonNull final String filePath) {
        final Uri folderUri = getFolderUri(filePath);
        if (folderUri == null) {
            Log.d(TAG, "No folder URI found for: " + filePath);
            return null;
        }

        final String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            Log.d(TAG, "Could not extract folder path from URI: " + folderUri);
            return null;
        }

        final String relativePath = filePath.substring(folderPath.length() + 1);
        return getDocumentUriForFile(folderUri, relativePath);
    }

    /**
     * Returns the document URI for the file at the given path within the
     * given folder.
     *
     * @param folderUri Parent folder URI
     * @param relativePath Path of the file relative to the folder
     * @return The document URI, or null when the file cannot be resolved
     */
    @Nullable
    private Uri getDocumentUriForFile(@NonNull final Uri folderUri,
                                      @NonNull final String relativePath) {
        try {
            DocumentFile current = DocumentFile.fromTreeUri(mContext, folderUri);
            if (current == null || !current.canRead()) {
                Log.w(TAG, "Cannot read folder: " + folderUri);
                return null;
            }

            final String[] parts = relativePath.split("/");
            for (String part : parts) {
                final DocumentFile child = current.findFile(part);
                if (child == null) {
                    Log.w(TAG, "File not found: " + part + " in path " + relativePath);
                    return null;
                }
                current = child;
            }

            return current.getUri();

        } catch (Exception exception) {
            Log.e(TAG, "Failed to get document URI", exception);
            return null;
        }
    }

    /**
     * Takes a persistable URI permission for the given file.
     *
     * @param fileUri File URI granted by the system picker
     * @return True when the permission was taken
     */
    public boolean takeFilePermission(@NonNull final Uri fileUri) {
        try {
            mContext.getContentResolver().takePersistableUriPermission(
                fileUri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Took persistable permission for: " + fileUri);
            return true;
        } catch (SecurityException exception) {
            Log.e(TAG, "Failed to take persistable permission", exception);
            return false;
        }
    }

    /**
     * Ensures the given URI has write permission, taking a persistable
     * permission when needed.
     *
     * @param uri URI to check or reacquire
     * @return True when write permission is available
     */
    public boolean reacquirePermission(@NonNull final Uri uri) {
        try {
            try {
                final DocumentFile document = DocumentFile.fromSingleUri(mContext, uri);
                if (document != null && document.canWrite()) {
                    Log.d(TAG, "Already have write permission for: " + uri);
                    return true;
                }
            } catch (Exception exception) {
                Log.w(TAG, "Permission check failed, attempting to reacquire", exception);
            }

            mContext.getContentResolver().takePersistableUriPermission(
                uri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Reacquired permission for: " + uri);
            return true;

        } catch (SecurityException exception) {
            Log.e(TAG, "Failed to reacquire permission", exception);
            return false;
        }
    }

    /**
     * Returns whether the given URI currently grants write permission.
     *
     * @param uri URI to test
     * @return True when write permission is available
     */
    public boolean validatePermission(@NonNull final Uri uri) {
        try {
            final DocumentFile document = DocumentFile.fromSingleUri(mContext, uri);
            final boolean hasPermission = document != null && document.canWrite();
            Log.d(TAG, "Permission validation for " + uri + ": " + hasPermission);
            return hasPermission;
        } catch (Exception exception) {
            Log.w(TAG, "Permission validation failed", exception);
            return false;
        }
    }

    // ========================================================================
    // URI Path Extraction Methods
    // ========================================================================

    /**
     * Returns the filesystem path stored for the given folder URI, or
     * extracts it from the URI when no mapping is stored.
     *
     * @param uri Folder URI to inspect, or null
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    public String getFolderPathFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }

        mReadLock.lock();
        try {
            return getFolderPathFromUriLocked(uri);
        } finally {
            mReadLock.unlock();
        }
    }

    /**
     * Returns the filesystem path stored for the given folder URI, or
     * extracts it from the URI when no mapping is stored.
     *
     * <p>Callers must hold the read or write lock.</p>
     *
     * @param uri Folder URI to inspect, or null
     * @return The filesystem path, or null when it cannot be determined
     */
    @Nullable
    private String getFolderPathFromUriLocked(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }

        final String storedPath = mPreferences.getString(
            KEY_FOLDER_URI_PREFIX + uri.toString(), null);
        if (storedPath != null) {
            return storedPath;
        }

        final String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int startIndex = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(startIndex);
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/");
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                }
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception exception) {
                Log.e(TAG, "Failed to extract folder path", exception);
                return null;
            }
        }
        return null;
    }

    /**
     * Returns the cleaned display name of the given folder URI.
     *
     * @param uri Folder URI to inspect, or null
     * @return The cleaned folder name, or null when it cannot be
     *         determined
     */
    @Nullable
    public String getFolderNameFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }

        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex);
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "getFolderName error", exception);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception);
                }
            }
        }

        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }

        return name != null ? CharacterMapper.cleanString(name) : null;
    }

    /**
     * Returns a label identifying the storage type of the given folder
     * URI, such as {@code " [Internal]"} or {@code " [SD Card]"}.
     *
     * @param uriString Folder URI string to inspect
     * @return The storage-type label, or an empty string when the type is
     *         unknown
     */
    @NonNull
    public String getStorageType(@NonNull final String uriString) {
        final String uriLower = uriString.toLowerCase();

        if (uriLower.contains("primary") || uriLower.contains("emulated")) {
            return " [Internal]";
        } else if (uriLower.contains("external") || uriLower.contains("sdcard")
                || uriLower.contains("extsdcard") || uriLower.contains("extsd")
                || uriLower.matches(".*[0-9a-f]{4}-[0-9a-f]{4}.*")) {
            return " [SD Card]";
        }

        return "";
    }

    // ========================================================================
    // Scanning Methods
    // ========================================================================

    /**
     * Recursively scans the given folder URI for audio files.
     *
     * @param folderUri Folder URI to scan
     * @return Every audio file found in the folder and its subfolders
     */
    @NonNull
    public List<DocumentFile> scanFolderForAudioFiles(@NonNull final Uri folderUri) {
        final List<DocumentFile> audioFiles = new ArrayList<DocumentFile>();

        try {
            final DocumentFile folder = DocumentFile.fromTreeUri(mContext, folderUri);
            if (folder == null || !folder.exists() || !folder.canRead()) {
                Log.w(TAG, "Cannot read folder: " + folderUri);
                return audioFiles;
            }

            scanDocumentFileForAudioFiles(folder, audioFiles);

        } catch (Exception exception) {
            Log.e(TAG, "Failed to scan folder", exception);
        }

        return audioFiles;
    }

    /**
     * Recursively walks the given document tree and adds every audio file
     * to the given list.
     *
     * @param document Document to inspect
     * @param results List that receives the audio files
     */
    private void scanDocumentFileForAudioFiles(@NonNull final DocumentFile document,
                                               @NonNull final List<DocumentFile> results) {
        if (document.isFile() && isAudioFile(document.getName())) {
            results.add(document);
        } else if (document.isDirectory()) {
            final DocumentFile[] children = document.listFiles();
            for (DocumentFile child : children) {
                if (child != null) {
                    scanDocumentFileForAudioFiles(child, results);
                }
            }
        }
    }

    /**
     * Returns whether the given filename has a recognised audio
     * extension.
     *
     * @param name Filename to test, or null
     * @return True when the filename has an audio extension
     */
    private boolean isAudioFile(@Nullable final String name) {
        if (name == null) {
            return false;
        }
        final String lower = name.toLowerCase();
        return lower.endsWith(".mp3") || lower.endsWith(".flac")
            || lower.endsWith(".ogg") || lower.endsWith(".m4a")
            || lower.endsWith(".mp4") || lower.endsWith(".wav")
            || lower.endsWith(".aac") || lower.endsWith(".wma");
    }

    // ========================================================================
    // Utility Methods
    // ========================================================================

    /**
     * Returns the number of stored folder permissions.
     *
     * @return The number of stored folder URIs
     */
    public int getStoredFolderCount() {
        mReadLock.lock();
        try {
            return getKnownFolderUrisLocked().size();
        } finally {
            mReadLock.unlock();
        }
    }

    /**
     * Returns whether a mapping exists for the given folder URI.
     *
     * @param folderUri Folder URI to test
     * @return True when the folder is already stored
     */
    public boolean isFolderStored(@NonNull final Uri folderUri) {
        final String uriString = folderUri.toString();
        mReadLock.lock();
        try {
            return mPreferences.contains(KEY_FOLDER_URI_PREFIX + uriString);
        } finally {
            mReadLock.unlock();
        }
    }

    /**
     * Returns a human-readable snapshot of the stored permissions.
     *
     * @return A multi-line string listing every stored folder URI and its
     *         path
     */
    @NonNull
    public String getDebugInfo() {
        final StringBuilder builder = new StringBuilder();
        builder.append("StorageAccessHelper Debug Info:\n");
        builder.append("  Stored folder URIs: ").append(getStoredFolderCount()).append("\n");

        mReadLock.lock();
        try {
            final Set<String> knownUris = getKnownFolderUrisLocked();
            for (String uriString : knownUris) {
                final String folderPath = mPreferences.getString(
                    KEY_FOLDER_URI_PREFIX + uriString, null);
                builder.append("    - URI: ").append(uriString).append("\n");
                builder.append("      Path: ").append(folderPath).append("\n");
            }
        } finally {
            mReadLock.unlock();
        }

        return builder.toString();
    }
}