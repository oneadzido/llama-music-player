
11. Hindi (values-hi/strings.xml)

```xml
```

12. Arabic (values-ar/strings.xml)

```xml
```

13. Turkish (values-tr/strings.xml)

```xml
```

14. Indonesian (values-in/strings.xml)

```xml
```

15. Dutch (values-nl/strings.xml)

```xml
```

16. Polish (values-pl/strings.xml)

```xml
```

(Note: Depending on your project setup, the Chinese folder might be values-zh-rCN for Simplified Chinese or just values-zh, but the string content remains the same).