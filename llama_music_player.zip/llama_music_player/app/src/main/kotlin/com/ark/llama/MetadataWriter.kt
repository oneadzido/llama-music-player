// MetadataWriter.kt
package com.ark.llama

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Writes ID3 tags and album art to audio files, with backup and
 * restore around every write.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
object MetadataWriter {

    private const val TAG = "MetadataWriter"
    private const val COPY_BUFFER_SIZE = 8192
    private const val MAX_ALBUM_ART_BYTES = 1024 * 1024
    private const val DEFAULT_EXTENSION = "mp3"

    private val sWriteLock = Any()

    // ========================================================================
    // WriteResult
    // ========================================================================

    class WriteResult private constructor(
        @JvmField val status: Status,
        @JvmField val errorMessage: String?
    ) {

        enum class Status {
            WRITTEN,
            PERMISSION_DENIED,
            COPY_FAILED,
            BACKUP_FAILED,
            WRITE_FAILED_RESTORED,
            VERIFY_FAILED_RESTORED,
            COPY_BACK_FAILED_RESTORED,
            FAILED
        }

        fun isSuccess(): Boolean = status == Status.WRITTEN

        fun isFileUnchanged(): Boolean = when (status) {
            Status.PERMISSION_DENIED,
            Status.COPY_FAILED,
            Status.BACKUP_FAILED,
            Status.WRITE_FAILED_RESTORED,
            Status.VERIFY_FAILED_RESTORED,
            Status.COPY_BACK_FAILED_RESTORED -> true
            Status.WRITTEN,
            Status.FAILED -> false
        }

        override fun toString(): String =
            "WriteResult{status=$status, errorMessage='$errorMessage'}"

        companion object {
            @JvmStatic
            fun written(): WriteResult = WriteResult(Status.WRITTEN, null)

            @JvmStatic
            fun failed(status: Status, errorMessage: String): WriteResult {
                require(status != Status.WRITTEN) {
                    "Use written() to construct a WRITTEN result"
                }
                return WriteResult(status, errorMessage)
            }
        }
    }

    // ========================================================================
    // UpdateBundle
    // ========================================================================

    class UpdateBundle {
        @JvmField var title: String? = null
        @JvmField var artist: String? = null
        @JvmField var album: String? = null
        @JvmField var year: String? = null
        @JvmField var genre: String? = null
        @JvmField var trackNumber: String? = null
        @JvmField var lyrics: String? = null
        @JvmField var albumArt: ByteArray? = null

        fun hasChanges(): Boolean =
            title != null || artist != null || album != null ||
                year != null || genre != null || trackNumber != null ||
                lyrics != null || albumArt != null

        override fun toString(): String =
            "UpdateBundle{" +
                "title=${if (title != null) "'$title'" else "null"}, " +
                "artist=${if (artist != null) "'$artist'" else "null"}, " +
                "album=${if (album != null) "'$album'" else "null"}, " +
                "year=${if (year != null) "'$year'" else "null"}, " +
                "genre=${if (genre != null) "'$genre'" else "null"}, " +
                "trackNumber=${if (trackNumber != null) "'$trackNumber'" else "null"}, " +
                "lyrics=${if (lyrics != null) "[set]" else "null"}, " +
                "albumArt=${albumArt?.let { "${it.size} bytes" } ?: "null"}}"
    }

    // ========================================================================
    // Public write
    // ========================================================================

    @JvmStatic
    fun writeMetadataToUri(
        context: Context,
        documentUri: Uri,
        update: UpdateBundle
    ): WriteResult {
        synchronized(sWriteLock) {
            var tempFile: File? = null
            var backupFile: File? = null

            try {
                Log.d(TAG, "Starting metadata write to URI: $documentUri")
                Log.d(TAG, "Update bundle: $update")

                val document = DocumentFile.fromSingleUri(context, documentUri)
                if (document == null || !document.canWrite()) {
                    Log.e(TAG, "No write permission for URI: $documentUri")
                    return WriteResult.failed(
                        WriteResult.Status.PERMISSION_DENIED,
                        "No write permission for file"
                    )
                }

                tempFile = copyUriToCache(context, documentUri)
                if (tempFile == null) {
                    Log.e(TAG, "Failed to copy file from URI")
                    return WriteResult.failed(
                        WriteResult.Status.COPY_FAILED,
                        "Failed to copy file from URI"
                    )
                }

                Log.d(TAG, "Copied to temp file: ${tempFile.absolutePath} " +
                    "(${tempFile.length()} bytes)")

                backupFile = File(
                    context.cacheDir,
                    "backup_${SystemClock.elapsedRealtime()}_${tempFile.name}"
                )
                if (!copyFile(tempFile, backupFile)) {
                    deleteFileSafely(tempFile)
                    return WriteResult.failed(
                        WriteResult.Status.BACKUP_FAILED,
                        "Failed to create backup"
                    )
                }

                Log.d(TAG, "Backup created: ${backupFile.absolutePath}")

                if (!writeMetadataToFileInternal(tempFile, update)) {
                    Log.e(TAG, "Failed to write metadata, restoring from backup")
                    restoreFromBackup(tempFile, backupFile)
                    deleteFileSafely(tempFile)
                    deleteFileSafely(backupFile)
                    return WriteResult.failed(
                        WriteResult.Status.WRITE_FAILED_RESTORED,
                        "Failed to write metadata"
                    )
                }

                Log.d(TAG, "Metadata written, temp file size: ${tempFile.length()} bytes")

                if (!verifyAudioFile(tempFile)) {
                    Log.e(TAG, "Verification failed, restoring from backup")
                    restoreFromBackup(tempFile, backupFile)
                    deleteFileSafely(tempFile)
                    deleteFileSafely(backupFile)
                    return WriteResult.failed(
                        WriteResult.Status.VERIFY_FAILED_RESTORED,
                        "Verification failed"
                    )
                }

                if (!copyCacheToUri(context, tempFile, documentUri)) {
                    Log.e(TAG, "Failed to write back to original URI, restoring from backup")
                    restoreFromBackup(tempFile, backupFile)
                    copyCacheToUri(context, tempFile, documentUri)
                    deleteFileSafely(tempFile)
                    deleteFileSafely(backupFile)
                    return WriteResult.failed(
                        WriteResult.Status.COPY_BACK_FAILED_RESTORED,
                        "Failed to write back to original"
                    )
                }

                deleteFileSafely(tempFile)
                deleteFileSafely(backupFile)
                Log.d(TAG, "Successfully wrote metadata to: $documentUri")
                return WriteResult.written()
            } catch (exception: Exception) {
                Log.e(TAG, "Unexpected error during metadata write", exception)
                if (backupFile != null && backupFile.exists() && tempFile != null) {
                    restoreFromBackup(tempFile, backupFile)
                    copyCacheToUri(context, tempFile, documentUri)
                }
                deleteFileSafely(tempFile)
                deleteFileSafely(backupFile)
                val errorMessage = exception.message ?: "Unknown error"
                return WriteResult.failed(WriteResult.Status.FAILED, errorMessage)
            }
        }
    }

    // ========================================================================
    // Internal write helpers
    // ========================================================================

    private fun writeMetadataToFileInternal(
        file: File,
        update: UpdateBundle
    ): Boolean {
        try {
            Log.d(TAG, "=== Starting metadata write ===")
            Log.d(TAG, "File: ${file.absolutePath}")

            val audioFile = AudioFileIO.read(file)
            if (audioFile == null) {
                Log.e(TAG, "AudioFileIO.read returned null")
                return false
            }

            var tag: Tag? = audioFile.tag
            if (tag == null) {
                Log.d(TAG, "No existing tag, creating default tag")
                tag = audioFile.createDefaultTag()
                audioFile.setTag(tag)
            }

            Log.d(TAG, "Tag class: ${tag.javaClass.name}")

            setOrDeleteField(tag, FieldKey.TITLE, update.title)
            setOrDeleteField(tag, FieldKey.ARTIST, update.artist)
            setOrDeleteField(tag, FieldKey.ALBUM, update.album)
            setOrDeleteField(tag, FieldKey.YEAR, update.year)
            setOrDeleteField(tag, FieldKey.GENRE, update.genre)
            setOrDeleteField(tag, FieldKey.TRACK, update.trackNumber)
            setOrDeleteField(tag, FieldKey.LYRICS, update.lyrics)

            if (update.albumArt != null) {
                try {
                    tag.deleteArtworkField()
                    Log.d(TAG, "Deleted existing artwork")
                } catch (exception: Exception) {
                    Log.w(TAG, "Failed to delete existing artwork: ${exception.message}")
                }

                val artBytes = update.albumArt
                if (artBytes != null && artBytes.isNotEmpty()) {
                    val artwork = createArtworkFromBytes(artBytes, file.parentFile)
                    if (artwork != null) {
                        try {
                            tag.setField(artwork)
                            Log.d(TAG, "Album art set successfully")
                        } catch (exception: Exception) {
                            Log.e(TAG, "Failed to set album art: ${exception.message}")
                            return false
                        }
                    } else {
                        Log.e(TAG, "Could not create Artwork object")
                        return false
                    }
                } else {
                    Log.d(TAG, "Album art deleted")
                }
            } else {
                Log.d(TAG, "Album art unchanged")
            }

            audioFile.commit()
            Log.d(TAG, "=== Metadata commit successful ===")
            return true
        } catch (exception: Exception) {
            Log.e(TAG, "writeMetadataToFileInternal failed: ${exception.message}", exception)
            return false
        }
    }

    private fun setOrDeleteField(tag: Tag, key: FieldKey, value: String?) {
        try {
            if (value == null) {
                Log.d(TAG, "Field $key: no change")
                return
            }
            val trimmed = value.trim()
            if (trimmed.isEmpty()) {
                tag.deleteField(key)
                Log.d(TAG, "Deleted field: $key")
            } else {
                tag.setField(key, trimmed)
                Log.d(TAG, "Set field $key = '$trimmed'")
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to set/delete field $key: ${exception.message}")
        }
    }

    private fun createArtworkFromBytes(
        albumArtBytes: ByteArray,
        parentDir: File?
    ): org.jaudiotagger.tag.images.Artwork? {
        if (albumArtBytes.isEmpty() || albumArtBytes.size > MAX_ALBUM_ART_BYTES) {
            Log.e(TAG, "Invalid album art size: ${albumArtBytes.size}")
            return null
        }

        var tempFile: File? = null
        try {
            val tempDir = parentDir ?: File(System.getProperty("java.io.tmpdir"))
            tempFile = File.createTempFile("album_art_", ".jpg", tempDir)

            FileOutputStream(tempFile).use { stream ->
                stream.write(albumArtBytes)
                stream.flush()
                Log.d(TAG, "Wrote album art to temp file: ${tempFile.absolutePath} " +
                    "(${tempFile.length()} bytes)")
            }

            try {
                val method = ArtworkFactory::class.java.getMethod(
                    "createArtworkFromFile", File::class.java
                )
                val artwork = method.invoke(null, tempFile) as? org.jaudiotagger.tag.images.Artwork
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromFile()")
                    return artwork
                }
            } catch (exception: NoSuchMethodException) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromFile not found")
            } catch (exception: Exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromFile failed: " +
                    "${exception.message}")
            }

            try {
                val method = ArtworkFactory::class.java.getMethod(
                    "createArtworkFromData", ByteArray::class.java
                )
                val artwork = method.invoke(null, albumArtBytes) as? org.jaudiotagger.tag.images.Artwork
                if (artwork != null) {
                    Log.d(TAG, "Artwork created via ArtworkFactory.createArtworkFromData()")
                    return artwork
                }
            } catch (exception: NoSuchMethodException) {
                Log.d(TAG, "ArtworkFactory.createArtworkFromData not found")
            } catch (exception: Exception) {
                Log.w(TAG, "ArtworkFactory.createArtworkFromData failed: " +
                    "${exception.message}")
            }

            return null
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to create artwork: ${exception.message}", exception)
            return null
        } finally {
            if (tempFile != null && tempFile.exists()) {
                val deleted = tempFile.delete()
                if (!deleted) {
                    Log.w(TAG, "Failed to delete temp art file")
                }
            }
        }
    }

    // ========================================================================
    // File helpers
    // ========================================================================

    private fun copyUriToCache(context: Context, uri: Uri): File? {
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        try {
            inputStream = context.contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: $uri")
                return null
            }
            val extension = determineSourceExtension(context, uri)
            val outFile = File(
                context.cacheDir,
                "temp_audio_${SystemClock.elapsedRealtime()}.$extension"
            )
            outputStream = FileOutputStream(outFile)
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            var length: Int
            var totalBytes = 0L
            while (inputStream.read(buffer).also { length = it } != -1) {
                outputStream.write(buffer, 0, length)
                totalBytes += length
            }
            outputStream.flush()
            Log.d(TAG, "Copied $totalBytes bytes from URI to cache")
            return outFile
        } catch (exception: IOException) {
            Log.e(TAG, "copyUriToCache failed: ${exception.message}")
            return null
        } finally {
            closeSafely(inputStream)
            closeSafely(outputStream)
        }
    }

    private fun determineSourceExtension(context: Context, uri: Uri): String {
        try {
            val doc = DocumentFile.fromSingleUri(context, uri)
            val name = doc?.name
            if (name != null) {
                val dotIndex = name.lastIndexOf('.')
                if (dotIndex > 0 && dotIndex < name.length - 1) {
                    return name.substring(dotIndex + 1)
                }
            }
        } catch (ignored: Exception) {
            // Fall through to the default extension.
        }
        return DEFAULT_EXTENSION
    }

    private fun copyCacheToUri(context: Context, cacheFile: File, uri: Uri): Boolean {
        Log.d(TAG, "Writing cache file to URI: ${cacheFile.absolutePath} " +
            "(${cacheFile.length()} bytes)")

        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        try {
            inputStream = FileInputStream(cacheFile)
            val resolver: ContentResolver = context.contentResolver
            outputStream = resolver.openOutputStream(uri, "wt")
            if (outputStream == null) {
                Log.e(TAG, "Failed to open output stream for URI: $uri")
                return false
            }
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            var length: Int
            var totalBytes = 0L
            while (inputStream.read(buffer).also { length = it } != -1) {
                outputStream.write(buffer, 0, length)
                totalBytes += length
            }
            outputStream.flush()
            Log.d(TAG, "Successfully wrote $totalBytes bytes to URI")
            return true
        } catch (exception: IOException) {
            Log.e(TAG, "copyCacheToUri failed: ${exception.message}", exception)
            return false
        } finally {
            closeSafely(inputStream)
            closeSafely(outputStream)
        }
    }

    private fun copyFile(sourceFile: File, destinationFile: File): Boolean {
        var fileInputStream: FileInputStream? = null
        var fileOutputStream: FileOutputStream? = null
        try {
            fileInputStream = FileInputStream(sourceFile)
            fileOutputStream = FileOutputStream(destinationFile)
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            var length: Int
            while (fileInputStream.read(buffer).also { length = it } != -1) {
                fileOutputStream.write(buffer, 0, length)
            }
            fileOutputStream.fd.sync()
            return true
        } catch (exception: IOException) {
            Log.e(TAG, "copyFile failed: ${exception.message}")
            return false
        } finally {
            closeSafely(fileInputStream)
            closeSafely(fileOutputStream)
        }
    }

    private fun restoreFromBackup(original: File, backup: File): Boolean {
        if (!backup.exists()) {
            Log.e(TAG, "Backup file doesn't exist: ${backup.absolutePath}")
            return false
        }
        deleteFileSafely(original)
        val success = backup.renameTo(original)
        Log.d(TAG, "Restore from backup: ${if (success) "success" else "failed"}")
        return success
    }

    private fun deleteFileSafely(file: File?) {
        if (file != null && file.exists()) {
            try {
                val deleted = file.delete()
                if (!deleted) {
                    Log.w(TAG, "Failed to delete: ${file.name}")
                }
            } catch (exception: SecurityException) {
                Log.w(TAG, "delete failed for ${file.name}: ${exception.message}")
            }
        }
    }

    private fun verifyAudioFile(file: File): Boolean {
        if (!file.exists() || file.length() == 0L) {
            Log.e(TAG, "Verify failed: file doesn't exist or is empty")
            return false
        }
        return try {
            val audioFile = AudioFileIO.read(file)
            val valid = audioFile != null
            Log.d(TAG, "Verify audio file: ${if (valid) "valid" else "failed"}")
            valid
        } catch (exception: Exception) {
            Log.e(TAG, "Verify failed with exception: ${exception.message}")
            false
        }
    }

    private fun closeSafely(closeable: Closeable?) {
        if (closeable != null) {
            try {
                closeable.close()
            } catch (exception: IOException) {
                // The closeable is already closed.
            }
        }
    }
}