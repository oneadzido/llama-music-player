// FontAwesome.kt
package com.ark.llama

import android.content.Context
import android.graphics.Typeface
import android.util.Log

/**
 * Provides the FontAwesome icon font as a shared [Typeface] and
 * exposes the Unicode characters that map to specific icon glyphs.
 *
 * <p>Icons are rendered by setting the typeface returned from
 * [getTypeface] on a [android.widget.TextView] and assigning one of
 * the public character constants as its text. Because the glyphs are
 * ordinary characters, they respond to the standard TextView styling
 * properties such as color, size, and letter spacing.</p>
 *
 * <h3>Loading contract</h3>
 * <p>The typeface is loaded once, on the first successful call to
 * [init], and read on every subsequent call to [getTypeface]. A
 * failed load leaves [getTypeface] returning null; icons then render
 * as blank glyphs at the default typeface, which is visible in
 * logcat but never throws into the caller.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>[init] writes the typeface once; [getTypeface] reads it on
 * every call. The {@code @Volatile} field guarantees the write is
 * visible to any thread that subsequently reads it.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
object FontAwesome {

    private const val TAG = "FontAwesome"

    // ========================================================================
    // Icon Unicode Characters
    // ========================================================================

    /** Solid play triangle. */
    const val PLAY: String = "\uF04B"

    /** Solid pause bars. */
    const val PAUSE: String = "\uF04C"

    /** Solid double left chevrons. */
    const val BACKWARD: String = "\uF04A"

    /** Solid double right chevrons. */
    const val FORWARD: String = "\uF04E"

    /** Solid crossed arrows. */
    const val SHUFFLE: String = "\uF074"

    /** Solid circular arrows. */
    const val REPEAT: String = "\uF363"

    /** Solid converging circular arrows. */
    const val REPEAT_ONE: String = "\uF2F1"

    /** Solid folder shape. */
    const val FOLDER: String = "\uF07B"

    /** Solid heart shape. */
    const val HEART: String = "\uF004"

    /** Solid check mark. */
    const val CHECK: String = "\uF00C"

    /** Solid house shape. */
    const val HOME: String = "\uF015"

    // ========================================================================
    // Typeface
    // ========================================================================

    /** Typeface loaded from assets, or null when not yet loaded. */
    @Volatile
    private var sTypeface: Typeface? = null

    /**
     * Loads the FontAwesome typeface from assets on the first call,
     * and does nothing on every subsequent call.
     *
     * <p>A failure to load the font file leaves [getTypeface]
     * returning null; this method does not throw on failure. The
     * failure is logged so a missing asset is visible in logcat
     * without changing runtime behaviour.</p>
     *
     * @param context Context used to open the asset
     */
    @JvmStatic
    fun init(context: Context) {
        if (sTypeface == null) {
            try {
                sTypeface = Typeface.createFromAsset(
                    context.assets, "fonts/fa-solid-900.ttf"
                )
            } catch (exception: Exception) {
                // A failed font load leaves the typeface null; icons
                // then render as blank glyphs at the default
                // typeface. Logged so a missing asset is visible in
                // logcat without changing runtime behaviour.
                Log.w(TAG, "Failed to load FontAwesome typeface", exception)
            }
        }
    }

    /**
     * Returns the loaded FontAwesome typeface, or null when [init]
     * has not yet been called or loading the font failed.
     *
     * @return The FontAwesome typeface, or null
     */
    @JvmStatic
    fun getTypeface(): Typeface? = sTypeface
}