// PlaylistActivity.kt
package com.ark.llama

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.MetadataEvent
import com.ark.llama.event.PlayerEvent
import com.ark.llama.event.PlaylistEvent
import com.ark.llama.event.SettingsEvent
import com.ark.llama.event.TransportEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.ArrayList
import java.util.Collections
import java.util.Comparator

/**
 * Displays the playlist, supports search and sort, and tracks the
 * currently playing song.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class PlaylistActivity : Activity() {

    // ========================================================================
    // Constants
    // ========================================================================

    private val PREFS_NAME = "LlamaPrefs"
    private val KEY_LAST_SONG_PATH = "last_song_path"
    private val KEY_SORT_MODE = "playlist_sort_mode"

    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val FOCUS_SCROLL_DELAY_MS = 500L
    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f
    private val MAX_SEARCH_LENGTH = 128
    private val SEARCH_BAR_CORNER_RADIUS_DP = 10
    private val SEARCH_INPUT_CORNER_RADIUS_DP = 8
    private val SEARCH_BAR_STROKE_WIDTH_DP = 1
    private val EMPTY_CONTAINER_PADDING_DP = 32
    private val SORT_OVERLAY_MIN_DURATION_MS = 250L

    private val SORT_TITLE_AZ = 0
    private val SORT_TITLE_ZA = 1
    private val SORT_ARTIST_AZ = 2
    private val SORT_ARTIST_ZA = 3
    private val SORT_ALBUM_AZ = 4
    private val SORT_ALBUM_ZA = 5
    private val SORT_GENRE_AZ = 6
    private val SORT_GENRE_ZA = 7
    private val SORT_OLDEST = 8
    private val SORT_NEWEST = 9
    private val SORT_MODE_COUNT = 10

    private val SORT_MODE_LABEL_SEPARATOR = " "

    private val SORT_LABEL_RES = intArrayOf(
        R.string.playlist_sort_label_title_az,
        R.string.playlist_sort_label_title_za,
        R.string.playlist_sort_label_artist_az,
        R.string.playlist_sort_label_artist_za,
        R.string.playlist_sort_label_album_az,
        R.string.playlist_sort_label_album_za,
        R.string.playlist_sort_label_genre_az,
        R.string.playlist_sort_label_genre_za,
        R.string.playlist_sort_label_oldest,
        R.string.playlist_sort_label_newest
    )

    private val SORT_TOAST_RES = intArrayOf(
        R.string.playlist_sort_toast_title_az,
        R.string.playlist_sort_toast_title_za,
        R.string.playlist_sort_toast_artist_az,
        R.string.playlist_sort_toast_artist_za,
        R.string.playlist_sort_toast_album_az,
        R.string.playlist_sort_toast_album_za,
        R.string.playlist_sort_toast_genre_az,
        R.string.playlist_sort_toast_genre_za,
        R.string.playlist_sort_toast_oldest,
        R.string.playlist_sort_toast_newest
    )

    // ========================================================================
    // PendingFavorites holder
    // ========================================================================

    private class PendingFavorites {
        private val mMap = HashMap<String, Boolean>()

        fun stage(path: String, favorite: Boolean) {
            mMap[path] = favorite
        }

        fun isEmpty(): Boolean = mMap.isEmpty()

        fun snapshot(): MutableMap<String, Boolean> = HashMap(mMap)

        fun clear() {
            mMap.clear()
        }
    }

    // ========================================================================
    // UI
    // ========================================================================

    private var mPlaylistRecyclerView: RecyclerView? = null
    private var mLayoutManager: LinearLayoutManager? = null
    private var mAdapter: PlaylistAdapter? = null
    private var mPlaylistTitle: TextView? = null
    private var mSongCountText: TextView? = null
    private var mSearchText: EditText? = null
    private var mSearchButton: Button? = null
    private var mClearButton: Button? = null
    private var mSortButton: Button? = null
    private var mCancelButton: Button? = null
    private var mSearchBar: LinearLayout? = null
    private var mEmptyContainer: LinearLayout? = null
    private var mRootContainer: FrameLayout? = null

    // ========================================================================
    // Data
    // ========================================================================

    private val mCurrentDisplayList = ArrayList<Song>()

    @Volatile
    private var mCurrentPlayingPath: String? = null

    private var mIsSearchVisible = false
    private var mInputMethodManager: InputMethodManager? = null
    private val mPendingFavorites = PendingFavorites()

    // ========================================================================
    // Scroll state
    // ========================================================================

    @Volatile
    private var mUserScrolling = false
    private var mSavedScrollState: Parcelable? = null
    private var mScrollRestorePending = false

    // ========================================================================
    // Theme
    // ========================================================================

    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper

    // ========================================================================
    // Sort
    // ========================================================================

    private var mCurrentSortMode = SORT_TITLE_AZ
    private var mLastSortClickTime = 0L
    private var mPendingSortAfterGenre = false
    private var mSortOverlayHideRunnable: Runnable? = null
    private var mSortGeneration = 0L

    // ========================================================================
    // Interaction state
    // ========================================================================

    private var mLastSearchClickTime = 0L
    private var mLastCancelClickTime = 0L
    @Volatile
    private var mUserInteractionInProgress = false
    @Volatile
    private var mIsGenreLoading = false

    private val mMainHandler = Handler(Looper.getMainLooper())

    // ========================================================================
    // Generation gate and deferred focus
    // ========================================================================

    private var mLastSeenGeneration = -1L
    private var mDeferredGenreFocusRow = -1

    // ========================================================================
    // Service connection
    // ========================================================================

    private var mMusicService: MusicService? = null
    private var mIsServiceBound = false

    private val mServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            mMusicService = binder.service
            mIsServiceBound = true
            mLastSeenGeneration = -1L
            refreshPlaylistFromService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            mMusicService = null
            mIsServiceBound = false
        }
    }

    // ========================================================================
    // attachBaseContext
    // ========================================================================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase)
        )
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ToastManager.init(this)
        OverlayManager.init(this)

        setFullScreen()
        setContentView(R.layout.activity_playlist)

        CharacterMapper.init(this)

        mInputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        mThemeManager = ThemeManager.getInstance(this)
        mThemeHelper = ThemeHelper.getInstance(this)

        LlamaEventBus.register(this)

        loadCurrentPlayingPath()
        loadSortMode()
        initializeViews()
        setupSearchListener()
        setupScrollListener()
        setupEdgeFastScroll()

        bindService(
            Intent(this, MusicService::class.java),
            mServiceConnection,
            BIND_AUTO_CREATE
        )

        applyThemeToUI()
        themeAllHeaders()
    }

    override fun onResume() {
        super.onResume()

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }

        refreshPlaylistFromService()

        mAdapter?.let { adapter ->
            val position = findPositionByPath(mCurrentPlayingPath)
            adapter.setCurrentPlayingIndex(position)
        }

        mMainHandler.postDelayed({
            val query = mSearchText?.text?.toString()?.trim() ?: ""
            if (query.isEmpty() && !mUserInteractionInProgress &&
                !mIsGenreLoading && !mUserScrolling
            ) {
                focusCurrentSong()
            }
        }, 100L)

        mSortButton?.let { mThemeHelper.updateButton(it, true) }
        updateSortHeaderDisplay()
        applyThemeToUI()
        themeAllHeaders()
        ToastManager.refreshThemeColor()
    }

    override fun onPause() {
        super.onPause()
        if (!mPendingFavorites.isEmpty() && mMusicService != null) {
            mMusicService?.commitFavorites(mPendingFavorites.snapshot())
            mPendingFavorites.clear()
        }
    }

    override fun onRestart() {
        super.onRestart()
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        mSortOverlayHideRunnable?.let { mMainHandler.removeCallbacks(it) }
        mSortOverlayHideRunnable = null
        OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT)

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection)
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to unbind from MusicService", exception)
            }
            mIsServiceBound = false
        }

        LlamaEventBus.unregister(this)
        mMainHandler.removeCallbacksAndMessages(null)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }
    }

    override fun onConfigurationChanged(config: Configuration) {
        super.onConfigurationChanged(config)
        forceRedraw()
    }

    override fun onBackPressed() {
        if (mIsSearchVisible) hideSearch() else returnToMusicPlayer()
    }

    // ========================================================================
    // LlamaEventBus subscribers
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlayerSnapshot(event: PlayerEvent.Snapshot) {
        var generationAdvanced: Boolean
        if (event.generation >= 0L) {
            if (event.generation < mLastSeenGeneration) return
            generationAdvanced = event.generation > mLastSeenGeneration
            if (generationAdvanced) mLastSeenGeneration = event.generation
        } else {
            generationAdvanced = false
        }

        val songPath = event.songPath ?: return
        mCurrentPlayingPath = songPath
        val adapter = mAdapter ?: return

        val displayPosition = findPositionByPath(songPath)
        if (displayPosition < 0) return
        adapter.setCurrentPlayingIndex(displayPosition)

        if (!generationAdvanced) return
        if (!shouldAutoScrollTo(displayPosition)) return

        if (mIsGenreLoading) {
            mDeferredGenreFocusRow = displayPosition
        } else if (!mUserScrolling && !mUserInteractionInProgress) {
            scrollToRowIfOffscreen(displayPosition)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaylistDisplay(event: PlaylistEvent.Display) {
        runOnUiThread {
            if (!mIsGenreLoading) refreshPlaylistFromService()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMetadataUpdated(event: MetadataEvent.Updated) {
        val songPath = resolveSongPathFromMetadata(event) ?: return
        val adapter = mAdapter ?: return

        val displayPosition = findPositionByPath(songPath)
        if (displayPosition >= 0) {
            val existing = mCurrentDisplayList[displayPosition]
            if (existing != null) {
                val updated = Song(
                    event.title,
                    event.artist,
                    event.album,
                    event.genre,
                    songPath,
                    existing.duration,
                    event.songUri ?: existing.uri
                )
                mCurrentDisplayList[displayPosition] = updated
                adapter.notifyItemChanged(displayPosition)
            }
        }

        if (songPath == mCurrentPlayingPath) {
            mCurrentPlayingPath = songPath
            adapter.setCurrentPlayingIndex(displayPosition)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onGenreUpdated(event: MetadataEvent.GenreUpdated) {
        when (event.status) {
            "START" -> {
                Log.d(TAG, "Genre loading started for ${event.total} songs")
                mIsGenreLoading = true
                mAdapter?.setGenreLoading(true)
            }
            "UPDATE" -> {
                val path = event.songPath ?: return
                val genre = event.genre ?: return
                mAdapter?.updateSongGenre(path, genre)
            }
            "COMPLETE" -> {
                Log.d(TAG, "Genre loading complete: ${event.current} genres loaded")
                mIsGenreLoading = false
                mAdapter?.setGenreLoading(false)
                if (mPendingSortAfterGenre) {
                    mPendingSortAfterGenre = false
                    applyCurrentSort(true)
                }
                applyDeferredGenreFocus()
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onLibraryReset(event: PlaylistEvent.LibraryReset) {
        Log.d(TAG, "LIBRARY_RESET received — clearing display list")
        mCurrentDisplayList.clear()
        mCurrentPlayingPath = null
        mDeferredGenreFocusRow = -1
        mLastSeenGeneration = -1L
        mIsGenreLoading = false
        mPendingSortAfterGenre = false

        runOnUiThread {
            mAdapter?.setGenreLoading(false)
            showEmptyView(R.string.playlist_empty_state)
            mAdapter?.updateList(mCurrentDisplayList)
            mAdapter?.setCurrentPlayingPath(null)
            updateTitleAndCount()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onSongAdded(event: PlaylistEvent.SongAdded) {
        val path = event.songPath
        if (path.isEmpty()) return
        val exists = mCurrentDisplayList.any { it.path == path }
        if (exists || mIsGenreLoading || mUserScrolling) return

        val newSong = Song(
            event.songTitle,
            event.songArtist,
            event.songAlbum,
            event.songGenre,
            path,
            event.songDuration,
            null
        )
        mCurrentDisplayList.add(newSong)
        mAdapter?.updateList(mCurrentDisplayList)
        updateTitleAndCount()
    }

    // ========================================================================
    // Navigation
    // ========================================================================

    private fun returnToMusicPlayer() {
        val intent = Intent(this, MusicPlayer::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    // ========================================================================
    // Edge fast scroll
    // ========================================================================

    private fun setupEdgeFastScroll() {
        mPlaylistRecyclerView?.let { EdgeScrollHelper.attach(it) }
    }

    private fun setupScrollListener() {
        mPlaylistRecyclerView?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                val scrolling = newState != RecyclerView.SCROLL_STATE_IDLE
                mUserScrolling = scrolling
                mAdapter?.setScrolling(scrolling)
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                val lm = mLayoutManager
                if (lm != null && !mUserScrolling) {
                    mSavedScrollState = lm.onSaveInstanceState()
                }
            }
        })
    }

    private fun saveScrollPosition() {
        val lm = mLayoutManager
        if (lm != null && !mUserScrolling) {
            mSavedScrollState = lm.onSaveInstanceState()
            mScrollRestorePending = true
        }
    }

    private fun restoreScrollPosition() {
        val lm = mLayoutManager
        if (mScrollRestorePending && mSavedScrollState != null &&
            lm != null && !mUserScrolling
        ) {
            try {
                lm.onRestoreInstanceState(mSavedScrollState)
                mScrollRestorePending = false
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to restore scroll position", exception)
                mScrollRestorePending = false
            }
        }
    }

    private fun shouldAutoScrollTo(row: Int): Boolean {
        val lm = mLayoutManager ?: return false
        if (row < 0 || row >= mCurrentDisplayList.size) return false
        val firstVisible = lm.findFirstCompletelyVisibleItemPosition()
        val lastVisible = lm.findLastCompletelyVisibleItemPosition()
        if (firstVisible == RecyclerView.NO_POSITION ||
            lastVisible == RecyclerView.NO_POSITION
        ) return false
        return row < firstVisible || row > lastVisible
    }

    private fun scrollToRowIfOffscreen(row: Int) {
        val rv = mPlaylistRecyclerView ?: return
        val lm = mLayoutManager ?: return
        if (!shouldAutoScrollTo(row)) return
        mScrollRestorePending = false
        val finalRow = row
        rv.post {
            if (isFinishing || isDestroyed) return@post
            lm.scrollToPositionWithOffset(finalRow, rv.height / 2)
        }
    }

    private fun applyDeferredGenreFocus() {
        if (mDeferredGenreFocusRow < 0) return
        val deferred = mDeferredGenreFocusRow
        mDeferredGenreFocusRow = -1
        scrollToRowIfOffscreen(deferred)
    }

    // ========================================================================
    // Refresh
    // ========================================================================

    private fun refreshPlaylistFromService() {
        if (mIsGenreLoading) {
            Log.d(TAG, "refreshPlaylistFromService suppressed during genre loading")
            return
        }
        if (mUserScrolling) {
            Log.d(TAG, "refreshPlaylistFromService suppressed during user scrolling")
            return
        }
        val service = mMusicService ?: return

        val currentSong = service.getCurrentSong()
        if (currentSong != null && currentSong.path.isNotEmpty()) {
            mCurrentPlayingPath = currentSong.path
        }

        saveScrollPosition()

        val playlist = service.getCurrentPlaylist()
        if (playlist.isEmpty()) {
            mCurrentDisplayList.clear()
            mCurrentPlayingPath = null
            mDeferredGenreFocusRow = -1
            val scope = service.getPlaybackScope()
            val scopeRestricts = scope.kind != PlaybackScope.Kind.ALL_SONGS
            showEmptyView(
                if (scopeRestricts) R.string.playlist_empty_scope
                else R.string.playlist_empty_state
            )
            mAdapter?.updateList(mCurrentDisplayList)
            mAdapter?.setCurrentPlayingPath(null)
            updateTitleAndCount()
            return
        }

        val searchText = mSearchText?.text?.toString() ?: ""
        if (searchText.isNotEmpty()) {
            performSearch(searchText)
        } else {
            mCurrentDisplayList.clear()
            mCurrentDisplayList.addAll(playlist)
            applyCurrentSort(false)
            hideEmptyView()
            mAdapter?.updateList(mCurrentDisplayList)
            updateTitleAndCount()
        }

        mMainHandler.postDelayed({ restoreScrollPosition() }, 100L)
    }

    // ========================================================================
    // Sort
    // ========================================================================

    private fun loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ)
    }

    private fun saveSortMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_SORT_MODE, mCurrentSortMode)
            .apply()
    }

    private fun cycleSortMode() {
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT
        saveSortMode()

        LlamaEventBus.post(TransportEvent.SetPlaybackSortMode(mCurrentSortMode))

        val listToSort = ArrayList(mCurrentDisplayList)
        val currentPath = mCurrentPlayingPath
        val sortMode = mCurrentSortMode
        val sortStartedElapsed = SystemClock.elapsedRealtime()
        val thisSortGeneration = ++mSortGeneration

        OverlayManager.show(OverlayManager.REASON_PLAYLIST_SORT)

        Thread {
            Collections.sort(listToSort, getComparatorForSortMode(sortMode))

            mMainHandler.post {
                if (isFinishing || isDestroyed) {
                    cancelSortOverlayHide()
                    OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT)
                    return@post
                }
                if (thisSortGeneration != mSortGeneration) return@post

                mCurrentDisplayList.clear()
                mCurrentDisplayList.addAll(listToSort)
                mAdapter?.updateList(mCurrentDisplayList, true)

                if (currentPath != null) {
                    val newPosition = findPositionByPath(currentPath)
                    if (newPosition >= 0) {
                        mCurrentPlayingPath = currentPath
                        mAdapter?.setCurrentPlayingIndex(newPosition)
                    }
                }

                scrollToCurrentSongImmediately()
                updateTitleAndCount()
                updateSortHeaderDisplay()

                ToastManager.showToast(
                    this,
                    getString(SORT_TOAST_RES[mCurrentSortMode]),
                    ToastManager.LENGTH_NORMAL
                )

                hideSortOverlayAfterListSettles(thisSortGeneration, sortStartedElapsed)
            }
        }.start()
    }

    private fun cancelSortOverlayHide() {
        mSortOverlayHideRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mSortOverlayHideRunnable = null
        }
    }

    private fun scrollToCurrentSongImmediately() {
        val rv = mPlaylistRecyclerView ?: return
        val lm = mLayoutManager ?: return
        val currentPath = mCurrentPlayingPath ?: return
        if (mCurrentDisplayList.isEmpty()) return
        if (mUserScrolling || mIsGenreLoading || mUserInteractionInProgress) return

        val position = findPositionByPath(currentPath)
        if (position < 0) return
        lm.scrollToPositionWithOffset(position, rv.height / 2)
    }

    private fun hideSortOverlayAfterListSettles(
        sortGeneration: Long,
        sortStartedElapsed: Long
    ) {
        val rv = mPlaylistRecyclerView
        if (rv == null) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(sortStartedElapsed)
            }
            return
        }

        val observer = rv.viewTreeObserver
        if (!observer.isAlive) {
            if (sortGeneration == mSortGeneration) {
                scheduleSortOverlayHideAtMinDuration(sortStartedElapsed)
            }
            return
        }

        observer.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                val current = rv.viewTreeObserver
                if (current.isAlive) current.removeOnPreDrawListener(this)
                rv.post {
                    if (sortGeneration != mSortGeneration) return@post
                    scheduleSortOverlayHideAtMinDuration(sortStartedElapsed)
                }
                return true
            }
        })
    }

    private fun scheduleSortOverlayHideAtMinDuration(sortStartedElapsed: Long) {
        val elapsed = SystemClock.elapsedRealtime() - sortStartedElapsed
        val remaining = Math.max(0L, SORT_OVERLAY_MIN_DURATION_MS - elapsed)
        scheduleSortOverlayHide(remaining)
    }

    private fun scheduleSortOverlayHide(delayMs: Long) {
        cancelSortOverlayHide()
        mSortOverlayHideRunnable = Runnable {
            mSortOverlayHideRunnable = null
            OverlayManager.hide(OverlayManager.REASON_PLAYLIST_SORT)
        }
        mMainHandler.postDelayed(mSortOverlayHideRunnable!!, delayMs)
    }

    private fun applyCurrentSort(showToast: Boolean) {
        if (mCurrentDisplayList.isEmpty()) return
        val currentPath = mCurrentPlayingPath

        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode))

        if (showToast) {
            LlamaEventBus.post(TransportEvent.SetPlaybackSortMode(mCurrentSortMode))
        }

        mAdapter?.let { adapter ->
            adapter.updateList(mCurrentDisplayList)
            if (currentPath != null) {
                val newPosition = findPositionByPath(currentPath)
                if (newPosition >= 0) {
                    mCurrentPlayingPath = currentPath
                    adapter.setCurrentPlayingIndex(newPosition)
                    if (showToast) {
                        mMainHandler.postDelayed({
                            if (!mUserScrolling && !mIsGenreLoading && !mUserInteractionInProgress) {
                                focusCurrentSong()
                            }
                        }, FOCUS_SCROLL_DELAY_MS)
                    }
                }
            }
        }

        updateTitleAndCount()
        if (showToast) {
            ToastManager.showToast(
                this,
                getString(SORT_TOAST_RES[mCurrentSortMode]),
                ToastManager.LENGTH_NORMAL
            )
        }
    }

    private fun findPositionByPath(path: String?): Int {
        if (path == null) return -1
        for (index in mCurrentDisplayList.indices) {
            if (mCurrentDisplayList[index].path == path) return index
        }
        return -1
    }

    private fun getSongDate(song: Song?): Long {
        if (song == null || song.path.isEmpty()) return 0L
        return try { File(song.path).lastModified() } catch (ignored: Exception) { 0L }
    }

    private fun getComparatorForSortMode(mode: Int): Comparator<Song> {
        return when (mode) {
            SORT_TITLE_AZ -> Comparator { a, b -> a.title.compareTo(b.title, ignoreCase = true) }
            SORT_TITLE_ZA -> Comparator { a, b -> b.title.compareTo(a.title, ignoreCase = true) }
            SORT_ARTIST_AZ -> Comparator { a, b ->
                val cmp = a.artist.compareTo(b.artist, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_ARTIST_ZA -> Comparator { a, b ->
                val cmp = b.artist.compareTo(a.artist, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_ALBUM_AZ -> Comparator { a, b ->
                val cmp = a.album.compareTo(b.album, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_ALBUM_ZA -> Comparator { a, b ->
                val cmp = b.album.compareTo(a.album, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_GENRE_AZ -> Comparator { a, b ->
                val cmp = a.genre.compareTo(b.genre, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_GENRE_ZA -> Comparator { a, b ->
                val cmp = b.genre.compareTo(a.genre, ignoreCase = true)
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_OLDEST -> Comparator { a, b ->
                val cmp = getSongDate(a).compareTo(getSongDate(b))
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            SORT_NEWEST -> Comparator { a, b ->
                val cmp = getSongDate(b).compareTo(getSongDate(a))
                if (cmp == 0) a.title.compareTo(b.title, ignoreCase = true) else cmp
            }
            else -> Comparator { a, b -> a.title.compareTo(b.title, ignoreCase = true) }
        }
    }

    private fun updateSortHeaderDisplay() {
        val title = mPlaylistTitle ?: return
        val query = mSearchText?.text?.toString() ?: ""
        if (query.isEmpty()) {
            title.text = getString(R.string.playlist_sort_mode_prefix) +
                SORT_MODE_LABEL_SEPARATOR +
                getString(SORT_LABEL_RES[mCurrentSortMode])
            mSortButton?.visibility = View.VISIBLE
        } else {
            title.setText(R.string.playlist_search_results)
            mSortButton?.visibility = View.GONE
        }
        title.setTextColor(Color.parseColor("#C0C0C0"))
    }

    // ========================================================================
    // Empty state
    // ========================================================================

    private fun showEmptyView(messageRes: Int) {
        mEmptyContainer?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            mEmptyContainer = null
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP)
            )
        }

        val text = TextView(this).apply {
            setText(messageRes)
            setTextColor(Color.parseColor("#C0C0C0"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        container.addView(text)

        mPlaylistRecyclerView?.let { rv ->
            (rv.parent as? LinearLayout)?.addView(
                container,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
                )
            )
            rv.visibility = View.GONE
        }

        mSearchBar?.visibility = View.GONE
        mSearchButton?.let {
            it.isEnabled = false
            it.setTextColor(Color.parseColor("#5A5A5A"))
        }

        mEmptyContainer = container
    }

    private fun hideEmptyView() {
        mEmptyContainer?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            mEmptyContainer = null
        }
        mPlaylistRecyclerView?.visibility = View.VISIBLE
        mSearchButton?.let {
            it.isEnabled = true
            applyThemeToUI()
        }
        if (mIsSearchVisible) mSearchBar?.visibility = View.VISIBLE
    }

    // ========================================================================
    // Adapter setup
    // ========================================================================

    private fun setupAdapter() {
        val adapter = PlaylistAdapter(
            this,
            mCurrentDisplayList,
            object : PlaylistAdapter.OnSongClickListener {
                override fun onSongClick(position: Int, song: Song) {
                    if (song.path.isEmpty()) return
                    mUserInteractionInProgress = true

                    LlamaEventBus.post(TransportEvent.PlaySong(song.path))

                    val selectedPath = song.path
                    mMainHandler.postDelayed({
                        try {
                            mCurrentPlayingPath = selectedPath
                            val newPosition = findPositionByPath(selectedPath)
                            mAdapter?.setCurrentPlayingIndex(newPosition)
                        } catch (exception: Exception) {
                            Log.e(TAG, "Error setting playing index", exception)
                        }
                        mUserInteractionInProgress = false
                    }, FOCUS_SCROLL_DELAY_MS)
                }
            }
        )

        adapter.setFavoriteListener(object : PlaylistAdapter.FavoriteListener {
            override fun onFavoriteToggle(songPath: String, favorite: Boolean) {
                mPendingFavorites.stage(songPath, favorite)
            }
        })

        val position = findPositionByPath(mCurrentPlayingPath)
        adapter.setCurrentPlayingIndex(position)

        mLayoutManager = LinearLayoutManager(this)
        mPlaylistRecyclerView?.layoutManager = mLayoutManager
        mPlaylistRecyclerView?.adapter = adapter
        mAdapter = adapter
    }

    private fun updateTitleAndCount() {
        val query = mSearchText?.text?.toString() ?: ""
        if (query.isEmpty()) {
            mPlaylistTitle?.let {
                it.text = getString(R.string.playlist_sort_mode_prefix) +
                    SORT_MODE_LABEL_SEPARATOR +
                    getString(SORT_LABEL_RES[mCurrentSortMode])
                it.setTextColor(Color.parseColor("#C0C0C0"))
            }
            mSongCountText?.let {
                val count = mCurrentDisplayList.size
                it.text = resources.getQuantityString(R.plurals.song_count, count, count)
            }
        } else {
            val total = mMusicService?.getCurrentPlaylist()?.size ?: 0
            mPlaylistTitle?.let {
                it.setText(R.string.playlist_search_results)
                it.setTextColor(Color.parseColor("#C0C0C0"))
            }
            mSongCountText?.let {
                val count = mCurrentDisplayList.size
                it.text = "$count / " +
                    resources.getQuantityString(R.plurals.song_count, total, total)
            }
        }
    }

    private fun loadCurrentPlayingPath() {
        mCurrentPlayingPath = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null)
    }

    private fun resolveSongPathFromMetadata(event: MetadataEvent.Updated): String? {
        event.songPath?.takeIf { it.isNotEmpty() }?.let { return it }
        val uriString = event.songUri ?: return null
        if (uriString.isEmpty()) return null
        return try {
            SongDatabase.getInstance(this).getAllSongs().firstOrNull { it.uri == uriString }?.path
        } catch (exception: Exception) {
            Log.w(TAG, "resolveSongPathFromMetadata failed", exception)
            null
        }
    }

    private fun focusCurrentSong() {
        if (mIsGenreLoading) {
            Log.d(TAG, "focusCurrentSong suppressed during genre loading")
            return
        }
        if (mUserScrolling) return
        val rv = mPlaylistRecyclerView ?: return
        val lm = mLayoutManager ?: return
        val adapter = mAdapter ?: return
        if (mUserInteractionInProgress) return
        if (mCurrentDisplayList.isEmpty() || adapter.itemCount == 0) return
        val path = mCurrentPlayingPath ?: return

        val targetPosition = findPositionByPath(path)
        if (targetPosition < 0) return

        val finalPosition = targetPosition
        rv.post {
            val firstVisible = lm.findFirstCompletelyVisibleItemPosition()
            val lastVisible = lm.findLastCompletelyVisibleItemPosition()
            if (finalPosition < firstVisible || finalPosition > lastVisible) {
                lm.scrollToPositionWithOffset(finalPosition, rv.height / 2)
            }
        }
    }

    // ========================================================================
    // Full-screen
    // ========================================================================

    @Suppress("DEPRECATION")
    private fun setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.statusBarColor = resources.getColor(R.color.backgroundDark, null)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark, null)
            } else {
                window.statusBarColor = resources.getColor(R.color.backgroundDark)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    // ========================================================================
    // View init
    // ========================================================================

    private fun initializeViews() {
        mPlaylistRecyclerView = findViewById(R.id.playlistRecyclerView)
        mPlaylistTitle = findViewById(R.id.playlistTitle)
        mSongCountText = findViewById(R.id.songCountText)
        mSortButton = findViewById(R.id.sortButton)
        mSearchText = findViewById(R.id.searchText)
        mSearchButton = findViewById(R.id.searchButton)
        mClearButton = findViewById(R.id.clearButton)
        mSearchBar = findViewById(R.id.searchBar)
        mCancelButton = findViewById(R.id.cancelButton)
        mRootContainer = findViewById(R.id.rootContainer)

        mSearchText?.filters = arrayOf(
            android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
        )

        animateButton(mCancelButton)
        animateButton(mSearchButton)
        animateButton(mClearButton)
        animateButton(mSortButton)

        mSearchBar?.let {
            it.visibility = View.GONE
            it.setOnTouchListener { _, _ -> true }
        }

        mSearchButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastSearchClickTime = now
                showSearch()
            }
        }

        mCancelButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelClickTime = now
                if (mIsSearchVisible) hideSearch() else returnToMusicPlayer()
            }
        }

        mSortButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastSortClickTime = now
                cycleSortMode()
            }
        }

        setupAdapter()
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
            }
            false
        }
    }

    // ========================================================================
    // Search
    // ========================================================================

    private fun setupSearchListener() {
        mSearchText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        mSearchText?.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                    event.action == KeyEvent.ACTION_DOWN)
            ) {
                mInputMethodManager?.hideSoftInputFromWindow(
                    mSearchText?.windowToken, 0
                )
                true
            } else false
        }

        mSearchText?.let {
            mThemeHelper.updateEditText(it)
            mThemeHelper.updateEditTextCursor(it)
        }

        mClearButton?.setOnClickListener { mSearchText?.setText("") }
    }

    private fun performSearch(query: String) {
        val adapter = mAdapter ?: return
        val service = mMusicService ?: return
        val currentPath = mCurrentPlayingPath
        val allSongs = service.getCurrentPlaylist()

        if (allSongs.isEmpty()) {
            mCurrentDisplayList.clear()
            adapter.updateList(mCurrentDisplayList)
            updateTitleAndCount()
            return
        }

        mCurrentDisplayList.clear()
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            mCurrentDisplayList.addAll(allSongs)
        } else {
            val lowerQuery = trimmed.lowercase()
            for (song in allSongs) {
                if (song.title.lowercase().contains(lowerQuery) ||
                    song.artist.lowercase().contains(lowerQuery) ||
                    song.album.lowercase().contains(lowerQuery) ||
                    song.genre.lowercase().contains(lowerQuery)
                ) {
                    mCurrentDisplayList.add(song)
                }
            }
        }

        applyCurrentSort(false)

        if (currentPath != null) {
            val position = findPositionByPath(currentPath)
            adapter.setCurrentPlayingIndex(position)
        } else {
            adapter.setCurrentPlayingIndex(-1)
        }

        updateTitleAndCount()
    }

    private fun showSearch() {
        mSearchBar?.visibility = View.VISIBLE
        mIsSearchVisible = true
        mSortButton?.visibility = View.GONE
        mSearchText?.requestFocus()
        mInputMethodManager?.showSoftInput(mSearchText, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideSearch() {
        mSearchBar?.visibility = View.GONE
        mIsSearchVisible = false
        mSortButton?.visibility = View.VISIBLE
        mSearchText?.setText("")
        mInputMethodManager?.hideSoftInputFromWindow(mSearchText?.windowToken, 0)
        performSearch("")
    }

    // ========================================================================
    // Theme
    // ========================================================================

    private fun themeAllHeaders() {
        mPlaylistTitle?.setTextColor(Color.parseColor("#C0C0C0"))
        mSongCountText?.setTextColor(Color.parseColor("#C0C0C0"))
        val root = findViewById<View>(android.R.id.content)
        if (root is ViewGroup) themeHeadersRecursive(root)
    }

    private fun themeHeadersRecursive(group: ViewGroup) {
        val playlistTitle = getString(R.string.playlist_title)
        for (index in 0 until group.childCount) {
            val child = group.getChildAt(index)
            if (child is TextView && child !is Button && child !is EditText) {
                if (child.text.toString() == playlistTitle) {
                    child.setTextColor(Color.parseColor("#C0C0C0"))
                }
            } else if (child is ViewGroup) {
                themeHeadersRecursive(child)
            }
        }
    }

    private fun applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        val themeColor = mThemeHelper.themeColorInt

        mCancelButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mSearchButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mClearButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mSortButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }

        mSearchBar?.let {
            val border = GradientDrawable()
            border.shape = GradientDrawable.RECTANGLE
            border.cornerRadius = dpToPx(SEARCH_BAR_CORNER_RADIUS_DP).toFloat()
            border.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor)
            border.setColor(Color.TRANSPARENT)
            it.background = border
        }

        mSearchText?.let {
            mThemeHelper.updateEditText(it)
            mThemeHelper.updateEditTextCursor(it)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.RECTANGLE
            bg.cornerRadius = dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP).toFloat()
            bg.setColor(Color.parseColor("#1A1A1A"))
            it.background = bg
            it.setTextColor(themeColor)
        }

        mPlaylistTitle?.setTextColor(Color.parseColor("#C0C0C0"))
        mSongCountText?.setTextColor(Color.parseColor("#C0C0C0"))

        mAdapter?.let { if (it.itemCount > 0) it.notifyItemRangeChanged(0, it.itemCount) }

        forceRedraw()
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    private fun forceRedraw() {
        val root = findViewById<View>(android.R.id.content) ?: return
        root.requestLayout()
        root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.updateConfiguration(resources.configuration, resources.displayMetrics)
        }
        recreate()
        overridePendingTransition(0, 0)
    }

    private fun dpToPx(dp: Int): Int = Math.round(dp * resources.displayMetrics.density)

    companion object {
        private const val TAG = "PlaylistActivity"
    }
}