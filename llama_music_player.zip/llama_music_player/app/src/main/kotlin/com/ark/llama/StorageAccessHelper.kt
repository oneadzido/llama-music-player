// StorageAccessHelper.kt
package com.ark.llama

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import java.util.ArrayList
import java.util.HashSet
import java.util.Set
import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * Manages Storage Access Framework permissions, document URIs, and
 * folder-to-URI mappings.
 *
 * <p>Stores the folder permissions the user has granted through the
 * system folder picker, resolves file paths to their writeable
 * document URIs, reacquires permissions on URIs that already exist,
 * and extracts a folder's display name and filesystem path from a
 * tree URI.</p>
 *
 * <h3>Storage-Type Labels</h3>
 * <p>[getStorageType] returns a bracketed suffix identifying the
 * storage medium a folder lives on — `"[Internal]"` for primary
 * storage, `"[SD Card]"` for removable. Both labels resolve from
 * string resources in the app's selected language.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Access to the shared preference store and the URI mappings is
 * guarded by a [ReentrantReadWriteLock]. Read operations acquire
 * the read lock; write operations acquire the write lock.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class StorageAccessHelper private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context.applicationContext

    private val mPreferences: SharedPreferences =
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val mReadWriteLock = ReentrantReadWriteLock()
    private val mReadLock = mReadWriteLock.readLock()
    private val mWriteLock = mReadWriteLock.writeLock()

    // ========================================================================
    // Localization
    // ========================================================================

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to obtain localized context", exception)
        mContext
    }

    // ========================================================================
    // Folder Permission Management
    // ========================================================================

    /**
     * Persists the given folder URI permission and maps it to its
     * filesystem path.
     */
    fun storeFolderPermission(folderUri: Uri, folderPath: String?): Boolean {
        val uriString = folderUri.toString()

        try {
            try {
                mContext.contentResolver.takePersistableUriPermission(
                    folderUri, URI_PERMISSION_FLAGS
                )
            } catch (exception: SecurityException) {
                Log.e(TAG, "Failed to take persistable URI permission", exception)
                return false
            }

            mWriteLock.lock()
            try {
                val knownUris = getKnownFolderUrisLocked()
                if (knownUris.size >= MAX_FOLDER_URIS) {
                    Log.w(TAG, "Maximum folder URIS reached ($MAX_FOLDER_URIS), cannot store more")
                    return false
                }

                val editor = mPreferences.edit()
                editor.putString(KEY_FOLDER_URI_PREFIX + uriString, folderPath)
                if (folderPath != null) {
                    editor.putString(KEY_PATH_URI_PREFIX + folderPath, uriString)
                }
                knownUris.add(uriString)
                editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris)
                editor.apply()

                Log.d(TAG, "Stored folder permission for: $folderPath")
                return true
            } finally {
                mWriteLock.unlock()
            }
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to store folder permission", exception)
            return false
        }
    }

    /**
     * Removes the mapping for the given folder URI.
     */
    fun removeFolderPermission(folderUri: Uri) {
        val uriString = folderUri.toString()
        val folderPath = getFolderPathFromUri(folderUri)

        mWriteLock.lock()
        try {
            val editor = mPreferences.edit()
            editor.remove(KEY_FOLDER_URI_PREFIX + uriString)
            if (folderPath != null) {
                editor.remove(KEY_PATH_URI_PREFIX + folderPath)
            }
            val knownUris = getKnownFolderUrisLocked()
            knownUris.remove(uriString)
            editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris)
            editor.apply()
            Log.d(TAG, "Removed folder permission for: $folderPath")
        } finally {
            mWriteLock.unlock()
        }
    }

    /**
     * Removes every stored folder URI mapping.
     */
    fun clearAll() {
        mWriteLock.lock()
        try {
            val editor = mPreferences.edit()
            val knownUris = getKnownFolderUrisLocked()
            for (uriString in knownUris) {
                editor.remove(KEY_FOLDER_URI_PREFIX + uriString)
                val folderPath = getFolderPathFromUriLocked(Uri.parse(uriString))
                if (folderPath != null) {
                    editor.remove(KEY_PATH_URI_PREFIX + folderPath)
                }
            }
            editor.remove(KEY_KNOWN_FOLDER_URIS)
            editor.apply()
            Log.d(TAG, "Cleared all folder permissions")
        } finally {
            mWriteLock.unlock()
        }
    }

    private fun getKnownFolderUrisLocked(): MutableSet<String> {
        val savedUris = mPreferences.getStringSet(KEY_KNOWN_FOLDER_URIS, null)
        val result = HashSet<String>()
        if (savedUris != null) {
            result.addAll(savedUris)
        }
        return result
    }

    /**
     * Returns a copy of every stored folder URI.
     */
    fun getAllFolderUris(): Set<String> {
        mReadLock.lock()
        try {
            return HashSet(getKnownFolderUrisLocked())
        } finally {
            mReadLock.unlock()
        }
    }

    /**
     * Returns the folder URI whose path is the longest prefix of
     * the given file path.
     */
    fun getFolderUri(filePath: String): Uri? {
        mReadLock.lock()
        try {
            var bestMatch: String? = null
            var bestUri: String? = null

            val allEntries = mPreferences.all
            for ((key, value) in allEntries) {
                if (key.startsWith(KEY_PATH_URI_PREFIX) &&
                    value is String
                ) {
                    val storedPath = key.substring(KEY_PATH_URI_PREFIX.length)
                    if (filePath.startsWith(storedPath) &&
                        (bestMatch == null || storedPath.length > bestMatch.length)
                    ) {
                        bestMatch = storedPath
                        bestUri = value
                    }
                }
            }

            return bestUri?.let { Uri.parse(it) }
        } finally {
            mReadLock.unlock()
        }
    }

    /**
     * Returns the document URI for the file at the given path,
     * resolved through the folder mapping that covers it.
     */
    fun getWriteableUriForFile(filePath: String): Uri? {
        val folderUri = getFolderUri(filePath) ?: run {
            Log.d(TAG, "No folder URI found for: $filePath")
            return null
        }

        val folderPath = getFolderPathFromUri(folderUri) ?: run {
            Log.d(TAG, "Could not extract folder path from URI: $folderUri")
            return null
        }

        val relativePath = filePath.substring(folderPath.length + 1)
        return getDocumentUriForFile(folderUri, relativePath)
    }

    private fun getDocumentUriForFile(folderUri: Uri, relativePath: String): Uri? {
        return try {
            var current: DocumentFile? = DocumentFile.fromTreeUri(mContext, folderUri)
            if (current == null || !current.canRead()) {
                Log.w(TAG, "Cannot read folder: $folderUri")
                return null
            }

            val parts = relativePath.split("/")
            for (part in parts) {
                val child = current.findFile(part)
                if (child == null) {
                    Log.w(TAG, "File not found: $part in path $relativePath")
                    return null
                }
                current = child
            }

            current.uri
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to get document URI", exception)
            null
        }
    }

    /**
     * Takes a persistable URI permission for the given file.
     */
    fun takeFilePermission(fileUri: Uri): Boolean {
        return try {
            mContext.contentResolver.takePersistableUriPermission(
                fileUri, URI_PERMISSION_FLAGS
            )
            Log.d(TAG, "Took persistable permission for: $fileUri")
            true
        } catch (exception: SecurityException) {
            Log.e(TAG, "Failed to take persistable permission", exception)
            false
        }
    }

    /**
     * Ensures the given URI has write permission, taking a
     * persistable permission when needed.
     */
    fun reacquirePermission(uri: Uri): Boolean {
        try {
            try {
                val document = DocumentFile.fromSingleUri(mContext, uri)
                if (document != null && document.canWrite()) {
                    Log.d(TAG, "Already have write permission for: $uri")
                    return true
                }
            } catch (exception: Exception) {
                Log.w(TAG, "Permission check failed, attempting to reacquire", exception)
            }

            mContext.contentResolver.takePersistableUriPermission(
                uri, URI_PERMISSION_FLAGS
            )
            Log.d(TAG, "Reacquired permission for: $uri")
            return true
        } catch (exception: SecurityException) {
            Log.e(TAG, "Failed to reacquire permission", exception)
            return false
        }
    }

    /**
     * Returns whether the given URI currently grants write
     * permission.
     */
    fun validatePermission(uri: Uri): Boolean {
        return try {
            val document = DocumentFile.fromSingleUri(mContext, uri)
            val hasPermission = document != null && document.canWrite()
            Log.d(TAG, "Permission validation for $uri: $hasPermission")
            hasPermission
        } catch (exception: Exception) {
            Log.w(TAG, "Permission validation failed", exception)
            false
        }
    }

    // ========================================================================
    // URI Path Extraction
    // ========================================================================

    /**
     * Returns the filesystem path stored for the given folder URI,
     * or extracts it from the URI when no mapping is stored.
     */
    fun getFolderPathFromUri(uri: Uri?): String? {
        if (uri == null) return null
        mReadLock.lock()
        try {
            return getFolderPathFromUriLocked(uri)
        } finally {
            mReadLock.unlock()
        }
    }

    private fun getFolderPathFromUriLocked(uri: Uri?): String? {
        if (uri == null) return null

        // Fast path: the mapping persisted at import time.
        val storedPath = mPreferences.getString(
            KEY_FOLDER_URI_PREFIX + uri.toString(), null
        )
        if (storedPath != null) {
            return storedPath
        }

        // Slow path: parse the tree URI.
        val uriString = uri.toString()
        val treeIndex = uriString.indexOf("/tree/")
        if (treeIndex < 0) {
            return null
        }

        var encoded = uriString.substring(treeIndex + "/tree/".length)

        // A document suffix can trail the tree segment on nested
        // URIs; strip it so only the volume-relative path remains.
        val documentIndex = encoded.indexOf("/document/")
        if (documentIndex >= 0) {
            encoded = encoded.substring(0, documentIndex)
        }

        val decoded = try {
            Uri.decode(encoded)
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to decode tree URI", exception)
            return null
        }

        val colonIndex = decoded.indexOf(':')
        if (colonIndex < 0) {
            return null
        }

        val volumeName = decoded.substring(0, colonIndex)
        val relativePath = decoded.substring(colonIndex + 1)

        val mountPoint = if ("primary".equals(volumeName, ignoreCase = true)) {
            "/storage/emulated/0"
        } else {
            "/storage/$volumeName"
        }

        var fullPath = if (relativePath.isEmpty()) {
            mountPoint
        } else {
            "$mountPoint/$relativePath"
        }

        while (fullPath.endsWith("/") && fullPath.length > 1) {
            fullPath = fullPath.substring(0, fullPath.length - 1)
        }

        return fullPath
    }

    /**
     * Returns the cleaned display name of the given folder URI.
     */
    fun getFolderNameFromUri(uri: Uri?): String? {
        if (uri == null) return null

        var name: String? = null
        var cursor: Cursor? = null
        try {
            cursor = mContext.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex)
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getFolderName error", exception)
        } finally {
            if (cursor != null) {
                try {
                    cursor.close()
                } catch (exception: Exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception)
                }
            }
        }

        if (name == null && uri.lastPathSegment != null) {
            var segment: String? = uri.lastPathSegment
            if (segment != null && segment.contains(":")) {
                segment = segment.substring(segment.indexOf(":") + 1)
            }
            name = segment
        }

        return name?.let { CharacterMapper.cleanString(it) }
    }

    /**
     * Returns a label identifying the storage type of the given
     * folder URI, such as `"[Internal]"` or `"[SD Card]"`.
     */
    fun getStorageType(uriString: String): String {
        val uriLower = uriString.lowercase()
        val localeContext = getLocaleContext()

        return when {
            uriLower.contains("primary") || uriLower.contains("emulated") ->
                localeContext.getString(R.string.folder_manager_storage_internal)
            uriLower.contains("external") ||
                uriLower.contains("sdcard") ||
                uriLower.contains("extsdcard") ||
                uriLower.contains("extsd") ||
                Regex(".*[0-9a-f]{4}-[0-9a-f]{4}.*").matches(uriLower) ->
                localeContext.getString(R.string.folder_manager_storage_sd_card)
            else -> ""
        }
    }

    // ========================================================================
    // Scanning
    // ========================================================================

    /**
     * Recursively scans the given folder URI for audio files.
     */
    fun scanFolderForAudioFiles(folderUri: Uri): List<DocumentFile> {
        val audioFiles = ArrayList<DocumentFile>()
        try {
            val folder = DocumentFile.fromTreeUri(mContext, folderUri)
            if (folder == null || !folder.exists() || !folder.canRead()) {
                Log.w(TAG, "Cannot read folder: $folderUri")
                return audioFiles
            }
            scanDocumentFileForAudioFiles(folder, audioFiles)
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to scan folder", exception)
        }
        return audioFiles
    }

    private fun scanDocumentFileForAudioFiles(
        document: DocumentFile,
        results: MutableList<DocumentFile>
    ) {
        if (document.isFile && isAudioFile(document.name)) {
            results.add(document)
        } else if (document.isDirectory) {
            val children = document.listFiles()
            for (child in children) {
                if (child != null) {
                    scanDocumentFileForAudioFiles(child, results)
                }
            }
        }
    }

    private fun isAudioFile(name: String?): Boolean {
        if (name == null) return false
        val lower = name.lowercase()
        return lower.endsWith(".mp3") || lower.endsWith(".flac") ||
            lower.endsWith(".ogg") || lower.endsWith(".m4a") ||
            lower.endsWith(".mp4") || lower.endsWith(".wav") ||
            lower.endsWith(".aac") || lower.endsWith(".wma")
    }

    // ========================================================================
    // Utility
    // ========================================================================

    fun getStoredFolderCount(): Int {
        mReadLock.lock()
        try {
            return getKnownFolderUrisLocked().size
        } finally {
            mReadLock.unlock()
        }
    }

    fun isFolderStored(folderUri: Uri): Boolean {
        val uriString = folderUri.toString()
        mReadLock.lock()
        try {
            return mPreferences.contains(KEY_FOLDER_URI_PREFIX + uriString)
        } finally {
            mReadLock.unlock()
        }
    }

    fun getDebugInfo(): String {
        val builder = StringBuilder()
        builder.append("StorageAccessHelper Debug Info:\n")
        builder.append("  Stored folder URIs: ")
            .append(getStoredFolderCount()).append("\n")

        mReadLock.lock()
        try {
            val knownUris = getKnownFolderUrisLocked()
            for (uriString in knownUris) {
                val folderPath = mPreferences.getString(
                    KEY_FOLDER_URI_PREFIX + uriString, null
                )
                builder.append("    - URI: ").append(uriString).append("\n")
                builder.append("      Path: ").append(folderPath).append("\n")
            }
        } finally {
            mReadLock.unlock()
        }

        return builder.toString()
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val TAG = "StorageAccessHelper"

        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_FOLDER_URI_PREFIX = "folder_uri_"
        private const val KEY_PATH_URI_PREFIX = "path_uri_"
        private const val KEY_KNOWN_FOLDER_URIS = "known_folder_uris"

        private const val URI_PERMISSION_FLAGS: Int =
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION

        private const val MAX_FOLDER_URIS = 100

        @Volatile
        private var sInstance: StorageAccessHelper? = null

        @JvmStatic
        fun getInstance(context: Context): StorageAccessHelper {
            if (sInstance == null) {
                synchronized(StorageAccessHelper::class.java) {
                    if (sInstance == null) {
                        sInstance = StorageAccessHelper(context.applicationContext)
                    }
                }
            }
            return sInstance!!
        }
    }
}