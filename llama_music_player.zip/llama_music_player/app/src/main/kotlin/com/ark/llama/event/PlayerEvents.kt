// PlayerEvents.kt
package com.ark.llama.event

import com.ark.llama.PlaybackWindow

/**
 * Player-surface events posted on the process EventBus.
 *
 * <p>Producer: [com.ark.llama.MusicService]. The service posts a
 * sticky [Snapshot] on every broadcastUpdate() and posts an
 * [ApplyScope] in response to the scope picker's Apply tap. Every
 * consumer — the player activity, the playlist activity, the
 * notification controller, the carousel — subscribes to what it
 * needs.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface PlayerEvent {

    /**
     * The full playback snapshot the service publishes on every
     * transition, pause, resume, seek, or metadata poke.
     *
     * <p>Sticky. A consumer that registers after the last transition
     * receives the current snapshot immediately on registration, so
     * a freshly created activity is in sync with the service without
     * a separate query round.</p>
     *
     * <p>The [generation] field is the service's monotonic transition
     * counter. Every consumer drops a snapshot whose generation is
     * strictly lower than the highest it has seen, so an out-of-order
     * delivery cannot roll the surface backwards. The generation
     * advances only when a fresh transition begins, which is what
     * lets a repeat-one restart — whose three window paths are
     * unchanged — be distinguished from a re-publication.</p>
     *
     * @property generation Service's monotonic transition counter
     * @property stateName Name of the ServiceState enum's current
     *        value; consumed by consumers that switch on state
     * @property currentIndex Index the MediaPlayer is bound to
     * @property targetIndex Index the state machine is driving toward
     * @property songPath Path of the current song, or null
     * @property targetSongPath Path of the target song, or null
     * @property isPlaying True when the state machine is in PLAYING
     * @property positionMs Current playback position
     * @property durationMs Duration of the current track
     * @property window The three-slot window the carousel renders
     * @property transitionDirection +1 forward, -1 backward, 0 none
     * @property transitionRestart True when the transition restarts
     *        the current song
     * @property displayTitle Title the player screen should show
     * @property displayArtist Artist the player screen should show
     * @property isFavorite Favorite flag of the currently bound song
     * @property scopeKind Name of the PlaybackScope.Kind in effect
     * @property scopeCount Number of songs in the scoped playlist
     */
    data class Snapshot(
        val generation: Long,
        val stateName: String,
        val currentIndex: Int,
        val targetIndex: Int,
        val songPath: String?,
        val targetSongPath: String?,
        val isPlaying: Boolean,
        val positionMs: Int,
        val durationMs: Int,
        val window: PlaybackWindow,
        val transitionDirection: Int,
        val transitionRestart: Boolean,
        val displayTitle: String?,
        val displayArtist: String?,
        val isFavorite: Boolean,
        val scopeKind: String,
        val scopeCount: Int
    ) : PlayerEvent

    /**
     * The scope picker's Apply tap. Carries the serialized
     * [com.ark.llama.PlaybackScope] the user selected.
     *
     * <p>The service deserializes the scope and applies it as the
     * active playback scope. Using a serialized string rather than
     * a live [com.ark.llama.PlaybackScope] instance keeps the event
     * a plain value with no class-identity dependency in the
     * consumer.</p>
     *
     * @property serializedScope The serialized scope
     */
    data class ApplyScope(
        val serializedScope: String
    ) : PlayerEvent
}