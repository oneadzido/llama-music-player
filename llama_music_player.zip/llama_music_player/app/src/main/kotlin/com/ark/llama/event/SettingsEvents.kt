// SettingsEvents.kt
package com.ark.llama.event

/**
 * Settings-surface events posted on the process EventBus.
 *
 * <p>Both events are sticky. A consumer that registers after the last
 * change receives the current value on registration, so a freshly
 * created activity or dialog always sees the current settings without
 * a separate query path. This is what lets every activity answer a
 * settings change with a recreate: the sticky event is already on the
 * bus when the recreated activity's register call runs, so it fires
 * on the same turn.</p>
 *
 * <p>Producers: [com.ark.llama.LanguageManager] posts
 * [LanguageChanged]; [com.ark.llama.ThemeManager] posts
 * [ThemeColorChanged].</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface SettingsEvent {

    /**
     * The app's display language has changed.
     *
     * <p>Posted by [com.ark.llama.LanguageManager.setLanguage] after
     * the in-memory tag and the persisted preference have both been
     * updated. Every activity subscribes in STICKY mode and answers
     * with a posted recreate. Dialogs that are open at the moment
     * of the change subscribe in STICKY mode and dismiss
     * themselves; the next open rebuilds against the new language.</p>
     *
     * @property languageTag The BCP 47 tag of the new language
     */
    data class LanguageChanged(
        val languageTag: String
    ) : SettingsEvent

    /**
     * The app's theme color has changed.
     *
     * <p>Posted by [com.ark.llama.ThemeManager.setThemeColor] after
     * the index and the hex value have both been updated and
     * persisted. Every activity subscribes in STICKY mode and
     * answers with a posted recreate.
     * [com.ark.llama.NotificationController] subscribes in STICKY
     * mode and rebuilds its notification chrome from the persisted
     * theme on the next commit.</p>
     *
     * @property colorIndex Index of the new theme in the color arrays
     * @property colorValue Hex color value of the new theme
     */
    data class ThemeColorChanged(
        val colorIndex: Int,
        val colorValue: String
    ) : SettingsEvent
}