// ThemeHelper.kt
package com.ark.llama

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.core.content.ContextCompat
import java.lang.reflect.Field
import java.lang.reflect.Method

/**
 * Applies the current theme color to UI components.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class ThemeHelper private constructor(context: Context) {

    private val mContext: Context = context.applicationContext

    var themeColor: String = "#B8A86E"

    fun setThemeColor(color: String) {
        themeColor = color
    }

    fun getThemeColor(): String = themeColor

    val themeColorInt: Int
        get() = try {
            Color.parseColor(themeColor)
        } catch (exception: IllegalArgumentException) {
            Log.e(TAG, "Invalid theme color: $themeColor")
            DEFAULT_COLOR
        }

    val mutedThemeColorInt: Int
        get() {
            val fullColor = themeColorInt
            return Color.argb(
                102,
                Color.red(fullColor),
                Color.green(fullColor),
                Color.blue(fullColor)
            )
        }

    fun dpToPx(dp: Int): Int =
        Math.round(
            dp * mContext.resources.displayMetrics.density
        )

    fun createThemedAlbumArtPlaceholder(): Drawable? {
        val drawable = ContextCompat.getDrawable(
            mContext, R.drawable.album_art_placeholder
        )
        drawable?.setColorFilter(themeColorInt, PorterDuff.Mode.SRC_IN)
        return drawable
    }

    fun updateButton(button: Button?, isEnabled: Boolean) {
        if (button == null) return

        button.isSingleLine = true
        button.ellipsize = TextUtils.TruncateAt.END
        button.maxLines = 1
        button.setHorizontallyScrolling(false)

        val currentThemeColor = themeColorInt
        val strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP)
        val cornerRadius = dpToPx(BUTTON_CORNER_RADIUS_DP)
        val inset = dpToPx(BUTTON_INSET_DP)

        val normalDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(
                strokeWidth,
                if (isEnabled) currentThemeColor else COLOR_DISABLED
            )
            setColor(Color.TRANSPARENT)
        }
        val normalInset = InsetDrawable(normalDrawable, inset)

        val pressedDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(strokeWidth, currentThemeColor)
            setColor(COLOR_PRESSED_BG)
        }
        val pressedInset = InsetDrawable(pressedDrawable, inset)

        val disabledDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(strokeWidth, COLOR_DISABLED)
            setColor(COLOR_NORMAL_BG)
        }
        val disabledInset = InsetDrawable(disabledDrawable, inset)

        val stateList = StateListDrawable()
        stateList.addState(
            intArrayOf(android.R.attr.state_pressed), pressedInset
        )
        stateList.addState(
            intArrayOf(android.R.attr.state_focused), pressedInset
        )
        stateList.addState(
            intArrayOf(-android.R.attr.state_enabled), disabledInset
        )

        val colorStates = arrayOf(
            intArrayOf(android.R.attr.state_pressed),
            intArrayOf(android.R.attr.state_focused),
            intArrayOf(-android.R.attr.state_enabled),
            intArrayOf()
        )

        if (isEnabled) {
            stateList.addState(intArrayOf(), normalInset)
            val colors = intArrayOf(
                Color.WHITE,
                Color.WHITE,
                COLOR_DISABLED,
                currentThemeColor
            )
            button.setTextColor(ColorStateList(colorStates, colors))
        } else {
            stateList.addState(intArrayOf(), disabledInset)
            button.setTextColor(COLOR_DISABLED)
        }

        button.background = stateList
        button.setPadding(dpToPx(8), 0, dpToPx(8), 0)
        button.includeFontPadding = false
        button.gravity = Gravity.CENTER
    }

    fun updateButtonPendingState(
        button: TextView,
        isPending: Boolean,
        dangerColor: Int
    ) {
        if (!isPending) {
            updateControlButton(button, button.isEnabled, false)
            return
        }

        val currentThemeColor = themeColorInt
        val pureWhite = Color.WHITE

        val isRedTheme =
            Math.abs(Color.red(currentThemeColor) - Color.red(dangerColor)) < 50 &&
                Math.abs(Color.green(currentThemeColor) - Color.green(dangerColor)) < 50 &&
                Math.abs(Color.blue(currentThemeColor) - Color.blue(dangerColor)) < 50

        val contrastColor = if (isRedTheme) pureWhite else dangerColor

        val cornerRadius = dpToPx(CONTROL_BUTTON_CORNER_RADIUS_DP)
        val strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP)

        val pendingDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(strokeWidth, contrastColor)
            setColor(COLOR_NORMAL_BG)
        }

        button.background = pendingDrawable
        button.setTextColor(contrastColor)
    }

    fun updateControlButton(
        button: TextView?,
        isEnabled: Boolean,
        isActive: Boolean
    ) {
        if (button == null) return

        val currentThemeColor = themeColorInt
        val cornerRadius = dpToPx(CONTROL_BUTTON_CORNER_RADIUS_DP)
        val strokeWidth = dpToPx(BUTTON_STROKE_WIDTH_DP)

        val normalDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(
                strokeWidth,
                if (isActive) currentThemeColor else CONTROL_BUTTON_INACTIVE_COLOR
            )
            setColor(COLOR_NORMAL_BG)
        }

        val pressedDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(strokeWidth, currentThemeColor)
            setColor(COLOR_PRESSED_BG)
        }

        val disabledDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            this.cornerRadius = cornerRadius.toFloat()
            setStroke(strokeWidth, COLOR_DISABLED)
            setColor(COLOR_NORMAL_BG)
        }

        val stateList = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressedDrawable)
            addState(intArrayOf(android.R.attr.state_focused), pressedDrawable)
            addState(intArrayOf(-android.R.attr.state_enabled), disabledDrawable)
            addState(intArrayOf(), normalDrawable)
        }

        button.background = stateList
        button.setPadding(0, 0, 0, 0)
        button.gravity = Gravity.CENTER

        val colorStates = arrayOf(
            intArrayOf(android.R.attr.state_pressed),
            intArrayOf(android.R.attr.state_focused),
            intArrayOf(-android.R.attr.state_enabled),
            intArrayOf()
        )

        if (isEnabled) {
            val colors = intArrayOf(
                currentThemeColor,
                currentThemeColor,
                COLOR_DISABLED,
                if (isActive) currentThemeColor else CONTROL_BUTTON_INACTIVE_COLOR
            )
            button.setTextColor(ColorStateList(colorStates, colors))
        } else {
            val colors = intArrayOf(
                COLOR_DISABLED, COLOR_DISABLED,
                COLOR_DISABLED, COLOR_DISABLED
            )
            button.setTextColor(ColorStateList(colorStates, colors))
        }
    }

    fun updateSeekBar(seekBar: SeekBar?, isEnabled: Boolean) {
        if (seekBar == null) return

        val progressColor = if (isEnabled) themeColorInt else COLOR_DISABLED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.progressTintList = ColorStateList.valueOf(progressColor)
            seekBar.thumbTintList = ColorStateList.valueOf(progressColor)
        }

        seekBar.thumb = null
        seekBar.isEnabled = isEnabled
    }

    fun updateTextView(textView: TextView?, isAccent: Boolean) {
        if (textView == null) return
        if (isAccent) {
            textView.setTextColor(themeColorInt)
        }
    }

    fun updateEditText(editText: EditText) {
        val currentThemeColor = themeColorInt
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            editText.highlightColor = Color.argb(
                40,
                Color.red(currentThemeColor),
                Color.green(currentThemeColor),
                Color.blue(currentThemeColor)
            )
        }
    }

    fun setCursorColor(editText: EditText, @ColorInt color: Int) {
        val cursorDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            setSize(dpToPx(CURSOR_WIDTH_DP), dpToPx(CURSOR_HEIGHT_DP))
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val method: Method = EditText::class.java.getMethod(
                    "setTextCursorDrawable", Drawable::class.java
                )
                method.invoke(editText, cursorDrawable)
                return
            } catch (exception: NoSuchMethodException) {
                Log.d(TAG, "setTextCursorDrawable not available, " +
                    "using reflection fallback")
            } catch (exception: Exception) {
                Log.w(TAG,
                    "setTextCursorDrawable failed, using reflection fallback",
                    exception)
            }
        }

        try {
            val cursorResField: Field = TextView::class.java
                .getDeclaredField("mCursorDrawableRes")
            cursorResField.isAccessible = true
            cursorResField.set(editText, 0)

            val editorField: Field = TextView::class.java
                .getDeclaredField("mEditor")
            editorField.isAccessible = true
            val editor = editorField.get(editText)

            if (editor != null) {
                val cursorField: Field = editor.javaClass
                    .getDeclaredField("mCursorDrawable")
                cursorField.isAccessible = true
                cursorField.set(
                    editor,
                    arrayOf<Drawable>(cursorDrawable, cursorDrawable)
                )
                editText.invalidate()
            }
        } catch (exception: Exception) {
            Log.e(TAG, "Cursor reflection failed", exception)
        }
    }

    fun updateEditTextCursor(editText: EditText) {
        val currentThemeColor = themeColorInt
        setCursorColor(editText, currentThemeColor)

        val hintColor = Color.argb(
            102,
            Color.red(currentThemeColor),
            Color.green(currentThemeColor),
            Color.blue(currentThemeColor)
        )
        editText.setHintTextColor(hintColor)

        editText.onFocusChangeListener =
            View.OnFocusChangeListener { view, hasFocus ->
                if (hasFocus && view is EditText) {
                    setCursorColor(view, themeColorInt)
                }
            }
    }

    fun updateRadio(
        indicator: TextView,
        selected: Boolean,
        enabled: Boolean
    ) {
        val currentThemeColor = themeColorInt
        val strokeColor = when {
            !enabled -> COLOR_DISABLED
            selected -> currentThemeColor
            else -> CONTROL_BUTTON_INACTIVE_COLOR
        }
        val innerColor = when {
            !selected -> Color.TRANSPARENT
            enabled -> currentThemeColor
            else -> COLOR_DISABLED
        }

        val outer = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
            setStroke(dpToPx(BUTTON_STROKE_WIDTH_DP), strokeColor)
        }

        if (innerColor != Color.TRANSPARENT) {
            val inner = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(innerColor)
            }
            val inset = dpToPx(6)
            val layer = LayerDrawable(
                arrayOf<Drawable>(outer, inner)
            )
            layer.setLayerInset(1, inset, inset, inset, inset)
            indicator.background = layer
        } else {
            indicator.background = outer
        }
        indicator.text = ""
        indicator.typeface = null
    }

    fun updateCheckbox(
        indicator: TextView,
        checked: Boolean,
        enabled: Boolean
    ) {
        val currentThemeColor = themeColorInt
        val strokeColor = when {
            !enabled -> COLOR_DISABLED
            checked -> currentThemeColor
            else -> CONTROL_BUTTON_INACTIVE_COLOR
        }
        val glyphColor = when {
            !enabled && checked -> COLOR_DISABLED
            !enabled -> Color.TRANSPARENT
            checked -> currentThemeColor
            else -> Color.TRANSPARENT
        }

        val box = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(4).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dpToPx(BUTTON_STROKE_WIDTH_DP), strokeColor)
        }
        indicator.background = box

        indicator.typeface = FontAwesome.getTypeface()
        indicator.text = if (checked) FontAwesome.CHECK else ""
        indicator.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        indicator.setTextColor(glyphColor)
        indicator.gravity = Gravity.CENTER
        indicator.includeFontPadding = false
    }

    companion object {

        private const val TAG = "ThemeHelper"

        @JvmField
        val COLOR_TEXT_PRIMARY: Int = 0xFFC0C0C0.toInt()

        @JvmField
        val COLOR_TEXT_SECONDARY: Int = 0xFFA0A0A0.toInt()

        @JvmField
        val COLOR_TEXT_HINT: Int = 0xFF5A5A5A.toInt()

        @JvmField
        val CONTROL_BUTTON_INACTIVE_COLOR: Int = 0xFFA0A0A0.toInt()

        @JvmField
        val DEFAULT_COLOR: Int = 0xFFB8A86E.toInt()

        private val COLOR_PRESSED_BG: Int = 0xFF2A2A2A.toInt()
        private val COLOR_DISABLED: Int = 0xFF5A5A5A.toInt()
        private val COLOR_NORMAL_BG: Int = 0xFF1E1E1E.toInt()

        private const val BUTTON_CORNER_RADIUS_DP = 10
        private const val CONTROL_BUTTON_CORNER_RADIUS_DP = 8
        private const val BUTTON_STROKE_WIDTH_DP = 1
        private const val BUTTON_INSET_DP = 2
        private const val CURSOR_WIDTH_DP = 1
        private const val CURSOR_HEIGHT_DP = 16

        @Volatile
        private var sInstance: ThemeHelper? = null

        @JvmStatic
        fun getInstance(context: Context): ThemeHelper {
            if (sInstance == null) {
                synchronized(ThemeHelper::class.java) {
                    if (sInstance == null) {
                        sInstance = ThemeHelper(context)
                    }
                }
            }
            return sInstance!!
        }

        @JvmStatic
        @ColorInt
        fun getDefaultColor(): Int = DEFAULT_COLOR
    }
}