// OverlayManager.kt
package com.ark.llama

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import java.lang.ref.WeakReference
import java.util.HashMap
import java.util.HashSet

/**
 * The dim-and-spinner overlay, process-wide and reason-keyed.
 *
 * <p>The overlay is a dim [FrameLayout] covering the current
 * activity's content view, with a rotating ring spinner centred in
 * it. It answers one question for the user: <em>is the app
 * working?</em></p>
 *
 * <h3>Process-Wide, Not Per-Activity</h3>
 * <p>The overlay is a singleton. When the activity in front changes,
 * the overlay is reattached to the new activity's content view
 * without the reason set being touched.</p>
 *
 * <h3>Ownership by Reason</h3>
 * <p>Visibility is by <b>reason token</b>. Each caller that wants
 * the overlay visible holds a reason; the overlay is visible while
 * at least one reason is held. The token is a string chosen by the
 * caller, stable across the operation it owns (for example,
 * [REASON_COLD_START] while the library is loading).</p>
 *
 * <h3>Stuck Timeout</h3>
 * <p>A reason held longer than [STUCK_TIMEOUT_MS] is released
 * automatically by a periodic health check running every
 * [HEALTH_CHECK_INTERVAL_MS]. The release is logged at warn level
 * so an orphaned reason is visible in logcat; the mechanism exists
 * so a code path that fails to call [hide] cannot leave the spinner
 * running forever.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. The reason set
 * and the attachment state are touched only from the main
 * thread.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.2.0
 */
class OverlayManager private constructor(context: Context) :
    Application.ActivityLifecycleCallbacks {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mHealthHandler = Handler(Looper.getMainLooper())

    /** The set of reasons currently held. Overlay visible iff non-empty. */
    private val mReasons = HashSet<String>()

    /** The wall-clock at which each reason was acquired. */
    private val mReasonShowTimes = HashMap<String, Long>()

    /** The activity the framework most recently resumed. */
    private var mCurrentActivityRef: WeakReference<Activity>? = null

    /** The activity the overlay is currently attached to, or null. */
    private var mAttachedActivityRef: WeakReference<Activity>? = null

    /** The container view the overlay is drawn in, or null. */
    private var mContainer: FrameLayout? = null

    /** The spinner inside [mContainer], or null. */
    private var mSpinner: SpinnerView? = null

    /** Current theme color of the spinner arc. */
    private var mColor: Int = DEFAULT_COLOR

    /** The repeating health-check runnable. */
    private var mHealthCheckRunnable: Runnable? = null

    /** True once the lifecycle callbacks have been registered. */
    private var mCallbacksRegistered: Boolean = false

    init {
        sApplication = context.applicationContext as Application
        registerLifecycleCallbacks()
        startHealthCheck()
        Log.d(TAG, "OverlayManager initialized")
    }

    // ========================================================================
    // Lifecycle registration
    // ========================================================================

    private fun registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) return
        sApplication?.registerActivityLifecycleCallbacks(this)
        mCallbacksRegistered = true
        Log.d(TAG, "Activity lifecycle callbacks registered")
    }

    override fun onActivityResumed(activity: Activity) {
        mCurrentActivityRef = WeakReference(activity)
        if (mReasons.isEmpty()) return
        val attached = mAttachedActivityRef?.get()
        if (attached !== activity) {
            detach()
            attach(activity)
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {
        if (mAttachedActivityRef?.get() === activity) {
            mContainer = null
            mSpinner = null
            mAttachedActivityRef = null
        }
        if (mCurrentActivityRef?.get() === activity) mCurrentActivityRef = null
    }

    // ========================================================================
    // Show / hide internals
    // ========================================================================

    private fun showInternal(reason: String) {
        val wasEmpty = mReasons.isEmpty()
        if (!mReasons.add(reason)) return
        mReasonShowTimes[reason] = SystemClock.elapsedRealtime()
        if (!wasEmpty) return
        val activity = mCurrentActivityRef?.get() ?: return
        if (!activity.isFinishing && !activity.isDestroyed) attach(activity)
    }

    private fun hideInternal(reason: String) {
        if (!mReasons.remove(reason)) return
        mReasonShowTimes.remove(reason)
        if (mReasons.isNotEmpty()) return
        detach()
    }

    // ========================================================================
    // Attachment
    // ========================================================================

    private fun attach(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        val attached = mAttachedActivityRef?.get()
        if (attached === activity && mContainer != null) return
        detach()

        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return

        val container = FrameLayout(activity).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(
                Color.argb(
                    DIM_ALPHA,
                    Color.red(DIM_RGB),
                    Color.green(DIM_RGB),
                    Color.blue(DIM_RGB)
                )
            )
            isClickable = true
            isFocusable = true
        }

        val spinner = SpinnerView(activity).apply {
            setColor(mColor)
            val size = dpToPx(activity, SPINNER_DIAMETER_DP)
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.CENTER
            }
        }

        container.addView(spinner)
        root.addView(container)

        mContainer = container
        mSpinner = spinner
        mAttachedActivityRef = WeakReference(activity)
    }

    private fun detach() {
        mContainer?.let { container ->
            (container.parent as? ViewGroup)?.removeView(container)
        }
        mContainer = null
        mSpinner = null
        mAttachedActivityRef = null
    }

    private fun dpToPx(context: Context, dp: Int): Int =
        Math.round(dp * context.resources.displayMetrics.density)

    // ========================================================================
    // Health check
    // ========================================================================

    private fun startHealthCheck() {
        if (mHealthCheckRunnable != null) return
        val runnable = object : Runnable {
            override fun run() {
                performHealthCheck()
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS)
                }
            }
        }
        mHealthCheckRunnable = runnable
        mHealthHandler.postDelayed(runnable, HEALTH_CHECK_INTERVAL_MS)
    }

    private fun performHealthCheck() {
        if (mReasons.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val iterator = mReasonShowTimes.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val age = now - entry.value
            if (age > STUCK_TIMEOUT_MS) {
                Log.w(TAG, "Releasing stuck reason '${entry.key}' after ${age}ms")
                mReasons.remove(entry.key)
                iterator.remove()
            }
        }
        if (mReasons.isEmpty()) detach()
    }

    // ========================================================================
    // Shutdown
    // ========================================================================

    fun shutdown() {
        Log.d(TAG, "Shutting down OverlayManager")
        mHealthCheckRunnable?.let { mHealthHandler.removeCallbacks(it) }
        mHealthCheckRunnable = null
        if (mCallbacksRegistered && sApplication != null) {
            try {
                sApplication?.unregisterActivityLifecycleCallbacks(this)
                mCallbacksRegistered = false
            } catch (ignored: Exception) {}
        }
        detach()
        mReasons.clear()
        mReasonShowTimes.clear()
        sInstance = null
        sApplication = null
    }

    // ========================================================================
    // Spinner view
    // ========================================================================

    private class SpinnerView(context: Context) : View(context) {

        private val mTrackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val mArcPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val mArcBounds = RectF()

        private var mRotation: ObjectAnimator? = null

        init {
            mTrackPaint.style = Paint.Style.STROKE
            mTrackPaint.strokeCap = Paint.Cap.ROUND
            mArcPaint.style = Paint.Style.STROKE
            mArcPaint.strokeCap = Paint.Cap.ROUND
            isClickable = false
            isFocusable = false
        }

        fun setColor(color: Int) {
            mArcPaint.color = color
            mTrackPaint.color = (color and 0x00FFFFFF) or (TRACK_ALPHA shl 24)
            invalidate()
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            startRotation()
        }

        override fun onDetachedFromWindow() {
            super.onDetachedFromWindow()
            stopRotation()
        }

        private fun startRotation() {
            if (mRotation?.isRunning == true) return
            mRotation = ObjectAnimator.ofFloat(this, "rotation", 0f, 360f).apply {
                duration = ROTATION_PERIOD_MS
                repeatCount = ObjectAnimator.INFINITE
                interpolator = LinearInterpolator()
                start()
            }
        }

        private fun stopRotation() {
            mRotation?.cancel()
            mRotation = null
        }

        override fun onDraw(canvas: Canvas) {
            val centerX = width / 2f
            val centerY = height / 2f
            val stroke = resources.displayMetrics.density * SPINNER_STROKE_DP
            val radius = Math.min(centerX, centerY) - stroke / 2f

            mTrackPaint.strokeWidth = stroke
            mArcPaint.strokeWidth = stroke

            canvas.drawCircle(centerX, centerY, radius, mTrackPaint)

            mArcBounds.set(
                centerX - radius, centerY - radius,
                centerX + radius, centerY + radius
            )
            canvas.drawArc(mArcBounds, -90f, BRIGHT_ARC_SWEEP_DEGREES.toFloat(), false, mArcPaint)
        }
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val TAG = "OverlayManager"

        const val REASON_COLD_START: String = "MusicPlayer.COLD_START"
        const val REASON_METADATA_LOAD: String = "MetadataEditor.METADATA_LOAD"
        const val REASON_FOLDER_UPDATE_CYCLE: String = "FolderUpdateCycle"
        const val REASON_PLAYLIST_SORT: String = "PlaylistActivity.PLAYLIST_SORT"

        private const val DIM_ALPHA = 180
        private const val DIM_RGB = 0x121212
        private const val SPINNER_DIAMETER_DP = 32
        private const val SPINNER_STROKE_DP = 2
        private const val BRIGHT_ARC_SWEEP_DEGREES = 90
        private const val ROTATION_PERIOD_MS = 1000L
        private const val TRACK_ALPHA = 0x4D
        private val DEFAULT_COLOR = 0xFFB8A86E.toInt()
        private const val HEALTH_CHECK_INTERVAL_MS = 5000L
        private const val STUCK_TIMEOUT_MS = 30000L

        @Volatile private var sInstance: OverlayManager? = null
        @Volatile private var sApplication: Application? = null

        @JvmStatic
        @Synchronized
        fun init(context: Context) {
            if (sInstance == null) {
                sInstance = OverlayManager(context)
            }
        }

        private fun getInstance(): OverlayManager =
            sInstance ?: throw IllegalStateException(
                "OverlayManager not initialized. Call init() first."
            )

        @JvmStatic
        fun show(reason: String) {
            val manager = getInstance()
            manager.mMainHandler.post { manager.showInternal(reason) }
        }

        @JvmStatic
        fun hide(reason: String) {
            val manager = getInstance()
            manager.mMainHandler.post { manager.hideInternal(reason) }
        }

        @JvmStatic
        fun setColor(color: Int) {
            val manager = getInstance()
            manager.mMainHandler.post {
                manager.mColor = color
                manager.mSpinner?.setColor(color)
            }
        }

        @JvmStatic
        fun isShowing(): Boolean = getInstance().mReasons.isNotEmpty()

        @JvmStatic
        fun isShowing(reason: String?): Boolean {
            if (reason == null) return false
            return getInstance().mReasons.contains(reason)
        }

        @JvmStatic
        fun shutdownGlobal() {
            sInstance?.shutdown()
        }
    }
}