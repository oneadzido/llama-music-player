// MetadataEditor.kt
package com.ark.llama

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputFilter
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.MetadataEvent
import com.ark.llama.event.SettingsEvent
import com.ark.llama.event.TransportEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Edits the ID3 tags and album art of an audio file.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class MetadataEditor : Activity(), NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    private val GALLERY_REQUEST_CODE = 400
    private val PERMISSION_GALLERY_REQUEST = 401
    private val REQUEST_SAF_FILE_PICKER = 402

    private val MODE_VIEW = 0
    private val MODE_EDIT = 1

    private val SONG_STATE_NOT_CURRENT = 0
    private val SONG_STATE_WAS_PLAYING = 1
    private val SONG_STATE_WAS_PAUSED = 2

    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f

    private val MAX_ALBUM_ART_SIZE_PX = 1024
    private val ALBUM_ART_QUALITY = 95

    private val MAX_TITLE_LENGTH = 200
    private val MAX_ARTIST_LENGTH = 200
    private val MAX_ALBUM_LENGTH = 200
    private val MAX_YEAR_LENGTH = 4
    private val MAX_GENRE_LENGTH = 50
    private val MAX_TRACK_LENGTH = 3
    private val MAX_LYRICS_LENGTH = 5000

    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val CLICK_ACTION_DELAY_MS = 1000L
    private val ALBUM_ART_CORNER_RADIUS_DP = 10
    private val PREFS_NAME = "LlamaPrefs"
    private val KEY_LAST_SONG_PATH = "last_song_path"

    private val KEYBOARD_SHOW_DELAY_MS = 1000L
    private val KEYBOARD_HIDE_DELAY_MS = 500L
    private val RESUME_PLAYBACK_DELAY_MS = 500L

    private val EXTRA_AWAITING_FILE_SELECTION = "awaiting_file_selection"

    // ========================================================================
    // UI
    // ========================================================================

    private var mCancelButton: Button? = null
    private var mActionButton: Button? = null
    private var mHeaderTitle: TextView? = null
    private var mFormatText: TextView? = null
    private var mAlbumArtView: ImageView? = null
    private var mAlbumArtHint: TextView? = null
    private var mTitleEdit: EditText? = null
    private var mArtistEdit: EditText? = null
    private var mAlbumEdit: EditText? = null
    private var mYearEdit: EditText? = null
    private var mGenreEdit: EditText? = null
    private var mTrackEdit: EditText? = null
    private var mLyricsEdit: EditText? = null
    private var mFileInfoText: EditText? = null
    private var mScrollView: ScrollView? = null
    private var mRootLayout: android.widget.LinearLayout? = null
    private var mAlbumArtContainer: FrameLayout? = null

    // ========================================================================
    // Data
    // ========================================================================

    private var mFilePath: String? = null
    private var mOriginalSong: Song? = null
    private var mOriginalData: MetadataReader.MetadataBundle? = null
    private var mCurrentMode = MODE_VIEW
    private var mHasTextChanges = false
    private var mAlbumArtChanged = false
    private var mNewAlbumArt: ByteArray? = null
    private var mAlbumArtDeleted = false
    private var mGrantedFileUri: Uri? = null
    private var mAwaitingFileSelection = false
    private var mOriginalTitle: String? = null
    private var mOriginalArtist: String? = null
    private var mOriginalAlbum: String? = null
    private var mOriginalYear: String? = null
    private var mOriginalGenre: String? = null
    private var mOriginalTrack: String? = null
    private var mOriginalLyrics: String? = null
    private var mPreviousSongState = SONG_STATE_NOT_CURRENT

    private var mStorageAccessHelper: StorageAccessHelper? = null
    private val mIsSaving = AtomicBoolean(false)
    @Volatile
    private var mIsDestroyed: Boolean = false
    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mActionHandler = Handler(Looper.getMainLooper())
    private var mExecutor: ExecutorService? = null

    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper

    private var mLastActionClickTime = 0L
    private var mLastCancelClickTime = 0L
    private var mLastModifyClickTime = 0L
    private var mLastSelectClickTime = 0L
    @Volatile
    private var mRequestInProgress = false
    private var mCurrentAlbumArtTask: Future<*>? = null

    // ========================================================================
    // attachBaseContext
    // ========================================================================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LanguageManager.getInstance(newBase).wrap(newBase))
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFullScreen()
        setContentView(R.layout.activity_metadata_editor)

        OverlayManager.init(this)
        mThemeManager = ThemeManager.getInstance(this)
        mThemeHelper = ThemeHelper.getInstance(this)
        mStorageAccessHelper = StorageAccessHelper.getInstance(this)
        mExecutor = Executors.newSingleThreadExecutor()

        NavigationController.getInstance().registerListener(this)
        LlamaEventBus.register(this)

        mFilePath = intent.getStringExtra("song_path")
        val songUri = intent.getStringExtra("song_uri")

        if (songUri != null) {
            val suppliedPath = mFilePath
            mGrantedFileUri = Uri.parse(songUri)
            mFilePath = getFilePathFromUri(mGrantedFileUri!!)
            if (mFilePath == null && suppliedPath != null) {
                val entry = SongDatabase.getInstance(this).getSong(suppliedPath)
                if (entry != null && songUri == entry.uri) mFilePath = suppliedPath
            }
        }

        if (mFilePath != null && mGrantedFileUri == null) {
            val cached = SongDatabase.getInstance(this).getSong(mFilePath!!)
            if (cached != null && cached.uri != null) {
                try {
                    mGrantedFileUri = cached.contentUri
                    Log.d(TAG, "Retrieved URI from database cache: $mGrantedFileUri")
                } catch (e: Exception) {
                    Log.w(TAG, "Cached URI is unusable", e); mGrantedFileUri = null
                }
            }
        }

        mAwaitingFileSelection = intent.getBooleanExtra(EXTRA_AWAITING_FILE_SELECTION, false)

        initializeViews()
        setupInputFilters()
        setupTextWatchers()

        if (mAwaitingFileSelection && mFilePath == null && mGrantedFileUri == null) {
            setPlaceholderUI()
        } else if (mFilePath == null && mGrantedFileUri == null) {
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_no_file_selected),
                ToastManager.LENGTH_NORMAL
            )
            finish(); return
        } else {
            mFilePath?.let {
                try { mOriginalSong = CharacterMapper.getSongFromFile(it) }
                catch (e: Exception) {
                    Log.w(TAG, "Could not parse song from file", e); mOriginalSong = null
                }
            }
            loadMetadataAsync()
        }
        applyThemeToUI()
    }

    override fun onDestroy() {
        mIsDestroyed = true
        super.onDestroy()
        NavigationController.getInstance().unregisterListener(this)
        LlamaEventBus.unregister(this)
        mCurrentAlbumArtTask?.cancel(true)
        if (mExecutor != null && !mExecutor!!.isShutdown) mExecutor!!.shutdown()
        mMainHandler.removeCallbacksAndMessages(null)
        mActionHandler.removeCallbacksAndMessages(null)
    }

    override fun onResume() {
        super.onResume()
        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS
            )
        )
        applyThemeToUI()
    }

    override fun onBackPressed() {
        hideKeyboard()
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    // ========================================================================
    // Bus subscribers
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    // ========================================================================
    // NavigationController listener
    // ========================================================================

    override fun onButtonStateChanged(
        group: NavigationController.ButtonGroup,
        disabled: Boolean
    ) {
        if (group == NavigationController.ButtonGroup.METADATA_ACTIONS) {
            runOnUiThread {
                if (mIsDestroyed || mActionButton == null) return@runOnUiThread
                val text = mActionButton?.text?.toString() ?: ""
                if (getString(R.string.action_select) == text) {
                    mActionButton?.isEnabled = true
                    mThemeHelper.updateButton(mActionButton, true)
                } else {
                    mActionButton?.isEnabled = !disabled
                    mThemeHelper.updateButton(mActionButton, !disabled)
                }
            }
        }
    }

    // ========================================================================
    // Full-screen
    // ========================================================================

    @Suppress("DEPRECATION")
    private fun setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.statusBarColor = resources.getColor(R.color.backgroundDark, null)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark, null)
            } else {
                window.statusBarColor = resources.getColor(R.color.backgroundDark)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    // ========================================================================
    // View init
    // ========================================================================

    private fun initializeViews() {
        mCancelButton = findViewById(R.id.cancelButton)
        mActionButton = findViewById(R.id.actionButton)
        mHeaderTitle = findViewById(R.id.headerTitle)
        mFormatText = findViewById(R.id.formatText)
        mAlbumArtView = findViewById(R.id.albumArtView)
        mAlbumArtHint = findViewById(R.id.albumArtHint)
        mTitleEdit = findViewById(R.id.titleEdit)
        mArtistEdit = findViewById(R.id.artistEdit)
        mAlbumEdit = findViewById(R.id.albumEdit)
        mYearEdit = findViewById(R.id.yearEdit)
        mGenreEdit = findViewById(R.id.genreEdit)
        mTrackEdit = findViewById(R.id.trackEdit)
        mLyricsEdit = findViewById(R.id.lyricsEdit)
        mFileInfoText = findViewById(R.id.fileInfoText)
        mScrollView = findViewById(R.id.scrollView)
        mRootLayout = findViewById(R.id.rootLayout)
        mAlbumArtContainer = findViewById(R.id.albumArtContainer)

        mFormatText?.letterSpacing = 0.1f
        mCancelButton?.setText(R.string.action_cancel)
        mCancelButton?.setBackgroundResource(R.drawable.button_border_selector)
        mActionButton?.apply {
            if (mFilePath != null || mGrantedFileUri != null)
                setText(R.string.action_modify)
            else setText(R.string.action_select)
            setBackgroundResource(R.drawable.button_border_selector)
        }
        mAlbumArtView?.scaleType = ImageView.ScaleType.CENTER_CROP

        animateButton(mCancelButton); animateButton(mActionButton)

        mCancelButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelClickTime = now
                handleCancelClick()
            }
        }
        mActionButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastActionClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastActionClickTime = now
                handleModifyClick()
            }
        }
        mAlbumArtView?.setOnClickListener {
            if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) checkGalleryPermissionAndOpen()
        }
        mAlbumArtView?.setOnLongClickListener {
            if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) { removeAlbumArt(); true }
            else false
        }
        mRootLayout?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) hideKeyboard()
            false
        }

        setupLyricsScrolling()
        setFieldsEnabled(false)
        mAlbumArtHint?.visibility = View.GONE
    }

    private fun setPlaceholderUI() {
        setPlaceholderAlbumArt()
        mTitleEdit?.setText("")
        mArtistEdit?.setText("")
        mAlbumEdit?.setText("")
        mYearEdit?.setText("")
        mGenreEdit?.setText("")
        mTrackEdit?.setText("")
        mLyricsEdit?.setText("")
        mFormatText?.setText(R.string.metadata_no_file)
        mHeaderTitle?.setText(R.string.metadata_mode_view)
        mFileInfoText?.setText(null)
        mFileInfoText?.setTextColor(Color.parseColor("#5A5A5A"))
        mActionButton?.setText(R.string.action_select)
        setActionButtonEnabled(true)
    }

    private fun setupLyricsScrolling() {
        val edit = mLyricsEdit ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            edit.movementMethod = android.text.method.ScrollingMovementMethod()
        }
        edit.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                mScrollView?.requestDisallowInterceptTouchEvent(true)
            }
            false
        }
        edit.setTextIsSelectable(false)
        edit.isFocusable = false
        edit.isFocusableInTouchMode = false
        edit.isLongClickable = false
        edit.customSelectionActionModeCallback = null
        edit.customInsertionActionModeCallback = null
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
            }
            false
        }
    }

    // ========================================================================
    // Action click
    // ========================================================================

    private fun handleModifyClick() {
        val text = mActionButton?.text?.toString() ?: ""
        if (getString(R.string.action_select) == text) {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastSelectClickTime < CLICK_DEBOUNCE_DELAY_MS) return
            mLastSelectClickTime = now
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_please_select_audio),
                ToastManager.LENGTH_NORMAL
            )
            mActionHandler.postDelayed({
                if (!isFinishing && !isDestroyed) openFilePicker()
            }, CLICK_ACTION_DELAY_MS)
            return
        }

        if (mCurrentMode == MODE_EDIT) {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) return
            mLastModifyClickTime = now
            if (NavigationController.getInstance().isGroupDisabled(
                    NavigationController.ButtonGroup.METADATA_ACTIONS)) {
                ToastManager.showToast(
                    this,
                    getString(R.string.metadata_toast_please_wait_sync),
                    ToastManager.LENGTH_NORMAL
                ); return
            }
            hideKeyboard()
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_saving),
                ToastManager.LENGTH_NORMAL
            )
            mActionHandler.postDelayed({
                if (!isFinishing && !isDestroyed) saveChanges()
            }, CLICK_ACTION_DELAY_MS)
            return
        }

        val now = SystemClock.elapsedRealtime()
        if (now - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) return
        mLastModifyClickTime = now

        if (NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_please_wait_sync),
                ToastManager.LENGTH_NORMAL
            ); return
        }

        var hasValidUri = false
        val selectedUri = mGrantedFileUri
        if (selectedUri != null && hasWritePermission(selectedUri)) {
            hasValidUri = true
            saveUriToDatabase()
            Log.d(TAG, "MODIFY: Using the current target URI with write permission: $selectedUri")
        } else if (mFilePath != null) {
            hasValidUri = getStoredUri(mFilePath!!)
        }

        if (hasValidUri) {
            Log.d(TAG, "MODIFY: Successfully resolved URI, entering edit mode")
            mActionHandler.postDelayed({
                if (!isFinishing && !isDestroyed) enterEditMode()
            }, CLICK_ACTION_DELAY_MS)
            return
        }

        Log.d(TAG, "MODIFY: No valid URI found, requesting SAF access")
        ToastManager.showToast(
            this,
            getString(R.string.metadata_toast_reselect_for_edit),
            ToastManager.LENGTH_NORMAL
        )
        mActionHandler.postDelayed({
            if (!isFinishing && !isDestroyed) requestSafFileAccess()
        }, CLICK_ACTION_DELAY_MS)
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, REQUEST_SAF_FILE_PICKER) }
        catch (e: Exception) {
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_no_file_manager),
                ToastManager.LENGTH_NORMAL
            )
            mRequestInProgress = false
        }
    }

    private fun requestSafFileAccess() {
        if (mIsSaving.get()) {
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_saving_in_progress),
                ToastManager.LENGTH_NORMAL
            ); return
        }
        if (mRequestInProgress) return
        mRequestInProgress = true
        openFilePicker()
        mActionHandler.postDelayed({ mRequestInProgress = false }, CLICK_ACTION_DELAY_MS)
    }

    private fun handleCancelClick() {
        if (mCurrentMode == MODE_EDIT) {
            hideKeyboard()
            exitEditMode()
            ToastManager.showToast(
                this,
                getString(R.string.metadata_toast_no_changes_saved),
                ToastManager.LENGTH_NORMAL
            )
        } else onBackPressed()
    }

    // ========================================================================
    // Input filters and watchers
    // ========================================================================

    private fun setupInputFilters() {
        mTitleEdit?.filters = arrayOf(InputFilter.LengthFilter(MAX_TITLE_LENGTH))
        mArtistEdit?.filters = arrayOf(InputFilter.LengthFilter(MAX_ARTIST_LENGTH))
        mAlbumEdit?.filters = arrayOf(InputFilter.LengthFilter(MAX_ALBUM_LENGTH))
        mYearEdit?.apply {
            filters = arrayOf(InputFilter.LengthFilter(MAX_YEAR_LENGTH), DigitsFilter())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        mGenreEdit?.filters = arrayOf(InputFilter.LengthFilter(MAX_GENRE_LENGTH))
        mTrackEdit?.apply {
            filters = arrayOf(InputFilter.LengthFilter(MAX_TRACK_LENGTH), DigitsFilter())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        mLyricsEdit?.apply {
            filters = arrayOf(InputFilter.LengthFilter(MAX_LYRICS_LENGTH))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
    }

    private class DigitsFilter : InputFilter {
        override fun filter(
            source: CharSequence, start: Int, end: Int,
            dest: android.text.Spanned?, dstart: Int, dend: Int
        ): CharSequence? {
            for (i in start until end) {
                if (!Character.isDigit(source[i])) return ""
            }
            return null
        }
    }

    private fun setupTextWatchers() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (mCurrentMode == MODE_EDIT) detectTextChanges()
            }
            override fun afterTextChanged(s: Editable?) {}
        }
        mTitleEdit?.addTextChangedListener(watcher)
        mArtistEdit?.addTextChangedListener(watcher)
        mAlbumEdit?.addTextChangedListener(watcher)
        mYearEdit?.addTextChangedListener(watcher)
        mGenreEdit?.addTextChangedListener(watcher)
        mTrackEdit?.addTextChangedListener(watcher)
        mLyricsEdit?.addTextChangedListener(watcher)
    }

    private fun detectTextChanges() {
        val title = getEditTextDisplayValue(mTitleEdit) ?: ""
        val artist = getEditTextDisplayValue(mArtistEdit) ?: ""
        val album = getEditTextDisplayValue(mAlbumEdit) ?: ""
        val year = getEditTextDisplayValue(mYearEdit) ?: ""
        val genre = getEditTextDisplayValue(mGenreEdit) ?: ""
        val track = getEditTextDisplayValue(mTrackEdit) ?: ""
        val lyrics = getEditTextDisplayValue(mLyricsEdit) ?: ""
        val oTitle = mOriginalTitle ?: ""
        val oArtist = mOriginalArtist ?: ""
        val oAlbum = mOriginalAlbum ?: ""
        val oYear = mOriginalYear ?: ""
        val oGenre = mOriginalGenre ?: ""
        val oTrack = mOriginalTrack ?: ""
        val oLyrics = mOriginalLyrics ?: ""
        mHasTextChanges = title != oTitle || artist != oArtist || album != oAlbum ||
            year != oYear || genre != oGenre || track != oTrack || lyrics != oLyrics
    }

    private fun getEditTextDisplayValue(editText: EditText?): String? {
        val value = editText?.text?.toString()?.trim() ?: return null
        return if (value.isEmpty()) null else value
    }

    private fun getEditTextChangeValue(editText: EditText?, original: String?): String? {
        val current = editText?.text?.toString()?.trim() ?: return null
        val o = original ?: ""
        if (current.isEmpty() && o.isNotEmpty()) return ""
        if (current == o) return null
        return if (current.isEmpty()) null else current
    }

    // ========================================================================
    // Save paths
    // ========================================================================

    private fun saveChanges() {
        hideKeyboard()
        mMainHandler.postDelayed({ performSaveChanges() }, KEYBOARD_HIDE_DELAY_MS)
    }

    private fun performSaveChanges() {
        val hasAnyChanges = mHasTextChanges || mAlbumArtChanged
        if (!hasAnyChanges) {
            ToastManager.showToast(this, getString(R.string.metadata_toast_no_changes),
                ToastManager.LENGTH_NORMAL); return
        }
        if (mIsSaving.get()) return
        val targetUri = mGrantedFileUri
        if (targetUri == null) {
            ToastManager.showToast(this, getString(R.string.metadata_toast_no_write_permission),
                ToastManager.LENGTH_NORMAL); requestSafFileAccess(); return
        }
        if (NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(this, getString(R.string.metadata_toast_please_wait_sync),
                ToastManager.LENGTH_NORMAL); return
        }

        val update = MetadataWriter.UpdateBundle()
        if (mHasTextChanges) {
            update.title = getEditTextChangeValue(mTitleEdit, mOriginalTitle)
            update.artist = getEditTextChangeValue(mArtistEdit, mOriginalArtist)
            update.album = getEditTextChangeValue(mAlbumEdit, mOriginalAlbum)
            update.year = getEditTextChangeValue(mYearEdit, mOriginalYear)
            update.genre = getEditTextChangeValue(mGenreEdit, mOriginalGenre)
            update.trackNumber = getEditTextChangeValue(mTrackEdit, mOriginalTrack)
            update.lyrics = getEditTextChangeValue(mLyricsEdit, mOriginalLyrics)
        }
        update.albumArt = if (mAlbumArtChanged)
            (if (mAlbumArtDeleted) ByteArray(0) else mNewAlbumArt) else null

        val targetPath = mFilePath
        val albumArtWasDeleted = mAlbumArtDeleted
        mPreviousSongState = checkCurrentSongState()

        val preEdit = mOriginalData
        val submitted = update

        mIsSaving.set(true)
        setActionButtonEnabled(false)

        val executor = mExecutor
        if (executor == null || executor.isShutdown) {
            mIsSaving.set(false); setActionButtonEnabled(true); return
        }
        executor.execute {
            val result = MetadataWriter.writeMetadataToUri(this, targetUri, submitted)
            mMainHandler.post {
                ToastManager.hidePersistentOverlay()
                mIsSaving.set(false)
                if (mIsDestroyed) {
                    if (result.isSuccess()) onSaveSuccess(targetUri, targetPath,
                        albumArtWasDeleted, preEdit, submitted)
                    return@post
                }
                setActionButtonEnabled(true)
                if (result.isSuccess())
                    onSaveSuccess(targetUri, targetPath, albumArtWasDeleted, preEdit, submitted)
                else onSaveFailure(result, targetPath)
            }
        }
    }

    private fun onSaveSuccess(
        savedUri: Uri, savedPath: String?, albumArtWasDeleted: Boolean,
        preEdit: MetadataReader.MetadataBundle?, submitted: MetadataWriter.UpdateBundle
    ) {
        val announcement = buildAnnouncementFromSubmitted(preEdit, submitted)
        var verified: MetadataReader.MetadataBundle? = null
        try { verified = MetadataReader.readMetadataFromUri(this, savedUri) }
        catch (e: Exception) { Log.w(TAG, "Post-save re-read failed", e) }
        val verifiedOk = verified?.status == MetadataReader.MetadataBundle.Status.SUCCESS
        if (!verifiedOk) Log.w(TAG, "Post-save verification did not succeed; announcing submitted values")
        mOriginalData = if (verifiedOk) verified else announcement

        evictAlbumArtCaches(savedPath, savedUri)

        val persisted = if (verifiedOk) verified!! else announcement
        val dbPath = savedPath ?: getFilePathFromUri(savedUri)
        if (dbPath != null) {
            val updated = Song(
                persisted.title.ifEmpty { CharacterMapper.getUnknownTitle() },
                persisted.artist.ifEmpty { CharacterMapper.getUnknownArtist() },
                persisted.album.ifEmpty { CharacterMapper.getUnknownAlbum() },
                persisted.genre.ifEmpty { CharacterMapper.getUnknownGenre() },
                dbPath, persisted.duration, savedUri.toString()
            )
            SongDatabase.getInstance(this).insertSong(updated)
        }

        LlamaEventBus.post(MetadataEvent.Updated(
            savedPath ?: getFilePathFromUri(savedUri),
            savedUri.toString(),
            announcement.title, announcement.artist, announcement.album,
            announcement.genre, announcement.hasAlbumArt(),
            albumArtWasDeleted && !announcement.hasAlbumArt(),
            announcement.albumArt
        ))

        if (mPreviousSongState == SONG_STATE_WAS_PLAYING) {
            mMainHandler.postDelayed({
                LlamaEventBus.post(TransportEvent.Resume)
            }, RESUME_PLAYBACK_DELAY_MS)
        }

        if (mIsDestroyed) return

        mHasTextChanges = false
        mAlbumArtChanged = false
        mAlbumArtDeleted = false
        mNewAlbumArt = null
        exitEditMode()
        applyThemeToUI()
        ToastManager.showToast(this, getString(R.string.metadata_toast_updated),
            ToastManager.LENGTH_NORMAL)
    }

    private fun onSaveFailure(result: MetadataWriter.WriteResult, failedPath: String?) {
        val msgRes = when (result.status) {
            MetadataWriter.WriteResult.Status.WRITE_FAILED_RESTORED,
            MetadataWriter.WriteResult.Status.VERIFY_FAILED_RESTORED,
            MetadataWriter.WriteResult.Status.COPY_BACK_FAILED_RESTORED ->
                R.string.metadata_toast_update_failed_restored
            MetadataWriter.WriteResult.Status.PERMISSION_DENIED ->
                R.string.metadata_toast_permission_lost
            else -> R.string.metadata_toast_update_failed
        }
        ToastManager.showToast(this, getString(msgRes), ToastManager.LENGTH_NORMAL)
        Log.e(TAG, "Save failed [${result.status}]: ${result.errorMessage}")
        if (result.status == MetadataWriter.WriteResult.Status.PERMISSION_DENIED) {
            if (failedPath != null) {
                SongDatabase.getInstance(this).insertSong(Song(
                    mOriginalTitle ?: CharacterMapper.getUnknownTitle(),
                    mOriginalArtist ?: CharacterMapper.getUnknownArtist(),
                    mOriginalAlbum ?: CharacterMapper.getUnknownAlbum(),
                    mOriginalGenre ?: CharacterMapper.getUnknownGenre(),
                    failedPath, 0L, null
                ))
            }
            mGrantedFileUri = null
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_permission_lost_reselect),
                ToastManager.LENGTH_NORMAL)
        }
    }

    private fun buildAnnouncementFromSubmitted(
        preEdit: MetadataReader.MetadataBundle?,
        update: MetadataWriter.UpdateBundle
    ): MetadataReader.MetadataBundle {
        val out = MetadataReader.MetadataBundle()
        out.status = MetadataReader.MetadataBundle.Status.SUCCESS
        preEdit?.let {
            out.title = it.title; out.artist = it.artist; out.album = it.album
            out.year = it.year; out.genre = it.genre; out.trackNumber = it.trackNumber
            out.lyrics = it.lyrics; out.albumArt = it.albumArt; out.format = it.format
            out.duration = it.duration; out.fileSize = it.fileSize
            out.isWriteSupported = it.isWriteSupported
        }
        update.title?.let { out.title = it }
        update.artist?.let { out.artist = it }
        update.album?.let { out.album = it }
        update.year?.let { out.year = it }
        update.genre?.let { out.genre = it }
        update.trackNumber?.let { out.trackNumber = it }
        update.lyrics?.let { out.lyrics = it }
        update.albumArt?.let {
            out.albumArt = if (it.isEmpty()) null else it
        }
        return out
    }

    private fun evictAlbumArtCaches(path: String?, uri: Uri) {
        val cache = AlbumArtCache.getInstance(this).asLruCache()
        path?.let { cache.remove(it) }
        cache.remove(uri.toString())
    }

    // ========================================================================
    // URI and file helpers
    // ========================================================================

    private fun getFilePathFromUri(uri: Uri): String? {
        when (uri.scheme) {
            "file" -> return uri.path
            "content" -> {
                var path: String? = null
                var cursor: android.database.Cursor? = null
                try {
                    cursor = contentResolver.query(uri,
                        arrayOf(android.provider.MediaStore.Audio.Media.DATA),
                        null, null, null)
                    if (cursor != null && cursor.moveToFirst()) {
                        path = cursor.getString(cursor.getColumnIndexOrThrow(
                            android.provider.MediaStore.Audio.Media.DATA))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not get file path from URI", e)
                } finally { cursor?.close() }
                return path
            }
            else -> return null
        }
    }

    private fun hasWritePermission(uri: Uri): Boolean {
        return try {
            val doc = DocumentFile.fromSingleUri(applicationContext, uri)
            doc?.canWrite() == true
        } catch (e: Exception) {
            Log.w(TAG, "hasWritePermission check failed", e); false
        }
    }

    private fun getStoredUri(filePath: String): Boolean {
        val cached = SongDatabase.getInstance(this).getSong(filePath)
        if (cached != null && cached.uri != null) {
            mGrantedFileUri = cached.contentUri
            Log.d(TAG, "Found stored URI in database: $mGrantedFileUri")
            if (mStorageAccessHelper?.reacquirePermission(mGrantedFileUri!!) == true) {
                Log.d(TAG, "Successfully reacquired permission for URI"); return true
            }
            if (hasWritePermission(mGrantedFileUri!!)) {
                Log.d(TAG, "URI has write permission"); return true
            }
            Log.w(TAG, "Cannot reacquire permission for URI, will need to reselect file")
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_permission_lost_reselect),
                ToastManager.LENGTH_NORMAL)
            SongDatabase.getInstance(this).insertSong(Song(
                cached.title, cached.artist, cached.album, cached.genre,
                filePath, cached.duration, null
            ))
            mGrantedFileUri = null
            return false
        }
        return false
    }

    private fun saveUriToDatabase() {
        val path = mFilePath ?: return
        val uri = mGrantedFileUri ?: return
        val existing = SongDatabase.getInstance(this).getSong(path)
        if (existing != null) {
            val updated = Song(
                existing.title, existing.artist, existing.album, existing.genre,
                path, existing.duration, uri.toString()
            )
            SongDatabase.getInstance(this).insertSong(updated)
        } else {
            val original = mOriginalData
            val new = Song(
                original?.title ?: CharacterMapper.getUnknownTitle(),
                original?.artist ?: CharacterMapper.getUnknownArtist(),
                original?.album ?: CharacterMapper.getUnknownAlbum(),
                original?.genre ?: CharacterMapper.getUnknownGenre(),
                path, original?.duration ?: 0L, uri.toString()
            )
            SongDatabase.getInstance(this).insertSong(new)
        }
    }

    // ========================================================================
    // Metadata loading
    // ========================================================================

    private fun loadMetadataAsync() {
        OverlayManager.show(OverlayManager.REASON_METADATA_LOAD)
        val executor = mExecutor ?: return
        executor.execute {
            val bundle = readMetadataSafely()
            mMainHandler.post {
                if (mIsDestroyed) return@post
                OverlayManager.hide(OverlayManager.REASON_METADATA_LOAD)
                mOriginalData = bundle
                displayMetadata()
                updateFileInfo()
                when (bundle.status) {
                    MetadataReader.MetadataBundle.Status.FILE_UNREADABLE -> {
                        loadCurrentSongInViewMode()
                        ToastManager.showToast(this,
                            getString(R.string.metadata_toast_file_not_accessible),
                            ToastManager.LENGTH_NORMAL)
                    }
                    MetadataReader.MetadataBundle.Status.PARSE_FAILED -> {
                        loadCurrentSongInViewMode()
                        ToastManager.showToast(this,
                            getString(R.string.metadata_toast_could_not_read),
                            ToastManager.LENGTH_NORMAL)
                    }
                    else -> {
                        if (!bundle.isWriteSupported) {
                            loadCurrentSongInViewMode()
                            ToastManager.showToast(this,
                                getString(R.string.metadata_toast_cannot_edit_format, bundle.format),
                                ToastManager.LENGTH_NORMAL)
                        } else {
                            setActionButtonEnabled(true)
                            if (mActionButton != null && mCurrentMode == MODE_VIEW) {
                                mActionButton?.setText(R.string.action_modify)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun readMetadataSafely(): MetadataReader.MetadataBundle {
        if (mGrantedFileUri != null && !hasWritePermission(mGrantedFileUri!!)) {
            mGrantedFileUri = null
        }
        var uriResult: MetadataReader.MetadataBundle? = null
        if (mGrantedFileUri != null) {
            try { uriResult = MetadataReader.readMetadataFromUri(this, mGrantedFileUri!!) }
            catch (e: Exception) { Log.w(TAG, "readMetadataFromUri failed", e) }
        }
        if (uriResult?.status == MetadataReader.MetadataBundle.Status.SUCCESS) {
            if (mFilePath == null) mFilePath = getFilePathFromUri(mGrantedFileUri!!)
            return uriResult
        }
        var pathResult: MetadataReader.MetadataBundle? = null
        mFilePath?.let {
            try { pathResult = MetadataReader.readMetadata(it) }
            catch (e: Exception) { Log.w(TAG, "readMetadata from path failed", e) }
        }
        if (pathResult?.status == MetadataReader.MetadataBundle.Status.SUCCESS) return pathResult
        if (mFilePath == null && mGrantedFileUri != null) {
            try { mFilePath = getFilePathFromUri(mGrantedFileUri!!) }
            catch (e: Exception) { Log.w(TAG, "Could not resolve path from URI", e) }
        }
        uriResult?.let { return it }
        pathResult?.let { return it }
        val failure = MetadataReader.MetadataBundle()
        failure.status = MetadataReader.MetadataBundle.Status.FILE_UNREADABLE
        failure.format = CharacterMapper.getUnknown()
        return failure
    }

    private fun loadCurrentSongInViewMode() {
        mFilePath?.let { path ->
            SongDatabase.getInstance(this).getSong(path)?.let { s ->
                mTitleEdit?.setText(s.title)
                mArtistEdit?.setText(s.artist)
                mAlbumEdit?.setText(s.album)
                mGenreEdit?.setText(s.genre)
            }
        }
        mHeaderTitle?.setText(R.string.metadata_mode_view)
        mActionButton?.setText(R.string.action_modify)
        setActionButtonEnabled(true)
        mAlbumArtHint?.visibility = View.GONE
    }

    private fun displayMetadata() {
        val data = mOriginalData ?: return
        mOriginalTitle = data.title; mOriginalArtist = data.artist
        mOriginalAlbum = data.album; mOriginalYear = data.year
        mOriginalGenre = data.genre; mOriginalTrack = data.trackNumber
        mOriginalLyrics = data.lyrics
        mTitleEdit?.setText(mOriginalTitle ?: "")
        mArtistEdit?.setText(mOriginalArtist ?: "")
        mAlbumEdit?.setText(mOriginalAlbum ?: "")
        mYearEdit?.setText(mOriginalYear ?: "")
        mGenreEdit?.setText(mOriginalGenre ?: "")
        mTrackEdit?.setText(mOriginalTrack ?: "")
        mLyricsEdit?.setText(mOriginalLyrics ?: "")
        if (mCurrentMode == MODE_VIEW) refreshTextColors()
        if (data.hasAlbumArt()) {
            data.albumArt?.let { loadAlbumArtFromBytes(it) }
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint?.visibility = View.VISIBLE
                mAlbumArtHint?.setText(R.string.metadata_hint_long_press_to_remove)
            } else mAlbumArtHint?.visibility = View.GONE
        } else {
            setPlaceholderAlbumArt()
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint?.visibility = View.VISIBLE
                mAlbumArtHint?.setText(R.string.metadata_hint_tap_to_add_art)
            } else mAlbumArtHint?.visibility = View.GONE
        }
        applyAlbumArtClipping()
        updateHeaderForMode()
    }

    private fun refreshTextColors() {
        if (mCurrentMode != MODE_VIEW) return
        val fields = arrayOf(mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit,
            mGenreEdit, mTrackEdit, mLyricsEdit)
        for (field in fields) {
            field ?: continue
            val text = field.text.toString()
            val isPlaceholder = CharacterMapper.isAnyUnknownPlaceholder(text)
            field.setTextColor(Color.parseColor(if (isPlaceholder) "#808080" else "#C0C0C0"))
        }
    }

    private fun loadAlbumArtFromBytes(bytes: ByteArray) {
        runOnUiThread {
            if (mIsDestroyed) return@runOnUiThread
            try {
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null && mAlbumArtView != null) {
                    mAlbumArtView?.setImageBitmap(bmp)
                    mAlbumArtView?.colorFilter = null
                    applyAlbumArtClipping()
                } else setPlaceholderAlbumArt()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to decode album art", e); setPlaceholderAlbumArt()
            }
        }
    }

    private fun setPlaceholderAlbumArt() {
        val view = mAlbumArtView ?: return
        val placeholder = mThemeHelper.createThemedAlbumArtPlaceholder()
        if (placeholder != null) view.setImageDrawable(placeholder)
        else {
            view.setImageResource(R.drawable.album_art_placeholder)
            view.setColorFilter(mThemeHelper.themeColorInt, PorterDuff.Mode.SRC_IN)
        }
        applyAlbumArtClipping()
    }

    private fun updateFileInfo() {
        val data = mOriginalData ?: return
        val info = mFileInfoText ?: return
        val sb = StringBuilder()
        val bytes = data.fileSize
        if (bytes < 1024 * 1024) {
            sb.append(getString(R.string.metadata_size_kilobytes, bytes / 1024.0f))
        } else {
            sb.append(getString(R.string.metadata_size_megabytes, bytes / (1024.0f * 1024.0f)))
        }
        if (mGrantedFileUri != null || mFilePath != null) {
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                if (mGrantedFileUri != null) retriever.setDataSource(this, mGrantedFileUri)
                else retriever.setDataSource(mFilePath)
                val bitrate = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_BITRATE)
                if (!bitrate.isNullOrEmpty()) {
                    val kbps = bitrate.toInt() / 1000
                    sb.append(" \u2022 ").append(getString(R.string.metadata_bitrate_kbps, kbps))
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not read audio properties: ${e.message}")
            } finally { try { retriever?.release() } catch (ignored: Exception) {} }
        }
        val totalSeconds = (data.duration / 1000).toInt()
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        val duration = if (h > 0) String.format("%02d:%02d:%02d", h, m, s)
        else String.format("%02d:%02d", m, s)
        sb.append(" \u2022 ").append(duration)
        info.setText(sb.toString())
        info.isSelected = false; info.isLongClickable = false
        info.setTextIsSelectable(false)
        info.setTextColor(Color.parseColor("#C0C0C0"))
        mFormatText?.text = getString(R.string.metadata_format_file, data.format.uppercase())
    }

    private fun applyAlbumArtClipping() {
        val container = mAlbumArtContainer ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            container.clipToOutline = true
            container.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height,
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP).toFloat())
                }
            }
        }
    }

    // ========================================================================
    // Edit mode
    // ========================================================================

    private fun enterEditMode() {
        val data = mOriginalData ?: run {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_cannot_edit_not_loaded),
                ToastManager.LENGTH_NORMAL); return
        }
        if (data.status != MetadataReader.MetadataBundle.Status.SUCCESS) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_cannot_edit_unreadable),
                ToastManager.LENGTH_NORMAL); return
        }
        if (!data.isWriteSupported) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_cannot_edit_format, data.format),
                ToastManager.LENGTH_NORMAL); return
        }
        if (mGrantedFileUri == null && mFilePath != null) getStoredUri(mFilePath!!)
        if (mGrantedFileUri == null) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_file_access_needed),
                ToastManager.LENGTH_NORMAL)
            requestSafFileAccess(); return
        }
        if (!hasWritePermission(mGrantedFileUri!!)) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_write_permission_needed),
                ToastManager.LENGTH_NORMAL)
            requestSafFileAccess(); return
        }
        mCurrentMode = MODE_EDIT
        mHasTextChanges = false; mAlbumArtChanged = false; mAlbumArtDeleted = false
        mNewAlbumArt = null
        mActionButton?.setText(R.string.action_update)
        setFieldsEnabled(true)
        mAlbumArtHint?.let { hint ->
            hint.visibility = View.VISIBLE
            hint.setText(if (!data.hasAlbumArt())
                R.string.metadata_hint_tap_to_add_art
            else R.string.metadata_hint_long_press_to_remove)
        }
        updateHeaderForMode()
        mTitleEdit?.requestFocus()
        mMainHandler.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(mTitleEdit, InputMethodManager.SHOW_IMPLICIT)
        }, KEYBOARD_SHOW_DELAY_MS)
        ToastManager.showToast(this, getString(R.string.metadata_toast_tap_update),
            ToastManager.LENGTH_NORMAL)
    }

    private fun exitEditMode() {
        mCurrentMode = MODE_VIEW
        mHasTextChanges = false; mAlbumArtChanged = false; mAlbumArtDeleted = false
        mNewAlbumArt = null
        mActionButton?.setText(R.string.action_modify)
        setFieldsEnabled(false)
        mAlbumArtHint?.visibility = View.GONE
        updateHeaderForMode()
        hideKeyboard()
        mOriginalData?.let { displayMetadata() }
    }

    private fun setFieldsEnabled(enabled: Boolean) {
        val fields = arrayOf(mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit,
            mGenreEdit, mTrackEdit)
        for (field in fields) {
            field ?: continue
            if (!enabled) {
                field.isEnabled = true
                field.isFocusable = false
                field.isFocusableInTouchMode = false
                field.isClickable = false
                field.isCursorVisible = false
                field.isLongClickable = false
                field.setTextIsSelectable(false)
                field.onFocusChangeListener = null
                val placeholder = CharacterMapper.isAnyUnknownPlaceholder(field.text.toString())
                field.setTextColor(Color.parseColor(if (placeholder) "#808080" else "#C0C0C0"))
                field.setHintTextColor(mThemeHelper.mutedThemeColorInt)
                mThemeHelper.updateEditText(field)
            } else {
                field.isEnabled = true; field.isFocusable = true
                field.isFocusableInTouchMode = true; field.isClickable = true
                field.isCursorVisible = true; field.isLongClickable = true
                field.setTextIsSelectable(true)
                mThemeHelper.updateEditTextCursor(field)
                val placeholder = CharacterMapper.isAnyUnknownPlaceholder(field.text.toString())
                field.setTextColor(Color.parseColor(if (placeholder) "#808080" else "#C0C0C0"))
                field.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                    val editText = v as EditText
                    if (hasFocus) {
                        editText.setTextColor(mThemeManager.getCurrentColorInt())
                    } else {
                        val isEmptyOrPlaceholder =
                            CharacterMapper.isAnyUnknownPlaceholder(editText.text.toString())
                        editText.setTextColor(Color.parseColor(
                            if (isEmptyOrPlaceholder) "#808080" else "#C0C0C0"))
                    }
                }
            }
        }
        mLyricsEdit?.let { edit ->
            if (!enabled) {
                edit.isEnabled = true; edit.isFocusable = false
                edit.isFocusableInTouchMode = false; edit.isClickable = false
                edit.isCursorVisible = false; edit.isLongClickable = false
                edit.setTextIsSelectable(false)
                edit.onFocusChangeListener = null
                edit.customSelectionActionModeCallback = null
                edit.customInsertionActionModeCallback = null
                val ph = CharacterMapper.isAnyUnknownPlaceholder(edit.text.toString())
                edit.setTextColor(Color.parseColor(if (ph) "#808080" else "#C0C0C0"))
                edit.setHintTextColor(mThemeHelper.mutedThemeColorInt)
                mThemeHelper.updateEditText(edit)
            } else {
                edit.isEnabled = true; edit.isFocusable = true
                edit.isFocusableInTouchMode = true; edit.isClickable = true
                edit.isCursorVisible = true; edit.isLongClickable = true
                edit.setTextIsSelectable(true)
                mThemeHelper.updateEditTextCursor(edit)
                val ph = CharacterMapper.isAnyUnknownPlaceholder(edit.text.toString())
                edit.setTextColor(Color.parseColor(if (ph) "#808080" else "#C0C0C0"))
                edit.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                    val et = v as EditText
                    if (hasFocus) {
                        et.setTextColor(mThemeManager.getCurrentColorInt())
                    } else {
                        val isEmpty = CharacterMapper.isAnyUnknownPlaceholder(et.text.toString())
                        et.setTextColor(Color.parseColor(if (isEmpty) "#808080" else "#C0C0C0"))
                    }
                }
            }
        }
        mFileInfoText?.apply {
            isEnabled = true; isFocusable = false; isFocusableInTouchMode = false
            isClickable = false; isCursorVisible = false; isLongClickable = false
            setTextIsSelectable(false)
        }
    }

    private fun updateHeaderForMode() {
        mHeaderTitle?.apply {
            setText(if (mCurrentMode == MODE_VIEW) R.string.metadata_mode_view
            else R.string.metadata_mode_edit)
            setTextColor(Color.parseColor("#C0C0C0"))
            letterSpacing = 0.1f
        }
        mFormatText?.apply {
            letterSpacing = 0.1f; setTextColor(Color.parseColor("#C0C0C0"))
        }
    }

    private fun setActionButtonEnabled(enabled: Boolean) {
        mActionButton?.let {
            it.isEnabled = enabled
            mThemeHelper.updateButton(it, enabled)
        }
    }

    private fun removeAlbumArt() {
        ToastManager.showToast(this,
            getString(R.string.metadata_toast_album_art_removed),
            ToastManager.LENGTH_NORMAL)
        mNewAlbumArt = null; mAlbumArtChanged = true; mAlbumArtDeleted = true
        setPlaceholderAlbumArt()
        mAlbumArtHint?.let {
            if (mCurrentMode == MODE_EDIT) {
                it.visibility = View.VISIBLE
                it.setText(R.string.metadata_hint_tap_to_add_art)
            } else it.visibility = View.GONE
        }
    }

    // ========================================================================
    // Album art picker
    // ========================================================================

    private fun checkGalleryPermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES")
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf("android.permission.READ_MEDIA_IMAGES"),
                    PERMISSION_GALLERY_REQUEST); return
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    PERMISSION_GALLERY_REQUEST); return
            }
        }
        openGalleryForAlbumArt()
    }

    private fun openGalleryForAlbumArt() {
        try {
            startActivityForResult(
                Intent(Intent.ACTION_PICK).setType("image/*"), GALLERY_REQUEST_CODE)
        } catch (e: Exception) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_no_file_manager),
                ToastManager.LENGTH_NORMAL)
        }
    }

    private fun processSelectedAlbumArt(uri: Uri?) {
        uri ?: return
        if (mIsSaving.get()) {
            ToastManager.showToast(this,
                getString(R.string.metadata_toast_saving_in_progress),
                ToastManager.LENGTH_NORMAL); return
        }
        mCurrentAlbumArtTask?.cancel(true)
        setPlaceholderAlbumArt()
        val executor = mExecutor ?: return
        mCurrentAlbumArtTask = executor.submit {
            val bytes = loadAlbumArtBytes(uri)
            runOnUiThread {
                if (mIsDestroyed) return@runOnUiThread
                mCurrentAlbumArtTask = null
                if (bytes == null || bytes.isEmpty()) {
                    ToastManager.showToast(this,
                        getString(R.string.metadata_toast_failed_to_load_image),
                        ToastManager.LENGTH_NORMAL)
                    if (mOriginalData?.hasAlbumArt() == true) {
                        mOriginalData?.albumArt?.let { loadAlbumArtFromBytes(it) }
                    } else setPlaceholderAlbumArt()
                    return@runOnUiThread
                }
                mNewAlbumArt = bytes
                mAlbumArtChanged = true
                mAlbumArtDeleted = false
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null && mAlbumArtView != null) {
                    mAlbumArtView?.setImageBitmap(bmp)
                    mAlbumArtView?.colorFilter = null
                    applyAlbumArtClipping()
                    mAlbumArtHint?.let {
                        it.visibility = View.VISIBLE
                        it.setText(R.string.metadata_hint_long_press_to_remove)
                    }
                    ToastManager.showToast(this,
                        getString(R.string.metadata_toast_album_art_changed),
                        ToastManager.LENGTH_NORMAL)
                }
            }
        }
    }

    private fun loadAlbumArtBytes(uri: Uri): ByteArray? {
        var input: InputStream? = null
        return try {
            input = contentResolver.openInputStream(uri) ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(input, null, bounds)
            input.close()
            val opts = BitmapFactory.Options().apply {
                inSampleSize = calculateInSampleSize(bounds, MAX_ALBUM_ART_SIZE_PX,
                    MAX_ALBUM_ART_SIZE_PX)
                inJustDecodeBounds = false
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            input = contentResolver.openInputStream(uri)
            var bmp = BitmapFactory.decodeStream(input, null, opts) ?: return null
            if (bmp.width > MAX_ALBUM_ART_SIZE_PX || bmp.height > MAX_ALBUM_ART_SIZE_PX) {
                val ratio = Math.min(MAX_ALBUM_ART_SIZE_PX.toFloat() / bmp.width,
                    MAX_ALBUM_ART_SIZE_PX.toFloat() / bmp.height)
                val newW = Math.round(bmp.width * ratio)
                val newH = Math.round(bmp.height * ratio)
                val scaled = Bitmap.createScaledBitmap(bmp, newW, newH, true)
                bmp.recycle(); bmp = scaled
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, ALBUM_ART_QUALITY, out)
            bmp.recycle()
            out.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Error loading album art", e); null
        } finally {
            try { input?.close() } catch (ignored: IOException) {}
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, rw: Int, rh: Int): Int {
        val h = options.outHeight; val w = options.outWidth
        var sample = 1
        if (h > rh || w > rw) {
            val halfH = h / 2; val halfW = w / 2
            while ((halfH / sample) >= rh && (halfW / sample) >= rw) sample *= 2
        }
        return sample
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SAF_FILE_PICKER) {
            mRequestInProgress = false
            if (resultCode == RESULT_OK && data != null) {
                val uri = data.data
                if (uri != null) {
                    mAwaitingFileSelection = false
                    mStorageAccessHelper?.takeFilePermission(uri)
                    mGrantedFileUri = uri
                    val resolved = getFilePathFromUri(uri)
                    if (resolved != null) mFilePath = resolved
                    mHeaderTitle?.setText(R.string.metadata_mode_view)
                    OverlayManager.show(OverlayManager.REASON_METADATA_LOAD)
                    mExecutor?.execute {
                        val bundle = MetadataReader.readMetadataFromUri(this, uri)
                        mMainHandler.post {
                            if (mIsDestroyed) return@post
                            OverlayManager.hide(OverlayManager.REASON_METADATA_LOAD)
                            mOriginalData = bundle
                            displayMetadata()
                            updateFileInfo()
                            mHeaderTitle?.setText(R.string.metadata_mode_view)
                            when (bundle.status) {
                                MetadataReader.MetadataBundle.Status.FILE_UNREADABLE -> {
                                    loadCurrentSongInViewMode()
                                    ToastManager.showToast(this,
                                        getString(R.string.metadata_toast_file_not_accessible),
                                        ToastManager.LENGTH_NORMAL)
                                }
                                MetadataReader.MetadataBundle.Status.PARSE_FAILED -> {
                                    loadCurrentSongInViewMode()
                                    ToastManager.showToast(this,
                                        getString(R.string.metadata_toast_could_not_read),
                                        ToastManager.LENGTH_NORMAL)
                                }
                                else -> {
                                    if (!bundle.isWriteSupported) {
                                        loadCurrentSongInViewMode()
                                        ToastManager.showToast(this,
                                            getString(R.string.metadata_toast_cannot_edit_format,
                                                bundle.format),
                                            ToastManager.LENGTH_NORMAL)
                                    } else {
                                        setActionButtonEnabled(true)
                                        mActionButton?.setText(R.string.action_modify)
                                    }
                                }
                            }
                            saveUriToDatabase()
                            enterEditMode()
                        }
                    }
                }
                return
            } else if (resultCode == RESULT_CANCELED && mAwaitingFileSelection) {
                finish(); return
            }
            return
        }
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            processSelectedAlbumArt(data.data)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_GALLERY_REQUEST) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) openGalleryForAlbumArt()
            else ToastManager.showToast(this,
                getString(R.string.metadata_toast_permission_needed_gallery),
                ToastManager.LENGTH_NORMAL)
        }
    }

    // ========================================================================
    // Song state
    // ========================================================================

    private fun checkCurrentSongState(): Int {
        val lastPath = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null)
        val path = mFilePath ?: return SONG_STATE_NOT_CURRENT
        if (path != lastPath) return SONG_STATE_NOT_CURRENT

        val wasPlaying = try {
            MusicService.getAudioSessionId() > 0 &&
                mServicePlayingCheck()
        } catch (e: Exception) {
            false
        }

        if (wasPlaying) {
            LlamaEventBus.post(TransportEvent.Pause)
            return SONG_STATE_WAS_PLAYING
        }
        return SONG_STATE_WAS_PAUSED
    }

    private fun mServicePlayingCheck(): Boolean =
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean("last_playing", false)

    // ========================================================================
    // Theme
    // ========================================================================

    private fun applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        OverlayManager.setColor(mThemeHelper.themeColorInt)
        mCancelButton?.let { mThemeHelper.updateButton(it, true) }
        setActionButtonEnabled(mActionButton?.isEnabled == true)
        val fields = arrayOf(mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit,
            mGenreEdit, mTrackEdit, mLyricsEdit)
        for (field in fields) {
            field ?: continue
            mThemeHelper.updateEditText(field)
            if (mCurrentMode == MODE_EDIT) {
                mThemeHelper.updateEditTextCursor(field)
                if (field.hasFocus()) {
                    field.setTextColor(mThemeManager.getCurrentColorInt())
                    field.setHintTextColor(mThemeManager.getCurrentColorInt())
                } else {
                    val ph = CharacterMapper.isAnyUnknownPlaceholder(field.text.toString())
                    field.setTextColor(Color.parseColor(if (ph) "#808080" else "#C0C0C0"))
                    field.setHintTextColor(Color.parseColor("#5A5A5A"))
                }
            } else {
                val ph = CharacterMapper.isAnyUnknownPlaceholder(field.text.toString())
                field.setTextColor(Color.parseColor(if (ph) "#808080" else "#C0C0C0"))
                field.setHintTextColor(mThemeHelper.mutedThemeColorInt)
            }
        }
        mFileInfoText?.let {
            mThemeHelper.updateEditText(it)
            val text = it.text?.toString() ?: ""
            it.setTextColor(Color.parseColor(if (text.isEmpty()) "#5A5A5A" else "#C0C0C0"))
            it.setHintTextColor(if (mCurrentMode == MODE_VIEW)
                mThemeHelper.mutedThemeColorInt else Color.parseColor("#5A5A5A"))
        }
        mAlbumArtHint?.setTextColor(Color.parseColor("#808080"))
        mHeaderTitle?.let {
            it.setTextColor(Color.parseColor("#C0C0C0")); it.letterSpacing = 0.1f
        }
        mFormatText?.let {
            it.letterSpacing = 0.1f; it.setTextColor(Color.parseColor("#C0C0C0"))
        }
        if (mOriginalData?.albumArt == null) setPlaceholderAlbumArt()
        forceRedraw()
    }

    private fun hideKeyboard() {
        val view = currentFocus ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun forceRedraw() {
        val root = findViewById<View>(android.R.id.content) ?: return
        root.requestLayout(); root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.updateConfiguration(resources.configuration, resources.displayMetrics)
        }
        recreate()
        overridePendingTransition(0, 0)
    }

    private fun dpToPx(dp: Int): Int = Math.round(dp * resources.displayMetrics.density)

    companion object {
        private const val TAG = "MetadataEditor"
    }
}