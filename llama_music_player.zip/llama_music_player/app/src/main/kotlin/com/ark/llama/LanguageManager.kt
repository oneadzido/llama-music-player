// LanguageManager.kt
package com.ark.llama

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import android.util.Log
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.SettingsEvent
import java.util.Locale

/**
 * Stores the application's current display language and exposes the
 * set of available languages.
 *
 * <p>The current language is selected by BCP 47 tag and persisted to
 * [SharedPreferences], and read back on the next process launch. The
 * class is the single source of truth for which language is applied;
 * [LanguageDialog] writes the selection through [setLanguage], and
 * every activity applies it by wrapping its base context through
 * [wrap] in `attachBaseContext`.</p>
 *
 * <h3>Available Languages</h3>
 * <p>The supported set is a curated list of the most widely used
 * languages in global streaming markets. Each language's display
 * name is its endonym. The set is declared once, in
 * [LANGUAGE_TAGS]; the display names are declared in
 * [LANGUAGE_NAMES] at the same index.</p>
 *
 * <h3>Locale Application</h3>
 * <p>Android applies a locale through the activity's base context.
 * [wrap] produces a context whose configuration carries the
 * selected locale; an activity that overrides
 * `attachBaseContext(Context)` with a call to that method receives
 * the selected locale throughout its lifetime.</p>
 *
 * <h3>The Localized Application Context</h3>
 * <p>Not every string in the app is resolved by an activity.
 * Singleton managers hold an application context and read
 * user-visible strings from it. An application context is not
 * wrapped by the activity's `attachBaseContext`; its resources
 * resolve against the system locale. Those managers therefore read
 * through [getLocalizedContext] instead, which returns a cached
 * application context wrapped with the currently selected locale.
 * The cache is invalidated by [setLanguage].</p>
 *
 * <h3>EventBus</h3>
 * <p>[setLanguage] posts a sticky [SettingsEvent.LanguageChanged]
 * on the process bus. Every activity and dialog that shows text
 * subscribes in STICKY mode and recreates itself on the change, so
 * a language selection propagates to the whole process in a single
 * turn.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The singleton instance is created under double-checked
 * locking. Every read returns the value held in memory at that
 * moment; [setLanguage] updates the in-memory value and clears the
 * cached localized context before scheduling the preference write,
 * so a subsequent read observes the new value even when the write
 * has not yet been flushed.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.3.0
 */
class LanguageManager private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    /** Application context used for preference access and locale application. */
    private val mContext: Context = context.applicationContext

    /**
     * Current language tag.
     *
     * <p>Written by [loadLanguage] during construction and by
     * [setLanguage] on every selection change. Read by every getter
     * and by [getCurrentLocale]. The {@code @Volatile} annotation is
     * what lets a background thread's read see a foreground thread's
     * write without a lock.</p>
     */
    @Volatile
    private var mCurrentLanguageTag: String = DEFAULT_LANGUAGE_TAG

    /**
     * Cached locale-wrapped application context, or null when the
     * cache has not been populated or has been invalidated by a
     * language change.
     *
     * <p>Populated lazily by [getLocalizedContext] under double-
     * checked locking; cleared by [setLanguage]. Volatile for the
     * same reason as [mCurrentLanguageTag].</p>
     */
    @Volatile
    private var mLocalizedContext: Context? = null

    init {
        loadLanguage()
    }

    // ========================================================================
    // Loading and saving
    // ========================================================================

    /**
     * Reads the persisted language tag into memory.
     *
     * <p>When the stored tag is missing or refers to a language that
     * is no longer in the supported set, the default tag is used.
     * This guards against two cases: first launch (no preference
     * stored), and a future release that drops a language the user
     * had previously selected (stored tag no longer in
     * [LANGUAGE_TAGS]).</p>
     */
    private fun loadLanguage() {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        var savedTag = preferences.getString(
            KEY_LANGUAGE_TAG, DEFAULT_LANGUAGE_TAG
        )
        if (savedTag == null || !isSupportedTag(savedTag)) {
            savedTag = DEFAULT_LANGUAGE_TAG
        }
        mCurrentLanguageTag = savedTag
    }

    /**
     * Applies the language with the given tag and persists the
     * selection.
     *
     * <p>A tag that is not in the supported set is ignored. A
     * supported tag updates the in-memory value, clears the cached
     * localized context, persists the tag, and posts a sticky
     * [SettingsEvent.LanguageChanged] so subscribers see the change
     * on the same turn.</p>
     *
     * <p>The order — memory, cache clear, persist, post — matters.
     * The memory write must precede the persist so a concurrent
     * reader on another thread sees the new value even before the
     * preference write has flushed; the cache clear must precede
     * the post so a subscriber that reads
     * [getLocalizedContext] inside its handler sees the new
     * language, not the stale cache.</p>
     *
     * @param languageTag BCP 47 tag of the language to apply
     */
    fun setLanguage(languageTag: String) {
        if (!isSupportedTag(languageTag)) {
            return
        }
        mCurrentLanguageTag = languageTag
        // The cached localized context was built for the previous
        // language tag; invalidate it so the next read rebuilds
        // against the new tag.
        mLocalizedContext = null
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE_TAG, languageTag)
            .apply()

        // Announce the change on the process bus. Sticky, so a
        // subscriber that registers after this call sees the current
        // language on registration.
        LlamaEventBus.postSticky(SettingsEvent.LanguageChanged(languageTag))
    }

    /**
     * Returns whether the given tag refers to a supported language.
     *
     * <p>O(n) linear scan over the sixteen supported tags. The list
     * is short enough that a hash set would add a class-load cost
     * for no measurable benefit.</p>
     */
    private fun isSupportedTag(languageTag: String): Boolean =
        LANGUAGE_TAGS.contains(languageTag)

    // ========================================================================
    // Getters — Java-bean surface preserved for interop
    // ========================================================================

    /**
     * Returns the current language tag.
     *
     * @return The current BCP 47 language tag, such as `"en"`
     */
    fun getCurrentLanguageTag(): String = mCurrentLanguageTag

    /**
     * Returns the index of the current language in the supported set.
     *
     * <p>Falls back to 0 (English) when the current tag is not
     * found. The fallback is unreachable in normal operation —
     * [setLanguage] and [loadLanguage] both guarantee the current
     * tag is in [LANGUAGE_TAGS] — but it keeps the return contract
     * total in case a future refactor breaks that invariant.</p>
     *
     * @return The index into the language arrays, or 0 when the
     *         current tag is not found
     */
    fun getCurrentLanguageIndex(): Int {
        for (index in LANGUAGE_TAGS.indices) {
            if (LANGUAGE_TAGS[index] == mCurrentLanguageTag) {
                return index
            }
        }
        return 0
    }

    /**
     * Returns the endonym of the current language.
     *
     * <p>An endonym is a language's name in its own language: "Español"
     * for Spanish, "中文" for Chinese, "Русский" for Russian. This is
     * what the language picker shows — a user who reads Chinese can
     * recognise 中文 even when the app is currently in a language
     * they do not read.</p>
     *
     * @return The name of the current language in its own language,
     *         such as `"Español"` for Spanish
     */
    fun getCurrentLanguageName(): String =
        LANGUAGE_NAMES[getCurrentLanguageIndex()]

    /**
     * Returns a copy of every supported language's endonym.
     *
     * <p>Copy returned so a caller that sorts or filters the array
     * cannot corrupt the manager's static table.</p>
     */
    fun getLanguageNames(): Array<String> = LANGUAGE_NAMES.copyOf()

    /**
     * Returns a copy of every supported language's English name.
     *
     * <p>Used by call sites that need to identify a language to a
     * reader who does not read that language — for example a
     * diagnostic log line, or a developer-facing debug screen.</p>
     */
    fun getLanguageNamesEn(): Array<String> = LANGUAGE_NAMES_EN.copyOf()

    /**
     * Returns a copy of every supported language's BCP 47 tag.
     */
    fun getLanguageTags(): Array<String> = LANGUAGE_TAGS.copyOf()

    /**
     * Returns the number of supported languages.
     */
    fun getLanguageCount(): Int = LANGUAGE_TAGS.size

    /**
     * Returns the display name of the language at the given index.
     *
     * @param languageIndex Index into the language arrays
     * @return The language's endonym, or null when the index is out
     *         of range
     */
    fun getLanguageName(languageIndex: Int): String? =
        if (languageIndex in LANGUAGE_NAMES.indices) {
            LANGUAGE_NAMES[languageIndex]
        } else {
            null
        }

    /**
     * Returns the BCP 47 tag of the language at the given index.
     *
     * @param languageIndex Index into the language arrays
     * @return The language tag, or null when the index is out of
     *         range
     */
    fun getLanguageTag(languageIndex: Int): String? =
        if (languageIndex in LANGUAGE_TAGS.indices) {
            LANGUAGE_TAGS[languageIndex]
        } else {
            null
        }

    // ========================================================================
    // Locale application
    // ========================================================================

    /**
     * Returns the current language as a [Locale].
     *
     * <p>Uses [Locale.forLanguageTag], which treats the tag as a
     * BCP 47 language tag and returns the appropriate [Locale]
     * instance. An empty tag produces [Locale.ROOT]; an
     * unrecognised tag produces a [Locale] with that tag as its
     * language field. Both are unreachable from [setLanguage]
     * because [isSupportedTag] rejects everything outside the
     * curated set.</p>
     */
    fun getCurrentLocale(): Locale =
        Locale.forLanguageTag(mCurrentLanguageTag)

    /**
     * Wraps the given context with the currently selected locale.
     *
     * <p>Called from an activity's `attachBaseContext(Context)`
     * override. The wrapped context carries the selected locale in
     * its configuration, so every string resolved from it is read
     * from the matching resource folder and every layout direction
     * is resolved under the locale's rules.</p>
     *
     * <p>[Locale.setDefault] is called as a side effect because a
     * few framework APIs that do not go through the wrapped context
     * — date formatters, number formatters, and some system services
     * — read the process-default locale. Setting it here keeps those
     * APIs consistent with the wrapped context.</p>
     *
     * @param context Base context to wrap
     * @return A context whose configuration carries the current
     *         locale
     */
    fun wrap(context: Context): Context {
        val locale = getCurrentLocale()
        Locale.setDefault(locale)
        val configuration = Configuration(
            context.resources.configuration
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            configuration.setLocales(LocaleList(locale))
        } else {
            @Suppress("DEPRECATION")
            configuration.locale = locale
        }
        return context.createConfigurationContext(configuration)
    }

    /**
     * Returns a locale-wrapped application context.
     *
     * <p>Every manager in the app that holds an application context
     * and reads user-visible strings resolves those strings through
     * the context this method returns. The wrapped context is cached
     * for the life of the current language tag. [setLanguage]
     * clears the cache.</p>
     *
     * <p>Safe to call from any thread. The double-check on the
     * volatile field avoids the synchronisation cost on the common
     * path: after the first call, the fast path reads the cached
     * reference without a lock. The `synchronized` block guarantees
     * that two threads that both miss the fast path produce
     * exactly one wrapped context.</p>
     */
    fun getLocalizedContext(): Context {
        mLocalizedContext?.let { return it }
        synchronized(LanguageManager::class.java) {
            mLocalizedContext?.let { return it }
            val wrapped = wrap(mContext)
            mLocalizedContext = wrapped
            return wrapped
        }
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val TAG = "LanguageManager"

        /** Preference file shared with every other manager. */
        private const val PREFS_NAME = "LlamaPrefs"

        /** Preference key under which the current language tag is stored. */
        private const val KEY_LANGUAGE_TAG = "app_language_tag"

        /** Default tag used on first launch and when the stored tag is invalid. */
        private const val DEFAULT_LANGUAGE_TAG = "en"

        /**
         * BCP 47 tags of the supported languages.
         *
         * <p>Index-aligned with [LANGUAGE_NAMES] and
         * [LANGUAGE_NAMES_EN]. The same set is declared in
         * `res/xml/locales_config.xml` and in the app module's
         * `resourceConfigurations`. Adding or removing a language
         * means editing all three.</p>
         *
         * <p>Indonesian is the one exception to the BCP 47
         * convention: the folder code Android uses is `in`
         * (inherited from the pre-standard Indonesian language
         * code) even though the current BCP 47 tag is `id`. The
         * resource folder is `values-in/`; the tag in this array
         * must match the folder.</p>
         */
        private val LANGUAGE_TAGS: Array<String> = arrayOf(
            "en",  // 0  English
            "es",  // 1  Spanish
            "fr",  // 2  French
            "de",  // 3  German
            "it",  // 4  Italian
            "pt",  // 5  Portuguese
            "ru",  // 6  Russian
            "zh",  // 7  Chinese
            "ja",  // 8  Japanese
            "ko",  // 9  Korean
            "hi",  // 10 Hindi
            "ar",  // 11 Arabic
            "tr",  // 12 Turkish
            "in",  // 13 Indonesian (folder code; current BCP 47 tag is "id")
            "nl",  // 14 Dutch
            "pl"   // 15 Polish
        )

        /**
         * Endonyms — the names of each language in that language —
         * index-aligned with [LANGUAGE_TAGS].
         */
        private val LANGUAGE_NAMES: Array<String> = arrayOf(
            "English",           // 0
            "Español",           // 1
            "Français",          // 2
            "Deutsch",           // 3
            "Italiano",          // 4
            "Português",         // 5
            "Русский",           // 6
            "中文",               // 7
            "日本語",             // 8
            "한국어",             // 9
            "हिन्दी",              // 10
            "العربية",            // 11
            "Türkçe",            // 12
            "Bahasa Indonesia",  // 13
            "Nederlands",        // 14
            "Polski"             // 15
        )

        /**
         * English exonyms — the names of each language in English —
         * index-aligned with [LANGUAGE_TAGS].
         */
        private val LANGUAGE_NAMES_EN: Array<String> = arrayOf(
            "English",     // 0
            "Spanish",     // 1
            "French",      // 2
            "German",      // 3
            "Italian",     // 4
            "Portuguese",  // 5
            "Russian",     // 6
            "Chinese",     // 7
            "Japanese",    // 8
            "Korean",      // 9
            "Hindi",       // 10
            "Arabic",      // 11
            "Turkish",     // 12
            "Indonesian",  // 13
            "Dutch",       // 14
            "Polish"       // 15
        )

        @Volatile
        private var sInstance: LanguageManager? = null

        /**
         * Returns the singleton instance, creating it on first call.
         */
        @JvmStatic
        fun getInstance(context: Context): LanguageManager {
            if (sInstance == null) {
                synchronized(LanguageManager::class.java) {
                    if (sInstance == null) {
                        sInstance = LanguageManager(context)
                    }
                }
            }
            return sInstance!!
        }

        /**
         * Releases the singleton.
         *
         * <p>Clears the cached localized context and the singleton
         * reference. Called only at process teardown.</p>
         */
        @JvmStatic
        fun shutdown() {
            val manager = sInstance
            if (manager != null) {
                manager.mLocalizedContext = null
                sInstance = null
            }
        }
    }
}