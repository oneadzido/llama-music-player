// LanguageDialog.kt
package com.ark.llama

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Presents the supported languages in a scrollable list and reports
 * the user's selection through [OnLanguageSelectedListener].
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.3.0
 */
class LanguageDialog(
    context: Context,
    private val mLanguageNames: Array<String>,
    private val mLanguageTags: Array<String>,
    private val mCurrentLanguageIndex: Int,
    private val mListener: OnLanguageSelectedListener?
) : Dialog(context, android.R.style.Theme_Black_NoTitleBar) {

    // ========================================================================
    // Constants
    // ========================================================================

    private val BACKGROUND_COLOR = "#121212"
    private val HEADER_BACKGROUND_COLOR = "#1A1A1A"
    private val SELECTED_BACKGROUND_COLOR = "#1E1E1E"
    private val TOUCH_HIGHLIGHT_COLOR = "#2A2A2A"
    private val TEXT_COLOR_LIGHT = "#C0C0C0"
    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val DISMISS_DELAY_MS = 500L
    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f
    private val TOP_BAR_HEIGHT_DP = 64
    private val HEADER_BAR_HEIGHT_DP = 40
    private val BUTTON_HEIGHT_DP = 36
    private val PADDING_STANDARD_DP = 16
    private val HEADER_PADDING_HORIZONTAL_DP = 16
    private val HEADER_PADDING_VERTICAL_DP = 4
    private val LIST_ITEM_PADDING_HORIZONTAL_DP = 16
    private val LIST_ITEM_PADDING_VERTICAL_DP = 12
    private val INDICATOR_PADDING_DP = 8
    private val BOTTOM_PADDING_DP = 8
    private val DIVIDER_THICKNESS_DP = 1
    private val HEADER_COUNT_MARGIN_START_DP = 8

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context
    private var mScrollView: ScrollView? = null
    private var mLanguageList: LinearLayout? = null
    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper
    private var mLastSelectionTime = 0L
    private var mLastCancelClickTime = 0L
    private val mMainHandler = Handler(Looper.getMainLooper())

    interface OnLanguageSelectedListener {
        fun onLanguageSelected(languageIndex: Int, languageName: String, languageTag: String)
    }

    init {
        mThemeManager = ThemeManager.getInstance(context)
        mThemeHelper = ThemeHelper.getInstance(context)
    }

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (e: Exception) {
        Log.w(TAG, "Failed to obtain localized context", e); mContext
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(createContentView())
        window?.let { configureWindow(it) }
        scrollToCurrentLanguage()
        applyThemeToButtons()
    }

    override fun dismiss() {
        super.dismiss()
        mMainHandler.removeCallbacksAndMessages(null)
    }

    private fun configureWindow(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = Color.parseColor(BACKGROUND_COLOR)
            window.navigationBarColor = Color.parseColor(BACKGROUND_COLOR)
        }
        val params = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.MATCH_PARENT
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.setWindowAnimations(R.style.LanguageDialogAnimation)
    }

    private fun applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        val root = findViewById<View>(android.R.id.content)
        if (root is ViewGroup) findAndThemeButtons(root)
        forceRedraw()
    }

    private fun findAndThemeButtons(group: ViewGroup) {
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child is Button) mThemeHelper.updateButton(child, true)
            else if (child is ViewGroup) findAndThemeButtons(child)
        }
    }

    private fun updateSelectedLanguage(newSelectedIndex: Int) {
        val themeColorInt = mThemeManager.getCurrentColorInt()
        val list = mLanguageList ?: return
        for (index in 0 until list.childCount) {
            val child = list.getChildAt(index)
            if (child !is LinearLayout) continue
            val tag = child.tag
            if (tag !is Int) continue
            val languageIndex = tag
            val isSelected = languageIndex == newSelectedIndex

            child.setBackgroundColor(if (isSelected)
                Color.parseColor(SELECTED_BACKGROUND_COLOR) else Color.TRANSPARENT)

            if (child.childCount > 0) {
                val nameChild = child.getChildAt(0)
                if (nameChild is TextView) {
                    nameChild.setTextColor(if (isSelected) themeColorInt
                    else Color.parseColor(TEXT_COLOR_LIGHT))
                }
            }
            if (child.childCount > 1) {
                val ind = child.getChildAt(1)
                if (ind is TextView) {
                    if (isSelected) {
                        ind.text = getLocaleContext().getString(R.string.language_dialog_current)
                        ind.textSize = 12f; ind.letterSpacing = 0.1f
                        ind.setTextColor(themeColorInt)
                        ind.visibility = View.VISIBLE
                    } else ind.visibility = View.GONE
                }
            }
        }
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
            }
            false
        }
    }

    private fun animateLanguageSelection(
        view: View, languageIndex: Int, languageName: String, languageTag: String
    ) {
        updateSelectedLanguage(languageIndex)
        view.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
            .setDuration(ANIMATION_DURATION_MS.toLong())
            .withEndAction {
                view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                    .scaleY(ANIMATION_SCALE_NORMAL)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
            }.start()
        mMainHandler.postDelayed({
            mListener?.onLanguageSelected(languageIndex, languageName, languageTag)
            dismiss()
        }, DISMISS_DELAY_MS)
    }

    private fun scrollToCurrentLanguage() {
        val scroll = mScrollView ?: return
        val list = mLanguageList ?: return
        if (mCurrentLanguageIndex < 0) return
        scroll.post {
            val targetIndex = findLanguageIndex()
            if (targetIndex >= 0) {
                val target = list.getChildAt(targetIndex) ?: return@post
                mMainHandler.postDelayed({
                    val scrollHeight = scroll.height
                    val targetTop = target.top
                    val targetHeight = target.height
                    val scrollY = targetTop - (scrollHeight / 2) + (targetHeight / 2)
                    scroll.smoothScrollTo(0, Math.max(0, scrollY))
                }, 0L)
            }
        }
    }

    private fun findLanguageIndex(): Int {
        val list = mLanguageList ?: return -1
        for (i in 0 until list.childCount) {
            val child = list.getChildAt(i)
            val tag = child.tag
            if (child is LinearLayout && tag is Int && tag == mCurrentLanguageIndex) return i
        }
        return -1
    }

    private fun createContentView(): View {
        val main = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(BACKGROUND_COLOR))
            cornerRadii = floatArrayOf(
                dpToPx(20).toFloat(), dpToPx(20).toFloat(),
                dpToPx(20).toFloat(), dpToPx(20).toFloat(),
                0f, 0f, 0f, 0f
            )
        }
        main.background = bg
        main.addView(createTopBar())
        main.addView(createHeader())
        main.addView(createScrollableList())
        main.addView(createBottomPadding())
        return main
    }

    private fun createTopBar(): LinearLayout {
        val bar = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP))
            setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
                dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP))
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        bar.addView(createCancelButton())
        bar.addView(createTitleText())
        bar.addView(createPlaceholder())
        return bar
    }

    private fun createCancelButton(): Button {
        val button = Button(mContext).apply {
            text = getLocaleContext().getString(R.string.action_cancel)
            textSize = 14f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            setPadding(dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3),
                dpToPx(INDICATOR_PADDING_DP), dpToPx(LIST_ITEM_PADDING_VERTICAL_DP / 3))
            minHeight = 0; minWidth = 0; includeFontPadding = false; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        }
        button.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelClickTime = now; dismiss()
            }
        }
        animateButton(button)
        return button
    }

    private fun createTitleText(): TextView {
        val localeContext = getLocaleContext()
        return TextView(localeContext).apply {
            text = localeContext.getString(R.string.language_dialog_title)
            textSize = 14f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            gravity = Gravity.CENTER
            includeFontPadding = false; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                0, dpToPx(BUTTON_HEIGHT_DP), 1f).apply {
                marginStart = dpToPx(8); marginEnd = dpToPx(8)
            }
        }
    }

    private fun createPlaceholder(): View = Button(mContext).apply {
        text = getLocaleContext().getString(R.string.action_themes)
        textSize = 14f; letterSpacing = 0.1f
        setBackgroundResource(R.drawable.button_border_selector)
        setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
        minHeight = 0; minWidth = 0; includeFontPadding = false; isSingleLine = true
        ellipsize = android.text.TextUtils.TruncateAt.END
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        visibility = View.INVISIBLE; isEnabled = false; isFocusable = false
    }

    private fun createHeader(): LinearLayout {
        val header = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP),
                dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP))
            setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR))
        }
        val title = TextView(mContext).apply {
            text = getLocaleContext().getString(R.string.language_dialog_list_header)
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val count = TextView(mContext).apply {
            text = getLocaleContext().resources.getQuantityString(
                R.plurals.language_dialog_count, mLanguageNames.size, mLanguageNames.size)
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dpToPx(HEADER_COUNT_MARGIN_START_DP)
            }
        }
        header.addView(title)
        header.addView(count)
        return header
    }

    private fun createScrollableList(): ScrollView {
        val scroll = ScrollView(mContext).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        mScrollView = scroll

        val list = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        mLanguageList = list

        for (i in mLanguageNames.indices) {
            val selected = i == mCurrentLanguageIndex
            list.addView(createLanguageItem(i, mLanguageNames[i], mLanguageTags[i], selected))
            if (i < mLanguageNames.size - 1) list.addView(createDivider())
        }
        scroll.addView(list)
        return scroll
    }

    private fun createLanguageItem(
        languageIndex: Int, name: String, tag: String, selected: Boolean
    ): LinearLayout {
        val item = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
            setPaddingRelative(dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
                dpToPx(LIST_ITEM_PADDING_VERTICAL_DP),
                dpToPx(LIST_ITEM_PADDING_HORIZONTAL_DP),
                dpToPx(LIST_ITEM_PADDING_VERTICAL_DP))
            this.tag = languageIndex
            setBackgroundColor(if (selected) Color.parseColor(SELECTED_BACKGROUND_COLOR)
            else Color.TRANSPARENT)
        }
        item.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.setBackgroundColor(
                    Color.parseColor(TOUCH_HIGHLIGHT_COLOR))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val idx = item.tag as? Int ?: -1
                    view.setBackgroundColor(if (idx == mCurrentLanguageIndex)
                        Color.parseColor(SELECTED_BACKGROUND_COLOR) else Color.TRANSPARENT)
                }
            }
            false
        }

        val nameView = TextView(mContext).apply {
            text = name; textSize = 14f; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(if (selected) mThemeManager.getCurrentColorInt()
            else Color.parseColor(TEXT_COLOR_LIGHT))
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val indicator = TextView(mContext).apply {
            if (selected) {
                text = getLocaleContext().getString(R.string.language_dialog_current)
                textSize = 12f; letterSpacing = 0.1f
                setTextColor(mThemeManager.getCurrentColorInt())
                visibility = View.VISIBLE
            } else visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dpToPx(INDICATOR_PADDING_DP)
            }
        }

        item.addView(nameView)
        item.addView(indicator)

        item.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastSelectionTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastSelectionTime = now
                animateLanguageSelection(item, languageIndex, name, tag)
            }
        }
        return item
    }

    private fun createDivider(): View = View(mContext).apply {
        setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP))
    }

    private fun createBottomPadding(): View = View(mContext).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP))
    }

    private fun forceRedraw() {
        val window = window ?: return
        val root = window.decorView.findViewById<View>(android.R.id.content) ?: return
        root.requestLayout(); root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * mContext.resources.displayMetrics.density)

    companion object {
        private const val TAG = "LanguageDialog"
    }
}