// TransportEvents.kt
package com.ark.llama.event

/**
 * Transport-command events posted on the process EventBus.
 *
 * <p>Consumer: [com.ark.llama.MusicService]. Producers are the player
 * activity's transport buttons, the album-art gesture classifier, the
 * media session callbacks, the notification action intents, the
 * Bluetooth receiver, and the metadata editor's pause-and-resume
 * surrounding a write.</p>
 *
 * <p>The action-shaped events ([TogglePlayPause], [Next],
 * [Previous], [Resume], [Pause], [Stop], [ToggleFavorite],
 * [RequestResumeFromGesture], [SavePlayerState]) carry no payload;
 * they exist to name the command. The data-shaped events ([PlaySong],
 * [PlaySongByIndex], [PlaySongAtPosition], [SeekTo], [SetPendingSong],
 * [SetRepeatMode], [SetShuffle], [SetBluetoothConnected],
 * [SetPlaybackSortMode]) carry the argument the service needs.</p>
 *
 * <p>Using an event bus keeps the service the sole authority on
 * playback state while letting the producer — sometimes an activity,
 * sometimes a receiver, sometimes the service itself — be anywhere in
 * the process.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface TransportEvent {

    /**
     * Toggle between playing and paused.
     *
     * <p>The service's behaviour depends on its current state:
     * PLAYING pauses, PAUSED or READY resumes, IDLE begins a
     * transition to the current target, PREPARING flips the
     * pause-after-prepare flag.</p>
     */
    object TogglePlayPause : TransportEvent

    /**
     * Advance to the next song.
     *
     * <p>Honours the current repeat mode and shuffle setting. Under
     * repeat-one, restarts the current song. Under shuffle,
     * consults the service's shuffle history.</p>
     */
    object Next : TransportEvent

    /**
     * Go back to the previous song.
     *
     * <p>The mirror of [Next]. Under shuffle, pops the shuffle
     * history. Under repeat-one, restarts the current song.</p>
     */
    object Previous : TransportEvent

    /**
     * Resume playback.
     *
     * <p>Distinct from [TogglePlayPause] in that it only ever
     * resumes. Used from the Bluetooth resume path, from the
     * metadata editor after a write completes, and from any
     * producer that has explicitly decided the action is resume
     * rather than toggle.</p>
     */
    object Resume : TransportEvent

    /**
     * Pause playback.
     *
     * <p>The mirror of [Resume]: only ever pauses. Used from the
     * Bluetooth disconnect path, from the metadata editor before a
     * write, and from any producer that has explicitly decided the
     * action is pause.</p>
     */
    object Pause : TransportEvent

    /**
     * Stop playback, keeping the current song loaded.
     *
     * <p>Different from [Pause] in that the playback position is
     * reset. The next [Resume] begins from the start of the current
     * song, not from the pause position.</p>
     */
    object Stop : TransportEvent

    /**
     * Toggle the current song's favorite flag.
     *
     * <p>The service reads the current song, flips its flag,
     * persists the change, and re-broadcasts a [PlayerEvent.Snapshot]
     * with the new flag. Both the player screen and the playlist
     * screen observe the change through their snapshot handlers.</p>
     */
    object ToggleFavorite : TransportEvent

    /**
     * Request a resume from the album-art upward swipe.
     *
     * <p>Distinct from [Resume] because the gesture path defers on a
     * refused audio-focus grant rather than dropping the request.
     * The service holds the request until AUDIOFOCUS_GAIN arrives or
     * the user acts again.</p>
     *
     * <p>Rationale: a user who swiped upward has explicitly asked
     * for playback. If another app holds audio focus at the moment
     * of the gesture, the request must survive the wait rather than
     * fail silently. The flag lives on the service and fires from
     * the AUDIOFOCUS_GAIN branch of the focus listener.</p>
     */
    object RequestResumeFromGesture : TransportEvent

    /**
     * Persist the current player state to SharedPreferences now.
     *
     * <p>Called by the folder manager before a folder update runs,
     * so the service's position and current-song state are durable
     * across the update cycle even if the process is killed.</p>
     */
    object SavePlayerState : TransportEvent

    /**
     * Play the song at the given path.
     *
     * <p>If the path is not in the current playlist, the service
     * parks it as the pending song and waits for the playlist to
     * include it. This is how the incoming-file path plays a song
     * that has not yet been inserted into the library.</p>
     *
     * @property path Absolute path, or null to no-op
     */
    data class PlaySong(
        val path: String?
    ) : TransportEvent

    /**
     * Play the song at the given playlist index.
     *
     * @property index Playlist index
     */
    data class PlaySongByIndex(
        val index: Int
    ) : TransportEvent

    /**
     * Play the song at the given playlist index, starting at the
     * given position.
     *
     * <p>Used by the cold-start path to resume the last-played song
     * at the last-persisted position.</p>
     *
     * @property index Playlist index
     * @property positionMs Start position in milliseconds
     */
    data class PlaySongAtPosition(
        val index: Int,
        val positionMs: Int
    ) : TransportEvent

    /**
     * Seek to the given position within the current track.
     *
     * @property positionMs Target position in milliseconds
     */
    data class SeekTo(
        val positionMs: Int
    ) : TransportEvent

    /**
     * Set the path queued for playback once it enters the playlist.
     *
     * <p>Clears when the playlist subsequently contains the path
     * and the state machine begins its transition to it.</p>
     *
     * @property path Path to queue, or null to clear
     */
    data class SetPendingSong(
        val path: String?
    ) : TransportEvent

    /**
     * Set the repeat mode.
     *
     * @property mode 0 repeat off, 1 repeat all, 2 repeat one
     */
    data class SetRepeatMode(
        val mode: Int
    ) : TransportEvent

    /**
     * Set the shuffle flag.
     *
     * <p>Enabling shuffle clears the shuffle history. Disabling
     * shuffle leaves the current song in place and re-syncs the
     * previous and next neighbours against the non-shuffled order.</p>
     *
     * @property enabled True to enable shuffle
     */
    data class SetShuffle(
        val enabled: Boolean
    ) : TransportEvent

    /**
     * Record whether a Bluetooth headset is currently connected.
     *
     * <p>Read by the service's media-button handler to decide
     * whether volume-up and volume-down should be interpreted as
     * next and previous.</p>
     *
     * @property connected True when connected
     */
    data class SetBluetoothConnected(
        val connected: Boolean
    ) : TransportEvent

    /**
     * Set the playlist sort mode.
     *
     * <p>Posted by [com.ark.llama.PlaylistActivity.cycleSortMode].
     * The service sorts its current playlist on the sort executor
     * and re-broadcasts through the ordinary UPDATE_PLAYER turn.</p>
     *
     * <p>The ten sort modes are:</p>
     * <ul>
     *   <li>0 title A→Z, 1 title Z→A</li>
     *   <li>2 artist A→Z, 3 artist Z→A</li>
     *   <li>4 album A→Z, 5 album Z→A</li>
     *   <li>6 genre A→Z, 7 genre Z→A</li>
     *   <li>8 oldest first, 9 newest first</li>
     * </ul>
     *
     * @property sortMode Sort mode index (0..9)
     */
    data class SetPlaybackSortMode(
        val sortMode: Int
    ) : TransportEvent
}