// PlaylistEvents.kt
package com.ark.llama.event

/**
 * Playlist-surface events posted on the process EventBus.
 *
 * <p>Producers: [com.ark.llama.PlaylistManager] (sync lifecycle,
 * genre loading, library reset), [com.ark.llama.StorageObserver]
 * (refresh trigger), [com.ark.llama.FolderManager] (sync started),
 * and [com.ark.llama.MusicLibrary] (per-song progress).</p>
 *
 * <p>Events in this file fall into three kinds:</p>
 * <ul>
 *   <li><b>Action-shaped</b> ([Refresh], [Display], [SyncComplete]):
 *       a named command with no payload.</li>
 *   <li><b>Progress-shaped</b> ([SyncStarted], [TriggerGenreLoading],
 *       [SongAdded]): a caller-supplied message or a per-item
 *       payload.</li>
 *   <li><b>Lifecycle-shaped</b> ([LibraryReset]): a signal that a
 *       whole-library state change has occurred, carrying the
 *       minimum context a consumer needs to react correctly.</li>
 * </ul>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface PlaylistEvent {

    /**
     * The library has been reset.
     *
     * <p>Sticky: a consumer that registers after the reset receives
     * the event on registration and clears its song-derived state.
     * Every cache owner — [com.ark.llama.MusicLibrary],
     * [com.ark.llama.PlaylistActivity],
     * [com.ark.llama.MusicService] — reacts to this single signal.</p>
     *
     * <p>The sticky is not removed by its consumers because a
     * freshly created activity may need to observe it after the
     * reset has already fired — a user who resets the library,
     * presses Back, then reopens the app from Recents still needs
     * the reset's effect to reach the new activity.</p>
     *
     * @property preserveSettings True when the reset preserved user
     *        preferences (LIBRARY mode); false when the reset cleared
     *        them (FACTORY mode)
     */
    data class LibraryReset(
        val preserveSettings: Boolean
    ) : PlaylistEvent

    /**
     * A soft refresh of the playlist from the songs table. Producers
     * post this after a scan, after a loose-track insert, and after
     * a file observed by the storage observer.
     *
     * <p>Consumers re-read the songs table and rebuild their
     * in-memory list. The playlist activity, the player activity,
     * and the service each handle it independently.</p>
     */
    object Refresh : PlaylistEvent

    /**
     * A redraw of the playlist activity's displayed list, without
     * re-reading the songs table.
     *
     * <p>Used after a metadata edit that changed only the display
     * fields of one row — the playlist activity already has the
     * song in memory and only needs to redraw.</p>
     */
    object Display : PlaylistEvent

    /**
     * A playlist sync has started, with the operation's initial text
     * and its ownership token.
     *
     * <p>Consumers that show a persistent overlay (via
     * [com.ark.llama.ToastManager]) use the operation ID to claim
     * the overlay and the two text fields to compose the initial
     * message.</p>
     *
     * @property customText Optional caller-supplied overlay text
     * @property customDetail Optional caller-supplied body text
     * @property operationId The operation ID that owns the overlay
     *        for the sync's duration
     */
    data class SyncStarted(
        val customText: String?,
        val customDetail: String?,
        val operationId: String?
    ) : PlaylistEvent

    /**
     * A playlist sync has finished.
     *
     * <p>Consumers that track the sync-in-progress state use this to
     * clear it. The event is not sticky: a consumer that registers
     * after the sync completes has no need to replay the finish
     * signal.</p>
     */
    object SyncComplete : PlaylistEvent

    /**
     * A trigger to begin the genre-loading pass on the songs whose
     * genre is still the app's placeholder.
     *
     * <p>Posted by [com.ark.llama.StorageObserver] after a storage
     * change settles. The optional custom message lets the caller
     * rename the persistent overlay that the loading pass will
     * create.</p>
     *
     * @property customMessage Optional caller-supplied overlay text
     */
    data class TriggerGenreLoading(
        val customMessage: String?
    ) : PlaylistEvent

    /**
     * A single song has been added to the playlist during a scan,
     * carrying the fields a playlist row needs.
     *
     * <p>Posted once per song by [com.ark.llama.MusicLibrary] during
     * a progress-reporting scan. The playlist activity appends each
     * event to its display list incrementally, so the user sees rows
     * appear as the scan proceeds rather than all at once at the
     * end.</p>
     *
     * @property songPath Absolute path of the added song
     * @property songTitle Title read from the file, or null
     * @property songArtist Artist read from the file, or null
     * @property songAlbum Album read from the file, or null
     * @property songGenre Genre read from the file, or null
     * @property songDuration Duration read from the file, in ms
     * @property currentCount Running count of discovered songs
     */
    data class SongAdded(
        val songPath: String,
        val songTitle: String?,
        val songArtist: String?,
        val songAlbum: String?,
        val songGenre: String?,
        val songDuration: Long,
        val currentCount: Int
    ) : PlaylistEvent
}