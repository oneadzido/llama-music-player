// FolderManager.kt
package com.ark.llama

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.PlaylistEvent
import com.ark.llama.event.SettingsEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.ArrayList
import java.util.HashSet

/**
 * Displays and edits the set of imported music folders and the
 * Loose Tracks entry.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class FolderManager : Activity(),
    NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    private val FOLDER_SELECT_CODE = 300
    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f
    private val EMPTY_CONTAINER_PADDING_DP = 32
    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val FOLDER_RELOAD_DELAY_MS = 100L
    private val OPERATION_FOLDER_SYNC = "FOLDER_SYNC"
    private val STORAGE_TYPE_SEPARATOR = " "
    private val PREFS_NAME = "LlamaPrefs"
    private val KEY_SELECTED_FOLDERS_URIS = "selected_folders_uris"
    private val KEY_PLAYBACK_SCOPE_JSON = "playback_scope_json"

    // ========================================================================
    // PendingChanges holder
    // ========================================================================

    private class PendingChanges {

        private val mFoldersToRemove = ArrayList<String>()
        private var mClearLooseTracks = false

        fun addFolderToRemove(folderUri: String) {
            if (!mFoldersToRemove.contains(folderUri)) {
                mFoldersToRemove.add(folderUri)
            }
        }

        fun markLooseTracksForRemoval() {
            mClearLooseTracks = true
        }

        fun isEmpty(): Boolean = mFoldersToRemove.isEmpty() && !mClearLooseTracks

        fun isClearLooseTracks(): Boolean = mClearLooseTracks

        fun getFoldersToRemove(): ArrayList<String> = ArrayList(mFoldersToRemove)

        fun clear() {
            mFoldersToRemove.clear()
            mClearLooseTracks = false
        }
    }

    // ========================================================================
    // State
    // ========================================================================

    private lateinit var mMusicLibrary: MusicLibrary
    private var mFoldersRecyclerView: RecyclerView? = null
    private var mFolderAdapter: FolderAdapter? = null
    private lateinit var mFolderItems: MutableList<FolderAdapter.FolderItem>
    private var mFolderCountText: TextView? = null
    private var mScopeButton: Button? = null
    private val mPendingChanges = PendingChanges()
    private var mEmptyContainer: LinearLayout? = null
    private var mRootContainer: FrameLayout? = null

    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper

    private var mLastCancelClickTime = 0L
    private var mLastScopeClickTime = 0L

    private val mMainHandler = Handler(Looper.getMainLooper())

    // ========================================================================
    // Language
    // ========================================================================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase)
        )
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ToastManager.init(this)
        OverlayManager.init(this)

        setFullScreen()
        setContentView(R.layout.activity_folder_manager)

        CharacterMapper.init(this)

        LlamaEventBus.register(this)

        mMusicLibrary = MusicLibrary(this)
        mThemeManager = ThemeManager.getInstance(this)
        mThemeHelper = ThemeHelper.getInstance(this)
        mFolderItems = ArrayList()

        initializeViews()
        loadFolders()

        applyThemeToUI()
        themeAllHeaders()

        NavigationController.getInstance().registerListener(this)
    }

    override fun onResume() {
        super.onResume()

        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS
            )
        )

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed({
                ToastManager.ensureOverlayAttached(this)
                ToastManager.reattachToCurrentActivity(this)
            }, 100L)
        }

        loadFolders()
        applyThemeToUI()
        themeAllHeaders()
        ToastManager.refreshThemeColor()
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "onRestart - FolderManager resumed, update in progress: ${isUpdating()}")

        if (ToastManager.hasPersistentToast()) {
            mMainHandler.postDelayed({
                ToastManager.ensureOverlayAttached(this)
                ToastManager.reattachToCurrentActivity(this)
            }, 100L)
        }

        ToastManager.ensureOverlayAttached(this)
        updateFolderButtons()
        loadFolders()
        applyThemeToUI()
        themeAllHeaders()

        if (isUpdating()) {
            val playlistManager = PlaylistManager.getInstance(this)
            if (playlistManager.isUpdating()) {
                ToastManager.ensureOverlayAttached(this)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        NavigationController.getInstance().unregisterListener(this)
        LlamaEventBus.unregister(this)

        mMainHandler.removeCallbacksAndMessages(null)

        mMusicLibrary.shutdown()
    }

    override fun onBackPressed() {
        returnToMusicPlayer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }
    }

    override fun onConfigurationChanged(config: Configuration) {
        super.onConfigurationChanged(config)
        updateLayoutForConfiguration()
        forceRedraw()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            data.data?.let { persistFolderPermission(it) }
        }
    }

    // ========================================================================
    // LlamaEventBus subscribers
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onLibraryReset(event: PlaylistEvent.LibraryReset) {
        Log.d(TAG, "LIBRARY_RESET received — invalidating library and reloading folders")
        mMusicLibrary.invalidate()
        loadFolders()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onSyncComplete(event: PlaylistEvent.SyncComplete) {
        Log.d(TAG, "Sync complete - scheduling folder list reload")
        mMainHandler.postDelayed({
            if (!isFinishing && !isDestroyed) loadFolders()
        }, FOLDER_RELOAD_DELAY_MS)
    }

    // ========================================================================
    // Layout
    // ========================================================================

    private fun updateLayoutForConfiguration() {
        val adapter = mFolderAdapter ?: return
        if (adapter.itemCount == 0) showEmptyView() else hideEmptyView()
    }

    // ========================================================================
    // Navigation
    // ========================================================================

    private fun returnToMusicPlayer() {
        val intent = Intent(this, MusicPlayer::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    // ========================================================================
    // Update state
    // ========================================================================

    private fun isUpdating(): Boolean =
        NavigationController.getInstance().isGroupDisabled(
            NavigationController.ButtonGroup.FOLDER_ACTIONS
        )

    private fun areFolderChangesAllowed(): Boolean =
        PermissionChecker.allGranted(this) && !isUpdating()

    // ========================================================================
    // NavigationController listener
    // ========================================================================

    override fun onButtonStateChanged(
        group: NavigationController.ButtonGroup,
        disabled: Boolean
    ) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            runOnUiThread { updateFolderButtons() }
        }
    }

    // ========================================================================
    // Full-screen
    // ========================================================================

    @Suppress("DEPRECATION")
    private fun setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.statusBarColor = resources.getColor(R.color.backgroundDark, null)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark, null)
            } else {
                window.statusBarColor = resources.getColor(R.color.backgroundDark)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    // ========================================================================
    // View init
    // ========================================================================

    private fun initializeViews() {
        mFoldersRecyclerView = findViewById(R.id.foldersRecyclerView)
        mFoldersRecyclerView?.let {
            it.layoutManager = LinearLayoutManager(this)
            val divider = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
            ContextCompat.getDrawable(this, R.drawable.divider_custom)?.let { drawable ->
                divider.setDrawable(drawable)
            }
            it.addItemDecoration(divider)
        }

        mFolderCountText = findViewById(R.id.folderCountText)
        mRootContainer = findViewById(R.id.rootContainer)
        mScopeButton = findViewById(R.id.scopeButton)

        val importFolderButton: Button? = findViewById(R.id.importFolderButton)
        val updateButton: Button? = findViewById(R.id.updateButton)
        val cancelButton: Button? = findViewById(R.id.cancelButton)

        animateButton(importFolderButton)
        animateButton(updateButton)
        animateButton(cancelButton)
        animateButton(mScopeButton)

        mScopeButton?.setOnClickListener {
            if (isUpdating()) return@setOnClickListener
            val now = SystemClock.elapsedRealtime()
            if (now - mLastScopeClickTime < CLICK_DEBOUNCE_DELAY_MS) return@setOnClickListener
            mLastScopeClickTime = now
            openPlaybackScopeDialog()
        }

        mFolderAdapter = FolderAdapter(
            this,
            mFolderItems,
            object : FolderAdapter.OnFolderRemoveListener {
                override fun onFolderRemove(folderUriString: String, position: Int) {
                    mPendingChanges.addFolderToRemove(folderUriString)
                    mFolderAdapter?.removeItem(position)
                    updateFolderCount()
                    updateFolderButtons()
                    if (mFolderAdapter?.itemCount == 0) showEmptyView()
                }

                override fun onLooseTracksRemove() {
                    mPendingChanges.markLooseTracksForRemoval()
                    for (index in mFolderItems.indices) {
                        if (mFolderItems[index].isLooseTracks) {
                            mFolderAdapter?.removeItem(index)
                            break
                        }
                    }
                    updateFolderCount()
                    updateFolderButtons()
                    if (mFolderAdapter?.itemCount == 0) showEmptyView()
                }
            },
            object : FolderAdapter.RemoveButtonStateSource {
                override fun areRemoveButtonsEnabled(): Boolean =
                    areFolderChangesAllowed()
            }
        )

        mFoldersRecyclerView?.adapter = mFolderAdapter

        importFolderButton?.setOnClickListener {
            if (!isUpdating()) selectFolder()
        }

        updateButton?.setOnClickListener {
            if (!isUpdating()) saveChanges()
        }

        cancelButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelClickTime = now
                returnToMusicPlayer()
            }
        }
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
            }
            false
        }
    }

    // ========================================================================
    // Empty state
    // ========================================================================

    private fun showEmptyView() {
        mEmptyContainer?.let { existing ->
            val parent = existing.parent
            if (parent is ViewGroup) parent.removeView(existing)
            mEmptyContainer = null
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP),
                dpToPx(EMPTY_CONTAINER_PADDING_DP)
            )
        }

        val emptyText = TextView(this).apply {
            setText(R.string.folder_manager_empty_state)
            setTextColor(Color.parseColor("#C0C0C0"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        container.addView(emptyText)

        mFoldersRecyclerView?.let { rv ->
            val parent = rv.parent
            if (parent is LinearLayout) {
                parent.addView(
                    container,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
                    )
                )
            }
            rv.visibility = View.GONE
        }

        mEmptyContainer = container
    }

    private fun hideEmptyView() {
        mEmptyContainer?.let { existing ->
            val parent = existing.parent
            if (parent is ViewGroup) parent.removeView(existing)
            mEmptyContainer = null
        }
        mFoldersRecyclerView?.visibility = View.VISIBLE
    }

    private fun updateFolderCount() {
        var folderCount = 0
        var hasLooseTracks = false
        for (item in mFolderItems) {
            if (item.isLooseTracks) hasLooseTracks = true else folderCount++
        }
        if (hasLooseTracks) folderCount++

        mFolderCountText?.let {
            it.setTextColor(Color.parseColor("#C0C0C0"))
            it.text = resources.getQuantityString(R.plurals.folder_count, folderCount, folderCount)
        }
    }

    // ========================================================================
    // Theme
    // ========================================================================

    private fun applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())

        val importFolderButton: Button? = findViewById(R.id.importFolderButton)
        val updateButton: Button? = findViewById(R.id.updateButton)
        val cancelButton: Button? = findViewById(R.id.cancelButton)

        importFolderButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        updateButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        cancelButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mScopeButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }

        mFolderAdapter?.refreshRemoveButtonStates()
        forceRedraw()
    }

    private fun themeAllHeaders() {
        mFolderCountText?.setTextColor(Color.parseColor("#C0C0C0"))
        val root = findViewById<View>(android.R.id.content)
        if (root is ViewGroup) themeHeadersRecursive(root)
    }

    private fun themeHeadersRecursive(group: ViewGroup) {
        for (index in 0 until group.childCount) {
            val child = group.getChildAt(index)
            if (child is TextView && child !is Button) {
                val text = child.text.toString()
                if (text == getString(R.string.folder_manager_title) ||
                    text == getString(R.string.folder_manager_list_header)
                ) {
                    child.setTextColor(Color.parseColor("#C0C0C0"))
                }
            } else if (child is ViewGroup) {
                themeHeadersRecursive(child)
            }
        }
    }

    // ========================================================================
    // Folder management
    // ========================================================================

    private fun persistFolderPermission(treeUri: Uri) {
        val helper = StorageAccessHelper.getInstance(this)
        val folderPath = helper.getFolderPathFromUri(treeUri)

        if (!helper.storeFolderPermission(treeUri, folderPath)) {
            ToastManager.showToast(
                this,
                getString(R.string.folder_manager_permission_denied),
                ToastManager.LENGTH_NORMAL
            )
            return
        }

        val folderUriString = treeUri.toString()
        mMusicLibrary.addFolder(folderUriString)
        cleanLooseSongsInFolder(treeUri)
        loadFolders()

        getFolderNameFromUri(treeUri)?.let { name ->
            ToastManager.showToast(
                this,
                getString(R.string.folder_manager_imported_toast, name),
                ToastManager.LENGTH_NORMAL
            )
        }
    }

    private fun cleanLooseSongsInFolder(folderUri: Uri) {
        val folderPath = getFolderPathFromUri(folderUri) ?: return
        val looseSongs = SongDatabase.getInstance(this).getLooseSongs()
        if (looseSongs.isEmpty()) return

        val normalized = if (folderPath.endsWith("/")) folderPath else "$folderPath/"
        for (song in looseSongs) {
            if (song != null && song.path.startsWith(normalized)) {
                SongDatabase.getInstance(this).removeLooseSong(song.path)
            }
        }
    }

    private fun getFolderPathFromUri(uri: Uri): String? =
        StorageAccessHelper.getInstance(this).getFolderPathFromUri(uri)

    private fun getFolderNameFromUri(uri: Uri): String? {
        var name: String? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx != -1) name = cursor.getString(idx)
            }
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to get folder name", exception)
        } finally {
            try { cursor?.close() } catch (ignored: Exception) { }
        }

        if (name == null) {
            uri.lastPathSegment?.let { segment ->
                name = if (segment.contains(":")) {
                    segment.substring(segment.indexOf(":") + 1)
                } else segment
            }
        }

        return CharacterMapper.cleanString(name ?: getString(R.string.folder_manager_default_name))
    }

    private fun loadFolders() {
        mFolderItems.clear()
        val folders = mMusicLibrary.getSelectedFolders()
        mPendingChanges.clear()

        val validLooseSongs = getValidLooseSongs()
        val hasLooseSongs = validLooseSongs.isNotEmpty()

        if (folders.isEmpty() && !hasLooseSongs) {
            showEmptyView()
        } else {
            hideEmptyView()

            for (folderUriString in folders) {
                val folderUri = Uri.parse(folderUriString)
                val name = getFolderNameFromUri(folderUri)
                val storageType = StorageAccessHelper.getInstance(this)
                    .getStorageType(folderUriString)
                val displayName = if (storageType.isEmpty()) name
                else "$name$STORAGE_TYPE_SEPARATOR$storageType"
                mFolderItems.add(
                    FolderAdapter.FolderItem(
                        folderUriString,
                        displayName ?: folderUriString
                    )
                )
            }

            if (hasLooseSongs) {
                val count = validLooseSongs.size
                val label = resources.getQuantityString(
                    R.plurals.folder_manager_loose_tracks, count, count
                )
                mFolderItems.add(FolderAdapter.FolderItem(label, count))
            }

            mFolderAdapter?.refreshRemoveButtonStates()
        }

        updateFolderCount()
        themeAllHeaders()
        updateFolderButtons()
    }

    private fun getValidLooseSongs(): ArrayList<Song> {
        val valid = ArrayList<Song>()
        val allLoose = SongDatabase.getInstance(this).getLooseSongs()
        for (song in allLoose) {
            if (song != null && song.path.isNotEmpty()) {
                val file = File(song.path)
                if (file.exists() && file.canRead()) {
                    valid.add(song)
                } else {
                    SongDatabase.getInstance(this).removeLooseSong(song.path)
                }
            }
        }
        return valid
    }

    private fun selectFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, FOLDER_SELECT_CODE)
        } catch (exception: Exception) {
            ToastManager.showToast(
                this,
                getString(R.string.folder_manager_no_file_manager),
                ToastManager.LENGTH_NORMAL
            )
        }
    }

    private fun openPlaybackScopeDialog() {
        val serialized = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_PLAYBACK_SCOPE_JSON, null)
        val current = PlaybackScope.deserialize(serialized)
        PlaybackScopeDialog(
            this,
            current,
            mFolderItems,
            object : PlaybackScopeDialog.OnScopeAppliedListener {
                override fun onScopeApplied(scope: PlaybackScope) {
                    LlamaEventBus.post(
                        com.ark.llama.event.PlayerEvent.ApplyScope(scope.serialize())
                    )
                }
            }
        ).show()
    }

    // ========================================================================
    // Buttons
    // ========================================================================

    private fun updateFolderButtons() {
        mFolderAdapter?.refreshRemoveButtonStates()

        val importFolderButton: Button? = findViewById(R.id.importFolderButton)
        importFolderButton?.let {
            it.isEnabled = !isUpdating()
            mThemeHelper.updateButton(it, !isUpdating())
        }

        val allowed = areFolderChangesAllowed()
        val hasFolders = mFolderItems.isNotEmpty()
        val hasPendingRemovals = !mPendingChanges.isEmpty()
        val shouldEnableUpdate = (hasFolders || hasPendingRemovals) && allowed

        val updateButton: Button? = findViewById(R.id.updateButton)
        updateButton?.let {
            it.isEnabled = shouldEnableUpdate
            mThemeHelper.updateButton(it, shouldEnableUpdate)
        }

        val shouldEnableScope = !isUpdating()
        mScopeButton?.let {
            it.isEnabled = shouldEnableScope
            mThemeHelper.updateButton(it, shouldEnableScope)
        }
    }

    private fun disableButton(button: Button?) {
        button ?: return
        button.isEnabled = false
        mThemeHelper.updateButton(button, false)
    }

    // ========================================================================
    // Update cycle
    // ========================================================================

    private fun saveChanges() {
        val playlistManager = PlaylistManager.getInstance(this)
        if (playlistManager.isUpdating()) {
            ToastManager.showToast(
                this,
                getString(R.string.folder_manager_sync_in_progress),
                ToastManager.LENGTH_NORMAL
            )
            return
        }

        NavigationController.getInstance().beginPlaylistSync()
        OverlayManager.show(OverlayManager.REASON_FOLDER_UPDATE_CYCLE)

        val clearLooseTracks = mPendingChanges.isClearLooseTracks()

        val foldersToKeep = HashSet(mMusicLibrary.getSelectedFolders())
        for (uri in mPendingChanges.getFoldersToRemove()) {
            foldersToKeep.remove(uri)
        }

        var hasLooseAfterClear = false
        if (!clearLooseTracks) {
            val remaining = SongDatabase.getInstance(this).getLooseSongs()
            hasLooseAfterClear = remaining.isNotEmpty()
        }

        val hasAnyFolders = foldersToKeep.isNotEmpty()
        val hasAnyContent = hasAnyFolders || hasLooseAfterClear

        updateFolderButtons()

        LlamaEventBus.post(com.ark.llama.event.TransportEvent.SavePlayerState)

        Handler(Looper.getMainLooper()).postDelayed({
            MusicService.setPlayerStateBeforeUpdate(this, true)

            disableButton(findViewById(R.id.updateButton))
            disableButton(findViewById(R.id.importFolderButton))

            if (clearLooseTracks) {
                SongDatabase.getInstance(this).clearLooseSongs()
            }

            for (uri in mPendingChanges.getFoldersToRemove()) {
                mMusicLibrary.removeFolder(uri)
                try {
                    StorageAccessHelper.getInstance(this)
                        .removeFolderPermission(Uri.parse(uri))
                } catch (exception: Exception) {
                    Log.w(TAG, "Failed to drop SAF permission for $uri", exception)
                }
            }

            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putStringSet(KEY_SELECTED_FOLDERS_URIS, foldersToKeep)
                .apply()

            if (!hasAnyContent) {
                PlaylistManager.getInstance(this).resetLibrary(
                    PlaylistManager.ResetMode.LIBRARY,
                    object : PlaylistManager.ResetCallback {
                        override fun onComplete() {
                            onResetComplete()
                        }
                        override fun onError(error: String) {
                            onResetError(error)
                        }
                    }
                )
                return@postDelayed
            }

            if (!hasAnyFolders) {
                val snapshot = SongDatabase.getInstance(this).getLooseSongs()
                PlaylistManager.getInstance(this).resetLibrary(
                    PlaylistManager.ResetMode.LIBRARY,
                    object : PlaylistManager.ResetCallback {
                        override fun onComplete() {
                            restoreLooseTracks(snapshot)
                            onResetComplete()
                        }
                        override fun onError(error: String) {
                            onResetError(error)
                        }
                    }
                )
                return@postDelayed
            }

            performPlaylistUpdate()
        }, 150L)
    }

    private fun onResetComplete() {
        loadFolders()
        updateFolderButtons()
    }

    private fun onResetError(error: String) {
        Log.e(TAG, "Library reset failed: $error")
        updateFolderButtons()
        ToastManager.showToast(
            this,
            getString(R.string.folder_manager_reset_failed, error),
            ToastManager.LENGTH_NORMAL
        )
    }

    private fun restoreLooseTracks(snapshot: ArrayList<Song>) {
        if (snapshot.isEmpty()) return
        val db = SongDatabase.getInstance(this)
        for (song in snapshot) {
            if (song != null && song.path.isNotEmpty()) {
                db.insertLooseSong(song)
            }
        }
        db.insertSongsBatch(snapshot)

        Log.d(TAG, "Restored ${snapshot.size} loose tracks after reset")

        LlamaEventBus.post(com.ark.llama.event.PlaylistEvent.Refresh)
        LlamaEventBus.post(com.ark.llama.event.PlaylistEvent.Display)
    }

    private fun performPlaylistUpdate() {
        val persistentShown = booleanArrayOf(false)
        PlaylistManager.getInstance(this).updatePlaylist(
            object : PlaylistManager.UpdateCallback {
                override fun onProgress(current: Int, total: Int) {
                    runOnUiThread {
                        val action: String
                        val detail: String
                        if (current == 0) {
                            action = getString(R.string.folder_manager_searching)
                            detail = ""
                        } else if (current < total) {
                            action = getString(R.string.folder_manager_searching)
                            detail = getString(R.string.folder_manager_searching_found, current)
                        } else {
                            action = getString(R.string.folder_manager_syncing)
                            detail = getString(R.string.folder_manager_syncing_found, current)
                        }

                        if (!persistentShown[0]) {
                            ToastManager.showPersistentOverlay(
                                this@FolderManager, action, detail, OPERATION_FOLDER_SYNC
                            )
                            persistentShown[0] = true
                        } else {
                            ToastManager.updatePersistentOverlay(action, detail, OPERATION_FOLDER_SYNC)
                        }

                        LlamaEventBus.post(
                            com.ark.llama.event.PlaylistEvent.SyncStarted(
                                action, detail, OPERATION_FOLDER_SYNC
                            )
                        )
                    }
                }

                override fun onComplete(songCount: Int) {
                    runOnUiThread {
                        ToastManager.hidePersistentOverlay(OPERATION_FOLDER_SYNC)
                    }
                }

                override fun onError(error: String) {
                    runOnUiThread {
                        if (persistentShown[0]) {
                            ToastManager.hidePersistentOverlay(OPERATION_FOLDER_SYNC)
                        }
                        NavigationController.getInstance().endPlaylistSync()
                        updateFolderButtons()
                        ToastManager.showToast(
                            this@FolderManager,
                            getString(R.string.folder_manager_error, error),
                            ToastManager.LENGTH_NORMAL
                        )
                    }
                }
            }
        )
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    private fun forceRedraw() {
        val root = findViewById<View>(android.R.id.content) ?: return
        root.requestLayout()
        root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.updateConfiguration(resources.configuration, resources.displayMetrics)
        }
        recreate()
        overridePendingTransition(0, 0)
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * resources.displayMetrics.density)

    companion object {
        private const val TAG = "FolderManager"
    }
}