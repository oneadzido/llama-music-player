// EqualizerManager.kt
package com.ark.llama

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.util.Log
import com.ark.llama.event.Bus
import com.ark.llama.event.SessionEvent

/**
 * Manages audio effects: a multi-band equalizer, bass boost,
 * surround, pitch, and speed, with persistent storage of every
 * user-facing setting.
 *
 * <p>Effect parameters are stored in [SharedPreferences]. Setters
 * write to both [SharedPreferences] and the corresponding Android
 * audio-effect object; getters read the persisted value.</p>
 *
 * <h3>State Ownership</h3>
 * <p>SharedPreferences are the authoritative store for every
 * user-facing setting this manager exposes: equalizer enabled
 * state, band levels, bass boost, surround, pitch, speed, the
 * selected preset, and the custom-settings snapshot.</p>
 *
 * <h3>Custom Snapshot</h3>
 * <p>The custom snapshot holds the values the user last tuned by
 * hand: the ten band levels, bass boost, surround, pitch, and
 * speed. It is written when the user leaves the Custom preset for a
 * named preset, or when the session detaches. It is read on the
 * reload path so a restart brings the user's full tuning back.</p>
 *
 * <h3>Preset Names</h3>
 * <p>Preset display names live in the resource array
 * `R.array.preset_names` so every locale presents the list in its
 * own language. Gain values remain in this class because they are
 * locale-independent. The array is read on demand through
 * [LanguageManager.getLocalizedContext].</p>
 *
 * <h3>EventBus Integration</h3>
 * <p>[attachToAudioSession] posts [SessionEvent.AudioSessionChanged]
 * so a consumer that reacts to a new session — chiefly
 * [EqualizerActivity] — sees the new identifier on the same turn.
 * Pitch and speed setters post [SessionEvent.PlaybackParamsRefresh]
 * so [MusicService] reapplies the values to the running
 * MediaPlayer.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class EqualizerManager private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context.applicationContext

    private var mEqualizer: Equalizer? = null
    private var mBassBoost: BassBoost? = null
    private var mSurround: Virtualizer? = null

    private var mCurrentAudioSessionId: Int = -1
    private var mCurrentPreset: Int = 0

    private var mNumberOfBands: Short = 0
    private var mBandLevelRange: ShortArray? = null
    private var mCurrentBandLevels: IntArray? = null
    private var mCenterFrequencies: IntArray? = null
    private var mCustomBandLevels: IntArray? = null

    private var mCustomBassBoost: Int = 0
    private var mCustomSurround: Int = 0
    private var mCustomPitch: Int = DEFAULT_PITCH_SPEED
    private var mCustomSpeed: Int = DEFAULT_PITCH_SPEED

    @Volatile
    private var mListener: EqualizerListener? = null

    init {
        loadSettings()
    }

    // ========================================================================
    // Listener interface
    // ========================================================================

    interface EqualizerListener {
        fun onBandLevelsChanged(levels: IntArray)
        fun onPresetChanged(preset: Int, presetName: String)
        fun onEqualizerReady(ready: Boolean)
    }

    // ========================================================================
    // Localization helper
    // ========================================================================

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to obtain localized context", exception)
        mContext
    }

    private fun loadPresetNames(): Array<String> =
        getLocaleContext().resources.getStringArray(R.array.preset_names)

    // ========================================================================
    // Listener management
    // ========================================================================

    @Synchronized
    fun setListener(listener: EqualizerListener?) {
        mListener = listener
    }

    // ========================================================================
    // Settings load / save
    // ========================================================================

    private fun loadSettings() {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        mCurrentPreset = preferences.getInt(KEY_SELECTED_PRESET, 0)
    }

    private fun saveCurrentBandLevels() {
        val levels = mCurrentBandLevels ?: return
        val editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        for (bandIndex in levels.indices) {
            editor.putInt(KEY_BAND_PREFIX + bandIndex, levels[bandIndex])
        }
        editor.apply()
    }

    private fun savePreset(preset: Int) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SELECTED_PRESET, preset)
            .apply()
        mCurrentPreset = preset
    }

    // ========================================================================
    // State queries
    // ========================================================================

    fun isAttached(): Boolean = mEqualizer != null && mCurrentAudioSessionId > 0

    fun isOperational(): Boolean = isAttached() && isEnabled

    val isEnabled: Boolean
        get() = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_EQUALIZER_ENABLED, false)

    fun setEnabled(enabled: Boolean) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, enabled)
            .apply()

        if (mEqualizer != null && isAttached()) {
            try {
                mEqualizer?.enabled = enabled
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to set enabled", exception)
            }
        }
    }

    // ========================================================================
    // Attach / detach
    // ========================================================================

    fun attachToAudioSession(audioSessionId: Int) {
        try {
            if (audioSessionId <= 0) {
                Log.w(TAG, "attachToAudioSession: invalid session ID $audioSessionId")
                notifyListenerReady(false)
                return
            }

            if (mCurrentAudioSessionId == audioSessionId && mEqualizer != null) {
                Log.d(TAG, "Already attached to session $audioSessionId")
                notifyListenerReady(true)
                applyPreset(mCurrentPreset)
                return
            }

            release()
            mCurrentAudioSessionId = audioSessionId

            try {
                mEqualizer = Equalizer(0, audioSessionId)
                mEqualizer?.enabled = isEnabled
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to create Equalizer for session $audioSessionId", exception)
                release()
                notifyListenerReady(false)
                return
            }

            val equalizer = mEqualizer!!
            mNumberOfBands = equalizer.numberOfBands
            mBandLevelRange = equalizer.bandLevelRange
            mCenterFrequencies = IntArray(mNumberOfBands.toInt())
            mCurrentBandLevels = IntArray(mNumberOfBands.toInt())

            for (bandIndex in 0 until mNumberOfBands) {
                mCenterFrequencies!![bandIndex.toInt()] = equalizer.getCenterFreq(bandIndex)
                if (mCenterFrequencies!![bandIndex.toInt()] == 0) {
                    mCenterFrequencies!![bandIndex.toInt()] =
                        (20 * Math.pow(2.0, bandIndex * 0.5)).toInt()
                }
            }

            val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val range = mBandLevelRange!!
            for (bandIndex in 0 until mNumberOfBands) {
                var savedLevel = preferences.getInt(KEY_BAND_PREFIX + bandIndex, 0)
                savedLevel = Math.max(range[0].toInt(), Math.min(range[1].toInt(), savedLevel))
                mCurrentBandLevels!![bandIndex.toInt()] = savedLevel
                equalizer.setBandLevel(bandIndex, savedLevel.toShort())
            }

            restoreCustomBandLevels()
            restoreCustomBoosters()
            restoreCustomPitch()
            restoreCustomSpeed()

            try {
                mBassBoost = BassBoost(0, audioSessionId)
                mBassBoost?.enabled = true
                val bassLevel = preferences.getInt(KEY_BASS_BOOST, 0)
                val maxStrength: Short =
                    if (mBassBoost?.strengthSupported == true) MAX_BOOST_STRENGTH.toShort() else 0
                mBassBoost?.setStrength(Math.min(bassLevel, maxStrength.toInt()).toShort())
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to create BassBoost", exception)
                mBassBoost = null
            }

            try {
                mSurround = Virtualizer(0, audioSessionId)
                mSurround?.enabled = true
                val surroundLevel = preferences.getInt(KEY_SURROUND, 0)
                val maxStrength: Short =
                    if (mSurround?.strengthSupported == true) MAX_BOOST_STRENGTH.toShort() else 0
                mSurround?.setStrength(Math.min(surroundLevel, maxStrength.toInt()).toShort())
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to create Surround", exception)
                mSurround = null
            }

            applyPreset(mCurrentPreset)

            setPitch(mCustomPitch)
            setSpeed(mCustomSpeed)

            notifyListenerReady(true)
            notifyBandLevelsChanged(mCurrentBandLevels)
            notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset))

            // Announce the new audio session on the bus so a consumer
            // that reacts to a new session attaches to it.
            Bus.post(SessionEvent.AudioSessionChanged(audioSessionId))
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to attach equalizer", exception)
            release()
            notifyListenerReady(false)
        }
    }

    fun detach() {
        mCurrentAudioSessionId = -1
    }

    fun release() {
        if (mCurrentPreset == PRESET_INDEX_CUSTOM && mCurrentBandLevels != null) {
            backupCustomBandLevels()
            backupCustomBoosters()
            backupCustomPitch()
            backupCustomSpeed()
        }

        mEqualizer?.let {
            try {
                saveCurrentBandLevels()
                it.release()
            } catch (exception: Exception) {
                Log.e(TAG, "Error releasing equalizer", exception)
            }
            mEqualizer = null
        }

        mBassBoost?.let {
            try {
                it.release()
            } catch (exception: Exception) {
                Log.e(TAG, "Error releasing bass boost", exception)
            }
            mBassBoost = null
        }

        mSurround?.let {
            try {
                it.release()
            } catch (exception: Exception) {
                Log.e(TAG, "Error releasing surround", exception)
            }
            mSurround = null
        }

        mNumberOfBands = 0
        mBandLevelRange = null
        mCenterFrequencies = null
        mCurrentAudioSessionId = -1
    }

    // ========================================================================
    // Listener notification
    // ========================================================================

    private fun notifyListenerReady(ready: Boolean) {
        val listener = mListener ?: return
        try {
            listener.onEqualizerReady(ready)
        } catch (exception: Exception) {
            Log.e(TAG, "Error notifying listener ready", exception)
        }
    }

    private fun notifyBandLevelsChanged(levels: IntArray?) {
        val listener = mListener ?: return
        if (levels == null) return
        try {
            listener.onBandLevelsChanged(levels)
        } catch (exception: Exception) {
            Log.e(TAG, "Error notifying band levels changed", exception)
        }
    }

    private fun notifyPresetChanged(preset: Int, presetName: String) {
        val listener = mListener ?: return
        try {
            listener.onPresetChanged(preset, presetName)
        } catch (exception: Exception) {
            Log.e(TAG, "Error notifying preset changed", exception)
        }
    }

    // ========================================================================
    // Band methods
    // ========================================================================

    fun getNumberOfBands(): Short = mNumberOfBands

    fun getMinBandLevel(): Short = mBandLevelRange?.get(0) ?: -1500

    fun getMaxBandLevel(): Short = mBandLevelRange?.get(1) ?: 1500

    fun getCenterFrequency(band: Int): Int {
        if (!isAttached() || mCenterFrequencies == null ||
            band < 0 || band >= mCenterFrequencies!!.size
        ) {
            return 0
        }
        return mCenterFrequencies!![band]
    }

    fun getFrequencyLabel(frequency: Int): String {
        val localeContext = getLocaleContext()
        val frequencyHz = frequency / 1000
        if (frequencyHz < 1000) {
            return localeContext.getString(R.string.equalizer_frequency_hz, frequencyHz.toFloat())
        }
        val kilohertz = frequencyHz / 1000
        val remainder = (frequencyHz % 1000) / 100
        return if (remainder == 0) {
            localeContext.getString(R.string.equalizer_frequency_khz, kilohertz.toFloat())
        } else {
            val khz = kilohertz + remainder / 10.0f
            localeContext.getString(R.string.equalizer_frequency_khz_decimal, khz)
        }
    }

    fun setBandLevel(band: Int, level: Int) {
        val range = mBandLevelRange ?: return
        val levels = mCurrentBandLevels ?: return
        if (!isAttached() || band < 0 || band >= mNumberOfBands) return

        val clamped: Short = Math.max(range[0].toInt(), Math.min(range[1].toInt(), level)).toShort()

        try {
            mEqualizer?.setBandLevel(band.toShort(), clamped)
            levels[band] = clamped.toInt()

            if (mCurrentPreset == PRESET_INDEX_CUSTOM) {
                mCustomBandLevels?.let { custom ->
                    if (band < custom.size) custom[band] = clamped.toInt()
                }
                mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(KEY_CUSTOM_BAND_PREFIX + band, clamped.toInt())
                    .apply()
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BAND_PREFIX + band, clamped.toInt())
                .apply()

            if (mCurrentPreset != PRESET_INDEX_CUSTOM) {
                mCurrentPreset = PRESET_INDEX_CUSTOM
                savePreset(PRESET_INDEX_CUSTOM)
                backupCustomBandLevels()
                notifyPresetChanged(PRESET_INDEX_CUSTOM, getPresetName(PRESET_INDEX_CUSTOM))
            }

            notifyBandLevelsChanged(mCurrentBandLevels)
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to set band level", exception)
        }
    }

    fun getBandLevel(band: Int): Int {
        val levels = mCurrentBandLevels ?: return 0
        if (!isAttached() || band < 0 || band >= mNumberOfBands) return 0
        return levels[band]
    }

    fun getAllBandLevels(): IntArray = mCurrentBandLevels?.clone() ?: IntArray(0)

    // ========================================================================
    // Preset methods
    // ========================================================================

    fun getPresetName(preset: Int): String = loadPresetNames()[preset]

    fun getPresetNames(): Array<String> = loadPresetNames().copyOf()

    fun getCurrentPreset(): Int = mCurrentPreset

    fun applyPreset(presetIndex: Int) {
        val equalizer = mEqualizer
        if (equalizer == null) {
            mCurrentPreset = presetIndex
            savePreset(presetIndex)
            return
        }
        if (!isAttached()) {
            Log.w(TAG, "applyPreset called but equalizer not attached")
            mCurrentPreset = presetIndex
            savePreset(presetIndex)
            return
        }

        try {
            if (presetIndex == PRESET_INDEX_CUSTOM) {
                applyCustomPreset()
            } else if (presetIndex < PRESET_GAINS.size) {
                applyStandardPreset(presetIndex)
            }
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to apply preset", exception)
        }
    }

    private fun applyCustomPreset() {
        var restored = false

        val customLevels = mCustomBandLevels
        if (customLevels != null && customLevels.size == mNumberOfBands.toInt()) {
            val equalizer = mEqualizer!!
            val range = mBandLevelRange!!
            val levels = mCurrentBandLevels!!
            for (bandIndex in 0 until mNumberOfBands) {
                val level = Math.max(range[0].toInt(), Math.min(range[1].toInt(),
                    customLevels[bandIndex.toInt()]))
                equalizer.setBandLevel(bandIndex, level.toShort())
                levels[bandIndex.toInt()] = level
            }
            restored = true
        } else if (restoreCustomBandLevels()) {
            val equalizer = mEqualizer!!
            val levels = mCurrentBandLevels!!
            for (bandIndex in 0 until mNumberOfBands) {
                val level = levels[bandIndex.toInt()]
                equalizer.setBandLevel(bandIndex, level.toShort())
            }
            restored = true
        }

        if (!restored) {
            val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val equalizer = mEqualizer!!
            val range = mBandLevelRange!!
            val levels = mCurrentBandLevels!!
            for (bandIndex in 0 until mNumberOfBands) {
                var savedLevel = preferences.getInt(KEY_BAND_PREFIX + bandIndex, 0)
                savedLevel = Math.max(range[0].toInt(), Math.min(range[1].toInt(), savedLevel))
                equalizer.setBandLevel(bandIndex, savedLevel.toShort())
                levels[bandIndex.toInt()] = savedLevel
            }
        }

        mCurrentPreset = PRESET_INDEX_CUSTOM
        saveCurrentBandLevels()
        savePreset(PRESET_INDEX_CUSTOM)

        notifyBandLevelsChanged(mCurrentBandLevels)
        notifyPresetChanged(PRESET_INDEX_CUSTOM, getPresetName(PRESET_INDEX_CUSTOM))
    }

    private fun applyStandardPreset(presetIndex: Int) {
        if (mCurrentPreset == PRESET_INDEX_CUSTOM) {
            backupCustomBandLevels()
            backupCustomBoosters()
            backupCustomPitch()
            backupCustomSpeed()
        }

        val gains = PRESET_GAINS[presetIndex]
        val equalizer = mEqualizer!!
        val range = mBandLevelRange!!
        val levels = mCurrentBandLevels!!
        for (bandIndex in 0 until Math.min(mNumberOfBands.toInt(), gains.size)) {
            val clamped: Short = Math.max(range[0].toInt(),
                Math.min(range[1].toInt(), gains[bandIndex])).toShort()
            equalizer.setBandLevel(bandIndex.toShort(), clamped)
            levels[bandIndex] = clamped.toInt()
        }

        mCurrentPreset = presetIndex
        saveCurrentBandLevels()
        savePreset(mCurrentPreset)

        notifyBandLevelsChanged(mCurrentBandLevels)
        notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset))
    }

    // ========================================================================
    // Custom snapshot backup / restore
    // ========================================================================

    private fun backupCustomBandLevels() {
        val levels = mCurrentBandLevels ?: return
        val editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        for (bandIndex in levels.indices) {
            editor.putInt(KEY_CUSTOM_BAND_PREFIX + bandIndex, levels[bandIndex])
        }
        editor.putBoolean(KEY_HAS_CUSTOM_BAND, true)
        editor.apply()
        mCustomBandLevels = levels.clone()
    }

    private fun backupCustomBoosters() {
        val editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        mCustomBassBoost = getBassBoost()
        mCustomSurround = getSurround()
        editor.putInt(KEY_CUSTOM_BASS_BOOST, mCustomBassBoost)
        editor.putInt(KEY_CUSTOM_SURROUND, mCustomSurround)
        editor.putBoolean(KEY_HAS_CUSTOM_BOOSTERS, true)
        editor.apply()
        backupCustomPitch()
        backupCustomSpeed()
    }

    private fun backupCustomPitch() {
        val editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        mCustomPitch = getPitch()
        editor.putInt(KEY_CUSTOM_PITCH, mCustomPitch)
        editor.putBoolean(KEY_HAS_CUSTOM_PITCH, true)
        editor.apply()
    }

    private fun backupCustomSpeed() {
        val editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        mCustomSpeed = getSpeed()
        editor.putInt(KEY_CUSTOM_SPEED, mCustomSpeed)
        editor.putBoolean(KEY_HAS_CUSTOM_SPEED, true)
        editor.apply()
    }

    private fun restoreCustomPitch() {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (preferences.getBoolean(KEY_HAS_CUSTOM_PITCH, false)) {
            mCustomPitch = preferences.getInt(KEY_CUSTOM_PITCH, DEFAULT_PITCH_SPEED)
        }
    }

    private fun restoreCustomSpeed() {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (preferences.getBoolean(KEY_HAS_CUSTOM_SPEED, false)) {
            mCustomSpeed = preferences.getInt(KEY_CUSTOM_SPEED, DEFAULT_PITCH_SPEED)
        }
    }

    private fun restoreCustomBandLevels(): Boolean {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!preferences.getBoolean(KEY_HAS_CUSTOM_BAND, false)) return false
        val levels = mCurrentBandLevels ?: return false
        val range = mBandLevelRange!!

        var valid = true
        for (bandIndex in levels.indices) {
            if (preferences.contains(KEY_CUSTOM_BAND_PREFIX + bandIndex)) {
                var savedLevel = preferences.getInt(KEY_CUSTOM_BAND_PREFIX + bandIndex, 0)
                savedLevel = Math.max(range[0].toInt(), Math.min(range[1].toInt(), savedLevel))
                levels[bandIndex] = savedLevel
            } else {
                valid = false
                break
            }
        }

        if (valid) {
            mCustomBandLevels = levels.clone()
            return true
        }
        return false
    }

    private fun restoreCustomBoosters() {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (preferences.getBoolean(KEY_HAS_CUSTOM_BOOSTERS, false)) {
            mCustomBassBoost = preferences.getInt(KEY_CUSTOM_BASS_BOOST, 0)
            mCustomSurround = preferences.getInt(KEY_CUSTOM_SURROUND, 0)
        } else {
            mCustomBassBoost = 0
            mCustomSurround = 0
        }
    }

    fun clearCustomBandLevels() {
        val preferences = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = preferences.edit()

        mCurrentBandLevels?.let { levels ->
            for (bandIndex in levels.indices) {
                editor.remove(KEY_CUSTOM_BAND_PREFIX + bandIndex)
            }
        }
        editor.remove(KEY_HAS_CUSTOM_BAND)
        editor.remove(KEY_CUSTOM_BASS_BOOST)
        editor.remove(KEY_CUSTOM_SURROUND)
        editor.remove(KEY_HAS_CUSTOM_BOOSTERS)
        editor.remove(KEY_CUSTOM_PITCH)
        editor.remove(KEY_CUSTOM_SPEED)
        editor.remove(KEY_HAS_CUSTOM_PITCH)
        editor.remove(KEY_HAS_CUSTOM_SPEED)
        editor.apply()

        mCustomBandLevels?.let {
            for (bandIndex in it.indices) it[bandIndex] = 0
        }
        mCustomBassBoost = 0
        mCustomSurround = 0
        mCustomPitch = DEFAULT_PITCH_SPEED
        mCustomSpeed = DEFAULT_PITCH_SPEED

        mCurrentBandLevels?.let { levels ->
            if (isAttached()) {
                for (bandIndex in levels.indices) {
                    levels[bandIndex] = 0
                    try {
                        mEqualizer?.setBandLevel(bandIndex.toShort(), 0)
                    } catch (exception: Exception) {
                        Log.e(TAG, "Failed to reset band level", exception)
                    }
                }
                saveCurrentBandLevels()
            }
        }
    }

    // ========================================================================
    // Bass boost
    // ========================================================================

    fun setBassBoost(level: Int) {
        val bass = mBassBoost ?: return
        if (!isAttached()) return

        try {
            val maxStrength: Short =
                if (bass.strengthSupported) MAX_BOOST_STRENGTH.toShort() else 0
            val clamped = Math.min(level, maxStrength.toInt()).toShort()
            val currentStrength = bass.roundedStrength

            if (clamped != currentStrength) {
                val wasEnabled = bass.enabled
                if (wasEnabled) bass.enabled = false
                bass.setStrength(clamped)
                if (wasEnabled) bass.enabled = true
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BASS_BOOST, clamped.toInt())
                .apply()
        } catch (exception: Exception) {
            Log.e(TAG, "setBassBoost error", exception)
        }
    }

    fun getBassBoost(): Int = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_BASS_BOOST, 0)

    fun isBassBoostSupported(): Boolean =
        mBassBoost?.strengthSupported == true && isAttached()

    fun setBassBoostStrength(strength: Short) {
        mBassBoost?.let {
            try {
                it.setStrength(strength)
                it.enabled = strength > 0
            } catch (exception: Exception) {
                Log.e(TAG, "setBassBoostStrength error", exception)
            }
        }
    }

    fun getAppliedBassBoostStrength(): Short =
        mBassBoost?.roundedStrength ?: 0

    // ========================================================================
    // Surround
    // ========================================================================

    fun setSurround(level: Int) {
        val surround = mSurround ?: return
        if (!isAttached()) return

        try {
            val maxStrength: Short =
                if (surround.strengthSupported) MAX_BOOST_STRENGTH.toShort() else 0
            val clamped = Math.min(level, maxStrength.toInt()).toShort()
            val currentStrength = surround.roundedStrength

            if (clamped != currentStrength) {
                val wasEnabled = surround.enabled
                if (wasEnabled) surround.enabled = false
                surround.setStrength(clamped)
                if (wasEnabled) surround.enabled = true
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_SURROUND, clamped.toInt())
                .apply()
        } catch (exception: Exception) {
            Log.e(TAG, "setSurround error", exception)
        }
    }

    fun getSurround(): Int = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_SURROUND, 0)

    fun isSurroundSupported(): Boolean =
        mSurround?.strengthSupported == true && isAttached()

    fun setSurroundStrength(strength: Short) {
        mSurround?.let {
            try {
                it.setStrength(strength)
                it.enabled = strength > 0
            } catch (exception: Exception) {
                Log.e(TAG, "setSurroundStrength error", exception)
            }
        }
    }

    fun getAppliedSurroundStrength(): Short =
        mSurround?.roundedStrength ?: 0

    // ========================================================================
    // Pitch / speed
    // ========================================================================

    fun setPitch(level: Int) {
        var smoothed = Math.max(0, Math.min(2000, level))
        if (Math.abs(smoothed - DEFAULT_PITCH_SPEED) <= 6) {
            smoothed = DEFAULT_PITCH_SPEED
        }
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PITCH, smoothed)
            .apply()

        // Announce pitch/speed change so the playback pipeline
        // reapplies its parameters.
        Bus.post(SessionEvent.PlaybackParamsRefresh)
    }

    fun getPitch(): Int = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_PITCH, DEFAULT_PITCH_SPEED)

    fun isPitchSupported(): Boolean = true

    fun getPitchSemitones(): Float {
        val level = getPitch()
        if (level == DEFAULT_PITCH_SPEED) return 0f
        val normalized = (level - DEFAULT_PITCH_SPEED) / 1000.0f
        return normalized * 6.0f
    }

    fun setSpeed(level: Int) {
        var smoothed = Math.max(0, Math.min(2000, level))
        if (Math.abs(smoothed - DEFAULT_PITCH_SPEED) <= 6) {
            smoothed = DEFAULT_PITCH_SPEED
        }
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SPEED, smoothed)
            .apply()

        Bus.post(SessionEvent.PlaybackParamsRefresh)
    }

    fun getSpeed(): Int = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_SPEED, DEFAULT_PITCH_SPEED)

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val TAG = "EqualizerManager"

        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_EQUALIZER_ENABLED = "equalizer_enabled"
        private const val KEY_BASS_BOOST = "bass_boost_level"
        private const val KEY_SURROUND = "surround_level"
        private const val KEY_PITCH = "pitch_level"
        private const val KEY_SPEED = "speed_level"
        private const val KEY_SELECTED_PRESET = "selected_preset"
        private const val KEY_BAND_PREFIX = "eq_band_"
        private const val KEY_CUSTOM_BAND_PREFIX = "eq_custom_band_"
        private const val KEY_HAS_CUSTOM_BAND = "has_custom_band"
        private const val KEY_CUSTOM_BASS_BOOST = "eq_custom_bass_boost"
        private const val KEY_CUSTOM_SURROUND = "eq_custom_surround"
        private const val KEY_CUSTOM_PITCH = "eq_custom_pitch"
        private const val KEY_CUSTOM_SPEED = "eq_custom_speed"
        private const val KEY_HAS_CUSTOM_BOOSTERS = "has_custom_boosters"
        private const val KEY_HAS_CUSTOM_PITCH = "has_custom_pitch"
        private const val KEY_HAS_CUSTOM_SPEED = "has_custom_speed"

        private const val DEFAULT_PITCH_SPEED = 1000
        private const val MAX_BOOST_STRENGTH = 1000
        private const val PRESET_INDEX_CUSTOM = 0

        /**
         * Gain values for each preset, in millibels where 100 = 1 dB.
         * Index-aligned with R.array.preset_names.
         */
        private val PRESET_GAINS: Array<IntArray> = arrayOf(
            intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),                                 // 0 Custom
            intArrayOf(300, 250, 200, 150, 100, 50, 0, -50, -100, -150),              // 1 Acoustic
            intArrayOf(450, 500, 500, 400, 300, 150, 100, 150, 250, 350),             // 2 Afrobeat
            intArrayOf(500, 550, 500, 450, 350, 250, 200, 250, 350, 400),             // 3 Afropop
            intArrayOf(300, 350, 400, 350, 300, 250, 200, 150, 200, 300),             // 4 Alternative
            intArrayOf(200, 250, 300, 350, 400, 350, 300, 250, 200, 150),             // 5 Ambient
            intArrayOf(600, 500, 300, 100, 0, 0, 0, 100, 300, 600),                   // 6 Bass & Treble
            intArrayOf(700, 650, 500, 300, 150, 0, -100, -150, -200, -250),           // 7 Bass Boost
            intArrayOf(-250, -200, -150, -100, -50, 50, 150, 250, 350, 450),          // 8 Bass Reducer
            intArrayOf(300, 350, 350, 250, 200, 150, 100, 50, 100, 150),              // 9 Blues
            intArrayOf(500, 450, 350, 250, 150, 100, 100, 150, 200, 250),             // 10 Car
            intArrayOf(200, 250, 300, 350, 300, 250, 200, 150, 100, 50),              // 11 Chill
            intArrayOf(400, 350, 300, 250, 200, 150, 100, 50, 0, -50),                // 12 Classical
            intArrayOf(600, 650, 650, 450, 250, 0, -50, -50, 100, 200),               // 13 Club
            intArrayOf(250, 300, 350, 400, 350, 300, 200, 150, 100, 50),              // 14 Country
            intArrayOf(500, 550, 550, 400, 200, 0, 100, 250, 400, 500),               // 15 Dance
            intArrayOf(800, 850, 700, 400, 150, -50, -150, -200, -300, -350),         // 16 Deep
            intArrayOf(500, 550, 600, 500, 350, 200, 150, 100, 50, 0),                // 17 Disco
            intArrayOf(650, 650, 500, 250, 100, -50, -100, -50, 150, 200),            // 18 Drum & Bass
            intArrayOf(700, 750, 550, 200, -100, -250, -150, 50, 200, 300),           // 19 Dubstep
            intArrayOf(650, 700, 650, 450, 200, 0, 50, 150, 350, 450),                // 20 Electronic
            intArrayOf(150, 200, 300, 400, 450, 400, 300, 200, 150, 100),             // 21 Folk
            intArrayOf(200, 250, 350, 450, 550, 500, 400, 300, 200, 150),             // 22 Gospel
            intArrayOf(450, 500, 400, 200, -75, -100, 0, 150, 300, 400),              // 23 Grunge
            intArrayOf(400, 450, 500, 450, 300, 200, 200, 250, 350, 400),             // 24 Hard Rock
            intArrayOf(200, 150, 100, 0, -100, -100, -50, 0, 150, 250),               // 25 Headphones
            intArrayOf(600, 650, 550, 300, 100, -50, -100, 0, 150, 250),              // 26 Hip Hop
            intArrayOf(600, 650, 600, 450, 250, 50, 0, 50, 150, 300),                 // 27 House
            intArrayOf(200, 250, 300, 400, 400, 350, 300, 250, 200, 150),             // 28 Indie
            intArrayOf(200, 250, 300, 350, 400, 350, 300, 250, 200, 150),             // 29 Jazz
            intArrayOf(100, 150, 250, 400, 500, 450, 350, 250, 150, 100),             // 30 Live
            intArrayOf(500, 450, 300, 100, -100, -150, -100, 100, 350, 450),          // 31 Loudness
            intArrayOf(150, 200, 250, 300, 350, 300, 250, 200, 150, 100),             // 32 Lounge
            intArrayOf(400, 450, 300, 100, -150, -200, -100, 150, 400, 500),          // 33 Metal
            intArrayOf(200, 250, 300, 250, 150, 50, -50, -100, -150, -200),           // 34 Midnight
            intArrayOf(250, 300, 350, 350, 300, 250, 200, 150, 100, 50),              // 35 Opera
            intArrayOf(300, 350, 400, 400, 350, 300, 250, 200, 150, 100),             // 36 Orchestral
            intArrayOf(300, 350, 400, 350, 300, 300, 350, 400, 450, 500),             // 37 Outdoor
            intArrayOf(550, 600, 550, 350, 100, -100, -50, 150, 400, 550),            // 38 Party
            intArrayOf(-200, -100, 100, 400, 600, 700, 600, 400, 200, 0),             // 39 Podcast
            intArrayOf(250, 300, 350, 400, 450, 450, 400, 350, 300, 250),             // 40 Pop
            intArrayOf(300, 350, 400, 350, 300, 200, 150, 200, 300, 400),             // 41 Psychedelic
            intArrayOf(50, 75, 100, 125, 150, 175, 200, 225, 250, 275),               // 42 Reference
            intArrayOf(450, 500, 450, 350, 250, 150, 100, 50, 0, -50),                // 43 Reggae
            intArrayOf(350, 400, 450, 500, 450, 350, 250, 200, 250, 300),             // 44 Rock
            intArrayOf(350, 400, 450, 400, 350, 300, 250, 200, 150, 150),             // 45 Ska
            intArrayOf(400, 350, 300, 200, 100, 100, 150, 200, 300, 400),             // 46 Small Speakers
            intArrayOf(200, 250, 300, 400, 350, 250, 150, 100, 50, 25),               // 47 Soft Rock
            intArrayOf(400, 450, 400, 300, 200, 150, 100, 50, 100, 150),              // 48 Soul
            intArrayOf(50, 100, 150, 200, 250, 300, 350, 400, 450, 500),              // 49 Studio
            intArrayOf(400, 450, 500, 450, 400, 350, 300, 250, 200, 150),             // 50 Symphony
            intArrayOf(650, 600, 500, 350, 150, -50, -100, 0, 200, 400),              // 51 Techno
            intArrayOf(550, 600, 550, 400, 200, 50, 100, 250, 400, 500),              // 52 Trance
            intArrayOf(-300, -250, -200, -150, 0, 150, 300, 500, 700, 800),           // 53 Treble Boost
            intArrayOf(50, 100, 150, 200, 150, 100, 50, 0, -100, -200),               // 54 Treble Reducer
            intArrayOf(-200, -150, 200, 400, 500, 600, 500, 400, 200, -100),          // 55 Vocal Boost
            intArrayOf(-400, -300, 0, 400, 600, 700, 600, 400, 0, -300),              // 56 Voice
            intArrayOf(400, 350, 250, 150, 100, 50, 25, 0, -25, -50),                 // 57 Warm
            intArrayOf(200, 300, 350, 400, 400, 350, 300, 200, 150, 100),             // 58 World
            intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)                                  // 59 Zero
        )

        @Volatile
        private var sInstance: EqualizerManager? = null

        @JvmStatic
        fun getInstance(context: Context): EqualizerManager {
            if (sInstance == null) {
                synchronized(EqualizerManager::class.java) {
                    if (sInstance == null) {
                        sInstance = EqualizerManager(context.applicationContext)
                    }
                }
            }
            return sInstance!!
        }
    }
}