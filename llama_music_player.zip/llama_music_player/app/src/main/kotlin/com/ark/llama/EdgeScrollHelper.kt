// EdgeScrollHelper.kt
package com.ark.llama

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import androidx.recyclerview.widget.RecyclerView

/**
 * Attaches proportional edge fast-scroll to a [RecyclerView].
 *
 * <p>A vertical drag that starts inside the leftmost or rightmost
 * [EDGE_ZONE_DP] of the list scrolls it proportionally: a full
 * viewport-height of finger travel maps to
 * [FAST_SCROLL_FRACTION_PER_VIEWPORT] of the total scrollable
 * range, anchored at the position the drag began. A drag that
 * starts anywhere else is left to the RecyclerView's own scroll
 * handling.</p>
 *
 * <p>Fast scroll only engages when the content is at least
 * [FAST_SCROLL_MIN_CONTENT_RATIO] times taller than the viewport.
 * On a shorter list the proportional mapping would be too coarse
 * and the edge zones defer to ordinary scrolling.</p>
 *
 * <p>A tap is never consumed. The interceptor only takes over once
 * the finger has moved beyond the touch slop, so tapping a row
 * that happens to sit near an edge still fires the row's click.</p>
 *
 * <p>Shared by the playlist and the playback scope dialog so both
 * surfaces use the same edge width, engagement threshold, and
 * scroll rate.</p>
 *
 * <h3>Installation contract</h3>
 * <p>[attach] must be called exactly once per RecyclerView. A
 * second call installs a second listener and doubles the scroll
 * rate; the caller is responsible for the once-only guarantee.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.4.0
 */
object EdgeScrollHelper {

    private const val EDGE_ZONE_DP = 32
    private const val FAST_SCROLL_FRACTION_PER_VIEWPORT = 0.05f
    private const val FAST_SCROLL_MIN_CONTENT_RATIO = 3.0f

    /**
     * Installs the edge fast-scroll interceptor on the given
     * RecyclerView.
     *
     * @param recyclerView The RecyclerView to attach the interceptor to
     */
    @JvmStatic
    fun attach(recyclerView: RecyclerView) {
        val context: Context = recyclerView.context
        val edgeZonePx = dpToPx(context, EDGE_ZONE_DP)
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

        recyclerView.addOnItemTouchListener(object :
            RecyclerView.OnItemTouchListener {

            private var anchorTouchY: Float = 0f
            private var anchorScrollY: Int = 0
            private var scrollableRange: Int = 1
            private var viewportHeight: Int = 1
            private var startedInEdgeZone: Boolean = false
            private var consuming: Boolean = false

            override fun onInterceptTouchEvent(
                rv: RecyclerView,
                event: MotionEvent
            ): Boolean {
                return when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        val x = event.x
                        val width = rv.width
                        startedInEdgeZone = (x <= edgeZonePx ||
                            x >= width - edgeZonePx)
                        consuming = false
                        if (startedInEdgeZone) {
                            anchorTouchY = event.y
                            anchorScrollY = rv.computeVerticalScrollOffset()
                            val contentHeight = rv.computeVerticalScrollRange()
                            viewportHeight = Math.max(1, rv.height)
                            scrollableRange = Math.max(1, contentHeight - viewportHeight)
                        }
                        false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!startedInEdgeZone) return false
                        if (!consuming) {
                            if (Math.abs(event.y - anchorTouchY) <= touchSlop) return false
                            if (!fastScrollEngages(rv)) {
                                startedInEdgeZone = false
                                return false
                            }
                            rv.stopScroll()
                            consuming = true
                            return true
                        }
                        applyProportionalScroll(rv, event.y)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val wasConsuming = consuming
                        consuming = false
                        startedInEdgeZone = false
                        wasConsuming
                    }
                    else -> false
                }
            }

            override fun onTouchEvent(rv: RecyclerView, event: MotionEvent) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_MOVE -> applyProportionalScroll(rv, event.y)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        consuming = false
                        startedInEdgeZone = false
                    }
                    else -> { }
                }
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {
                // The RecyclerView is asking whether the listener
                // wants to veto an interception. The listener
                // accepts the request unconditionally.
            }

            private fun fastScrollEngages(rv: RecyclerView): Boolean {
                val contentHeight = rv.computeVerticalScrollRange()
                val viewport = Math.max(1, rv.height)
                return contentHeight > viewport * FAST_SCROLL_MIN_CONTENT_RATIO
            }

            private fun applyProportionalScroll(rv: RecyclerView, currentTouchY: Float) {
                val viewportFraction =
                    (currentTouchY - anchorTouchY) / viewportHeight
                val libraryFraction =
                    viewportFraction * FAST_SCROLL_FRACTION_PER_VIEWPORT
                val targetOffset = anchorScrollY +
                    Math.round(libraryFraction * scrollableRange)
                val currentOffset = rv.computeVerticalScrollOffset()
                val delta = targetOffset - currentOffset
                if (delta != 0) {
                    rv.scrollBy(0, delta)
                }
            }
        })
    }

    private fun dpToPx(context: Context, dpValue: Int): Int =
        Math.round(dpValue * context.resources.displayMetrics.density)
}