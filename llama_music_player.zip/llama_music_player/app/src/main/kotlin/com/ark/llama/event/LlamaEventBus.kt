// LlamaEventBus.kt
package com.ark.llama.event

import android.util.Log
import com.ark.llama.BuildConfig
import org.greenrobot.eventbus.EventBus

/**
 * Process-wide EventBus façade.
 *
 * <p>This object owns the single installed bus and the dispatch
 * surface the rest of the app calls: [init], [post], [postSticky],
 * [latest], [removeLatest], [register], [unregister]. No other class
 * in the app touches [EventBus] directly, so the bus construction
 * lives in exactly one place.</p>
 *
 * <h3>Installation</h3>
 * <p>[init] is called once from [com.ark.llama.LlamaMusicPlayer.onCreate]
 * before any manager or activity that registers a subscriber. The
 * bus is built with the library's reflective subscriber lookup.</p>
 *
 * <h3>Subscriber failure policy</h3>
 * <p>{@code throwSubscriberException} is bound to
 * [BuildConfig.DEBUG]. Debug builds fail fast on a broken subscriber
 * method; release builds leave the library's catch-and-log behaviour
 * intact so a single bad subscriber cannot bring down the UI thread.</p>
 *
 * <h3>Registration idempotence</h3>
 * <p>[register] and [unregister] are safe to call across a re-entrant
 * lifecycle. A second [register] for an already-registered subscriber
 * is a no-op; an [unregister] for a subscriber that was never
 * registered is a no-op. Both operations are wrapped in try/catch
 * because they run from activity lifecycle methods where throwing
 * would abort the calling method.</p>
 *
 * <h3>Thread safety</h3>
 * <p>[init] is synchronized and idempotent. [register] and
 * [unregister] defer serialisation to the underlying library, which
 * is thread-safe. [post] and [postSticky] are thread-safe per the
 * library's contract.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
object LlamaEventBus {

    // ========================================================================
    // Constants
    // ========================================================================

    /**
     * Logcat tag for messages this object emits.
     *
     * Marked [PublishedApi] so the public inline functions [latest]
     * and [removeLatest] can reference it. Without the annotation
     * the Kotlin compiler rejects a public inline function that
     * reads a non-public member.
     */
    @PublishedApi
    internal const val TAG = "LlamaEventBus"

    // ========================================================================
    // Instance state
    // ========================================================================

    /**
     * True once [init] has installed the default bus. Guarded by
     * [init]'s {@code @Synchronized}; read by [init] to short-circuit
     * a redundant second call.
     */
    @Volatile
    private var initialised = false

    // ========================================================================
    // Installation
    // ========================================================================

    /**
     * Installs the default EventBus exactly once.
     *
     * <p>Idempotent. The first call installs the bus and returns;
     * subsequent calls return immediately.</p>
     */
    @Synchronized
    fun init() {
        if (initialised) {
            return
        }
        EventBus.builder()
            .throwSubscriberException(BuildConfig.DEBUG)
            .installDefaultEventBus()
        initialised = true
        Log.d(TAG, "LlamaEventBus installed")
    }

    // ========================================================================
    // Dispatch
    // ========================================================================

    /**
     * Posts the given event on the process bus.
     *
     * @param event Event to post
     */
    @JvmStatic
    fun post(event: Any) {
        EventBus.getDefault().post(event)
    }

    /**
     * Posts the given event as the sticky instance of its type.
     *
     * @param event Event to post
     */
    @JvmStatic
    fun postSticky(event: Any) {
        EventBus.getDefault().postSticky(event)
    }

    // ========================================================================
    // Sticky reads
    // ========================================================================

    /**
     * Returns the current sticky event of the given type, or null
     * when none is present.
     */
    inline fun <reified T : Any> latest(): T? = try {
        EventBus.getDefault().getStickyEvent(T::class.java)
    } catch (t: Throwable) {
        Log.w(TAG, "Failed to read sticky event", t)
        null
    }

    /**
     * Removes the current sticky event of the given type.
     */
    inline fun <reified T : Any> removeLatest() {
        try {
            EventBus.getDefault().removeStickyEvent(T::class.java)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to remove sticky event", t)
        }
    }

    // ========================================================================
    // Registration
    // ========================================================================

    /**
     * Registers the given subscriber.
     *
     * @param subscriber Subscriber to register
     */
    @JvmStatic
    fun register(subscriber: Any) {
        try {
            val bus = EventBus.getDefault()
            if (!bus.isRegistered(subscriber)) {
                bus.register(subscriber)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to register subscriber", t)
        }
    }

    /**
     * Unregisters the given subscriber.
     *
     * @param subscriber Subscriber to unregister
     */
    @JvmStatic
    fun unregister(subscriber: Any) {
        try {
            val bus = EventBus.getDefault()
            if (bus.isRegistered(subscriber)) {
                bus.unregister(subscriber)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to unregister subscriber", t)
        }
    }
}