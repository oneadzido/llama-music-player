// AlbumArtCache.kt
package com.ark.llama

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache

/**
 * Process-scoped cache of decoded album art bitmaps, keyed by song
 * path.
 *
 * <p>The cache is a singleton and outlives every activity. Two
 * consumers read and write it — [AlbumArtCarousel] through
 * [MusicPlayer], and [NotificationController] for the playback
 * notification and the media session — and both see the same
 * bitmaps for the same path. A song's art is decoded once per
 * process for as long as the entry remains in the cache.</p>
 *
 * <h3>Why process-scoped</h3>
 * <p>The bitmaps are a fact about the songs, not about any
 * activity. An activity-scoped cache is discarded on every recreate
 * and the carousel's next read then misses and schedules a fresh
 * decode. Scoping the cache to the process makes the decode survive
 * every activity lifecycle event that does not change which song is
 * playing.</p>
 *
 * <h3>Entry lifetime</h3>
 * <p>An entry lives until the cache evicts it under memory pressure
 * or a caller removes it explicitly.</p>
 *
 * <h3>Thread safety</h3>
 * <p>[LruCache] is internally synchronised. All public methods are
 * safe to call from any thread.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.3.0
 */
class AlbumArtCache private constructor() {

    /** The underlying LRU cache. */
    private val mCache: LruCache<String, Bitmap>

    init {
        val cacheSize = MAX_CACHE_MB * 1024 * 1024
        mCache = object : LruCache<String, Bitmap>(cacheSize) {
            override fun sizeOf(key: String, bitmap: Bitmap?): Int {
                if (bitmap == null || bitmap.isRecycled) {
                    return 0
                }
                return bitmap.byteCount
            }
        }
    }

    /**
     * Returns the cached bitmap for the given path, or null when
     * none is cached or the cached bitmap has been recycled.
     */
    fun get(path: String?): Bitmap? {
        if (path == null) return null
        val cached = mCache.get(path) ?: return null
        return if (!cached.isRecycled) cached else null
    }

    /**
     * Stores the given bitmap under the given path, replacing any
     * existing entry.
     */
    fun put(path: String?, bitmap: Bitmap?) {
        if (path == null || bitmap == null || bitmap.isRecycled) {
            return
        }
        mCache.put(path, bitmap)
    }

    /**
     * Removes the entry for the given path, if one is present.
     */
    fun remove(path: String?) {
        if (path == null) return
        mCache.remove(path)
    }

    /**
     * Evicts every entry.
     *
     * <p>Called by a caller that owns a state transition to
     * "no song" — the empty-state path in [MusicPlayer] — not from
     * any activity's `onDestroy`.</p>
     */
    fun evictAll() {
        mCache.evictAll()
    }

    /**
     * Returns the underlying [LruCache].
     *
     * <p>Exposes the cache to consumers whose APIs were already
     * built against [LruCache], such as [AlbumArtCarousel]. The
     * returned instance is the same one every other consumer reads
     * from; there is one cache in the process.</p>
     */
    fun asLruCache(): LruCache<String, Bitmap> = mCache

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        /** Maximum size of the cache, in megabytes. */
        private const val MAX_CACHE_MB = 50

        /** Singleton instance. */
        @Volatile
        private var sInstance: AlbumArtCache? = null

        /**
         * Returns the singleton instance, creating it on first call.
         *
         * @param context A context used only when the instance is
         *        created
         * @return The singleton instance
         */
        @JvmStatic
        fun getInstance(context: Context): AlbumArtCache {
            if (sInstance == null) {
                synchronized(AlbumArtCache::class.java) {
                    if (sInstance == null) {
                        sInstance = AlbumArtCache()
                    }
                }
            }
            return sInstance!!
        }

        /**
         * Releases the singleton and evicts every entry. Called
         * only at process teardown.
         */
        @JvmStatic
        fun shutdown() {
            val cache = sInstance
            if (cache != null) {
                cache.evictAll()
                sInstance = null
            }
        }
    }
}