// ThemeManager.kt
package com.ark.llama

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.util.Log
import com.ark.llama.event.Bus
import com.ark.llama.event.SettingsEvent

/**
 * Stores the application's current theme color and exposes the set
 * of available themes.
 *
 * <p>The current theme is selected by index into [COLOR_VALUES] and
 * the resource array `R.array.theme_names`, persisted to
 * [SharedPreferences], and read back on the next process launch.
 * The class is the single source of truth for which color is
 * applied; [ThemeHelper] reads the current color from this manager
 * when it themes UI components.</p>
 *
 * <p>The theme display names live in the resource array so every
 * locale can present the list in its own language. The colour hex
 * values are locale-independent and remain in this class.</p>
 *
 * <h3>Localization of Theme Names</h3>
 * <p>The array is read on demand through
 * [LanguageManager.getLocalizedContext], not cached from the
 * application context at construction time. The application context
 * resolves against the system locale; the localized context
 * resolves against the app's selected one.</p>
 *
 * <h3>EventBus</h3>
 * <p>[setThemeColor] posts a sticky [SettingsEvent.ThemeColorChanged].
 * Every activity and dialog that paints themed UI subscribes in
 * STICKY mode and recreates itself on the change, so a theme
 * selection propagates to the whole process in a single turn.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>The singleton instance is created under double-checked
 * locking. [setThemeColor] persists the new value, updates the
 * in-memory field, and posts the sticky bus event in that order.
 * `SharedPreferences.Editor.apply()` commits the in-memory map
 * synchronously, so a consumer that reads the persisted index in
 * the same turn sees the new value.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class ThemeManager private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    /** Application context used for preference and resource access. */
    private val mContext: Context = context.applicationContext

    /**
     * Current theme color value, as a hex string.
     *
     * <p>Written by [loadTheme] during construction and by
     * [setThemeColor] on every selection change. Read by
     * [getCurrentColor] and [getCurrentColorInt].</p>
     */
    private var mCurrentColor: String = COLOR_VALUES[0]

    /**
     * Current theme index.
     *
     * <p>Written by [loadTheme] and [setThemeColor]. Read by
     * [getCurrentColorIndex].</p>
     */
    private var mCurrentColorIndex: Int = 0

    init {
        loadTheme()
    }

    // ========================================================================
    // Loading and saving
    // ========================================================================

    /**
     * Reads the persisted theme index into memory.
     *
     * <p>When the stored index is out of range, the default index is
     * used. This guards against a future release that shrinks the
     * palette: a user who had selected index 30 in a version with
     * 31 colors falls back to index 0 when index 30 is no longer
     * valid.</p>
     */
    private fun loadTheme() {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        mCurrentColorIndex = preferences.getInt(
            KEY_THEME_INDEX, DEFAULT_THEME_INDEX
        )
        if (mCurrentColorIndex < 0 ||
            mCurrentColorIndex >= COLOR_VALUES.size
        ) {
            mCurrentColorIndex = DEFAULT_THEME_INDEX
        }
        mCurrentColor = COLOR_VALUES[mCurrentColorIndex]
    }

    /**
     * Applies the theme at the given index, persists the selection,
     * and posts the sticky bus event.
     *
     * <p>An out-of-range index is ignored. An in-range index updates
     * the in-memory value, persists it, and posts the sticky
     * [SettingsEvent.ThemeColorChanged]. Subscribers receive the
     * event synchronously on the same turn.</p>
     *
     * @param colorIndex Index of the theme to apply
     */
    fun setThemeColor(colorIndex: Int) {
        if (colorIndex < 0 || colorIndex >= COLOR_VALUES.size) {
            return
        }
        mCurrentColorIndex = colorIndex
        mCurrentColor = COLOR_VALUES[colorIndex]

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME_COLOR, mCurrentColor)
            .putInt(KEY_THEME_INDEX, mCurrentColorIndex)
            .apply()

        // Announce the change on the process bus. Sticky, so a
        // consumer registering after this call sees the new theme
        // on registration.
        Bus.postSticky(
            SettingsEvent.ThemeColorChanged(
                mCurrentColorIndex, mCurrentColor
            )
        )
    }

    // ========================================================================
    // Getters
    // ========================================================================

    /**
     * Returns the current theme color as a hex string.
     *
     * <p>The string form is what [ThemeHelper.setThemeColor]
     * consumes. Every themed drawable in the app ultimately reads
     * from this string.</p>
     */
    fun getCurrentColor(): String = mCurrentColor

    /**
     * Returns the current theme color as an integer.
     *
     * <p>Re-parses the string on every call. Consumers on the hot
     * path that need the int repeatedly should read through
     * [ThemeHelper.themeColorInt], which is the same computation
     * but lives next to the drawing code.</p>
     */
    fun getCurrentColorInt(): Int = Color.parseColor(mCurrentColor)

    /**
     * Returns the current theme index.
     *
     * <p>Index is what the theme dialog opens with when deciding
     * which row to highlight.</p>
     */
    fun getCurrentColorIndex(): Int = mCurrentColorIndex

    /**
     * Returns a copy of every localized theme display name.
     *
     * <p>Re-reads the resource array on every call so a language
     * change is immediately reflected. A copy is returned so a
     * caller that sorts or filters the array cannot corrupt the
     * resource-backed array.</p>
     */
    fun getColorNames(): Array<String> = loadColorNames().copyOf()

    /**
     * Returns a copy of every theme hex color value.
     */
    fun getColorValues(): Array<String> = COLOR_VALUES.copyOf()

    /**
     * Returns the number of available themes.
     */
    fun getThemeCount(): Int = COLOR_VALUES.size

    /**
     * Returns whether the given theme index is within range.
     */
    fun isValidColorIndex(colorIndex: Int): Boolean =
        colorIndex in COLOR_VALUES.indices

    /**
     * Returns the localized display name of the theme at the given
     * index, or null when the index is out of range.
     */
    fun getColorName(colorIndex: Int): String? {
        if (!isValidColorIndex(colorIndex)) {
            return null
        }
        val names = loadColorNames()
        return if (colorIndex < names.size) names[colorIndex] else null
    }

    /**
     * Returns the hex color value of the theme at the given index,
     * or null when the index is out of range.
     */
    fun getColorValue(colorIndex: Int): String? =
        if (isValidColorIndex(colorIndex)) {
            COLOR_VALUES[colorIndex]
        } else {
            null
        }

    // ========================================================================
    // Localization helper
    // ========================================================================

    /**
     * Reads the theme-names array from the app's selected locale.
     *
     * <p>Falls back to an empty array when the resource lookup
     * fails. The empty array drives the dialog's
     * {@code getColorNames()} to an empty list rather than a null
     * pointer; the dialog then shows no theme rows rather than
     * crashing.</p>
     */
    private fun loadColorNames(): Array<String> = try {
        LanguageManager.getInstance(mContext)
            .getLocalizedContext()
            .resources
            .getStringArray(R.array.theme_names)
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to load theme names", exception)
        emptyArray()
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val TAG = "ThemeManager"

        /** Preference file shared with every other manager. */
        private const val PREFS_NAME = "LlamaPrefs"

        /** Preference key under which the theme hex color is stored. */
        private const val KEY_THEME_COLOR = "theme_color"

        /** Preference key under which the theme index is stored. */
        private const val KEY_THEME_INDEX = "theme_color_index"

        /** Default theme index (Royal Llama, `#B8A86E`). */
        private const val DEFAULT_THEME_INDEX = 0

        /**
         * Hex color values for the available themes, indexed by
         * theme index. The names are read from `R.array.theme_names`
         * at the same index.
         *
         * <p>The palette is grouped by hue family so the picker
         * presents a roughly spectral ordering:</p>
         * <ul>
         *   <li>Index 0: the brand color (Royal Llama).</li>
         *   <li>Indices 1–8: warm tones (magenta through orange).</li>
         *   <li>Indices 9–13: golden tones (amber through yellow).</li>
         *   <li>Indices 14–17: fresh tones (lime through green).</li>
         *   <li>Indices 18–21: cool tones (teal green through cyan).</li>
         *   <li>Indices 22–26: ocean tones (aqua through royal blue).</li>
         *   <li>Indices 27–29: mystic tones (violet through purple).</li>
         *   <li>Indices 30–31: muted tones (white and frosted glass).</li>
         * </ul>
         */
        private val COLOR_VALUES: Array<String> = arrayOf(
            "#B8A86E",  // 0  Royal Llama
            // Warm tones.
            "#FF00FF",  // 1  Neon Flame
            "#FF40BF",  // 2  Berry Crush
            "#FF1493",  // 3  Rose Quartz
            "#FF0066",  // 4  Cherry Pop
            "#FF0000",  // 5  Red Jasper
            "#FF2400",  // 6  Scarlet Fire
            "#FF4500",  // 7  Sunset Glow
            "#FF6B35",  // 8  Citrus Burst
            // Golden tones.
            "#FF8C00",  // 9  Amber Glow
            "#FFB347",  // 10 Wild Honey
            "#FFD700",  // 11 Lemon Drop
            "#FFEA00",  // 12 Solar Flare
            "#FFFF00",  // 13 Neon Yellow
            // Fresh tones.
            "#CFFF00",  // 14 Neon Lime
            "#9AFF00",  // 15 Fresh Kiwi
            "#7FFF00",  // 16 Clover Field
            "#39FF14",  // 17 Neon Green
            // Cool tones.
            "#00FF66",  // 18 Pine Grove
            "#00FF7F",  // 19 Cool Sage
            "#00FFAA",  // 20 Sea Foam
            "#00FFFF",  // 21 Neon Cyan
            // Ocean tones.
            "#00E5FF",  // 22 Aqua Wave
            "#00CED1",  // 23 Navy Blue
            "#00BFFF",  // 24 Ocean Blue
            "#1E90FF",  // 25 Azure Sky
            "#4169E1",  // 26 Royal Blue
            // Mystic tones.
            "#6A5ACD",  // 27 Irish Haze
            "#8A2BE2",  // 28 Indigo Dream
            "#9D00FF",  // 29 Cosmic Purple
            // Muted tones.
            "#FFFFFF",  // 30 Pure White
            "#9DBCBC"   // 31 Frosted Glass
        )

        @Volatile
        private var sInstance: ThemeManager? = null

        /**
         * Returns the singleton instance, creating it on first call.
         */
        @JvmStatic
        fun getInstance(context: Context): ThemeManager {
            if (sInstance == null) {
                synchronized(ThemeManager::class.java) {
                    if (sInstance == null) {
                        sInstance = ThemeManager(context)
                    }
                }
            }
            return sInstance!!
        }
    }
}