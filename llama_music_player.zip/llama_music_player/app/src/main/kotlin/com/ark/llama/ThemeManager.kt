// ThemeManager.kt
package com.ark.llama

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.util.Log
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.SettingsEvent

/**
 * Stores the application's current theme color and exposes the set
 * of available themes.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class ThemeManager private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context.applicationContext

    private var mCurrentColor: String = COLOR_VALUES[0]

    private var mCurrentColorIndex: Int = 0

    init {
        loadTheme()
    }

    // ========================================================================
    // Loading and saving
    // ========================================================================

    private fun loadTheme() {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        mCurrentColorIndex = preferences.getInt(
            KEY_THEME_INDEX, DEFAULT_THEME_INDEX
        )
        if (mCurrentColorIndex < 0 ||
            mCurrentColorIndex >= COLOR_VALUES.size
        ) {
            mCurrentColorIndex = DEFAULT_THEME_INDEX
        }
        mCurrentColor = COLOR_VALUES[mCurrentColorIndex]
    }

    fun setThemeColor(colorIndex: Int) {
        if (colorIndex < 0 || colorIndex >= COLOR_VALUES.size) {
            return
        }
        mCurrentColorIndex = colorIndex
        mCurrentColor = COLOR_VALUES[colorIndex]

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME_COLOR, mCurrentColor)
            .putInt(KEY_THEME_INDEX, mCurrentColorIndex)
            .apply()

        // Announce the change on the process bus. Sticky, so a
        // consumer registering after this call sees the new theme
        // on registration.
        LlamaEventBus.postSticky(
            SettingsEvent.ThemeColorChanged(
                mCurrentColorIndex, mCurrentColor
            )
        )
    }

    // ========================================================================
    // Getters
    // ========================================================================

    fun getCurrentColor(): String = mCurrentColor

    fun getCurrentColorInt(): Int = Color.parseColor(mCurrentColor)

    fun getCurrentColorIndex(): Int = mCurrentColorIndex

    fun getColorNames(): Array<String> = loadColorNames().copyOf()

    fun getColorValues(): Array<String> = COLOR_VALUES.copyOf()

    fun getThemeCount(): Int = COLOR_VALUES.size

    fun isValidColorIndex(colorIndex: Int): Boolean =
        colorIndex in COLOR_VALUES.indices

    fun getColorName(colorIndex: Int): String? {
        if (!isValidColorIndex(colorIndex)) {
            return null
        }
        val names = loadColorNames()
        return if (colorIndex < names.size) names[colorIndex] else null
    }

    fun getColorValue(colorIndex: Int): String? =
        if (isValidColorIndex(colorIndex)) {
            COLOR_VALUES[colorIndex]
        } else {
            null
        }

    // ========================================================================
    // Localization helper
    // ========================================================================

    private fun loadColorNames(): Array<String> = try {
        LanguageManager.getInstance(mContext)
            .getLocalizedContext()
            .resources
            .getStringArray(R.array.theme_names)
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to load theme names", exception)
        emptyArray()
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val TAG = "ThemeManager"

        private const val PREFS_NAME = "LlamaPrefs"

        private const val KEY_THEME_COLOR = "theme_color"

        private const val KEY_THEME_INDEX = "theme_color_index"

        private const val DEFAULT_THEME_INDEX = 0

        private val COLOR_VALUES: Array<String> = arrayOf(
            "#B8A86E",  // 0  Royal Llama
            // Warm tones.
            "#FF00FF",  // 1  Neon Flame
            "#FF40BF",  // 2  Berry Crush
            "#FF1493",  // 3  Rose Quartz
            "#FF0066",  // 4  Cherry Pop
            "#FF0000",  // 5  Red Jasper
            "#FF2400",  // 6  Scarlet Fire
            "#FF4500",  // 7  Sunset Glow
            "#FF6B35",  // 8  Citrus Burst
            // Golden tones.
            "#FF8C00",  // 9  Amber Glow
            "#FFB347",  // 10 Wild Honey
            "#FFD700",  // 11 Lemon Drop
            "#FFEA00",  // 12 Solar Flare
            "#FFFF00",  // 13 Neon Yellow
            // Fresh tones.
            "#CFFF00",  // 14 Neon Lime
            "#9AFF00",  // 15 Fresh Kiwi
            "#7FFF00",  // 16 Clover Field
            "#39FF14",  // 17 Neon Green
            // Cool tones.
            "#00FF66",  // 18 Pine Grove
            "#00FF7F",  // 19 Cool Sage
            "#00FFAA",  // 20 Sea Foam
            "#00FFFF",  // 21 Neon Cyan
            // Ocean tones.
            "#00E5FF",  // 22 Aqua Wave
            "#00CED1",  // 23 Navy Blue
            "#00BFFF",  // 24 Ocean Blue
            "#1E90FF",  // 25 Azure Sky
            "#4169E1",  // 26 Royal Blue
            // Mystic tones.
            "#6A5ACD",  // 27 Irish Haze
            "#8A2BE2",  // 28 Indigo Dream
            "#9D00FF",  // 29 Cosmic Purple
            // Muted tones.
            "#FFFFFF",  // 30 Pure White
            "#9DBCBC"   // 31 Frosted Glass
        )

        @Volatile
        private var sInstance: ThemeManager? = null

        @JvmStatic
        fun getInstance(context: Context): ThemeManager {
            if (sInstance == null) {
                synchronized(ThemeManager::class.java) {
                    if (sInstance == null) {
                        sInstance = ThemeManager(context)
                    }
                }
            }
            return sInstance!!
        }
    }
}