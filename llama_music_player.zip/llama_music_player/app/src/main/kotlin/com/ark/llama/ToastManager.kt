// ToastManager.kt
package com.ark.llama

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.FrameLayout
import android.widget.TextView
import com.ark.llama.event.Bus
import com.ark.llama.event.SettingsEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.lang.ref.WeakReference
import java.util.ArrayList
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Owns every in-activity toast and persistent overlay the app shows,
 * and drives their lifecycle through an operation stack.
 *
 * <p>Persistent overlays are owned by operations. An operation is
 * registered on the stack by its operation ID. The stack renders the
 * operation at the top; a lower operation's message is retained but
 * not shown while a higher operation is active, and surfaces
 * automatically when the higher operation ends.</p>
 *
 * <p>Each activity maintains its own overlay view instances, tracked
 * in [mOverlayMap]. An activity's overlays are removed only when the
 * activity is destroyed. A periodic health check treats a
 * persistent overlay whose owner has stopped heartbeating, or an
 * overlay whose view has been detached from its parent, as stuck and
 * runs a recovery pass.</p>
 *
 * <p>Every persistent overlay is mirrored to the status bar through
 * [NotificationController]. Temporary toasts are not mirrored.</p>
 *
 * <h3>Theme Application</h3>
 * <p>When [SettingsEvent.ThemeColorChanged] arrives on the sticky
 * bus, every persistent overlay's view is removed and re-created
 * through [createOverlayInView], which reads the current theme color
 * at construction. No view is repainted in place. Temporary toasts
 * are not rebuilt.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every public method runs on the main thread. State transitions
 * and view mutation run on [mMainHandler]. The overlay map, the
 * operation stack, and the pending-dismissal map are
 * thread-safe collections.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class ToastManager private constructor(context: Context) :
    Application.ActivityLifecycleCallbacks {

    // ========================================================================
    // State machine
    // ========================================================================

    enum class State {
        HIDDEN, SHOWING_TEMPORARY, SHOWING_PERSISTENT,
        HIDING, REATTACHING, STUCK
    }

    enum class Event {
        SHOW_TEMPORARY, SHOW_PERSISTENT, UPDATE, HEARTBEAT,
        HIDE, FORCE_HIDE, REATTACH, STUCK_DETECTED, RECOVERED
    }

    private fun isPersistentActive(state: State?): Boolean =
        state == State.SHOWING_PERSISTENT || state == State.REATTACHING

    interface ToastStateListener {
        fun onStateChanged(oldState: State, newState: State)
        fun onStuckToastDetected(reason: String, ageMs: Long, inactiveTimeMs: Long)
    }

    // ========================================================================
    // OverlayHolder
    // ========================================================================

    private class OverlayHolder(
        overlay: FrameLayout,
        textView: TextView,
        activity: Activity?,
        rootView: ViewGroup,
        @JvmField val message: String,
        @JvmField val operationId: String?,
        @JvmField val isPersistent: Boolean
    ) {
        val overlayRef = WeakReference(overlay)
        val textViewRef = WeakReference(textView)
        val activityRef = WeakReference(activity)
        val rootViewRef = WeakReference(rootView)

        fun isValid(): Boolean =
            overlayRef.get() != null && textViewRef.get() != null

        fun cleanup() {
            overlayRef.get()?.let { overlay ->
                (overlay.parent as? ViewGroup)?.removeView(overlay)
            }
        }
    }

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mOverlayMap = ConcurrentHashMap<String, OverlayHolder>()
    private val mOperationOrder = CopyOnWriteArrayList<String>()
    private val mOperationMessages = ConcurrentHashMap<String, String>()
    private val mOperationBodies = ConcurrentHashMap<String, String>()
    private val mOperationHeartbeats = ConcurrentHashMap<String, Long>()

    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mHealthHandler = Handler(Looper.getMainLooper())

    private val mState = AtomicReference(State.HIDDEN)
    private val mStateStartTime = AtomicLong(0L)
    private val mLastActivityTime = AtomicLong(0L)
    private val mLastValidOverlayTime = AtomicLong(0L)
    private val mIsRecovering = AtomicBoolean(false)

    private var mHealthCheckRunnable: Runnable? = null
    private var mRecoveryRunnable: Runnable? = null
    private val mHealthLock = Any()
    private val mStackLock = Any()

    private val mPendingAutoDismiss = ConcurrentHashMap<String, Runnable>()

    private var mCurrentActivityRef: WeakReference<Activity>? = null
    private var mCallbacksRegistered = false

    private val mStateListeners = CopyOnWriteArrayList<ToastStateListener>()

    init {
        sApplication = context.applicationContext as Application
        registerLifecycleCallbacks()
        startHealthCheck()
        mState.set(State.HIDDEN)
        mStateStartTime.set(SystemClock.elapsedRealtime())
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime())
        Bus.register(this)
        Log.d(TAG, "ToastManager initialized")
    }

    // ========================================================================
    // Sticky theme subscriber
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        mMainHandler.post { rebuildPersistentOverlaysForTheme() }
    }

    // ========================================================================
    // Activity lifecycle
    // ========================================================================

    private fun registerLifecycleCallbacks() {
        if (mCallbacksRegistered || sApplication == null) return
        sApplication?.registerActivityLifecycleCallbacks(this)
        mCallbacksRegistered = true
        Log.d(TAG, "Activity lifecycle callbacks registered")
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}

    override fun onActivityResumed(activity: Activity) {
        mCurrentActivityRef = WeakReference(activity)
        val currentState = mState.get()
        val hasOperations = mOperationOrder.isNotEmpty()
        if (isPersistentActive(currentState) || hasOperations) {
            if (currentState == State.SHOWING_PERSISTENT) {
                handleEvent(Event.REATTACH)
            } else if (!isPersistentActive(currentState)) {
                transitionTo(State.SHOWING_PERSISTENT)
            }
            reattachToActivity(activity)
        } else if (currentState == State.SHOWING_TEMPORARY) {
            Log.d(TAG, "Temporary toast showing, not reattaching " +
                "(auto-dismiss will handle it)")
        }
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {
        if (mCurrentActivityRef?.get() === activity) mCurrentActivityRef = null
        performHealthCheck()
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {
        if (mCurrentActivityRef?.get() === activity) mCurrentActivityRef = null

        val activityKey = getActivityKey(activity)
        val tempKey = getTempToastKey(activity)

        mOverlayMap.remove(activityKey)?.cleanup()
        mOverlayMap.remove(tempKey)?.cleanup()

        mPendingAutoDismiss.remove(tempKey)?.let { mMainHandler.removeCallbacks(it) }

        recomputeStateFromMap()
        performHealthCheck()
    }

    // ========================================================================
    // State machine
    // ========================================================================

    private fun transitionTo(newState: State) {
        val oldState = mState.getAndSet(newState)
        if (oldState == newState) return
        Log.d(TAG, "State transition: $oldState -> $newState")
        mStateStartTime.set(SystemClock.elapsedRealtime())
        for (listener in mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState)
            } catch (exception: Exception) {
                Log.e(TAG, "Error notifying state listener", exception)
            }
        }
    }

    private fun recomputeStateFromMap() {
        if (mState.get() == State.REATTACHING) return

        var hasPersistent = false
        var hasTemporary = false
        for (holder in mOverlayMap.values) {
            if (holder.isPersistent) hasPersistent = true else hasTemporary = true
        }

        val hasOperations: Boolean
        synchronized(mStackLock) { hasOperations = mOperationOrder.isNotEmpty() }

        if (hasPersistent || hasOperations) {
            transitionTo(State.SHOWING_PERSISTENT)
        } else if (hasTemporary) {
            transitionTo(State.SHOWING_TEMPORARY)
        } else {
            transitionTo(State.HIDDEN)
        }
    }

    private fun handleEvent(event: Event): Boolean {
        val currentState = mState.get()
        Log.v(TAG, "Event: $event in state: $currentState")

        return when (event) {
            Event.SHOW_TEMPORARY -> {
                if (currentState == State.HIDDEN || currentState == State.HIDING ||
                    currentState == State.SHOWING_TEMPORARY
                ) {
                    transitionTo(State.SHOWING_TEMPORARY); true
                } else {
                    Log.w(TAG, "SHOW_TEMPORARY in state $currentState — refusing"); false
                }
            }
            Event.SHOW_PERSISTENT -> {
                transitionTo(State.SHOWING_PERSISTENT); true
            }
            Event.UPDATE -> {
                if (isPersistentActive(currentState)) {
                    mLastActivityTime.set(SystemClock.elapsedRealtime()); true
                } else false
            }
            Event.HEARTBEAT -> {
                if (isPersistentActive(currentState)) {
                    mLastActivityTime.set(SystemClock.elapsedRealtime()); true
                } else false
            }
            Event.HIDE -> {
                if (isPersistentActive(currentState)) {
                    transitionTo(State.HIDING); true
                } else currentState == State.HIDDEN
            }
            Event.FORCE_HIDE -> {
                if (currentState != State.HIDDEN) {
                    transitionTo(State.HIDING); true
                } else true
            }
            Event.REATTACH -> {
                if (currentState == State.SHOWING_PERSISTENT) {
                    transitionTo(State.REATTACHING); true
                } else currentState == State.REATTACHING
            }
            Event.STUCK_DETECTED -> {
                if (isPersistentActive(currentState) ||
                    currentState == State.SHOWING_TEMPORARY
                ) {
                    Log.w(TAG, "Overlay stuck detected, transitioning to STUCK")
                    transitionTo(State.STUCK); true
                } else false
            }
            Event.RECOVERED -> {
                if (currentState == State.STUCK) {
                    transitionTo(State.HIDDEN); true
                } else false
            }
        }
    }

    // ========================================================================
    // Health check
    // ========================================================================

    private fun startHealthCheck() {
        val runnable = object : Runnable {
            override fun run() {
                performHealthCheck()
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS)
                }
            }
        }
        mHealthCheckRunnable = runnable
        mHealthHandler.postDelayed(runnable, HEALTH_CHECK_INTERVAL_MS)
    }

    private fun performHealthCheck() {
        synchronized(mHealthLock) {
            val currentState = mState.get()
            if (currentState != State.SHOWING_TEMPORARY &&
                !isPersistentActive(currentState)
            ) return

            val now = SystemClock.elapsedRealtime()
            val age = now - mStateStartTime.get()

            var hasValidPersistent = false
            for (holder in mOverlayMap.values) {
                if (holder.isPersistent && holder.isValid()) {
                    hasValidPersistent = true
                    mLastValidOverlayTime.set(now)
                    break
                }
            }

            var isStuck = false
            var stuckReason: String? = null

            if (isPersistentActive(currentState) && !hasValidPersistent) {
                val noOverlayDuration = now - mLastValidOverlayTime.get()
                if (noOverlayDuration > STUCK_TIMEOUT_MS) {
                    isStuck = true
                    stuckReason = "Persistent overlay missing for ${noOverlayDuration}ms " +
                        "(timeout: ${STUCK_TIMEOUT_MS}ms)"
                }
            } else if (isPersistentActive(currentState)) {
                val topId = getCurrentOperationId()
                if (topId != null) {
                    val heartbeat = mOperationHeartbeats[topId]
                    val lastActivity = heartbeat ?: mStateStartTime.get()
                    val inactiveTime = now - lastActivity
                    if (inactiveTime > STUCK_TIMEOUT_MS) {
                        isStuck = true
                        stuckReason = "No heartbeat for operation '$topId' in " +
                            "${inactiveTime}ms (timeout: ${STUCK_TIMEOUT_MS}ms)"
                    }
                }
            }

            if (isStuck) {
                Log.w(TAG, "STUCK OVERLAY DETECTED: $stuckReason")
                for (listener in mStateListeners) {
                    try {
                        listener.onStuckToastDetected(
                            stuckReason!!, age, now - mLastActivityTime.get()
                        )
                    } catch (exception: Exception) {
                        Log.e(TAG, "Error notifying stuck listener", exception)
                    }
                }
                if (handleEvent(Event.STUCK_DETECTED)) startRecovery()
            }
        }
    }

    private fun startRecovery() {
        if (mIsRecovering.getAndSet(true)) return
        Log.d(TAG, "Starting overlay recovery")
        cancelRecovery()
        val runnable = object : Runnable {
            override fun run() {
                Log.d(TAG, "Overlay recovery completed")
                forceHideAllOverlays()
                handleEvent(Event.RECOVERED)
                mIsRecovering.set(false)
                mRecoveryRunnable = null
            }
        }
        mRecoveryRunnable = runnable
        mMainHandler.postDelayed(runnable, RECOVERY_DELAY_MS)
    }

    private fun cancelRecovery() {
        mRecoveryRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mRecoveryRunnable = null
        }
        mIsRecovering.set(false)
    }

    // ========================================================================
    // Public API — getCurrentActivity
    // ========================================================================

    fun getCurrentActivityOrNull(): Activity? = mCurrentActivityRef?.get()

    // ========================================================================
    // Public API — heartbeat
    // ========================================================================

    fun heartbeatInternal(operationId: String?): Boolean {
        if (operationId == null) return false
        if (!mOperationOrder.contains(operationId)) return false
        mOperationHeartbeats[operationId] = SystemClock.elapsedRealtime()
        mLastActivityTime.set(SystemClock.elapsedRealtime())
        return handleEvent(Event.HEARTBEAT)
    }

    // ========================================================================
    // Temporary toasts
    // ========================================================================

    fun showToastInternal(activity: Activity, message: String, duration: Long) {
        if (activity.isFinishing || activity.isDestroyed) {
            Log.w(TAG, "Cannot show toast in finishing/destroyed activity")
            return
        }
        val tempKey = getTempToastKey(activity)
        mOverlayMap.remove(tempKey)?.cleanup()
        mPendingAutoDismiss.remove(tempKey)?.let { mMainHandler.removeCallbacks(it) }

        val currentState = mState.get()
        if (!isPersistentActive(currentState)) handleEvent(Event.SHOW_TEMPORARY)
        mLastActivityTime.set(SystemClock.elapsedRealtime())

        val root = activity.window?.decorView
            ?.findViewById<ViewGroup>(android.R.id.content) ?: run {
            Log.w(TAG, "Content view not found, cannot show toast")
            return
        }

        createOverlayInView(activity, root, message, false, tempKey, null)

        val dismissRunnable = object : Runnable {
            override fun run() {
                mOverlayMap.remove(tempKey)?.cleanup()
                recomputeStateFromMap()
                mPendingAutoDismiss.remove(tempKey)
            }
        }
        mPendingAutoDismiss[tempKey] = dismissRunnable
        mMainHandler.postDelayed(dismissRunnable, duration)
    }

    fun showToastInViewInternal(rootView: ViewGroup, message: String, duration: Long) {
        val tempKey = getTempToastKey(null)
        mOverlayMap.remove(tempKey)?.cleanup()
        mPendingAutoDismiss.remove(tempKey)?.let { mMainHandler.removeCallbacks(it) }

        val currentState = mState.get()
        if (!isPersistentActive(currentState)) handleEvent(Event.SHOW_TEMPORARY)
        mLastActivityTime.set(SystemClock.elapsedRealtime())

        createOverlayInView(null, rootView, message, false, tempKey, null)

        val dismissRunnable = object : Runnable {
            override fun run() {
                mOverlayMap.remove(tempKey)?.cleanup()
                recomputeStateFromMap()
                mPendingAutoDismiss.remove(tempKey)
            }
        }
        mPendingAutoDismiss[tempKey] = dismissRunnable
        mMainHandler.postDelayed(dismissRunnable, duration)
    }

    // ========================================================================
    // Persistent overlays
    // ========================================================================

    fun showPersistentOverlayInternal(
        activity: Activity,
        title: String,
        body: String,
        operationId: String?
    ) {
        if (activity.isFinishing || activity.isDestroyed) {
            Log.w(TAG, "Cannot show persistent overlay in finishing/destroyed activity")
            return
        }
        if (operationId != null) pushOperationInternal(operationId, title, body)

        removeAllOverlayViews()
        handleEvent(Event.SHOW_PERSISTENT)
        mLastActivityTime.set(SystemClock.elapsedRealtime())

        val root = activity.window?.decorView
            ?.findViewById<ViewGroup>(android.R.id.content) ?: run {
            Log.w(TAG, "Content view not found, cannot show persistent overlay")
            return
        }

        val key = getActivityKey(activity)
        val renderedOperationId = getCurrentOperationId()
        val renderedTitle = renderedOperationId?.let { mOperationMessages[it] } ?: title
        val renderedBody = renderedOperationId?.let { mOperationBodies[it] } ?: body
        val renderedMessage = composeOverlayText(renderedTitle, renderedBody)

        createOverlayInView(activity, root, renderedMessage, true, key, renderedOperationId)
        mCurrentActivityRef = WeakReference(activity)

        sApplication?.let {
            NotificationController.getInstance(it)
                .showLibraryStatus(title, body, renderedOperationId)
        }

        Log.d(TAG, "Persistent overlay shown: $renderedMessage" +
            (renderedOperationId?.let { " (ID: $it)" } ?: ""))
    }

    fun updatePersistentOverlayInternal(title: String, body: String, operationId: String) {
        val currentState = mState.get()
        if (!isPersistentActive(currentState)) {
            Log.w(TAG, "Cannot update persistent overlay - no persistent overlay is showing")
            return
        }
        if (!mOperationOrder.contains(operationId)) {
            Log.d(TAG, "Update rejected - operation not on stack: $operationId")
            return
        }

        mOperationMessages[operationId] = title
        mOperationBodies[operationId] = body
        mOperationHeartbeats[operationId] = SystemClock.elapsedRealtime()

        if (!handleEvent(Event.UPDATE)) return

        val topId = getCurrentOperationId()
        if (topId != operationId) {
            Log.v(TAG, "Operation updated below top of stack: $operationId")
            return
        }

        val composedMessage = composeOverlayText(title, body)
        mMainHandler.post {
            for (holder in mOverlayMap.values) {
                if (!holder.isPersistent) continue
                val textView = holder.textViewRef.get() ?: continue
                val rootView = holder.rootViewRef.get()
                if (rootView != null) {
                    textView.maxWidth = resolveAvailableToastWidthPx(rootView)
                }
                textView.text = composedMessage
            }
        }

        sApplication?.let {
            NotificationController.getInstance(it)
                .updateLibraryStatus(title, body, operationId)
        }
    }

    fun hidePersistentOverlayInternal(operationId: String?): Boolean {
        if (operationId == null) return false
        return popOperationInternal(operationId)
    }

    fun hideAllPersistentOverlaysInternal() {
        val currentState = mState.get()
        if (currentState == State.SHOWING_TEMPORARY || isPersistentActive(currentState)) {
            val currentId = getCurrentOperationId()
            handleEvent(Event.FORCE_HIDE)
            removeAllOverlayViews()
            clearOperationStack()
            sApplication?.let {
                NotificationController.getInstance(it).dismissLibraryStatus(currentId)
            }
        }
    }

    fun hasPersistentToastInternal(): Boolean = isPersistentActive(mState.get())

    fun getPersistentToastTextInternal(): String? {
        val topId = getCurrentOperationId() ?: return null
        return mOperationMessages[topId]
    }

    fun cancelOperationInternal(operationId: String?) {
        if (operationId == null) return
        popOperationInternal(operationId)
    }

    fun getCurrentOperationIdInternal(): String? = getCurrentOperationId()

    fun isOperationRunningInternal(operationId: String?): Boolean {
        if (operationId == null) return false
        return mOperationOrder.contains(operationId)
    }

    fun getOperationMessageInternal(operationId: String?): String? {
        if (operationId == null) return null
        return mOperationMessages[operationId]
    }

    fun reattachToCurrentActivityInternal(activity: Activity) {
        val currentState = mState.get()
        if (!isPersistentActive(currentState) && mOperationOrder.isEmpty()) return
        if (activity.isFinishing || activity.isDestroyed) return

        mMainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) return@post
            val currentStateCheck = mState.get()
            if (currentStateCheck == State.HIDDEN && mOperationOrder.isEmpty()) return@post
            if (isPersistentActive(currentStateCheck)) {
                handleEvent(Event.REATTACH)
            } else {
                transitionTo(State.SHOWING_PERSISTENT)
            }
            reattachToActivity(activity)
        }
    }

    fun ensureOverlayAttachedInternal(activity: Activity) {
        val currentState = mState.get()
        if (!isPersistentActive(currentState) && mOperationOrder.isEmpty()) return
        val key = getActivityKey(activity)
        val holder = mOverlayMap[key]
        if (holder == null || !holder.isValid()) {
            reattachToCurrentActivityInternal(activity)
        }
    }

    fun addStateListenerInternal(listener: ToastStateListener) {
        mStateListeners.add(listener)
        val currentState = mState.get()
        listener.onStateChanged(currentState, currentState)
    }

    fun removeStateListenerInternal(listener: ToastStateListener) {
        mStateListeners.remove(listener)
    }

    // ========================================================================
    // Stack internals
    // ========================================================================

    private fun pushOperationInternal(operationId: String, message: String, body: String) {
        synchronized(mStackLock) {
            mOperationOrder.remove(operationId)
            mOperationMessages[operationId] = message
            mOperationBodies[operationId] = body
            mOperationHeartbeats[operationId] = SystemClock.elapsedRealtime()
            mOperationOrder.add(operationId)
        }
    }

    private fun popOperationInternal(operationId: String): Boolean {
        val newTopId: String?
        val wasTop: Boolean
        synchronized(mStackLock) {
            if (!mOperationOrder.contains(operationId)) return false
            wasTop = operationId == mOperationOrder[mOperationOrder.size - 1]
            mOperationOrder.remove(operationId)
            mOperationMessages.remove(operationId)
            mOperationBodies.remove(operationId)
            mOperationHeartbeats.remove(operationId)
            newTopId = if (mOperationOrder.isEmpty()) null
            else mOperationOrder[mOperationOrder.size - 1]
        }

        if (!wasTop) {
            Log.v(TAG, "Popped operation below top of stack: $operationId")
            return true
        }

        if (newTopId == null) {
            handleEvent(Event.HIDE)
            removePersistentOverlayViews(true)
            sApplication?.let {
                NotificationController.getInstance(it).dismissLibraryStatus(operationId)
            }
        } else {
            val newTitle = mOperationMessages[newTopId] ?: ""
            val newBody = mOperationBodies[newTopId] ?: ""
            val finalMessage = composeOverlayText(newTitle, newBody)
            mMainHandler.post {
                for (holder in mOverlayMap.values) {
                    if (!holder.isPersistent) continue
                    val textView = holder.textViewRef.get() ?: continue
                    val rootView = holder.rootViewRef.get()
                    if (rootView != null) {
                        textView.maxWidth = resolveAvailableToastWidthPx(rootView)
                    }
                    textView.text = finalMessage
                }
            }
            sApplication?.let {
                NotificationController.getInstance(it)
                    .showLibraryStatus(newTitle, newBody, newTopId)
            }
        }
        return true
    }

    private fun clearOperationStack() {
        synchronized(mStackLock) {
            mOperationOrder.clear()
            mOperationMessages.clear()
            mOperationBodies.clear()
            mOperationHeartbeats.clear()
        }
    }

    // ========================================================================
    // Reattach
    // ========================================================================

    private fun reattachToActivity(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        val topId = getCurrentOperationId() ?: run {
            Log.w(TAG, "Cannot reattach - stack is empty")
            return
        }
        val title = mOperationMessages[topId] ?: run {
            Log.w(TAG, "Cannot reattach - no message available")
            return
        }
        val body = mOperationBodies[topId] ?: ""
        val message = composeOverlayText(title, body)

        val key = getActivityKey(activity)
        mOverlayMap.remove(key)?.cleanup()

        val root = activity.window?.decorView
            ?.findViewById<ViewGroup>(android.R.id.content) ?: run {
            Log.w(TAG, "Content view not found for reattachment")
            return
        }

        createOverlayInView(activity, root, message, true, key, topId)
        mCurrentActivityRef = WeakReference(activity)
        if (mState.get() != State.SHOWING_PERSISTENT) {
            transitionTo(State.SHOWING_PERSISTENT)
        }
    }

    // ========================================================================
    // View management
    // ========================================================================

    private fun createOverlayInView(
        activity: Activity?,
        rootView: ViewGroup,
        message: String,
        isPersistent: Boolean,
        key: String,
        operationId: String?
    ) {
        mOverlayMap.remove(key)?.cleanup()

        val container = FrameLayout(rootView.context)
        val containerParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dpToPx(rootView.context, resolveBottomMarginDp())
        }
        container.layoutParams = containerParams
        container.setPadding(0, 0, 0, 0)

        val availableWidthPx = resolveAvailableToastWidthPx(rootView)

        val textView = TextView(rootView.context).apply {
            text = message
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            maxLines = 1
            isHorizontalScrollingEnabled = false
            maxWidth = availableWidthPx
            setPadding(
                dpToPx(rootView.context, TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.context, TOAST_PADDING_VERTICAL_DP),
                dpToPx(rootView.context, TOAST_PADDING_HORIZONTAL_DP),
                dpToPx(rootView.context, TOAST_PADDING_VERTICAL_DP)
            )
            setTextColor(getThemeColor())
        }

        val background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(TOAST_BACKGROUND_COLOR)
            cornerRadius = dpToPx(rootView.context, TOAST_CORNER_RADIUS_DP).toFloat()
            setStroke(
                dpToPx(rootView.context, TOAST_STROKE_WIDTH_DP),
                TOAST_STROKE_COLOR
            )
        }
        textView.background = background

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.elevation = dpToPx(rootView.context, TOAST_ELEVATION_DP).toFloat()
        }

        container.addView(textView)
        rootView.addView(container)

        mOverlayMap[key] = OverlayHolder(
            container, textView, activity, rootView, message, operationId, isPersistent
        )
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime())

        if (activity != null) mCurrentActivityRef = WeakReference(activity)

        val fadeIn = AlphaAnimation(0f, 1f).apply { duration = FADE_DURATION_MS.toLong() }
        container.startAnimation(fadeIn)
    }

    private fun removeAllOverlayViews() {
        for (holder in mOverlayMap.values) holder.cleanup()
        mOverlayMap.clear()
        for (pending in mPendingAutoDismiss.values) mMainHandler.removeCallbacks(pending)
        mPendingAutoDismiss.clear()
        transitionTo(State.HIDDEN)
    }

    private fun removePersistentOverlayViews(animate: Boolean) {
        val keysToRemove = ArrayList<String>()
        for ((key, holder) in mOverlayMap) {
            if (holder.isPersistent) keysToRemove.add(key)
        }

        for (key in keysToRemove) {
            val holder = mOverlayMap.remove(key) ?: continue
            if (animate) {
                val overlay = holder.overlayRef.get()
                if (overlay != null) {
                    val fadeOut = AlphaAnimation(1f, 0f).apply { duration = FADE_DURATION_MS.toLong() }
                    fadeOut.setAnimationListener(object : Animation.AnimationListener {
                        override fun onAnimationStart(animation: Animation) {}
                        override fun onAnimationEnd(animation: Animation) {
                            (overlay.parent as? ViewGroup)?.removeView(overlay)
                        }
                        override fun onAnimationRepeat(animation: Animation) {}
                    })
                    overlay.startAnimation(fadeOut)
                }
            } else {
                holder.cleanup()
            }
        }

        recomputeStateFromMap()
    }

    private fun forceHideAllOverlays() {
        removeAllOverlayViews()
        clearOperationStack()
        sApplication?.let { NotificationController.getInstance(it).clearLibraryStatus() }
    }

    // ========================================================================
    // Helpers
    // ========================================================================

    private fun composeOverlayText(title: String, body: String): String =
        if (body.isEmpty()) title else "$title$OVERLAY_SEPARATOR$body"

    private fun getActivityKey(activity: Activity?): String =
        if (activity == null) KEY_ROOT_VIEW_ONLY
        else "${activity.javaClass.name}@${System.identityHashCode(activity)}"

    private fun getTempToastKey(activity: Activity?): String =
        "$KEY_TEMP_TOAST_PREFIX${getActivityKey(activity)}"

    private fun getCurrentOperationId(): String? {
        val order = mOperationOrder
        if (order.isEmpty()) return null
        return order[order.size - 1]
    }

    private fun rebuildPersistentOverlaysForTheme() {
        val topId = getCurrentOperationId() ?: return
        val title = mOperationMessages[topId] ?: return
        val body = mOperationBodies[topId] ?: ""
        val message = composeOverlayText(title, body)

        var removedAny = false
        for (key in ArrayList(mOverlayMap.keys)) {
            val holder = mOverlayMap[key] ?: continue
            if (holder.isPersistent) {
                holder.cleanup()
                mOverlayMap.remove(key)
                removedAny = true
            }
        }
        if (!removedAny) return

        val current = mCurrentActivityRef?.get() ?: return
        if (current.isFinishing || current.isDestroyed) return

        val root = current.window?.decorView
            ?.findViewById<ViewGroup>(android.R.id.content) ?: return

        val key = getActivityKey(current)
        createOverlayInView(current, root, message, true, key, topId)
        mCurrentActivityRef = WeakReference(current)
        mLastValidOverlayTime.set(SystemClock.elapsedRealtime())
    }

    private fun getThemeColor(): Int = try {
        sApplication?.let { ThemeManager.getInstance(it).getCurrentColorInt() }
            ?: DEFAULT_THEME_COLOR
    } catch (exception: Exception) {
        DEFAULT_THEME_COLOR
    }

    private fun resolveBottomMarginDp(): Int {
        val app = sApplication ?: return TOAST_BOTTOM_MARGIN_DP
        try {
            val configuration: Configuration = app.resources.configuration
            val heightDp = configuration.screenHeightDp
            if (heightDp > 0 && heightDp <= COMPACT_LAYOUT_HEIGHT_DP) {
                return TOAST_BOTTOM_MARGIN_COMPACT_DP
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to read window height for toast margin", exception)
        }
        return TOAST_BOTTOM_MARGIN_DP
    }

    private fun resolveAvailableToastWidthPx(rootView: ViewGroup): Int {
        val context = rootView.context
        val measuredWidth = rootView.width
        val baseWidth = if (measuredWidth > 0) measuredWidth
        else rootView.resources.displayMetrics.widthPixels
        val insetPx = dpToPx(context, TOAST_HORIZONTAL_INSET_DP)
        return Math.max(0, baseWidth - insetPx * 2)
    }

    private fun dpToPx(context: Context, dp: Int): Int =
        Math.round(dp * context.resources.displayMetrics.density)

    fun getDebugInfo(): String {
        val current = mCurrentActivityRef?.get()
        var persistentCount = 0
        var tempCount = 0
        for (holder in mOverlayMap.values) {
            if (holder.isPersistent) persistentCount++ else tempCount++
        }
        return "ToastManager\n" +
            "State: ${mState.get()}\n" +
            "State duration: ${SystemClock.elapsedRealtime() - mStateStartTime.get()}ms\n" +
            "Last activity: ${SystemClock.elapsedRealtime() - mLastActivityTime.get()}ms ago\n" +
            "Last valid overlay: ${SystemClock.elapsedRealtime() - mLastValidOverlayTime.get()}ms ago\n" +
            "Operation stack size: ${mOperationOrder.size}\n" +
            "Top operation: ${getCurrentOperationId()}\n" +
            "Current activity: ${current?.javaClass?.simpleName ?: "null"}\n" +
            "Persistent overlays: $persistentCount\n" +
            "Temporary toasts: $tempCount\n" +
            "Pending dismissals: ${mPendingAutoDismiss.size}\n" +
            "Listeners: ${mStateListeners.size}"
    }

    fun shutdown() {
        Log.d(TAG, "Shutting down ToastManager")
        for (pending in mPendingAutoDismiss.values) mMainHandler.removeCallbacks(pending)
        mPendingAutoDismiss.clear()
        cancelRecovery()
        mHealthCheckRunnable?.let { mHealthHandler.removeCallbacks(it) }
        mHealthCheckRunnable = null
        if (mCallbacksRegistered && sApplication != null) {
            try {
                sApplication?.unregisterActivityLifecycleCallbacks(this)
                mCallbacksRegistered = false
            } catch (ignored: Exception) {}
        }
        Bus.unregister(this)
        forceHideAllOverlays()
        sInstance = null
        sApplication = null
    }

    // ========================================================================
    // Companion — static facade for Java callers
    // ========================================================================

    companion object {
        private const val TAG = "ToastManager"

        const val LENGTH_SHORT: Long = 500L
        const val LENGTH_NORMAL: Long = 1000L
        const val LENGTH_LONG: Long = 2000L

        private const val FADE_DURATION_MS = 150
        private const val TOAST_HORIZONTAL_INSET_DP = 16
        private const val TOAST_PADDING_HORIZONTAL_DP = 8
        private const val TOAST_PADDING_VERTICAL_DP = 8
        private const val TOAST_BOTTOM_MARGIN_DP = 76
        private const val TOAST_BOTTOM_MARGIN_COMPACT_DP = 68
        private const val COMPACT_LAYOUT_HEIGHT_DP = 400
        private const val TOAST_CORNER_RADIUS_DP = 8
        private const val TOAST_STROKE_WIDTH_DP = 1
        private const val TOAST_ELEVATION_DP = 6

        private val TOAST_BACKGROUND_COLOR = 0xFF1A1A1A.toInt()
        private val TOAST_STROKE_COLOR = 0xFF2A2A2A.toInt()
        private val DEFAULT_THEME_COLOR = 0xFFB8A86E.toInt()

        private const val HEALTH_CHECK_INTERVAL_MS = 500L
        private const val STUCK_TIMEOUT_MS = 1000L
        private const val RECOVERY_DELAY_MS = 500L

        private const val KEY_TEMP_TOAST_PREFIX = "TEMP_TOAST_"
        private const val KEY_ROOT_VIEW_ONLY = "ROOT_VIEW_ONLY"
        private const val OVERLAY_SEPARATOR = " \u00B7 "

        @Volatile private var sInstance: ToastManager? = null
        @Volatile private var sApplication: Application? = null

        @JvmStatic
        @Synchronized
        fun init(context: Context) {
            if (sInstance == null) {
                sInstance = ToastManager(context)
            }
        }

        private fun getInstance(): ToastManager {
            val instance = sInstance ?: throw IllegalStateException(
                "ToastManager not initialized. Call init() first."
            )
            return instance
        }

        @JvmStatic
        fun isOperationRunning(operationId: String?): Boolean =
            getInstance().isOperationRunningInternal(operationId)

        @JvmStatic
        fun cancelOperation(operationId: String?) {
            getInstance().cancelOperationInternal(operationId)
        }

        @JvmStatic
        fun getCurrentOperationId(): String? = getInstance().getCurrentOperationIdInternal()

        @JvmStatic
        fun getOperationMessage(operationId: String?): String? =
            getInstance().getOperationMessageInternal(operationId)

        @JvmStatic
        fun getCurrentActivity(): Activity? = getInstance().getCurrentActivityOrNull()

        @JvmStatic
        fun heartbeat(operationId: String?): Boolean =
            getInstance().heartbeatInternal(operationId)

        @JvmStatic
        fun showToast(activity: Activity, message: String, duration: Long) {
            getInstance().showToastInternal(activity, message, duration)
        }

        @JvmStatic
        fun showToast(activity: Activity, message: String) {
            showToast(activity, message, LENGTH_LONG)
        }

        @JvmStatic
        fun showToastInView(rootView: ViewGroup, message: String, duration: Long) {
            getInstance().showToastInViewInternal(rootView, message, duration)
        }

        @JvmStatic
        fun showPersistentOverlay(activity: Activity, message: String) {
            showPersistentOverlay(activity, message, "", null)
        }

        @JvmStatic
        fun showPersistentOverlay(activity: Activity, message: String, operationId: String?) {
            showPersistentOverlay(activity, message, "", operationId)
        }

        @JvmStatic
        fun showPersistentOverlay(
            activity: Activity,
            title: String,
            body: String,
            operationId: String?
        ) {
            getInstance().showPersistentOverlayInternal(activity, title, body, operationId)
        }

        @JvmStatic
        fun updatePersistentOverlay(message: String, operationId: String) {
            updatePersistentOverlay(message, "", operationId)
        }

        @JvmStatic
        fun updatePersistentOverlay(title: String, body: String, operationId: String) {
            getInstance().updatePersistentOverlayInternal(title, body, operationId)
        }

        @JvmStatic
        fun hidePersistentOverlay(operationId: String?): Boolean =
            getInstance().hidePersistentOverlayInternal(operationId)

        @JvmStatic
        fun hidePersistentOverlay() {
            getInstance().hideAllPersistentOverlaysInternal()
        }

        @JvmStatic
        fun hasPersistentToast(): Boolean = getInstance().hasPersistentToastInternal()

        @JvmStatic
        fun getPersistentToastText(): String? = getInstance().getPersistentToastTextInternal()

        @JvmStatic
        fun reattachToCurrentActivity(activity: Activity) {
            getInstance().reattachToCurrentActivityInternal(activity)
        }

        @JvmStatic
        fun ensureOverlayAttached(activity: Activity) {
            getInstance().ensureOverlayAttachedInternal(activity)
        }

        @JvmStatic
        fun addStateListener(listener: ToastStateListener) {
            getInstance().addStateListenerInternal(listener)
        }

        @JvmStatic
        fun removeStateListener(listener: ToastStateListener) {
            getInstance().removeStateListenerInternal(listener)
        }

        @JvmStatic
        fun refreshThemeColor() {
            getInstance().mMainHandler.post {
                getInstance().rebuildPersistentOverlaysForTheme()
            }
        }

        @JvmStatic
        fun shutdownGlobal() {
            sInstance?.shutdown()
        }
    }
}