// StorageObserver.kt
package com.ark.llama

import android.app.Activity
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.PlaylistEvent
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Observes MediaStore for storage changes and triggers a playlist
 * update on the detected change.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class StorageObserver(activity: Activity) :
    ContentObserver(Handler(Looper.getMainLooper())) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private var mActivityRef = WeakReference(activity)

    private val mContext: Context = activity.applicationContext

    private val mPlaylistManager = PlaylistManager.getInstance(mContext)

    private val mIsActive = AtomicBoolean(false)

    private val mHasShutDown = AtomicBoolean(false)

    private val mLastSyncTime = AtomicLong(0L)

    private val mMainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var mPendingUpdateRunnable: Runnable? = null

    private val mPendingUpdateLock = Any()

    // ========================================================================
    // Activity ref
    // ========================================================================

    fun setActivity(activity: Activity) {
        mActivityRef = WeakReference(activity)
        Log.d(TAG, "Activity reference updated")
    }

    // ========================================================================
    // ContentObserver override
    // ========================================================================

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        super.onChange(selfChange, uri)
        if (mIsActive.get()) handleChange(uri)
    }

    override fun onChange(selfChange: Boolean) {
        super.onChange(selfChange)
        if (mIsActive.get()) handleChange(null)
    }

    private fun handleChange(uri: Uri?) {
        uri ?: return
        val uriString = uri.toString()
        Log.d(TAG, "MediaStore changed: $uriString")
        if (!uriString.contains("/audio/")) return
        if (isUpdateInProgress()) { Log.d(TAG, "Update in progress, skipping"); return }
        val now = SystemClock.elapsedRealtime()
        val lastSync = mLastSyncTime.get()
        if (now - lastSync < SYNC_COOLDOWN_MS && lastSync > 0L) {
            Log.d(TAG, "Cooldown active - last sync was ${now - lastSync}ms ago, skipping")
            return
        }
        synchronized(mPendingUpdateLock) {
            mPendingUpdateRunnable?.let {
                mMainHandler.removeCallbacks(it)
                Log.d(TAG, "Cancelled previous pending update, resetting quiet period")
            }
            val runnable = object : Runnable {
                override fun run() {
                    synchronized(mPendingUpdateLock) { mPendingUpdateRunnable = null }
                    if (mIsActive.get() && !isUpdateInProgress()) performStorageUpdate()
                }
            }
            mPendingUpdateRunnable = runnable
            mMainHandler.postDelayed(runnable, QUIET_PERIOD_MS)
        }
        Log.d(TAG, "Quiet period started - sync scheduled in ${QUIET_PERIOD_MS}ms")
    }

    // ========================================================================
    // Storage update
    // ========================================================================

    private fun performStorageUpdate() {
        if (!mIsActive.get()) return
        Log.d(TAG, "Quiet period ended - triggering playlist update...")
        try {
            mPlaylistManager.updatePlaylistSilent()
            mLastSyncTime.set(SystemClock.elapsedRealtime())

            mMainHandler.postDelayed({
                if (!mIsActive.get()) return@postDelayed

                LlamaEventBus.post(PlaylistEvent.Refresh)

                mMainHandler.postDelayed({
                    if (!mIsActive.get()) return@postDelayed
                    LlamaEventBus.post(PlaylistEvent.TriggerGenreLoading(
                        mContext.getString(R.string.library_syncing_playlist)
                    ))
                }, GENRE_LOAD_DELAY_MS)

                val activity = mActivityRef.get()
                if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                    ToastManager.showToast(
                        activity,
                        activity.getString(R.string.library_playlist_updated),
                        ToastManager.LENGTH_NORMAL
                    )
                }
            }, OPERATION_END_DELAY_MS)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to perform storage update", e)
        }
    }

    private fun cancelPendingUpdate() {
        synchronized(mPendingUpdateLock) {
            mPendingUpdateRunnable?.let {
                mMainHandler.removeCallbacks(it)
                mPendingUpdateRunnable = null
                Log.d(TAG, "Cancelled pending update")
            }
        }
    }

    private fun isUpdateInProgress(): Boolean =
        NavigationController.getInstance().isGroupDisabled(
            NavigationController.ButtonGroup.FOLDER_ACTIONS
        )

    // ========================================================================
    // Lifecycle
    // ========================================================================

    fun startObserving() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot start observing - observer has been shut down"); return
        }
        if (!mIsActive.compareAndSet(false, true)) {
            Log.d(TAG, "Already observing, skipping"); return
        }
        try {
            mContext.contentResolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, this
            )
            Log.d(TAG, "Started observing storage changes")
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission denied for storage observer", e)
            mIsActive.set(false)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register observer", e)
            mIsActive.set(false)
        }
    }

    fun stopObserving() {
        mHasShutDown.set(true)
        cancelPendingUpdate()
        if (!mIsActive.compareAndSet(true, false)) {
            Log.d(TAG, "Not observing, skipping stop"); return
        }
        try {
            mContext.contentResolver.unregisterContentObserver(this)
            Log.d(TAG, "Stopped observing storage changes")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to unregister observer", e)
        }
    }

    fun forceUpdate() {
        if (mHasShutDown.get()) {
            Log.w(TAG, "Cannot force update - observer has been shut down"); return
        }
        cancelPendingUpdate()
        mLastSyncTime.set(0L)
        mMainHandler.post {
            if (!mIsActive.get() || isUpdateInProgress()) return@post
            Log.d(TAG, "Force update triggered")
            performStorageUpdate()
        }
    }

    fun getDebugInfo(): String {
        val builder = StringBuilder()
        builder.append("StorageObserver Debug Info:\n")
        builder.append("  Active: ${mIsActive.get()}\n")
        builder.append("  Shut down: ${mHasShutDown.get()}\n")
        builder.append("  Update in progress: ${isUpdateInProgress()}\n")
        builder.append("  Last sync time: ${mLastSyncTime.get()}\n")
        builder.append("  Time since last sync: " +
            "${SystemClock.elapsedRealtime() - mLastSyncTime.get()}ms\n")
        synchronized(mPendingUpdateLock) {
            builder.append("  Pending update: ${mPendingUpdateRunnable != null}\n")
        }
        return builder.toString()
    }

    companion object {
        private const val TAG = "StorageObserver"
        private const val SYNC_COOLDOWN_MS = 60_000L
        private const val QUIET_PERIOD_MS = 5_000L
        private const val GENRE_LOAD_DELAY_MS = 1_000L
        private const val OPERATION_END_DELAY_MS = 500L
    }
}