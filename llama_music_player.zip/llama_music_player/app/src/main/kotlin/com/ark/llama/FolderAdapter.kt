// FolderAdapter.kt
package com.ark.llama

import android.content.Context
import android.graphics.Color
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.List

/**
 * Renders the list of folders and the Loose Tracks entry in the
 * [FolderManager] RecyclerView.
 *
 * <p>Each row shows a themed folder icon, the folder's display name,
 * and a remove button. The Loose Tracks row is rendered the same
 * way, with its label resolved from
 * [R.plurals.folder_manager_loose_tracks] by the owning activity and
 * passed in as a plain string.</p>
 *
 * <h3>State Ownership</h3>
 * <p>Whether the remove button for a row is enabled is a function
 * of the [RemoveButtonStateSource] the adapter is constructed with.
 * The adapter does not decide the fact itself and does not cache
 * it: it queries the source on every bind. The activity changes the
 * answer by toggling the state its source returns, and calling
 * [refreshRemoveButtonStates] to redraw.</p>
 *
 * <h3>Row Click Handling</h3>
 * <p>Row taps do not open anything themselves. The remove button is
 * the only interactive element on the row; the row itself carries a
 * pressed highlight but no click handler. This matches the design:
 * the folder manager screen is a removal surface, not a folder
 * browser.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class FolderAdapter(
    private val context: Context,
    private val folders: MutableList<FolderItem>,
    private val removeListener: OnFolderRemoveListener,
    private val removeButtonStateSource: RemoveButtonStateSource
) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    private val themeHelper: ThemeHelper = ThemeHelper.getInstance(context)
    private val themeManager: ThemeManager = ThemeManager.getInstance(context)

    // ========================================================================
    // Listener interfaces
    // ========================================================================

    /**
     * The two removal surfaces the adapter exposes: a folder removal
     * carrying the folder's URI, and the Loose Tracks removal.
     */
    interface OnFolderRemoveListener {
        fun onFolderRemove(folderUriString: String, position: Int)
        fun onLooseTracksRemove()
    }

    /**
     * The row-level enable/disable source. The adapter queries this
     * on every bind; the answer flows straight into the remove
     * button's enabled state.
     */
    interface RemoveButtonStateSource {
        fun areRemoveButtonsEnabled(): Boolean
    }

    // ========================================================================
    // FolderItem
    // ========================================================================

    /**
     * One row of the folder list. Either an ordinary folder entry
     * (constructed with URI + name) or the Loose Tracks entry
     * (constructed with name + count).
     *
     * <p>The two constructors are mutually exclusive; a
     * [FolderItem] is one or the other, never both. The
     * [isLooseTracks] flag distinguishes the two cases at the
     * call sites that branch on it.</p>
     */
    class FolderItem {

        /** The folder's URI string, or [LOOSE_TRACKS_URI_STRING]. */
        @JvmField val uriString: String

        /** The display name for the row. */
        @JvmField val displayName: String

        /** True for the Loose Tracks row; false for an ordinary folder. */
        @JvmField val isLooseTracks: Boolean

        /** Loose track count for the Loose Tracks row; 0 for folders. */
        @JvmField val looseTracksCount: Int

        /** Constructs an ordinary folder entry. */
        constructor(uriString: String, displayName: String) {
            this.uriString = uriString
            this.displayName = displayName
            this.isLooseTracks = false
            this.looseTracksCount = 0
        }

        /** Constructs the Loose Tracks entry. */
        constructor(displayName: String, looseTracksCount: Int) {
            this.uriString = LOOSE_TRACKS_URI_STRING
            this.displayName = displayName
            this.isLooseTracks = true
            this.looseTracksCount = looseTracksCount
        }

        override fun toString(): String =
            "FolderItem{uriString='$uriString', displayName='$displayName', " +
                "isLooseTracks=$isLooseTracks, looseTracksCount=$looseTracksCount}"
    }

    // ========================================================================
    // ViewHolder
    // ========================================================================

    class FolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val folderIcon: TextView? = itemView.findViewById(R.id.folderIcon)
        val folderName: TextView? = itemView.findViewById(R.id.folderName)
        val removeButton: Button? = itemView.findViewById(R.id.removeButton)
    }

    // ========================================================================
    // Public methods
    // ========================================================================

    /**
     * Re-binds every row so each remove button reads the current
     * answer from [removeButtonStateSource].
     */
    fun refreshRemoveButtonStates() {
        notifyDataSetChanged()
    }

    /**
     * Replaces the adapter's list with a new one and rebinds every
     * row. Callers that hold the mutable list the adapter was
     * constructed with should prefer mutating it and calling
     * [removeItem] instead, so the RecyclerView animates the change
     * rather than doing a full rebind.
     */
    fun updateFolders(newFolders: List<FolderItem>) {
        folders.clear()
        folders.addAll(newFolders)
        notifyDataSetChanged()
    }

    /**
     * Removes the item at the given position and notifies the
     * RecyclerView with the standard remove-and-shift animation.
     */
    fun removeItem(position: Int) {
        if (position in folders.indices) {
            folders.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, folders.size - position)
        }
    }

    // ========================================================================
    // Adapter methods
    // ========================================================================

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderViewHolder {
        val view = LayoutInflater.from(context).inflate(
            R.layout.item_folder, parent, false
        )
        return FolderViewHolder(view)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        if (position !in folders.indices) return
        val folderItem = folders[position]

        val itemView = holder.itemView
        val removeButton = holder.removeButton

        holder.folderIcon?.let { icon ->
            icon.typeface = FontAwesome.getTypeface()
            icon.text = FontAwesome.FOLDER
            themeHelper.setThemeColor(themeManager.getCurrentColor())
            icon.setTextColor(themeHelper.getThemeColorInt())
        }

        holder.folderName?.let { name ->
            name.text = folderItem.displayName
            (name.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
                lp.marginStart = dpToPx(8)
                name.layoutParams = lp
            }
        }

        removeButton?.let { button ->
            configureRemoveButton(button, folderItem, holder)
            (button.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
                lp.marginStart = dpToPx(8)
                button.layoutParams = lp
            }
        }

        itemView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.setBackgroundColor(Color.TRANSPARENT)
            }
            false
        }
    }

    override fun getItemCount(): Int = folders.size

    // ========================================================================
    // Private helpers
    // ========================================================================

    private fun configureRemoveButton(
        removeButton: Button,
        folderItem: FolderItem,
        holder: FolderViewHolder
    ) {
        val enabled = removeButtonStateSource.areRemoveButtonsEnabled()
        removeButton.isEnabled = enabled

        themeHelper.setThemeColor(themeManager.getCurrentColor())
        themeHelper.updateButton(removeButton, enabled)

        animateButton(removeButton)

        if (enabled) {
            removeButton.setOnClickListener(createRemoveClickListener(folderItem, holder))
        } else {
            removeButton.setOnClickListener(null)
        }
    }

    private fun animateButton(button: Button) {
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
            }
            false
        }
    }

    private fun createRemoveClickListener(
        folderItem: FolderItem,
        holder: FolderViewHolder
    ): View.OnClickListener {
        return object : View.OnClickListener {
            private var lastClickTime = 0L

            override fun onClick(view: View) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return
                lastClickTime = now

                val position = holder.bindingAdapterPosition
                if (position == RecyclerView.NO_POSITION) return

                if (folderItem.isLooseTracks) {
                    removeListener.onLooseTracksRemove()
                } else {
                    removeListener.onFolderRemove(folderItem.uriString, position)
                }
            }
        }
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * context.resources.displayMetrics.density)

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val CLICK_DEBOUNCE_DELAY_MS = 250L
        private const val ANIMATION_DURATION_MS = 80
        private const val ANIMATION_SCALE_DOWN = 0.97f
        private const val ANIMATION_SCALE_NORMAL = 1.0f
        private const val TOUCH_HIGHLIGHT_COLOR = "#2A2A2A"
        private const val LOOSE_TRACKS_URI_STRING = "LOOSE_TRACKS"
    }
}