// PlaylistAdapter.kt
package com.ark.llama

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList
import java.util.HashMap
import java.util.HashSet
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Renders playlist rows and highlights the row that matches the
 * current song.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class PlaylistAdapter(
    private val mContext: Context,
    songs: List<Song>,
    @Volatile private var mListener: OnSongClickListener?
) : RecyclerView.Adapter<PlaylistAdapter.ViewHolder>() {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mSongs: CopyOnWriteArrayList<Song> = CopyOnWriteArrayList(songs)
    private val mThemeHelper: ThemeHelper = ThemeHelper.getInstance(mContext)
    private var mFavoriteListener: FavoriteListener? = null

    @Volatile
    private var mCurrentPlayingPath: String? = null

    @Volatile
    private var mIsGenreLoading: Boolean = false

    private val mPendingGenreUpdates = HashMap<String, String>()

    @Volatile
    private var mIsScrolling: Boolean = false

    init {
        setHasStableIds(true)
    }

    // ========================================================================
    // Listener interfaces
    // ========================================================================

    interface OnSongClickListener {
        fun onSongClick(position: Int, song: Song)
    }

    interface FavoriteListener {
        fun onFavoriteToggle(songPath: String, favorite: Boolean)
    }

    // ========================================================================
    // ViewHolder
    // ========================================================================

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val mContentLayout: LinearLayout = view.findViewById(R.id.contentLayout)
        val mTitle: TextView = view.findViewById(android.R.id.text1)
        val mSubtitle: TextView = view.findViewById(android.R.id.text2)
        val mFavoriteIcon: TextView = view.findViewById(R.id.favoriteIcon)
        val mDivider: View = view.findViewById(R.id.itemDivider)
    }

    // ========================================================================
    // DiffUtil callback
    // ========================================================================

    private class SongDiffCallback(
        private val oldList: List<Song>,
        private val newList: List<Song>
    ) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size
        override fun getNewListSize(): Int = newList.size
        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition].path == newList[newItemPosition].path

        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition].genre == newList[newItemPosition].genre

        override fun getChangePayload(oldItemPosition: Int, newItemPosition: Int): Any? {
            val oldGenre = oldList[oldItemPosition].genre
            val newGenre = newList[newItemPosition].genre
            return if (oldGenre != newGenre) PAYLOAD_GENRE else null
        }
    }

    // ========================================================================
    // Adapter methods
    // ========================================================================

    override fun getItemId(position: Int): Long {
        val song = mSongs.getOrNull(position) ?: return position.toLong()
        return song.path.hashCode().toLong()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext)
            .inflate(R.layout.item_song, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        onBindViewHolder(holder, position, mutableListOf())
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (position !in mSongs.indices) return
        val song = mSongs[position]
        val isGenreOnlyUpdate = payloads.contains(PAYLOAD_GENRE)

        if (!isGenreOnlyUpdate) {
            val title = song.title
            holder.mTitle.text = if (title.isNotEmpty())
                title else CharacterMapper.getUnknownTitle()

            val currentPath = mCurrentPlayingPath
            val isCurrent = currentPath != null && currentPath == song.path
            val themeColor = resolveThemeColor()

            if (isCurrent) {
                holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND))
                holder.mTitle.setTextColor(Color.parseColor(themeColor))
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
                holder.mDivider.visibility = View.GONE
            } else {
                holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT)
                holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
                holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK))
                holder.mDivider.visibility = View.VISIBLE
            }

            bindFavoriteIcon(holder, song, themeColor)
            bindRowTouch(holder, isCurrent)
            bindRowClick(holder)
        }

        val subtitle = StringBuilder()
        val artist = song.artist
        if (artist.isNotEmpty() && !CharacterMapper.isUnknownArtist(artist)) {
            subtitle.append(artist)
        } else {
            subtitle.append(CharacterMapper.getUnknownArtist())
        }

        val album = song.album
        if (album.isNotEmpty() && !CharacterMapper.isUnknownAlbum(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album)
        } else {
            subtitle.append(METADATA_SEPARATOR).append(CharacterMapper.getUnknownAlbum())
        }

        val genre = song.genre
        if (genre.isNotEmpty() && !CharacterMapper.isUnknownGenre(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre)
        } else {
            subtitle.append(METADATA_SEPARATOR).append(CharacterMapper.getUnknownGenre())
        }
        holder.mSubtitle.text = subtitle.toString()
    }

    override fun getItemCount(): Int = mSongs.size

    // ========================================================================
    // Public methods
    // ========================================================================

    fun updateList(newSongs: List<Song>) {
        updateList(newSongs, false)
    }

    fun updateList(newSongs: List<Song>, reorderOnly: Boolean) {
        val oldList = ArrayList<Song>(mSongs)
        val newList = ArrayList<Song>(newSongs)

        if (reorderOnly || shouldBulkReplace(oldList, newList)) {
            mSongs.clear()
            mSongs.addAll(newList)
            notifyDataSetChanged()
            return
        }

        val diff = DiffUtil.calculateDiff(SongDiffCallback(oldList, newList))
        mSongs.clear()
        mSongs.addAll(newList)
        diff.dispatchUpdatesTo(this)
    }

    fun setCurrentPlayingPath(songPath: String?) {
        val oldPath = mCurrentPlayingPath
        if (oldPath == songPath) return
        mCurrentPlayingPath = songPath

        oldPath?.let {
            val oldPosition = findPositionByPath(it)
            if (oldPosition in 0 until mSongs.size) notifyItemChanged(oldPosition)
        }
        songPath?.let {
            val newPosition = findPositionByPath(it)
            if (newPosition in 0 until mSongs.size) notifyItemChanged(newPosition)
        }
    }

    fun getCurrentPlayingPath(): String? = mCurrentPlayingPath

    fun getSongAt(position: Int): Song? =
        if (position in mSongs.indices) mSongs[position] else null

    fun setFavoriteListener(listener: FavoriteListener?) {
        mFavoriteListener = listener
    }

    fun setScrolling(scrolling: Boolean) {
        mIsScrolling = scrolling
        if (!scrolling && !mIsGenreLoading && mPendingGenreUpdates.isNotEmpty()) {
            Handler(Looper.getMainLooper()).postDelayed(
                { flushPendingGenreUpdates() }, SCROLL_SETTLE_MS
            )
        }
    }

    fun setGenreLoading(loading: Boolean) {
        mIsGenreLoading = loading
        if (!loading && !mIsScrolling) flushPendingGenreUpdates()
    }

    fun updateSongGenre(songPath: String, newGenre: String) {
        if (mIsGenreLoading || mIsScrolling) {
            mPendingGenreUpdates[songPath] = newGenre
        } else {
            applyGenreUpdate(songPath, newGenre, true)
        }
    }

    @Deprecated("Use setCurrentPlayingPath(String)", ReplaceWith("setCurrentPlayingPath(song.getPath())"))
    fun setCurrentPlayingIndex(index: Int) {
        if (index in mSongs.indices) {
            mSongs[index]?.let { setCurrentPlayingPath(it.path) }
        } else {
            setCurrentPlayingPath(null)
        }
    }

    @Deprecated("Use getCurrentPlayingPath()", ReplaceWith("getCurrentPlayingPath()"))
    fun getCurrentPlayingIndex(): Int {
        val path = mCurrentPlayingPath ?: return -1
        return findPositionByPath(path)
    }

    // ========================================================================
    // Binding helpers
    // ========================================================================

    private fun bindFavoriteIcon(holder: ViewHolder, song: Song, themeColor: String) {
        holder.mFavoriteIcon.typeface = FontAwesome.getTypeface()
        holder.mFavoriteIcon.text = FontAwesome.HEART
        holder.mFavoriteIcon.textSize = 20f

        if (song.isFavorite) {
            holder.mFavoriteIcon.setTextColor(Color.parseColor(themeColor))
        } else {
            holder.mFavoriteIcon.setTextColor(Color.parseColor(TEXT_COLOR_DARK))
        }

        holder.mFavoriteIcon.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
            }
            false
        }

        holder.mFavoriteIcon.setOnClickListener { _ ->
            val adapterPosition = holder.bindingAdapterPosition
            if (adapterPosition == RecyclerView.NO_POSITION ||
                adapterPosition >= mSongs.size
            ) return@setOnClickListener
            val tappedSong = mSongs[adapterPosition]
            val newValue = !tappedSong.isFavorite
            tappedSong.setFavorite(newValue)
            notifyItemChanged(adapterPosition)
            val listener = mFavoriteListener
            val path = tappedSong.path
            if (listener != null && path.isNotEmpty()) {
                listener.onFavoriteToggle(path, newValue)
            }
            if (mContext is android.app.Activity) {
                ToastManager.showToast(
                    mContext as android.app.Activity,
                    mContext.getString(
                        if (newValue) R.string.player_toast_favorite_on
                        else R.string.player_toast_favorite_off
                    ),
                    ToastManager.LENGTH_NORMAL
                )
            }
        }
    }

    private fun bindRowTouch(holder: ViewHolder, isCurrent: Boolean) {
        holder.mContentLayout.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    view.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isCurrent) {
                        view.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND))
                    } else {
                        view.setBackgroundColor(Color.TRANSPARENT)
                    }
                }
            }
            false
        }
    }

    private fun bindRowClick(holder: ViewHolder) {
        holder.mContentLayout.setOnClickListener(object : View.OnClickListener {
            private var lastClickTime = 0L

            override fun onClick(view: View) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) return
                lastClickTime = now

                val adapterPosition = holder.bindingAdapterPosition
                if (adapterPosition == RecyclerView.NO_POSITION ||
                    adapterPosition >= mSongs.size
                ) return

                val clickedSong = mSongs[adapterPosition]
                view.animate().scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong())
                    .withEndAction {
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS.toLong())
                            .start()
                    }
                    .start()

                mListener?.onSongClick(adapterPosition, clickedSong)
            }
        })
    }

    // ========================================================================
    // Genre queue
    // ========================================================================

    private fun flushPendingGenreUpdates() {
        if (mIsScrolling || mIsGenreLoading || mPendingGenreUpdates.isEmpty()) return
        for ((path, genre) in mPendingGenreUpdates) {
            applyGenreUpdate(path, genre, true)
        }
        mPendingGenreUpdates.clear()
    }

    private fun applyGenreUpdate(songPath: String, newGenre: String, notify: Boolean) {
        val position = findPositionByPath(songPath)
        if (position in 0 until mSongs.size) {
            val song = mSongs[position]
            if (song.genre != newGenre) {
                song.setGenre(newGenre)
                if (notify) notifyItemChanged(position, PAYLOAD_GENRE)
            }
        }
    }

    // ========================================================================
    // Helpers
    // ========================================================================

    private fun findPositionByPath(songPath: String?): Int {
        if (songPath == null) return -1
        for (index in mSongs.indices) {
            if (mSongs[index].path == songPath) return index
        }
        return -1
    }

    private fun resolveThemeColor(): String = try {
        ThemeManager.getInstance(mContext).getCurrentColor().takeIf { it.isNotEmpty() }
            ?: DEFAULT_THEME_COLOR
    } catch (exception: Exception) {
        DEFAULT_THEME_COLOR
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val ANIMATION_DURATION_MS = 80
        private const val ANIMATION_SCALE_DOWN = 0.97f
        private const val ANIMATION_SCALE_NORMAL = 1.0f
        private const val DEFAULT_THEME_COLOR = "#B8A86E"
        private const val CURRENT_SONG_BACKGROUND = "#1E1E1E"
        private const val TOUCH_HIGHLIGHT_COLOR = "#2A2A2A"
        private const val TEXT_COLOR_LIGHT = "#C0C0C0"
        private const val TEXT_COLOR_DARK = "#808080"
        private const val METADATA_SEPARATOR = " \u2022 "
        private const val CLICK_DEBOUNCE_DELAY_MS = 250L
        private const val PAYLOAD_GENRE = "genre_update"
        private const val SCROLL_SETTLE_MS = 100L

        private fun shouldBulkReplace(oldList: List<Song>, newList: List<Song>): Boolean {
            if (oldList.isEmpty() || newList.isEmpty()) return true
            if (Math.abs(oldList.size - newList.size) > oldList.size / 2) return true
            val newPaths = HashSet<String>(newList.size)
            for (song in newList) newPaths.add(song.path)
            var overlap = 0
            for (song in oldList) if (newPaths.contains(song.path)) overlap++
            return overlap < oldList.size / 2
        }
    }
}