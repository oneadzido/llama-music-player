// CharacterMapper.kt
package com.ark.llama

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import android.util.Log
import androidx.annotation.StringRes
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import java.io.File
import java.util.HashSet
import java.util.Locale
import java.util.regex.Pattern

/**
 * Provides static utilities for extracting, cleaning, and
 * canonicalizing music metadata.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
object CharacterMapper {

    private const val TAG = "CharacterMapper"

    private const val FALLBACK_UNKNOWN = "Unknown"
    private const val FALLBACK_UNKNOWN_TITLE = "Unknown Title"
    private const val FALLBACK_UNKNOWN_ARTIST = "Unknown Artist"
    private const val FALLBACK_UNKNOWN_ALBUM = "Unknown Album"
    private const val FALLBACK_UNKNOWN_GENRE = "Unknown Genre"

    private val CONTROL_CHARS: Pattern =
        Pattern.compile("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]")

    private val MULTIPLE_SPACES: Pattern = Pattern.compile("\\s+")

    private val PLACEHOLDER_VALUES: Array<String> = arrayOf(
        "<unknown>", "unknown", "?", "null", ""
    )

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var sRecognizedPlaceholders: Set<String> = emptySet()

    @JvmStatic
    fun init(context: Context) {
        val wasUninitialized = (appContext == null)
        appContext = context.applicationContext
        if (wasUninitialized) {
            rebuildRecognizedPlaceholders()
        }
    }

    private fun rebuildRecognizedPlaceholders() {
        val context = appContext ?: return

        val set = HashSet<String>()

        set.add(FALLBACK_UNKNOWN)
        set.add(FALLBACK_UNKNOWN_TITLE)
        set.add(FALLBACK_UNKNOWN_ARTIST)
        set.add(FALLBACK_UNKNOWN_ALBUM)
        set.add(FALLBACK_UNKNOWN_GENRE)

        try {
            val languageManager = LanguageManager.getInstance(context)
            val tags = languageManager.getLanguageTags()
            for (tag in tags) {
                try {
                    val locale = Locale.forLanguageTag(tag)
                    val configuration = Configuration(
                        context.resources.configuration
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        configuration.setLocales(LocaleList(locale))
                    } else {
                        @Suppress("DEPRECATION")
                        configuration.locale = locale
                    }
                    val localeContext =
                        context.createConfigurationContext(configuration)

                    set.add(localeContext.getString(R.string.common_unknown))
                    set.add(localeContext.getString(R.string.common_unknown_title))
                    set.add(localeContext.getString(R.string.common_unknown_artist))
                    set.add(localeContext.getString(R.string.common_unknown_album))
                    set.add(localeContext.getString(R.string.common_unknown_genre))
                } catch (exception: Exception) {
                    Log.w(
                        TAG,
                        "Failed to read placeholder for locale $tag",
                        exception
                    )
                }
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to enumerate supported locales", exception)
        }

        sRecognizedPlaceholders = set.toSet()
    }

    @JvmStatic
    fun getUnknownTitle(): String =
        getStringSafe(R.string.common_unknown_title, FALLBACK_UNKNOWN_TITLE)

    @JvmStatic
    fun getUnknownArtist(): String =
        getStringSafe(R.string.common_unknown_artist, FALLBACK_UNKNOWN_ARTIST)

    @JvmStatic
    fun getUnknownAlbum(): String =
        getStringSafe(R.string.common_unknown_album, FALLBACK_UNKNOWN_ALBUM)

    @JvmStatic
    fun getUnknownGenre(): String =
        getStringSafe(R.string.common_unknown_genre, FALLBACK_UNKNOWN_GENRE)

    @JvmStatic
    fun getUnknown(): String =
        getStringSafe(R.string.common_unknown, FALLBACK_UNKNOWN)

    private fun getStringSafe(@StringRes resId: Int, fallbackEnglish: String): String {
        val context = appContext
        if (context != null) {
            try {
                return LanguageManager.getInstance(context)
                    .getLocalizedContext()
                    .getString(resId)
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to resolve resource $resId", exception)
            }
        }
        return fallbackEnglish
    }

    @JvmStatic
    fun isUnknownTitle(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_TITLE)

    @JvmStatic
    fun isUnknownArtist(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_ARTIST)

    @JvmStatic
    fun isUnknownAlbum(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_ALBUM)

    @JvmStatic
    fun isUnknownGenre(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_GENRE)

    @JvmStatic
    fun isAnyUnknownPlaceholder(value: String?): Boolean {
        if (value == null || value.isEmpty()) {
            return true
        }
        return isUnknownTitle(value) ||
            isUnknownArtist(value) ||
            isUnknownAlbum(value) ||
            isUnknownGenre(value) ||
            getUnknown() == value ||
            FALLBACK_UNKNOWN == value
    }

    private fun matchesPlaceholder(value: String?, fallbackEnglish: String): Boolean {
        if (value == null || value.isEmpty()) {
            return true
        }
        if (fallbackEnglish == value) {
            return true
        }
        return sRecognizedPlaceholders.contains(value)
    }

    class ParseResult private constructor(
        @JvmField val status: Status,
        @JvmField val title: String,
        @JvmField val artist: String,
        @JvmField val album: String,
        @JvmField val genre: String
    ) {

        enum class Status {
            PARSED,
            FILE_UNREADABLE,
            PARSE_FAILED
        }

        fun isParsed(): Boolean = status == Status.PARSED
        fun hasRealGenre(): Boolean = !isUnknownGenre(genre)
        fun hasRealArtist(): Boolean = !isUnknownArtist(artist)
        fun hasRealAlbum(): Boolean = !isUnknownAlbum(album)

        companion object {
            @JvmSynthetic
            internal fun of(
                status: Status,
                title: String,
                artist: String,
                album: String,
                genre: String
            ): ParseResult = ParseResult(status, title, artist, album, genre)
        }
    }

    @JvmStatic
    fun getSongFromFile(filePath: String): Song? {
        if (filePath.isEmpty()) return null
        val context = appContext ?: return null

        val cachedSong = SongDatabase.getInstance(context).getSong(filePath)
        if (cachedSong != null &&
            cachedSong.title.isNotEmpty() &&
            !isUnknownTitle(cachedSong.title)
        ) {
            return cachedSong
        }

        val result = parseSongInfo(filePath)
        if (result.status != ParseResult.Status.PARSED) {
            return null
        }

        val song = Song(
            result.title,
            result.artist,
            result.album,
            result.genre,
            filePath,
            0L,
            null
        )
        SongDatabase.getInstance(context).insertSong(song)
        return song
    }

    @JvmStatic
    fun getTitle(filePath: String): String {
        if (filePath.isEmpty()) return ""
        val context = appContext ?: return ""

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.title.isNotEmpty()) {
            return song.title
        }
        return parseSongInfo(filePath).title
    }

    @JvmStatic
    fun getArtist(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownArtist()
        val context = appContext ?: return getUnknownArtist()

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.artist.isNotEmpty()) {
            return song.artist
        }
        return parseSongInfo(filePath).artist
    }

    @JvmStatic
    fun getAlbum(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownAlbum()
        val context = appContext ?: return getUnknownAlbum()

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.album.isNotEmpty()) {
            return song.album
        }
        return parseSongInfo(filePath).album
    }

    @JvmStatic
    fun getGenre(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownGenre()
        val context = appContext ?: return getUnknownGenre()

        val result = parseSongInfo(filePath)
        if (!result.hasRealGenre()) {
            return getUnknownGenre()
        }

        val genre = result.genre
        val database = SongDatabase.getInstance(context)

        val existingSong = database.getSong(filePath)
        if (existingSong != null && genre != existingSong.genre) {
            val updatedSong = Song(
                existingSong.title,
                existingSong.artist,
                existingSong.album,
                genre,
                existingSong.path,
                existingSong.duration,
                existingSong.uri
            )
            database.insertSong(updatedSong)
            Log.d(TAG, "Updated genre in database: " +
                "${existingSong.title} -> $genre")
        }

        val looseSongs = database.getLooseSongs()
        for (looseSong in looseSongs) {
            if (looseSong != null && filePath == looseSong.path) {
                val updatedLooseSong = Song(
                    looseSong.title,
                    looseSong.artist,
                    looseSong.album,
                    genre,
                    looseSong.path,
                    looseSong.duration,
                    null
                )
                database.insertLooseSong(updatedLooseSong)
                break
            }
        }

        return genre
    }

    @JvmStatic
    internal fun parseSongInfo(filePath: String): ParseResult {
        if (filePath.isEmpty()) {
            return ParseResult.of(
                ParseResult.Status.FILE_UNREADABLE,
                "",
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        val file = File(filePath)
        if (!file.exists() || !file.canRead()) {
            val fallbackTitle = getFileNameWithoutExtension(file.name)
            return ParseResult.of(
                ParseResult.Status.FILE_UNREADABLE,
                clean(fallbackTitle),
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        var rawTitle: String? = null
        var rawArtist: String? = null
        var rawAlbum: String? = null
        var rawGenre: String? = null

        try {
            val audioFile = AudioFileIO.read(file)
            val tag = audioFile?.tag
            if (tag != null) {
                rawTitle = tag.getFirst(FieldKey.TITLE)
                rawArtist = tag.getFirst(FieldKey.ARTIST)
                rawAlbum = tag.getFirst(FieldKey.ALBUM)
                rawGenre = tag.getFirst(FieldKey.GENRE)
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to parse metadata for: $filePath", exception)
            val fallbackTitle = getFileNameWithoutExtension(file.name)
            return ParseResult.of(
                ParseResult.Status.PARSE_FAILED,
                clean(fallbackTitle),
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        val title = canonicalizeTitle(rawTitle, file)
        val artist = canonicalizeArtist(rawArtist)
        val album = canonicalizeAlbum(rawAlbum)
        val genre = canonicalizeGenre(rawGenre)

        return ParseResult.of(
            ParseResult.Status.PARSED,
            title,
            artist,
            album,
            genre
        )
    }

    private fun canonicalizeTitle(rawTitle: String?, file: File): String {
        val cleaned = cleanMusicMetadata(rawTitle)
        if (cleaned != null) return cleaned
        val fallbackTitle = getFileNameWithoutExtension(file.name)
        val cleanedFallback = clean(fallbackTitle)
        return if (cleanedFallback.isEmpty()) getUnknownTitle() else cleanedFallback
    }

    private fun canonicalizeArtist(rawArtist: String?): String {
        val cleaned = cleanMusicMetadata(rawArtist)
        return cleaned ?: getUnknownArtist()
    }

    private fun canonicalizeAlbum(rawAlbum: String?): String {
        val cleaned = cleanMusicMetadata(rawAlbum)
        return cleaned ?: getUnknownAlbum()
    }

    private fun canonicalizeGenre(rawGenre: String?): String {
        val cleaned = cleanMusicMetadata(rawGenre)
        return cleaned ?: getUnknownGenre()
    }

    private fun getFileNameWithoutExtension(fileName: String): String {
        val dotIndex = fileName.lastIndexOf(".")
        return if (dotIndex > 0) fileName.substring(0, dotIndex) else fileName
    }

    private fun isPlaceholder(input: String?): Boolean {
        if (input.isNullOrEmpty()) return false
        val trimmed = input.trim()
        for (placeholder in PLACEHOLDER_VALUES) {
            if (trimmed.equals(placeholder, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun clean(input: String?): String {
        if (input.isNullOrEmpty()) {
            return input ?: ""
        }
        return try {
            var result = decodeHtmlEntities(input)
            result = CONTROL_CHARS.matcher(result).replaceAll("")
            result = result
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .replace("\u00A0", " ")
            result = MULTIPLE_SPACES.matcher(result).replaceAll(" ")
            result.trim()
        } catch (exception: Exception) {
            Log.w(TAG, "Error cleaning string", exception)
            input
        }
    }

    @JvmStatic
    fun cleanString(input: String?): String = clean(input)

    @JvmStatic
    fun cleanMusicMetadata(input: String?): String? {
        if (input.isNullOrEmpty()) return null

        val trimmed = input.trim()
        if (isPlaceholder(trimmed)) return null

        val cleaned = clean(trimmed)
        if (cleaned.isEmpty()) return null
        if (isPlaceholder(cleaned)) return null

        return cleaned
    }

    @JvmStatic
    fun formatForDisplay(input: String?, maxLength: Int): String {
        if (input.isNullOrEmpty()) return ""
        if (input.length <= maxLength) return input
        if (maxLength < 4) return input.substring(0, maxLength)
        return input.substring(0, maxLength - 3) + "..."
    }

    @JvmStatic
    fun displayFileName(originalName: String?): String {
        val cleaned = cleanMusicMetadata(originalName)
        return if (cleaned.isNullOrEmpty()) getUnknown() else cleaned
    }

    @JvmStatic
    fun cleanForPath(input: String?): String = input ?: ""

    @JvmStatic
    fun cleanForSearch(input: String?): String {
        if (input == null) return ""
        return clean(input).lowercase()
    }

    @JvmStatic
    fun decodeHtmlEntities(input: String?): String {
        if (input.isNullOrEmpty()) return input ?: ""

        val result = StringBuilder(input)
        replaceAll(result, "&amp;", "&")
        replaceAll(result, "&lt;", "<")
        replaceAll(result, "&gt;", ">")
        replaceAll(result, "&quot;", "\"")
        replaceAll(result, "&apos;", "'")
        replaceAll(result, "&#39;", "'")
        replaceAll(result, "&#34;", "\"")
        replaceAll(result, "&#38;", "&")
        replaceAll(result, "&#60;", "<")
        replaceAll(result, "&#62;", ">")
        replaceAll(result, "&nbsp;", " ")
        replaceAll(result, "&#160;", " ")
        replaceAll(result, "&ndash;", "\u2013")
        replaceAll(result, "&mdash;", "\u2014")
        replaceAll(result, "&lsquo;", "'")
        replaceAll(result, "&rsquo;", "'")
        replaceAll(result, "&ldquo;", "\"")
        replaceAll(result, "&rdquo;", "\"")
        replaceAll(result, "&hellip;", "\u2026")
        replaceAll(result, "&#8230;", "\u2026")
        return result.toString()
    }

    private fun replaceAll(builder: StringBuilder, target: String, replacement: String) {
        var index = builder.indexOf(target)
        while (index != -1) {
            builder.replace(index, index + target.length, replacement)
            index = builder.indexOf(target, index + replacement.length)
        }
    }

    @JvmStatic
    fun hasProblematicCharacters(input: String?): Boolean {
        if (input.isNullOrEmpty()) return false
        for (character in input) {
            if (character > '\u007F') return true
        }
        return false
    }

    @JvmStatic
    fun isCached(filePath: String): Boolean {
        if (filePath.isEmpty()) return false
        val context = appContext ?: return false
        return SongDatabase.getInstance(context).hasSong(filePath)
    }
}