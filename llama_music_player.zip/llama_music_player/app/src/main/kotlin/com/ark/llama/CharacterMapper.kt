// CharacterMapper.kt
package com.ark.llama

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import android.util.Log
import androidx.annotation.StringRes
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import java.io.File
import java.util.Collections
import java.util.HashSet
import java.util.Locale
import java.util.Set
import java.util.regex.Pattern

/**
 * Provides static utilities for extracting, cleaning, and
 * canonicalizing music metadata.
 *
 * <p>Reads ID3 tags from audio files, cleans strings by removing
 * control characters and decoding HTML entities, replaces
 * placeholder values such as `"<unknown>"` with canonical values,
 * and caches the parsed result in the song database.</p>
 *
 * <h3>The Unknown Placeholders</h3>
 * <p>When a tag is absent, unreadable, or carries a recognised
 * placeholder value, the parser produces a canonical value in the
 * app's current language. The value is resolved from a string
 * resource at the moment it is needed. There is one owner for each
 * placeholder's text — the resource — and one owner for the
 * parser's use of it — this class.</p>
 *
 * <p>The four placeholder producers are [getUnknownTitle],
 * [getUnknownArtist], [getUnknownAlbum], [getUnknownGenre]. The
 * four placeholder predicates are [isUnknownTitle],
 * [isUnknownArtist], [isUnknownAlbum], [isUnknownGenre]. Every
 * caller that produces a placeholder uses a producer; every caller
 * that decides whether a value is a placeholder uses a predicate.
 * No caller compares a user-visible string against a literal.</p>
 *
 * <h3>The Recognized Placeholder Set</h3>
 * <p>The predicate methods recognize a placeholder value regardless
 * of which locale wrote it. A song cached in the database under
 * German — the title field holds "Unbekannter Titel" — is still
 * recognized as a placeholder after the app switches to French. The
 * recognition is performed against a cached set of every supported
 * locale's placeholder values, built once at [init].</p>
 *
 * <h3>Producer Context</h3>
 * <p>The producers read through
 * [LanguageManager.getLocalizedContext] rather than through the raw
 * application context. The application context resolves against the
 * system locale; the localized context resolves against the app's
 * selected one.</p>
 *
 * <h3>Result Contract</h3>
 * <p>Every parse produces a [ParseResult] whose [ParseResult.status]
 * is the exhaustive answer to "what happened". Callers branch on the
 * status, not on the presence or emptiness of any field.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. Compiled patterns are
 * immutable and reused across calls. [getStringSafe] falls back to
 * the English base value when [init] has not yet been called.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
object CharacterMapper {

    // ========================================================================
    // Constants
    // ========================================================================

    private const val TAG = "CharacterMapper"

    private const val FALLBACK_UNKNOWN = "Unknown"
    private const val FALLBACK_UNKNOWN_TITLE = "Unknown Title"
    private const val FALLBACK_UNKNOWN_ARTIST = "Unknown Artist"
    private const val FALLBACK_UNKNOWN_ALBUM = "Unknown Album"
    private const val FALLBACK_UNKNOWN_GENRE = "Unknown Genre"

    /** Pattern matching control characters (ASCII 0-31 except tab, newline, CR). */
    private val CONTROL_CHARS: Pattern =
        Pattern.compile("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]")

    /** Pattern collapsing runs of whitespace into a single space. */
    private val MULTIPLE_SPACES: Pattern = Pattern.compile("\\s+")

    /** Placeholder values that indicate missing metadata. */
    private val PLACEHOLDER_VALUES: Array<String> = arrayOf(
        "<unknown>", "unknown", "?", "null", ""
    )

    // ========================================================================
    // State
    // ========================================================================

    /** Application context used for database access and resource lookup. */
    @Volatile
    private var appContext: Context? = null

    /**
     * Every value this app recognizes as an unknown placeholder, in
     * every supported locale. Built once by
     * [rebuildRecognizedPlaceholders] on the first call to [init].
     * Read-only afterwards.
     */
    @Volatile
    private var sRecognizedPlaceholders: Set<String> = Collections.emptySet()

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Stores the application context and builds the recognized-
     * placeholder set on the first call.
     *
     * <p>Call before using any method that requires database access
     * or that produces a placeholder value. In normal operation this
     * is called from [LlamaMusicPlayer.onCreate].</p>
     *
     * <p>The recognized-placeholder set is built once per process. A
     * second call replaces the application context but does not
     * rebuild the set, because the set depends only on the
     * supported-language list, which is a build-time constant.</p>
     *
     * @param context A context; the application context is retained
     */
    @JvmStatic
    fun init(context: Context) {
        val wasUninitialized = (appContext == null)
        appContext = context.applicationContext
        if (wasUninitialized) {
            rebuildRecognizedPlaceholders()
        }
    }

    /**
     * Reads every supported locale's placeholder values and caches
     * them in a single set.
     *
     * <p>Called once from [init]. Uses
     * [LanguageManager.getLanguageTags] to enumerate the supported
     * languages, and for each language builds a configuration
     * context whose resources resolve against that language.</p>
     *
     * <p>Failures are logged and skipped: a locale whose resources
     * cannot be read does not prevent the rest of the set from
     * being built.</p>
     */
    private fun rebuildRecognizedPlaceholders() {
        val context = appContext ?: return

        val set = HashSet<String>()

        // The English base values, always recognized.
        set.add(FALLBACK_UNKNOWN)
        set.add(FALLBACK_UNKNOWN_TITLE)
        set.add(FALLBACK_UNKNOWN_ARTIST)
        set.add(FALLBACK_UNKNOWN_ALBUM)
        set.add(FALLBACK_UNKNOWN_GENRE)

        // Every supported locale's values.
        try {
            val languageManager = LanguageManager.getInstance(context)
            val tags = languageManager.languageTags
            for (tag in tags) {
                try {
                    val locale = Locale.forLanguageTag(tag)
                    val configuration = Configuration(
                        context.resources.configuration
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        configuration.setLocales(LocaleList(locale))
                    } else {
                        @Suppress("DEPRECATION")
                        configuration.locale = locale
                    }
                    val localeContext =
                        context.createConfigurationContext(configuration)

                    set.add(localeContext.getString(R.string.common_unknown))
                    set.add(localeContext.getString(R.string.common_unknown_title))
                    set.add(localeContext.getString(R.string.common_unknown_artist))
                    set.add(localeContext.getString(R.string.common_unknown_album))
                    set.add(localeContext.getString(R.string.common_unknown_genre))
                } catch (exception: Exception) {
                    Log.w(
                        TAG,
                        "Failed to read placeholder for locale $tag",
                        exception
                    )
                }
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to enumerate supported locales", exception)
        }

        sRecognizedPlaceholders = Collections.unmodifiableSet(set)
    }

    // ========================================================================
    // Placeholder Producers
    // ========================================================================

    /**
     * Returns the app's current "unknown title" placeholder.
     *
     * @return The placeholder string; never null and never empty
     */
    @JvmStatic
    fun getUnknownTitle(): String =
        getStringSafe(R.string.common_unknown_title, FALLBACK_UNKNOWN_TITLE)

    /**
     * Returns the app's current "unknown artist" placeholder.
     *
     * @return The placeholder string; never null and never empty
     */
    @JvmStatic
    fun getUnknownArtist(): String =
        getStringSafe(R.string.common_unknown_artist, FALLBACK_UNKNOWN_ARTIST)

    /**
     * Returns the app's current "unknown album" placeholder.
     *
     * @return The placeholder string; never null and never empty
     */
    @JvmStatic
    fun getUnknownAlbum(): String =
        getStringSafe(R.string.common_unknown_album, FALLBACK_UNKNOWN_ALBUM)

    /**
     * Returns the app's current "unknown genre" placeholder.
     *
     * @return The placeholder string; never null and never empty
     */
    @JvmStatic
    fun getUnknownGenre(): String =
        getStringSafe(R.string.common_unknown_genre, FALLBACK_UNKNOWN_GENRE)

    /**
     * Returns the app's current bare "unknown" placeholder.
     *
     * @return The placeholder string; never null and never empty
     */
    @JvmStatic
    fun getUnknown(): String =
        getStringSafe(R.string.common_unknown, FALLBACK_UNKNOWN)

    /**
     * Returns the given resource identifier's value in the app's
     * selected language, or the English fallback when the context
     * has not yet been initialised.
     *
     * @param resId Resource identifier to resolve
     * @param fallbackEnglish English base value to use before init
     * @return The resolved string; never null
     */
    private fun getStringSafe(@StringRes resId: Int, fallbackEnglish: String): String {
        val context = appContext
        if (context != null) {
            try {
                return LanguageManager.getInstance(context)
                    .localizedContext
                    .getString(resId)
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to resolve resource $resId", exception)
            }
        }
        return fallbackEnglish
    }

    // ========================================================================
    // Placeholder Predicates
    // ========================================================================

    /**
     * Returns whether the given value is the "unknown title" placeholder.
     *
     * @param value Value to test, or null
     * @return True when the value is the unknown-title placeholder
     */
    @JvmStatic
    fun isUnknownTitle(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_TITLE)

    /**
     * Returns whether the given value is the "unknown artist" placeholder.
     *
     * @param value Value to test, or null
     * @return True when the value is the unknown-artist placeholder
     */
    @JvmStatic
    fun isUnknownArtist(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_ARTIST)

    /**
     * Returns whether the given value is the "unknown album" placeholder.
     *
     * @param value Value to test, or null
     * @return True when the value is the unknown-album placeholder
     */
    @JvmStatic
    fun isUnknownAlbum(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_ALBUM)

    /**
     * Returns whether the given value is the "unknown genre" placeholder.
     *
     * @param value Value to test, or null
     * @return True when the value is the unknown-genre placeholder
     */
    @JvmStatic
    fun isUnknownGenre(value: String?): Boolean =
        matchesPlaceholder(value, FALLBACK_UNKNOWN_GENRE)

    /**
     * Returns whether the given value equals any of the four
     * "unknown" placeholders in any of the app's supported languages.
     *
     * @param value Value to test, or null
     * @return True when the value is any of the unknown placeholders
     */
    @JvmStatic
    fun isAnyUnknownPlaceholder(value: String?): Boolean {
        if (value == null || value.isEmpty()) {
            return true
        }
        return isUnknownTitle(value) ||
            isUnknownArtist(value) ||
            isUnknownAlbum(value) ||
            isUnknownGenre(value) ||
            getUnknown() == value ||
            FALLBACK_UNKNOWN == value
    }

    /**
     * Returns whether the given value matches the recognized-
     * placeholder set, the English base value for the kind, or the
     * empty string.
     *
     * @param value Value to test, or null
     * @param fallbackEnglish English base value for the kind
     * @return True when the value is a recognized placeholder
     */
    private fun matchesPlaceholder(value: String?, fallbackEnglish: String): Boolean {
        if (value == null || value.isEmpty()) {
            return true
        }
        if (fallbackEnglish == value) {
            return true
        }
        return sRecognizedPlaceholders.contains(value)
    }

    // ========================================================================
    // ParseResult
    // ========================================================================

    /**
     * Immutable result of parsing a file's metadata.
     *
     * <p>All string fields are non-null. A field whose tag was absent
     * carries the app's current placeholder for its kind — the artist
     * carries [getUnknownArtist], the album carries
     * [getUnknownAlbum], the genre carries [getUnknownGenre] —
     * except the title, which always carries at least the
     * filename-derived value.</p>
     *
     * <p>The [status] field distinguishes the three outcomes the
     * parser produces.</p>
     */
    class ParseResult private constructor(
        @JvmField val status: Status,
        @JvmField val title: String,
        @JvmField val artist: String,
        @JvmField val album: String,
        @JvmField val genre: String
    ) {

        /** Exhaustive outcomes of a file parse. */
        enum class Status {
            /** The file was read and jaudiotagger extracted whatever tags it found. */
            PARSED,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        /** Returns whether the file was read successfully. */
        fun isParsed(): Boolean = status == Status.PARSED

        /** Returns whether the genre came from an actual tag. */
        fun hasRealGenre(): Boolean = !isUnknownGenre(genre)

        /** Returns whether the artist came from an actual tag. */
        fun hasRealArtist(): Boolean = !isUnknownArtist(artist)

        /** Returns whether the album came from an actual tag. */
        fun hasRealAlbum(): Boolean = !isUnknownAlbum(album)

        // Companion access for the private constructor.
        companion object {
            @JvmSynthetic
            internal fun of(
                status: Status,
                title: String,
                artist: String,
                album: String,
                genre: String
            ): ParseResult = ParseResult(status, title, artist, album, genre)
        }
    }

    // ========================================================================
    // Song Retrieval Methods
    // ========================================================================

    /**
     * Returns the song for the given file path, using the database
     * cache when a cached entry with a usable title is present.
     *
     * <p>When no cached entry is usable, the file is parsed and the
     * result is inserted into the database if the parse succeeded.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The song, or null if the file cannot be read
     */
    @JvmStatic
    fun getSongFromFile(filePath: String): Song? {
        if (filePath.isEmpty()) return null
        val context = appContext ?: return null

        val cachedSong = SongDatabase.getInstance(context).getSong(filePath)
        if (cachedSong != null &&
            cachedSong.title.isNotEmpty() &&
            !isUnknownTitle(cachedSong.title)
        ) {
            return cachedSong
        }

        val result = parseSongInfo(filePath)
        if (result.status != ParseResult.Status.PARSED) {
            return null
        }

        val song = Song(
            result.title,
            result.artist,
            result.album,
            result.genre,
            filePath,
            0L,
            null
        )
        SongDatabase.getInstance(context).insertSong(song)
        return song
    }

    /**
     * Returns the title of the song at the given file path.
     *
     * @param filePath Absolute path to the music file
     * @return The song title, or an empty string when unavailable
     */
    @JvmStatic
    fun getTitle(filePath: String): String {
        if (filePath.isEmpty()) return ""
        val context = appContext ?: return ""

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.title.isNotEmpty()) {
            return song.title
        }
        return parseSongInfo(filePath).title
    }

    /**
     * Returns the artist of the song at the given file path.
     *
     * @param filePath Absolute path to the music file
     * @return The artist name, or the unknown-artist placeholder
     *         when unavailable
     */
    @JvmStatic
    fun getArtist(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownArtist()
        val context = appContext ?: return getUnknownArtist()

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.artist.isNotEmpty()) {
            return song.artist
        }
        return parseSongInfo(filePath).artist
    }

    /**
     * Returns the album of the song at the given file path.
     *
     * @param filePath Absolute path to the music file
     * @return The album name, or the unknown-album placeholder when
     *         unavailable
     */
    @JvmStatic
    fun getAlbum(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownAlbum()
        val context = appContext ?: return getUnknownAlbum()

        val song = SongDatabase.getInstance(context).getSong(filePath)
        if (song != null && song.album.isNotEmpty()) {
            return song.album
        }
        return parseSongInfo(filePath).album
    }

    /**
     * Returns the genre of the song at the given file path.
     *
     * <p>Reads the genre tag directly from the file, updates the
     * database entry for the song when the tag value differs from
     * the cached value, and returns the tag value. Returns the app's
     * unknown-genre placeholder when the tag is absent or carries a
     * placeholder value.</p>
     *
     * @param filePath Absolute path to the music file
     * @return The genre, or the unknown-genre placeholder when
     *         unavailable
     */
    @JvmStatic
    fun getGenre(filePath: String): String {
        if (filePath.isEmpty()) return getUnknownGenre()
        val context = appContext ?: return getUnknownGenre()

        val result = parseSongInfo(filePath)
        if (!result.hasRealGenre()) {
            return getUnknownGenre()
        }

        val genre = result.genre
        val database = SongDatabase.getInstance(context)

        val existingSong = database.getSong(filePath)
        if (existingSong != null && genre != existingSong.genre) {
            val updatedSong = Song(
                existingSong.title,
                existingSong.artist,
                existingSong.album,
                genre,
                existingSong.path,
                existingSong.duration,
                existingSong.uri
            )
            database.insertSong(updatedSong)
            Log.d(TAG, "Updated genre in database: " +
                "${existingSong.title} -> $genre")
        }

        val looseSongs = database.looseSongs
        for (looseSong in looseSongs) {
            if (looseSong != null && filePath == looseSong.path) {
                val updatedLooseSong = Song(
                    looseSong.title,
                    looseSong.artist,
                    looseSong.album,
                    genre,
                    looseSong.path,
                    looseSong.duration,
                    null
                )
                database.insertLooseSong(updatedLooseSong)
                break
            }
        }

        return genre
    }

    // ========================================================================
    // File Parsing
    // ========================================================================

    /**
     * Parses the metadata of the audio file at the given path.
     *
     * @param filePath Absolute path to the music file
     * @return The parsed metadata and the outcome of the parse
     */
    @JvmStatic
    internal fun parseSongInfo(filePath: String): ParseResult {
        if (filePath.isEmpty()) {
            return ParseResult.of(
                ParseResult.Status.FILE_UNREADABLE,
                "",
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        val file = File(filePath)
        if (!file.exists() || !file.canRead()) {
            val fallbackTitle = getFileNameWithoutExtension(file.name)
            return ParseResult.of(
                ParseResult.Status.FILE_UNREADABLE,
                clean(fallbackTitle),
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        var rawTitle: String? = null
        var rawArtist: String? = null
        var rawAlbum: String? = null
        var rawGenre: String? = null

        try {
            val audioFile = AudioFileIO.read(file)
            val tag = audioFile?.tag
            if (tag != null) {
                rawTitle = tag.getFirst(FieldKey.TITLE)
                rawArtist = tag.getFirst(FieldKey.ARTIST)
                rawAlbum = tag.getFirst(FieldKey.ALBUM)
                rawGenre = tag.getFirst(FieldKey.GENRE)
            }
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to parse metadata for: $filePath", exception)
            val fallbackTitle = getFileNameWithoutExtension(file.name)
            return ParseResult.of(
                ParseResult.Status.PARSE_FAILED,
                clean(fallbackTitle),
                getUnknownArtist(),
                getUnknownAlbum(),
                getUnknownGenre()
            )
        }

        val title = canonicalizeTitle(rawTitle, file)
        val artist = canonicalizeArtist(rawArtist)
        val album = canonicalizeAlbum(rawAlbum)
        val genre = canonicalizeGenre(rawGenre)

        return ParseResult.of(
            ParseResult.Status.PARSED,
            title,
            artist,
            album,
            genre
        )
    }

    private fun canonicalizeTitle(rawTitle: String?, file: File): String {
        val cleaned = cleanMusicMetadata(rawTitle)
        if (cleaned != null) return cleaned
        val fallbackTitle = getFileNameWithoutExtension(file.name)
        val cleanedFallback = clean(fallbackTitle)
        return if (cleanedFallback.isEmpty()) getUnknownTitle() else cleanedFallback
    }

    private fun canonicalizeArtist(rawArtist: String?): String {
        val cleaned = cleanMusicMetadata(rawArtist)
        return cleaned ?: getUnknownArtist()
    }

    private fun canonicalizeAlbum(rawAlbum: String?): String {
        val cleaned = cleanMusicMetadata(rawAlbum)
        return cleaned ?: getUnknownAlbum()
    }

    private fun canonicalizeGenre(rawGenre: String?): String {
        val cleaned = cleanMusicMetadata(rawGenre)
        return cleaned ?: getUnknownGenre()
    }

    private fun getFileNameWithoutExtension(fileName: String): String {
        val dotIndex = fileName.lastIndexOf(".")
        return if (dotIndex > 0) fileName.substring(0, dotIndex) else fileName
    }

    // ========================================================================
    // String Cleaning
    // ========================================================================

    private fun isPlaceholder(input: String?): Boolean {
        if (input.isNullOrEmpty()) return false
        val trimmed = input.trim()
        for (placeholder in PLACEHOLDER_VALUES) {
            if (trimmed.equals(placeholder, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun clean(input: String?): String {
        if (input.isNullOrEmpty()) {
            return input ?: ""
        }
        return try {
            var result = decodeHtmlEntities(input)
            result = CONTROL_CHARS.matcher(result).replaceAll("")
            result = result
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .replace("\u00A0", " ")
            result = MULTIPLE_SPACES.matcher(result).replaceAll(" ")
            result.trim()
        } catch (exception: Exception) {
            Log.w(TAG, "Error cleaning string", exception)
            input
        }
    }

    @JvmStatic
    fun cleanString(input: String?): String = clean(input)

    @JvmStatic
    fun cleanMusicMetadata(input: String?): String? {
        if (input.isNullOrEmpty()) return null

        val trimmed = input.trim()
        if (isPlaceholder(trimmed)) return null

        val cleaned = clean(trimmed)
        if (cleaned.isEmpty()) return null
        if (isPlaceholder(cleaned)) return null

        return cleaned
    }

    @JvmStatic
    fun formatForDisplay(input: String?, maxLength: Int): String {
        if (input.isNullOrEmpty()) return ""
        if (input.length <= maxLength) return input
        if (maxLength < 4) return input.substring(0, maxLength)
        return input.substring(0, maxLength - 3) + "..."
    }

    @JvmStatic
    fun displayFileName(originalName: String?): String {
        val cleaned = cleanMusicMetadata(originalName)
        return if (cleaned.isNullOrEmpty()) getUnknown() else cleaned
    }

    @JvmStatic
    fun cleanForPath(input: String?): String = input ?: ""

    @JvmStatic
    fun cleanForSearch(input: String?): String {
        if (input == null) return ""
        return clean(input).lowercase()
    }

    @JvmStatic
    fun decodeHtmlEntities(input: String?): String {
        if (input.isNullOrEmpty()) return input ?: ""

        val result = StringBuilder(input)
        replaceAll(result, "&amp;", "&")
        replaceAll(result, "&lt;", "<")
        replaceAll(result, "&gt;", ">")
        replaceAll(result, "&quot;", "\"")
        replaceAll(result, "&apos;", "'")
        replaceAll(result, "&#39;", "'")
        replaceAll(result, "&#34;", "\"")
        replaceAll(result, "&#38;", "&")
        replaceAll(result, "&#60;", "<")
        replaceAll(result, "&#62;", ">")
        replaceAll(result, "&nbsp;", " ")
        replaceAll(result, "&#160;", " ")
        replaceAll(result, "&ndash;", "\u2013")
        replaceAll(result, "&mdash;", "\u2014")
        replaceAll(result, "&lsquo;", "'")
        replaceAll(result, "&rsquo;", "'")
        replaceAll(result, "&ldquo;", "\"")
        replaceAll(result, "&rdquo;", "\"")
        replaceAll(result, "&hellip;", "\u2026")
        replaceAll(result, "&#8230;", "\u2026")
        return result.toString()
    }

    private fun replaceAll(builder: StringBuilder, target: String, replacement: String) {
        var index = builder.indexOf(target)
        while (index != -1) {
            builder.replace(index, index + target.length, replacement)
            index = builder.indexOf(target, index + replacement.length)
        }
    }

    @JvmStatic
    fun hasProblematicCharacters(input: String?): Boolean {
        if (input.isNullOrEmpty()) return false
        for (character in input) {
            if (character > '\u007F') return true
        }
        return false
    }

    @JvmStatic
    fun isCached(filePath: String): Boolean {
        if (filePath.isEmpty()) return false
        val context = appContext ?: return false
        return SongDatabase.getInstance(context).hasSong(filePath)
    }
}