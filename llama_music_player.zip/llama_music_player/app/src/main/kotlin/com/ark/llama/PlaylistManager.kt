// PlaylistManager.kt
package com.ark.llama

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import com.ark.llama.event.Bus
import com.ark.llama.event.MetadataEvent
import com.ark.llama.event.PlaylistEvent
import java.io.File
import java.util.ArrayList
import java.util.HashSet
import java.util.Set
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Scans the selected music folders through [MediaStore], caches the
 * results in the song database, reads ID3 genres on a background
 * thread, adds loose tracks opened from other apps, and owns the
 * full-library reset.
 *
 * <h3>State Ownership</h3>
 * <p>The manager owns four pieces of state: the scan-in-progress
 * flag, the current scan generation, the genre-load operation ID,
 * and the reset operation ID. [NavigationController] owns the
 * update-in-progress state that every component queries.</p>
 *
 * <h3>EventBus producers</h3>
 * <p>Every lifecycle event this manager produces is posted on the
 * process bus: [PlaylistEvent.LibraryReset],
 * [PlaylistEvent.SyncStarted], [PlaylistEvent.SyncComplete],
 * [PlaylistEvent.Refresh], [PlaylistEvent.Display],
 * [PlaylistEvent.TriggerGenreLoading], and
 * [MetadataEvent.GenreUpdated]. Consumers subscribe to the events
 * they need.</p>
 *
 * <h3>Genre Loading Threading</h3>
 * <p>Genre loading runs entirely on the single-thread executor. The
 * overlay is shown synchronously in the trigger's own turn, before
 * the executor is dispatched.</p>
 *
 * <h3>The reset contract</h3>
 * <ul>
 *   <li><b>One owner.</b> The reset has a beginning, a middle, and
 *       an end, and this manager owns all three.</li>
 *   <li><b>One write barrier.</b> The database and the SAF mappings
 *       are cleared on the executor, in one place.</li>
 *   <li><b>One invalidation signal.</b> After the barrier, a single
 *       [PlaylistEvent.LibraryReset] event tells every cache owner
 *       to drop its song-derived state.</li>
 *   <li><b>One completion signal.</b> The operation ends when its
 *       work completes, not when a timer expires.</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>[mIsUpdating] is an atomic flag that refuses overlapping scans.
 * [mGenreOperationId] and [mResetOperationId] are volatile strings
 * naming the current operation on each channel.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class PlaylistManager private constructor(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context.applicationContext

    private val mExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val mIsUpdating: AtomicBoolean = AtomicBoolean(false)

    private val mMainHandler: Handler = Handler(Looper.getMainLooper())

    private val mScanGeneration: AtomicLong = AtomicLong(0L)

    @Volatile
    private var mGenreOperationId: String? = null

    @Volatile
    private var mResetOperationId: String? = null

    private val mGenreHandler: Handler = Handler(Looper.getMainLooper())

    private val mGenreHeartbeatToken: AtomicLong = AtomicLong(0L)
    private val mResetHeartbeatToken: AtomicLong = AtomicLong(0L)
    private val mPlaylistSyncHeartbeatToken: AtomicLong = AtomicLong(0L)

    init {
        OverlayManager.init(mContext)
        Bus.register(this)
    }

    // ========================================================================
    // Callback interfaces
    // ========================================================================

    interface UpdateCallback {
        fun onProgress(current: Int, total: Int)
        fun onComplete(songCount: Int)
        fun onError(error: String)
    }

    interface ResetCallback {
        fun onComplete()
        fun onError(error: String)
    }

    enum class ResetMode {
        LIBRARY,
        FACTORY
    }

    // ========================================================================
    // Localization helper
    // ========================================================================

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to obtain localized context", exception)
        mContext
    }

    // ========================================================================
    // Public API — Scans
    // ========================================================================

    fun updatePlaylist(callback: UpdateCallback?) {
        updatePlaylistInternal(callback, false)
    }

    fun updatePlaylistSilent() {
        updatePlaylistInternal(null, true)
    }

    fun addLooseTrackAndUpdate(song: Song, callback: UpdateCallback?) {
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping loose track addition")
            if (callback != null) {
                mMainHandler.post { callback.onError("Update already in progress") }
            }
            return
        }

        NavigationController.getInstance().beginPlaylistSync()

        val scanGeneration = mScanGeneration.get()

        mExecutor.execute {
            try {
                if (mScanGeneration.get() != scanGeneration) return@execute

                val database = SongDatabase.getInstance(mContext)
                database.insertLooseSong(song)

                val allSongs = database.allSongs
                val totalSongCount = allSongs.size

                if (callback != null && !Thread.currentThread().isInterrupted) {
                    mMainHandler.post { callback.onProgress(1, 1) }
                }

                mMainHandler.postDelayed({
                    Bus.post(PlaylistEvent.Refresh)
                    Bus.post(PlaylistEvent.Display)
                    Bus.post(PlaylistEvent.SyncComplete)

                    callback?.onComplete(totalSongCount)
                }, UPDATE_BROADCAST_DELAY_MS)
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to add loose track", exception)
                mMainHandler.post {
                    callback?.onError(exception.message ?: "Unknown error")
                }
            } finally {
                NavigationController.getInstance().endPlaylistSync()
                mIsUpdating.set(false)
            }
        }
    }

    fun cancelUpdate() {
        mIsUpdating.set(false)
        mScanGeneration.incrementAndGet()
        Log.d(TAG, "Scan cancel requested (generation ${mScanGeneration.get()})")
    }

    fun isUpdating(): Boolean = mIsUpdating.get()

    fun isResetting(): Boolean = mResetOperationId != null

    // ========================================================================
    // Public API — Library Reset
    // ========================================================================

    fun resetLibrary(mode: ResetMode, callback: ResetCallback?) {
        OverlayManager.hide(OverlayManager.REASON_FOLDER_UPDATE_CYCLE)

        if (mIsUpdating.get()) {
            Log.w(TAG, "resetLibrary refused — a scan is in flight")
            callback?.let { mMainHandler.post { it.onError("Update in progress") } }
            return
        }
        if (mResetOperationId != null) {
            Log.w(TAG, "resetLibrary refused — a reset is already in flight")
            callback?.let { mMainHandler.post { it.onError("Reset in progress") } }
            return
        }

        mIsUpdating.set(true)
        mScanGeneration.incrementAndGet()
        mResetOperationId = OPERATION_LIBRARY_RESET

        val genreOperationId = mGenreOperationId
        if (genreOperationId != null) {
            mGenreOperationId = null
            ToastManager.cancelOperation(genreOperationId)
        }

        NavigationController.getInstance().beginPlaylistSync()

        Log.d(TAG, "Library reset started (mode=$mode)")

        mMainHandler.post {
            ToastManager.hidePersistentOverlay(OPERATION_GENRE_UPDATE)

            val currentActivity = ToastManager.getCurrentActivity()
            if (currentActivity != null && !currentActivity.isFinishing &&
                !currentActivity.isDestroyed
            ) {
                ToastManager.showPersistentOverlay(
                    currentActivity,
                    getLocaleContext().getString(R.string.library_clearing),
                    "",
                    OPERATION_LIBRARY_RESET
                )
            } else {
                Log.w(TAG, "No activity available for reset overlay")
            }
            startResetHeartbeatTicker(OPERATION_LIBRARY_RESET)
        }

        mExecutor.execute {
            try {
                performResetBarrier()
            } catch (exception: Exception) {
                Log.e(TAG, "Reset barrier failed", exception)
                val message = exception.message ?: "Reset failed"
                mMainHandler.post { postResetCompletion(callback, false, message) }
                return@execute
            }

            cleanupTempCacheAsync()

            mMainHandler.post {
                sendResetSignal(mode)
                postResetCompletion(callback, true, null)
            }
        }
    }

    // ========================================================================
    // Reset internals
    // ========================================================================

    private fun performResetBarrier() {
        Log.d(TAG, "Reset barrier: clearing content")

        val database = SongDatabase.getInstance(mContext)
        database.clearCache()
        database.clearLooseSongs()

        StorageAccessHelper.getInstance(mContext).clearAll()

        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_SELECTED_FOLDERS, HashSet<String>())
            .apply()

        Log.d(TAG, "Reset barrier: content cleared")
    }

    private fun sendResetSignal(mode: ResetMode) {
        val preserveSettings = (mode == ResetMode.LIBRARY)
        Bus.postSticky(PlaylistEvent.LibraryReset(preserveSettings))
        Log.d(TAG, "LIBRARY_RESET signal sent (preserve_settings=$preserveSettings)")
    }

    private fun postResetCompletion(
        callback: ResetCallback?,
        success: Boolean,
        error: String?
    ) {
        stopResetHeartbeatTicker()
        mResetOperationId = null
        mIsUpdating.set(false)

        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_RESET)

        NavigationController.getInstance().endPlaylistSync()

        if (callback != null) {
            if (success) callback.onComplete()
            else callback.onError(error ?: "Reset failed")
        }

        Log.d(TAG, "Library reset ${if (success) "completed" else "failed"}")
    }

    private fun startResetHeartbeatTicker(operationId: String) {
        val token = mResetHeartbeatToken.incrementAndGet()
        mGenreHandler.post(object : Runnable {
            override fun run() {
                if (mResetHeartbeatToken.get() != token) return
                if (!ToastManager.isOperationRunning(operationId)) return
                ToastManager.heartbeat(operationId)
                mGenreHandler.postDelayed(this, RESET_HEARTBEAT_INTERVAL_MS)
            }
        })
    }

    private fun stopResetHeartbeatTicker() {
        mResetHeartbeatToken.incrementAndGet()
    }

    private fun cleanupTempCacheAsync() {
        Thread {
            try {
                val cacheDir = mContext.cacheDir
                if (cacheDir == null || !cacheDir.isDirectory) return@Thread
                val files = cacheDir.listFiles() ?: return@Thread
                for (file in files) {
                    if (file == null || !file.isFile) continue
                    val name = file.name
                    if (name.startsWith("temp_audio_") || name.startsWith("backup_")) {
                        if (file.delete()) {
                            Log.d(TAG, "Deleted stale temp file: $name")
                        }
                    }
                }
            } catch (exception: Exception) {
                Log.w(TAG, "cleanupTempCache failed", exception)
            }
        }.start()
    }

    // ========================================================================
    // Genre loading
    // ========================================================================

    fun triggerGenreLoading() {
        triggerGenreLoading(null)
    }

    fun triggerGenreLoading(customMessage: String?) {
        OverlayManager.hide(OverlayManager.REASON_FOLDER_UPDATE_CYCLE)

        if (mResetOperationId != null) {
            Log.d(TAG, "Genre loading refused — reset in progress")
            return
        }
        if (mGenreOperationId != null) {
            Log.d(TAG, "Genre loading already in progress, skipping")
            return
        }

        val operationId = OPERATION_GENRE_UPDATE
        val initialMessage = customMessage
            ?: getLocaleContext().getString(R.string.library_loading_metadata)
        mGenreOperationId = operationId

        Log.d(TAG, "Starting genre loading...")

        val currentActivity = ToastManager.getCurrentActivity()
        if (currentActivity != null && !currentActivity.isFinishing &&
            !currentActivity.isDestroyed
        ) {
            ToastManager.showPersistentOverlay(
                currentActivity, initialMessage, "", operationId
            )
        } else {
            Log.w(TAG, "No activity available for persistent overlay")
        }
        startGenreHeartbeatTicker(operationId)

        mExecutor.execute {
            runGenreLoad(operationId, customMessage)
        }
    }

    private fun runGenreLoad(operationId: String, customMessage: String?) {
        val allSongs = SongDatabase.getInstance(mContext).allSongs

        val songsNeedingGenres = ArrayList<Song>()
        for (song in allSongs) {
            if (song != null && CharacterMapper.isUnknownGenre(song.genre)) {
                songsNeedingGenres.add(song)
            }
        }

        if (songsNeedingGenres.isEmpty()) {
            Log.d(TAG, "No songs need genre update")
            sendGenreUpdateSignal("COMPLETE", null, null, 0, 0)
            mGenreHandler.post {
                stopGenreHeartbeatTicker()
                ToastManager.hidePersistentOverlay(operationId)
                sApplication?.let {
                    NotificationController.getInstance(it)
                        .dismissLibraryStatus(operationId)
                }
                mGenreOperationId = null
            }
            return
        }

        Log.d(TAG, "Loading genres for ${songsNeedingGenres.size} songs")

        val database = SongDatabase.getInstance(mContext)
        var updatedCount = 0
        val total = songsNeedingGenres.size
        var lastProgressTime = 0L

        sendGenreUpdateSignal("START", null, null, 0, total)

        try {
            for (song in songsNeedingGenres) {
                if (!ToastManager.isOperationRunning(operationId)) {
                    Log.d(TAG, "Genre loading cancelled — exiting without completion")
                    mGenreOperationId = null
                    return
                }
                if (song == null || song.path.isEmpty()) continue

                val realGenre = CharacterMapper.getGenre(song.path)
                val hasRealGenre = !CharacterMapper.isUnknownGenre(realGenre)

                if (hasRealGenre) {
                    val updatedSong = Song(
                        song.title,
                        song.artist,
                        song.album,
                        realGenre,
                        song.path,
                        song.duration,
                        song.uri
                    )
                    database.insertSong(updatedSong)
                    song.setGenre(realGenre)
                    updatedCount++

                    sendGenreUpdateSignal(
                        "UPDATE", song.path, realGenre, updatedCount, total
                    )
                }

                val now = SystemClock.elapsedRealtime()
                if (now - lastProgressTime >= PROGRESS_TIME_THRESHOLD_MS ||
                    updatedCount == total || updatedCount == 1
                ) {
                    lastProgressTime = now
                    val currentUpdated = updatedCount
                    val currentTotal = total
                    val title = customMessage
                        ?: getLocaleContext().getString(R.string.library_loading_metadata)
                    val body = "$currentUpdated/$currentTotal"
                    mGenreHandler.post {
                        ToastManager.updatePersistentOverlay(title, body, operationId)
                    }
                }
            }
        } finally {
            stopGenreHeartbeatTicker()
        }

        if (!ToastManager.isOperationRunning(operationId)) {
            Log.d(TAG, "Genre loading cancelled before completion")
            mGenreOperationId = null
            return
        }

        Log.d(TAG, "Genre loading completed: $updatedCount/$total songs updated")

        sendGenreUpdateSignal("COMPLETE", null, null, updatedCount, total)

        Bus.post(PlaylistEvent.Refresh)

        mGenreHandler.post {
            ToastManager.hidePersistentOverlay(operationId)
            sApplication?.let {
                NotificationController.getInstance(it)
                    .dismissLibraryStatus(operationId)
            }
            mGenreOperationId = null
        }
    }

    fun isGenreLoading(): Boolean = mGenreOperationId != null

    private fun startGenreHeartbeatTicker(operationId: String) {
        val token = mGenreHeartbeatToken.incrementAndGet()
        mGenreHandler.post(object : Runnable {
            override fun run() {
                if (mGenreHeartbeatToken.get() != token) return
                if (!ToastManager.isOperationRunning(operationId)) return
                ToastManager.heartbeat(operationId)
                mGenreHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS)
            }
        })
    }

    private fun stopGenreHeartbeatTicker() {
        mGenreHeartbeatToken.incrementAndGet()
    }

    private fun sendGenreUpdateSignal(
        status: String,
        songPath: String?,
        genre: String?,
        current: Int,
        total: Int
    ) {
        Bus.post(MetadataEvent.GenreUpdated(status, songPath, genre, current, total))
    }

    // ========================================================================
    // Bus subscriber — trigger path
    // ========================================================================

    @org.greenrobot.eventbus.Subscribe(
        threadMode = org.greenrobot.eventbus.ThreadMode.MAIN
    )
    fun onTriggerGenreLoading(event: PlaylistEvent.TriggerGenreLoading) {
        triggerGenreLoading(event.customMessage)
    }

    // ========================================================================
    // Public API — Scan entry point
    // ========================================================================

    private fun updatePlaylistInternal(callback: UpdateCallback?, silent: Boolean) {
        if (mResetOperationId != null) {
            Log.w(TAG, "Update refused — reset in progress")
            callback?.onError("Reset in progress")
            return
        }
        if (!mIsUpdating.compareAndSet(false, true)) {
            Log.w(TAG, "Update already in progress, skipping")
            callback?.onError("Update already in progress")
            return
        }

        NavigationController.getInstance().beginPlaylistSync()
        startPlaylistSyncHeartbeat()

        val scanGeneration = mScanGeneration.get()

        mExecutor.execute {
            try {
                performScan(callback, silent, scanGeneration)
            } catch (exception: Exception) {
                Log.e(TAG, "Uncaught exception during playlist update", exception)
                mMainHandler.post {
                    callback?.onError(exception.message ?: "Unknown error during scan")
                }
            } finally {
                stopPlaylistSyncHeartbeat()
                NavigationController.getInstance().endPlaylistSync()
                mIsUpdating.set(false)
            }
        }
    }

    private fun performScan(
        callback: UpdateCallback?,
        silent: Boolean,
        scanGeneration: Long
    ) {
        try {
            val newSongs = ArrayList<Song>()
            val allFoundPaths = HashSet<String>()
            val selectedFolders = getSelectedFolders()

            var foundAnySongs = false

            if (selectedFolders.isEmpty()) {
                val database = SongDatabase.getInstance(mContext)
                val looseSongs = database.looseSongs
                database.clearCache()
                if (looseSongs.isNotEmpty()) {
                    database.insertSongsBatch(looseSongs)
                    foundAnySongs = true
                }
                val songsAfterUpdate = database.allSongs

                mMainHandler.post {
                    Bus.post(PlaylistEvent.Refresh)
                    Bus.post(PlaylistEvent.Display)

                    callback?.onComplete(songsAfterUpdate.size)
                }
                return
            }

            val totalFiles = countMusicFiles(selectedFolders)
            val currentCount = AtomicInteger(0)

            if (!silent && callback != null) {
                mMainHandler.post { callback.onProgress(0, totalFiles) }
            }

            for (folderUriString in selectedFolders) {
                if (!mIsUpdating.get() || mResetOperationId != null) return

                val foundInFolder = scanFolderFast(
                    Uri.parse(folderUriString),
                    newSongs, allFoundPaths, currentCount,
                    totalFiles, callback, silent
                )
                if (foundInFolder > 0) {
                    foundAnySongs = true
                }
            }

            if (!mIsUpdating.get() || mResetOperationId != null) return

            val database = SongDatabase.getInstance(mContext)

            if (mScanGeneration.get() != scanGeneration || mResetOperationId != null) return

            if (newSongs.isNotEmpty()) {
                database.insertSongsBatch(newSongs)
            }

            if (selectedFolders.isNotEmpty() && !foundAnySongs) {
                val currentSongs = database.allSongs
                mMainHandler.post { callback?.onComplete(currentSongs.size) }
                return
            }

            if (mScanGeneration.get() != scanGeneration || mResetOperationId != null) return
            database.deleteSongsNotInSet(allFoundPaths, true)

            val allSongsAfterUpdate = database.allSongs
            val totalSongCount = allSongsAfterUpdate.size

            Bus.post(PlaylistEvent.Refresh)
            Bus.post(PlaylistEvent.Display)

            mMainHandler.postDelayed({
                callback?.onComplete(totalSongCount)

                Bus.post(PlaylistEvent.SyncComplete)
            }, SYNC_COMPLETE_DELAY_MS)
        } catch (exception: Exception) {
            Log.e(TAG, "Update failed: ${exception.message}", exception)
            mMainHandler.post {
                callback?.onError(exception.message ?: "Unknown error")
            }
            throw RuntimeException(exception)
        }
    }

    // ========================================================================
    // Folder and file scanning
    // ========================================================================

    private fun scanFolderFast(
        folderUri: Uri,
        newSongs: ArrayList<Song>,
        allFoundPaths: Set<String>,
        currentCount: AtomicInteger,
        totalFiles: Int,
        callback: UpdateCallback?,
        silent: Boolean
    ): Int {
        if (!mIsUpdating.get() || mResetOperationId != null) return 0

        var songsFound = 0
        try {
            val folderPath = getFolderPathFromUri(folderUri)
            if (folderPath != null) {
                songsFound = queryMediaStoreFast(
                    folderPath, newSongs, allFoundPaths, currentCount,
                    totalFiles, callback, silent
                )
            } else {
                val folderName = getFolderNameFromUri(folderUri)
                if (folderName != null) {
                    songsFound = queryMediaStoreByNameFast(
                        folderName, newSongs, allFoundPaths, currentCount,
                        totalFiles, callback, silent
                    )
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "scan error for folder: $folderUri", exception)
        }
        return songsFound
    }

    private fun queryMediaStoreFast(
        folderPath: String,
        newSongs: ArrayList<Song>,
        allFoundPaths: Set<String>,
        currentCount: AtomicInteger,
        totalFiles: Int,
        callback: UpdateCallback?,
        silent: Boolean
    ): Int {
        if (!mIsUpdating.get() || mResetOperationId != null) return 0

        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val normalizedPath =
            if (folderPath.endsWith("/")) folderPath else "$folderPath/"
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null

        val lastProgress = intArrayOf(0)
        val lastProgressTime = longArrayOf(0L)
        var songsFound = 0

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("$normalizedPath%"),
                null
            )

            if (cursor != null && cursor.moveToFirst() &&
                mIsUpdating.get() && mResetOperationId == null
            ) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor")
                    return 0
                }

                val database = SongDatabase.getInstance(mContext)

                do {
                    if (!mIsUpdating.get() || mResetOperationId != null) break

                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    val file = File(filePath)
                    if (!file.exists() || !file.canRead()) continue

                    allFoundPaths.add(filePath)

                    try {
                        val cachedSong = database.getSong(filePath)
                        if (cachedSong == null) {
                            val rawTitle = cursor.getString(titleColumn)
                            val rawArtist = cursor.getString(artistColumn)
                            val rawAlbum = cursor.getString(albumColumn)
                            val duration: Long =
                                if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L

                            var title = CharacterMapper.cleanMusicMetadata(rawTitle)
                            if (title.isNullOrEmpty()) {
                                var fileName = file.name
                                val dotIndex = fileName.lastIndexOf(".")
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex)
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName)
                            }

                            var artist = CharacterMapper.cleanMusicMetadata(rawArtist)
                            var album = CharacterMapper.cleanMusicMetadata(rawAlbum)
                            var genre: String? = null

                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)
                            ) {
                                val parsedSong = CharacterMapper.getSongFromFile(filePath)
                                if (parsedSong != null) {
                                    title = parsedSong.title
                                    artist = parsedSong.artist
                                    album = parsedSong.album
                                    genre = parsedSong.genre
                                }
                            }

                            val newSong = Song(title, artist, album, genre, filePath, duration, null)
                            newSongs.add(newSong)
                            songsFound++
                        } else {
                            songsFound++
                        }
                    } catch (exception: Exception) {
                        Log.e(TAG, "Failed to process file: $filePath", exception)
                    }

                    val currentValue = currentCount.incrementAndGet()
                    val currentTime = SystemClock.elapsedRealtime()
                    val shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                            currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                            currentValue == totalFiles)

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue
                        lastProgressTime[0] = currentTime
                        val finalCurrent = currentValue
                        val finalTotal = totalFiles
                        mMainHandler.post {
                            if (callback != null && mIsUpdating.get() &&
                                mResetOperationId == null
                            ) {
                                callback.onProgress(finalCurrent, finalTotal)
                            }
                        }
                    }
                } while (cursor.moveToNext() && mIsUpdating.get() &&
                    mResetOperationId == null
                )
            }
        } catch (exception: SecurityException) {
            Log.e(TAG, "Permission denied scanning folder: $folderPath", exception)
            if (callback != null && !silent) {
                mMainHandler.post {
                    if (mIsUpdating.get() && mResetOperationId == null) {
                        callback.onError("Permission denied accessing storage")
                    }
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "query error for folder: $folderPath", exception)
        } finally {
            cursor?.let {
                try {
                    it.close()
                } catch (exception: Exception) {
                    Log.w(TAG, "Failed to close cursor", exception)
                }
            }
        }
        return songsFound
    }

    private fun queryMediaStoreByNameFast(
        folderName: String,
        newSongs: ArrayList<Song>,
        allFoundPaths: Set<String>,
        currentCount: AtomicInteger,
        totalFiles: Int,
        callback: UpdateCallback?,
        silent: Boolean
    ): Int {
        if (!mIsUpdating.get() || mResetOperationId != null) return 0

        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null

        val lastProgress = intArrayOf(0)
        val lastProgressTime = longArrayOf(0L)
        var songsFound = 0

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("%/$folderName/%"),
                null
            )

            if (cursor != null && cursor.moveToFirst() &&
                mIsUpdating.get() && mResetOperationId == null
            ) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)

                if (pathColumn == -1) {
                    Log.w(TAG, "DATA column not found in cursor")
                    return 0
                }

                val database = SongDatabase.getInstance(mContext)

                do {
                    if (!mIsUpdating.get() || mResetOperationId != null) break

                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    val file = File(filePath)
                    if (!file.exists() || !file.canRead()) continue

                    allFoundPaths.add(filePath)

                    try {
                        val cachedSong = database.getSong(filePath)
                        if (cachedSong == null) {
                            val rawTitle = cursor.getString(titleColumn)
                            val rawArtist = cursor.getString(artistColumn)
                            val rawAlbum = cursor.getString(albumColumn)
                            val duration: Long =
                                if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L

                            var title = CharacterMapper.cleanMusicMetadata(rawTitle)
                            if (title.isNullOrEmpty()) {
                                var fileName = file.name
                                val dotIndex = fileName.lastIndexOf(".")
                                if (dotIndex > 0) {
                                    fileName = fileName.substring(0, dotIndex)
                                }
                                title = CharacterMapper.cleanMusicMetadata(fileName)
                            }

                            var artist = CharacterMapper.cleanMusicMetadata(rawArtist)
                            var album = CharacterMapper.cleanMusicMetadata(rawAlbum)
                            var genre: String? = null

                            if (CharacterMapper.hasProblematicCharacters(title) ||
                                CharacterMapper.hasProblematicCharacters(artist) ||
                                CharacterMapper.hasProblematicCharacters(album)
                            ) {
                                val parsedSong = CharacterMapper.getSongFromFile(filePath)
                                if (parsedSong != null) {
                                    title = parsedSong.title
                                    artist = parsedSong.artist
                                    album = parsedSong.album
                                    genre = parsedSong.genre
                                }
                            }

                            val newSong = Song(title, artist, album, genre, filePath, duration, null)
                            newSongs.add(newSong)
                            songsFound++
                        } else {
                            songsFound++
                        }
                    } catch (exception: Exception) {
                        Log.e(TAG, "Failed to process file: $filePath", exception)
                    }

                    val currentValue = currentCount.incrementAndGet()
                    val currentTime = SystemClock.elapsedRealtime()
                    val shouldUpdateProgress = !silent && callback != null &&
                        (currentValue - lastProgress[0] >= PROGRESS_THRESHOLD ||
                            currentTime - lastProgressTime[0] >= PROGRESS_TIME_THRESHOLD_MS ||
                            currentValue == totalFiles)

                    if (shouldUpdateProgress) {
                        lastProgress[0] = currentValue
                        lastProgressTime[0] = currentTime
                        val finalCurrent = currentValue
                        val finalTotal = totalFiles
                        mMainHandler.post {
                            if (callback != null && mIsUpdating.get() &&
                                mResetOperationId == null
                            ) {
                                callback.onProgress(finalCurrent, finalTotal)
                            }
                        }
                    }
                } while (cursor.moveToNext() && mIsUpdating.get() &&
                    mResetOperationId == null
                )
            }
        } catch (exception: Exception) {
            Log.e(TAG, "query by name error for: $folderName", exception)
        } finally {
            cursor?.let {
                try {
                    it.close()
                } catch (exception: Exception) {
                    Log.w(TAG, "Failed to close cursor", exception)
                }
            }
        }
        return songsFound
    }

    // ========================================================================
    // Helper methods
    // ========================================================================

    private fun getSelectedFolders(): Set<String> {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        val savedFolders = preferences.getStringSet(KEY_SELECTED_FOLDERS, null)
        val result = HashSet<String>()
        if (savedFolders != null) {
            result.addAll(savedFolders)
        }
        return result
    }

    private fun countMusicFiles(selectedFolders: Set<String>): Int {
        var total = 0
        if (selectedFolders.isEmpty()) return 0

        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        for (folderUriString in selectedFolders) {
            try {
                val folderUri = Uri.parse(folderUriString)
                val folderPath = getFolderPathFromUri(folderUri)

                if (folderPath != null) {
                    val normalizedPath =
                        if (folderPath.endsWith("/")) folderPath else "$folderPath/"
                    val folderSelection = "$selection AND " +
                        "${MediaStore.Audio.Media.DATA} LIKE ?"
                    var cursor: Cursor? = null
                    try {
                        cursor = resolver.query(
                            mediaUri,
                            arrayOf(MediaStore.Audio.Media.DATA),
                            folderSelection,
                            arrayOf("$normalizedPath%"),
                            null
                        )
                        if (cursor != null) total += cursor.count
                    } finally {
                        cursor?.let {
                            try { it.close() } catch (exception: Exception) {
                                Log.w(TAG, "Failed to close count cursor", exception)
                            }
                        }
                    }
                } else {
                    val folderName = getFolderNameFromUri(folderUri)
                    if (folderName != null) {
                        val folderSelection = "$selection AND " +
                            "${MediaStore.Audio.Media.DATA} LIKE ?"
                        var cursor: Cursor? = null
                        try {
                            cursor = resolver.query(
                                mediaUri,
                                arrayOf(MediaStore.Audio.Media.DATA),
                                folderSelection,
                                arrayOf("%/$folderName/%"),
                                null
                            )
                            if (cursor != null) total += cursor.count
                        } finally {
                            cursor?.let {
                                try { it.close() } catch (exception: Exception) {
                                    Log.w(TAG, "Failed to close count cursor", exception)
                                }
                            }
                        }
                    }
                }
            } catch (exception: Exception) {
                Log.e(TAG, "count error for folder: $folderUriString", exception)
            }
        }

        return total
    }

    private fun getFolderPathFromUri(uri: Uri?): String? =
        StorageAccessHelper.getInstance(mContext).getFolderPathFromUri(uri)

    private fun getFolderNameFromUri(uri: Uri?): String? {
        if (uri == null) return null

        var name: String? = null
        var cursor: Cursor? = null
        try {
            cursor = mContext.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex)
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getFolderName error", exception)
        } finally {
            cursor?.let {
                try { it.close() } catch (exception: Exception) {
                    Log.w(TAG, "Failed to close folder name cursor", exception)
                }
            }
        }

        if (name == null) {
            var segment = uri.lastPathSegment
            if (segment != null && segment.contains(":")) {
                segment = segment.substring(segment.indexOf(":") + 1)
            }
            name = segment
        }

        return name?.let { CharacterMapper.cleanString(it) }
    }

    // ========================================================================
    // Heartbeats and shutdown
    // ========================================================================

    private fun startPlaylistSyncHeartbeat() {
        val token = mPlaylistSyncHeartbeatToken.incrementAndGet()
        mMainHandler.post(object : Runnable {
            override fun run() {
                if (mPlaylistSyncHeartbeatToken.get() != token) return
                NavigationController.getInstance().heartbeat(
                    NavigationController.Operation.PLAYLIST_SYNC
                )
                mMainHandler.postDelayed(this, GENRE_HEARTBEAT_INTERVAL_MS)
            }
        })
    }

    private fun stopPlaylistSyncHeartbeat() {
        mPlaylistSyncHeartbeatToken.incrementAndGet()
    }

    fun shutdown() {
        cancelUpdate()

        mGenreOperationId?.let { opId ->
            ToastManager.cancelOperation(opId)
            mGenreOperationId = null
        }

        mResetOperationId = null

        stopGenreHeartbeatTicker()
        stopResetHeartbeatTicker()
        stopPlaylistSyncHeartbeat()

        Bus.unregister(this)

        if (!mExecutor.isShutdown) {
            mExecutor.shutdown()
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow()
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown")
                }
            } catch (exception: InterruptedException) {
                mExecutor.shutdownNow()
                Thread.currentThread().interrupt()
                Log.w(TAG, "Executor shutdown interrupted", exception)
            }
        }
        mGenreHandler.removeCallbacksAndMessages(null)
        sApplication = null
        Log.d(TAG, "PlaylistManager shut down")
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val TAG = "PlaylistManager"

        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_SELECTED_FOLDERS = "selected_folders_uris"

        private const val PROGRESS_THRESHOLD = 10
        private const val PROGRESS_TIME_THRESHOLD_MS = 500L
        private const val GENRE_HEARTBEAT_INTERVAL_MS = 500L
        private const val RESET_HEARTBEAT_INTERVAL_MS = 500L
        private const val SHUTDOWN_TIMEOUT_MS = 5000L
        private const val UPDATE_BROADCAST_DELAY_MS = 200L
        private const val SYNC_COMPLETE_DELAY_MS = 400L

        private const val OPERATION_GENRE_UPDATE = "GENRE_UPDATE"
        private const val OPERATION_LIBRARY_RESET = "LIBRARY_RESET"

        @Volatile
        private var sInstance: PlaylistManager? = null

        @JvmStatic
        @JvmField
        var sApplication: Application? = null
            private set

        @JvmStatic
        fun getInstance(context: Context): PlaylistManager {
            if (sInstance == null) {
                synchronized(PlaylistManager::class.java) {
                    if (sInstance == null) {
                        sApplication = context.applicationContext as Application
                        sInstance = PlaylistManager(context)
                    }
                }
            }
            return sInstance!!
        }
    }
}