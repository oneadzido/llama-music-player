// PermissionChecker.kt
package com.ark.llama

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * Answers whether the runtime permissions the app needs are granted.
 *
 * <p>The set of permissions the app requests is version-gated: the
 * media-read permission the app asks for is [READ_MEDIA_AUDIO] on
 * API 33 and later and [Manifest.permission.READ_EXTERNAL_STORAGE]
 * below that; [POST_NOTIFICATIONS] is required from API 33; and
 * [BLUETOOTH_CONNECT] is required from API 31. The
 * foreground-service media-playback permission is a normal permission
 * and is not part of the runtime request set.</p>
 *
 * <p>The set lives here, in one place, so every reader of "are the
 * permissions granted" reads the same answer.</p>
 *
 * <h3>Readers</h3>
 * <ul>
 *   <li>[com.ark.llama.MusicPlayer.checkPermissionsAndInitialize]
 *       asks [getMissing] for the array it requests.</li>
 *   <li>[com.ark.llama.MusicPlayer.onResume] asks [allGranted] on
 *       every pass.</li>
 *   <li>[com.ark.llama.MusicPlayer.canEnableTransportControls] asks
 *       [allGranted] as one of the three facts it combines.</li>
 *   <li>[com.ark.llama.FolderManager.areFolderChangesAllowed] asks
 *       [allGranted] as one half of its answer.</li>
 * </ul>
 *
 * <h3>Below the runtime-permission model</h3>
 * <p>[Build.VERSION_CODES.M] is the floor. Below it, permission
 * grants are established at install time and
 * [Context.checkSelfPermission] does not apply. Both public methods
 * return the honest answer for that case.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.2.9
 */
object PermissionChecker {

    /** Media-read permission name on API 33 and later. */
    private const val PERMISSION_READ_MEDIA_AUDIO =
        "android.permission.READ_MEDIA_AUDIO"

    /** Notification-post permission name on API 33 and later. */
    private const val PERMISSION_POST_NOTIFICATIONS =
        "android.permission.POST_NOTIFICATIONS"

    /** Bluetooth-connect permission name on API 31 and later. */
    private const val PERMISSION_BLUETOOTH_CONNECT =
        "android.permission.BLUETOOTH_CONNECT"

    /**
     * Returns whether every runtime permission the app needs is
     * currently granted.
     *
     * <p>Below [Build.VERSION_CODES.M] the runtime permission model
     * does not apply, and this method returns true. From API 23 on,
     * it checks each permission the running release requires.</p>
     *
     * @param context Context used to check the grants
     * @return True when every required permission is granted
     */
    @JvmStatic
    fun allGranted(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true
        }
        return getMissing(context).isEmpty()
    }

    /**
     * Returns the runtime permissions the app needs that are not
     * granted.
     *
     * <p>Below [Build.VERSION_CODES.M] the returned array is empty.
     * From API 23 on, it contains one entry per missing permission,
     * in the order the version gate adds them.</p>
     *
     * <p>Callers that only need a yes-or-no answer should use
     * [allGranted], whose answer is derived from this method's
     * result.</p>
     *
     * @param context Context used to check the grants
     * @return An array of missing permission names
     */
    @JvmStatic
    fun getMissing(context: Context): Array<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return emptyArray()
        }

        val missing = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= 33) {
            if (context.checkSelfPermission(PERMISSION_READ_MEDIA_AUDIO) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                missing.add(PERMISSION_READ_MEDIA_AUDIO)
            }
            if (context.checkSelfPermission(PERMISSION_POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                missing.add(PERMISSION_POST_NOTIFICATIONS)
            }
        } else {
            if (context.checkSelfPermission(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                missing.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (Build.VERSION.SDK_INT >= 31) {
            if (context.checkSelfPermission(PERMISSION_BLUETOOTH_CONNECT) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                missing.add(PERMISSION_BLUETOOTH_CONNECT)
            }
        }

        return missing.toTypedArray()
    }
}