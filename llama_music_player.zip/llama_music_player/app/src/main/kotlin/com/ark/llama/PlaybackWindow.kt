// PlaybackWindow.kt
package com.ark.llama

import java.util.Objects

/**
 * An immutable snapshot of the three paths the album-art carousel
 * renders, together with the transition counter that produced it.
 *
 * <p>A window names the previous neighbour, the current song, and
 * the next neighbour, and carries [MusicService]'s monotonic
 * transition counter. It is a value: equality compares the three
 * paths and the generation, and the same window published twice is
 * a no-op for every consumer. The window is computed by
 * [MusicService] and carried on every [com.ark.llama.event.PlayerEvent.Snapshot].</p>
 *
 * <h3>Authority</h3>
 * <p>[MusicService] is the sole producer of a window.
 * [AlbumArtCarousel] is the sole consumer. Nothing else computes a
 * window, and no consumer computes neighbours from a playlist.</p>
 *
 * <p>The carousel therefore does not need to know how the playlist
 * is sorted, whether shuffle is on, or what the repeat mode is. The
 * service answers all of that in the three paths it publishes; the
 * carousel renders the three paths and runs the one animation the
 * direction and restart flag describe.</p>
 *
 * <h3>Null Semantics</h3>
 * <p>[previousPath] and [nextPath] are the neighbours the service's
 * next and previous requests would advance to, under the current
 * repeat mode and shuffle setting. For a single-song playlist, or a
 * shuffle re-pick that cannot avoid the current index, the neighbour
 * is the current song itself. The two paths are null only when the
 * playlist is empty; in that case the window is [EMPTY] and every
 * path is null. Under repeat-one the window still publishes the
 * positional or shuffle-chosen neighbours while the service restarts
 * the current song.</p>
 *
 * <h3>Generation</h3>
 * <p>[generation] is the service's transition counter at the moment
 * the window was produced. It advances only when a fresh transition
 * begins. The carousel compares the generation of an incoming window
 * against the generation of the window it last held to distinguish a
 * fresh transition from a re-publication. This is what lets a
 * repeat-one restart — whose three paths are unchanged — be animated
 * exactly as a song change is.</p>
 *
 * @param previousPath Path of the previous neighbour, or null
 * @param currentPath Path of the current song, or null
 * @param nextPath Path of the next neighbour, or null
 * @param generation The service's transition counter
 *
 * @see MusicService
 * @see AlbumArtCarousel
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.2.0
 */
class PlaybackWindow @JvmOverloads constructor(
    @JvmField val previousPath: String?,
    @JvmField val currentPath: String?,
    @JvmField val nextPath: String?,
    @JvmField val generation: Long = 0L
) {

    /**
     * Returns whether the given path is named by this window.
     *
     * <p>Convenience for the carousel's "did the incoming art match
     * one of the three slots" check. A null path never matches, so
     * callers do not need a null guard around the call.</p>
     *
     * @param path Path to test, or null
     * @return True when the path equals one of the three window paths
     */
    fun contains(path: String?): Boolean {
        if (path == null) return false
        return path == previousPath ||
            path == currentPath ||
            path == nextPath
    }

    /**
     * Returns whether this window and the given object describe the
     * same three paths and the same generation.
     *
     * @param other Object to compare against, or null
     * @return True when the given object is a window with the same
     *         three paths and generation
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PlaybackWindow) return false
        return generation == other.generation &&
            previousPath == other.previousPath &&
            currentPath == other.currentPath &&
            nextPath == other.nextPath
    }

    /**
     * Returns a hash code derived from the three paths and the
     * generation. Matches [java.util.Objects.hash] on the same
     * fields so any persisted or logged hash value is byte-identical
     * to v1.4.8's.
     */
    override fun hashCode(): Int =
        Objects.hash(previousPath, currentPath, nextPath, generation)

    /**
     * Returns a debug representation of this window.
     *
     * @return A string containing the three paths and the generation
     */
    override fun toString(): String =
        "PlaybackWindow{previous=$previousPath, " +
            "current=$currentPath, next=$nextPath, " +
            "generation=$generation}"

    companion object {

        /**
         * The empty window, published when the service is idle.
         *
         * <p>Every path is null and the generation is zero. The
         * carousel resets to its placeholder art when it receives
         * this window. A fresh window with the same shape and a
         * non-zero generation is a different value (the service is
         * running with no current song, which is a transient state
         * during a scan); the carousel distinguishes them by the
         * generation.</p>
         */
        @JvmField
        val EMPTY = PlaybackWindow(null, null, null, 0L)
    }
}