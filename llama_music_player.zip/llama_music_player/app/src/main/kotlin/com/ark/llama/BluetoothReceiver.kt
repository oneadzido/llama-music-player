// BluetoothReceiver.kt
package com.ark.llama

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothHeadset
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import com.ark.llama.event.Bus
import com.ark.llama.event.TransportEvent
import java.io.File

/**
 * Handles Bluetooth headset and A2DP connection state changes.
 *
 * <p>Listens for headset and A2DP profile connection and
 * disconnection events. When either profile connects and there is
 * prior playback state to resume, starts [MusicService] with an
 * explicit {@code ACTION_BLUETOOTH_RESUME} action. When either
 * profile disconnects, posts [TransportEvent.Pause] on the bus; the
 * service owns the pause so it fires whether or not the player
 * activity is alive.</p>
 *
 * <h3>Cold-process entry</h3>
 * <p>The `startForegroundService(ACTION_BLUETOOTH_RESUME)` call is
 * the cold-process entry into [MusicService]. A Bluetooth headset
 * can reconnect when the app has been evicted from memory and no
 * activity or bound client exists. An explicit service start is the
 * only reliable way to bring the service back and resume playback
 * from the persisted state, so the call is a first-class part of the
 * connect path rather than a convenience.</p>
 *
 * <h3>EventBus producers</h3>
 * <p>[TransportEvent.SetBluetoothConnected] and [TransportEvent.Pause]
 * are posted on the process bus. The service's handlers are the sole
 * consumers.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class BluetoothReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: run {
            Log.w(TAG, "Received intent with null action"); return
        }
        if (action == BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED ||
            action == BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED
        ) {
            handleConnectionStateChanged(context, intent)
        }
    }

    private fun handleConnectionStateChanged(context: Context, intent: Intent) {
        val state = intent.getIntExtra(
            BluetoothHeadset.EXTRA_STATE, BluetoothHeadset.STATE_DISCONNECTED
        )
        when (state) {
            BluetoothHeadset.STATE_CONNECTED -> {
                Log.d(TAG, "Bluetooth profile connected")
                handleBluetoothConnect(context)
            }
            BluetoothHeadset.STATE_DISCONNECTED -> {
                Log.d(TAG, "Bluetooth profile disconnected")
                handleBluetoothDisconnect(context, intent)
            }
            else -> Log.v(TAG, "Bluetooth state change ignored: $state")
        }
    }

    private fun handleBluetoothConnect(context: Context) {
        Bus.post(TransportEvent.SetBluetoothConnected(true))

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val wasPlaying = prefs.getBoolean(KEY_LAST_PLAYING, false)
        val lastPath = prefs.getString(KEY_LAST_SONG_PATH, null)

        val hasSomething = wasPlaying && lastPath != null && File(lastPath).exists()
        if (!hasSomething) {
            Log.d(TAG, "Connected, no prior playback to resume"); return
        }
        Log.d(TAG, "Resuming playback after Bluetooth connect")

        val resumeIntent = Intent(context, MusicService::class.java).apply {
            action = ACTION_BLUETOOTH_RESUME
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(resumeIntent)
        } else {
            context.startService(resumeIntent)
        }
    }

    private fun handleBluetoothDisconnect(context: Context, intent: Intent) {
        Bus.post(TransportEvent.Pause)
        Bus.post(TransportEvent.SetBluetoothConnected(false))
    }

    companion object {
        private const val TAG = "BluetoothReceiver"
        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_LAST_PLAYING = "last_playing"
        private const val KEY_LAST_SONG_PATH = "last_song_path"
        private const val ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME"
    }
}