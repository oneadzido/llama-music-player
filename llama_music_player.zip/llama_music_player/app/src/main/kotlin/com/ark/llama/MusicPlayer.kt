// MusicPlayer.kt
package com.ark.llama

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.MetadataEvent
import com.ark.llama.event.PlayerEvent
import com.ark.llama.event.PlaylistEvent
import com.ark.llama.event.SettingsEvent
import com.ark.llama.event.TransportEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Renders the main playback screen and forwards user input to
 * [MusicService].
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class MusicPlayer : Activity(), NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================

    private val PERMISSION_REQUEST_CODE = 100
    private val FOLDER_SELECT_CODE = 200
    private val BATTERY_OPTIMIZATION_REQUEST_CODE = 300
    private val PREFS_NAME = "LlamaPrefs"
    private val KEY_LAST_SONG_PATH = "last_song_path"

    private val OPERATION_LIBRARY_LOAD = "LIBRARY_LOAD"
    private val LIBRARY_HEARTBEAT_INTERVAL_MS = 500L
    private val LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS = 30_000L
    private val MAX_ALBUM_ART_SIZE_PX = 1024
    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val HOME_CONFIRM_WINDOW_MS = 1000L
    private val HOME_CONFIRM_DWELL_MS = 500L
    private val RECONNECT_SERVICE_DELAY_MS = 1000L
    private val FOCUS_SCROLL_DELAY_MS = 500L
    private val TIME_UPDATE_INTERVAL_MS = 500L
    private val REPEAT_SHUFFLE_DELAY_MS = 250L
    private val BUFFER_SIZE = 8192
    private val BUTTON_ANIMATION_DURATION_MS = 80
    private val BUTTON_SCALE_DOWN = 0.97f
    private val BUTTON_SCALE_NORMAL = 1.0f
    private val ALBUM_ART_CORNER_RADIUS_DP = 10
    private val VOLUME_GESTURE_EDGE_DP = 60
    private val VOLUME_LIMIT_ECHO_STEP_FRACTION = 0.15f
    private val VOLUME_LIMIT_SIDE_NONE = 0
    private val VOLUME_LIMIT_SIDE_MAXIMUM = +1
    private val VOLUME_LIMIT_SIDE_MINIMUM = -1
    private val SPLIT_SCREEN_FULL_HEIGHT_DP = 600
    private val SPLIT_SCREEN_MIN_HEIGHT_DP = 400
    private val ALBUM_ART_FULL_DP = 300
    private val ALBUM_ART_SHRUNK_DP = 180
    private val TRANSPORT_ROW_SPLIT_BOTTOM_DP = 48

    private val MESSAGE_LIBRARY_LOAD = R.string.player_library_loading
    private val MESSAGE_LIBRARY_LOAD_FAILED = R.string.player_library_load_failed
    private val MESSAGE_SERVICE_BIND_FAILED = R.string.player_service_bind_failed

    // ========================================================================
    // UI
    // ========================================================================

    private var mSongTitle: TextView? = null
    private var mSongArtist: TextView? = null
    private var mSeekTime: TextView? = null
    private var mTotalTime: TextView? = null
    private var mSeekBar: SeekBar? = null
    private var mPlayButton: Button? = null
    private var mPrevButton: Button? = null
    private var mNextButton: Button? = null
    private var mRepeatButton: Button? = null
    private var mShuffleButton: Button? = null
    private var mManagerButton: Button? = null
    private var mLlamaButton: Button? = null
    private var mPlaylistButton: Button? = null
    private var mEqualizerButton: Button? = null
    private var mMetadataButton: Button? = null
    private var mFavoriteButton: Button? = null
    private var mHomeButton: Button? = null
    private var mAlbumArtContainer: FrameLayout? = null
    private var mAlbumArtWrapper: LinearLayout? = null
    private var mSongInfoGroup: FrameLayout? = null
    private var mTransportRow: LinearLayout? = null

    private var mDefaultSongInfoChildGravities: IntArray? = null
    private var mDefaultSongInfoPaddingTop = 0
    private var mDefaultTransportPaddingBottom = 0

    // ========================================================================
    // Managers and services
    // ========================================================================

    private var mMusicLibrary: MusicLibrary? = null
    private var mMusicService: MusicService? = null
    private var mStorageAccessHelper: StorageAccessHelper? = null

    private var mHomeReturnRunnable: Runnable? = null
    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mServiceHandler = Handler(Looper.getMainLooper())
    private var mTimeHandler: Handler? = null

    private var mIsServiceBound = false
    private var mIsUserSeeking = false

    private enum class HomeConfirmState { IDLE, ARMED, CONFIRMED }
    private var mHomeConfirmState = HomeConfirmState.IDLE

    private val mIsUpdatingUI = AtomicBoolean(false)
    @Volatile
    private var mPendingUIUpdate: Runnable? = null

    @Volatile
    private var mPendingIncomingPath: String? = null

    private val mServiceLock = Any()
    private var mLastSeenGeneration = -1L

    // ========================================================================
    // State flags
    // ========================================================================

    private var mIsPostUpdateRestart = false
    private var mIsLoadingComplete = false
    private var mInitializationAttempted = false
    private var mPermissionsDenied = false
    private var mLibraryHeartbeatRunnable: Runnable? = null
    private var mScopeEmpty = false

    // ========================================================================
    // Click debounce timestamps
    // ========================================================================

    private var mLastPlayPauseClickTime = 0L
    private var mLastNextClickTime = 0L
    private var mLastPrevClickTime = 0L
    private var mLastRepeatClickTime = 0L
    private var mLastShuffleClickTime = 0L
    private var mLastEqualizerClickTime = 0L
    private var mLastManagerClickTime = 0L
    private var mLastLlamaClickTime = 0L
    private var mLastPlaylistClickTime = 0L
    private var mLastMetadataClickTime = 0L
    private var mLastFavoriteClickTime = 0L
    private var mLastHomeClickTime = 0L

    // ========================================================================
    // Album art components
    // ========================================================================

    private var mAlbumArtCache: android.util.LruCache<String, Bitmap>? = null
    private val mAlbumArtExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mMetadataLoader: ExecutorService = Executors.newSingleThreadExecutor()
    private var mCurrentMetadataFuture: Future<*>? = null

    @Volatile private var mPlaceholderBitmap: Bitmap? = null
    @Volatile private var mOriginalPlaceholderBitmap: Bitmap? = null
    private val mPlaceholderExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var mCurrentPlaceholderTask: Future<*>? = null
    private val mPlaceholderLock = Any()

    private var mAlbumArtCarousel: AlbumArtCarousel? = null

    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper

    private var mStorageObserver: StorageObserver? = null
    private var mCachedLastSong: Song? = null
    private var mLastTapTime = 0L

    // ========================================================================
    // Gestures
    // ========================================================================

    private var mAudioManager: AudioManager? = null
    private enum class GestureState { TOUCHED, CAROUSEL, VOLUME, PLAYBACK, CANCELLED }
    private var mGestureState = GestureState.TOUCHED
    private var mGestureStartX = 0f
    private var mGestureStartY = 0f
    private var mGestureContainerWidth = 1
    private var mGestureContainerHeight = 1
    private var mVolumeGestureStartVolume = 0
    private var mVolumeGestureMaxVolume = 0
    private var mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE
    private var mVolumeGestureLimitEchoBaseline = Float.NaN

    // ========================================================================
    // Service connection
    // ========================================================================

    private val mServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            mMusicService = binder.service
            mIsServiceBound = true
            mLastSeenGeneration = -1L

            if (mPendingIncomingPath != null) {
                val pending = mPendingIncomingPath
                mPendingIncomingPath = null
                Log.d(TAG, "Handing off parked incoming path: $pending")
                if (pending != null) handOffIncomingPath(pending)
            }

            refreshTransportControls()
            loadFullPlaylistInBackground()
            refreshCarouselFromService()

            mServiceHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                if (canEnableTransportControls()) {
                    refreshTransportControls()
                    refreshCarouselFromService()
                } else {
                    applyNoSongState()
                }
            }, FOCUS_SCROLL_DELAY_MS)

            setupSeekBar()
            updateTimeDisplay()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            mIsServiceBound = false
            Log.w(TAG, "MusicService disconnected unexpectedly")
            mServiceHandler.postDelayed({
                if (!mIsServiceBound && !isFinishing && !isDestroyed) {
                    Log.d(TAG, "Attempting to reconnect to MusicService")
                    val intent = Intent(this@MusicPlayer, MusicService::class.java)
                    bindService(intent, mServiceConnection, BIND_AUTO_CREATE)
                }
            }, RECONNECT_SERVICE_DELAY_MS)
        }
    }

    // ========================================================================
    // attachBaseContext
    // ========================================================================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase)
        )
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFullScreen()
        setContentView(R.layout.activity_music_player)

        ToastManager.init(this)
        OverlayManager.init(this)

        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity()
            return
        }

        FontAwesome.init(this)
        LlamaEventBus.register(this)

        mAlbumArtCache = AlbumArtCache.getInstance(this).asLruCache()
        mThemeManager = ThemeManager.getInstance(this)
        mThemeHelper = ThemeHelper.getInstance(this)
        mStorageAccessHelper = StorageAccessHelper.getInstance(this)
        mAudioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        mIsPostUpdateRestart = intent.getBooleanExtra("is_post_update_restart", false)
        if (mIsPostUpdateRestart) MusicService.clearPlayerStateBeforeUpdate(this)

        mMusicLibrary = MusicLibrary(this)
        initializeViews()
        setupListeners()
        checkPermissionsAndInitialize()

        mStorageObserver = StorageObserver(this).also { it.startObserving() }

        applyThemeToUI()
        NavigationController.getInstance().registerListener(this)
    }

    override fun onResume() {
        super.onResume()

        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }
        mStorageObserver?.setActivity(this)
        onButtonStateChanged(
            NavigationController.ButtonGroup.FOLDER_ACTIONS,
            NavigationController.getInstance().isGroupDisabled(
                NavigationController.ButtonGroup.FOLDER_ACTIONS
            )
        )

        val permissionsGranted = PermissionChecker.allGranted(this)
        if (permissionsGranted && mMusicService != null && mMusicLibrary != null &&
            (mMusicLibrary?.getSongCount() ?: 0) > 0
        ) {
            refreshTransportControls()
            refreshCarouselFromService()
        }

        applyThemeToUI()
        ToastManager.refreshThemeColor()

        if (!mIsLoadingComplete && !ToastManager.hasPersistentToast()) {
            mIsLoadingComplete = true
            ToastManager.showPersistentOverlay(
                this,
                getString(MESSAGE_LIBRARY_LOAD),
                "",
                OPERATION_LIBRARY_LOAD
            )
        }
        ensureLibraryLoadHeartbeat()

        if (!permissionsGranted) {
            if (!mPermissionsDenied) {
                mPermissionsDenied = true
                applyNoSongState()
            }
            return
        }

        if (mPermissionsDenied) {
            mPermissionsDenied = false
            if (mInitializationAttempted) {
                mInitializationAttempted = false
                mMusicLibrary?.invalidate()
            }
        }

        if (!mInitializationAttempted) proceedWithInitialization()
    }

    override fun onRestart() {
        super.onRestart()
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        mTimeHandler?.removeCallbacksAndMessages(null); mTimeHandler = null
        mServiceHandler.removeCallbacksAndMessages(null)
        if (!mAlbumArtExecutor.isShutdown) mAlbumArtExecutor.shutdownNow()
        if (!mMetadataLoader.isShutdown) mMetadataLoader.shutdownNow()
        mCurrentPlaceholderTask?.cancel(true); mCurrentPlaceholderTask = null
        if (!mPlaceholderExecutor.isShutdown) mPlaceholderExecutor.shutdownNow()
        mCurrentMetadataFuture?.cancel(true); mCurrentMetadataFuture = null
        mAlbumArtCarousel?.clear(); mAlbumArtCarousel = null
        mAlbumArtCache = null
        mPendingUIUpdate = null
        mMusicLibrary?.shutdown(); mMusicLibrary = null
        NavigationController.getInstance().unregisterListener(this)
        mMusicService?.savePlayerState()
        mStorageObserver?.stopObserving()
        if (mIsServiceBound) try { unbindService(mServiceConnection) } catch (ignored: Exception) {}
        cancelReturnHome()
        LlamaEventBus.unregister(this)
        mMainHandler.removeCallbacksAndMessages(null)
        cleanupPlaceholderBitmaps()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (mMusicService != null && mIsServiceBound) {
            try { mMusicService?.onTrimMemory(level) } catch (e: Exception) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e)
            }
        }
        if (level >= TRIM_MEMORY_BACKGROUND) mAlbumArtCache?.evictAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("close_app", false)) finishAffinity()
        else handleIncomingFile(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onConfigurationChanged(config: Configuration) {
        super.onConfigurationChanged(config)
        applyAlbumArtSize(config)
        forceRedraw()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN &&
            event.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        ) {
            resumeIfPausedAtMaxVolumeIfFocused()
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlayPause(); return true }
            KeyEvent.KEYCODE_MEDIA_NEXT -> { playNextSong(); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { playPreviousSong(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun resumeIfPausedAtMaxVolumeIfFocused() {
        val am = mAudioManager ?: return
        if (mMusicService == null || !mIsServiceBound) return
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max <= 0) return
            val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (current < max) return
            val service = mMusicService ?: return
            if (!service.isPausedOrReady()) return
            if (!service.hasAudioFocus()) {
                Log.d(TAG, "Volume-up at max while another app holds focus; not resuming")
                return
            }
            service.resume()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to resume on volume-up at max", e)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            val treeUri = data.data
            if (treeUri != null && mStorageAccessHelper != null) {
                val folderPath = mStorageAccessHelper?.getFolderPathFromUri(treeUri)
                mStorageAccessHelper?.storeFolderPermission(treeUri, folderPath)
                mMusicLibrary?.addFolder(treeUri.toString())
                cleanLooseSongsInFolder(treeUri)
                mStorageAccessHelper?.getFolderNameFromUri(treeUri)?.let { folderName ->
                    ToastManager.showToast(
                        this,
                        getString(R.string.folder_manager_imported_toast, folderName),
                        ToastManager.LENGTH_NORMAL
                    )
                }
            }
        } else if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                val isOptimized = pm.isIgnoringBatteryOptimizations(packageName)
                showBatteryOptimizationToast(isOptimized)
            }
        }
    }

    private fun showBatteryOptimizationToast(optimized: Boolean) {
        ToastManager.hidePersistentOverlay()
        mMainHandler.postDelayed({
            if (!isFinishing && !isDestroyed) {
                val msgRes = if (optimized) R.string.player_battery_optimized
                else R.string.player_battery_restricted
                ToastManager.showToast(this, getString(msgRes), ToastManager.LENGTH_NORMAL)
            }
        }, 150L)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.isNotEmpty() &&
                grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (allGranted) {
                mPermissionsDenied = false
            } else {
                ToastManager.showToast(
                    this,
                    getString(R.string.player_permissions_required),
                    ToastManager.LENGTH_NORMAL
                )
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
                OverlayManager.hide(OverlayManager.REASON_COLD_START)
                mPermissionsDenied = true
                applyNoSongState()
            }
        }
    }

    // ========================================================================
    // LlamaEventBus subscribers
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        if (!isFinishing && !isDestroyed) recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onPlayerSnapshot(event: PlayerEvent.Snapshot) {
        if (event.scopeCount == 0) {
            if (!mScopeEmpty) {
                mScopeEmpty = true
                runOnUiThread { applyNoSongState() }
            }
            return
        } else if (event.scopeCount > 0) {
            mScopeEmpty = false
        }

        if (event.generation >= 0L) {
            if (event.generation < mLastSeenGeneration) return
            if (event.generation > mLastSeenGeneration) {
                mLastSeenGeneration = event.generation
            }
        }

        val displayTitle: String? = event.displayTitle
        val displayArtist: String? = event.displayArtist
        val positionMs: Int = event.positionMs
        val durationMs: Int = event.durationMs
        val direction: Int = event.transitionDirection
        val restart: Boolean = event.transitionRestart
        val windowSnapshot: PlaybackWindow = event.window

        // The commit runnable is declared as a standalone `val` with an
        // explicit `Runnable` type *before* the outer runnable is
        // constructed. This breaks the recursive type-inference chain:
        // `updateUISafely(outerUpdate)` would otherwise infer
        // `outerUpdate`'s parameter type from a body that itself
        // references `commit`, whose type would be inferred from
        // `carousel.postOnSettle(commit)`, which is a SAM parameter
        // that the compiler tries to infer from the same lambda graph.
        // Hoisting `commit` out and pinning its type with an explicit
        // `Runnable` annotation leaves no inference cycle.
        val commitRunnable: Runnable = Runnable {
            if (isFinishing || isDestroyed) return@Runnable
            refreshTransportControls()
            mSeekBar?.let { bar ->
                if (bar.isEnabled && durationMs > 0) {
                    if (bar.max != durationMs) bar.max = durationMs
                    bar.progress = positionMs
                }
            }
            mSongTitle?.let { tv ->
                if (displayTitle != null) {
                    tv.text = displayTitle
                    tv.setTextColor(mThemeHelper.themeColorInt)
                }
            }
            mSongArtist?.let { tv ->
                if (displayArtist != null) {
                    tv.text = displayArtist
                    tv.setTextColor(Color.parseColor("#C0C0C0"))
                }
            }
            setupSeekBar()
        }

        val outerUpdate: Runnable = Runnable {
            val carousel = mAlbumArtCarousel ?: return@Runnable
            val committedSynchronously =
                carousel.setWindow(windowSnapshot, direction, restart)
            if (committedSynchronously) commitRunnable.run()
            else carousel.postOnSettle(commitRunnable)
        }
        updateUISafely(outerUpdate)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaylistLibraryReset(event: PlaylistEvent.LibraryReset) {
        mPendingIncomingPath = null
        mIsUserSeeking = false
        mLastSeenGeneration = -1L
        mCurrentMetadataFuture?.cancel(true); mCurrentMetadataFuture = null
        mCachedLastSong = null
        mMusicLibrary?.invalidate()
        runOnUiThread {
            applyNoSongState()
            if (!event.preserveSettings) {
                mMusicService?.setRepeatMode(0)
                mMusicService?.setShuffle(false)
            }
            refreshTransportControls()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMetadataUpdated(event: MetadataEvent.Updated) {
        val path = event.songPath ?: resolveSongPathFromMetadata(event) ?: return
        mMusicService?.refreshMetadataForSong(
            path, event.title, event.artist, event.album, event.genre,
            event.songUri, event.albumArtBytes, event.albumArtRemoved
        )
        mMusicLibrary?.refreshCache()
        mAlbumArtCarousel?.invalidatePath(path)
        val current = mMusicService?.getCurrentSong()
        val editedIsCurrent = current != null && current.path == path
        if (!editedIsCurrent) LlamaEventBus.post(PlaylistEvent.Display)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onSyncStarted(event: PlaylistEvent.SyncStarted) {
        if (ToastManager.hasPersistentToast()) {
            ToastManager.ensureOverlayAttached(this)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onSyncComplete(event: PlaylistEvent.SyncComplete) {
        Log.d(TAG, "Sync complete")
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaylistRefresh(event: PlaylistEvent.Refresh) {
        if (mMusicService == null || mMusicLibrary == null) return
        mMusicLibrary?.refreshCache()
        val songs = mMusicLibrary?.getAllSongs()
        if (songs != null && songs.isNotEmpty()) {
            mMusicService?.setPlaylist(songs, true)
            runOnUiThread {
                refreshTransportControls()
                setupSeekBar()
                updateTimeDisplay()
            }
        } else {
            mMusicService?.stop()
            mMusicService?.setPlaylist(null, false)
            mMusicLibrary?.refreshCache()
            runOnUiThread {
                applyNoSongState()
                ToastManager.hidePersistentOverlay()
            }
        }
    }

    // ========================================================================
    // NavigationController listener
    // ========================================================================

    override fun onButtonStateChanged(
        group: NavigationController.ButtonGroup,
        disabled: Boolean
    ) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            runOnUiThread {
                mPlaylistButton?.let {
                    it.isEnabled = !disabled
                    mThemeHelper.updateButton(it, !disabled)
                }
                mMetadataButton?.let {
                    it.isEnabled = !disabled
                    mThemeHelper.updateButton(it, !disabled)
                }
            }
        }
    }

    // ========================================================================
    // Full screen
    // ========================================================================

    @Suppress("DEPRECATION")
    private fun setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.statusBarColor = resources.getColor(R.color.backgroundDark, null)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark, null)
            } else {
                window.statusBarColor = resources.getColor(R.color.backgroundDark)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    // ========================================================================
    // View init
    // ========================================================================

    private fun initializeViews() {
        mSongTitle = findViewById(R.id.songTitle)
        mSongArtist = findViewById(R.id.songArtist)
        mSeekTime = findViewById(R.id.seekTime)
        mTotalTime = findViewById(R.id.totalTime)
        mSeekBar = findViewById(R.id.seekBar)
        mPlayButton = findViewById(R.id.playButton)
        mPrevButton = findViewById(R.id.prevButton)
        mNextButton = findViewById(R.id.nextButton)
        mRepeatButton = findViewById(R.id.repeatButton)
        mShuffleButton = findViewById(R.id.shuffleButton)
        mManagerButton = findViewById(R.id.managerButton)
        mLlamaButton = findViewById(R.id.llamaButton)
        mPlaylistButton = findViewById(R.id.playlistButton)
        mEqualizerButton = findViewById(R.id.equalizerButton)
        mMetadataButton = findViewById(R.id.metadataButton)
        mFavoriteButton = findViewById(R.id.favoriteButton)
        mHomeButton = findViewById(R.id.homeButton)
        mAlbumArtContainer = findViewById(R.id.albumArtContainer)
        mAlbumArtWrapper = findViewById(R.id.albumArtWrapper)
        mSongInfoGroup = findViewById(R.id.songInfoGroup)
        mTransportRow = findViewById(R.id.transportRow)

        mSongInfoGroup?.let { group ->
            mDefaultSongInfoPaddingTop = group.paddingTop
            mDefaultSongInfoChildGravities = IntArray(group.childCount) { i ->
                val lp = group.getChildAt(i).layoutParams
                if (lp is FrameLayout.LayoutParams) lp.gravity else Gravity.CENTER_VERTICAL
            }
        }
        mTransportRow?.let { mDefaultTransportPaddingBottom = it.paddingBottom }

        mAlbumArtContainer?.let { container ->
            mAlbumArtCache?.let { cache ->
                mAlbumArtCarousel = AlbumArtCarousel(this, container, cache, mAlbumArtExecutor).apply {
                    setEdgeZonePx(dpToPx(VOLUME_GESTURE_EDGE_DP))
                    setSwipeCommitListener(object : AlbumArtCarousel.SwipeCommitListener {
                        override fun onSwipeCommitted(direction: Int) {
                            if (direction > 0) playNextSong()
                            else if (direction < 0) playPreviousSong()
                        }
                    })
                    attach()
                }
            }
        }

        applyAlbumArtClipping()
        setupAlbumArtGestures()

        val fa = FontAwesome.getTypeface()
        mPlayButton?.apply { typeface = fa; text = FontAwesome.PLAY; textSize = 36f }
        mPrevButton?.apply { typeface = fa; text = FontAwesome.BACKWARD; textSize = 32f }
        mNextButton?.apply { typeface = fa; text = FontAwesome.FORWARD; textSize = 32f }
        mShuffleButton?.apply { typeface = fa; text = FontAwesome.SHUFFLE; textSize = 28f }
        mRepeatButton?.apply { typeface = fa; text = FontAwesome.REPEAT; textSize = 28f }
        mFavoriteButton?.apply {
            typeface = fa; text = FontAwesome.HEART; textSize = 30f
            mThemeHelper.updateControlButton(this, true, false)
        }
        mHomeButton?.apply {
            typeface = fa; text = FontAwesome.HOME; textSize = 28f
            mThemeHelper.updateControlButton(this, true, false)
        }

        mPlayButton?.setBackgroundResource(R.drawable.control_button_selector)
        mPrevButton?.setBackgroundResource(R.drawable.control_button_selector)
        mNextButton?.setBackgroundResource(R.drawable.control_button_selector)
        mRepeatButton?.setBackgroundResource(R.drawable.control_button_selector)
        mShuffleButton?.setBackgroundResource(R.drawable.control_button_selector)
        mManagerButton?.setBackgroundResource(R.drawable.button_border_selector)
        mLlamaButton?.setBackgroundResource(R.drawable.button_border_selector)
        mPlaylistButton?.setBackgroundResource(R.drawable.button_border_selector)
        mEqualizerButton?.setBackgroundResource(R.drawable.button_border_selector)
        mMetadataButton?.setBackgroundResource(R.drawable.button_border_selector)

        mManagerButton?.letterSpacing = 0.1f
        mLlamaButton?.letterSpacing = 0.1f
        mPlaylistButton?.letterSpacing = 0.1f
        mEqualizerButton?.letterSpacing = 0.1f
        mMetadataButton?.letterSpacing = 0.1f

        animateButton(mPlayButton)
        animateButton(mPrevButton)
        animateButton(mNextButton)
        animateButton(mRepeatButton)
        animateButton(mShuffleButton)
        animateButton(mManagerButton)
        animateButton(mLlamaButton)
        animateButton(mPlaylistButton)
        animateButton(mEqualizerButton)
        animateButton(mMetadataButton)
        animateButton(mFavoriteButton)
        animateButton(mHomeButton)

        applyAlbumArtSize(resources.configuration)
        loadAndDisplayPlaceholder()
        refreshTransportControls()
    }

    private fun refreshCarouselFromService() {
        val service = mMusicService ?: return
        val carousel = mAlbumArtCarousel ?: return
        carousel.setWindow(service.getWindowSnapshot(), 0, false)
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(BUTTON_SCALE_DOWN)
                    .scaleY(BUTTON_SCALE_DOWN)
                    .setDuration(BUTTON_ANIMATION_DURATION_MS.toLong()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL)
                    .setDuration(BUTTON_ANIMATION_DURATION_MS.toLong()).start()
            }
            false
        }
    }

    // ========================================================================
    // Split-screen
    // ========================================================================

    private fun applyAlbumArtSize(config: Configuration) {
        val container = mAlbumArtContainer ?: return
        val heightDp = config.screenHeightDp
        val sizeDp: Int
        val visibility: Int
        when {
            heightDp >= SPLIT_SCREEN_FULL_HEIGHT_DP -> { sizeDp = ALBUM_ART_FULL_DP; visibility = View.VISIBLE }
            heightDp >= SPLIT_SCREEN_MIN_HEIGHT_DP -> { sizeDp = ALBUM_ART_SHRUNK_DP; visibility = View.VISIBLE }
            else -> { sizeDp = ALBUM_ART_SHRUNK_DP; visibility = View.GONE }
        }
        val sizePx = dpToPx(sizeDp)
        val params = container.layoutParams
        if (params.width != sizePx || params.height != sizePx) {
            params.width = sizePx; params.height = sizePx
            container.layoutParams = params
        }
        if (container.visibility != visibility) container.visibility = visibility
        applySongInfoLayout(visibility == View.GONE)
        mAlbumArtCarousel?.onContainerResized()
    }

    private fun applySongInfoLayout(albumArtHidden: Boolean) {
        mAlbumArtWrapper?.visibility = if (albumArtHidden) View.GONE else View.VISIBLE

        mSongInfoGroup?.let { group ->
            val albumArtTopOffset = mAlbumArtWrapper?.paddingTop ?: 0
            val desiredTop = if (albumArtHidden) albumArtTopOffset else mDefaultSongInfoPaddingTop
            if (group.paddingTop != desiredTop) {
                group.setPadding(group.paddingLeft, desiredTop, group.paddingRight, group.paddingBottom)
            }
            val defaultGravities = mDefaultSongInfoChildGravities ?: return@let
            val horizontalMask = Gravity.LEFT or Gravity.RIGHT or
                Gravity.START or Gravity.END or Gravity.CENTER_HORIZONTAL
            for (i in 0 until group.childCount) {
                val child = group.getChildAt(i)
                val lp = child.layoutParams as? FrameLayout.LayoutParams ?: continue
                val default = if (i < defaultGravities.size) defaultGravities[i]
                else Gravity.CENTER_VERTICAL
                val target = if (albumArtHidden) (default and horizontalMask) or Gravity.TOP
                else default
                if (lp.gravity != target) { lp.gravity = target; child.layoutParams = lp }
            }
        }

        mTransportRow?.let { row ->
            val desired = if (albumArtHidden) dpToPx(TRANSPORT_ROW_SPLIT_BOTTOM_DP)
            else mDefaultTransportPaddingBottom
            if (row.paddingBottom != desired) {
                row.setPadding(row.paddingLeft, row.paddingTop, row.paddingRight, desired)
            }
        }
    }

    // ========================================================================
    // Album-art gestures
    // ========================================================================

    private fun setupAlbumArtGestures() {
        mAlbumArtContainer?.setOnTouchListener { view, event -> handleAlbumArtGesture(view, event) }
    }

    private fun handleAlbumArtGesture(view: View, event: MotionEvent): Boolean {
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> handleGestureDown(view, event)
            MotionEvent.ACTION_MOVE -> handleGestureMove(view, event)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handleGestureUp(view, event)
            else -> false
        }
    }

    private fun handleGestureDown(view: View, event: MotionEvent): Boolean {
        mGestureState = GestureState.TOUCHED
        mGestureStartX = event.x
        mGestureStartY = event.y
        mGestureContainerWidth = Math.max(1, view.width)
        mGestureContainerHeight = Math.max(1, view.height)

        mAudioManager?.let { am ->
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max > 0) {
                mVolumeGestureMaxVolume = max
                mVolumeGestureStartVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            } else {
                mVolumeGestureMaxVolume = 0; mVolumeGestureStartVolume = 0
            }
        } ?: run { mVolumeGestureMaxVolume = 0; mVolumeGestureStartVolume = 0 }

        mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE
        mVolumeGestureLimitEchoBaseline = Float.NaN

        view.parent?.requestDisallowInterceptTouchEvent(true)
        return true
    }

    private fun handleGestureMove(view: View, event: MotionEvent): Boolean {
        if (mGestureState == GestureState.TOUCHED) classifyGesture(event)
        when (mGestureState) {
            GestureState.CAROUSEL -> {
                mAlbumArtCarousel?.updateSwipe(event.x - mGestureStartX)
                return true
            }
            GestureState.VOLUME -> { handleVolumeDrag(event); return true }
            GestureState.PLAYBACK, GestureState.CANCELLED, GestureState.TOUCHED -> return true
        }
    }

    private fun handleGestureUp(view: View, event: MotionEvent): Boolean {
        when {
            mGestureState == GestureState.CAROUSEL -> {
                val displacement = if (event.actionMasked == MotionEvent.ACTION_CANCEL) 0f
                else event.x - mGestureStartX
                mAlbumArtCarousel?.endSwipe(displacement)
                cancelReturnHome()
            }
            mGestureState == GestureState.PLAYBACK &&
                event.actionMasked == MotionEvent.ACTION_UP -> {
                handlePlaybackGesture(event.y - mGestureStartY)
            }
            mGestureState == GestureState.TOUCHED &&
                event.actionMasked == MotionEvent.ACTION_UP -> {
                val tapTime = event.eventTime
                if (tapTime - mLastTapTime <= ViewConfiguration.getDoubleTapTimeout()) {
                    handleGestureDoubleTap()
                    mLastTapTime = 0L
                } else mLastTapTime = tapTime
            }
        }
        view.parent?.requestDisallowInterceptTouchEvent(false)
        mGestureState = GestureState.TOUCHED
        return true
    }

    private fun handleGestureDoubleTap() {
        synchronized(mServiceLock) {
            val service = mMusicService ?: return
            if (!mIsServiceBound) return
            val current = service.getCurrentSong() ?: return
            val newFavorite = !current.isFavorite
            service.toggleFavorite()
            ToastManager.showToast(
                this,
                getString(if (newFavorite) R.string.player_toast_favorite_on
                else R.string.player_toast_favorite_off),
                ToastManager.LENGTH_NORMAL
            )
        }
    }

    private fun classifyGesture(event: MotionEvent) {
        val dx = event.x - mGestureStartX
        val dy = event.y - mGestureStartY
        val absX = Math.abs(dx)
        val absY = Math.abs(dy)
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        if (absX < slop && absY < slop) return

        if (absX > absY) {
            mGestureState = GestureState.CAROUSEL
            mAlbumArtCarousel?.beginSwipe()
            return
        }

        val edgeZone = dpToPx(VOLUME_GESTURE_EDGE_DP)
        val startedInEdge = mGestureStartX <= edgeZone ||
            mGestureStartX >= mGestureContainerWidth - edgeZone
        if (startedInEdge) {
            mGestureState = if (mVolumeGestureMaxVolume > 0) GestureState.VOLUME
            else GestureState.CANCELLED
            return
        }
        mGestureState = GestureState.PLAYBACK
    }

    private fun handleVolumeDrag(event: MotionEvent) {
        val am = mAudioManager ?: return
        if (mVolumeGestureMaxVolume <= 0) return
        val dy = event.y - mGestureStartY
        val fraction = -dy / mGestureContainerHeight
        val unclampedTarget = mVolumeGestureStartVolume + fraction * mVolumeGestureMaxVolume
        var target = Math.round(unclampedTarget)
        target = Math.max(0, Math.min(mVolumeGestureMaxVolume, target))

        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)

        if (target == mVolumeGestureMaxVolume) {
            if (mVolumeGestureLimitSide != VOLUME_LIMIT_SIDE_MAXIMUM) {
                mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_MAXIMUM
                mVolumeGestureLimitEchoBaseline = Float.NaN
            }
        } else if (target == 0) {
            if (mVolumeGestureLimitSide != VOLUME_LIMIT_SIDE_MINIMUM) {
                mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_MINIMUM
                mVolumeGestureLimitEchoBaseline = Float.NaN
            }
        } else {
            mVolumeGestureLimitSide = VOLUME_LIMIT_SIDE_NONE
            mVolumeGestureLimitEchoBaseline = Float.NaN
        }

        if (target != current) {
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                showVolumeToast(target)
            } catch (e: SecurityException) { Log.w(TAG, "setStreamVolume refused", e) }
            if (target == mVolumeGestureMaxVolume) {
                mVolumeGestureLimitEchoBaseline = Math.max(0f, unclampedTarget - mVolumeGestureMaxVolume)
            } else if (target == 0) {
                mVolumeGestureLimitEchoBaseline = Math.max(0f, -unclampedTarget)
            }
            return
        }

        val echoStep = Math.max(1f, mVolumeGestureMaxVolume * VOLUME_LIMIT_ECHO_STEP_FRACTION)
        if (target == mVolumeGestureMaxVolume && mVolumeGestureLimitSide == VOLUME_LIMIT_SIDE_MAXIMUM) {
            val overshoot = unclampedTarget - mVolumeGestureMaxVolume
            val baseline = if (mVolumeGestureLimitEchoBaseline.isNaN()) -echoStep
            else mVolumeGestureLimitEchoBaseline
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot
                showVolumeToast(target)
            }
        } else if (target == 0 && mVolumeGestureLimitSide == VOLUME_LIMIT_SIDE_MINIMUM) {
            val overshoot = -unclampedTarget
            val baseline = if (mVolumeGestureLimitEchoBaseline.isNaN()) -echoStep
            else mVolumeGestureLimitEchoBaseline
            if (overshoot >= baseline + echoStep) {
                mVolumeGestureLimitEchoBaseline = overshoot
                showVolumeToast(target)
            }
        }
    }

    private fun handlePlaybackGesture(dy: Float) {
        val threshold = ViewConfiguration.get(this).scaledTouchSlop * 2
        if (Math.abs(dy) < threshold) return
        cancelReturnHome()
        synchronized(mServiceLock) {
            val service = mMusicService ?: return
            if (!mIsServiceBound) return
            try {
                if (dy < 0) {
                    if (!service.isPlaying && service.isPausedOrReady()) {
                        service.requestResumeFromGesture()
                    }
                } else {
                    if (service.isPlaying) service.togglePlayPause()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to handle playback gesture", e)
            }
        }
    }

    private fun showVolumeToast(volume: Int) {
        if (mVolumeGestureMaxVolume <= 0) return
        val percent = Math.round(100f * volume / mVolumeGestureMaxVolume)
        ToastManager.showToast(
            this,
            getString(R.string.player_toast_volume, percent),
            ToastManager.LENGTH_NORMAL
        )
    }

    // ========================================================================
    // Permission and initialization
    // ========================================================================

    private fun checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            proceedWithInitialization(); return
        }
        val missing = PermissionChecker.getMissing(this)
        if (missing.isNotEmpty()) requestPermissions(missing, PERMISSION_REQUEST_CODE)
        else proceedWithInitialization()
    }

    private fun proceedWithInitialization() {
        mInitializationAttempted = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) requestBatteryOptimization()
        preloadLastSongDisplay()

        if (mMusicService != null && mIsServiceBound) {
            loadFullPlaylistInBackground()
            handleIncomingFile(intent)
            return
        }

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        val bound = bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE)
        if (!bound) {
            Log.e(TAG, "bindService refused; abandoning library load")
            abandonLibraryLoadOverlay(MESSAGE_SERVICE_BIND_FAILED)
            return
        }
        handleIncomingFile(intent)
    }

    private fun requestBatteryOptimization() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
                startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to request battery optimization", e)
            }
        }
    }

    // ========================================================================
    // Incoming file
    // ========================================================================

    private fun handleIncomingFile(intent: Intent?) {
        if (intent == null || intent.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        val path = getFilePathFromUri(uri)
        if (path == null || !File(path).exists()) {
            Log.w(TAG, "File not found or inaccessible: $path"); return
        }
        Log.d(TAG, "Handling incoming file: $path")
        if (isSongInLibrary(path)) { handOffIncomingPath(path); return }
        Log.d(TAG, "New song detected; adding as a loose track")
        handOffIncomingPath(path)
        preDecodeIncomingArt(path)
        val newSong = parseIncomingSong(path)
        insertLooseTrackAndHandOff(newSong)
    }

    private fun isSongInLibrary(path: String): Boolean {
        if (SongDatabase.getInstance(this).hasSong(path)) return true
        return SongDatabase.getInstance(this).getLooseSongs().any { it.path == path }
    }

    private fun parseIncomingSong(path: String): Song {
        return CharacterMapper.getSongFromFile(path) ?: run {
            var name = File(path).name
            val dot = name.lastIndexOf(".")
            if (dot > 0) name = name.substring(0, dot)
            Song(name, null, null, null, path, 0L, null)
        }
    }

    private fun insertLooseTrackAndHandOff(song: Song) {
        val path = song.path
        PlaylistManager.getInstance(this).addLooseTrackAndUpdate(
            song,
            object : PlaylistManager.UpdateCallback {
                override fun onProgress(current: Int, total: Int) {}
                override fun onComplete(songCount: Int) {
                    Log.d(TAG, "Loose track inserted: $path")
                }
                override fun onError(error: String) {
                    Log.e(TAG, "Failed to insert loose track: $error")
                    mPendingIncomingPath = null
                    if (mMusicService != null && mIsServiceBound) {
                        mMusicService?.clearPendingSongPath()
                    }
                    ToastManager.showToast(
                        this@MusicPlayer,
                        getString(R.string.folder_manager_error, error),
                        ToastManager.LENGTH_NORMAL
                    )
                }
            }
        )
    }

    private fun handOffIncomingPath(path: String) {
        Log.d(TAG, "Handing off incoming path: $path")
        if (mMusicService != null && mIsServiceBound) {
            mMusicService?.requestIncomingFile(path)
            return
        }
        mPendingIncomingPath = path
    }

    private fun preDecodeIncomingArt(path: String) {
        if (mMetadataLoader.isShutdown) return
        mMetadataLoader.execute {
            if (Thread.currentThread().isInterrupted) return@execute
            loadSongMetadata(path)
            val decoded = mAlbumArtCache?.get(path) ?: return@execute
            if (decoded.isRecycled) return@execute
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                mAlbumArtCarousel?.onArtReady(path, decoded)
            }
        }
    }

    // ========================================================================
    // URI helper
    // ========================================================================

    private fun getFilePathFromUri(uri: Uri): String? {
        when (uri.scheme) {
            "file" -> return uri.path
            "content" -> {
                var path: String? = null
                var cursor: Cursor? = null
                try {
                    cursor = contentResolver.query(uri,
                        arrayOf(android.provider.MediaStore.Audio.Media.DATA),
                        null, null, null)
                    if (cursor != null && cursor.moveToFirst()) {
                        path = cursor.getString(cursor.getColumnIndexOrThrow(
                            android.provider.MediaStore.Audio.Media.DATA))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaStore query failed; falling back to copy", e)
                } finally { cursor?.close() }
                return path ?: copyContentUriToTempFile(uri)
            }
            else -> return null
        }
    }

    private fun copyContentUriToTempFile(uri: Uri): String? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            val out = File(cacheDir, "temp_audio_${SystemClock.elapsedRealtime()}.mp3")
            val stream = FileOutputStream(out)
            val buf = ByteArray(BUFFER_SIZE)
            var n: Int
            while (input.read(buf).also { n = it } != -1) stream.write(buf, 0, n)
            input.close(); stream.close()
            out.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy URI to temp file", e); null
        }
    }

    private fun cleanLooseSongsInFolder(folderUri: Uri) {
        val path = mStorageAccessHelper?.getFolderPathFromUri(folderUri) ?: return
        val normalized = if (path.endsWith("/")) path else "$path/"
        val loose = SongDatabase.getInstance(this).getLooseSongs()
        for (s in loose) {
            if (s.path.startsWith(normalized)) {
                SongDatabase.getInstance(this).removeLooseSong(s.path)
            }
        }
    }

    // ========================================================================
    // Playlist loading
    // ========================================================================

    private fun loadFullPlaylistInBackground() {
        val library = mMusicLibrary ?: return
        OverlayManager.show(OverlayManager.REASON_COLD_START)
        library.loadAllSongsWithProgress(object : MusicLibrary.LoadProgressListener {
            override fun onLoadProgress(currentCount: Int) {
                if (OPERATION_LIBRARY_LOAD == ToastManager.getCurrentOperationId()) {
                    ToastManager.updatePersistentOverlay(
                        getString(MESSAGE_LIBRARY_LOAD), "", OPERATION_LIBRARY_LOAD
                    )
                }
            }
            override fun onLoadComplete(songs: ArrayList<Song>) {
                mMusicService?.setPlaylist(songs, true)
                refreshCarouselFromService()
                refreshTransportControls()
                setupSeekBar()
                updateTimeDisplay()
                if (songs.isEmpty() && !mMusicLibrary?.getSelectedFolders().isNullOrEmpty() &&
                    !isFinishing && !isDestroyed
                ) {
                    triggerAutomaticFolderUpdate(); return
                }
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
                OverlayManager.hide(OverlayManager.REASON_COLD_START)
            }
            override fun onLoadError(error: String) {
                Log.e(TAG, "Error loading full playlist: $error")
                ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
                OverlayManager.hide(OverlayManager.REASON_COLD_START)
            }
        })
    }

    private fun triggerAutomaticFolderUpdate() {
        PlaylistManager.getInstance(this).updatePlaylist(
            object : PlaylistManager.UpdateCallback {
                override fun onProgress(current: Int, total: Int) {}
                override fun onComplete(songCount: Int) {
                    Log.d(TAG, "Automatic folder update complete: $songCount songs")
                    ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
                    OverlayManager.hide(OverlayManager.REASON_COLD_START)
                    LlamaEventBus.post(PlaylistEvent.Refresh)
                }
                override fun onError(error: String) {
                    Log.e(TAG, "Automatic folder update failed: $error")
                    ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
                    OverlayManager.hide(OverlayManager.REASON_COLD_START)
                }
            }
        )
    }

    private fun ensureLibraryLoadHeartbeat() {
        if (mLibraryHeartbeatRunnable != null) return
        val startedAt = SystemClock.elapsedRealtime()
        val runnable = object : Runnable {
            override fun run() {
                if (OPERATION_LIBRARY_LOAD != ToastManager.getCurrentOperationId()) {
                    mLibraryHeartbeatRunnable = null; return
                }
                if (SystemClock.elapsedRealtime() - startedAt > LIBRARY_LOAD_HEARTBEAT_DEADLINE_MS) {
                    Log.w(TAG, "Library load heartbeat deadline exceeded; abandoning overlay")
                    mLibraryHeartbeatRunnable = null
                    abandonLibraryLoadOverlay(MESSAGE_LIBRARY_LOAD_FAILED); return
                }
                ToastManager.heartbeat(OPERATION_LIBRARY_LOAD)
                mMainHandler.postDelayed(this, LIBRARY_HEARTBEAT_INTERVAL_MS)
            }
        }
        mLibraryHeartbeatRunnable = runnable
        mMainHandler.postDelayed(runnable, LIBRARY_HEARTBEAT_INTERVAL_MS)
    }

    private fun abandonLibraryLoadOverlay(msgRes: Int) {
        ToastManager.hidePersistentOverlay(OPERATION_LIBRARY_LOAD)
        OverlayManager.hide(OverlayManager.REASON_COLD_START)
        if (!isFinishing && !isDestroyed) {
            ToastManager.showToast(this, getString(msgRes), ToastManager.LENGTH_NORMAL)
        }
    }

    // ========================================================================
    // UI update
    // ========================================================================

    private fun updateUISafely(update: Runnable) {
        if (isFinishing || isDestroyed) return
        if (!mIsUpdatingUI.compareAndSet(false, true)) {
            mPendingUIUpdate = update; return
        }
        runOnUiThread {
            try { if (!isFinishing && !isDestroyed) update.run() }
            finally {
                mIsUpdatingUI.set(false)
                mPendingUIUpdate?.let {
                    mPendingUIUpdate = null
                    updateUISafely(it)
                }
            }
        }
    }

    private fun applyNoSongState() {
        mSongTitle?.text = getString(R.string.player_placeholder_title)
        mSongTitle?.setTextColor(mThemeHelper.themeColorInt)
        mSongArtist?.text = getString(R.string.player_placeholder_artist)
        mSongArtist?.setTextColor(Color.parseColor("#C0C0C0"))
        mAlbumArtCarousel?.setWindow(PlaybackWindow.EMPTY, 0, false)
        mAlbumArtContainer?.let {
            if (mPlaceholderBitmap?.isRecycled == false) {
                mAlbumArtCarousel?.setPlaceholder(mPlaceholderBitmap)
            } else loadAndDisplayPlaceholder()
            mAlbumArtCache?.evictAll()
        }
        applyAlbumArtClipping()
        mSeekBar?.progress = 0
        mSeekBar?.max = 100
        refreshTransportControls()
        mSeekTime?.text = getString(R.string.player_time_zero)
        mTotalTime?.text = getString(R.string.player_time_zero)
        mCachedLastSong = null
    }

    private fun resolveSongPathFromMetadata(event: MetadataEvent.Updated): String? {
        event.songPath?.takeIf { it.isNotEmpty() }?.let { return it }
        val uri = event.songUri?.takeIf { it.isNotEmpty() } ?: return null
        return try {
            SongDatabase.getInstance(this).getAllSongs().firstOrNull { it.uri == uri }?.path
        } catch (e: Exception) {
            Log.w(TAG, "resolveSongPathFromMetadata failed", e); null
        }
    }

    // ========================================================================
    // Playback control
    // ========================================================================

    private fun callServiceSafely(action: () -> Unit) {
        synchronized(mServiceLock) {
            if (mMusicService != null && mIsServiceBound) action()
        }
    }

    private fun togglePlayPause() {
        val btn = mPlayButton ?: return
        if (!btn.isEnabled) return
        if ((mMusicLibrary?.getSongCount() ?: 0) == 0) return
        callServiceSafely { mMusicService?.togglePlayPause() }
    }

    private fun playNextSong() {
        synchronized(mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) return
            mMusicService?.playNextSong()
        }
    }

    private fun playPreviousSong() {
        synchronized(mServiceLock) {
            if (mMusicService == null || !mIsServiceBound) return
            mMusicService?.playPreviousSong()
        }
    }

    // ========================================================================
    // Transport controls
    // ========================================================================

    private fun canEnableTransportControls(): Boolean {
        return PermissionChecker.allGranted(this) &&
            mMusicService != null && mIsServiceBound &&
            (mMusicService?.getCurrentPlaylist()?.isNotEmpty() == true)
    }

    private fun refreshTransportControls() {
        updateUISafely(Runnable {
            if (isFinishing || isDestroyed) return@Runnable
            var canEnable = canEnableTransportControls()
            var isPlaying = false
            var isShuffleOn = false
            var isFavorite = false
            var repeatMode = 0
            if (canEnable) {
                try {
                    val service = mMusicService!!
                    isPlaying = service.getCurrentSong() != null && service.isPlaying
                    repeatMode = service.getRepeatMode()
                    isShuffleOn = service.isShuffle()
                    isFavorite = service.getCurrentSong()?.isFavorite ?: false
                } catch (e: Exception) {
                    Log.e(TAG, "Error reading playback state", e); canEnable = false
                }
            }

            mPlayButton?.let {
                it.text = if (isPlaying) FontAwesome.PAUSE else FontAwesome.PLAY
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, canEnable)
            }
            mPrevButton?.let {
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, false)
            }
            mNextButton?.let {
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, false)
            }
            mRepeatButton?.let {
                it.text = if (repeatMode == 2) FontAwesome.REPEAT_ONE else FontAwesome.REPEAT
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, repeatMode != 0)
            }
            mShuffleButton?.let {
                it.text = FontAwesome.SHUFFLE
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, isShuffleOn)
            }
            mFavoriteButton?.let {
                it.text = FontAwesome.HEART
                it.isEnabled = canEnable
                mThemeHelper.updateControlButton(it, canEnable, isFavorite)
            }
            mSeekBar?.let {
                it.isEnabled = canEnable
                mThemeHelper.updateSeekBar(it, canEnable)
            }
            mTransportRow?.requestLayout()
            mTransportRow?.invalidate()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                mTransportRow?.postInvalidateOnAnimation()
                mPlayButton?.postInvalidateOnAnimation()
            }
        })
    }

    // ========================================================================
    // Seek bar
    // ========================================================================

    private fun setupSeekBar() {
        val bar = mSeekBar ?: return
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser && mMusicService != null && seekBar.isEnabled && mSeekTime != null) {
                    mMusicService?.seekTo(progress)
                    mSeekTime?.text = formatTime(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                if (seekBar.isEnabled) mIsUserSeeking = true
            }
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                if (mMusicService != null && seekBar.isEnabled) {
                    mMusicService?.seekTo(seekBar.progress)
                }
                mIsUserSeeking = false
            }
        })
    }

    private fun updateTimeDisplay() {
        mTimeHandler?.removeCallbacksAndMessages(null)
        mTimeHandler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                val service = mMusicService
                if (service == null || mIsUserSeeking ||
                    mAlbumArtCarousel?.isAnimating() == true
                ) {
                    mTimeHandler?.postDelayed(this, TIME_UPDATE_INTERVAL_MS); return
                }
                try {
                    var duration = service.getDuration()
                    if (duration <= 0) {
                        val song = service.getCurrentSong()
                        if (song != null && song.duration > 0) duration = song.duration.toInt()
                    }
                    val position = service.getCurrentPosition()
                    if (duration > 0) {
                        mSeekTime?.text = formatTime(position)
                        mTotalTime?.text = formatTime(duration)
                        mSeekBar?.let { bar ->
                            if (bar.isEnabled) {
                                if (bar.max != duration) bar.max = duration
                                bar.progress = position
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating time display", e)
                }
                mTimeHandler?.postDelayed(this, TIME_UPDATE_INTERVAL_MS)
            }
        }
        mTimeHandler?.post(runnable)
    }

    private fun formatTime(ms: Int): String {
        val secs = ms / 1000
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        return if (h > 0) String.format("%02d:%02d:%02d", h, m, s)
        else String.format("%02d:%02d", m, s)
    }

    // ========================================================================
    // Album art
    // ========================================================================

    private fun calculateInSampleSize(options: BitmapFactory.Options, rw: Int, rh: Int): Int {
        val h = options.outHeight; val w = options.outWidth
        var sample = 1
        if (h > rh || w > rw) {
            val halfH = h / 2; val halfW = w / 2
            while ((halfH / sample) >= rh && (halfW / sample) >= rw) sample *= 2
        }
        return sample
    }

    private fun decodeSampledBitmap(data: ByteArray, rw: Int, rh: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(bounds, rw, rh)
            inJustDecodeBounds = false
        }
        return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    }

    private fun loadAndDisplayPlaceholder() = updatePlaceholderBitmap()

    private fun updatePlaceholderBitmap() {
        if (isFinishing || isDestroyed) return
        synchronized(mPlaceholderLock) {
            mCurrentPlaceholderTask?.cancel(true)
        }
        val themeColor = mThemeHelper.themeColorInt
        val task = mPlaceholderExecutor.submit {
            try {
                var tinted: Bitmap? = null
                synchronized(mPlaceholderLock) {
                    mOriginalPlaceholderBitmap?.let { if (!it.isRecycled) tinted = it.copy(Bitmap.Config.ARGB_8888, true) }
                }
                if (tinted == null) {
                    val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    val loaded = BitmapFactory.decodeResource(resources, R.drawable.album_art_placeholder, opts)
                    if (loaded != null) {
                        tinted = loaded.copy(Bitmap.Config.ARGB_8888, true)
                        loaded.recycle()
                        synchronized(mPlaceholderLock) {
                            mOriginalPlaceholderBitmap?.let { if (!it.isRecycled) it.recycle() }
                            mOriginalPlaceholderBitmap = tinted?.copy(Bitmap.Config.ARGB_8888, true)
                        }
                    }
                }
                val bitmap = tinted ?: return@submit
                val canvas = Canvas(bitmap)
                val paint = Paint().apply {
                    colorFilter = PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN)
                }
                canvas.drawBitmap(bitmap, 0f, 0f, paint)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    synchronized(mPlaceholderLock) {
                        mPlaceholderBitmap?.let { if (!it.isRecycled) it.recycle() }
                        mPlaceholderBitmap = bitmap
                    }
                    mAlbumArtCarousel?.setPlaceholder(mPlaceholderBitmap)
                    applyAlbumArtClipping()
                }
            } catch (e: Exception) {
                Log.e(TAG, "updatePlaceholderBitmap error", e)
            }
        }
        synchronized(mPlaceholderLock) { mCurrentPlaceholderTask = task }
    }

    private fun cleanupPlaceholderBitmaps() {
        synchronized(mPlaceholderLock) {
            mCurrentPlaceholderTask?.cancel(true); mCurrentPlaceholderTask = null
            recycleSafely(mPlaceholderBitmap); mPlaceholderBitmap = null
            recycleSafely(mOriginalPlaceholderBitmap); mOriginalPlaceholderBitmap = null
        }
    }

    private fun recycleSafely(bitmap: Bitmap?) {
        if (bitmap != null && !bitmap.isRecycled) {
            try { bitmap.recycle() } catch (e: Exception) {
                Log.e(TAG, "Error recycling bitmap", e)
            }
        }
    }

    private fun applyAlbumArtClipping() {
        val container = mAlbumArtContainer ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            container.clipToOutline = true
            container.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height,
                        dpToPx(ALBUM_ART_CORNER_RADIUS_DP).toFloat())
                }
            }
        }
        container.setBackgroundResource(R.drawable.album_art_container)
    }

    // ========================================================================
    // Navigation
    // ========================================================================

    private fun openFolderManager() {
        startActivityForResult(Intent(this, FolderManager::class.java), FOLDER_SELECT_CODE)
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun openPlaylist() {
        startActivity(Intent(this, PlaylistActivity::class.java))
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun openMetadataEditor() {
        val intent = Intent(this, MetadataEditor::class.java)
        val song = mMusicService?.getCurrentSong()
        if (song != null && song.path.isNotEmpty()) {
            intent.putExtra("song_path", song.path)
            song.uri?.let { intent.putExtra("song_uri", it) }
            intent.putExtra("awaiting_file_selection", false)
        } else {
            intent.putExtra("awaiting_file_selection", true)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }

    private fun cancelReturnHome() {
        mHomeConfirmState = HomeConfirmState.IDLE
        mLastHomeClickTime = 0L
        mHomeReturnRunnable?.let {
            mMainHandler.removeCallbacks(it); mHomeReturnRunnable = null
        }
        mThemeHelper.updateControlButton(mHomeButton, true, false)
    }

    private fun enterArmedState(tapTime: Long) {
        mHomeConfirmState = HomeConfirmState.ARMED
        mLastHomeClickTime = tapTime
        mThemeHelper.updateControlButton(mHomeButton, true, true)
        ToastManager.showToast(this, getString(R.string.player_return_home), ToastManager.LENGTH_NORMAL)
        mHomeReturnRunnable = Runnable {
            mHomeReturnRunnable = null
            if (mHomeConfirmState != HomeConfirmState.ARMED) return@Runnable
            mHomeConfirmState = HomeConfirmState.IDLE
            mLastHomeClickTime = 0L
            mThemeHelper.updateControlButton(mHomeButton, true, false)
        }
        mMainHandler.postDelayed(mHomeReturnRunnable!!, HOME_CONFIRM_WINDOW_MS)
    }

    private fun enterConfirmedState() {
        mHomeConfirmState = HomeConfirmState.CONFIRMED
        ToastManager.hidePersistentOverlay()
        mHomeButton?.let {
            mThemeHelper.updateButtonPendingState(it, true, Color.parseColor("#E53935"))
        }
        mHomeReturnRunnable = Runnable {
            mHomeReturnRunnable = null
            if (isFinishing || isDestroyed) return@Runnable
            if (mHomeConfirmState != HomeConfirmState.CONFIRMED) return@Runnable
            moveTaskToBack(true)
            mHomeConfirmState = HomeConfirmState.IDLE
        }
        mMainHandler.postDelayed(mHomeReturnRunnable!!, HOME_CONFIRM_DWELL_MS)
    }

    // ========================================================================
    // Cold-start preload
    // ========================================================================

    private fun preloadLastSongDisplay() {
        val lastPath = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null)
        if (lastPath == null || !File(lastPath).exists()) { applyNoSongState(); return }
        mSongTitle?.setText(R.string.player_placeholder_title)
        mSongArtist?.setText(R.string.player_placeholder_artist)
        mCurrentMetadataFuture?.cancel(true)
        mCurrentMetadataFuture = mMetadataLoader.submit {
            if (Thread.currentThread().isInterrupted) return@submit
            val song = loadSongMetadata(lastPath)
            runOnUiThread {
                if (isFinishing || isDestroyed || mScopeEmpty) return@runOnUiThread
                if (song != null) {
                    mCachedLastSong = song
                    mSongTitle?.text = song.title
                    mSongTitle?.setTextColor(mThemeHelper.themeColorInt)
                    mSongArtist?.text = song.artist
                    mSongArtist?.setTextColor(Color.parseColor("#C0C0C0"))
                    val cached = mAlbumArtCache?.get(lastPath)
                    if (cached != null) mAlbumArtCarousel?.onArtReady(lastPath, cached)
                    else loadAndDisplayPlaceholder()
                } else applyNoSongState()
            }
        }
    }

    private fun loadSongMetadata(path: String): Song? {
        val cached = SongDatabase.getInstance(this).getSong(path)
        if (cached != null && cached.title.isNotEmpty() &&
            !CharacterMapper.isUnknownTitle(cached.title)
        ) return cached
        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(path)
            var title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            val art = retriever.embeddedPicture
            if (title.isNullOrEmpty()) {
                var name = File(path).name
                val dot = name.lastIndexOf(".")
                if (dot > 0) name = name.substring(0, dot)
                title = name
            }
            val genre = cached?.genre ?: CharacterMapper.getUnknownGenre()
            val result = Song(
                title,
                artist ?: CharacterMapper.getUnknownArtist(),
                album ?: CharacterMapper.getUnknownAlbum(),
                genre,
                path, 0L, null
            )
            if (art != null) {
                decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX)
                    ?.let { mAlbumArtCache?.put(path, it) }
            }
            return result
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load last song metadata for: $path", e); return null
        } finally {
            try { retriever?.release() } catch (ignored: Exception) {}
        }
    }

    // ========================================================================
    // Theme
    // ========================================================================

    private fun applyThemeToUI() {
        if (isFinishing || isDestroyed) return
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        OverlayManager.setColor(mThemeHelper.themeColorInt)
        mManagerButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mLlamaButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mPlaylistButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mEqualizerButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        mMetadataButton?.let { mThemeHelper.updateButton(it, it.isEnabled) }
        when (mHomeConfirmState) {
            HomeConfirmState.ARMED -> mThemeHelper.updateControlButton(mHomeButton, true, true)
            HomeConfirmState.CONFIRMED -> mHomeButton?.let {
                mThemeHelper.updateButtonPendingState(it, true, Color.parseColor("#E53935"))
            }
            HomeConfirmState.IDLE -> mThemeHelper.updateControlButton(mHomeButton, true, false)
        }
        refreshTransportControls()
        mSongTitle?.setTextColor(mThemeHelper.themeColorInt)
        mSeekTime?.setTextColor(Color.parseColor("#C0C0C0"))
        mTotalTime?.setTextColor(Color.parseColor("#C0C0C0"))
        mSongArtist?.setTextColor(Color.parseColor("#C0C0C0"))
        updatePlaceholderBitmap()
        ToastManager.refreshThemeColor()
        forceRedraw()
    }

    // ========================================================================
    // Listeners
    // ========================================================================

    private fun setupListeners() {
        mPlayButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastPlayPauseClickTime = now; togglePlayPause()
            }
        }
        mNextButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastNextClickTime = now; playNextSong()
            }
        }
        mPrevButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastPrevClickTime = now; playPreviousSong()
            }
        }
        mRepeatButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastRepeatClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                mLastRepeatClickTime = now
                val service = mMusicService ?: return@setOnClickListener
                if (mRepeatButton?.isEnabled != true) return@setOnClickListener
                val newMode = (service.getRepeatMode() + 1) % 3
                service.setRepeatMode(newMode)
                refreshTransportControls()
                val msg = when (newMode) {
                    0 -> R.string.player_toast_repeat_off
                    1 -> R.string.player_toast_repeat_all
                    else -> R.string.player_toast_repeat_one
                }
                ToastManager.showToast(this, getString(msg), ToastManager.LENGTH_NORMAL)
            }
        }
        mShuffleButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastShuffleClickTime >= REPEAT_SHUFFLE_DELAY_MS) {
                mLastShuffleClickTime = now
                val service = mMusicService ?: return@setOnClickListener
                if (mShuffleButton?.isEnabled != true) return@setOnClickListener
                val newShuffle = !service.isShuffle()
                service.setShuffle(newShuffle)
                refreshTransportControls()
                ToastManager.showToast(
                    this,
                    getString(if (newShuffle) R.string.player_toast_shuffle_on
                    else R.string.player_toast_shuffle_off),
                    ToastManager.LENGTH_NORMAL
                )
            }
        }
        mManagerButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastManagerClickTime = now; cancelReturnHome(); openFolderManager()
            }
        }
        mLlamaButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastLlamaClickTime = now; cancelReturnHome()
                findViewById<View>(android.R.id.content).startAnimation(
                    AnimationUtils.loadAnimation(this, R.anim.slide_out_down)
                )
                val dialog = CreditsDialog(this)
                dialog.setOnDismissListener(DialogInterface.OnDismissListener {
                    findViewById<View>(android.R.id.content).startAnimation(
                        AnimationUtils.loadAnimation(this, R.anim.slide_in_up)
                    )
                })
                dialog.show()
            }
        }
        mPlaylistButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastPlaylistClickTime = now; cancelReturnHome(); openPlaylist()
            }
        }
        mEqualizerButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastEqualizerClickTime = now; cancelReturnHome()
                startActivity(Intent(this, EqualizerActivity::class.java))
            }
        }
        mMetadataButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastMetadataClickTime = now; cancelReturnHome(); openMetadataEditor()
            }
        }
        mFavoriteButton?.setOnClickListener {
            cancelReturnHome()
            val now = SystemClock.elapsedRealtime()
            if (now - mLastFavoriteClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastFavoriteClickTime = now
                callServiceSafely {
                    val current = mMusicService?.getCurrentSong() ?: return@callServiceSafely
                    val wasFavorite = current.isFavorite
                    mMusicService?.toggleFavorite()
                    ToastManager.showToast(
                        this,
                        getString(if (wasFavorite) R.string.player_toast_favorite_off
                        else R.string.player_toast_favorite_on),
                        ToastManager.LENGTH_NORMAL
                    )
                }
            }
        }
        mHomeButton?.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (mHomeConfirmState == HomeConfirmState.CONFIRMED) return@setOnClickListener
            mHomeReturnRunnable?.let { mMainHandler.removeCallbacks(it); mHomeReturnRunnable = null }
            if (mHomeConfirmState == HomeConfirmState.ARMED &&
                now - mLastHomeClickTime <= HOME_CONFIRM_WINDOW_MS
            ) { enterConfirmedState(); return@setOnClickListener }
            enterArmedState(now)
        }
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    private fun forceRedraw() {
        val root = findViewById<View>(android.R.id.content) ?: return
        root.requestLayout(); root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.updateConfiguration(resources.configuration, resources.displayMetrics)
        }
        recreate()
        overridePendingTransition(0, 0)
    }

    private fun dpToPx(dp: Int): Int = Math.round(dp * resources.displayMetrics.density)

    companion object {
        private const val TAG = "MusicPlayer"
    }
}