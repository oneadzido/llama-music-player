// SessionEvents.kt
package com.ark.llama.event

/**
 * Audio-session lifecycle events posted on the process EventBus.
 *
 * <p>Producer: [com.ark.llama.EqualizerManager] posts
 * [AudioSessionChanged] when it attaches to a new audio session;
 * [com.ark.llama.EqualizerActivity] and any other audio-effect
 * consumer react. Posts [PlaybackParamsRefresh] when the pitch or
 * speed changes mid-playback.</p>
 *
 * <p>The two events split along the same axis the audio pipeline
 * does: [AudioSessionChanged] is a session-level signal that fires
 * once per MediaPlayer attach; [PlaybackParamsRefresh] is a
 * per-change signal that fires on every pitch or speed adjustment.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface SessionEvent {

    /**
     * A new audio session is available.
     *
     * <p>Posted by [com.ark.llama.EqualizerManager.attachToAudioSession]
     * after it has successfully created the Equalizer, BassBoost,
     * and Virtualizer objects for the session. Consumers attach their
     * own audio effects to the same session ID.</p>
     *
     * <p>The session ID is the value
     * [android.media.MediaPlayer.getAudioSessionId] returned for the
     * player the service just prepared.</p>
     *
     * @property sessionId The audio session identifier
     */
    data class AudioSessionChanged(
        val sessionId: Int
    ) : SessionEvent

    /**
     * A playback-parameter change (pitch or speed) has been
     * persisted. Consumers that own the pipeline reapply the values.
     *
     * <p>Posted by [com.ark.llama.EqualizerManager.setPitch] and
     * [com.ark.llama.EqualizerManager.setSpeed] on every change.
     * [com.ark.llama.MusicService] reapplies the values to the
     * running MediaPlayer; [com.ark.llama.EqualizerActivity] refreshes
     * its labels.</p>
     *
     * <p>A named object rather than a data class because the event
     * carries no payload: the consumer re-reads the persisted values
     * from [android.content.SharedPreferences], which is the single
     * source of truth for pitch and speed.</p>
     */
    object PlaybackParamsRefresh : SessionEvent
}