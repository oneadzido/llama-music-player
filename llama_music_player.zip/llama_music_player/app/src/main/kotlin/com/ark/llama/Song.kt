// Song.kt
package com.ark.llama

import android.net.Uri
import java.util.Objects

/**
 * Represents a single audio file and its metadata.
 *
 * <p>A song carries a title, an artist, an album, a genre, an
 * absolute filesystem path, a duration, an optional document URI
 * from the Storage Access Framework, and a favorite flag. Equality
 * is by path.</p>
 *
 * <h3>Placeholders and the Current Language</h3>
 * <p>Any of the four metadata fields may be absent. In those cases
 * the field is stored as null. The four getters — [title],
 * [artist], [album], [genre] — resolve a null field, or a field
 * that already holds a placeholder from another locale, against the
 * app's currently selected language through [CharacterMapper]. A
 * song whose artist tag is absent is displayed with the German
 * placeholder on a device whose app language is German, with the
 * Arabic placeholder on a device whose app language is Arabic, and
 * with the English placeholder on a device whose app language is
 * English — all from the same instance.</p>
 *
 * <p>The getter logic is therefore <em>pull</em>-based rather than
 * <em>push</em>-based: nothing in the app has to walk the song list
 * and rewrite placeholders when the language changes. Each getter
 * resolves the placeholder at read time, using the current
 * locale.</p>
 *
 * <h3>Java Interop</h3>
 * <p>The getters are Kotlin `val` properties with custom getters,
 * so Java callers continue to see `getTitle()`, `getArtist()`,
 * `getAlbum()`, `getGenre()`, `getPath()`, `getDuration()`,
 * `getUri()`, `getContentUri()`, `isFavorite()`. The setters are
 * declared as explicit `fun setX(...)` because the metadata
 * setters accept nullable values but their getters never return
 * null.</p>
 *
 * <h3>Identity</h3>
 * <p>Equality is by [path]. Two songs with the same path are
 * equal regardless of their favorite flag, their metadata, or
 * their document URI. The favorite flag is deliberately excluded
 * so a list lookup against a path does not fail after the flag has
 * been flipped.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class Song(
    title: String?,
    artist: String?,
    album: String?,
    genre: String?,
    path: String?,
    duration: Long,
    uri: String?
) {

    // ========================================================================
    // Storage
    // ========================================================================

    /** Raw title, or null when absent. Resolved through [title]. */
    private var mTitle: String? = normalize(title)

    /** Raw artist, or null when absent. Resolved through [artist]. */
    private var mArtist: String? = normalize(artist)

    /** Raw album, or null when absent. Resolved through [album]. */
    private var mAlbum: String? = normalize(album)

    /** Raw genre, or null when absent. Resolved through [genre]. */
    private var mGenre: String? = normalize(genre)

    /** Absolute filesystem path. Never null; empty when unknown. */
    private var mPath: String = path ?: DEFAULT_PATH

    /** Duration in milliseconds. Zero when unknown. */
    private var mDuration: Long = duration

    /** Document URI as a string, or null when none. */
    private var mUri: String? = uri

    /** Favorite flag. Persisted through [SongDatabase]. */
    private var mFavorite: Boolean = false

    // ========================================================================
    // Additional constructors
    // ========================================================================

    /**
     * Constructs a song without a genre or document URI.
     *
     * <p>Convenience for the call sites that only have the four
     * common metadata fields — the artist or album path during a
     * scan, the fallback in
     * [com.ark.llama.MusicPlayer.parseIncomingSong], and the
     * initial song construction in
     * [com.ark.llama.MusicLibrary].</p>
     */
    constructor(
        title: String?,
        artist: String?,
        album: String?,
        path: String?,
        duration: Long
    ) : this(title, artist, album, null, path, duration, null)

    /**
     * Constructs a song without a genre.
     *
     * <p>Convenience for the call sites that have a document URI
     * but no genre yet — typically during a metadata read before
     * the genre has been resolved.</p>
     */
    constructor(
        title: String?,
        artist: String?,
        album: String?,
        path: String?,
        duration: Long,
        uri: String?
    ) : this(title, artist, album, null, path, duration, uri)

    // ========================================================================
    // Getters — placeholder-resolving
    // ========================================================================

    /**
     * Returns the song title, or the current language's placeholder
     * when the song carries no title.
     *
     * <p>A stored title that is already the placeholder for some
     * other locale is treated the same as an absent title and
     * resolved against the current language. This is what makes a
     * language change immediate: the getter re-resolves without any
     * write path.</p>
     */
    val title: String
        get() {
            val value = mTitle
            return if (value == null || CharacterMapper.isUnknownTitle(value)) {
                CharacterMapper.getUnknownTitle()
            } else {
                value
            }
        }

    /**
     * Returns the artist name, or the current language's
     * placeholder when the song carries no artist.
     */
    val artist: String
        get() {
            val value = mArtist
            return if (value == null || CharacterMapper.isUnknownArtist(value)) {
                CharacterMapper.getUnknownArtist()
            } else {
                value
            }
        }

    /**
     * Returns the album name, or the current language's placeholder
     * when the song carries no album.
     */
    val album: String
        get() {
            val value = mAlbum
            return if (value == null || CharacterMapper.isUnknownAlbum(value)) {
                CharacterMapper.getUnknownAlbum()
            } else {
                value
            }
        }

    /**
     * Returns the genre, or the current language's placeholder when
     * the song carries no genre.
     */
    val genre: String
        get() {
            val value = mGenre
            return if (value == null || CharacterMapper.isUnknownGenre(value)) {
                CharacterMapper.getUnknownGenre()
            } else {
                value
            }
        }

    // ========================================================================
    // Getters — direct
    // ========================================================================

    /**
     * Returns the absolute filesystem path of the audio file.
     *
     * <p>Empty string when no path was supplied at construction and
     * no [setPath] call was made.</p>
     */
    val path: String
        get() = mPath

    /**
     * Returns the duration of the song, or 0 when unknown.
     */
    val duration: Long
        get() = mDuration

    /**
     * Returns the document URI as a string, or null.
     *
     * <p>The string form is what the database persists in its
     * `uri` column. Consumers that need to pass the URI to an
     * Android API use [contentUri] instead.</p>
     */
    val uri: String?
        get() = mUri

    /**
     * Returns the document URI as a [Uri] object, or null.
     *
     * <p>Re-parses the string on every call. Callers on the hot
     * path that need the URI repeatedly should hoist the call.</p>
     */
    val contentUri: Uri?
        get() = mUri?.let { Uri.parse(it) }

    /**
     * Returns whether the user has marked this song as a favorite.
     */
    val isFavorite: Boolean
        get() = mFavorite

    // ========================================================================
    // Setters
    // ========================================================================

    /**
     * Sets the song title. A null or empty value clears it.
     *
     * <p>An empty string is normalised to null so the getter's
     * placeholder logic fires. There is no way to store a stored
     * empty title; the app treats empty and absent identically.</p>
     */
    fun setTitle(title: String?) {
        mTitle = normalize(title)
    }

    /**
     * Sets the artist name. A null or empty value clears it.
     */
    fun setArtist(artist: String?) {
        mArtist = normalize(artist)
    }

    /**
     * Sets the album name. A null or empty value clears it.
     */
    fun setAlbum(album: String?) {
        mAlbum = normalize(album)
    }

    /**
     * Sets the genre. A null or empty value clears it.
     */
    fun setGenre(genre: String?) {
        mGenre = normalize(genre)
    }

    /**
     * Sets the filesystem path. A null value uses the default.
     */
    fun setPath(path: String?) {
        mPath = path ?: DEFAULT_PATH
    }

    /**
     * Sets the duration in milliseconds.
     */
    fun setDuration(duration: Long) {
        mDuration = duration
    }

    /**
     * Sets the document URI, or null to clear.
     */
    fun setUri(uri: String?) {
        mUri = uri
    }

    /**
     * Sets the favorite flag.
     */
    fun setFavorite(favorite: Boolean) {
        mFavorite = favorite
    }

    // ========================================================================
    // Object methods
    // ========================================================================

    /**
     * Returns whether this song has the same path as the given
     * object.
     *
     * <p>The path uniquely identifies a song within the filesystem.
     * The favorite flag is not part of equality: marking a song as
     * favorite must not make a list lookup against the same path
     * fail.</p>
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Song) return false
        return mPath == other.mPath
    }

    /**
     * Returns a hash code derived from the song's path.
     */
    override fun hashCode(): Int = Objects.hash(mPath)

    /**
     * Returns a debug representation of this song.
     *
     * <p>Uses the raw stored field values, not the placeholder-
     * resolving getters, so a log line shows exactly what is
     * stored rather than what the UI would display.</p>
     */
    override fun toString(): String =
        "Song{title='$mTitle', artist='$mArtist', album='$mAlbum', " +
            "genre='$mGenre', path='$mPath', uri='$mUri', " +
            "favorite=$mFavorite}"

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        /** Path stored when a song has no filesystem path. */
        private const val DEFAULT_PATH: String = ""

        /**
         * Returns the given raw metadata value with an empty string
         * normalised to null.
         *
         * <p>The normalisation is what makes the getter's
         * placeholder logic simple: only null needs a special case,
         * not null-or-empty.</p>
         */
        private fun normalize(value: String?): String? =
            if (!value.isNullOrEmpty()) value else null
    }
}