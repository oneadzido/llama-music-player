// Song.kt
package com.ark.llama

import android.net.Uri
import java.util.Objects

/**
 * Represents a single audio file and its metadata.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class Song(
    title: String?,
    artist: String?,
    album: String?,
    genre: String?,
    path: String?,
    duration: Long,
    uri: String?
) {

    // ========================================================================
    // Storage
    // ========================================================================

    private var mTitle: String? = normalize(title)
    private var mArtist: String? = normalize(artist)
    private var mAlbum: String? = normalize(album)
    private var mGenre: String? = normalize(genre)

    private var mPath: String = path ?: DEFAULT_PATH
    private var mDuration: Long = duration
    private var mUri: String? = uri
    private var mFavorite: Boolean = false

    // ========================================================================
    // Additional constructors
    // ========================================================================

    constructor(
        title: String?,
        artist: String?,
        album: String?,
        path: String?,
        duration: Long
    ) : this(title, artist, album, null, path, duration, null)

    constructor(
        title: String?,
        artist: String?,
        album: String?,
        path: String?,
        duration: Long,
        uri: String?
    ) : this(title, artist, album, null, path, duration, uri)

    // ========================================================================
    // Getters — placeholder-resolving
    // ========================================================================

    val title: String
        get() {
            val value = mTitle
            return if (value == null || CharacterMapper.isUnknownTitle(value)) {
                CharacterMapper.getUnknownTitle()
            } else {
                value
            }
        }

    val artist: String
        get() {
            val value = mArtist
            return if (value == null || CharacterMapper.isUnknownArtist(value)) {
                CharacterMapper.getUnknownArtist()
            } else {
                value
            }
        }

    val album: String
        get() {
            val value = mAlbum
            return if (value == null || CharacterMapper.isUnknownAlbum(value)) {
                CharacterMapper.getUnknownAlbum()
            } else {
                value
            }
        }

    val genre: String
        get() {
            val value = mGenre
            return if (value == null || CharacterMapper.isUnknownGenre(value)) {
                CharacterMapper.getUnknownGenre()
            } else {
                value
            }
        }

    // ========================================================================
    // Getters — direct
    // ========================================================================

    val path: String
        get() = mPath

    val duration: Long
        get() = mDuration

    val uri: String?
        get() = mUri

    val contentUri: Uri?
        get() = mUri?.let { Uri.parse(it) }

    val isFavorite: Boolean
        get() = mFavorite

    // ========================================================================
    // Setters
    // ========================================================================

    fun setTitle(title: String?) {
        mTitle = normalize(title)
    }

    fun setArtist(artist: String?) {
        mArtist = normalize(artist)
    }

    fun setAlbum(album: String?) {
        mAlbum = normalize(album)
    }

    fun setGenre(genre: String?) {
        mGenre = normalize(genre)
    }

    fun setPath(path: String?) {
        mPath = path ?: DEFAULT_PATH
    }

    fun setDuration(duration: Long) {
        mDuration = duration
    }

    fun setUri(uri: String?) {
        mUri = uri
    }

    fun setFavorite(favorite: Boolean) {
        mFavorite = favorite
    }

    // ========================================================================
    // Object methods
    // ========================================================================

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Song) return false
        return mPath == other.mPath
    }

    override fun hashCode(): Int = Objects.hash(mPath)

    override fun toString(): String =
        "Song{title='$mTitle', artist='$mArtist', album='$mAlbum', " +
            "genre='$mGenre', path='$mPath', uri='$mUri', " +
            "favorite=$mFavorite}"

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val DEFAULT_PATH: String = ""

        private fun normalize(value: String?): String? =
            if (!value.isNullOrEmpty()) value else null
    }
}