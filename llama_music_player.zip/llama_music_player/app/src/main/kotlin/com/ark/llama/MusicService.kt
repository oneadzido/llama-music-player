// MusicService.kt
package com.ark.llama

import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.ark.llama.event.Bus
import com.ark.llama.event.MetadataEvent
import com.ark.llama.event.PlayerEvent
import com.ark.llama.event.PlaylistEvent
import com.ark.llama.event.SessionEvent
import com.ark.llama.event.TransportEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.io.IOException
import java.util.ArrayList
import java.util.Collections
import java.util.Comparator
import java.util.HashMap
import java.util.HashSet
import java.util.Map
import java.util.Random
import java.util.Set
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

/**
 * Owns the playback state machine, the MediaPlayer lifecycle, and the
 * persisted playback preferences.
 *
 * <p>The service runs in the background and continues playback when
 * the application is not visible. Playback orchestration is owned by
 * a single state machine: a [ServiceState] enum, two monotonic
 * counters ([mGeneration] and [mStartToken]), and a two-index model
 * ([mCurrentIndex] and [mTargetIndex]) hold every transition-related
 * value. State mutations happen on the main thread; raw MediaPlayer
 * calls run on a dedicated [HandlerThread].</p>
 *
 * <p>[mCurrentIndex] is the index the MediaPlayer is bound to.
 * [mTargetIndex] is the index the state machine is driving toward.
 * Every request method mutates [mTargetIndex] only;
 * [reconcile] decides whether a transition begins.</p>
 *
 * <h3>EventBus integration</h3>
 * <p>[broadcastUpdate] posts a sticky [PlayerEvent.Snapshot] on the
 * bus and then calls
 * [NotificationController.commitFromBroadcast] inline, on the same
 * main-thread turn, with the same snapshot. This is the commit
 * contract: the notification, the media session, the player UI, and
 * the carousel all advance together.</p>
 *
 * <p>Every transport command arrives on the bus through a
 * [Subscribe] handler: [TransportEvent.PlaySong] and its siblings,
 * [TransportEvent.TogglePlayPause], [TransportEvent.Next],
 * [TransportEvent.Previous], [TransportEvent.Resume],
 * [TransportEvent.Pause], [TransportEvent.Stop],
 * [TransportEvent.ToggleFavorite], [TransportEvent.SeekTo],
 * [TransportEvent.SetPendingSong], [TransportEvent.SetRepeatMode],
 * [TransportEvent.SetShuffle],
 * [TransportEvent.SetBluetoothConnected],
 * [TransportEvent.SetPlaybackSortMode],
 * [TransportEvent.RequestResumeFromGesture],
 * [TransportEvent.SavePlayerState]. Playlist, metadata, and
 * session events are handled the same way.</p>
 *
 * <h3>Volume-gesture resume</h3>
 * <p>[requestResumeFromGesture] is the album-art upward-swipe entry
 * point. When audio focus is refused at the moment of the gesture,
 * the request is remembered on [mPendingResumeFromGesture] and
 * resumed on the next [AudioManager.AUDIOFOCUS_GAIN]. A gesture
 * resume is never dropped silently.</p>
 *
 * <h3>System-broadcast receiver</h3>
 * <p>[mMusicVolumeReceiver] listens for
 * [AudioManager.VOLUME_CHANGED_ACTION] — a system broadcast emitted
 * by the platform when the user changes the music stream volume
 * with the hardware key. Its handler pauses on volume zero and
 * resumes on volume up when audio focus is held. This is the only
 * receiver this service registers.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class MusicService : Service() {

    // ========================================================================
    // State machine
    // ========================================================================

    enum class ServiceState {
        IDLE, PREPARING, READY, PLAYING, PAUSED, STOPPING
    }

    private enum class InterruptionKind { TRANSIENT_LOSS, PERMANENT_LOSS }

    private class Interruption(
        @JvmField val kind: InterruptionKind,
        @JvmField val startedAtElapsed: Long,
        @JvmField val wasPlaying: Boolean,
        @JvmField val generationAtStart: Long
    )

    private var mState: ServiceState = ServiceState.IDLE
    private var mGeneration: Long = 0L
    private var mStartToken: Long = 0L
    private var mCurrentIndex: Int = -1
    private var mTargetIndex: Int = -1
    private var mPendingSeekPosition: Int = 0
    private var mForceReprepare: Boolean = false
    private var mPauseAfterPrepare: Boolean = false
    private var mAutoStartOnPrepared: Boolean = true
    private var mDeferredReconcile: Boolean = false

    private var mGenerationDirection: Int = 0
    private var mGenerationRestart: Boolean = false
    private var mNotedDirection: Int = 0
    private var mNotedRestart: Boolean = false

    private var mPlaybackStartElapsed: Long = 0L
    private var mRecoveryAttempts: Int = 0
    private var mSkipLoopStartedElapsed: Long = 0L
    private var mPositionSaveTickCounter: Int = 0

    private val mMainHandler = Handler(Looper.getMainLooper())
    private var mHealthHandler: Handler? = null
    private var mHealthCheckRunnable: Runnable? = null

    private val mLastNotificationActionTime = HashMap<String, Long>()

    @Volatile
    private var mInterruption: Interruption? = null

    private var mResumeRetryCount: Int = 0
    private var mResumeRetryRunnable: Runnable? = null

    private var mBluetoothPauseConfirmRunnable: Runnable? = null

    @Volatile
    private var mPendingResumeFromGesture: Boolean = false

    // Shuffle peek memos.
    private var mShuffleNextPeekValid: Boolean = false
    private var mShuffleNextPeekFromIndex: Int = -1
    private var mShuffleNextPeekResult: Int = -1
    private var mShufflePrevPeekValid: Boolean = false
    private var mShufflePrevPeekFromIndex: Int = -1
    private var mShufflePrevPeekResult: Int = -1
    private var mCachedWindow: PlaybackWindow? = null

    // MediaPlayer.
    private var mMediaPlayer: MediaPlayer? = null
    private var mPlayerThread: HandlerThread? = null
    private var mPlayerHandler: Handler? = null
    private var mWakeLock: PowerManager.WakeLock? = null

    // Art loader / sort executor / art cache.
    private val mArtLoader: ExecutorService = Executors.newSingleThreadExecutor()
    private val mSortExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var mArtCache: LruCache<String, Bitmap>
    private var mCurrentArtLoad: Future<*>? = null
    @Volatile private var mResolvedArtPath: String? = null
    @Volatile private var mResolvedArt: Bitmap? = null

    private val mStateSource = object : NotificationController.ServiceStateSource {
        override fun snapshotForNotification(): NotificationController.RenderSnapshot? {
            val displaySong = getDisplaySong() ?: return null
            val displayPath = displaySong.path
            if (displayPath.isEmpty()) return null

            val artResolved = displayPath == mResolvedArtPath
            val resolvedArt = if (artResolved) mResolvedArt else null
            val album = displaySong.album

            return NotificationController.RenderSnapshot(
                displaySong.title,
                displaySong.artist,
                album,
                displayPath,
                isPlaying,
                mCachedDuration,
                resolvedArt,
                artResolved
            )
        }

        override fun isIdle(): Boolean = mState == ServiceState.IDLE

        override fun sessionPlaybackState(): Int = when (mState) {
            ServiceState.PLAYING -> PlaybackStateCompat.STATE_PLAYING
            ServiceState.PAUSED, ServiceState.READY -> PlaybackStateCompat.STATE_PAUSED
            ServiceState.PREPARING ->
                if (mAutoStartOnPrepared && !mPauseAfterPrepare)
                    PlaybackStateCompat.STATE_PLAYING
                else PlaybackStateCompat.STATE_PAUSED
            else -> PlaybackStateCompat.STATE_NONE
        }

        override fun updateSessionPlaybackState() {
            this@MusicService.updateMediaSessionPlaybackState()
        }

        override fun getGeneration(): Long = mGeneration

        override fun shouldRemainForeground(): Boolean =
            this@MusicService.shouldRemainForeground()

        override fun applyToMediaSession(snapshot: NotificationController.RenderSnapshot?) {
            val session = mMediaSession ?: return
            try {
                val builder = MediaMetadataCompat.Builder()
                if (snapshot != null) {
                    builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, snapshot.title)
                    builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, snapshot.artist)
                    builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, snapshot.album)
                    builder.putLong(MediaMetadataCompat.METADATA_KEY_DURATION,
                        snapshot.durationMs.toLong())
                    if (snapshot.artResolved && snapshot.art != null &&
                        !snapshot.art.isRecycled
                    ) {
                        builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART,
                            snapshot.art)
                    } else {
                        mNotificationController?.getPlaceholderForMediaSession()?.let {
                            if (!it.isRecycled) {
                                builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, it)
                            }
                        }
                    }
                } else {
                    builder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, "")
                    builder.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "")
                    builder.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "")
                }
                session.setMetadata(builder.build())
            } catch (exception: Exception) {
                Log.e(TAG, "applyToMediaSession failed", exception)
            }
        }
    }

    // Cached playback facts.
    private var mCachedDuration: Int = 0
    private var mCachedAudioSessionId: Int = 0
    private var mCachedPosition: Int = 0
    private var mPlaybackBasePosition: Int = 0
    private var mPlaybackBaseElapsed: Long = 0L
    private var mPositionEpoch: Long = 0L

    // Playlist and playback state.
    private var mCurrentPlaylist: ArrayList<Song>? = null
    private var mFullPlaylist: ArrayList<Song>? = null
    private var mScopedPlaylist: ArrayList<Song>? = null

    private var mPlaybackScope: PlaybackScope = PlaybackScope.ALL_SONGS
    private var mLooseTrackPaths: Set<String> = HashSet()

    @Volatile private var mRepeatMode: Int = 0
    @Volatile private var mIsShuffle: Boolean = false
    private var mCurrentSortMode: Int = SORT_TITLE_AZ
    private var mShuffleHistory: ArrayList<Int>? = null
    private var mRandom: Random? = null

    @Volatile
    private var mPendingSongPath: String? = null

    private val mBinder = LocalBinder()
    private var mMusicLibrary: MusicLibrary? = null
    private var mNotificationController: NotificationController? = null

    private var mAudioManager: AudioManager? = null
    private var mAudioFocusListener: AudioManager.OnAudioFocusChangeListener? = null
    private var mAudioFocusRequest: AudioFocusRequest? = null
    private var mAudioFocusRequestTransient: AudioFocusRequest? = null
    private var mMediaSession: MediaSessionCompat? = null
    @Volatile private var mIsBluetoothConnected: Boolean = false
    @Volatile private var mIsDucked: Boolean = false
    @Volatile private var mHasAudioFocus: Boolean = false

    /**
     * System-broadcast receiver for music-stream volume changes.
     *
     * <p>[AudioManager.VOLUME_CHANGED_ACTION] is emitted by the
     * platform when the user presses a hardware volume key. The
     * receiver pauses on volume zero and resumes on volume up when
     * audio focus is held. This is the only receiver this service
     * registers.</p>
     */
    private var mMusicVolumeReceiver: BroadcastReceiver? = null

    inner class LocalBinder : Binder() {
        val service: MusicService get() = this@MusicService
    }

    // ========================================================================
    // Sort comparators
    // ========================================================================

    private inner class TitleAZComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int =
            a.title.compareTo(b.title, ignoreCase = true)
    }

    private inner class TitleZAComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int =
            b.title.compareTo(a.title, ignoreCase = true)
    }

    private inner class ArtistAZComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = a.artist.compareTo(b.artist, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class ArtistZAComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = b.artist.compareTo(a.artist, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class AlbumAZComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = a.album.compareTo(b.album, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class AlbumZAComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = b.album.compareTo(a.album, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class GenreAZComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = a.genre.compareTo(b.genre, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class GenreZAComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = b.genre.compareTo(a.genre, ignoreCase = true)
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class OldestFirstComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = getSongDate(a).compareTo(getSongDate(b))
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private inner class NewestFirstComparator : Comparator<Song> {
        override fun compare(a: Song, b: Song): Int {
            val c = getSongDate(b).compareTo(getSongDate(a))
            return if (c != 0) c else a.title.compareTo(b.title, ignoreCase = true)
        }
    }

    private fun getSongDate(song: Song): Long =
        if (song.path.isEmpty()) 0L else File(song.path).lastModified()

    private fun getComparatorForSortMode(mode: Int): Comparator<Song> = when (mode) {
        SORT_TITLE_AZ -> TitleAZComparator()
        SORT_TITLE_ZA -> TitleZAComparator()
        SORT_ARTIST_AZ -> ArtistAZComparator()
        SORT_ARTIST_ZA -> ArtistZAComparator()
        SORT_ALBUM_AZ -> AlbumAZComparator()
        SORT_ALBUM_ZA -> AlbumZAComparator()
        SORT_GENRE_AZ -> GenreAZComparator()
        SORT_GENRE_ZA -> GenreZAComparator()
        SORT_OLDEST -> OldestFirstComparator()
        SORT_NEWEST -> NewestFirstComparator()
        else -> TitleAZComparator()
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "MusicService onCreate")

        mArtCache = LruCache<String, Bitmap>(NOTIFICATION_ART_CACHE_MB * 1024 * 1024) {
            override fun sizeOf(key: String, bitmap: Bitmap): Int = bitmap.byteCount
        }

        mPlayerThread = HandlerThread("MediaPlayerThread").also { it.start() }
        mPlayerHandler = Handler(mPlayerThread!!.looper)

        mNotificationController = NotificationController.getInstance(this)
        mNotificationController!!.attachService(this)
        mNotificationController!!.setStateSource(mStateSource)
        mNotificationController!!.setSessionTokenProvider { sessionToken }

        mAudioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        loadRepeatAndShuffle()
        loadSortMode()
        loadPlaybackScope()
        setupMediaSession()
        setupAudioFocus()

        EqualizerManager.getInstance(this)

        mShuffleHistory = ArrayList()
        mRandom = Random()
        mHealthHandler = Handler(Looper.getMainLooper())
        installHealthCheckRunnable()

        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        mWakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback"
        ).apply { setReferenceCounted(false) }

        Bus.register(this)

        mMusicLibrary = MusicLibrary(this)

        Log.d(TAG, "MusicService onCreate complete")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == null) {
            onMain { restoreNotificationFromPersistedState() }
            return START_STICKY
        }
        val action = intent.action ?: return START_STICKY

        if (Intent.ACTION_MEDIA_BUTTON == action) {
            val event: KeyEvent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
            }
            if (event != null && event.action == KeyEvent.ACTION_DOWN) {
                mMediaSession?.controller?.dispatchMediaButtonEvent(event)
            }
            return START_STICKY
        }

        if (isNotificationActionDebounced(action)) return START_STICKY

        when (action) {
            ACTION_PLAY_PAUSE -> togglePlayPauseInternal()
            ACTION_NEXT -> playNextSongInternal()
            ACTION_PREV -> playPreviousSongInternal()
            ACTION_STOP -> pauseInternal()
            ACTION_BLUETOOTH_RESUME -> handleBluetoothResume()
            ACTION_PLAY_SONG -> {
                val songPath = intent.getStringExtra("song_path")
                if (songPath != null) playSongByPathInternal(songPath)
                else {
                    val position = intent.getIntExtra("position", -1)
                    if (position >= 0) playSongInternal(position)
                }
            }
        }
        return START_STICKY
    }

    private fun isNotificationActionDebounced(action: String): Boolean {
        if (action != ACTION_PLAY_PAUSE && action != ACTION_NEXT && action != ACTION_PREV) {
            return false
        }
        val now = SystemClock.elapsedRealtime()
        val last = mLastNotificationActionTime[action]
        if (last != null && now - last < NOTIFICATION_ACTION_DEBOUNCE_MS) return true
        mLastNotificationActionTime[action] = now
        return false
    }

    private fun handleBluetoothResume() {
        onMain {
            val lastPath = savedSongPath
            if (lastPath == null || !File(lastPath).exists()) {
                transitionToIdle()
                stopSelf()
                return@onMain
            }

            var lastSong = SongDatabase.getInstance(this).getSong(lastPath)
            if (lastSong == null) lastSong = CharacterMapper.getSongFromFile(lastPath)
            if (lastSong == null) {
                transitionToIdle()
                stopSelf()
                return@onMain
            }

            val single = arrayListOf(lastSong)
            setPlaylistInternal(single, true)
            resumeInternal()

            if (mMusicLibrary == null) mMusicLibrary = MusicLibrary(this)
            mMusicLibrary?.loadAllSongsAsync(object : MusicLibrary.OnSongsLoadedListener {
                override fun onSongsLoaded(songs: ArrayList<Song>) {
                    onMain {
                        if (songs.isNotEmpty()) setPlaylistInternal(songs, true)
                    }
                }
                override fun onLoadingError(error: String) {
                    Log.w(TAG, "Full library load after BT resume failed: $error")
                }
            })
        }
    }

    private fun restoreNotificationFromPersistedState() {
        val controller = mNotificationController ?: return
        val lastPath = savedSongPath ?: return
        if (lastPath.isEmpty()) return
        val lastSong = SongDatabase.getInstance(this).getSong(lastPath) ?: return
        val snapshot = NotificationController.RenderSnapshot(
            lastSong.title,
            lastSong.artist,
            lastSong.album,
            lastPath,
            false,
            mCachedDuration,
            null,
            false
        )
        controller.commitFromBroadcast(mGeneration, snapshot)
    }

    override fun onBind(intent: Intent?): IBinder {
        registerMusicVolumeReceiver()
        return mBinder
    }

    override fun onDestroy() {
        Log.d(TAG, "MusicService onDestroy")

        clearInterruption()
        stopHealthMonitoring()
        saveFullState()
        savePlayerState()

        mCurrentArtLoad?.cancel(true); mCurrentArtLoad = null
        if (!mArtLoader.isShutdown) mArtLoader.shutdownNow()
        if (!mSortExecutor.isShutdown) mSortExecutor.shutdownNow()

        mPlayerHandler?.post { releaseMediaPlayerInternal() }
        mPlayerThread?.quitSafely()
        mPlayerThread = null
        mPlayerHandler = null

        mMusicLibrary?.shutdown(); mMusicLibrary = null

        releaseWakeLock()
        mState = ServiceState.STOPPING

        mNotificationController?.detachService(); mNotificationController = null

        mMediaSession?.setActive(false)
        mMediaSession?.release(); mMediaSession = null

        abandonAudioFocus()

        unregisterMusicVolumeReceiver()

        mHealthHandler?.removeCallbacksAndMessages(null); mHealthHandler = null
        mMainHandler.removeCallbacksAndMessages(null)

        Bus.unregister(this)

        super.onDestroy()
        Log.d(TAG, "MusicService onDestroy complete")
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        onMain {
            if (mState == ServiceState.PLAYING) savePlayingState()
            if (level >= TRIM_MEMORY_BACKGROUND) mArtCache.evictAll()
            reconcile()
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveFullState()
        savePlayerState()
        super.onTaskRemoved(rootIntent)
    }

    // ========================================================================
    // Thread marshalling
    // ========================================================================

    private fun onMain(action: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) action.run()
        else mMainHandler.post(action)
    }

    private fun onPlayer(action: Runnable) {
        val handler = mPlayerHandler ?: return
        if (Looper.myLooper() == handler.looper) action.run()
        else handler.post(action)
    }

    // ========================================================================
    // Small helpers
    // ========================================================================

    private fun playlistSize(): Int = mCurrentPlaylist?.size ?: 0
    private fun playlistEmpty(): Boolean = playlistSize() == 0
    private fun pathOf(index: Int): String? {
        if (mCurrentPlaylist == null) return null
        if (index < 0 || index >= mCurrentPlaylist!!.size) return null
        return mCurrentPlaylist!![index]?.path
    }
    private fun indexOfPath(path: String?): Int {
        if (path == null || mCurrentPlaylist == null) return -1
        for (i in mCurrentPlaylist!!.indices) {
            if (mCurrentPlaylist!![i]?.path == path) return i
        }
        return -1
    }

    private fun acquireWakeLock() {
        mWakeLock?.let {
            if (!it.isHeld) try { it.acquire() } catch (e: Exception) {
                Log.w(TAG, "WakeLock acquire failed", e)
            }
        }
    }

    private fun releaseWakeLock() {
        mWakeLock?.let {
            if (it.isHeld) try { it.release() } catch (e: Exception) {
                Log.w(TAG, "WakeLock release failed", e)
            }
        }
    }

    private fun estimateCurrentPosition(): Int {
        if (mState == ServiceState.PLAYING && mPlaybackBaseElapsed > 0L) {
            val elapsed = SystemClock.elapsedRealtime() - mPlaybackBaseElapsed
            val est = mPlaybackBasePosition + elapsed
            if (mCachedDuration > 0 && est > mCachedDuration) return mCachedDuration
            return est.toInt()
        }
        return mCachedPosition
    }

    private fun skipBudgetExhausted(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (mSkipLoopStartedElapsed == 0L) {
            mSkipLoopStartedElapsed = now; return false
        }
        return now - mSkipLoopStartedElapsed >= SKIP_LOOP_BUDGET_MS
    }

    private fun abandonSkipLoop() {
        Log.w(TAG, "Abandoning skip loop after " +
            "${SystemClock.elapsedRealtime() - mSkipLoopStartedElapsed} ms")
        mSkipLoopStartedElapsed = 0L
        mPauseAfterPrepare = false
        mForceReprepare = false
        onPlayer { releaseMediaPlayerInternal() }
        releaseWakeLock()
        mCurrentIndex = -1
        mState = ServiceState.IDLE
        mCachedPosition = 0
        mPlaybackBasePosition = 0
        mPlaybackBaseElapsed = 0L
        savePlayingState()
        savePlayerState()
        broadcastUpdate()
    }

    // ========================================================================
    // Music volume receiver (system broadcast)
    // ========================================================================

    private fun registerMusicVolumeReceiver() {
        if (mMusicVolumeReceiver != null) return
        mMusicVolumeReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action != VOLUME_CHANGED_ACTION) return
                var streamType = intent.getIntExtra(EXTRA_VOLUME_STREAM_TYPE, -1)
                if (streamType == -1) {
                    streamType = intent.getIntExtra(EXTRA_VOLUME_STREAM_TYPE_ALIAS, -1)
                }
                if (streamType != AudioManager.STREAM_MUSIC) return
                val newVolume = intent.getIntExtra(EXTRA_VOLUME_STREAM_VALUE, -1)
                if (newVolume < 0) return
                onMusicVolumeChanged(newVolume)
            }
        }
        try {
            ContextCompat.registerReceiver(
                this, mMusicVolumeReceiver,
                android.content.IntentFilter(VOLUME_CHANGED_ACTION),
                ContextCompat.RECEIVER_EXPORTED
            )
            Log.d(TAG, "Music volume receiver registered")
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to register music volume receiver", exception)
            mMusicVolumeReceiver = null
        }
    }

    private fun unregisterMusicVolumeReceiver() {
        mMusicVolumeReceiver?.let {
            try { unregisterReceiver(it) } catch (ignored: Exception) {}
            mMusicVolumeReceiver = null
        }
    }

    fun hasAudioFocus(): Boolean = mHasAudioFocus

    private fun onMusicVolumeChanged(broadcastVolume: Int) {
        var target = broadcastVolume
        mAudioManager?.let { am ->
            try {
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                if (max > 0) {
                    val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    if (current >= 0) target = current
                    target = Math.max(0, Math.min(max, target))
                }
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to read current music volume", exception)
                target = broadcastVolume
            }
        }
        if (target < 0) target = 0
        if (target == 0) {
            if (mState == ServiceState.PLAYING) {
                clearInterruption(); doPauseInternal()
            } else if (mState == ServiceState.PREPARING) {
                mPauseAfterPrepare = true
            }
        } else {
            if (!mHasAudioFocus) {
                Log.d(TAG, "Volume raised but focus not held; not resuming")
                return
            }
            when (mState) {
                ServiceState.PAUSED -> doResumeInternal()
                ServiceState.PREPARING -> mPauseAfterPrepare = false
                ServiceState.READY -> togglePlayPauseInternal()
                else -> { }
            }
        }
    }

    // ========================================================================
    // Notification album art prefetch
    // ========================================================================

    private fun prefetchNotificationArt() {
        val displaySong = getDisplaySong() ?: return
        val path = displaySong.path
        if (path.isEmpty()) return
        mArtCache.get(path)?.let {
            mResolvedArtPath = path
            mResolvedArt = it
            return
        }
        mCurrentArtLoad?.cancel(true); mCurrentArtLoad = null
        mCurrentArtLoad = mArtLoader.submit {
            if (Thread.currentThread().isInterrupted) return@submit
            var art: Bitmap? = null
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                retriever.setDataSource(path)
                val bytes = retriever.embeddedPicture
                if (bytes != null && !Thread.currentThread().isInterrupted) {
                    art = decodeNotificationArt(bytes)
                }
            } catch (exception: Exception) {
                Log.e(TAG, "Notification art prefetch failed for $path", exception)
            } finally {
                try { retriever?.release() } catch (ignored: Exception) {}
            }
            if (art != null && !Thread.currentThread().isInterrupted) {
                mArtCache.put(path, art)
            }
            val finalArt = art
            onMain {
                val currentSong = getDisplaySong() ?: return@onMain
                if (currentSong.path != path) return@onMain
                mResolvedArtPath = path
                mResolvedArt = finalArt
                if (mState != ServiceState.PREPARING) {
                    mNotificationController?.pokeAwareness()
                }
            }
        }
    }

    private fun decodeNotificationArt(data: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sampleSize = 1
        val longSide = Math.max(bounds.outWidth, bounds.outHeight)
        while (longSide / sampleSize > NOTIFICATION_ART_MAX_PX * 2) sampleSize *= 2
        val decode = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return BitmapFactory.decodeByteArray(data, 0, data.size, decode)
    }

    // ========================================================================
    // Shuffle and window
    // ========================================================================

    private fun clearShufflePeek() {
        mShuffleNextPeekValid = false
        mShuffleNextPeekFromIndex = -1
        mShuffleNextPeekResult = -1
        mShufflePrevPeekValid = false
        mShufflePrevPeekFromIndex = -1
        mShufflePrevPeekResult = -1
        mCachedWindow = null
    }

    private fun peekNextIndex(from: Int): Int {
        if (playlistSize() == 0) return -1
        if (mIsShuffle) return peekShuffleNextIndex(from)
        return (from + 1) % playlistSize()
    }

    private fun peekPreviousIndex(from: Int): Int {
        if (playlistSize() == 0) return -1
        if (mIsShuffle) return peekShufflePreviousIndex(from)
        return (from - 1 + playlistSize()) % playlistSize()
    }

    private fun peekShuffleNextIndex(from: Int): Int {
        val size = playlistSize()
        if (size <= 1) return from
        if (mShuffleNextPeekValid && mShuffleNextPeekFromIndex == from) {
            return mShuffleNextPeekResult
        }
        val rnd = mRandom ?: Random().also { mRandom = it }
        var candidate: Int
        var guard = 0
        do { candidate = rnd.nextInt(size); guard++ } while (candidate == from && guard < 8)
        mShuffleNextPeekValid = true
        mShuffleNextPeekFromIndex = from
        mShuffleNextPeekResult = candidate
        return candidate
    }

    private fun peekShufflePreviousIndex(from: Int): Int {
        if (mShufflePrevPeekValid && mShufflePrevPeekFromIndex == from) {
            return mShufflePrevPeekResult
        }
        val prev: Int = if (mShuffleHistory != null && mShuffleHistory!!.size >= 2) {
            val candidate = mShuffleHistory!![mShuffleHistory!!.size - 2]
            if (candidate >= 0 && candidate < playlistSize()) candidate
            else freshShufflePick(from)
        } else freshShufflePick(from)
        mShufflePrevPeekValid = true
        mShufflePrevPeekFromIndex = from
        mShufflePrevPeekResult = prev
        return prev
    }

    private fun freshShufflePick(from: Int): Int {
        val size = playlistSize()
        if (size <= 1) return from
        val rnd = mRandom ?: Random().also { mRandom = it }
        var candidate: Int
        var guard = 0
        do { candidate = rnd.nextInt(size); guard++ } while (candidate == from && guard < 8)
        return candidate
    }

    private fun computeNext(from: Int): Int {
        if (playlistEmpty()) return -1
        if (mIsShuffle) return pickShuffleNext(from)
        return (from + 1) % playlistSize()
    }

    private fun computePrevious(from: Int): Int {
        if (playlistEmpty()) return -1
        if (mIsShuffle) return popShuffleHistory(from)
        return (from - 1 + playlistSize()) % playlistSize()
    }

    private fun pickShuffleNext(from: Int): Int {
        val size = playlistSize()
        if (size <= 1) return from
        val next = peekShuffleNextIndex(from)
        if (mShuffleHistory == null) mShuffleHistory = ArrayList()
        if (mShuffleHistory!!.size >= size * 2) mShuffleHistory!!.clear()
        mShuffleHistory!!.add(next)
        clearShufflePeek()
        return next
    }

    private fun pickShuffleNextInScope(from: Int): Int {
        val scoped = mScopedPlaylist ?: return -1
        if (scoped.isEmpty()) return -1
        if (scoped.size == 1) {
            return indexOfPath(scoped[0].path)
        }
        val currentPath = pathOf(from)
        var currentScoped = -1
        if (currentPath != null) {
            for (i in scoped.indices) {
                if (scoped[i].path == currentPath) { currentScoped = i; break }
            }
        }
        val rnd = mRandom ?: Random().also { mRandom = it }
        var candidate: Int
        var guard = 0
        do { candidate = rnd.nextInt(scoped.size); guard++ } while (candidate == currentScoped && guard < 8)
        val picked = scoped[candidate]
        val pickedIndex = indexOfPath(picked.path)
        if (mShuffleHistory == null) mShuffleHistory = ArrayList()
        if (mShuffleHistory!!.size >= scoped.size * 2) mShuffleHistory!!.clear()
        if (pickedIndex >= 0) mShuffleHistory!!.add(pickedIndex)
        clearShufflePeek()
        return pickedIndex
    }

    private fun popShuffleHistory(from: Int): Int {
        val prev = peekShufflePreviousIndex(from)
        if (mShuffleHistory != null && mShuffleHistory!!.size >= 2) {
            mShuffleHistory!!.removeAt(mShuffleHistory!!.size - 1)
        }
        clearShufflePeek()
        return prev
    }

    private fun getDisplaySong(): Song? {
        val list = mCurrentPlaylist ?: return null
        if (list.isEmpty()) return null
        if (mState == ServiceState.PREPARING) {
            if (mTargetIndex < 0 || mTargetIndex >= list.size) return null
            val target = list[mTargetIndex]
            if (target == null || target.path.isEmpty()) return null
            return target
        }
        if (mCurrentIndex >= 0 && mCurrentIndex < list.size) {
            val current = list[mCurrentIndex]
            if (current == null || current.path.isEmpty()) return null
            return current
        }
        return null
    }

    fun getWindowSnapshot(): PlaybackWindow {
        val displaySong = getDisplaySong() ?: run {
            mCachedWindow = null
            return PlaybackWindow.EMPTY
        }
        val displayIndex = indexOfPath(displaySong.path)
        if (displayIndex < 0) {
            mCachedWindow = null
            return PlaybackWindow.EMPTY
        }
        val cached = mCachedWindow
        if (cached != null && cached.generation == mGeneration &&
            displaySong.path == cached.currentPath
        ) return cached

        val previousIndex = peekPreviousIndex(displayIndex)
        val nextIndex = peekNextIndex(displayIndex)
        val previousPath = if (previousIndex >= 0) pathOf(previousIndex) else null
        val nextPath = if (nextIndex >= 0) pathOf(nextIndex) else null
        val window = PlaybackWindow(previousPath, displaySong.path, nextPath, mGeneration)
        mCachedWindow = window
        return window
    }

    // ========================================================================
    // Reconcile / transition
    // ========================================================================

    private fun noteTransition(direction: Int, restart: Boolean) {
        mNotedDirection = direction
        mNotedRestart = restart
    }

    private fun clearNotedTransition() {
        mNotedDirection = 0
        mNotedRestart = false
    }

    private fun reconcile() {
        if (mState == ServiceState.STOPPING) { clearNotedTransition(); return }
        if (mState == ServiceState.PREPARING) { mDeferredReconcile = true; return }

        val pending = mPendingSongPath
        if (pending != null) {
            val idx = indexOfPath(pending)
            if (idx >= 0) {
                mTargetIndex = idx
                if (idx == mCurrentIndex && !mForceReprepare) mPendingSongPath = null
            }
        }

        if (mTargetIndex < 0 || mTargetIndex >= playlistSize()) {
            clearNotedTransition(); return
        }

        val need = mTargetIndex != mCurrentIndex || mForceReprepare
        if (!need) {
            mDeferredReconcile = false
            clearNotedTransition()
            return
        }
        mForceReprepare = false
        mDeferredReconcile = false
        beginTransition(mTargetIndex, mPendingSeekPosition)
    }

    private fun beginTransition(index: Int, seekPosition: Int) {
        if (mState == ServiceState.STOPPING) return
        if (playlistEmpty()) { transitionToIdle(); return }
        if (index < 0 || index >= playlistSize()) return

        val pending = mPendingSongPath
        if (pending != null && pending == pathOf(index)) mPendingSongPath = null

        val generation = ++mGeneration
        mGenerationDirection = mNotedDirection
        mGenerationRestart = mNotedRestart
        mNotedDirection = 0
        mNotedRestart = false

        mState = ServiceState.PREPARING
        mTargetIndex = index
        mPendingSeekPosition = seekPosition
        mAutoStartOnPrepared = true

        val song = mCurrentPlaylist!![index]
        if (song == null || song.path.isEmpty()) {
            mState = ServiceState.IDLE
            if (skipBudgetExhausted()) { abandonSkipLoop(); return }
            mTargetIndex = computeNext(index)
            noteTransition(+1, false)
            mMainHandler.post { reconcile() }
            return
        }

        prefetchNotificationArt()
        val path = song.path
        val committed = index
        val capturedGeneration = generation

        onPlayer {
            releaseMediaPlayerInternal()
            val player = getOrCreatePlayerRaw()
            removeAllListeners(player)
            applyDuckVolume(player)
            try { player.reset() } catch (exception: IllegalStateException) {
                Log.e(TAG, "player.reset() failed", exception)
                releaseMediaPlayerInternal()
                mMainHandler.post {
                    if (capturedGeneration != mGeneration) return@post
                    mState = ServiceState.IDLE
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return@post }
                    mTargetIndex = computeNext(committed)
                    noteTransition(+1, false)
                    mMainHandler.post { reconcile() }
                }
                return@onPlayer
            }
            try { player.setDataSource(path) } catch (exception: Exception) {
                Log.e(TAG, "setDataSource failed: $path", exception)
                releaseMediaPlayerInternal()
                mMainHandler.post {
                    if (capturedGeneration != mGeneration) return@post
                    mState = ServiceState.IDLE
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return@post }
                    mTargetIndex = computeNext(committed)
                    noteTransition(+1, false)
                    mMainHandler.post { reconcile() }
                }
                return@onPlayer
            }

            player.setOnPreparedListener { mp ->
                val duration: Int
                val audioSessionId: Int
                try {
                    duration = mp.duration
                    audioSessionId = mp.audioSessionId
                } catch (exception: Exception) {
                    mMainHandler.post { onPrepareFailed(capturedGeneration, committed) }
                    return@setOnPreparedListener
                }
                mMainHandler.post {
                    onPrepared(capturedGeneration, duration, audioSessionId, song, committed)
                }
            }
            player.setOnCompletionListener {
                mMainHandler.post {
                    if (capturedGeneration != mGeneration) return@post
                    onCompletionInternal()
                }
            }
            player.setOnErrorListener { _, what, extra ->
                mMainHandler.post {
                    if (capturedGeneration != mGeneration) return@post
                    onPlayerErrorInternal(what, extra)
                }
                true
            }

            try { player.prepareAsync() } catch (exception: IllegalStateException) {
                Log.e(TAG, "prepareAsync failed", exception)
                releaseMediaPlayerInternal()
                mMainHandler.post {
                    if (capturedGeneration != mGeneration) return@post
                    mState = ServiceState.IDLE
                    if (skipBudgetExhausted()) { abandonSkipLoop(); return@post }
                    mTargetIndex = computeNext(committed)
                    noteTransition(+1, false)
                    mMainHandler.post { reconcile() }
                }
            }
        }
    }

    private fun transitionToIdle() {
        if (mState == ServiceState.STOPPING) return
        if (mState == ServiceState.IDLE && mCurrentPlaylist == null &&
            mCurrentIndex == -1 && mTargetIndex == -1
        ) return

        clearInterruption()
        mState = ServiceState.STOPPING
        mGeneration++
        mGenerationDirection = 0
        mGenerationRestart = false
        clearNotedTransition()
        mCachedWindow = null
        mTargetIndex = -1
        mPendingSeekPosition = 0
        mPauseAfterPrepare = false
        mForceReprepare = false
        mDeferredReconcile = false
        mSkipLoopStartedElapsed = 0L
        mCurrentIndex = -1
        mPendingSongPath = null

        mPositionSaveTickCounter = 0
        mCachedPosition = 0
        mCachedDuration = 0
        mCachedAudioSessionId = 0
        mPlaybackBasePosition = 0
        mPlaybackBaseElapsed = 0L
        mPositionEpoch++

        mResolvedArtPath = null
        mResolvedArt = null
        mCurrentArtLoad?.cancel(true); mCurrentArtLoad = null
        mArtCache.evictAll()

        mLastNotificationActionTime.clear()
        stopHealthMonitoring()

        onPlayer { releaseMediaPlayerInternal() }
        releaseWakeLock()

        mCurrentPlaylist = null
        mShuffleHistory?.clear()
        clearShufflePeek()

        EqualizerManager.getInstance(this).release()
        sCurrentAudioSessionId = 0

        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply()

        mNotificationController?.clearPlaybackNotification()

        mMediaSession?.let {
            try { it.setActive(false) } catch (e: Exception) {
                Log.w(TAG, "Failed to deactivate MediaSession", e)
            }
        }

        mState = ServiceState.IDLE
        broadcastUpdate()
    }

    // ========================================================================
    // MediaPlayer callbacks
    // ========================================================================

    private fun onPrepared(
        generation: Long,
        duration: Int,
        audioSessionId: Int,
        song: Song,
        committed: Int
    ) {
        if (generation != mGeneration) return
        if (mState != ServiceState.PREPARING) return
        if (duration <= 0) { onPrepareFailed(generation, committed); return }

        val seekPosition = mPendingSeekPosition
        mPendingSeekPosition = 0
        mSkipLoopStartedElapsed = 0L
        mCachedDuration = duration
        mCachedAudioSessionId = audioSessionId
        mCachedPosition = 0
        mPlaybackBasePosition = 0
        mPlaybackBaseElapsed = 0L
        sCurrentAudioSessionId = audioSessionId
        broadcastAudioSessionChanged(audioSessionId)
        EqualizerManager.getInstance(this).attachToAudioSession(audioSessionId)
        mCurrentIndex = committed
        rebuildPlaylists()

        if (mPauseAfterPrepare) {
            mPauseAfterPrepare = false
            mAutoStartOnPrepared = false
        }

        if (!mAutoStartOnPrepared) {
            if (seekPosition > 0 && seekPosition < duration - 500) {
                val finalSeek = seekPosition
                onPlayer {
                    try { mMediaPlayer?.seekTo(finalSeek) } catch (ignored: Exception) {}
                }
                mCachedPosition = seekPosition
                mPlaybackBasePosition = seekPosition
            }
            mState = ServiceState.READY
            mRecoveryAttempts = 0
            mMediaSession?.let { try { it.setActive(true) } catch (ignored: Exception) {} }
            saveCurrentPlayingIndex()
            broadcastUpdate()
            if (mDeferredReconcile || mPendingSongPath != null ||
                mTargetIndex != mCurrentIndex || mForceReprepare
            ) mMainHandler.post { reconcile() }
            return
        }

        val doSeek = if (seekPosition > 0 && seekPosition < duration - 500)
            seekPosition else 0
        val capturedGeneration = generation
        val capturedSong = song
        val capturedIndex = committed
        val capturedStartToken = ++mStartToken

        raiseVolumeIfSilentForResume()

        onPlayer {
            val player = mMediaPlayer
            if (player == null) {
                mMainHandler.post { onPrepareFailed(capturedGeneration, capturedIndex) }
                return@onPlayer
            }
            if (doSeek > 0) try { player.seekTo(doSeek) } catch (ignored: Exception) {}
            try { player.start() } catch (exception: Exception) {
                Log.e(TAG, "onPrepared: start() failed", exception)
                releaseMediaPlayerInternal()
                mMainHandler.post { onPrepareFailed(capturedGeneration, capturedIndex) }
                return@onPlayer
            }
            mMainHandler.post {
                if (capturedStartToken != mStartToken) return@post
                onPlaybackStarted(capturedGeneration, capturedIndex, capturedSong, doSeek)
            }
        }
    }

    private fun onPlaybackStarted(
        generation: Long,
        committed: Int,
        song: Song,
        seekPosition: Int
    ) {
        if (generation != mGeneration) return
        if (mState != ServiceState.PREPARING) return
        mState = ServiceState.PLAYING
        mPositionSaveTickCounter = 0
        mPlaybackStartElapsed = SystemClock.elapsedRealtime()
        mPlaybackBasePosition = seekPosition
        mPlaybackBaseElapsed = mPlaybackStartElapsed
        mCachedPosition = seekPosition
        mRecoveryAttempts = 0
        acquireWakeLock()
        requestAudioFocus()
        mMediaSession?.let { try { it.setActive(true) } catch (ignored: Exception) {} }
        updatePlaybackParams()
        saveCurrentPlayingIndex()
        savePlayingState()
        savePlayerState()
        startHealthMonitoring()
        broadcastUpdate()
        if (mDeferredReconcile || mPendingSongPath != null ||
            mTargetIndex != mCurrentIndex || mForceReprepare
        ) mMainHandler.post { reconcile() }
    }

    private fun onPrepareFailed(generation: Long, committed: Int) {
        if (generation != mGeneration) return
        mPauseAfterPrepare = false
        mState = ServiceState.IDLE
        onPlayer { releaseMediaPlayerInternal() }
        if (skipBudgetExhausted()) { abandonSkipLoop(); return }
        if (mDeferredReconcile) { mMainHandler.post { reconcile() }; return }
        mTargetIndex = computeNext(committed)
        noteTransition(+1, false)
        mDeferredReconcile = true
        mMainHandler.post { reconcile() }
    }

    private fun onCompletionInternal() {
        if (mState != ServiceState.PLAYING) return
        if (playlistEmpty()) { transitionToIdle(); return }

        val fromIndex = mCurrentIndex
        val currentPath = pathOf(fromIndex)
        val scopeEmpty = mScopedPlaylist == null || mScopedPlaylist!!.isEmpty()
        var currentScoped = -1
        if (!scopeEmpty && currentPath != null) {
            for (i in mScopedPlaylist!!.indices) {
                if (mScopedPlaylist!![i].path == currentPath) {
                    currentScoped = i; break
                }
            }
        }

        val nextIndex: Int = when {
            mRepeatMode == 2 -> fromIndex
            mIsShuffle -> {
                if (scopeEmpty) { pauseAtEndOfQueue(fromIndex); return }
                val p = pickShuffleNextInScope(fromIndex)
                if (p < 0) { pauseAtEndOfQueue(fromIndex); return }
                p
            }
            mRepeatMode == 1 -> {
                if (scopeEmpty) { pauseAtEndOfQueue(fromIndex); return }
                val nextScoped = if (currentScoped < 0) 0
                else (currentScoped + 1) % mScopedPlaylist!!.size
                val nextSong = mScopedPlaylist!![nextScoped]
                val ni = indexOfPath(nextSong.path)
                if (ni < 0) { pauseAtEndOfQueue(fromIndex); return }
                ni
            }
            else -> {
                if (scopeEmpty) { pauseAtEndOfQueue(fromIndex); return }
                val nextScoped = when {
                    currentScoped < 0 -> 0
                    currentScoped + 1 < mScopedPlaylist!!.size -> currentScoped + 1
                    else -> { pauseAtEndOfQueue(fromIndex); return }
                }
                val nextSong = mScopedPlaylist!![nextScoped]
                val ni = indexOfPath(nextSong.path)
                if (ni < 0) { pauseAtEndOfQueue(fromIndex); return }
                ni
            }
        }

        mTargetIndex = nextIndex
        mPendingSeekPosition = 0
        if (nextIndex == fromIndex) mForceReprepare = true
        noteTransition(+1, nextIndex == fromIndex)
        mMainHandler.post { reconcile() }
    }

    private fun pauseAtEndOfQueue(fromIndex: Int) {
        mState = ServiceState.PAUSED
        mTargetIndex = fromIndex
        mPendingSeekPosition = 0
        mCachedPosition = 0
        mPlaybackBasePosition = 0
        mPlaybackBaseElapsed = 0L
        onPlayer {
            try { mMediaPlayer?.pause() } catch (ignored: Exception) {}
            try { mMediaPlayer?.seekTo(0) } catch (ignored: Exception) {}
        }
        releaseWakeLock()
        savePlayingState()
        savePlayerState()
        broadcastUpdate()
    }

    private fun onPlayerErrorInternal(what: Int, extra: Int) {
        Log.e(TAG, "MediaPlayer error: what=$what extra=$extra")
        mPauseAfterPrepare = false
        mState = ServiceState.IDLE
        mCachedPosition = 0
        mPlaybackBasePosition = 0
        mPlaybackBaseElapsed = 0L
        onPlayer { releaseMediaPlayerInternal() }
        releaseWakeLock()
        if (playlistEmpty()) { transitionToIdle(); return }
        if (skipBudgetExhausted()) { abandonSkipLoop(); return }
        if (mTargetIndex >= 0) mTargetIndex = computeNext(mTargetIndex)
        noteTransition(+1, false)
        mDeferredReconcile = true
        mMainHandler.post { reconcile() }
    }

    private fun onStallInternal() {
        if (mState != ServiceState.PLAYING) return
        mRecoveryAttempts++
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0
            if (playlistEmpty()) { transitionToIdle(); return }
            if (skipBudgetExhausted()) { abandonSkipLoop(); return }
            mTargetIndex = computeNext(mCurrentIndex)
            mPendingSeekPosition = 0
            noteTransition(+1, false)
        } else {
            mTargetIndex = mCurrentIndex
            mPendingSeekPosition = savedPosition
            mForceReprepare = true
            noteTransition(0, false)
        }
        reconcile()
    }

    // ========================================================================
    // Health monitoring
    // ========================================================================

    private fun installHealthCheckRunnable() {
        mHealthCheckRunnable = object : Runnable {
            override fun run() {
                if (mState == ServiceState.PLAYING) refreshPositionFromPlayer()
                if (mState == ServiceState.PLAYING ||
                    mState == ServiceState.PREPARING ||
                    mState == ServiceState.PAUSED
                ) {
                    mHealthHandler?.let { h ->
                        val r = mHealthCheckRunnable
                        if (r != null) h.postDelayed(r, HEALTH_CHECK_INTERVAL_MS)
                    }
                }
            }
        }
    }

    private fun refreshPositionFromPlayer() {
        if (mState != ServiceState.PLAYING) return
        val epoch = mPositionEpoch
        onPlayer {
            val player = mMediaPlayer ?: return@onPlayer
            val position = try { player.currentPosition } catch (exception: Exception) {
                return@onPlayer
            }
            mMainHandler.post {
                if (epoch != mPositionEpoch) return@post
                if (mState != ServiceState.PLAYING) return@post
                mCachedPosition = position
                mPlaybackBasePosition = position
                mPlaybackBaseElapsed = SystemClock.elapsedRealtime()
                val elapsed = SystemClock.elapsedRealtime() - mPlaybackStartElapsed
                if (position < 100 && elapsed > MAX_STALL_TIME_MS) onStallInternal()
                else if (position >= 100) mPlaybackStartElapsed = SystemClock.elapsedRealtime()
                mPositionSaveTickCounter++
                if (mPositionSaveTickCounter >= POSITION_SAVE_INTERVAL_TICKS) {
                    mPositionSaveTickCounter = 0
                    savePlayingState()
                }
            }
        }
    }

    private fun startHealthMonitoring() {
        stopHealthMonitoring()
        mPlaybackStartElapsed = SystemClock.elapsedRealtime()
        mHealthHandler?.let { h ->
            val r = mHealthCheckRunnable
            if (r != null) h.postDelayed(r, HEALTH_CHECK_INTERVAL_MS)
        }
    }

    private fun stopHealthMonitoring() {
        mHealthCheckRunnable?.let { mHealthHandler?.removeCallbacks(it) }
    }

    // ========================================================================
    // Public request API
    // ========================================================================

    fun playSong(index: Int) = playSongInternal(index)
    fun playSongAtPosition(index: Int, position: Int) =
        playSongAtPositionInternal(index, position)
    fun playSongByPath(filePath: String) = playSongByPathInternal(filePath)
    fun requestIncomingFile(filePath: String) {
        onMain {
            clearInterruption()
            mPendingSongPath = filePath
            reconcile()
        }
    }
    fun playNextSong() = playNextSongInternal()
    fun playPreviousSong() = playPreviousSongInternal()
    fun togglePlayPause() = togglePlayPauseInternal()
    fun pause() = pauseInternal()
    fun resume() = resumeInternal()
    fun stop() = stopInternal()
    fun stopCompletely() = stopCompletelyInternal()
    fun seekTo(position: Int) = seekToInternal(position)
    fun setPlaylist(playlist: ArrayList<Song>?, preserveCurrentSong: Boolean) =
        setPlaylistInternal(playlist, preserveCurrentSong)
    fun setPlaylist(playlist: ArrayList<Song>?) = setPlaylistInternal(playlist, false)
    fun updatePlaylist(newPlaylist: ArrayList<Song>) = setPlaylistInternal(newPlaylist, true)
    fun setPendingSongPath(path: String?) = setPendingSongPathInternal(path)
    fun getPendingSongPath(): String? = mPendingSongPath
    fun clearPendingSongPath() {
        onMain { mPendingSongPath = null; Log.d(TAG, "Pending song path cleared") }
    }
    fun playPendingSongIfExists() {
        onMain { if (mPendingSongPath != null) reconcile() }
    }
    fun getCurrentPosition(): Int = estimateCurrentPosition()
    fun getDuration(): Int = mCachedDuration
    val isPlaying: Boolean
        get() = when (mState) {
            ServiceState.PLAYING -> true
            ServiceState.PREPARING -> mAutoStartOnPrepared && !mPauseAfterPrepare
            else -> false
        }
    fun isTransitionPending(): Boolean {
        if (mState == ServiceState.PREPARING) return true
        if (mDeferredReconcile) return true
        if (mForceReprepare) return true
        return mTargetIndex >= 0 && mTargetIndex != mCurrentIndex
    }
    fun isPausedOrReady(): Boolean =
        mState == ServiceState.PAUSED || mState == ServiceState.READY
    fun getCurrentSong(): Song? {
        val list = mCurrentPlaylist ?: return null
        if (list.isEmpty()) return null
        if (mCurrentIndex < 0 || mCurrentIndex >= list.size) return null
        return list[mCurrentIndex]
    }
    fun getCurrentIndex(): Int = mCurrentIndex
    fun setCurrentIndex(index: Int) {
        onMain { mCurrentIndex = index; saveCurrentPlayingIndex() }
    }
    fun getRepeatMode(): Int = mRepeatMode
    fun setRepeatMode(mode: Int) {
        onMain {
            mRepeatMode = mode
            clearShufflePeek()
            savePlayerState()
            broadcastUpdate()
        }
    }
    fun isShuffle(): Boolean = mIsShuffle
    fun setShuffle(shuffle: Boolean) {
        onMain {
            mIsShuffle = shuffle
            clearShufflePeek()
            mShuffleHistory?.clear()
            savePlayerState()
            broadcastUpdate()
        }
    }
    fun setBluetoothConnected(connected: Boolean) {
        mIsBluetoothConnected = connected
    }
    fun getPlaybackScope(): PlaybackScope = mPlaybackScope
    fun getScopedPlaylist(): ArrayList<Song> =
        mScopedPlaylist?.let { ArrayList(it) } ?: ArrayList()
    fun getScopedPlaylistSize(): Int = mScopedPlaylist?.size ?: 0
    fun setPlaybackScope(scope: PlaybackScope?) {
        if (scope == null) return
        onMain { applyPlaybackScopeInternal(scope) }
    }
    private fun applyPlaybackScopeInternal(scope: PlaybackScope) {
        if (scope == mPlaybackScope) return
        mPlaybackScope = scope
        savePlaybackScope()
        rebuildPlaylists()
        broadcastUpdate()
    }
    fun commitFavorites(changes: Map<String, Boolean>?) {
        if (changes.isNullOrEmpty()) return
        onMain {
            val db = SongDatabase.getInstance(this)
            var anyChanged = false
            for ((path, favorite) in changes) {
                if (path == null || favorite == null) continue
                applyFavoriteInList(mFullPlaylist, path, favorite)
                applyFavoriteInList(mScopedPlaylist, path, favorite)
                applyFavoriteInList(mCurrentPlaylist, path, favorite)
                try { db.setFavorite(path, favorite) } catch (e: Exception) {
                    Log.e(TAG, "Failed to persist favorite for $path", e)
                }
                anyChanged = true
            }
            if (!anyChanged) return@onMain
            rebuildPlaylists()
            broadcastUpdate()
            Bus.post(PlayerEvent.Snapshot(
                mGeneration, mState.name, mCurrentIndex, mTargetIndex,
                pathOf(mCurrentIndex), pathOf(mTargetIndex), isPlaying,
                estimateCurrentPosition(), mCachedDuration,
                getWindowSnapshot(), mGenerationDirection, mGenerationRestart,
                getDisplaySong()?.title, getDisplaySong()?.artist,
                getCurrentSong()?.isFavorite ?: false,
                mPlaybackScope.kind.name, mScopedPlaylist?.size ?: 0
            ))
        }
    }
    fun toggleFavorite() {
        onMain {
            val current = getCurrentSong() ?: return@onMain
            if (current.path.isEmpty()) return@onMain
            val single = HashMap<String, Boolean>()
            single[current.path] = !current.isFavorite
            commitFavorites(single)
        }
    }
    fun savePlayerState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, estimateCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, isPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply()
    }
    val savedPosition: Int
        get() = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_CURRENT_POSITION, 0)
    fun wasPlayingBeforeRestart(): Boolean =
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_LAST_PLAYING, false)
    val savedSongPath: String?
        get() = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_LAST_SONG_PATH, null)
    fun getCurrentPlaylist(): ArrayList<Song> =
        synchronized(this) {
            mCurrentPlaylist?.let { ArrayList(it) } ?: ArrayList()
        }
    fun updatePlaybackParams() = updatePlaybackParamsInternal()
    fun getSessionToken(): MediaSessionCompat.Token? = mMediaSession?.sessionToken
    fun handleMediaButton(keyCode: Int) = handleMediaButtonInternal(keyCode)
    fun refreshMetadataForSong(
        songPath: String, newTitle: String?, newArtist: String?,
        newAlbum: String?, newGenre: String?, uriString: String?,
        albumArtBytes: ByteArray?, albumArtRemoved: Boolean
    ) {
        onMain {
            var playlistChanged = false
            var resolvedUri: String? = uriString?.takeIf { it.isNotEmpty() }
            var knownTitle = newTitle
            var knownArtist = newArtist
            var knownAlbum = newAlbum
            var knownGenre = newGenre
            var knownDuration = 0L

            mCurrentPlaylist?.let { list ->
                for (i in list.indices) {
                    val s = list[i] ?: continue
                    if (s.path != songPath) continue
                    if (knownTitle == null) knownTitle = s.title
                    if (knownArtist == null) knownArtist = s.artist
                    if (knownAlbum == null) knownAlbum = s.album
                    if (knownGenre == null) knownGenre = s.genre
                    if (resolvedUri == null) resolvedUri = s.uri
                    if (knownDuration == 0L) knownDuration = s.duration
                    val updated = Song(
                        if (newTitle != null && newTitle.isNotEmpty()) newTitle else s.title,
                        if (newArtist != null && newArtist.isNotEmpty()) newArtist else s.artist,
                        if (newAlbum != null && newAlbum.isNotEmpty()) newAlbum else s.album,
                        if (newGenre != null && newGenre.isNotEmpty()) newGenre else s.genre,
                        songPath, s.duration, resolvedUri ?: s.uri
                    )
                    list[i] = updated
                    playlistChanged = true
                }
            }

            if (playlistChanged) {
                val persisted = Song(
                    knownTitle ?: CharacterMapper.getUnknownTitle(),
                    knownArtist ?: CharacterMapper.getUnknownArtist(),
                    knownAlbum ?: CharacterMapper.getUnknownAlbum(),
                    knownGenre ?: CharacterMapper.getUnknownGenre(),
                    songPath, knownDuration, resolvedUri
                )
                SongDatabase.getInstance(this).insertSong(persisted)
            }

            val shared = AlbumArtCache.getInstance(this).asLruCache()
            shared.remove(songPath)
            resolvedUri?.let { shared.remove(it) }
            mArtCache.remove(songPath)

            if (albumArtRemoved) {
                mResolvedArtPath = songPath
                mResolvedArt = null
                mCurrentArtLoad?.cancel(true); mCurrentArtLoad = null
            } else if (albumArtBytes != null) {
                val newArt = BitmapFactory.decodeByteArray(albumArtBytes, 0, albumArtBytes.size)
                if (newArt != null) {
                    shared.put(songPath, newArt)
                    mArtCache.put(songPath, newArt)
                    mResolvedArtPath = songPath
                    mResolvedArt = newArt
                }
            }
            broadcastUpdate()
        }
    }

    // ========================================================================
    // Internal request implementations
    // ========================================================================

    private fun playSongInternal(index: Int) {
        onMain {
            clearInterruption()
            if (index < 0 || index >= playlistSize()) return@onMain
            mSkipLoopStartedElapsed = 0L
            mTargetIndex = index
            mPendingSeekPosition = 0
            reconcile()
        }
    }

    private fun playSongAtPositionInternal(index: Int, position: Int) {
        onMain {
            clearInterruption()
            if (index < 0 || index >= playlistSize()) return@onMain
            mSkipLoopStartedElapsed = 0L
            mTargetIndex = index
            mPendingSeekPosition = position
            reconcile()
        }
    }

    private fun playSongByPathInternal(filePath: String) {
        onMain {
            clearInterruption()
            val idx = indexOfPath(filePath)
            if (idx >= 0) {
                mSkipLoopStartedElapsed = 0L
                mTargetIndex = idx
                mPendingSeekPosition = 0
                reconcile()
            } else {
                mPendingSongPath = filePath
                Log.d(TAG, "playSongByPath: not in playlist, parked: $filePath")
            }
        }
    }

    private fun playNextSongInternal() {
        onMain {
            clearInterruption()
            if (playlistEmpty() || mState == ServiceState.STOPPING) return@onMain
            mSkipLoopStartedElapsed = 0L
            var base = if (mState == ServiceState.PREPARING && mTargetIndex >= 0)
                mTargetIndex else mCurrentIndex
            if (base < 0) base = 0
            val restart: Boolean
            if (mRepeatMode == 2) {
                mTargetIndex = base
                mForceReprepare = true
                restart = true
            } else {
                mTargetIndex = computeNext(base)
                restart = mTargetIndex == base
                if (restart) mForceReprepare = true
            }
            mPendingSeekPosition = 0
            noteTransition(+1, restart)
            reconcile()
        }
    }

    private fun playPreviousSongInternal() {
        onMain {
            clearInterruption()
            if (playlistEmpty() || mState == ServiceState.STOPPING) return@onMain
            mSkipLoopStartedElapsed = 0L
            var base = if (mState == ServiceState.PREPARING && mTargetIndex >= 0)
                mTargetIndex else mCurrentIndex
            if (base < 0) base = 0
            val restart: Boolean
            if (mRepeatMode == 2) {
                mTargetIndex = base
                mForceReprepare = true
                restart = true
            } else {
                mTargetIndex = computePrevious(base)
                restart = mTargetIndex == base
                if (restart) mForceReprepare = true
            }
            mPendingSeekPosition = 0
            noteTransition(-1, restart)
            reconcile()
        }
    }

    private fun togglePlayPauseInternal() {
        onMain {
            clearInterruption()
            when (mState) {
                ServiceState.PLAYING -> doPauseInternal()
                ServiceState.PAUSED, ServiceState.READY -> doResumeInternal()
                ServiceState.IDLE -> {
                    if (playlistEmpty()) { broadcastUpdate(); return@onMain }
                    mSkipLoopStartedElapsed = 0L
                    if (mTargetIndex < 0) mTargetIndex = 0
                    reconcile()
                }
                ServiceState.PREPARING -> {
                    val currentlyPlays = mAutoStartOnPrepared && !mPauseAfterPrepare
                    if (currentlyPlays) mPauseAfterPrepare = true
                    else { mPauseAfterPrepare = false; mAutoStartOnPrepared = true }
                }
                ServiceState.STOPPING -> { }
            }
        }
    }

    private fun pauseInternal() {
        onMain {
            clearInterruption()
            when (mState) {
                ServiceState.PLAYING -> doPauseInternal()
                ServiceState.PREPARING -> mPauseAfterPrepare = true
                else -> { }
            }
        }
    }

    private fun resumeInternal() {
        onMain {
            clearInterruption()
            when (mState) {
                ServiceState.PAUSED -> doResumeInternal()
                ServiceState.READY -> togglePlayPauseInternal()
                ServiceState.IDLE -> {
                    mSkipLoopStartedElapsed = 0L
                    if (mTargetIndex < 0 && !playlistEmpty()) mTargetIndex = 0
                    reconcile()
                }
                ServiceState.PREPARING -> {
                    if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                        mPauseAfterPrepare = false
                        mAutoStartOnPrepared = true
                    }
                }
                else -> { }
            }
        }
    }

    private fun stopInternal() {
        onMain {
            clearInterruption()
            if (mState != ServiceState.PLAYING && mState != ServiceState.PAUSED) return@onMain
            val stoppedAt = mCurrentIndex
            onPlayer { releaseMediaPlayerInternal() }
            releaseWakeLock()
            mCurrentIndex = -1
            mTargetIndex = stoppedAt
            mPendingSeekPosition = 0
            mPauseAfterPrepare = false
            mForceReprepare = false
            mDeferredReconcile = false
            mSkipLoopStartedElapsed = 0L
            clearNotedTransition()
            mCachedWindow = null
            mState = ServiceState.IDLE
            mPositionSaveTickCounter = 0
            mCachedPosition = 0
            mCachedDuration = 0
            mPlaybackBasePosition = 0
            mPlaybackBaseElapsed = 0L
            savePlayingState()
            savePlayerState()
            broadcastUpdate()
        }
    }

    private fun stopCompletelyInternal() {
        onMain {
            clearInterruption()
            transitionToIdle()
        }
    }

    private fun doPauseInternal() {
        mStartToken++
        mPositionSaveTickCounter = 0
        val pos = estimateCurrentPosition()
        mState = ServiceState.PAUSED
        mCachedPosition = pos
        mPlaybackBasePosition = pos
        mPlaybackBaseElapsed = 0L
        onPlayer {
            try { mMediaPlayer?.pause() } catch (ignored: Exception) {}
        }
        releaseWakeLock()
        savePlayingState()
        savePlayerState()
        broadcastUpdate()
        mNotificationController?.demoteFromForeground()
    }

    private fun doResumeInternal() {
        if (!requestAudioFocus(true)) {
            Log.d(TAG, "doResume refused: audio focus not granted")
            return
        }
        updatePlaybackParams()
        val captured = ++mStartToken
        onPlaybackResumedInternal()
        raiseVolumeIfSilentForResume()
        onPlayer {
            var started = false
            try { mMediaPlayer?.start(); started = true } catch (e: Exception) {
                Log.e(TAG, "resume: start() failed", e)
            }
            if (started) return@onPlayer
            mMainHandler.post {
                if (captured != mStartToken) return@post
                if (mState != ServiceState.PLAYING) return@post
                mState = ServiceState.IDLE
                onPlayer { releaseMediaPlayerInternal() }
                releaseWakeLock()
                savePlayerState()
                broadcastUpdate()
                reconcile()
            }
        }
    }

    private fun onPlaybackResumedInternal() {
        mState = ServiceState.PLAYING
        mPositionSaveTickCounter = 0
        mPlaybackStartElapsed = SystemClock.elapsedRealtime()
        mPlaybackBaseElapsed = mPlaybackStartElapsed
        acquireWakeLock()
        mMediaSession?.let { try { it.setActive(true) } catch (ignored: Exception) {} }
        clearInterruption()
        savePlayingState()
        savePlayerState()
        startHealthMonitoring()
        broadcastUpdate()
    }

    private fun seekToInternal(position: Int) {
        onMain {
            if (mState == ServiceState.PREPARING) {
                mPendingSeekPosition = position
                return@onMain
            }
            if (mState == ServiceState.PLAYING ||
                mState == ServiceState.PAUSED ||
                mState == ServiceState.READY
            ) {
                mPositionEpoch++
                onPlayer {
                    try { mMediaPlayer?.seekTo(position) } catch (ignored: Exception) {}
                }
                mCachedPosition = position
                mPlaybackBasePosition = position
                if (mState == ServiceState.PLAYING) {
                    mPlaybackBaseElapsed = SystemClock.elapsedRealtime()
                }
                mPositionSaveTickCounter = 0
                savePlayerState()
                broadcastUpdate()
            }
        }
    }

    private fun setPlaylistInternal(playlist: ArrayList<Song>?, preserveCurrentSong: Boolean) {
        onMain {
            if (mState == ServiceState.STOPPING) return@onMain
            if (playlist == null || playlist.isEmpty()) {
                if (playlistEmpty()) { broadcastUpdate(); return@onMain }
                transitionToIdle()
                return@onMain
            }
            val sorted = ArrayList(playlist)
            Collections.sort(sorted, getComparatorForSortMode(mCurrentSortMode))

            val fullList = mFullPlaylist
            if (fullList != null && fullList.size == sorted.size && sameOrder(fullList, sorted)) {
                rebuildPlaylists()
                broadcastUpdate()
                return@onMain
            }

            val playingPath = pathOf(mCurrentIndex)
            val targetPath = pathOf(mTargetIndex)
            val hasPending = mPendingSongPath != null
            var anchorPath = mPendingSongPath ?: playingPath ?: savedSongPath
            var anchorSong: Song? = null
            if (anchorPath != null) {
                for (s in sorted) if (s.path == anchorPath) { anchorSong = s; break }
            }

            mFullPlaylist = sorted
            rebuildPlaylists()

            var resolved = if (anchorPath != null) indexOfPath(anchorPath) else -1
            if (resolved < 0 && anchorSong != null) {
                for (i in 0 until playlistSize()) {
                    val c = mCurrentPlaylist!![i]
                    if (c != null && c.title == anchorSong.title) { resolved = i; break }
                }
            }

            if (hasPending && resolved < 0 && mState != ServiceState.PREPARING) {
                broadcastUpdate(); return@onMain
            }
            if (resolved < 0) resolved = 0

            if (mState == ServiceState.PREPARING) {
                if (targetPath != null) {
                    val newTarget = indexOfPath(targetPath)
                    if (newTarget >= 0) mTargetIndex = newTarget
                }
                reconcile()
                broadcastUpdate()
                return@onMain
            }

            val resolvedPath = pathOf(resolved)
            val sameSong = playingPath != null && !hasPending &&
                playingPath == resolvedPath &&
                (mState == ServiceState.PLAYING ||
                    mState == ServiceState.PAUSED ||
                    mState == ServiceState.READY)
            if (sameSong) {
                mCurrentIndex = resolved
                mTargetIndex = resolved
                broadcastUpdate(); return@onMain
            }

            val coldStart = mCurrentIndex == -1 && mState == ServiceState.IDLE
            if (coldStart) {
                if (anchorPath != null && anchorPath == savedSongPath) {
                    val saved = savedPosition
                    if (saved > 0) mPendingSeekPosition = saved
                }
                if (!wasPlayingBeforeRestart() && !hasPending) {
                    mPauseAfterPrepare = true
                }
            }
            mTargetIndex = resolved
            reconcile()
        }
    }

    private fun setPendingSongPathInternal(path: String?) {
        onMain {
            if (path == null) {
                mPendingSongPath = null
                Log.d(TAG, "Pending song path cleared")
                return@onMain
            }
            clearInterruption()
            mPendingSongPath = path
            reconcile()
        }
    }

    private fun rebuildPlaylists() {
        refreshLooseTrackPaths()
        mScopedPlaylist = ArrayList()
        mFullPlaylist?.let { full ->
            for (s in full) {
                if (s != null && mPlaybackScope.matches(s, mLooseTrackPaths)) {
                    mScopedPlaylist!!.add(s)
                }
            }
        }
        val currentPath = pathOf(mCurrentIndex)
        val targetPath = pathOf(mTargetIndex)
        val next = ArrayList(mScopedPlaylist!!)
        if (currentPath != null && !containsPath(next, currentPath)) {
            findSongInFull(currentPath)?.let { next.add(it) }
        }
        if (targetPath != null && targetPath != currentPath &&
            !containsPath(next, targetPath)
        ) {
            findSongInFull(targetPath)?.let { next.add(it) }
        }
        mCurrentPlaylist = next
        if (currentPath != null) {
            val i = indexOfPath(currentPath)
            if (i >= 0) mCurrentIndex = i
        }
        if (targetPath != null) {
            val i = indexOfPath(targetPath)
            if (i >= 0) mTargetIndex = i
        }
        mCachedWindow = null
        clearShufflePeek()
        mShuffleHistory?.clear()
        Log.d(TAG, "rebuildPlaylists: full=${mFullPlaylist?.size ?: 0}, " +
            "scoped=${mScopedPlaylist!!.size}, current=${playlistSize()}, " +
            "kind=${mPlaybackScope.kind}")
    }

    private fun containsPath(list: ArrayList<Song>, path: String?): Boolean {
        if (path == null) return false
        for (s in list) if (s?.path == path) return true
        return false
    }

    private fun findSongInFull(path: String?): Song? {
        if (path == null) return null
        mFullPlaylist?.let { full -> for (s in full) if (s?.path == path) return s }
        return null
    }

    private fun refreshLooseTrackPaths() {
        mLooseTrackPaths = HashSet()
        try {
            val loose = SongDatabase.getInstance(this).looseSongs
            for (s in loose) if (s.path.isNotEmpty()) mLooseTrackPaths.add(s.path)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to refresh loose track paths", e)
        }
    }

    private fun applyFavoriteInList(list: ArrayList<Song>?, path: String, favorite: Boolean) {
        list ?: return
        for (s in list) if (s.path == path) s.setFavorite(favorite)
    }

    private fun sameOrder(a: ArrayList<Song>, b: ArrayList<Song>): Boolean {
        if (a.size != b.size) return false
        for (i in a.indices) if (a[i].path != b[i].path) return false
        return true
    }

    // ========================================================================
    // MediaSession / AudioFocus
    // ========================================================================

    private fun setupMediaSession() {
        try {
            val receiver = ComponentName(this, androidx.media.session.MediaButtonReceiver::class.java)
            mMediaSession = MediaSessionCompat(this, "LlamaMusicService", receiver, null)
            mMediaSession!!.setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    if (isNotificationActionDebounced(ACTION_PLAY_PAUSE)) return
                    onMain {
                        if (!mHasAudioFocus && mState != ServiceState.IDLE &&
                            mState != ServiceState.PREPARING
                        ) return@onMain
                        clearInterruption()
                        when (mState) {
                            ServiceState.PAUSED -> doResumeInternal()
                            ServiceState.IDLE -> resumeInternal()
                            ServiceState.READY -> togglePlayPauseInternal()
                            ServiceState.PREPARING -> {
                                if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                                    mPauseAfterPrepare = false
                                    mAutoStartOnPrepared = true
                                }
                            }
                            else -> { }
                        }
                    }
                }
                override fun onPause() {
                    if (isNotificationActionDebounced(ACTION_PLAY_PAUSE)) return
                    onMain {
                        clearInterruption()
                        when (mState) {
                            ServiceState.PLAYING -> doPauseInternal()
                            ServiceState.PREPARING -> mPauseAfterPrepare = true
                            else -> { }
                        }
                    }
                }
                override fun onSkipToNext() {
                    if (isNotificationActionDebounced(ACTION_NEXT)) return
                    playNextSongInternal()
                }
                override fun onSkipToPrevious() {
                    if (isNotificationActionDebounced(ACTION_PREV)) return
                    playPreviousSongInternal()
                }
                override fun onStop() {
                    if (isNotificationActionDebounced(ACTION_PLAY_PAUSE)) return
                    onMain {
                        clearInterruption()
                        if (mState == ServiceState.PLAYING) doPauseInternal()
                    }
                }
                override fun onPlayFromMediaId(mediaId: String?, extras: Bundle?) {
                    if (mediaId == null) return
                    try { playSongInternal(mediaId.toInt()) } catch (ignored: Exception) {}
                }
            })
            mMediaSession!!.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS)
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to setup MediaSession", exception)
        }
    }

    private fun updateMediaSessionPlaybackState() {
        val session = mMediaSession ?: return
        try {
            val actions = (PlaybackStateCompat.ACTION_PLAY or
                PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_PLAY_PAUSE or
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                PlaybackStateCompat.ACTION_STOP).toLong()
            val builder = PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(mStateSource.sessionPlaybackState(),
                    estimateCurrentPosition().toLong(), 1.0f)
            session.setPlaybackState(builder.build())
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to update MediaSession state", exception)
        }
    }

    private fun setupAudioFocus() {
        mAudioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
            handleAudioFocusChange(change)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            mAudioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener!!)
                .setAudioAttributes(attrs)
                .build()
            mAudioFocusRequestTransient =
                AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setOnAudioFocusChangeListener(mAudioFocusListener!!)
                    .setAudioAttributes(attrs)
                    .build()
        }
    }

    @Suppress("DEPRECATION")
    private fun requestAudioFocus(transient: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = if (transient) mAudioFocusRequestTransient else mAudioFocusRequest
            if (req != null) {
                return mAudioManager?.requestAudioFocus(req) ==
                    AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } else {
            val listener = mAudioFocusListener
            val am = mAudioManager
            if (listener != null && am != null) {
                return am.requestAudioFocus(
                    listener, AudioManager.STREAM_MUSIC,
                    if (transient) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                    else AudioManager.AUDIOFOCUS_GAIN
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        }
        return false
    }

    private fun requestAudioFocus(): Boolean = requestAudioFocus(false)

    @Suppress("DEPRECATION")
    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mAudioFocusRequest?.let { mAudioManager?.abandonAudioFocusRequest(it) }
        } else {
            mAudioFocusListener?.let { mAudioManager?.abandonAudioFocus(it) }
        }
    }

    private fun raiseVolumeIfSilentForResume() {
        val am = mAudioManager ?: return
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max <= 0) return
            val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (current != 0) return
            val target = Math.min(3, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            Log.d(TAG, "Raised music volume to $target/$max for resume")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to raise volume for resume", e)
        }
    }

    @Suppress("DEPRECATION")
    private fun isBluetoothChosenOutput(): Boolean =
        mAudioManager?.isBluetoothA2dpOn == true

    private fun onBluetoothDisconnect(intent: Intent?) {
        val profileAction = intent?.getStringExtra(EXTRA_PROFILE_ACTION)
        val profileState = intent?.getIntExtra(EXTRA_PROFILE_STATE, -1) ?: -1
        if (mInterruption != null) {
            Log.d(TAG, "Bluetooth disconnect ignored: interruption in progress" +
                " profile=$profileAction state=$profileState")
            return
        }
        if (!isBluetoothChosenOutput()) {
            Log.d(TAG, "Bluetooth disconnect ignored: not the active output" +
                " profile=$profileAction state=$profileState")
            return
        }
        if (mState != ServiceState.PLAYING) {
            Log.d(TAG, "Bluetooth disconnect ignored: state=$mState" +
                " profile=$profileAction state=$profileState")
            return
        }
        cancelBluetoothPauseConfirmation()
        mBluetoothPauseConfirmRunnable = Runnable {
            mBluetoothPauseConfirmRunnable = null
            if (mState != ServiceState.PLAYING) return@Runnable
            if (isBluetoothChosenOutput()) {
                Log.d(TAG, "Bluetooth disconnect suppressed: route restored")
                return@Runnable
            }
            Log.d(TAG, "Bluetooth disconnect confirmed: pausing")
            pauseInternal()
        }
        mMainHandler.postDelayed(mBluetoothPauseConfirmRunnable!!, BLUETOOTH_DISCONNECT_CONFIRM_MS)
    }

    private fun cancelBluetoothPauseConfirmation() {
        mBluetoothPauseConfirmRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mBluetoothPauseConfirmRunnable = null
        }
    }

    private fun shouldResumeAfterInterruption(): Boolean {
        val interruption = mInterruption ?: return false
        if (!interruption.wasPlaying) return false
        if (interruption.generationAtStart != mGeneration) return false
        return mState == ServiceState.PAUSED ||
            mState == ServiceState.PREPARING ||
            mState == ServiceState.READY
    }

    private fun shouldRemainForeground(): Boolean {
        val interruption = mInterruption ?: return false
        if (!interruption.wasPlaying) return false
        if (interruption.generationAtStart != mGeneration) return false
        if (mState == ServiceState.IDLE || mState == ServiceState.STOPPING) return false
        return !playlistEmpty()
    }

    private fun clearInterruption() {
        mInterruption = null
        mResumeRetryCount = 0
        mResumeRetryRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mResumeRetryRunnable = null
        }
        cancelBluetoothPauseConfirmation()
    }

    private fun resumeAfterInterruption() {
        if (!shouldResumeAfterInterruption()) { clearInterruption(); return }
        if (requestAudioFocus(true)) {
            clearInterruption()
            when (mState) {
                ServiceState.PAUSED -> doResumeInternal()
                ServiceState.PREPARING -> {
                    mPauseAfterPrepare = false; mAutoStartOnPrepared = true
                }
                ServiceState.READY -> togglePlayPauseInternal()
                else -> { }
            }
            return
        }
        if (mResumeRetryCount < RESUME_RETRY_ATTEMPTS) {
            mResumeRetryCount++
            mResumeRetryRunnable?.let { mMainHandler.removeCallbacks(it) }
            mResumeRetryRunnable = Runnable { resumeAfterInterruption() }
            mMainHandler.postDelayed(mResumeRetryRunnable!!, RESUME_RETRY_INTERVAL_MS)
            return
        }
        Log.w(TAG, "resumeAfterInterruption: focus unavailable after " +
            "$RESUME_RETRY_ATTEMPTS attempts; leaving resumable")
        mResumeRetryCount = 0
        mResumeRetryRunnable = null
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                mHasAudioFocus = false
                val kind = if (focusChange == AudioManager.AUDIOFOCUS_LOSS)
                    InterruptionKind.PERMANENT_LOSS else InterruptionKind.TRANSIENT_LOSS
                if (mInterruption == null &&
                    (mState == ServiceState.PLAYING ||
                        mState == ServiceState.PREPARING ||
                        mState == ServiceState.READY)
                ) {
                    val wasPlaying = mState == ServiceState.PLAYING ||
                        (mState == ServiceState.PREPARING &&
                            mAutoStartOnPrepared && !mPauseAfterPrepare)
                    if (wasPlaying) {
                        mInterruption = Interruption(
                            kind, SystemClock.elapsedRealtime(), true, mGeneration
                        )
                    }
                } else if (mInterruption != null &&
                    mInterruption!!.kind == InterruptionKind.TRANSIENT_LOSS &&
                    kind == InterruptionKind.PERMANENT_LOSS
                ) {
                    mInterruption = Interruption(
                        kind, SystemClock.elapsedRealtime(),
                        mInterruption!!.wasPlaying, mGeneration
                    )
                }
                when (mState) {
                    ServiceState.PLAYING -> doPauseInternal()
                    ServiceState.PREPARING -> {
                        mPauseAfterPrepare = true
                        mAutoStartOnPrepared = false
                    }
                    else -> { }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                mHasAudioFocus = false
                mIsDucked = true
                onPlayer { applyDuckVolume(mMediaPlayer) }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                mHasAudioFocus = true
                if (mIsDucked) {
                    mIsDucked = false
                    onPlayer { applyDuckVolume(mMediaPlayer) }
                }
                // Gesture-triggered resume that was deferred
                // fires here, before the interruption-record branch.
                if (mPendingResumeFromGesture) {
                    mPendingResumeFromGesture = false
                    if (mState == ServiceState.PAUSED) {
                        doResumeInternal()
                        return
                    }
                }
                if (mInterruption == null) return
                if (mAudioManager?.mode != AudioManager.MODE_NORMAL) {
                    if (mResumeRetryCount < RESUME_RETRY_ATTEMPTS) {
                        mResumeRetryCount++
                        mResumeRetryRunnable?.let { mMainHandler.removeCallbacks(it) }
                        mResumeRetryRunnable = Runnable { resumeAfterInterruption() }
                        mMainHandler.postDelayed(mResumeRetryRunnable!!, RESUME_RETRY_INTERVAL_MS)
                    }
                    return
                }
                resumeAfterInterruption()
            }
            else -> { }
        }
    }

    private fun applyDuckVolume(player: MediaPlayer?) {
        player ?: return
        val volume = if (mIsDucked) DUCK_VOLUME_FRACTION else 1.0f
        try { player.setVolume(volume, volume) } catch (ignored: Exception) {}
    }

    // ========================================================================
    // Media button
    // ========================================================================

    private fun handleMediaButtonInternal(keyCode: Int) {
        if (mIsBluetoothConnected &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) &&
            !mHasAudioFocus
        ) return

        clearInterruption()

        if (mIsBluetoothConnected) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    if (!isNotificationActionDebounced(ACTION_NEXT))
                        playNextSongInternal()
                    return
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    if (!isNotificationActionDebounced(ACTION_PREV))
                        playPreviousSongInternal()
                    return
                }
            }
        }
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (!isNotificationActionDebounced(ACTION_PLAY_PAUSE))
                    togglePlayPauseInternal()
            }
            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (!isNotificationActionDebounced(ACTION_NEXT))
                    playNextSongInternal()
            }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (!isNotificationActionDebounced(ACTION_PREV))
                    playPreviousSongInternal()
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (isNotificationActionDebounced(ACTION_PLAY_PAUSE)) return
                when (mState) {
                    ServiceState.PAUSED -> doResumeInternal()
                    ServiceState.IDLE -> resumeInternal()
                    ServiceState.READY -> togglePlayPauseInternal()
                    ServiceState.PREPARING -> {
                        if (mPauseAfterPrepare || !mAutoStartOnPrepared) {
                            mPauseAfterPrepare = false
                            mAutoStartOnPrepared = true
                        }
                    }
                    else -> { }
                }
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (isNotificationActionDebounced(ACTION_PLAY_PAUSE)) return
                when (mState) {
                    ServiceState.PLAYING -> doPauseInternal()
                    ServiceState.PREPARING -> mPauseAfterPrepare = true
                    else -> { }
                }
            }
        }
    }

    // ========================================================================
    // Bus broadcast
    // ========================================================================

    private fun broadcastUpdate() {
        val window = getWindowSnapshot()
        val displaySong = getDisplaySong()
        val currentSong = getCurrentSong()
        val generation = mGeneration

        Bus.postSticky(PlayerEvent.Snapshot(
            generation, mState.name, mCurrentIndex, mTargetIndex,
            pathOf(mCurrentIndex), pathOf(mTargetIndex), isPlaying,
            estimateCurrentPosition(), mCachedDuration, window,
            mGenerationDirection, mGenerationRestart,
            displaySong?.title, displaySong?.artist,
            currentSong?.isFavorite ?: false,
            mPlaybackScope.kind.name,
            mScopedPlaylist?.size ?: 0
        ))

        val snapshot = mStateSource.snapshotForNotification()
        mNotificationController?.commitFromBroadcast(generation, snapshot)
    }

    private fun broadcastAudioSessionChanged(sessionId: Int) {
        Bus.post(SessionEvent.AudioSessionChanged(sessionId))
    }

    // ========================================================================
    // Bus subscribers
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportPlay(event: TransportEvent.PlaySong) {
        val path = event.path ?: return
        playSongByPathInternal(path)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportPlayIndex(event: TransportEvent.PlaySongByIndex) {
        playSongInternal(event.index)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportPlayAtPosition(event: TransportEvent.PlaySongAtPosition) {
        playSongAtPositionInternal(event.index, event.positionMs)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportToggle(event: TransportEvent.TogglePlayPause) = togglePlayPauseInternal()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportNext(event: TransportEvent.Next) = playNextSongInternal()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportPrevious(event: TransportEvent.Previous) = playPreviousSongInternal()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportResume(event: TransportEvent.Resume) = resumeInternal()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportPause(event: TransportEvent.Pause) {
        onMain { onBluetoothDisconnect(null) }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportStop(event: TransportEvent.Stop) = stopInternal()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportToggleFavorite(event: TransportEvent.ToggleFavorite) = toggleFavorite()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportRequestResumeFromGesture(event: TransportEvent.RequestResumeFromGesture) =
        requestResumeFromGesture()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSaveState(event: TransportEvent.SavePlayerState) = savePlayerState()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSeekTo(event: TransportEvent.SeekTo) = seekToInternal(event.positionMs)

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSetPendingSong(event: TransportEvent.SetPendingSong) =
        setPendingSongPathInternal(event.path)

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSetRepeatMode(event: TransportEvent.SetRepeatMode) = setRepeatMode(event.mode)

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSetShuffle(event: TransportEvent.SetShuffle) = setShuffle(event.enabled)

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSetBluetooth(event: TransportEvent.SetBluetoothConnected) =
        setBluetoothConnected(event.connected)

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onTransportSetPlaybackSortMode(event: TransportEvent.SetPlaybackSortMode) {
        onMain {
            mCurrentSortMode = event.sortMode
            saveSortModeInternal()
            if (mCurrentPlaylist != null && mCurrentPlaylist!!.isNotEmpty()) {
                val snapshot = ArrayList(mCurrentPlaylist!!)
                val anchorPath = pathOf(mCurrentIndex)
                mSortExecutor.execute {
                    Collections.sort(snapshot, getComparatorForSortMode(event.sortMode))
                    onMain {
                        if (mCurrentSortMode != event.sortMode) return@onMain
                        if (mCurrentPlaylist == null || mCurrentPlaylist!!.isEmpty()) return@onMain
                        mCurrentPlaylist = snapshot
                        clearShufflePeek()
                        mShuffleHistory?.clear()
                        if (anchorPath != null) {
                            val i = indexOfPath(anchorPath)
                            if (i >= 0) {
                                mCurrentIndex = i
                                mTargetIndex = i
                                saveCurrentPlayingIndex()
                            }
                        }
                        broadcastUpdate()
                    }
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlayerApplyScope(event: PlayerEvent.ApplyScope) {
        val scope = PlaybackScope.deserialize(event.serializedScope)
        applyPlaybackScopeInternal(scope)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaylistRefresh(event: PlaylistEvent.Refresh) {
        if (mMusicLibrary == null) mMusicLibrary = MusicLibrary(this)
        mMusicLibrary?.refreshCache()
        val songs = mMusicLibrary?.getAllSongs()
        if (songs != null && songs.isNotEmpty()) setPlaylistInternal(songs, true)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaylistLibraryReset(event: PlaylistEvent.LibraryReset) {
        val preserve = event.preserveSettings
        onMain {
            stopCompletelyInternal()
            mResolvedArtPath = null
            mResolvedArt = null
            mCurrentArtLoad?.cancel(true); mCurrentArtLoad = null
            mArtCache.evictAll()
            mMusicLibrary?.invalidate()
            if (!preserve) {
                mRepeatMode = 0
                mIsShuffle = false
                mCurrentSortMode = SORT_TITLE_AZ
                mShuffleHistory?.clear()
                clearShufflePeek()
                savePlayerState()
                saveSortModeInternal()
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMetadataUpdated(event: MetadataEvent.Updated) {
        val path = event.songPath ?: resolveSongPathFromUri(event.songUri) ?: return
        refreshMetadataForSong(
            path, event.title, event.artist, event.album, event.genre,
            event.songUri, event.albumArtBytes, event.albumArtRemoved
        )
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMetadataGenreUpdate(event: MetadataEvent.GenreUpdated) {
        if (event.status == "UPDATE") {
            val path = event.songPath ?: return
            val newGenre = event.genre ?: return
            updateGenreInPlaylist(path, newGenre)
        } else if (event.status == "COMPLETE") {
            broadcastUpdate()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onSessionPlaybackParamsRefresh(event: SessionEvent.PlaybackParamsRefresh) {
        updatePlaybackParamsInternal()
    }

    private fun resolveSongPathFromUri(uriString: String?): String? {
        if (uriString == null || uriString.isEmpty()) return null
        return try {
            SongDatabase.getInstance(this).allSongs.firstOrNull { it.uri == uriString }?.path
        } catch (e: Exception) {
            Log.w(TAG, "resolveSongPathFromUri failed", e); null
        }
    }

    private fun updateGenreInPlaylist(path: String, newGenre: String) {
        mCurrentPlaylist?.let { list ->
            for (i in list.indices) {
                if (list[i].path == path) {
                    if (list[i].genre != newGenre) list[i].setGenre(newGenre)
                    break
                }
            }
        }
    }

    // ========================================================================
    // Gesture resume
    // ========================================================================

    fun requestResumeFromGesture() {
        onMain {
            clearInterruption()
            when (mState) {
                ServiceState.PAUSED -> {
                    if (requestAudioFocus(true)) {
                        doResumeInternal()
                    } else {
                        mPendingResumeFromGesture = true
                        Log.d(TAG, "Gesture resume deferred: focus refused")
                    }
                }
                ServiceState.READY -> togglePlayPauseInternal()
                ServiceState.IDLE -> {
                    mSkipLoopStartedElapsed = 0L
                    if (mTargetIndex < 0 && !playlistEmpty()) mTargetIndex = 0
                    reconcile()
                }
                else -> { }
            }
        }
    }

    // ========================================================================
    // MediaPlayer plumbing
    // ========================================================================

    private fun removeAllListeners(player: MediaPlayer?) {
        player ?: return
        try {
            player.setOnPreparedListener(null)
            player.setOnCompletionListener(null)
            player.setOnErrorListener(null)
            player.setOnBufferingUpdateListener(null)
            player.setOnInfoListener(null)
            player.setOnSeekCompleteListener(null)
        } catch (ignored: Exception) {}
    }

    private fun releaseMediaPlayerInternal() {
        mMediaPlayer?.let { player ->
            removeAllListeners(player)
            try { if (player.isPlaying) player.stop() } catch (ignored: Exception) {}
            try { player.reset() } catch (ignored: Exception) {}
            try { player.release() } catch (ignored: Exception) {}
            mMediaPlayer = null
        }
    }

    private fun getOrCreatePlayerRaw(): MediaPlayer {
        mMediaPlayer?.let { return it }
        return MediaPlayer().also { mMediaPlayer = it }
    }

    private fun updatePlaybackParamsInternal() {
        val eq = EqualizerManager.getInstance(this)
        val speedLevel = eq.getSpeed()
        val tempo = 0.5f + (speedLevel / 2000.0f)
        val pitchLevel = eq.getPitch()
        val semitones = (pitchLevel - 1000) / (1000.0f / 6.0f)
        val finalTempo = tempo
        val finalSemitones = semitones
        onPlayer {
            val player = mMediaPlayer ?: return@onPlayer
            try {
                val pitch = Math.pow(2.0, finalSemitones / 12.0).toFloat()
                val params = player.playbackParams
                params.speed = finalTempo
                params.pitch = pitch
                player.playbackParams = params
                Log.d(TAG, "PlaybackParams: tempo=$finalTempo, pitch=$pitch")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set playback params", e)
            }
        }
    }

    // ========================================================================
    // Persistence
    // ========================================================================

    private fun loadRepeatAndShuffle() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0)
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false)
    }

    private fun loadSortMode() {
        mCurrentSortMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getInt(KEY_SORT_MODE, SORT_TITLE_AZ)
    }

    private fun saveSortModeInternal() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply()
    }

    private fun loadPlaybackScope() {
        val serialized = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_PLAYBACK_SCOPE, null)
        mPlaybackScope = PlaybackScope.deserialize(serialized)
    }

    private fun savePlaybackScope() {
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(KEY_PLAYBACK_SCOPE, mPlaybackScope.serialize())
                .apply()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to persist playback scope", e)
        }
    }

    private fun saveCurrentPlayingIndex() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, pathOf(mCurrentIndex))
            .apply()
    }

    private fun savePlayingState() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putBoolean(KEY_LAST_PLAYING, isPlaying)
            .putInt(KEY_CURRENT_POSITION, estimateCurrentPosition())
            .apply()
    }

    private fun saveFullState() = savePlayerState()

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val TAG = "MusicService"

        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_CURRENT_INDEX = "current_playing_index"
        private const val KEY_LAST_PLAYING = "last_playing"
        private const val KEY_CURRENT_POSITION = "current_position"
        private const val KEY_REPEAT_MODE = "repeat_mode"
        private const val KEY_SHUFFLE = "shuffle"
        private const val KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update"
        private const val KEY_LAST_SONG_PATH = "last_song_path"
        private const val KEY_SORT_MODE = "playlist_sort_mode"
        private const val KEY_PLAYBACK_SCOPE = "playback_scope_json"

        private const val ACTION_BLUETOOTH_RESUME = "ACTION_BLUETOOTH_RESUME"
        private const val ACTION_PLAY_SONG = "PLAY_SONG"
        private const val ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE"
        private const val ACTION_NEXT = "ACTION_NEXT"
        private const val ACTION_PREV = "ACTION_PREV"
        private const val ACTION_STOP = "ACTION_STOP"

        private const val EXTRA_PROFILE_ACTION = "profile_action"
        private const val EXTRA_PROFILE_STATE = "profile_state"

        private const val VOLUME_CHANGED_ACTION = "android.media.VOLUME_CHANGED_ACTION"
        private const val EXTRA_VOLUME_STREAM_TYPE = "android.media.EXTRA_VOLUME_STREAM_TYPE"
        private const val EXTRA_VOLUME_STREAM_TYPE_ALIAS = "android.media.EXTRA_VOLUME_STREAM_TYPE_ALIAS"
        private const val EXTRA_VOLUME_STREAM_VALUE = "android.media.EXTRA_VOLUME_STREAM_VALUE"

        private const val NOTIFICATION_ACTION_DEBOUNCE_MS = 500L
        private const val HEALTH_CHECK_INTERVAL_MS = 500L
        private const val MAX_STALL_TIME_MS = 1500L
        private const val MAX_RECOVERY_ATTEMPTS = 3
        private const val SKIP_LOOP_BUDGET_MS = 2500L
        private const val DUCK_VOLUME_FRACTION = 0.2f
        private const val NOTIFICATION_ART_MAX_PX = 300
        private const val NOTIFICATION_ART_CACHE_MB = 25
        private const val POSITION_SAVE_INTERVAL_TICKS = 10
        private const val RESUME_RETRY_ATTEMPTS = 12
        private const val RESUME_RETRY_INTERVAL_MS = 500L
        private const val BLUETOOTH_DISCONNECT_CONFIRM_MS = 400L

        private const val SORT_TITLE_AZ = 0
        private const val SORT_TITLE_ZA = 1
        private const val SORT_ARTIST_AZ = 2
        private const val SORT_ARTIST_ZA = 3
        private const val SORT_ALBUM_AZ = 4
        private const val SORT_ALBUM_ZA = 5
        private const val SORT_GENRE_AZ = 6
        private const val SORT_GENRE_ZA = 7
        private const val SORT_OLDEST = 8
        private const val SORT_NEWEST = 9

        @Volatile
        private var sCurrentAudioSessionId: Int = 0

        fun getAudioSessionId(): Int = sCurrentAudioSessionId

        @JvmStatic
        fun setPlayerStateBeforeUpdate(context: Context, need: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply()
        }

        @JvmStatic
        fun getPlayerStateBeforeUpdate(context: Context): Boolean =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)

        @JvmStatic
        fun clearPlayerStateBeforeUpdate(context: Context) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply()
        }
    }
}