// MetadataReader.kt
package com.ark.llama

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Arrays
import java.util.HashSet
import java.util.Set

/**
 * Reads ID3 tags and other metadata from audio files.
 *
 * <p>Supports MP3, FLAC, OGG, M4A, and MP4 formats. Reads can be
 * performed against a filesystem path or against a document URI
 * from the Storage Access Framework. Every write operation is
 * handled by [MetadataWriter].</p>
 *
 * <h3>Result Contract</h3>
 * <p>A read produces a [MetadataBundle] whose string fields are all
 * non-null, using the empty string as the "not present" value, and
 * whose [MetadataBundle.status] field distinguishes the three
 * outcomes the reader can produce.</p>
 *
 * <h3>URI reads</h3>
 * <p>A URI read copies the document to a temporary cache file,
 * reads the cache file through the path-based reader, and deletes
 * the cache file. This is the only way to give jaudiotagger a real
 * filesystem path while still resolving through the Storage Access
 * Framework.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every method is static and uses only local variables. Callers
 * that run reads concurrently are responsible for the thread safety
 * of any shared dependency the reads touch.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
object MetadataReader {

    private const val TAG = "MetadataReader"
    private const val COPY_BUFFER_SIZE = 8192
    private const val DEFAULT_EXTENSION = "mp3"

    private val WRITABLE_EXTENSIONS: Set<String> = HashSet(
        Arrays.asList("mp3", "flac", "ogg", "m4a", "mp4")
    )

    // ========================================================================
    // MetadataBundle
    // ========================================================================

    class MetadataBundle {

        /** Exhaustive outcomes of a metadata read. */
        enum class Status {
            /** jaudiotagger extracted whatever tags it found. */
            SUCCESS,
            /** The file does not exist or cannot be read. */
            FILE_UNREADABLE,
            /** The file exists but jaudiotagger failed to read it. */
            PARSE_FAILED
        }

        @JvmField var status: Status = Status.SUCCESS
        @JvmField var title: String = ""
        @JvmField var artist: String = ""
        @JvmField var album: String = ""
        @JvmField var year: String = ""
        @JvmField var genre: String = ""
        @JvmField var trackNumber: String = ""
        @JvmField var lyrics: String = ""
        @JvmField var albumArt: ByteArray? = null
        @JvmField var format: String = "Unknown"
        @JvmField var isWriteSupported: Boolean = false
        @JvmField var fileSize: Long = 0L
        @JvmField var duration: Long = 0L

        fun hasMetadata(): Boolean =
            title.isNotEmpty() || artist.isNotEmpty() ||
                album.isNotEmpty() || year.isNotEmpty() ||
                genre.isNotEmpty() || trackNumber.isNotEmpty() ||
                lyrics.isNotEmpty() || hasAlbumArt()

        fun hasAlbumArt(): Boolean =
            albumArt != null && albumArt!!.isNotEmpty()

        override fun toString(): String =
            "MetadataBundle{status=$status, title='$title', " +
                "artist='$artist', album='$album', year='$year', " +
                "genre='$genre', trackNumber='$trackNumber', " +
                "format='$format', isWriteSupported=$isWriteSupported, " +
                "fileSize=$fileSize, duration=$duration, " +
                "hasAlbumArt=${hasAlbumArt()}}"
    }

    // ========================================================================
    // Public read methods
    // ========================================================================

    @JvmStatic
    fun readMetadata(filePath: String): MetadataBundle {
        val bundle = MetadataBundle()

        if (filePath.isEmpty()) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE
            return bundle
        }

        val file = File(filePath)
        if (!file.exists() || !file.canRead()) {
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE
            Log.w(TAG, "File does not exist or cannot be read: $filePath")
            return bundle
        }

        bundle.fileSize = file.length()
        bundle.format = getFileExtension(filePath).uppercase()
        bundle.isWriteSupported = isWriteSupportedFormat(bundle.format)

        var audioFile: org.jaudiotagger.audio.AudioFile? = null
        var retriever: MediaMetadataRetriever? = null

        try {
            audioFile = AudioFileIO.read(file)
            if (audioFile != null) {
                val tag: Tag? = audioFile.tag
                if (tag != null) {
                    bundle.title = cleanString(tag.getFirst(FieldKey.TITLE))
                    bundle.artist = cleanString(tag.getFirst(FieldKey.ARTIST))
                    bundle.album = cleanString(tag.getFirst(FieldKey.ALBUM))
                    bundle.year = cleanString(tag.getFirst(FieldKey.YEAR))
                    bundle.genre = cleanString(tag.getFirst(FieldKey.GENRE))
                    bundle.trackNumber = cleanString(tag.getFirst(FieldKey.TRACK))
                    bundle.lyrics = cleanString(tag.getFirst(FieldKey.LYRICS))

                    try {
                        val artwork = tag.firstArtwork
                        if (artwork != null && artwork.binaryData != null) {
                            bundle.albumArt = artwork.binaryData
                            Log.d(TAG, "Read album art: ${bundle.albumArt!!.size} bytes")
                        }
                    } catch (exception: Exception) {
                        Log.w(TAG, "Failed to read album art: ${exception.message}")
                    }
                }
            } else {
                bundle.status = MetadataBundle.Status.PARSE_FAILED
            }

            try {
                retriever = MediaMetadataRetriever()
                retriever.setDataSource(filePath)
                val durationString = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )
                if (durationString != null) {
                    bundle.duration = durationString.toLong()
                    Log.d(TAG, "Duration from MediaMetadataRetriever: " +
                        "${bundle.duration} ms")
                } else if (audioFile?.audioHeader != null) {
                    bundle.duration = audioFile.audioHeader.trackLength * 1000L
                    Log.d(TAG, "Duration from jaudiotagger (fallback): " +
                        "${bundle.duration} ms")
                }
            } catch (exception: Exception) {
                Log.w(TAG, "MediaMetadataRetriever failed, using jaudiotagger fallback",
                    exception)
                if (audioFile?.audioHeader != null) {
                    bundle.duration = audioFile.audioHeader.trackLength * 1000L
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "Failed to read metadata from: $filePath", exception)
            bundle.status = MetadataBundle.Status.PARSE_FAILED
        } finally {
            retriever?.let {
                try {
                    it.release()
                } catch (ignored: Exception) {
                    // The retriever is not in a state that permits release.
                }
            }
        }

        return bundle
    }

    @JvmStatic
    fun readMetadataFromUri(context: Context, documentUri: Uri): MetadataBundle {
        val sourceExtension = determineSourceExtension(context, documentUri)
        val cacheFile = copyUriToCache(context, documentUri, sourceExtension)
        if (cacheFile == null) {
            val bundle = MetadataBundle()
            bundle.status = MetadataBundle.Status.FILE_UNREADABLE
            Log.w(TAG, "Failed to copy URI to cache: $documentUri")
            return bundle
        }
        val bundle = readMetadata(cacheFile.absolutePath)
        deleteFileSafely(cacheFile)
        return bundle
    }

    @JvmStatic
    fun isWriteSupported(filePath: String): Boolean =
        isWriteSupportedFormat(getFileExtension(filePath))

    // ========================================================================
    // Private helpers
    // ========================================================================

    private fun determineSourceExtension(context: Context, documentUri: Uri): String {
        try {
            val doc = DocumentFile.fromSingleUri(context, documentUri)
            val docName = doc?.name
            if (docName != null) {
                val ext = getFileExtension(docName)
                if (ext.isNotEmpty()) return ext
            }
        } catch (ignored: Exception) {
            // Fall through to the next strategy.
        }

        val lastSegment = documentUri.lastPathSegment
        if (lastSegment != null) {
            val ext = getFileExtension(lastSegment)
            if (ext.isNotEmpty()) return ext
        }

        return DEFAULT_EXTENSION
    }

    private fun isWriteSupportedFormat(extension: String): Boolean =
        WRITABLE_EXTENSIONS.contains(extension.lowercase())

    private fun cleanString(input: String?): String {
        if (input.isNullOrEmpty()) return ""
        val trimmed = input.trim()
        return if (trimmed.isEmpty()) "" else trimmed
    }

    private fun getFileExtension(filePath: String): String {
        val dotIndex = filePath.lastIndexOf(".")
        if (dotIndex > 0 && dotIndex < filePath.length - 1) {
            return filePath.substring(dotIndex + 1)
        }
        return ""
    }

    private fun copyUriToCache(
        context: Context,
        uri: Uri,
        extension: String
    ): File? {
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        try {
            inputStream = context.contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "openInputStream returned null for URI: $uri")
                return null
            }
            val outFile = File(
                context.cacheDir,
                "temp_audio_${SystemClock.elapsedRealtime()}.$extension"
            )
            outputStream = FileOutputStream(outFile)
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            var length: Int
            var totalBytes = 0L
            while (inputStream.read(buffer).also { length = it } != -1) {
                outputStream.write(buffer, 0, length)
                totalBytes += length
            }
            outputStream.flush()
            Log.d(TAG, "Copied $totalBytes bytes from URI to cache: ${outFile.name}")
            return outFile
        } catch (exception: IOException) {
            Log.e(TAG, "copyUriToCache failed: ${exception.message}")
            return null
        } finally {
            closeSafely(inputStream)
            closeSafely(outputStream)
        }
    }

    private fun deleteFileSafely(file: File?) {
        if (file != null && file.exists()) {
            try {
                val deleted = file.delete()
                Log.d(TAG, "Deleted ${file.name}: $deleted")
            } catch (exception: SecurityException) {
                Log.w(TAG, "delete failed for ${file.name}: ${exception.message}")
            }
        }
    }

    private fun closeSafely(closeable: Closeable?) {
        if (closeable != null) {
            try {
                closeable.close()
            } catch (exception: IOException) {
                // The closeable is already closed.
            }
        }
    }
}