// SongDatabase.kt
package com.ark.llama

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.annotation.WorkerThread
import java.io.File
import java.util.ArrayList
import java.util.HashSet
import java.util.Set

/**
 * Caches song metadata in a local SQLite database.
 *
 * <p>Reading metadata from audio files is expensive. This class
 * persists the parsed values — title, artist, album, genre,
 * duration, and document URI — so later reads can return from the
 * database rather than re-parsing every file.</p>
 *
 * <h3>Tables</h3>
 * <p>The database holds two tables with an identical schema. The
 * [Table.SONGS] table caches metadata for songs in imported
 * folders. The [Table.LOOSE_SONGS] table caches metadata for songs
 * opened as loose tracks. Every operation is written once against
 * the [Table] enum and exposed to callers through a thin public
 * wrapper.</p>
 *
 * <h3>Favorites</h3>
 * <p>The favorite column is written only by the fresh-row branch
 * of the insert path and by [setFavorite]. Every other write path —
 * [updateSongMetadata], the batch upsert's update branch — uses
 * [buildMetadataContentValues], which does not carry the column.
 * This is what makes the favorite flag immune to a metadata edit,
 * a genre load, and the scan's reconciliation pass.</p>
 *
 * <h3>Column Resolution</h3>
 * <p>[Cursor.getColumnIndex] walks the cursor's column-name array
 * on every call. Every read path resolves the column indexes once
 * per query through [RowReader].</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Every database accessor is annotated [WorkerThread] and is
 * intended to be called from a background thread.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class SongDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    init {
        setWriteAheadLoggingEnabled(true)
    }

    // ========================================================================
    // Schema
    // ========================================================================

    override fun onConfigure(database: SQLiteDatabase) {
        super.onConfigure(database)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            database.setForeignKeyConstraintsEnabled(true)
        }
    }

    override fun onCreate(database: SQLiteDatabase) {
        for (table in Table.values()) {
            createTable(database, table)
        }
        Log.d(TAG, "Database created successfully with version $DATABASE_VERSION")
    }

    private fun createTable(database: SQLiteDatabase, table: Table) {
        database.execSQL(
            "CREATE TABLE ${table.tableName} (" +
                "$COL_PATH TEXT PRIMARY KEY, " +
                "$COL_TITLE TEXT, " +
                "$COL_ARTIST TEXT, " +
                "$COL_ALBUM TEXT, " +
                "$COL_GENRE TEXT, " +
                "$COL_DURATION INTEGER, " +
                "$COL_MODIFIED INTEGER, " +
                "$COL_FILE_SIZE INTEGER, " +
                "$COL_URI TEXT, " +
                "$COL_FAVORITE INTEGER DEFAULT 0)"
        )
        table.pathIndex?.let {
            database.execSQL("CREATE INDEX $it ON ${table.tableName}($COL_PATH)")
        }
        table.titleIndex?.let {
            database.execSQL("CREATE INDEX $it ON ${table.tableName}($COL_TITLE)")
        }
        table.modifiedIndex?.let {
            database.execSQL("CREATE INDEX $it ON ${table.tableName}($COL_MODIFIED)")
        }
    }

    override fun onUpgrade(
        database: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        Log.d(TAG, "Upgrading database from version $oldVersion to $newVersion")

        if (oldVersion < 2) {
            try {
                database.execSQL(
                    "ALTER TABLE ${Table.LOOSE_SONGS.tableName} " +
                        "ADD COLUMN $COL_FILE_SIZE INTEGER DEFAULT 0"
                )
                database.execSQL(
                    "ALTER TABLE ${Table.LOOSE_SONGS.tableName} " +
                        "ADD COLUMN $COL_URI TEXT"
                )
                Log.d(TAG, "Successfully upgraded loose_songs table to version 2")
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to upgrade loose_songs table", exception)
            }
        }

        if (oldVersion < 3) {
            try {
                database.execSQL(
                    "ALTER TABLE ${Table.SONGS.tableName} " +
                        "ADD COLUMN $COL_FAVORITE INTEGER DEFAULT 0"
                )
                database.execSQL(
                    "ALTER TABLE ${Table.LOOSE_SONGS.tableName} " +
                        "ADD COLUMN $COL_FAVORITE INTEGER DEFAULT 0"
                )
                Log.d(TAG, "Successfully upgraded favorite column to version 3")
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to add favorite column", exception)
            }
        }

        Log.d(TAG, "Database upgrade completed")
    }

    // ========================================================================
    // Table-Parameterized Implementation
    // ========================================================================

    @WorkerThread
    private fun hasSongInternal(table: Table, path: String): Boolean {
        if (path.isEmpty()) return false
        var cursor: Cursor? = null
        return try {
            cursor = readableDatabase.query(
                table.tableName,
                arrayOf(COL_PATH),
                "$COL_PATH=?",
                arrayOf(path),
                null, null, null
            )
            cursor != null && cursor.moveToFirst()
        } catch (exception: Exception) {
            Log.e(TAG, "hasSong error", exception)
            false
        } finally {
            closeCursorSafely(cursor)
        }
    }

    @WorkerThread
    private fun getSongInternal(table: Table, path: String): Song? {
        if (path.isEmpty()) return null
        var cursor: Cursor? = null
        try {
            cursor = readableDatabase.query(
                table.tableName,
                null,
                "$COL_PATH=?",
                arrayOf(path),
                null, null, null
            )
            if (cursor != null && cursor.moveToFirst()) {
                val reader = RowReader(cursor)
                return reader.read(cursor, path)
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getSong error", exception)
        } finally {
            closeCursorSafely(cursor)
        }
        return null
    }

    @WorkerThread
    private fun insertSongInternal(table: Table, song: Song?) {
        if (song == null || song.path.isEmpty()) return
        try {
            val database = writableDatabase
            val rowId = database.insertWithOnConflict(
                table.tableName,
                null,
                buildContentValues(song),
                SQLiteDatabase.CONFLICT_IGNORE
            )
            if (rowId == -1L) {
                updateSongMetadataInternalOn(database, table, song)
            }
        } catch (exception: Exception) {
            Log.e(TAG, "insertSong error", exception)
        }
    }

    @WorkerThread
    private fun insertSongsBatchInternal(table: Table, songs: ArrayList<Song>?) {
        if (songs == null || songs.isEmpty()) return
        var database: SQLiteDatabase? = null
        try {
            database = writableDatabase
            database.beginTransaction()
            for (song in songs) {
                if (song == null || song.path.isEmpty()) continue
                val rowId = database.insertWithOnConflict(
                    table.tableName,
                    null,
                    buildContentValues(song),
                    SQLiteDatabase.CONFLICT_IGNORE
                )
                if (rowId == -1L) {
                    updateSongMetadataInternalOn(database, table, song)
                }
            }
            database.setTransactionSuccessful()
            Log.d(TAG, "Batch upserted ${songs.size} songs into ${table.tableName}")
        } catch (exception: Exception) {
            Log.e(TAG, "Batch insert error", exception)
        } finally {
            if (database != null) {
                try {
                    database.endTransaction()
                } catch (ignored: Exception) {
                    // The transaction has already ended.
                }
            }
        }
    }

    @WorkerThread
    private fun getAllSongsInternal(table: Table): ArrayList<Song> {
        val songs = ArrayList<Song>()
        var cursor: Cursor? = null
        try {
            cursor = readableDatabase.query(
                table.tableName,
                null, null, null, null, null,
                "$COL_TITLE COLLATE NOCASE ASC"
            )
            if (cursor != null && cursor.moveToFirst()) {
                val pathColumn = cursor.getColumnIndex(COL_PATH)
                if (pathColumn < 0) return songs
                val reader = RowReader(cursor)
                do {
                    val path = cursor.getString(pathColumn)
                    if (path != null) {
                        val song = reader.read(cursor, path)
                        if (song != null) {
                            songs.add(song)
                        }
                    }
                } while (cursor.moveToNext())
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getAllSongs error", exception)
        } finally {
            closeCursorSafely(cursor)
        }
        return songs
    }

    @WorkerThread
    private fun getSongsCountInternal(table: Table): Int {
        var cursor: Cursor? = null
        try {
            cursor = readableDatabase.rawQuery(
                "SELECT COUNT(*) FROM ${table.tableName}", null
            )
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0)
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getSongsCount error", exception)
        } finally {
            closeCursorSafely(cursor)
        }
        return 0
    }

    @WorkerThread
    private fun removeSongInternal(table: Table, path: String) {
        if (path.isEmpty()) return
        try {
            val deleted = writableDatabase.delete(
                table.tableName,
                "$COL_PATH=?",
                arrayOf(path)
            )
            if (deleted > 0) {
                Log.d(TAG, "Removed song from ${table.tableName}: $path")
            }
        } catch (exception: Exception) {
            Log.e(TAG, "removeSong error", exception)
        }
    }

    @WorkerThread
    private fun clearTableInternal(table: Table) {
        try {
            val deleted = writableDatabase.delete(table.tableName, null, null)
            Log.d(TAG, "Cleared ${table.tableName}, deleted $deleted songs")
        } catch (exception: Exception) {
            Log.e(TAG, "clearTable error", exception)
        }
    }

    @WorkerThread
    private fun isFileModifiedInternal(
        table: Table,
        path: String,
        currentModified: Long
    ): Boolean {
        var cursor: Cursor? = null
        try {
            cursor = readableDatabase.query(
                table.tableName,
                arrayOf(COL_MODIFIED),
                "$COL_PATH=?",
                arrayOf(path),
                null, null, null
            )
            if (cursor != null && cursor.moveToFirst()) {
                val cachedModified = cursor.getLong(0)
                return cachedModified != currentModified
            }
        } catch (exception: Exception) {
            Log.e(TAG, "isFileModified error", exception)
        } finally {
            closeCursorSafely(cursor)
        }
        return true
    }

    // ========================================================================
    // Row Reader
    // ========================================================================

    private class RowReader(cursor: Cursor) {

        private val titleColumn: Int = cursor.getColumnIndex(COL_TITLE)
        private val artistColumn: Int = cursor.getColumnIndex(COL_ARTIST)
        private val albumColumn: Int = cursor.getColumnIndex(COL_ALBUM)
        private val genreColumn: Int = cursor.getColumnIndex(COL_GENRE)
        private val durationColumn: Int = cursor.getColumnIndex(COL_DURATION)
        private val uriColumn: Int = cursor.getColumnIndex(COL_URI)
        private val favoriteColumn: Int = cursor.getColumnIndex(COL_FAVORITE)

        fun read(cursor: Cursor, path: String): Song? {
            if (titleColumn < 0 || artistColumn < 0 ||
                albumColumn < 0 || durationColumn < 0
            ) {
                return null
            }
            val title: String? = cursor.getString(titleColumn)
            val artist: String? = cursor.getString(artistColumn)
            val album: String? = cursor.getString(albumColumn)
            val genre: String? =
                if (genreColumn >= 0) cursor.getString(genreColumn) else null
            val duration: Long = cursor.getLong(durationColumn)
            val uri: String? =
                if (uriColumn >= 0) cursor.getString(uriColumn) else null
            val song = Song(title, artist, album, genre, path, duration, uri)
            if (favoriteColumn >= 0) {
                song.setFavorite(cursor.getInt(favoriteColumn) != 0)
            }
            return song
        }
    }

    // ========================================================================
    // Shared Row Helpers
    // ========================================================================

    private fun buildContentValues(song: Song): ContentValues {
        val values = buildMetadataContentValues(song)
        values.put(COL_FAVORITE, if (song.isFavorite) 1 else 0)
        return values
    }

    private fun buildMetadataContentValues(song: Song): ContentValues {
        val values = ContentValues()
        values.put(COL_PATH, song.path)
        values.put(COL_TITLE, song.title)
        values.put(COL_ARTIST, song.artist)
        values.put(COL_ALBUM, song.album)
        values.put(COL_GENRE, song.genre)
        values.put(COL_DURATION, song.duration)
        values.put(COL_MODIFIED, SystemClock.elapsedRealtime())
        values.put(COL_FILE_SIZE, safeGetFileSize(song.path))
        song.uri?.let { values.put(COL_URI, it) }
        return values
    }

    @WorkerThread
    private fun safeGetFileSize(path: String): Long {
        return try {
            val file = File(path)
            if (file.exists() && file.canRead()) file.length() else 0L
        } catch (exception: SecurityException) {
            Log.w(TAG, "No permission for file size: $path")
            0L
        }
    }

    private fun closeCursorSafely(cursor: Cursor?) {
        if (cursor != null) {
            try {
                cursor.close()
            } catch (exception: Exception) {
                Log.w(TAG, "Failed to close cursor", exception)
            }
        }
    }

    // ========================================================================
    // Public API — Main Songs Table
    // ========================================================================

    @WorkerThread
    fun hasSong(path: String): Boolean = hasSongInternal(Table.SONGS, path)

    @WorkerThread
    fun getExistingPaths(paths: Set<String>?): Set<String> {
        val existing = HashSet<String>()
        if (paths == null || paths.isEmpty()) return existing

        val pathArray = paths.toTypedArray()
        val placeholders = StringBuilder()
        for (index in pathArray.indices) {
            if (index > 0) placeholders.append(",")
            placeholders.append("?")
        }

        val query = "SELECT $COL_PATH FROM ${Table.SONGS.tableName}" +
            " WHERE $COL_PATH IN ($placeholders)"
        var cursor: Cursor? = null
        try {
            cursor = readableDatabase.rawQuery(query, pathArray)
            if (cursor != null) {
                val columnIndex = cursor.getColumnIndex(COL_PATH)
                if (columnIndex >= 0) {
                    while (cursor.moveToNext()) {
                        val path = cursor.getString(columnIndex)
                        if (path != null) {
                            existing.add(path)
                        }
                    }
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getExistingPaths error", exception)
        } finally {
            closeCursorSafely(cursor)
        }
        return existing
    }

    @WorkerThread
    fun getSong(path: String): Song? = getSongInternal(Table.SONGS, path)

    @WorkerThread
    fun insertSong(song: Song?) = insertSongInternal(Table.SONGS, song)

    @WorkerThread
    fun insertSongsBatch(songs: ArrayList<Song>?) =
        insertSongsBatchInternal(Table.SONGS, songs)

    @JvmOverloads
    @WorkerThread
    fun deleteSongsNotInSet(
        validPaths: Set<String>?,
        preserveLooseTracks: Boolean = true
    ): Int {
        val keepPaths = HashSet<String>()
        if (validPaths != null) {
            keepPaths.addAll(validPaths)
        }

        if (preserveLooseTracks) {
            val looseSongs = looseSongs
            for (looseSong in looseSongs) {
                if (looseSong != null && looseSong.path.isNotEmpty()) {
                    keepPaths.add(looseSong.path)
                }
            }
        }

        if (keepPaths.isEmpty()) {
            Log.w(TAG, "deleteSongsNotInSet called with empty keepPaths and " +
                "preserveLooseTracks=false - skipping deletion to prevent " +
                "accidental data loss")
            return 0
        }

        val keepArray = keepPaths.toTypedArray()
        val placeholders = StringBuilder()
        for (index in keepArray.indices) {
            if (index > 0) placeholders.append(",")
            placeholders.append("?")
        }

        return try {
            val deleted = writableDatabase.delete(
                Table.SONGS.tableName,
                "$COL_PATH NOT IN ($placeholders)",
                keepArray
            )
            Log.d(TAG, "Deleted $deleted songs, kept ${keepPaths.size} " +
                "(preserveLooseTracks=$preserveLooseTracks)")
            deleted
        } catch (exception: Exception) {
            Log.e(TAG, "deleteSongsNotInSet error", exception)
            0
        }
    }

    @WorkerThread
    fun clearCache() = clearTableInternal(Table.SONGS)

    @WorkerThread
    fun removeSong(path: String) = removeSongInternal(Table.SONGS, path)

    @WorkerThread
    fun updateSongMetadata(song: Song?) {
        if (song == null || song.path.isEmpty()) return
        updateSongMetadataInternal(Table.SONGS, song)
    }

    @WorkerThread
    private fun updateSongMetadataInternal(table: Table, song: Song) {
        try {
            updateSongMetadataInternalOn(writableDatabase, table, song)
        } catch (exception: Exception) {
            Log.e(TAG, "updateSongMetadata error", exception)
        }
    }

    @WorkerThread
    private fun updateSongMetadataInternalOn(
        database: SQLiteDatabase,
        table: Table,
        song: Song
    ) {
        try {
            database.update(
                table.tableName,
                buildMetadataContentValues(song),
                "$COL_PATH=?",
                arrayOf(song.path)
            )
        } catch (exception: Exception) {
            Log.e(TAG, "updateSongMetadataOn error", exception)
        }
    }

    @WorkerThread
    fun setFavorite(path: String, favorite: Boolean) {
        if (path.isEmpty()) return
        val values = ContentValues()
        values.put(COL_FAVORITE, if (favorite) 1 else 0)
        try {
            val database = writableDatabase
            database.update(
                Table.SONGS.tableName, values,
                "$COL_PATH=?", arrayOf(path)
            )
            database.update(
                Table.LOOSE_SONGS.tableName, values,
                "$COL_PATH=?", arrayOf(path)
            )
        } catch (exception: Exception) {
            Log.e(TAG, "setFavorite error", exception)
        }
    }

    @WorkerThread
    fun getAllSongs(): ArrayList<Song> = getAllSongsInternal(Table.SONGS)

    @WorkerThread
    fun getSongsCount(): Int = getSongsCountInternal(Table.SONGS)

    @WorkerThread
    fun isFileModified(path: String, currentModified: Long): Boolean =
        isFileModifiedInternal(Table.SONGS, path, currentModified)

    // ========================================================================
    // Public API — Loose Songs Table
    // ========================================================================

    @WorkerThread
    fun insertLooseSong(song: Song?) = insertSongInternal(Table.LOOSE_SONGS, song)

    @WorkerThread
    fun getLooseSongs(): ArrayList<Song> =
        getAllSongsInternal(Table.LOOSE_SONGS)

    @WorkerThread
    fun clearLooseSongs() = clearTableInternal(Table.LOOSE_SONGS)

    @WorkerThread
    fun removeLooseSong(path: String) =
        removeSongInternal(Table.LOOSE_SONGS, path)

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {

        private const val TAG = "SongDatabase"

        private const val DATABASE_NAME = "songs_cache.db"
        private const val DATABASE_VERSION = 3

        private const val COL_PATH = "path"
        private const val COL_TITLE = "title"
        private const val COL_ARTIST = "artist"
        private const val COL_ALBUM = "album"
        private const val COL_GENRE = "genre"
        private const val COL_DURATION = "duration"
        private const val COL_MODIFIED = "modified"
        private const val COL_FILE_SIZE = "file_size"
        private const val COL_URI = "uri"
        private const val COL_FAVORITE = "favorite"

        /**
         * The two tables this class manages. Both share an
         * identical schema.
         */
        private enum class Table(
            val tableName: String,
            val pathIndex: String?,
            val titleIndex: String?,
            val modifiedIndex: String?
        ) {
            SONGS("songs", "idx_path", "idx_title", "idx_modified"),
            LOOSE_SONGS("loose_songs", "idx_loose_path", null, null)
        }

        @Volatile
        private var sInstance: SongDatabase? = null

        @JvmStatic
        fun getInstance(context: Context): SongDatabase {
            if (sInstance == null) {
                synchronized(SongDatabase::class.java) {
                    if (sInstance == null) {
                        sInstance = SongDatabase(context.applicationContext)
                    }
                }
            }
            return sInstance!!
        }
    }
}