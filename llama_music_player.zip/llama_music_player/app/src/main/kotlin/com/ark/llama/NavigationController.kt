// NavigationController.kt
package com.ark.llama

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.util.EnumSet
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Tracks active operations and disables the button groups each
 * operation affects.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class NavigationController private constructor() {

    // ========================================================================
    // Enums
    // ========================================================================

    enum class ButtonGroup {
        DATABASE_ACTIONS,
        FOLDER_ACTIONS,
        METADATA_ACTIONS
    }

    enum class Operation(
        @JvmField val affectedGroups: EnumSet<ButtonGroup>,
        @JvmField val heartbeatIntervalMs: Long,
        @JvmField val missedHeartbeatTolerance: Int
    ) {
        PLAYLIST_SYNC(
            EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS),
            500L, 3
        ),
        METADATA_SAVE(
            EnumSet.of(ButtonGroup.METADATA_ACTIONS),
            500L, 3
        ),
        FOLDER_UPDATE(
            EnumSet.of(ButtonGroup.FOLDER_ACTIONS),
            500L, 3
        );

        fun getAffectedGroups(): EnumSet<ButtonGroup> = affectedGroups
        fun getHeartbeatIntervalMs(): Long = heartbeatIntervalMs
        fun getMissedHeartbeatTolerance(): Int = missedHeartbeatTolerance
        fun getLivenessWindowMs(): Long = heartbeatIntervalMs * missedHeartbeatTolerance
    }

    /**
     * Internal state-machine phases.
     *
     * <p>Public rather than internal because [StateListener] is a
     * public interface and exposes [State] in its method signature.
     * A public interface cannot expose an internal type.</p>
     */
    enum class State {
        IDLE, SYNCING, COMPLETED, ERROR, RECOVERING, RECOVERED, RESETTING
    }

    // ========================================================================
    // Listener interfaces
    // ========================================================================

    interface ButtonStateListener {
        fun onButtonStateChanged(group: ButtonGroup, disabled: Boolean)
    }

    interface StateListener : ButtonStateListener {
        fun onStateChanged(oldState: State, newState: State)
        fun onStuckDetected(operation: Operation, stuckDurationMs: Long)
    }

    interface ProgressListener {
        fun onProgress(operation: Operation, current: Int, total: Int)
    }

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mHealthHandler = Handler(Looper.getMainLooper())

    private val mState = AtomicReference(State.IDLE)
    private val mCurrentOperation = AtomicReference<Operation?>(null)
    private val mStateStartTime = AtomicLong(0L)
    private val mLastActivityTime = AtomicLong(0L)
    private val mIsRecovering = AtomicBoolean(false)

    private var mHealthCheckRunnable: Runnable? = null
    private var mRecoveryRunnable: Runnable? = null
    private val mHealthLock = Any()

    private val mGroupOperationCounts = ConcurrentHashMap<ButtonGroup, AtomicInteger>()
    private val mGroupDisabledState = ConcurrentHashMap<ButtonGroup, Boolean>()

    private val mOperationProgress = ConcurrentHashMap<Operation, IntArray>()

    private val mButtonListeners = CopyOnWriteArrayList<ButtonStateListener>()
    private val mStateListeners = CopyOnWriteArrayList<StateListener>()
    private val mProgressListeners = CopyOnWriteArrayList<ProgressListener>()

    init {
        for (group in ButtonGroup.values()) {
            mGroupDisabledState[group] = false
            mGroupOperationCounts[group] = AtomicInteger(0)
        }
        startContinuousHealthCheck()
        Log.d(TAG, "NavigationController initialized with declared-liveness enforcement")
    }

    // ========================================================================
    // Health check
    // ========================================================================

    private fun startContinuousHealthCheck() {
        if (mHealthCheckRunnable != null) return
        val runnable = object : Runnable {
            override fun run() {
                performHealthCheck()
                if (mHealthCheckRunnable != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS)
                }
            }
        }
        mHealthCheckRunnable = runnable
        mHealthHandler.post(runnable)
        Log.d(TAG, "Continuous health check started (interval: ${HEALTH_CHECK_INTERVAL_MS}ms)")
    }

    private fun stopContinuousHealthCheck() {
        mHealthCheckRunnable?.let {
            mHealthHandler.removeCallbacks(it)
            mHealthCheckRunnable = null
        }
        Log.d(TAG, "Continuous health check stopped")
    }

    private fun performHealthCheck() {
        synchronized(mHealthLock) {
            if (mState.get() == State.SYNCING) {
                val operation = mCurrentOperation.get()
                if (operation != null) {
                    val inactiveTime = SystemClock.elapsedRealtime() - mLastActivityTime.get()
                    val window = operation.getLivenessWindowMs()

                    if (inactiveTime > window) {
                        Log.w(TAG, "STUCK DETECTED: $operation inactive for ${inactiveTime}ms " +
                            "(declared window: ${window}ms, interval: ${operation.getHeartbeatIntervalMs()}ms, " +
                            "tolerance: ${operation.getMissedHeartbeatTolerance()})")

                        for (listener in mStateListeners) {
                            try {
                                listener.onStuckDetected(operation, inactiveTime)
                            } catch (exception: Exception) {
                                Log.e(TAG, "Error notifying stuck listener", exception)
                            }
                        }
                        startAutoRecovery()
                    }
                }
            }

            for (group in ButtonGroup.values()) {
                val isDisabled = isGroupDisabled(group)
                val count = getGroupOperationCount(group)
                if (isDisabled && count == 0 && mState.get() != State.SYNCING) {
                    Log.w(TAG, "Orphaned disabled state detected for ${group.name} - recovering")
                    setGroupDisabled(group, false)
                }
            }
        }
    }

    // ========================================================================
    // Recovery
    // ========================================================================

    private fun startAutoRecovery() {
        if (mIsRecovering.getAndSet(true)) return
        Log.d(TAG, "Starting auto-recovery")
        transitionTo(State.RECOVERING)
        cancelRecovery()

        val runnable = object : Runnable {
            override fun run() {
                if (mState.get() == State.RECOVERING) {
                    Log.d(TAG, "Auto-recovery completed")
                    transitionTo(State.RECOVERED)
                    mIsRecovering.set(false)
                    mCurrentOperation.set(null)
                    mOperationProgress.clear()
                    resetAllGroupCounts()
                    enableAllButtons()
                    mMainHandler.postDelayed({
                        if (mState.get() == State.RECOVERED) transitionTo(State.IDLE)
                    }, 100)
                }
            }
        }
        mRecoveryRunnable = runnable
        mMainHandler.postDelayed(runnable, RECOVERY_DELAY_MS)
    }

    private fun cancelRecovery() {
        mRecoveryRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mRecoveryRunnable = null
        }
        mIsRecovering.set(false)
    }

    // ========================================================================
    // State transitions
    // ========================================================================

    private fun transitionTo(newState: State) {
        val oldState = mState.getAndSet(newState)
        if (oldState == newState) return
        Log.d(TAG, "State transition: $oldState -> $newState")
        mStateStartTime.set(SystemClock.elapsedRealtime())
        for (listener in mStateListeners) {
            try {
                listener.onStateChanged(oldState, newState)
            } catch (exception: Exception) {
                Log.e(TAG, "Error notifying state listener", exception)
            }
        }
    }

    private fun enableAllButtons() {
        for (group in ButtonGroup.values()) setGroupDisabled(group, false)
    }

    private fun resetAllGroupCounts() {
        for (group in ButtonGroup.values()) {
            mGroupOperationCounts[group] = AtomicInteger(0)
        }
    }

    fun forceReset() {
        Log.w(TAG, "forceReset - Manual reset triggered")
        cancelRecovery()
        mCurrentOperation.set(null)
        mIsRecovering.set(false)
        mOperationProgress.clear()
        transitionTo(State.RESETTING)
        enableAllButtons()
        resetAllGroupCounts()
        mMainHandler.postDelayed({
            if (mState.get() == State.RESETTING) transitionTo(State.IDLE)
        }, 100)
    }

    // ========================================================================
    // Public API — Operation management
    // ========================================================================

    fun beginOperation(operation: Operation) {
        val currentState = mState.get()
        if (currentState == State.SYNCING) {
            Log.w(TAG, "Already syncing, cannot begin $operation")
            return
        }
        if (currentState == State.ERROR || currentState == State.RECOVERING) {
            Log.w(TAG, "In $currentState, forcing reset before beginning")
            forceReset()
            if (mState.get() != State.IDLE) {
                Log.w(TAG, "State not IDLE after reset, aborting")
                return
            }
        }

        Log.d(TAG, "beginOperation: $operation from $currentState " +
            "(declared liveness: heartbeat every ${operation.getHeartbeatIntervalMs()}ms, " +
            "tolerance ${operation.getMissedHeartbeatTolerance()}, " +
            "window ${operation.getLivenessWindowMs()}ms)")

        mCurrentOperation.set(operation)
        mStateStartTime.set(SystemClock.elapsedRealtime())
        mLastActivityTime.set(SystemClock.elapsedRealtime())
        mOperationProgress.remove(operation)

        transitionTo(State.SYNCING)

        for (group in operation.affectedGroups) {
            incrementGroupCount(group)
            setGroupDisabled(group, true)
        }
    }

    fun endOperation(operation: Operation) {
        val currentState = mState.get()
        if (currentState != State.SYNCING) {
            Log.w(TAG, "endOperation called but not in SYNCING state: $currentState")
            if (currentState == State.IDLE) enableAllButtons()
            return
        }
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "endOperation called for wrong operation: " +
                "expected ${mCurrentOperation.get()} but got $operation")
            return
        }

        Log.d(TAG, "endOperation: $operation")
        transitionTo(State.COMPLETED)
        mOperationProgress.remove(operation)

        for (group in operation.affectedGroups) {
            decrementGroupCount(group)
            if (getGroupOperationCount(group) <= 0) {
                setGroupDisabled(group, false)
            }
        }

        mMainHandler.postDelayed({
            if (mState.get() == State.COMPLETED) {
                transitionTo(State.IDLE)
                mCurrentOperation.set(null)
            }
        }, 100)
    }

    fun heartbeat(operation: Operation): Boolean {
        if (mState.get() != State.SYNCING) {
            Log.w(TAG, "Heartbeat called but not in SYNCING state")
            return false
        }
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Heartbeat called for wrong operation")
            return false
        }
        mLastActivityTime.set(SystemClock.elapsedRealtime())
        Log.v(TAG, "Heartbeat received for ${operation.name}")
        return true
    }

    fun recordProgress(operation: Operation, current: Int, total: Int) {
        if (mState.get() != State.SYNCING) {
            Log.w(TAG, "Progress reported but not in SYNCING state")
            return
        }
        if (mCurrentOperation.get() != operation) {
            Log.w(TAG, "Progress reported for wrong operation")
            return
        }
        mLastActivityTime.set(SystemClock.elapsedRealtime())
        mOperationProgress[operation] = intArrayOf(current, total)
        for (listener in mProgressListeners) {
            try {
                listener.onProgress(operation, current, total)
            } catch (exception: Exception) {
                Log.e(TAG, "Error notifying progress listener", exception)
            }
        }
    }

    fun isOperationActive(operation: Operation): Boolean =
        mState.get() == State.SYNCING && mCurrentOperation.get() == operation

    fun isOperationStuck(operation: Operation): Boolean {
        if (mState.get() != State.SYNCING || mCurrentOperation.get() != operation) return false
        return getInactiveTimeMs() > operation.getLivenessWindowMs()
    }

    fun getInactiveTimeMs(operation: Operation): Long {
        if (mState.get() != State.SYNCING || mCurrentOperation.get() != operation) return -1L
        return SystemClock.elapsedRealtime() - mLastActivityTime.get()
    }

    fun getOperationProgress(operation: Operation): IntArray? {
        if (mState.get() != State.SYNCING || mCurrentOperation.get() != operation) return null
        val progress = mOperationProgress[operation] ?: return null
        return progress.clone()
    }

    fun isGroupDisabled(group: ButtonGroup): Boolean =
        mGroupDisabledState[group] ?: false

    fun getGroupOperationCount(group: ButtonGroup): Int =
        mGroupOperationCounts[group]?.get() ?: 0

    fun forceEndAllOperations() = forceReset()

    // ========================================================================
    // Private state management
    // ========================================================================

    private fun incrementGroupCount(group: ButtonGroup): Int {
        val counter = mGroupOperationCounts.getOrPut(group) { AtomicInteger(0) }
        return counter.incrementAndGet()
    }

    private fun decrementGroupCount(group: ButtonGroup): Int {
        val counter = mGroupOperationCounts[group]
        if (counter == null) {
            Log.w(TAG, "No counter found for group: ${group.name}")
            return -1
        }
        return counter.decrementAndGet()
    }

    private fun setGroupDisabled(group: ButtonGroup, disabled: Boolean) {
        val current = mGroupDisabledState[group]
        if (current == disabled) return
        mGroupDisabledState[group] = disabled
        Log.d(TAG, "Group ${group.name} ${if (disabled) "DISABLED" else "ENABLED"}")

        for (listener in mStateListeners) {
            try {
                listener.onButtonStateChanged(group, disabled)
            } catch (exception: Exception) {
                Log.e(TAG, "Error notifying state listener", exception)
            }
        }
        for (listener in mButtonListeners) {
            try {
                listener.onButtonStateChanged(group, disabled)
            } catch (exception: Exception) {
                Log.e(TAG, "Error notifying button listener", exception)
            }
        }
    }

    // ========================================================================
    // Listener management
    // ========================================================================

    fun registerListener(listener: ButtonStateListener) {
        if (!mButtonListeners.contains(listener)) {
            mButtonListeners.add(listener)
            for (group in ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group))
            }
        }
    }

    fun unregisterListener(listener: ButtonStateListener) {
        mButtonListeners.remove(listener)
    }

    fun registerStateListener(listener: StateListener) {
        if (!mStateListeners.contains(listener)) {
            mStateListeners.add(listener)
            listener.onStateChanged(State.IDLE, mState.get())
            for (group in ButtonGroup.values()) {
                listener.onButtonStateChanged(group, isGroupDisabled(group))
            }
        }
    }

    fun unregisterStateListener(listener: StateListener) {
        mStateListeners.remove(listener)
    }

    fun addProgressListener(listener: ProgressListener) {
        if (!mProgressListeners.contains(listener)) {
            mProgressListeners.add(listener)
        }
    }

    fun removeProgressListener(listener: ProgressListener) {
        mProgressListeners.remove(listener)
    }

    // ========================================================================
    // Convenience
    // ========================================================================

    fun beginPlaylistSync() = beginOperation(Operation.PLAYLIST_SYNC)

    fun endPlaylistSync() {
        val current = mCurrentOperation.get()
        if (current == Operation.PLAYLIST_SYNC) {
            endOperation(current)
        } else {
            Log.w(TAG, "endPlaylistSync called but current operation is $current")
            forceReset()
        }
    }

    fun beginMetadataSave() = beginOperation(Operation.METADATA_SAVE)

    fun endMetadataSave() {
        val current = mCurrentOperation.get()
        if (current == Operation.METADATA_SAVE) {
            endOperation(current)
        } else {
            Log.w(TAG, "endMetadataSave called but current operation is $current")
            forceReset()
        }
    }

    fun beginFolderUpdate() = beginOperation(Operation.FOLDER_UPDATE)

    fun endFolderUpdate() {
        val current = mCurrentOperation.get()
        if (current == Operation.FOLDER_UPDATE) {
            endOperation(current)
        } else {
            Log.w(TAG, "endFolderUpdate called but current operation is $current")
            forceReset()
        }
    }

    fun progressPlaylistSync(current: Int, total: Int) {
        val currentOperation = mCurrentOperation.get()
        if (currentOperation == Operation.PLAYLIST_SYNC) {
            recordProgress(currentOperation, current, total)
        }
    }

    // ========================================================================
    // Debug
    // ========================================================================

    fun getDebugInfo(): String {
        val builder = StringBuilder()
        builder.append("NavigationController Debug Info:\n")
        builder.append("  State: ${mState.get()}\n")
        builder.append("  Operation: ${mCurrentOperation.get()}\n")
        builder.append("  State duration: ${getStateDurationMs()}ms\n")
        builder.append("  Inactive time: ${getInactiveTimeMs()}ms\n")
        builder.append("  Is recovering: ${mIsRecovering.get()}\n")

        val currentOperation = mCurrentOperation.get()
        if (currentOperation != null) {
            builder.append("  Declared heartbeat interval: ${currentOperation.getHeartbeatIntervalMs()}ms\n")
            builder.append("  Declared tolerance: ${currentOperation.getMissedHeartbeatTolerance()}\n")
            builder.append("  Declared liveness window: ${currentOperation.getLivenessWindowMs()}ms\n")
            getOperationProgress(currentOperation)?.let {
                builder.append("  Progress: ${it[0]}/${it[1]}\n")
            }
        }

        builder.append("  Group states:\n")
        for (group in ButtonGroup.values()) {
            builder.append("    - ${group.name}: count=${getGroupOperationCount(group)}, " +
                "disabled=${isGroupDisabled(group)}\n")
        }
        builder.append("  State listeners: ${mStateListeners.size}\n")
        builder.append("  Button listeners: ${mButtonListeners.size}\n")
        builder.append("  Progress listeners: ${mProgressListeners.size}\n")
        return builder.toString()
    }

    private fun getStateDurationMs(): Long =
        SystemClock.elapsedRealtime() - mStateStartTime.get()

    private fun getInactiveTimeMs(): Long {
        if (mState.get() != State.SYNCING) return -1L
        return SystemClock.elapsedRealtime() - mLastActivityTime.get()
    }

    fun shutdown() {
        Log.d(TAG, "Shutting down NavigationController")
        stopContinuousHealthCheck()
        cancelRecovery()
        forceReset()
        sInstance = null
    }

    companion object {
        private const val TAG = "NavigationController"
        private const val HEALTH_CHECK_INTERVAL_MS = 500L
        private const val RECOVERY_DELAY_MS = 1000L

        @Volatile
        private var sInstance: NavigationController? = null

        @JvmStatic
        fun getInstance(): NavigationController {
            if (sInstance == null) {
                synchronized(NavigationController::class.java) {
                    if (sInstance == null) {
                        sInstance = NavigationController()
                    }
                }
            }
            return sInstance!!
        }
    }
}