// CreditsDialog.kt
package com.ark.llama

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.SettingsEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * Displays the application's credits, version, developer
 * information, third-party libraries, licenses, and language
 * selection controls.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class CreditsDialog(context: Context) :
    Dialog(context, android.R.style.Theme_Black_NoTitleBar) {

    // ========================================================================
    // Constants
    // ========================================================================

    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val TEXT_CLICK_DEBOUNCE_DELAY_MS = 250L
    private val TAP_TIMEOUT_MS = 5000L
    private val REQUIRED_TAPS = 5
    private val EASTER_EGG_MESSAGE_RES = R.string.credits_easter_egg_message
    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f
    private val FADE_DURATION_MS = 250

    private val BACKGROUND_COLOR = "#121212"
    private val HEADER_BACKGROUND_COLOR = "#1A1A1A"
    private val TEXT_COLOR_LIGHT = "#C0C0C0"
    private val TEXT_COLOR_MUTED = "#808080"

    private val TOP_BAR_HEIGHT_DP = 64
    private val HEADER_BAR_HEIGHT_DP = 40
    private val BUTTON_HEIGHT_DP = 36
    private val LANGUAGE_BUTTON_HEIGHT_DP = 28
    private val LANGUAGE_BUTTON_PADDING_HORIZONTAL_DP = 12
    private val ICON_SIZE_DP = 64
    private val DIALOG_CORNER_RADIUS_DP = 20
    private val LICENSE_CORNER_RADIUS_DP = 10
    private val DIVIDER_THICKNESS_DP = 1
    private val PADDING_STANDARD_DP = 16
    private val SPACING_BASE_DP = 4
    private val HEADER_PADDING_VERTICAL_DP = 4
    private val HEADER_PADDING_HORIZONTAL_DP = 16
    private val BUTTON_PADDING_HORIZONTAL_DP = 8
    private val BUTTON_PADDING_VERTICAL_DP = 4
    private val BOTTOM_PADDING_DP = 4

    // ========================================================================
    // License texts
    // ========================================================================

    private val LLAMA_MIT_LICENSE = "Llama Music Player\n\n" +
        "Copyright (C) 2026 Richard Korbla Adzido\n\n" +
        "Licensed under the MIT License\n\n" +
        "Permission is hereby granted, free of charge, to any person obtaining a copy " +
        "of this software and associated documentation files (the \"Software\"), to deal " +
        "in the Software without restriction, including without limitation the rights " +
        "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell " +
        "copies of the Software, and to permit persons to whom the Software is " +
        "furnished to do so, subject to the following conditions:\n\n" +
        "The above copyright notice and this permission notice shall be included in all " +
        "copies or substantial portions of the Software.\n\n" +
        "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR " +
        "IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, " +
        "FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE " +
        "AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER " +
        "LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, " +
        "OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE " +
        "SOFTWARE."

    private val JAUDIOTAGGER_LICENSE = "jaudiotagger\n\n" +
        "Copyright (C) 2003-2018 jthink Ltd\n\n" +
        "Licensed under the GNU Lesser General Public License v2.1\n" +
        "or Mozilla Public License v1.1\n\n" +
        "This library is free software; you can redistribute it and/or " +
        "modify it under the terms of the GNU Lesser General Public " +
        "License as published by the Free Software Foundation; either " +
        "version 2.1 of the License, or (at your option) any later version.\n\n" +
        "Alternatively, this library may be distributed under the terms of " +
        "the Mozilla Public License Version 1.1.\n\n" +
        "jaudiotagger is used for reading and writing ID3 tags,\n" +
        "album art, and metadata in Llama Music Player."

    private val FONTAWESOME_LICENSE = "FontAwesome\n\n" +
        "Copyright (C) 2025 Fonticons, Inc.\n\n" +
        "This Font Software is licensed under the SIL Open Font License, Version 1.1.\n\n" +
        "This license is available with a FAQ at:\n http://scripts.sil.org/OFL\n\n" +
        "Permission is hereby granted, free of charge, to any person obtaining a copy " +
        "of the Font Software, to use, study, copy, merge, embed, modify, redistribute, " +
        "and sell modified and unmodified copies of the Font Software, subject to the " +
        "following conditions:\n\n" +
        "1. Neither the Font Software nor any of its individual components may be sold by itself.\n\n" +
        "2. The original copyright notice must be retained.\n\n" +
        "3. Modified versions must be clearly marked as such.\n\n" +
        "FontAwesome is used for folder icons, playback controls, and album art " +
        "placeholders in Llama Music Player."

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context
    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper
    private lateinit var mLanguageManager: LanguageManager

    private var mScrollView: ScrollView? = null
    private var mLanguageButton: Button? = null
    private var mLastThemeClickTime = 0L
    private var mLastCancelClickTime = 0L
    private var mLastLanguageClickTime = 0L
    private var mIsThemeDialogShowing = false
    private var mIsLanguageDialogShowing = false
    private var mDynamicLicenseText: TextView? = null
    private var mCurrentLicenseText: String = LLAMA_MIT_LICENSE
    private val mMainHandler = Handler(Looper.getMainLooper())

    init {
        mThemeManager = ThemeManager.getInstance(context)
        mThemeHelper = ThemeHelper.getInstance(context)
        mLanguageManager = LanguageManager.getInstance(context)
    }

    // ========================================================================
    // Localization
    // ========================================================================

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (e: Exception) {
        Log.w(TAG, "Failed to obtain localized context", e); mContext
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(createContentView())
        configureWindow()
        LlamaEventBus.register(this)
        applyThemeToButtons()
    }

    override fun dismiss() {
        super.dismiss()
        LlamaEventBus.unregister(this)
        mMainHandler.removeCallbacksAndMessages(null)
    }

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        mMainHandler.post { if (isShowing) dismiss() }
    }

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        mMainHandler.post { if (isShowing) dismiss() }
    }

    // ========================================================================
    // Window
    // ========================================================================

    private fun configureWindow() {
        val window = window ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = Color.parseColor(BACKGROUND_COLOR)
            window.navigationBarColor = Color.parseColor(BACKGROUND_COLOR)
        }
        val params = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.MATCH_PARENT
        params.gravity = Gravity.TOP
        window.attributes = params
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.setWindowAnimations(R.style.CreditsDialogAnimation)
    }

    // ========================================================================
    // Theme
    // ========================================================================

    private fun applyThemeToButtons() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        val rootView = findViewById<View>(android.R.id.content)
        if (rootView is ViewGroup) findAndThemeButtons(rootView)
        forceRedraw()
    }

    private fun findAndThemeButtons(group: ViewGroup) {
        for (index in 0 until group.childCount) {
            val child = group.getChildAt(index)
            if (child is Button) mThemeHelper.updateButton(child, true)
            else if (child is ViewGroup) findAndThemeButtons(child)
        }
    }

    // ========================================================================
    // Dialog openers
    // ========================================================================

    private fun showThemeDialog() {
        val colorNames = mThemeManager.getColorNames()
        val colorValues = mThemeManager.getColorValues()
        val openedAtIndex = mThemeManager.getCurrentColorIndex()

        val dialog = ThemeDialog(mContext, colorNames, colorValues, openedAtIndex,
            object : ThemeDialog.OnThemeSelectedListener {
                override fun onThemeSelected(colorIndex: Int, colorName: String,
                                             colorValue: String) {
                    if (colorIndex == openedAtIndex) return
                    mThemeManager.setThemeColor(colorIndex)
                }
            })
        dialog.setOnDismissListener(DialogInterface.OnDismissListener {
            mIsThemeDialogShowing = false
        })
        dialog.show()
    }

    private fun showLanguageDialog() {
        val languageNames = mLanguageManager.getLanguageNames()
        val languageTags = mLanguageManager.getLanguageTags()
        val openedAtIndex = mLanguageManager.getCurrentLanguageIndex()

        val dialog = LanguageDialog(mContext, languageNames, languageTags, openedAtIndex,
            object : LanguageDialog.OnLanguageSelectedListener {
                override fun onLanguageSelected(languageIndex: Int, languageName: String,
                                                languageTag: String) {
                    if (languageIndex == openedAtIndex) return
                    mLanguageManager.setLanguage(languageTag)
                }
            })
        dialog.setOnDismissListener(DialogInterface.OnDismissListener {
            mIsLanguageDialogShowing = false
        })
        dialog.show()
    }

    // ========================================================================
    // Content construction
    // ========================================================================

    private fun createContentView(): View {
        val container = createMainContainer()
        container.addView(createTopBar())
        container.addView(createVersionHeader())
        container.addView(createScrollableContent())
        container.addView(createBottomPadding())
        return container
    }

    private fun createMainContainer(): LinearLayout {
        val container = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(BACKGROUND_COLOR))
            cornerRadii = floatArrayOf(
                dpToPx(DIALOG_CORNER_RADIUS_DP).toFloat(),
                dpToPx(DIALOG_CORNER_RADIUS_DP).toFloat(),
                0f, 0f, 0f, 0f, 0f, 0f
            )
        }
        container.background = bg
        return container
    }

    private fun createTopBar(): LinearLayout {
        val topBar = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP))
            setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
                dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP))
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        topBar.addView(createCancelButton())
        topBar.addView(createTitleText())
        topBar.addView(createThemeButton())
        return topBar
    }

    private fun createCancelButton(): Button {
        val button = Button(mContext).apply {
            text = getLocaleContext().getString(R.string.action_cancel)
            textSize = 14f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            setPadding(dpToPx(BUTTON_PADDING_HORIZONTAL_DP), dpToPx(BUTTON_PADDING_VERTICAL_DP),
                dpToPx(BUTTON_PADDING_HORIZONTAL_DP), dpToPx(BUTTON_PADDING_VERTICAL_DP))
            minHeight = 0; minWidth = 0; includeFontPadding = false
            isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        }
        button.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelClickTime = now; dismiss()
            }
        }
        animateButton(button)
        return button
    }

    private fun createTitleText(): TextView {
        val tv = TextView(mContext).apply {
            text = getLocaleContext().getString(R.string.credits_title)
            textSize = 14f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            gravity = Gravity.CENTER
            includeFontPadding = false; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                0, dpToPx(BUTTON_HEIGHT_DP), 1f).apply {
                marginStart = dpToPx(8); marginEnd = dpToPx(8)
            }
        }
        return tv
    }

    private fun createThemeButton(): Button {
        val button = Button(mContext).apply {
            text = getLocaleContext().getString(R.string.action_themes)
            textSize = 14f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            setPadding(dpToPx(BUTTON_PADDING_HORIZONTAL_DP), dpToPx(BUTTON_PADDING_VERTICAL_DP),
                dpToPx(BUTTON_PADDING_HORIZONTAL_DP), dpToPx(BUTTON_PADDING_VERTICAL_DP))
            minHeight = 0; minWidth = 0; includeFontPadding = false
            isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        }
        button.setOnClickListener {
            if (mIsThemeDialogShowing) return@setOnClickListener
            val now = SystemClock.elapsedRealtime()
            if (now - mLastThemeClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastThemeClickTime = now; mIsThemeDialogShowing = true
                showThemeDialog()
            }
        }
        animateButton(button)
        return button
    }

    private fun createVersionHeader(): LinearLayout {
        val localeContext = getLocaleContext()
        val headerBar = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP))
            setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP),
                dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP))
            setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR))
        }

        val headerTitle = TextView(mContext).apply {
            text = localeContext.getString(R.string.credits_version_label)
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        mLanguageButton = createLanguageButton()

        val headerVersion = TextView(mContext).apply {
            text = getAppVersion()
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        headerBar.addView(headerTitle)
        mLanguageButton?.let { headerBar.addView(it) }
        headerBar.addView(headerVersion)
        return headerBar
    }

    private fun createLanguageButton(): Button {
        val button = Button(mContext).apply {
            text = mLanguageManager.getCurrentLanguageName()
            textSize = 12f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            setPadding(dpToPx(LANGUAGE_BUTTON_PADDING_HORIZONTAL_DP), 0,
                dpToPx(LANGUAGE_BUTTON_PADDING_HORIZONTAL_DP), 0)
            minHeight = 0; minWidth = 0; includeFontPadding = false
            isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(LANGUAGE_BUTTON_HEIGHT_DP))
        }
        button.setOnClickListener {
            if (mIsLanguageDialogShowing) return@setOnClickListener
            val now = SystemClock.elapsedRealtime()
            if (now - mLastLanguageClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastLanguageClickTime = now; mIsLanguageDialogShowing = true
                showLanguageDialog()
            }
        }
        animateButton(button)
        return button
    }

    private fun getAppVersion(): String = try {
        val info = mContext.packageManager
            .getPackageInfo(mContext.packageName, 0)
        info.versionName ?: "1.5.0"
    } catch (e: Exception) { "1.5.0" }

    private fun createScrollableContent(): ScrollView {
        val scroll = ScrollView(mContext).apply {
            isVerticalScrollBarEnabled = false
            id = R.id.creditsScrollView
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }
        mScrollView = scroll

        val container = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dpToPx(SPACING_BASE_DP * 2), 0, dpToPx(SPACING_BASE_DP * 2))
            gravity = Gravity.CENTER
        }

        container.addView(createAppIcon())
        container.addView(createAppNameText())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createDivider())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createDeveloperSection())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createDivider())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createLibrariesSection())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createDivider())
        container.addView(createSpacer(dpToPx(SPACING_BASE_DP)))
        container.addView(createLicenseViewerSection())

        scroll.addView(container)
        return scroll
    }

    private fun createSpacer(heightPx: Int): View =
        View(mContext).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, heightPx)
        }

    private fun createAppIcon(): ImageView {
        val iv = ImageView(mContext)
        try {
            val bmp = BitmapFactory.decodeResource(mContext.resources, R.mipmap.ic_launcher)
            if (bmp != null) iv.setImageBitmap(bmp) else iv.setImageResource(R.drawable.ic_notification)
        } catch (e: Exception) { iv.setImageResource(R.drawable.ic_notification) }
        iv.layoutParams = LinearLayout.LayoutParams(
            dpToPx(ICON_SIZE_DP), dpToPx(ICON_SIZE_DP)).apply { gravity = Gravity.CENTER }
        iv.isClickable = true; iv.isFocusable = true
        iv.setOnClickListener(object : View.OnClickListener {
            private var mTapCount = 0
            private var mLastTapTime = 0L
            override fun onClick(view: View) {
                view.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong())
                    .withEndAction {
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                    }.start()
                val now = SystemClock.elapsedRealtime()
                if (now - mLastTapTime > TAP_TIMEOUT_MS) mTapCount = 0
                mLastTapTime = now; mTapCount++
                if (mTapCount >= REQUIRED_TAPS) { mTapCount = 0; showSecretMessage() }
            }
        })
        return iv
    }

    private fun showSecretMessage() {
        try {
            val window = window ?: return
            val root = window.decorView.findViewById<ViewGroup>(android.R.id.content) ?: return
            ToastManager.showToastInView(
                root,
                getLocaleContext().getString(EASTER_EGG_MESSAGE_RES),
                ToastManager.LENGTH_LONG
            )
        } catch (e: Exception) { Log.w(TAG, "Failed to show secret message", e) }
    }

    private fun createAppNameText(): TextView {
        val tv = TextView(mContext).apply {
            text = getLocaleContext().getString(R.string.credits_app_display_name)
            textSize = 16f
            setTextColor(mThemeManager.getCurrentColorInt())
            gravity = Gravity.CENTER
            isClickable = true; isFocusable = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        tv.setOnClickListener(object : View.OnClickListener {
            private var mLastClick = 0L
            override fun onClick(view: View) {
                val now = SystemClock.elapsedRealtime()
                if (now - mLastClick < TEXT_CLICK_DEBOUNCE_DELAY_MS) return
                mLastClick = now
                view.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong())
                    .withEndAction {
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                    }.start()
                updateLicenseViewer(LLAMA_MIT_LICENSE)
            }
        })
        return tv
    }

    private fun createDivider(): View = View(mContext).apply {
        setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(DIVIDER_THICKNESS_DP))
    }

    private fun createDeveloperSection(): LinearLayout {
        val localeContext = getLocaleContext()
        val section = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        section.addView(createSectionTitle(localeContext.getString(R.string.credits_section_developer)))
        section.addView(createDeveloperText(localeContext.getString(R.string.credits_developer_name)))
        section.addView(createDeveloperText(localeContext.getString(R.string.credits_developer_email)))
        return section
    }

    private fun createDeveloperText(text: String): TextView = TextView(mContext).apply {
        this.text = text; textSize = 14f
        setTextColor(Color.parseColor(TEXT_COLOR_MUTED))
        gravity = Gravity.CENTER
        setPadding(0, dpToPx(SPACING_BASE_DP / 2), 0, dpToPx(SPACING_BASE_DP / 2))
    }

    private fun createLibrariesSection(): LinearLayout {
        val section = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        section.addView(createSectionTitle(getLocaleContext().getString(R.string.credits_section_libraries)))
        section.addView(createClickableLibraryText("jaudiotagger", JAUDIOTAGGER_LICENSE))
        section.addView(createClickableLibraryText("FontAwesome", FONTAWESOME_LICENSE))
        return section
    }

    private fun createClickableLibraryText(text: String, license: String): TextView {
        val tv = TextView(mContext).apply {
            this.text = text; textSize = 14f
            setTextColor(mThemeManager.getCurrentColorInt())
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(SPACING_BASE_DP / 2), 0, dpToPx(SPACING_BASE_DP / 2))
            isClickable = true; isFocusable = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        tv.setOnClickListener(object : View.OnClickListener {
            private var mLastClick = 0L
            override fun onClick(view: View) {
                val now = SystemClock.elapsedRealtime()
                if (now - mLastClick < TEXT_CLICK_DEBOUNCE_DELAY_MS) return
                mLastClick = now
                view.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong())
                    .withEndAction {
                        view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                            .scaleY(ANIMATION_SCALE_NORMAL)
                            .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                    }.start()
                updateLicenseViewer(license)
            }
        })
        return tv
    }

    private fun createLicenseViewerSection(): LinearLayout {
        val section = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        section.addView(createSectionTitle(getLocaleContext().getString(R.string.credits_section_license)))
        section.addView(createSpacer(dpToPx(SPACING_BASE_DP)))

        val outer = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(PADDING_STANDARD_DP), 0, dpToPx(PADDING_STANDARD_DP), 0)
        }
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(HEADER_BACKGROUND_COLOR))
            cornerRadius = dpToPx(LICENSE_CORNER_RADIUS_DP).toFloat()
        }
        val inner = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
                dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        mDynamicLicenseText = TextView(mContext).apply {
            text = LLAMA_MIT_LICENSE; textSize = 12f
            setTextColor(Color.parseColor(TEXT_COLOR_MUTED))
            gravity = Gravity.CENTER
            setLineSpacing(4f, 1.2f)
        }
        mDynamicLicenseText?.let { inner.addView(it) }
        outer.addView(inner)
        section.addView(outer)
        return section
    }

    private fun updateLicenseViewer(newLicense: String) {
        val textView = mDynamicLicenseText ?: return
        if (newLicense == mCurrentLicenseText) return
        mCurrentLicenseText = newLicense
        textView.animate().alpha(0f).setDuration(FADE_DURATION_MS.toLong())
            .withEndAction {
                textView.text = newLicense
                textView.animate().alpha(1f).setDuration(FADE_DURATION_MS.toLong()).start()
            }.start()
    }

    private fun createSectionTitle(title: String): TextView = TextView(mContext).apply {
        text = title; textSize = 14f
        setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, dpToPx(SPACING_BASE_DP))
    }

    private fun createBottomPadding(): View = View(mContext).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(BOTTOM_PADDING_DP))
    }

    private fun animateButton(button: Button?) {
        button ?: return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
            }
            false
        }
    }

    private fun forceRedraw() {
        val window = window ?: return
        val root = window.decorView.findViewById<View>(android.R.id.content) ?: return
        root.requestLayout(); root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun dpToPx(dp: Int): Int = Math.round(
        dp * mContext.resources.displayMetrics.density)

    companion object {
        private const val TAG = "CreditsDialog"
    }
}