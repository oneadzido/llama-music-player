// AlbumArtCarousel.kt
package com.ark.llama

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.ArrayList
import java.util.Collections
import java.util.Set
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService

/**
 * The three-slot album-art carousel.
 *
 * <p>A horizontal strip three slot-widths wide sits inside a
 * viewport one slot wide. The strip's middle slot is aligned to the
 * viewport at rest; the outer slots are clipped by the container.
 * When the user drags horizontally on the album art, the strip
 * follows the finger, revealing the previous or next song's art. On
 * release the strip either settles back to the middle slot or
 * animates to a neighbour slot and then asks [MusicService] to
 * request the corresponding song change.</p>
 *
 * <p>Every other transition — a transport button, a headset key,
 * an automatic advance, a stall recovery, a metadata
 * re-publication — is driven from one signal: the [PlaybackWindow]
 * the service publishes on its [com.ark.llama.event.PlayerEvent.Snapshot]
 * event, together with the transition direction and the restart
 * flag the service names alongside it.</p>
 *
 * <h3>Authority</h3>
 * <p>The window the carousel displays is a value published by
 * [MusicService]. The carousel computes neither the window nor its
 * neighbours nor the direction of the transition that produced it;
 * it renders the three paths the service names and consults the
 * shared [LruCache] for each path's art, and it runs the one
 * animation the service's direction and restart flag describe.</p>
 *
 * <h3>Slots</h3>
 * <p>Three slots, always drawn: Previous (path named by service),
 * Current (path named by service), Next (path named by service).</p>
 *
 * <h3>Transitions</h3>
 * <ul>
 *   <li><b>Commit.</b> Direction is non-zero, restart flag is
 *       false, current path differs. The strip slides a full slot
 *       width toward the named neighbour.</li>
 *   <li><b>Restart.</b> Restart flag is true. The strip slides a
 *       fraction of the middle zone toward the neighbour the
 *       direction names, then returns to rest.</li>
 *   <li><b>Reveal.</b> Direction is zero and current path differs.
 *       A staggered cross-fade begins once the incoming art has
 *       resolved.</li>
 * </ul>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.2.0
 */
class AlbumArtCarousel(
    private val mContext: Context,
    private val mContainer: FrameLayout,
    private val mCache: LruCache<String, Bitmap>,
    private val mExecutor: ExecutorService
) {

    // ========================================================================
    // Constants and configuration
    // ========================================================================

    private val mHandler = Handler(Looper.getMainLooper())

    private val EMPHASIZED_DECELERATE = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    private val EMPHASIZED_ACCELERATE = PathInterpolator(0.3f, 0f, 0.8f, 0.15f)

    private enum class SwipeState {
        IDLE, DRAGGING, COMMITTING, AWAITING_SNAPSHOT,
        RESTARTING, REVEAL_PENDING, REVEALING
    }

    interface SwipeCommitListener {
        fun onSwipeCommitted(direction: Int)
    }

    // ========================================================================
    // View state
    // ========================================================================

    private var mStrip: LinearLayout? = null
    private var mPreviousView: ImageView? = null
    private var mCurrentView: ImageView? = null
    private var mNextView: ImageView? = null
    private var mFadeOverlayView: ImageView? = null
    private var mFadeOverlayPath: String? = null
    private var mSlotWidth: Int = 0
    private var mSlotHeight: Int = 0
    private var mEdgeZonePx: Int = 0

    private var mWindow: PlaybackWindow = PlaybackWindow.EMPTY
    private var mLastWindowGeneration: Long = -1L
    private var mPlaceholderBitmap: Bitmap? = null
    private val mInflightDecodePaths: MutableSet<String> =
        Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val mDecodedPaths: MutableSet<String> =
        Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    private var mSwipeState: SwipeState = SwipeState.IDLE
    private var mSwipeDirection: Int = 0
    private var mExpectedCurrentPath: String? = null
    private var mConfirmedWindow: PlaybackWindow? = null
    private var mPendingRevealPath: String? = null
    private var mSwipeCommitListener: SwipeCommitListener? = null
    private var mSnapshotTimeoutRunnable: Runnable? = null
    private var mPendingRevealTimeoutRunnable: Runnable? = null
    private var mReturningToRest: Boolean = false
    private var mRestSpring: SpringAnimation? = null
    private val mPostSettleActions = ArrayList<Runnable>()

    // ========================================================================
    // Configuration
    // ========================================================================

    fun setEdgeZonePx(edgeZonePx: Int) {
        mEdgeZonePx = Math.max(0, edgeZonePx)
    }

    fun setSwipeCommitListener(listener: SwipeCommitListener?) {
        mSwipeCommitListener = listener
    }

    // ========================================================================
    // Attach and layout
    // ========================================================================

    fun attach() {
        if (mStrip != null) return

        val strip = LinearLayout(mContext)
        strip.orientation = LinearLayout.HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        strip.isClickable = false
        strip.isFocusable = false
        strip.visibility = View.INVISIBLE
        strip.layoutDirection = View.LAYOUT_DIRECTION_LTR

        val previousView = createSlot()
        val currentView = createSlot()
        val nextView = createSlot()

        strip.addView(previousView)
        strip.addView(currentView)
        strip.addView(nextView)

        mContainer.addView(strip)
        mContainer.clipChildren = true

        mStrip = strip
        mPreviousView = previousView
        mCurrentView = currentView
        mNextView = nextView

        mContainer.post {
            if (mStrip == null) return@post
            layoutSlots()
            mStrip?.visibility = View.VISIBLE
            render()
        }
    }

    private fun createSlot(): ImageView {
        val view = ImageView(mContext)
        view.scaleType = ImageView.ScaleType.FIT_CENTER
        view.isClickable = false
        view.isFocusable = false
        view.layoutDirection = View.LAYOUT_DIRECTION_LTR
        view.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        return view
    }

    fun onContainerResized() {
        if (mStrip == null) return
        mContainer.post {
            if (mStrip == null) return@post
            cancelSwipe()
            layoutSlots()
            render()
        }
    }

    private fun layoutSlots() {
        val strip = mStrip ?: return
        val current = mCurrentView ?: return
        val previous = mPreviousView ?: return
        val next = mNextView ?: return

        val width = mContainer.width
        val height = mContainer.height
        if (width <= 0 || height <= 0) return

        mSlotWidth = width
        mSlotHeight = height

        for (slotView in arrayOf(previous, current, next)) {
            var lp = slotView.layoutParams as? LinearLayout.LayoutParams
            if (lp == null) {
                lp = LinearLayout.LayoutParams(width, height)
            } else {
                lp.width = width
                lp.height = height
            }
            slotView.layoutParams = lp
        }

        val stripLp = strip.layoutParams
        val frameParams = if (stripLp is FrameLayout.LayoutParams) {
            stripLp
        } else {
            FrameLayout.LayoutParams(width * 3, height)
        }
        frameParams.width = width * 3
        frameParams.height = height
        frameParams.gravity = Gravity.LEFT or Gravity.TOP
        strip.layoutParams = frameParams

        snapToRest()
    }

    private fun snapToRest() {
        mStrip?.let { strip ->
            strip.animate().cancel()
            mRestSpring?.cancel()
            strip.translationX = -mSlotWidth.toFloat()
        }
        mReturningToRest = false
    }

    // ========================================================================
    // Main-thread work contract
    // ========================================================================

    fun isAnimating(): Boolean =
        mSwipeState != SwipeState.IDLE || mReturningToRest

    fun postOnSettle(action: Runnable) {
        if (!isAnimating()) {
            action.run()
            return
        }
        mPostSettleActions.add(action)
    }

    private fun runPostSettleActions() {
        if (mPostSettleActions.isEmpty()) return
        val pending = ArrayList(mPostSettleActions)
        mPostSettleActions.clear()
        for (action in pending) action.run()
    }

    // ========================================================================
    // Window
    // ========================================================================

    fun setWindow(window: PlaybackWindow, direction: Int, restart: Boolean): Boolean {
        if (mStrip == null) {
            mWindow = window
            mLastWindowGeneration = window.generation
            return true
        }

        val previousGeneration = mLastWindowGeneration
        mLastWindowGeneration = window.generation

        return when (mSwipeState) {
            SwipeState.AWAITING_SNAPSHOT -> {
                val accepted = mExpectedCurrentPath != null &&
                    mExpectedCurrentPath == window.currentPath
                mWindow = window
                mExpectedCurrentPath = null
                cancelSnapshotTimeout()
                mSwipeState = SwipeState.IDLE
                if (accepted) {
                    snapToRest()
                    render()
                    runPostSettleActions()
                    true
                } else {
                    render()
                    animateToRest { runPostSettleActions() }
                    false
                }
            }
            SwipeState.COMMITTING -> {
                val accepted = mExpectedCurrentPath != null &&
                    mExpectedCurrentPath == window.currentPath
                if (accepted) {
                    mConfirmedWindow = window
                } else {
                    cancelSwipe()
                    mWindow = window
                    render()
                    animateToRest { runPostSettleActions() }
                }
                false
            }
            SwipeState.RESTARTING -> {
                val incoming = window.currentPath
                val sameSong = incoming != null && incoming == mWindow.currentPath
                if (sameSong) {
                    mWindow = window
                    false
                } else {
                    cancelSwipe()
                    mWindow = window
                    render()
                    animateToRest { runPostSettleActions() }
                    false
                }
            }
            SwipeState.REVEAL_PENDING -> {
                mWindow = window
                val incoming = window.currentPath
                if (incoming != null && incoming != mPendingRevealPath) {
                    startReveal(incoming)
                }
                false
            }
            SwipeState.REVEALING -> {
                mWindow = window
                val incoming = window.currentPath
                if (mFadeOverlayView != null && incoming != null &&
                    incoming != mFadeOverlayPath
                ) {
                    installOverlayBitmap(incoming)
                }
                false
            }
            SwipeState.DRAGGING -> {
                cancelSwipe()
                mWindow = window
                snapToRest()
                render()
                runPostSettleActions()
                true
            }
            SwipeState.IDLE -> adoptInIdle(window, previousGeneration, direction, restart)
        }
    }

    private fun adoptInIdle(
        window: PlaybackWindow,
        previousGeneration: Long,
        direction: Int,
        restart: Boolean
    ): Boolean {
        val incomingCurrent = window.currentPath
        val songChanged = incomingCurrent != null && incomingCurrent != mWindow.currentPath
        val freshTransition = window.generation > previousGeneration

        if (incomingCurrent == null || !freshTransition || mSlotWidth <= 0) {
            mWindow = window
            snapToRest()
            render()
            return true
        }

        if (direction == 0) {
            mWindow = window
            return if (songChanged) {
                startReveal(incomingCurrent)
                false
            } else {
                snapToRest()
                render()
                true
            }
        }

        if (restart) {
            mWindow = window
            startBelowThreshold(direction)
            return false
        }

        mConfirmedWindow = window
        startCommit(direction, false)
        return false
    }

    fun clear() {
        cancelSwipe()
        mWindow = PlaybackWindow.EMPTY
        mLastWindowGeneration = -1L
        if (mStrip != null) {
            snapToRest()
            render()
        }
    }

    // ========================================================================
    // External art handoff
    // ========================================================================

    fun onArtReady(path: String, bitmap: Bitmap) {
        mCache.put(path, bitmap)
        mDecodedPaths.add(path)
        if (mStrip == null) return
        if (mSwipeState == SwipeState.REVEAL_PENDING && path == mPendingRevealPath) {
            cancelPendingRevealTimeout()
            mPendingRevealPath = null
            startFade()
            return
        }
        if (mSwipeState == SwipeState.REVEALING && path == mFadeOverlayPath) {
            installOverlayBitmap(path)
        }
        render()
    }

    fun invalidatePath(path: String) {
        mCache.remove(path)
        mDecodedPaths.remove(path)
        if (mStrip != null) render()
    }

    fun setPlaceholder(placeholderBitmap: Bitmap?) {
        mPlaceholderBitmap = placeholderBitmap
        if (mStrip != null) render()
    }

    // ========================================================================
    // Swipe
    // ========================================================================

    fun beginSwipe() {
        if (mSwipeState != SwipeState.IDLE || mReturningToRest) return
        if (mStrip == null || mSlotWidth <= 0) return
        mSwipeState = SwipeState.DRAGGING
    }

    fun updateSwipe(horizontalDisplacement: Float) {
        if (mSwipeState != SwipeState.DRAGGING) return
        val strip = mStrip ?: return
        if (mSlotWidth <= 0) return
        val clamped = Math.max(-mSlotWidth.toFloat(), Math.min(mSlotWidth.toFloat(), horizontalDisplacement))
        strip.translationX = -mSlotWidth + clamped
    }

    fun endSwipe(horizontalDisplacement: Float) {
        if (mSwipeState != SwipeState.DRAGGING) {
            mSwipeState = SwipeState.IDLE
            return
        }
        if (mStrip == null || mSlotWidth <= 0) {
            mSwipeState = SwipeState.IDLE
            return
        }

        val middleZoneWidth = Math.max(1f, mSlotWidth - 2f * mEdgeZonePx)
        val commitThreshold = middleZoneWidth * COMMIT_THRESHOLD_FRACTION
        val clamped = Math.max(-mSlotWidth.toFloat(), Math.min(mSlotWidth.toFloat(), horizontalDisplacement))

        val wantsForward = clamped <= -commitThreshold
        val wantsBackward = clamped >= commitThreshold

        val canCommitForward = wantsForward &&
            mWindow.nextPath != null && mWindow.nextPath != mWindow.currentPath
        val canCommitBackward = wantsBackward &&
            mWindow.previousPath != null && mWindow.previousPath != mWindow.currentPath

        if (canCommitForward) {
            startCommit(1, true)
            return
        }
        if (canCommitBackward) {
            startCommit(-1, true)
            return
        }

        mSwipeState = SwipeState.IDLE
        animateToRest(null)
    }

    // ========================================================================
    // Commit animations
    // ========================================================================

    private fun startCommit(direction: Int, fireListener: Boolean) {
        mSwipeDirection = direction
        mSwipeState = SwipeState.COMMITTING
        mExpectedCurrentPath = if (direction > 0) mWindow.nextPath else mWindow.previousPath

        val targetTranslationX = if (direction > 0) -2f * mSlotWidth else 0f

        mStrip?.animate()
            ?.translationX(targetTranslationX)
            ?.setDuration(COMMIT_DURATION_MS)
            ?.setInterpolator(EMPHASIZED_DECELERATE)
            ?.withEndAction {
                if (mSwipeState != SwipeState.COMMITTING) return@withEndAction
                if (mConfirmedWindow != null) {
                    val confirmed = mConfirmedWindow!!
                    mConfirmedWindow = null
                    mWindow = confirmed
                    mExpectedCurrentPath = null
                    mSwipeState = SwipeState.IDLE
                    snapToRest()
                    render()
                    runPostSettleActions()
                    return@withEndAction
                }
                mSwipeState = SwipeState.AWAITING_SNAPSHOT
                if (fireListener) {
                    mSwipeCommitListener?.onSwipeCommitted(mSwipeDirection)
                }
                scheduleSnapshotTimeout()
            }
            ?.start()
    }

    private fun startBelowThreshold(direction: Int) {
        mSwipeDirection = direction
        mSwipeState = SwipeState.RESTARTING
        mExpectedCurrentPath = null
        mConfirmedWindow = null

        val middleZoneWidth = Math.max(1f, mSlotWidth - 2f * mEdgeZonePx)
        val nudgePx = middleZoneWidth * RESTART_NUDGE_FRACTION
        val displacedTranslationX = if (direction > 0) {
            -mSlotWidth - nudgePx
        } else {
            -mSlotWidth + nudgePx
        }

        startRestSpring(displacedTranslationX) {
            if (mSwipeState != SwipeState.RESTARTING) return@startRestSpring
            startNudgeReturn()
        }
    }

    private fun startNudgeReturn() {
        startRestSpring(-mSlotWidth.toFloat()) { finishNudge() }
    }

    private fun finishNudge() {
        if (mSwipeState != SwipeState.RESTARTING) return
        mSwipeState = SwipeState.IDLE
        mSwipeDirection = 0
        mExpectedCurrentPath = null
        mConfirmedWindow = null
        runPostSettleActions()
    }

    // ========================================================================
    // Reveal
    // ========================================================================

    private fun startReveal(incomingPath: String): Boolean {
        val incomingBitmap = pathBitmap(incomingPath)
        if (incomingBitmap != null || mDecodedPaths.contains(incomingPath)) {
            cancelPendingRevealTimeout()
            mPendingRevealPath = null
            startFade()
            return true
        }
        scheduleIfMissing(incomingPath, null)
        beginPendingReveal(incomingPath)
        return false
    }

    private fun beginPendingReveal(incomingPath: String) {
        mSwipeState = SwipeState.REVEAL_PENDING
        mSwipeDirection = 0
        mExpectedCurrentPath = null
        mConfirmedWindow = null
        mPendingRevealPath = incomingPath

        cancelPendingRevealTimeout()
        mPendingRevealTimeoutRunnable = Runnable {
            if (mSwipeState != SwipeState.REVEAL_PENDING) return@Runnable
            Log.w(TAG, "Reveal art timeout; starting with placeholder")
            mPendingRevealPath = null
            startFade()
        }
        mHandler.postDelayed(mPendingRevealTimeoutRunnable!!, REVEAL_ART_TIMEOUT_MS)
    }

    private fun cancelPendingRevealTimeout() {
        mPendingRevealTimeoutRunnable?.let {
            mHandler.removeCallbacks(it)
            mPendingRevealTimeoutRunnable = null
        }
    }

    private fun startFade() {
        val strip = mStrip
        if (strip == null || mSlotWidth <= 0 || mSlotHeight <= 0) {
            snapToRest()
            render()
            return
        }

        mSwipeState = SwipeState.REVEALING
        mSwipeDirection = 0
        mExpectedCurrentPath = null
        mConfirmedWindow = null
        mPendingRevealPath = null

        val incomingPath = mWindow.currentPath
        val incomingBitmap = pathBitmap(incomingPath)

        val overlay = ImageView(mContext)
        overlay.scaleType = ImageView.ScaleType.FIT_CENTER
        overlay.isClickable = false
        overlay.isFocusable = false
        overlay.layoutDirection = View.LAYOUT_DIRECTION_LTR

        val overlayParams = FrameLayout.LayoutParams(mSlotWidth, mSlotHeight)
        overlayParams.gravity = Gravity.CENTER
        overlay.layoutParams = overlayParams
        overlay.setImageBitmap(incomingBitmap ?: mPlaceholderBitmap)
        overlay.alpha = 0f
        overlay.scaleX = REVEAL_INCOMING_START_SCALE
        overlay.scaleY = REVEAL_INCOMING_START_SCALE

        overlay.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        mContainer.addView(overlay)
        mFadeOverlayView = overlay
        mFadeOverlayPath = incomingPath

        val outgoingDuration = Math.max(1L, (REVEAL_DURATION_MS * REVEAL_OUTGOING_FRACTION).toLong())
        strip.animate()
            .alpha(0f)
            .setDuration(outgoingDuration)
            .setInterpolator(EMPHASIZED_ACCELERATE)
            .start()

        val overlapDuration = Math.max(1L, (REVEAL_DURATION_MS * REVEAL_OVERLAP_FRACTION).toLong())
        val incomingDelay = Math.max(0L, outgoingDuration - overlapDuration)
        val incomingDuration = Math.max(1L, REVEAL_DURATION_MS - incomingDelay)
        overlay.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(incomingDelay)
            .setDuration(incomingDuration)
            .setInterpolator(EMPHASIZED_DECELERATE)
            .withEndAction {
                if (mSwipeState != SwipeState.REVEALING) return@withEndAction
                mContainer.removeView(overlay)
                mFadeOverlayView = null
                mFadeOverlayPath = null
                mSwipeState = SwipeState.IDLE
                mSwipeDirection = 0
                mStrip?.alpha = 1f
                snapToRest()
                render()
                runPostSettleActions()
            }
            .start()
    }

    private fun installOverlayBitmap(path: String?) {
        val overlay = mFadeOverlayView ?: return
        val art = if (path != null) pathBitmap(path) else null
        overlay.setImageBitmap(art ?: mPlaceholderBitmap)
    }

    private fun cancelSwipe() {
        mStrip?.animate()?.cancel()
        mStrip?.alpha = 1f
        mRestSpring?.cancel()
        mFadeOverlayView?.let {
            it.animate().cancel()
            it.setLayerType(View.LAYER_TYPE_NONE, null)
            mContainer.removeView(it)
            mFadeOverlayView = null
        }
        mFadeOverlayPath = null
        cancelSnapshotTimeout()
        cancelPendingRevealTimeout()
        mPendingRevealPath = null
        mSwipeState = SwipeState.IDLE
        mSwipeDirection = 0
        mExpectedCurrentPath = null
        mConfirmedWindow = null
        mReturningToRest = false
        runPostSettleActions()
    }

    private fun animateToRest(endAction: Runnable?) {
        val strip = mStrip
        if (strip == null) {
            endAction?.run()
            return
        }
        mReturningToRest = true
        startRestSpring(-mSlotWidth.toFloat()) {
            mStrip?.translationX = -mSlotWidth.toFloat()
            mReturningToRest = false
            endAction?.run()
        }
    }

    private fun startRestSpring(targetTranslationX: Float, endAction: Runnable) {
        mRestSpring?.cancel()
        val strip = mStrip ?: return
        val spring = SpringAnimation(strip, DynamicAnimation.TRANSLATION_X, targetTranslationX)
        spring.spring.dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
            .toFloat()
        spring.spring.stiffness = SpringForce.STIFFNESS_LOW
        spring.addEndListener { animation, canceled, value, velocity ->
            if (canceled) return@addEndListener
            endAction.run()
        }
        spring.start()
        mRestSpring = spring
    }

    private fun scheduleSnapshotTimeout() {
        cancelSnapshotTimeout()
        mSnapshotTimeoutRunnable = Runnable {
            if (mSwipeState != SwipeState.AWAITING_SNAPSHOT) return@Runnable
            Log.w(TAG, "Snapshot timeout; settling back")
            mExpectedCurrentPath = null
            mSwipeState = SwipeState.IDLE
            animateToRest { runPostSettleActions() }
        }
        mHandler.postDelayed(mSnapshotTimeoutRunnable!!, SNAPSHOT_TIMEOUT_MS)
    }

    private fun cancelSnapshotTimeout() {
        mSnapshotTimeoutRunnable?.let {
            mHandler.removeCallbacks(it)
            mSnapshotTimeoutRunnable = null
        }
    }

    // ========================================================================
    // Rendering
    // ========================================================================

    private fun render() {
        if (mStrip == null || mSlotWidth <= 0) return

        val previousBitmap = pathBitmap(mWindow.previousPath)
        val currentBitmap = pathBitmap(mWindow.currentPath)
        val nextBitmap = pathBitmap(mWindow.nextPath)

        installImage(mPreviousView, previousBitmap)
        installImage(mCurrentView, currentBitmap ?: mPlaceholderBitmap)
        installImage(mNextView, nextBitmap)

        scheduleIfMissing(mWindow.previousPath, previousBitmap)
        scheduleIfMissing(mWindow.currentPath, currentBitmap)
        scheduleIfMissing(mWindow.nextPath, nextBitmap)
    }

    private fun pathBitmap(path: String?): Bitmap? {
        if (path == null) return null
        val cached = mCache.get(path) ?: return null
        return if (!cached.isRecycled) cached else null
    }

    private fun installImage(slotView: ImageView?, bitmap: Bitmap?) {
        if (slotView == null) return
        if (bitmap != null && !bitmap.isRecycled) {
            slotView.setImageBitmap(bitmap)
        } else {
            slotView.setImageDrawable(null)
        }
    }

    private fun scheduleIfMissing(path: String?, alreadyLoadedBitmap: Bitmap?) {
        if (path == null || alreadyLoadedBitmap != null) return
        if (!mInflightDecodePaths.add(path)) return
        mExecutor.execute {
            val decoded = decodeSlotBitmap(path)
            mContainer.post {
                mInflightDecodePaths.remove(path)
                mDecodedPaths.add(path)
                if (decoded != null) {
                    mCache.put(path, decoded)
                }
                if (mSwipeState == SwipeState.REVEAL_PENDING && path == mPendingRevealPath) {
                    cancelPendingRevealTimeout()
                    mPendingRevealPath = null
                    startFade()
                    return@post
                }
                if (mStrip != null) render()
            }
        }
    }

    private fun decodeSlotBitmap(path: String): Bitmap? {
        var retriever: MediaMetadataRetriever? = null
        return try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(path)
            val bytes = retriever.embeddedPicture
            if (bytes == null || bytes.isEmpty()) return null

            val boundsOptions = BitmapFactory.Options()
            boundsOptions.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOptions)
            val sampleSize = calculateSampleSize(
                boundsOptions, SLOT_BITMAP_SIZE_PX, SLOT_BITMAP_SIZE_PX
            )
            val decodeOptions = BitmapFactory.Options()
            decodeOptions.inSampleSize = sampleSize
            decodeOptions.inPreferredConfig = Bitmap.Config.ARGB_8888
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)
        } catch (exception: Exception) {
            Log.w(TAG, "Failed to decode slot art for $path", exception)
            null
        } finally {
            retriever?.let {
                try { it.release() } catch (ignored: Exception) { }
            }
        }
    }

    private fun calculateSampleSize(
        options: BitmapFactory.Options,
        requestedWidth: Int,
        requestedHeight: Int
    ): Int {
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 1
        if (height > requestedHeight || width > requestedWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= requestedHeight &&
                (halfWidth / inSampleSize) >= requestedWidth
            ) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    // ========================================================================
    // Companion constants
    // ========================================================================

    companion object {
        private const val TAG = "AlbumArtCarousel"

        private const val SLOT_BITMAP_SIZE_PX = 1024
        private const val COMMIT_DURATION_MS = 500L
        private const val REVEAL_DURATION_MS = 500L
        private const val REVEAL_OUTGOING_FRACTION = 0.45f
        private const val REVEAL_INCOMING_START_SCALE = 0.96f
        private const val REVEAL_OVERLAP_FRACTION = 0.15f
        private const val REVEAL_ART_TIMEOUT_MS = 1500L
        private const val COMMIT_THRESHOLD_FRACTION = 0.50f
        private const val RESTART_NUDGE_FRACTION = 0.25f
        private const val SNAPSHOT_TIMEOUT_MS = 1500L
    }
}