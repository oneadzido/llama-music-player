// NotificationController.kt
package com.ark.llama

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Log
import android.util.LruCache
import androidx.core.content.ContextCompat
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.SettingsEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.HashMap
import java.util.Objects
import java.util.concurrent.atomic.AtomicBoolean
import java.util.function.Supplier

/**
 * Owns every notification surface the app produces, and is the sole
 * writer of the [MediaSessionCompat] metadata and playback state.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class NotificationController private constructor(appContext: Context) {

    interface ServiceStateSource {
        fun snapshotForNotification(): RenderSnapshot?
        fun isIdle(): Boolean
        fun applyToMediaSession(snapshot: RenderSnapshot?)
        fun sessionPlaybackState(): Int
        fun updateSessionPlaybackState()
        fun getGeneration(): Long
        fun shouldRemainForeground(): Boolean
    }

    class RenderSnapshot(
        @JvmField val title: String,
        @JvmField val artist: String,
        @JvmField val album: String,
        @JvmField val path: String,
        @JvmField val isPlaying: Boolean,
        @JvmField val durationMs: Int,
        @JvmField val art: Bitmap?,
        @JvmField val artResolved: Boolean
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is RenderSnapshot) return false
            return isPlaying == other.isPlaying &&
                artResolved == other.artResolved &&
                durationMs == other.durationMs &&
                title == other.title &&
                artist == other.artist &&
                album == other.album &&
                path == other.path &&
                art === other.art
        }

        override fun hashCode(): Int =
            Objects.hash(title, artist, album, path, isPlaying, durationMs, artResolved)
    }

    private class PlaybackState(
        @JvmField val channelState: String,
        @JvmField val isPlaying: Boolean,
        @JvmField val title: String,
        @JvmField val artist: String,
        @JvmField val albumArt: Bitmap?,
        @JvmField val artKey: String?,
        @JvmField val songPath: String?
    ) {
        fun isResting(): Boolean = STATE_RESTING == channelState
    }

    private val mContext: Context = appContext
    private val mNotificationManager: NotificationManager? =
        appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    private val mMainHandler = Handler(Looper.getMainLooper())
    private val mAlbumArtCache: LruCache<String, Bitmap> =
        AlbumArtCache.getInstance(appContext).asLruCache()

    @Volatile private var mThemedPlaceholder: Bitmap? = null
    @Volatile private var mThemedPlaceholderColor: Int = 0

    private val mPlaybackLock = Any()
    private val mLibraryLock = Any()

    private var mService: Service? = null
    private var mStateSource: ServiceStateSource? = null
    private var mSessionTokenProvider: Supplier<MediaSessionCompat.Token?>? = null

    private var mPlayPauseIntent: PendingIntent? = null
    private var mNextIntent: PendingIntent? = null
    private var mPreviousIntent: PendingIntent? = null
    private var mContentIntent: PendingIntent? = null
    private var mCloseIntent: PendingIntent? = null
    private var mDeleteIntent: PendingIntent? = null

    private val mThemedIconCache = HashMap<Long, Icon>()

    @Volatile
    private var mPlaybackState: PlaybackState =
        PlaybackState(STATE_RESTING, false, "", "", null, null, "")

    private val mPlaybackForeground = AtomicBoolean(false)

    private var mLastRenderedSnapshot: RenderSnapshot? = null
    private var mLastCommittedGeneration: Long = -1L

    private var mAwarenessRunnable: Runnable? = null

    private var mLibraryTitle: String? = null
    private var mLibraryBody: String? = null
    private var mLibraryOperationId: String? = null
    private var mLibraryShowing: Boolean = false
    private var mLibraryStartTime: Long = 0L

    init {
        createChannels()
        mPlayPauseIntent = buildTransportPendingIntent(REQUEST_PLAY_PAUSE, ACTION_PLAY_PAUSE)
        mNextIntent = buildTransportPendingIntent(REQUEST_NEXT, ACTION_NEXT)
        mPreviousIntent = buildTransportPendingIntent(REQUEST_PREVIOUS, ACTION_PREV)
        LlamaEventBus.register(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        // No in-place repaint. The notification is rebuilt from the
        // persisted theme on the next commit. This subscriber is a
        // registered consumer of the sticky event; its body is a
        // no-op.
    }

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (exception: Exception) {
        Log.w(TAG, "Failed to obtain localized context", exception)
        mContext
    }

    fun attachService(service: Service) {
        mService = service
    }

    fun detachService() {
        stopAwareness()
        mStateSource = null
        mSessionTokenProvider = null
        mLastRenderedSnapshot = null
        mLastCommittedGeneration = -1L
        mPlaybackForeground.set(false)
        mPlaybackState = PlaybackState(STATE_RESTING, false, "", "", null, null, "")
        synchronized(mPlaybackLock) {
            mNotificationManager?.cancel(ID_PLAYBACK)
        }
        mService = null
    }

    fun setStateSource(source: ServiceStateSource?) {
        mStateSource = source
        if (source == null) stopAwareness() else startAwareness()
    }

    fun setSessionTokenProvider(provider: Supplier<MediaSessionCompat.Token?>?) {
        mSessionTokenProvider = provider
    }

    fun demoteFromForeground() {
        synchronized(mPlaybackLock) {
            val service = mService ?: return
            if (!mPlaybackForeground.getAndSet(false)) return
            try {
                service.stopForeground(false)
            } catch (exception: Exception) {
                Log.e(TAG, "demoteFromForeground failed", exception)
            }
        }
    }

    fun clearPlaybackNotification() {
        synchronized(mPlaybackLock) {
            mLastRenderedSnapshot = null
            mLastCommittedGeneration = -1L
            mPlaybackForeground.set(false)
            mPlaybackState = PlaybackState(STATE_RESTING, false, "", "", null, null, "")
            mNotificationManager?.cancel(ID_PLAYBACK)
        }
    }

    fun commitFromBroadcast(generation: Long, snapshot: RenderSnapshot?) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post { commitFromBroadcast(generation, snapshot) }
            return
        }

        if (generation >= 0 && generation < mLastCommittedGeneration) return
        if (snapshot == null) return

        var rendered = false
        if (snapshot != mLastRenderedSnapshot) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot
                rendered = true
            }
        } else {
            rendered = true
        }

        if (rendered && generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation
        }

        mStateSource?.updateSessionPlaybackState()
    }

    fun commitNow() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mMainHandler.post { commitNow() }
            return
        }
        if (mStateSource == null) return
        try {
            syncOnce()
        } catch (exception: Exception) {
            Log.e(TAG, "commitNow failed", exception)
        }
    }

    fun pokeAwareness() {
        if (mStateSource == null) return
        mMainHandler.post {
            try {
                syncOnce()
            } catch (exception: Exception) {
                Log.e(TAG, "pokeAwareness poll failed", exception)
            }
        }
    }

    private fun startAwareness() {
        if (mAwarenessRunnable != null) return
        mAwarenessRunnable = object : Runnable {
            override fun run() {
                try {
                    syncOnce()
                } catch (exception: Exception) {
                    Log.e(TAG, "awareness poll failed", exception)
                }
                mAwarenessRunnable?.let { mMainHandler.postDelayed(it, AWARENESS_INTERVAL_MS) }
            }
        }
        mMainHandler.post(mAwarenessRunnable!!)
    }

    private fun stopAwareness() {
        mAwarenessRunnable?.let {
            mMainHandler.removeCallbacks(it)
            mAwarenessRunnable = null
        }
    }

    private fun syncOnce() {
        val source = mStateSource ?: return
        val generation = source.getGeneration()

        if (source.isIdle()) {
            val service = mService as? MusicService
            val transitionPending = service?.isTransitionPending() ?: false
            if (!transitionPending && mLastRenderedSnapshot != null) {
                if (applySnapshot(null)) {
                    mLastRenderedSnapshot = null
                    mLastCommittedGeneration = generation
                }
            } else if (!transitionPending && mLastRenderedSnapshot == null) {
                mLastCommittedGeneration = generation
            }
            source.updateSessionPlaybackState()
            return
        }

        if (generation < mLastCommittedGeneration) {
            source.updateSessionPlaybackState()
            return
        }

        val snapshot = source.snapshotForNotification()
        if (snapshot == null) {
            source.updateSessionPlaybackState()
            return
        }

        if (snapshot != mLastRenderedSnapshot) {
            if (applySnapshot(snapshot)) {
                mLastRenderedSnapshot = snapshot
                if (generation > mLastCommittedGeneration) {
                    mLastCommittedGeneration = generation
                }
            }
        } else if (generation > mLastCommittedGeneration) {
            mLastCommittedGeneration = generation
        }

        source.updateSessionPlaybackState()
    }

    private fun applySnapshot(snapshot: RenderSnapshot?): Boolean {
        val previousState = mPlaybackState
        val previousSnapshot = mLastRenderedSnapshot
        val nextState: PlaybackState

        if (snapshot == null) {
            nextState = PlaybackState(STATE_RESTING, false, "", "", null, null, "")
        } else {
            val songChanged = previousState == null ||
                snapshot.path != previousState.songPath

            var albumArt: Bitmap? = null
            var artKey: String? = null

            if (snapshot.art != null && !snapshot.art.isRecycled) {
                val cached = mAlbumArtCache.get(snapshot.path)
                if (cached != null && !cached.isRecycled) {
                    albumArt = cached
                } else {
                    val safe = createSafeCopy(snapshot.art, MAX_ART_SIZE)
                    if (safe != null) {
                        mAlbumArtCache.put(snapshot.path, safe)
                        albumArt = safe
                    }
                }
                if (albumArt != null) artKey = snapshot.path
            } else if (!songChanged && !snapshot.artResolved) {
                albumArt = previousState.albumArt
                artKey = previousState.artKey
            }

            nextState = PlaybackState(
                if (snapshot.isPlaying) STATE_PLAYING else STATE_PAUSED,
                snapshot.isPlaying,
                snapshot.title,
                snapshot.artist,
                albumArt,
                artKey,
                snapshot.path
            )
        }

        mPlaybackState = nextState
        val posted = performPlaybackUpdate()
        if (!posted) {
            mPlaybackState = previousState
            mStateSource?.applyToMediaSession(previousSnapshot)
            return false
        }
        mStateSource?.applyToMediaSession(snapshot)
        return true
    }

    private fun performPlaybackUpdate(): Boolean {
        synchronized(mPlaybackLock) {
            val nm = mNotificationManager ?: return false
            try {
                val state = mPlaybackState
                val valid = !state.isResting() && state.title.isNotEmpty()

                if (valid) {
                    val notification = buildPlaybackNotification(state)
                    try {
                        nm.notify(ID_PLAYBACK, notification)
                    } catch (exception: SecurityException) {
                        Log.e(TAG, "Missing notification permission", exception)
                        return false
                    }

                    val promote = STATE_PLAYING == state.channelState ||
                        (mStateSource?.shouldRemainForeground() == true)

                    if (promote) {
                        val service = mService
                        if (service != null && !mPlaybackForeground.get()) {
                            try {
                                service.startForeground(ID_PLAYBACK, notification)
                                mPlaybackForeground.set(true)
                            } catch (exception: SecurityException) {
                                Log.w(TAG,
                                    "Foreground promotion failed; notification remains posted",
                                    exception)
                            } catch (exception: Exception) {
                                Log.e(TAG, "Foreground promotion failed", exception)
                            }
                        }
                    } else {
                        if (mService != null) demoteFromForeground()
                    }
                } else {
                    nm.cancel(ID_PLAYBACK)
                    if (mService != null) demoteFromForeground()
                }
                return true
            } catch (exception: Exception) {
                Log.e(TAG, "performPlaybackUpdate failed", exception)
                return false
            }
        }
    }

    private fun buildPlaybackNotification(state: PlaybackState): Notification {
        val themeColor = resolveThemeColor()
        val localeContext = getLocaleContext()

        val contentIntent = getContentIntent()
        val closeIntent = getCloseIntent()
        val deleteIntent = getDeleteIntent()

        val isResting = state.isResting()
        var displayTitle = if (isResting)
            localeContext.getString(R.string.notification_placeholder_title)
        else state.title
        var displayArtist = if (isResting)
            localeContext.getString(R.string.notification_placeholder_artist)
        else state.artist

        if (displayTitle.length > MAX_TITLE_LENGTH) {
            displayTitle = displayTitle.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS
        }
        if (displayArtist.length > MAX_ARTIST_LENGTH) {
            displayArtist = displayArtist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS
        }

        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(mContext, CHANNEL_PLAYBACK)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(mContext)
        }

        builder.setSmallIcon(SMALL_ICON_RES)
            .setContentTitle(displayTitle)
            .setContentText(displayArtist)
            .setColor(themeColor)
            .setContentIntent(contentIntent)
            .setDeleteIntent(deleteIntent)
            .setOngoing(state.isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }

        val largeIcon = getSafeLargeIcon(state)
        if (largeIcon != null) builder.setLargeIcon(largeIcon)

        mPreviousIntent?.let {
            addAction(
                builder, R.drawable.ic_notification_prev,
                localeContext.getString(R.string.notification_action_prev),
                it, NEUTRAL_COLOR
            )
        }
        mPlayPauseIntent?.let {
            val icon = if (state.isPlaying) R.drawable.ic_notification_pause
            else R.drawable.ic_notification_play
            val label = if (state.isPlaying)
                localeContext.getString(R.string.notification_action_pause)
            else localeContext.getString(R.string.notification_action_play)
            addAction(builder, icon, label, it, themeColor)
        }
        mNextIntent?.let {
            addAction(
                builder, R.drawable.ic_notification_next,
                localeContext.getString(R.string.notification_action_next),
                it, NEUTRAL_COLOR
            )
        }
        addAction(
            builder, R.drawable.ic_notification_close,
            localeContext.getString(R.string.notification_action_close),
            closeIntent, RED_COLOR
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val mediaStyle = Notification.MediaStyle()
            mediaStyle.setShowActionsInCompactView(0, 1, 2)
            val token = mSessionTokenProvider?.get()
            if (token != null) {
                val raw = token.token
                if (raw is android.media.session.MediaSession.Token) {
                    mediaStyle.setMediaSession(raw)
                }
            }
            builder.setStyle(mediaStyle)
        }

        return builder.build()
    }

    private fun addAction(
        builder: Notification.Builder,
        iconRes: Int,
        label: String,
        intent: PendingIntent,
        color: Int
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val themed = getThemedIcon(iconRes, color)
            if (themed != null) {
                builder.addAction(Notification.Action.Builder(themed, label, intent).build())
                return
            }
        }
        @Suppress("DEPRECATION")
        builder.addAction(Notification.Action.Builder(iconRes, label, intent).build())
    }

    private fun getSafeLargeIcon(state: PlaybackState): Bitmap? {
        state.artKey?.let { key ->
            val cached = mAlbumArtCache.get(key)
            if (cached != null && !cached.isRecycled) return cached
        }
        state.albumArt?.let {
            if (!it.isRecycled) return it
        }
        return getThemedPlaceholder()
    }

    private fun getThemedPlaceholder(): Bitmap? {
        val themeColor = resolveThemeColor()
        val cached = mThemedPlaceholder
        if (cached != null && !cached.isRecycled && mThemedPlaceholderColor == themeColor) {
            return cached
        }
        val built = buildThemedPlaceholder(themeColor)
        if (built != null) {
            mThemedPlaceholder = built
            mThemedPlaceholderColor = themeColor
        }
        return built
    }

    fun getPlaceholderForMediaSession(): Bitmap? = getThemedPlaceholder()

    private fun buildThemedPlaceholder(themeColor: Int): Bitmap? {
        return try {
            val drawable = ContextCompat.getDrawable(mContext, R.drawable.album_art_placeholder)
                ?: return null

            var width = drawable.intrinsicWidth
            var height = drawable.intrinsicHeight
            if (width <= 0 || height <= 0) {
                width = MAX_ART_SIZE
                height = MAX_ART_SIZE
            }

            val scale = Math.min(
                MAX_ART_SIZE.toFloat() / width,
                MAX_ART_SIZE.toFloat() / height
            )
            if (scale < 1f) {
                width = Math.max(1, Math.round(width * scale))
                height = Math.max(1, Math.round(height * scale))
            }

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, width, height)
            drawable.colorFilter = PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN)
            drawable.draw(canvas)
            bitmap
        } catch (exception: Exception) {
            Log.e(TAG, "buildThemedPlaceholder failed", exception)
            null
        }
    }

    fun showLibraryStatus(title: String, body: String, operationId: String?) {
        synchronized(mLibraryLock) {
            mLibraryTitle = title
            mLibraryBody = body
            mLibraryOperationId = operationId
            mLibraryShowing = true
            mLibraryStartTime = System.currentTimeMillis()
            performLibraryUpdateLocked()
        }
    }

    fun updateLibraryStatus(title: String, body: String, operationId: String?) {
        synchronized(mLibraryLock) {
            if (!mLibraryShowing) return
            if (mLibraryOperationId != operationId) return
            mLibraryTitle = title
            mLibraryBody = body
            performLibraryUpdateLocked()
        }
    }

    fun dismissLibraryStatus(operationId: String?): Boolean {
        synchronized(mLibraryLock) {
            if (!mLibraryShowing) return false
            if (mLibraryOperationId != operationId) return false
            mLibraryShowing = false
            mLibraryTitle = null
            mLibraryBody = null
            mLibraryOperationId = null
            mLibraryStartTime = 0L
            mNotificationManager?.cancel(ID_LIBRARY)
            return true
        }
    }

    fun clearLibraryStatus(): Boolean {
        synchronized(mLibraryLock) {
            val wasShowing = mLibraryShowing
            mLibraryShowing = false
            mLibraryTitle = null
            mLibraryBody = null
            mLibraryOperationId = null
            mLibraryStartTime = 0L
            mNotificationManager?.cancel(ID_LIBRARY)
            return wasShowing
        }
    }

    fun isLibraryStatusShowing(): Boolean = synchronized(mLibraryLock) { mLibraryShowing }

    fun getLibraryOperationId(): String? = synchronized(mLibraryLock) { mLibraryOperationId }

    private fun performLibraryUpdateLocked() {
        val title = mLibraryTitle ?: return
        val nm = mNotificationManager ?: return
        val body = mLibraryBody ?: ""
        try {
            nm.notify(ID_LIBRARY, buildLibraryNotification(title, body))
        } catch (exception: SecurityException) {
            Log.e(TAG, "Missing notification permission (library)", exception)
        } catch (exception: Exception) {
            Log.e(TAG, "performLibraryUpdate failed", exception)
        }
    }

    private fun buildLibraryNotification(title: String, body: String): Notification {
        val contentIntent = getContentIntent()

        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(mContext, CHANNEL_LIBRARY)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(mContext)
        }

        builder.setSmallIcon(SMALL_ICON_RES)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(resolveThemeColor())
            .setPriority(Notification.PRIORITY_LOW)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setStyle(Notification.BigTextStyle().bigText(body))

        if (mLibraryStartTime > 0L) {
            builder.setWhen(mLibraryStartTime)
            builder.setUsesChronometer(true)
            builder.setChronometerCountDown(false)
            builder.setShowWhen(true)
        } else {
            builder.setShowWhen(false)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setProgress(0, 0, true)
        }
        return builder.build()
    }

    private fun buildPendingIntentFlags(): Int {
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags or PendingIntent.FLAG_IMMUTABLE
        }
        return flags
    }

    private fun buildTransportPendingIntent(requestCode: Int, action: String): PendingIntent {
        val intent = Intent(mContext, MusicService::class.java).apply { setAction(action) }
        return PendingIntent.getService(mContext, requestCode, intent, buildPendingIntentFlags())
    }

    private fun getContentIntent(): PendingIntent {
        mContentIntent?.let { return it }
        val intent = Intent(mContext, MusicPlayer::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val pending = PendingIntent.getActivity(
            mContext, REQUEST_CONTENT, intent, buildPendingIntentFlags()
        )
        mContentIntent = pending
        return pending
    }

    private fun getCloseIntent(): PendingIntent {
        mCloseIntent?.let { return it }
        val intent = Intent(mContext, MusicService::class.java).apply { setAction("ACTION_STOP") }
        val pending = PendingIntent.getService(
            mContext, REQUEST_CLOSE, intent, buildPendingIntentFlags()
        )
        mCloseIntent = pending
        return pending
    }

    private fun getDeleteIntent(): PendingIntent {
        mDeleteIntent?.let { return it }
        val intent = Intent(mContext, MusicService::class.java).apply { setAction("ACTION_STOP") }
        val pending = PendingIntent.getService(
            mContext, REQUEST_DELETE, intent, buildPendingIntentFlags()
        )
        mDeleteIntent = pending
        return pending
    }

    private fun resolveThemeColor(): Int = try {
        ThemeManager.getInstance(mContext).getCurrentColorInt()
    } catch (exception: Exception) {
        DEFAULT_THEME_COLOR
    }

    private fun createSafeCopy(source: Bitmap?, maxSize: Int): Bitmap? {
        if (source == null || source.isRecycled) return null
        return try {
            val width = source.width
            val height = source.height
            if (width <= 0 || height <= 0) return null
            val config = source.config ?: Bitmap.Config.ARGB_8888
            if (width <= maxSize && height <= maxSize) return source.copy(config, false)
            val scale = Math.min(maxSize.toFloat() / width, maxSize.toFloat() / height)
            Bitmap.createScaledBitmap(
                source,
                Math.round(width * scale),
                Math.round(height * scale),
                true
            )
        } catch (exception: Exception) {
            Log.e(TAG, "createSafeCopy failed", exception)
            null
        }
    }

    private fun getThemedIcon(drawableRes: Int, color: Int): Icon? {
        val key = (drawableRes.toLong() shl 32) or (color.toLong() and 0xFFFFFFFFL)
        mThemedIconCache[key]?.let { return it }
        val built = createThemedIcon(drawableRes, color)
        if (built != null) mThemedIconCache[key] = built
        return built
    }

    private fun createThemedIcon(drawableRes: Int, color: Int): Icon? {
        return try {
            val drawable = ContextCompat.getDrawable(mContext, drawableRes) ?: return null
            drawable.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)

            var width = drawable.intrinsicWidth
            var height = drawable.intrinsicHeight
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE
                height = DEFAULT_ICON_SIZE
            }

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Icon.createWithBitmap(bitmap)
            } else null
        } catch (exception: Exception) {
            Log.e(TAG, "createThemedIcon failed", exception)
            null
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = mNotificationManager ?: return
        val localeContext = getLocaleContext()

        if (nm.getNotificationChannel(CHANNEL_PLAYBACK) == null) {
            val channel = NotificationChannel(
                CHANNEL_PLAYBACK,
                localeContext.getString(R.string.notification_channel_playback),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = localeContext.getString(R.string.notification_channel_playback_desc)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(null, null)
                enableVibration(false)
            }
            nm.createNotificationChannel(channel)
        }

        if (nm.getNotificationChannel(CHANNEL_LIBRARY) == null) {
            val channel = NotificationChannel(
                CHANNEL_LIBRARY,
                localeContext.getString(R.string.notification_channel_library),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = localeContext.getString(R.string.notification_channel_library_desc)
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    fun shutdown() {
        stopAwareness()
        LlamaEventBus.unregister(this)
        synchronized(mLibraryLock) {
            mLibraryShowing = false
            mLibraryTitle = null
            mLibraryBody = null
            mLibraryOperationId = null
            mLibraryStartTime = 0L
        }
        synchronized(mPlaybackLock) {
            mNotificationManager?.cancel(ID_PLAYBACK)
            mNotificationManager?.cancel(ID_LIBRARY)
        }
        mPlaybackForeground.set(false)
        mService = null
        mStateSource = null
        mLastRenderedSnapshot = null
        mLastCommittedGeneration = -1L
        mThemedPlaceholder = null
        mThemedPlaceholderColor = 0
        mThemedIconCache.clear()
        mContentIntent = null
        mCloseIntent = null
        mDeleteIntent = null
        mPlayPauseIntent = null
        mNextIntent = null
        mPreviousIntent = null
        sInstance = null
    }

    companion object {
        private const val TAG = "NotificationController"

        const val ID_PLAYBACK: Int = 1
        const val ID_LIBRARY: Int = 2

        private const val CHANNEL_PLAYBACK = "music_playback_channel"
        private const val CHANNEL_LIBRARY = "music_library_channel"
        private const val SMALL_ICON_RES = R.drawable.ic_notification
        private const val MAX_ART_SIZE = 300
        // `0xFFC0C0C0` is a Long literal (it exceeds Int.MAX_VALUE),
        // and `.toInt()` is a method call, which is not a compile-time
        // constant expression. `const val` therefore rejects the
        // initializer, so these two are plain `private val`.
        private val NEUTRAL_COLOR = 0xFFC0C0C0.toInt()
        private val RED_COLOR = 0xFFE53935.toInt()
        private const val MAX_TITLE_LENGTH = 20
        private const val MAX_ARTIST_LENGTH = 30
        private const val ELLIPSIS = "..."
        private const val DEFAULT_ICON_SIZE = 96
        private const val STATE_RESTING = "Resting"
        private const val STATE_PLAYING = "Playing"
        private const val STATE_PAUSED = "Paused"
        private const val ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE"
        private const val ACTION_NEXT = "ACTION_NEXT"
        private const val ACTION_PREV = "ACTION_PREV"
        private const val AWARENESS_INTERVAL_MS = 100L
        private val DEFAULT_THEME_COLOR = 0xFFB8A86E.toInt()
        private const val REQUEST_CONTENT = 0
        private const val REQUEST_PLAY_PAUSE = 1
        private const val REQUEST_NEXT = 2
        private const val REQUEST_PREVIOUS = 3
        private const val REQUEST_CLOSE = 4
        private const val REQUEST_DELETE = 5

        @Volatile
        private var sInstance: NotificationController? = null

        @JvmStatic
        fun getInstance(context: Context): NotificationController {
            if (sInstance == null) {
                synchronized(NotificationController::class.java) {
                    if (sInstance == null) {
                        sInstance = NotificationController(context.applicationContext)
                    }
                }
            }
            return sInstance!!
        }
    }
}