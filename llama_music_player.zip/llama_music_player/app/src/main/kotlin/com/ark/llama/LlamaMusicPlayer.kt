// LlamaMusicPlayer.kt
package com.ark.llama

import android.app.Application

/**
 * Application class that installs the process-wide singletons in
 * dependency order.
 *
 * <p>Called once per process, before any activity or service.
 * Every singleton below reads a resource, a preference, or another
 * singleton, so the order matters: [LanguageManager] first (its
 * localized context is read by every subsequent manager);
 * [CharacterMapper] second (it reads every supported locale's
 * placeholder values through [LanguageManager.getLocalizedContext]);
 * [Bus] first of all so the EventBus is installed before any
 * manager that posts to it.</p>
 *
 * <p>The name [LlamaMusicPlayer] is the Application, not the player
 * screen. The player screen is [MusicPlayer] (activity); the two are
 * distinct classes in the manifest and distinct identifiers in code.</p>
 *
 * <h3>Install Order Contract</h3>
 * <ol>
 *   <li><b>[Bus.init]</b> — the bus must be installed before any
 *       manager whose constructor registers a subscriber.
 *       [PlaylistManager] registers in its constructor.</li>
 *   <li><b>[LanguageManager]</b> — placeholder rebuild reads
 *       {@code getLanguageTags()}. Everything that resolves a
 *       user-visible string through
 *       {@code getLocalizedContext()} depends on this.</li>
 *   <li><b>[CharacterMapper.init]</b> — reads the placeholder set
 *       through the localized context. Every later manager that
 *       produces a placeholder depends on this.</li>
 *   <li><b>[ThemeManager], [FontAwesome], [AlbumArtCache]</b> —
 *       theme color, icon typeface, and the shared LRU cache.</li>
 *   <li><b>[StorageAccessHelper], [EqualizerManager],
 *       [NotificationController]</b> — SAF, audio effects, and the
 *       notification surface.</li>
 *   <li><b>[ToastManager.init], [OverlayManager.init],
 *       [PlaylistManager.getInstance]</b> — the overlay stack, then
 *       the playlist pipeline that reads it.</li>
 *   <li><b>[NavigationController]</b> — no Context dependency.</li>
 * </ol>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
class LlamaMusicPlayer : Application() {

    override fun onCreate() {
        super.onCreate()

        // The event bus must be installed before any manager that
        // posts to it during construction. Managers that post during
        // construction are rare but not impossible: PlaylistManager
        // registers its own subscriber in its constructor.
        Bus.init()

        // Locale first: CharacterMapper.rebuildRecognizedPlaceholders()
        // calls LanguageManager.getInstance(context).getLanguageTags().
        LanguageManager.getInstance(this)

        // Placeholders second: every subsequent manager that
        // produces a placeholder reads CharacterMapper's resolved set.
        CharacterMapper.init(this)

        // Theme, icons, caches. Each is independent of the others but
        // reads the theme color for placeholder construction.
        ThemeManager.getInstance(this)
        FontAwesome.init(this)
        AlbumArtCache.getInstance(this)

        // Storage access, audio effects, notification surface, and the
        // playlist pipeline. Order between these matters only when one
        // reads another during construction.
        StorageAccessHelper.getInstance(this)
        EqualizerManager.getInstance(this)
        NotificationController.getInstance(this)

        // PlaylistManager constructs the persistent-overlay stack and
        // registers the trigger-genre receiver. It reads ToastManager
        // through the trigger's onReceive, which fires later — but the
        // manager's own constructor reads OverlayManager.init at the
        // end, so ToastManager must land before PlaylistManager.
        ToastManager.init(this)
        OverlayManager.init(this)
        PlaylistManager.getInstance(this)

        // The navigation controller has no Context dependency.
        NavigationController.getInstance()
    }
}