// LlamaMusicPlayer.kt
package com.ark.llama

import android.app.Application
import com.ark.llama.event.LlamaEventBus

/**
 * Application class that installs the process-wide singletons in
 * dependency order.
 *
 * <p>Called once per process, before any activity or service.
 * Every singleton below reads a resource, a preference, or another
 * singleton, so the order matters: [LanguageManager] first (its
 * localized context is read by every subsequent manager);
 * [CharacterMapper] second (it reads every supported locale's
 * placeholder values through [LanguageManager.getLocalizedContext]);
 * [LlamaEventBus] first of all so the bus is installed before any
 * manager that posts to it.</p>
 *
 * <p>The name [LlamaMusicPlayer] is the Application, not the player
 * screen. The player screen is [MusicPlayer] (activity); the two are
 * distinct classes in the manifest and distinct identifiers in code.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
class LlamaMusicPlayer : Application() {

    override fun onCreate() {
        super.onCreate()

        // The event bus must be installed before any manager that
        // posts to it during construction. Managers that post during
        // construction are rare but not impossible: PlaylistManager
        // registers its own subscriber in its constructor.
        LlamaEventBus.init()

        // Locale first: CharacterMapper.rebuildRecognizedPlaceholders()
        // calls LanguageManager.getInstance(context).getLanguageTags().
        LanguageManager.getInstance(this)

        // Placeholders second: every subsequent manager that
        // produces a placeholder reads CharacterMapper's resolved set.
        CharacterMapper.init(this)

        // Theme, icons, caches. Each is independent of the others but
        // reads the theme color for placeholder construction.
        ThemeManager.getInstance(this)
        FontAwesome.init(this)
        AlbumArtCache.getInstance(this)

        // Storage access, audio effects, notification surface, and the
        // playlist pipeline. Order between these matters only when one
        // reads another during construction.
        StorageAccessHelper.getInstance(this)
        EqualizerManager.getInstance(this)
        NotificationController.getInstance(this)

        // PlaylistManager constructs the persistent-overlay stack and
        // registers the trigger-genre receiver. It reads ToastManager
        // through the trigger's onReceive, which fires later — but the
        // manager's own constructor reads OverlayManager.init at the
        // end, so ToastManager must land before PlaylistManager.
        ToastManager.init(this)
        OverlayManager.init(this)
        PlaylistManager.getInstance(this)

        // The navigation controller has no Context dependency.
        NavigationController.getInstance()
    }
}