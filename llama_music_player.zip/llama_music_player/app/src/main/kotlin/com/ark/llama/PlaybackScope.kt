// PlaybackScope.kt
package com.ark.llama

import org.json.JSONArray
import org.json.JSONObject
import java.util.Collections
import java.util.HashSet
import java.util.Objects
import java.util.Set

/**
 * Immutable filter describing which subset of the library the player
 * considers its current playback scope. Combined with the loose-track
 * path set owned by [MusicService], [matches] answers whether a given
 * song belongs to the active scope.
 *
 * <h3>The Seven Kinds</h3>
 * <p>[Kind] enumerates the seven scope modes. The first three are
 * exclusive; the last four carry a single set of the corresponding
 * filter values. The kind and the set that kind uses travel together;
 * the three other sets are empty for any given instance.</p>
 *
 * <ul>
 *   <li>{@link Kind#ALL_SONGS} — every song in the library.</li>
 *   <li>{@link Kind#FAVORITES} — only songs whose favorite flag is set.</li>
 *   <li>{@link Kind#LOOSE_TRACKS} — only songs that arrived as loose tracks.</li>
 *   <li>{@link Kind#SPECIFIC_FOLDERS} — songs under the enumerated folders.</li>
 *   <li>{@link Kind#SPECIFIC_GENRES} — songs in the enumerated genres.</li>
 *   <li>{@link Kind#SPECIFIC_ARTISTS} — songs by the enumerated artists.</li>
 *   <li>{@link Kind#SPECIFIC_ALBUMS} — songs from the enumerated albums.</li>
 * </ul>
 *
 * <h3>Serialization</h3>
 * <p>[serialize] produces a JSON object string that [deserialize]
 * parses back into an equal instance. The representation is stable
 * across process restarts and is the format [MusicService] persists
 * under `playback_scope_json` in `LlamaPrefs`. A malformed string
 * deserializes to [ALL_SONGS], so a corrupted preference cannot brick
 * the player.</p>
 *
 * <p>The kind is written and read by name. A name that does not
 * match a current constant deserializes to [ALL_SONGS].</p>
 *
 * <h3>Empty Sets</h3>
 * <p>A scope of one of the four filter kinds may carry an empty set.
 * That is a scope that matches nothing — "limit to these artists"
 * with no artists named. [matches] reports false for every song when
 * it is applied. The dialog presents such a selection as it is; it is
 * not rewritten into [ALL_SONGS].</p>
 *
 * <h3>Folder Matching</h3>
 * <p>Folder scope matches a song when its path begins with the
 * stored folder path followed by a path separator. The separator
 * check stops `/storage/emulated/0/Music` from matching
 * `/storage/emulated/0/Music2/song.mp3`.</p>
 *
 * <h3>Placeholder Guard</h3>
 * <p>The genre, artist, and album matchers reject a field whose value
 * is the current locale's placeholder, so a song whose genre is
 * "Unknown Genre" is never matched against a stored genre of
 * "Unknown Genre" chosen by the user.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.4.0
 */
class PlaybackScope constructor(
    kind: Kind,
    paths: Set<String>,
    genres: Set<String>,
    artists: Set<String>,
    albums: Set<String>
) {

    // ========================================================================
    // Kind Enum
    // ========================================================================

    /**
     * The seven scope kinds.
     *
     * <p>The first three carry no filter set; the last four carry
     * exactly one. A scope is either "everything", "something the
     * player derives from the song's own state", or "something the
     * user enumerated".</p>
     */
    enum class Kind {
        /** Every song in the library. */
        ALL_SONGS,

        /** Only songs marked as favorites. */
        FAVORITES,

        /** Only songs that arrived as loose tracks. */
        LOOSE_TRACKS,

        /** Only songs under the enumerated folder paths. */
        SPECIFIC_FOLDERS,

        /** Only songs whose genre is in the enumerated set. */
        SPECIFIC_GENRES,

        /** Only songs whose artist is in the enumerated set. */
        SPECIFIC_ARTISTS,

        /** Only songs whose album is in the enumerated set. */
        SPECIFIC_ALBUMS
    }

    // ========================================================================
    // Fields
    // ========================================================================

    /** Kind of this scope. */
    @JvmField
    val kind: Kind = kind

    /**
     * Folder paths used when [kind] is [Kind.SPECIFIC_FOLDERS].
     * Unmodifiable so a caller cannot corrupt a scope after
     * construction.
     */
    @JvmField
    val paths: Set<String> = Collections.unmodifiableSet(HashSet(paths))

    /**
     * Genres used when [kind] is [Kind.SPECIFIC_GENRES].
     */
    @JvmField
    val genres: Set<String> = Collections.unmodifiableSet(HashSet(genres))

    /**
     * Artists used when [kind] is [Kind.SPECIFIC_ARTISTS].
     */
    @JvmField
    val artists: Set<String> = Collections.unmodifiableSet(HashSet(artists))

    /**
     * Albums used when [kind] is [Kind.SPECIFIC_ALBUMS].
     */
    @JvmField
    val albums: Set<String> = Collections.unmodifiableSet(HashSet(albums))

    // ========================================================================
    // Matching
    // ========================================================================

    /**
     * Returns whether the given song belongs to this scope.
     *
     * <p>A null song, a song with an empty path, or a song whose
     * fields carry the current locale's placeholder never match. The
     * placeholder guard is what stops a "genre" scope chosen by the
     * user from also matching a song whose genre was never tagged.</p>
     *
     * <p>Folder matching appends the platform path separator to the
     * stored folder path before the prefix check, so `/Music` does
     * not match `/Music2/song.mp3`.</p>
     *
     * @param song Song to test, or null
     * @param looseTrackPaths Paths of the loose tracks known to the
     *        service
     * @return True when the song belongs to the scope
     */
    fun matches(song: Song?, looseTrackPaths: Set<String>): Boolean {
        if (song == null || song.path.isEmpty()) {
            return false
        }
        return when (kind) {
            Kind.ALL_SONGS -> true
            Kind.FAVORITES -> song.isFavorite
            Kind.LOOSE_TRACKS -> looseTrackPaths.contains(song.path)
            Kind.SPECIFIC_FOLDERS -> {
                val songPath = song.path
                paths.any { folderPath ->
                    if (folderPath.isEmpty()) {
                        return@any false
                    }
                    val prefix = if (folderPath.endsWith("/")) {
                        folderPath
                    } else {
                        "$folderPath/"
                    }
                    songPath.startsWith(prefix)
                }
            }
            Kind.SPECIFIC_GENRES -> {
                val genre = song.genre
                !CharacterMapper.isUnknownGenre(genre) &&
                    genres.contains(genre)
            }
            Kind.SPECIFIC_ARTISTS -> {
                val artist = song.artist
                !CharacterMapper.isUnknownArtist(artist) &&
                    artists.contains(artist)
            }
            Kind.SPECIFIC_ALBUMS -> {
                val album = song.album
                !CharacterMapper.isUnknownAlbum(album) &&
                    albums.contains(album)
            }
        }
    }

    // ========================================================================
    // Serialization
    // ========================================================================

    /**
     * Serializes this scope to a JSON object string.
     *
     * <p>The representation names every field explicitly so a future
     * kind can be added without breaking older deserializers: an
     * unknown kind deserializes to [ALL_SONGS].</p>
     *
     * <p>On failure (which would indicate a library-level bug in
     * the org.json implementation, not a caller error), returns the
     * serialized form of [ALL_SONGS] so downstream consumers
     * continue to function.</p>
     *
     * @return A JSON string; never null
     */
    fun serialize(): String = try {
        val jsonObject = JSONObject()
        jsonObject.put("kind", kind.name)
        jsonObject.put("paths", JSONArray(paths))
        jsonObject.put("genres", JSONArray(genres))
        jsonObject.put("artists", JSONArray(artists))
        jsonObject.put("albums", JSONArray(albums))
        jsonObject.toString()
    } catch (exception: Exception) {
        "{\"kind\":\"ALL_SONGS\",\"paths\":[],\"genres\":[],\"artists\":[],\"albums\":[]}"
    }

    // ========================================================================
    // Object Methods
    // ========================================================================

    /**
     * Returns whether this scope equals the given object.
     *
     * @param other Object to compare against, or null
     * @return True when the given object is a scope with the same
     *         kind and filter sets
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PlaybackScope) return false
        return kind == other.kind &&
            paths == other.paths &&
            genres == other.genres &&
            artists == other.artists &&
            albums == other.albums
    }

    /**
     * Returns a hash code derived from the kind and the four filter
     * sets. Uses [Objects.hash] on the same field order as v1.4.8's
     * implementation, so any hash value ever logged or persisted is
     * byte-identical.
     *
     * @return The hash code
     */
    override fun hashCode(): Int =
        Objects.hash(kind, paths, genres, artists, albums)

    /**
     * Returns a debug representation of this scope.
     *
     * <p>Names the kind and the size of each filter set rather than
     * dumping the sets themselves, so a log line stays short even
     * for a scope that names hundreds of folders.</p>
     *
     * @return A string naming the kind and the size of each set
     */
    override fun toString(): String =
        "PlaybackScope{kind=$kind, " +
            "paths=${paths.size}, " +
            "genres=${genres.size}, " +
            "artists=${artists.size}, " +
            "albums=${albums.size}}"

    // ========================================================================
    // Companion — Factories and Deserialization
    // ========================================================================

    companion object {

        /** The "every song" scope. Immutable and shared. */
        @JvmField
        val ALL_SONGS: PlaybackScope = PlaybackScope(
            Kind.ALL_SONGS,
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet()
        )

        /**
         * Returns a scope that selects only favorites.
         *
         * @return A favorites scope
         */
        @JvmStatic
        fun favorites(): PlaybackScope = PlaybackScope(
            Kind.FAVORITES,
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet()
        )

        /**
         * Returns a scope that selects only loose tracks.
         *
         * @return A loose-tracks scope
         */
        @JvmStatic
        fun looseTracks(): PlaybackScope = PlaybackScope(
            Kind.LOOSE_TRACKS,
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet()
        )

        /**
         * Returns a folder scope.
         *
         * @param folderPaths Filesystem paths of the folders to include
         * @return A folders scope
         */
        @JvmStatic
        fun folders(folderPaths: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_FOLDERS,
                folderPaths,
                Collections.emptySet(),
                Collections.emptySet(),
                Collections.emptySet()
            )

        /**
         * Returns a genre scope.
         *
         * @param genreNames Genres to include
         * @return A genres scope
         */
        @JvmStatic
        fun genres(genreNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_GENRES,
                Collections.emptySet(),
                genreNames,
                Collections.emptySet(),
                Collections.emptySet()
            )

        /**
         * Returns an artist scope.
         *
         * @param artistNames Artists to include
         * @return An artists scope
         */
        @JvmStatic
        fun artists(artistNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_ARTISTS,
                Collections.emptySet(),
                Collections.emptySet(),
                artistNames,
                Collections.emptySet()
            )

        /**
         * Returns an album scope.
         *
         * @param albumNames Albums to include
         * @return An albums scope
         */
        @JvmStatic
        fun albums(albumNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_ALBUMS,
                Collections.emptySet(),
                Collections.emptySet(),
                Collections.emptySet(),
                albumNames
            )

        /**
         * Deserializes a scope from a string previously produced by
         * [serialize].
         *
         * <p>Returns [ALL_SONGS] for any input that does not parse,
         * and for a kind name that does not match a current
         * constant. This means a corrupted preference, a format
         * upgrade, or an older app version's serialization all fall
         * back to the safest scope rather than leaving the player in
         * an unreachable state.</p>
         *
         * @param serialized JSON string, or null
         * @return The deserialized scope; never null
         */
        @JvmStatic
        fun deserialize(serialized: String?): PlaybackScope {
            if (serialized == null || serialized.isEmpty()) {
                return ALL_SONGS
            }
            return try {
                val jsonObject = JSONObject(serialized)
                val kind = try {
                    Kind.valueOf(
                        jsonObject.optString("kind", "ALL_SONGS")
                    )
                } catch (exception: IllegalArgumentException) {
                    Kind.ALL_SONGS
                }
                val paths = toStringSet(
                    jsonObject.optJSONArray("paths")
                )
                val genres = toStringSet(
                    jsonObject.optJSONArray("genres")
                )
                val artists = toStringSet(
                    jsonObject.optJSONArray("artists")
                )
                val albums = toStringSet(
                    jsonObject.optJSONArray("albums")
                )
                PlaybackScope(kind, paths, genres, artists, albums)
            } catch (exception: Exception) {
                ALL_SONGS
            }
        }

        /**
         * Converts a [JSONArray] of strings into a [Set].
         *
         * <p>Skips null entries and preserves no ordering. A null
         * array (the field was absent in the source JSON) yields an
         * empty set rather than null, so the caller never needs to
         * null-check the result.</p>
         *
         * @param array Array to convert, or null
         * @return A set containing each string in the array
         */
        private fun toStringSet(array: JSONArray?): Set<String> {
            val result: MutableSet<String> = HashSet()
            if (array == null) {
                return result
            }
            for (index in 0 until array.length()) {
                val value: String? = array.optString(index, null)
                if (value != null) {
                    result.add(value)
                }
            }
            return result
        }
    }
}