// PlaybackScope.kt
package com.ark.llama

import org.json.JSONArray
import org.json.JSONObject
import java.util.Objects

/**
 * Immutable filter describing which subset of the library the player
 * considers its current playback scope.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.4.0
 */
class PlaybackScope constructor(
    kind: Kind,
    paths: Set<String>,
    genres: Set<String>,
    artists: Set<String>,
    albums: Set<String>
) {

    // ========================================================================
    // Kind Enum
    // ========================================================================

    enum class Kind {
        ALL_SONGS,
        FAVORITES,
        LOOSE_TRACKS,
        SPECIFIC_FOLDERS,
        SPECIFIC_GENRES,
        SPECIFIC_ARTISTS,
        SPECIFIC_ALBUMS
    }

    // ========================================================================
    // Fields
    // ========================================================================

    @JvmField
    val kind: Kind = kind

    @JvmField
    val paths: Set<String> = paths.toSet()

    @JvmField
    val genres: Set<String> = genres.toSet()

    @JvmField
    val artists: Set<String> = artists.toSet()

    @JvmField
    val albums: Set<String> = albums.toSet()

    // ========================================================================
    // Matching
    // ========================================================================

    fun matches(song: Song?, looseTrackPaths: Set<String>): Boolean {
        if (song == null || song.path.isEmpty()) {
            return false
        }
        return when (kind) {
            Kind.ALL_SONGS -> true
            Kind.FAVORITES -> song.isFavorite
            Kind.LOOSE_TRACKS -> looseTrackPaths.contains(song.path)
            Kind.SPECIFIC_FOLDERS -> {
                val songPath = song.path
                paths.any { folderPath ->
                    if (folderPath.isEmpty()) {
                        return@any false
                    }
                    val prefix = if (folderPath.endsWith("/")) {
                        folderPath
                    } else {
                        "$folderPath/"
                    }
                    songPath.startsWith(prefix)
                }
            }
            Kind.SPECIFIC_GENRES -> {
                val genre = song.genre
                !CharacterMapper.isUnknownGenre(genre) &&
                    genres.contains(genre)
            }
            Kind.SPECIFIC_ARTISTS -> {
                val artist = song.artist
                !CharacterMapper.isUnknownArtist(artist) &&
                    artists.contains(artist)
            }
            Kind.SPECIFIC_ALBUMS -> {
                val album = song.album
                !CharacterMapper.isUnknownAlbum(album) &&
                    albums.contains(album)
            }
        }
    }

    // ========================================================================
    // Serialization
    // ========================================================================

    fun serialize(): String = try {
        val jsonObject = JSONObject()
        jsonObject.put("kind", kind.name)
        jsonObject.put("paths", JSONArray(paths))
        jsonObject.put("genres", JSONArray(genres))
        jsonObject.put("artists", JSONArray(artists))
        jsonObject.put("albums", JSONArray(albums))
        jsonObject.toString()
    } catch (exception: Exception) {
        "{\"kind\":\"ALL_SONGS\",\"paths\":[],\"genres\":[],\"artists\":[],\"albums\":[]}"
    }

    // ========================================================================
    // Object Methods
    // ========================================================================

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PlaybackScope) return false
        return kind == other.kind &&
            paths == other.paths &&
            genres == other.genres &&
            artists == other.artists &&
            albums == other.albums
    }

    override fun hashCode(): Int =
        Objects.hash(kind, paths, genres, artists, albums)

    override fun toString(): String =
        "PlaybackScope{kind=$kind, " +
            "paths=${paths.size}, " +
            "genres=${genres.size}, " +
            "artists=${artists.size}, " +
            "albums=${albums.size}}"

    // ========================================================================
    // Companion — Factories and Deserialization
    // ========================================================================

    companion object {

        @JvmField
        val ALL_SONGS: PlaybackScope = PlaybackScope(
            Kind.ALL_SONGS,
            emptySet(),
            emptySet(),
            emptySet(),
            emptySet()
        )

        @JvmStatic
        fun favorites(): PlaybackScope = PlaybackScope(
            Kind.FAVORITES,
            emptySet(),
            emptySet(),
            emptySet(),
            emptySet()
        )

        @JvmStatic
        fun looseTracks(): PlaybackScope = PlaybackScope(
            Kind.LOOSE_TRACKS,
            emptySet(),
            emptySet(),
            emptySet(),
            emptySet()
        )

        @JvmStatic
        fun folders(folderPaths: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_FOLDERS,
                folderPaths,
                emptySet(),
                emptySet(),
                emptySet()
            )

        @JvmStatic
        fun genres(genreNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_GENRES,
                emptySet(),
                genreNames,
                emptySet(),
                emptySet()
            )

        @JvmStatic
        fun artists(artistNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_ARTISTS,
                emptySet(),
                emptySet(),
                artistNames,
                emptySet()
            )

        @JvmStatic
        fun albums(albumNames: Set<String>): PlaybackScope =
            PlaybackScope(
                Kind.SPECIFIC_ALBUMS,
                emptySet(),
                emptySet(),
                emptySet(),
                albumNames
            )

        @JvmStatic
        fun deserialize(serialized: String?): PlaybackScope {
            if (serialized == null || serialized.isEmpty()) {
                return ALL_SONGS
            }
            return try {
                val jsonObject = JSONObject(serialized)
                val kind = try {
                    Kind.valueOf(
                        jsonObject.optString("kind", "ALL_SONGS")
                    )
                } catch (exception: IllegalArgumentException) {
                    Kind.ALL_SONGS
                }
                val paths = toStringSet(
                    jsonObject.optJSONArray("paths")
                )
                val genres = toStringSet(
                    jsonObject.optJSONArray("genres")
                )
                val artists = toStringSet(
                    jsonObject.optJSONArray("artists")
                )
                val albums = toStringSet(
                    jsonObject.optJSONArray("albums")
                )
                PlaybackScope(kind, paths, genres, artists, albums)
            } catch (exception: Exception) {
                ALL_SONGS
            }
        }

        private fun toStringSet(array: JSONArray?): Set<String> {
            val result: MutableSet<String> = HashSet()
            if (array == null) {
                return result
            }
            for (index in 0 until array.length()) {
                val value: String? = array.optString(index, null)
                if (value != null) {
                    result.add(value)
                }
            }
            return result
        }
    }
}