// MusicLibrary.kt
package com.ark.llama

import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import androidx.annotation.WorkerThread
import com.ark.llama.event.Bus
import com.ark.llama.event.PlaylistEvent
import java.io.File
import java.util.ArrayList
import java.util.Collections
import java.util.Comparator
import java.util.HashSet
import java.util.Set
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * Owns the in-memory song list and the set of selected folder URIs,
 * and scans folders through [MediaStore] to populate the list.
 *
 * <h3>State Ownership</h3>
 * <p>[refreshCache] is the sole writer of the in-memory song list.
 * Every other public API reads from that list. Multiple instances
 * may coexist, one per component that reads song data, and the
 * database keeps them in agreement: the [PlaylistEvent] events that
 * every instance subscribes to converge on the same database state.</p>
 *
 * <h3>Lifecycle</h3>
 * <p>Construction is synchronous and cheap: folder URIs are read
 * from [SharedPreferences] on the calling thread, and the initial
 * database read plus loose-track merge is scheduled on the
 * single-thread executor.</p>
 *
 * <h3>EventBus</h3>
 * <p>[postSongAdded] posts [PlaylistEvent.SongAdded] once per song
 * during a progress-reporting scan, letting the playlist activity
 * render each discovered row incrementally rather than waiting for
 * the scan to finish.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Song list access is guarded by a [ReentrantReadWriteLock].
 * Loading state is tracked with an [AtomicBoolean], pending
 * listeners with an [AtomicReference], and folder URIs with a
 * synchronized set. Public list-returning methods return copies.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class MusicLibrary(context: Context) {

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mContext: Context = context
    private val mSelectedFolderUris: MutableSet<String> = HashSet()
    private val mSongDatabase: SongDatabase = SongDatabase.getInstance(context)
    private val mExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mIsShutdown: AtomicBoolean = AtomicBoolean(false)
    private val mSongsLock: ReentrantReadWriteLock = ReentrantReadWriteLock()
    private val mAllSongs: ArrayList<Song> = ArrayList()
    private val mLooseSongs: ArrayList<Song> = ArrayList()
    private val mIsLoading: AtomicBoolean = AtomicBoolean(false)
    private val mPendingListener: AtomicReference<OnSongsLoadedListener?> =
        AtomicReference(null)

    @Volatile
    private var mIsLoaded: Boolean = false

    init {
        CharacterMapper.init(context)
        loadSavedFolders()
        deleteLegacyCacheFile()

        mExecutor.execute {
            try {
                loadSongsFromDatabaseSync()
                loadLooseSongs()
                mergeLooseSongs()
                if (!mAllSongs.isEmpty()) {
                    mIsLoaded = true
                }
            } catch (exception: Exception) {
                Log.e(TAG, "Initial library load failed", exception)
            }
        }
    }

    // ========================================================================
    // Listener interfaces
    // ========================================================================

    interface OnSongsLoadedListener {
        fun onSongsLoaded(songs: ArrayList<Song>)
        fun onLoadingError(error: String)
    }

    interface UpdateProgressListener {
        fun onProgress(current: Int, total: Int, message: String)
        fun onComplete()
        fun onError(error: String)
    }

    interface LoadProgressListener {
        fun onLoadProgress(currentCount: Int)
        fun onLoadComplete(songs: ArrayList<Song>)
        fun onLoadError(error: String)
    }

    // ========================================================================
    // Initialization helpers
    // ========================================================================

    private fun deleteLegacyCacheFile() {
        try {
            val cacheFile = File(mContext.filesDir, "playlist_cache.ser")
            if (cacheFile.exists()) {
                cacheFile.delete()
                Log.d(TAG, "Deleted legacy cache file")
            }
        } catch (exception: SecurityException) {
            Log.w(TAG, "Permission denied deleting cache file")
        }
    }

    private fun loadSavedFolders() {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        val savedFolders = preferences.getStringSet(KEY_FOLDERS, null)
        if (savedFolders != null) {
            mSelectedFolderUris.addAll(savedFolders)
            Log.d(TAG, "Loaded ${savedFolders.size} saved folders")
        }
    }

    private fun saveFolders() {
        val preferences = mContext.getSharedPreferences(
            PREFS_NAME, Context.MODE_PRIVATE
        )
        preferences.edit().putStringSet(
            KEY_FOLDERS, mSelectedFolderUris
        ).apply()
        Log.d(TAG, "Saved ${mSelectedFolderUris.size} folders")
    }

    @WorkerThread
    private fun loadSongsFromDatabaseSync() {
        mSongsLock.writeLock().lock()
        try {
            mAllSongs.clear()
            val cachedSongs = mSongDatabase.allSongs
            if (cachedSongs != null && cachedSongs.isNotEmpty()) {
                mAllSongs.addAll(cachedSongs)
                Log.d(TAG, "Loaded ${cachedSongs.size} songs from database")
            }
        } finally {
            mSongsLock.writeLock().unlock()
        }
    }

    private fun loadLooseSongs() {
        synchronized(mLooseSongs) {
            mLooseSongs.clear()
            val allLooseSongs = mSongDatabase.looseSongs
            for (song in allLooseSongs) {
                if (song != null && song.path.isNotEmpty()) {
                    val file = File(song.path)
                    if (file.exists() && file.canRead()) {
                        mLooseSongs.add(song)
                    } else {
                        mSongDatabase.removeLooseSong(song.path)
                        Log.d(TAG, "Removed missing loose song: ${song.path}")
                    }
                }
            }
            Log.d(TAG, "Loaded ${mLooseSongs.size} valid loose songs")
        }
    }

    private fun mergeLooseSongs() {
        synchronized(mLooseSongs) {
            mSongsLock.writeLock().lock()
            try {
                var addedCount = 0
                for (looseSong in mLooseSongs) {
                    if (looseSong == null || looseSong.path.isEmpty()) continue

                    var alreadyExists = false
                    for (existingSong in mAllSongs) {
                        if (existingSong != null &&
                            looseSong.path == existingSong.path
                        ) {
                            alreadyExists = true
                            break
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(looseSong)
                        addedCount++
                    }
                }
                if (addedCount > 0) {
                    Log.d(TAG, "Merged $addedCount loose songs into main list")
                }
            } finally {
                mSongsLock.writeLock().unlock()
            }
        }
    }

    // ========================================================================
    // Public API — Folder management
    // ========================================================================

    fun getSelectedFolders(): Set<String> = synchronized(mSelectedFolderUris) {
        HashSet(mSelectedFolderUris)
    }

    fun addFolder(uri: String) {
        synchronized(mSelectedFolderUris) {
            mSelectedFolderUris.add(uri)
            Log.d(TAG, "Added folder: $uri")
        }
        saveFolders()
    }

    fun removeFolder(uri: String) {
        synchronized(mSelectedFolderUris) {
            mSelectedFolderUris.remove(uri)
            Log.d(TAG, "Removed folder: $uri")
        }
        saveFolders()
    }

    fun getFolderCount(): Int = synchronized(mSelectedFolderUris) {
        mSelectedFolderUris.size
    }

    // ========================================================================
    // Public API — Song management
    // ========================================================================

    fun refreshCache() {
        mSongsLock.writeLock().lock()
        try {
            val allLooseSongs = mSongDatabase.looseSongs
            val validLooseSongs = ArrayList<Song>()
            for (song in allLooseSongs) {
                if (song != null && song.path.isNotEmpty()) {
                    val file = File(song.path)
                    if (file.exists() && file.canRead()) {
                        validLooseSongs.add(song)
                    } else {
                        mSongDatabase.removeLooseSong(song.path)
                    }
                }
            }
            synchronized(mLooseSongs) {
                mLooseSongs.clear()
                mLooseSongs.addAll(validLooseSongs)
            }

            mAllSongs.clear()
            val freshSongs = mSongDatabase.allSongs
            if (freshSongs != null) {
                mAllSongs.addAll(freshSongs)
            }

            var addedCount = 0
            synchronized(mLooseSongs) {
                for (looseSong in mLooseSongs) {
                    if (looseSong == null || looseSong.path.isEmpty()) continue
                    var alreadyExists = false
                    for (existingSong in mAllSongs) {
                        if (existingSong != null &&
                            looseSong.path == existingSong.path
                        ) {
                            alreadyExists = true
                            break
                        }
                    }
                    if (!alreadyExists) {
                        mAllSongs.add(looseSong)
                        addedCount++
                    }
                }
            }

            mIsLoaded = true

            Log.d(TAG, "Cache refreshed: ${mAllSongs.size} songs, " +
                "${validLooseSongs.size} loose ($addedCount merged)")
        } finally {
            mSongsLock.writeLock().unlock()
        }
    }

    fun invalidate() {
        mSongsLock.writeLock().lock()
        try {
            mAllSongs.clear()
            synchronized(mLooseSongs) {
                mLooseSongs.clear()
            }
            mIsLoaded = false
        } finally {
            mSongsLock.writeLock().unlock()
        }

        synchronized(mSelectedFolderUris) {
            mSelectedFolderUris.clear()
            loadSavedFolders()
        }

        Log.d(TAG, "Library invalidated: ${mSelectedFolderUris.size} " +
            "folders remain in selection")
    }

    fun removeMissingFiles(currentSongs: ArrayList<Song>?) {
        if (currentSongs == null || currentSongs.isEmpty()) return

        val validSongs = ArrayList<Song>()
        for (song in currentSongs) {
            if (song != null && song.path.isNotEmpty()) {
                val file = File(song.path)
                if (file.exists() && file.canRead()) {
                    validSongs.add(song)
                } else {
                    Log.d(TAG, "Removing missing file: ${song.path}")
                }
            }
        }

        if (validSongs.size != currentSongs.size) {
            mSongDatabase.clearCache()
            if (validSongs.isNotEmpty()) {
                mSongDatabase.insertSongsBatch(validSongs)
            }
            refreshCache()
        }
    }

    @WorkerThread
    fun clearPlaylistCache() {
        mSongDatabase.clearCache()
        Log.d(TAG, "Cleared playlist cache")
    }

    fun getAllSongs(): ArrayList<Song> {
        mSongsLock.readLock().lock()
        try {
            return ArrayList(mAllSongs)
        } finally {
            mSongsLock.readLock().unlock()
        }
    }

    fun getSongCount(): Int {
        mSongsLock.readLock().lock()
        try {
            return mAllSongs.size
        } finally {
            mSongsLock.readLock().unlock()
        }
    }

    fun searchSongs(query: String): ArrayList<Song> {
        if (query.isEmpty()) {
            return getAllSongs()
        }

        val results = ArrayList<Song>()
        val lowerQuery = query.lowercase().trim()

        mSongsLock.readLock().lock()
        try {
            for (song in mAllSongs) {
                if (song != null) {
                    val title = song.title
                    val artist = song.artist
                    val album = song.album
                    val genre = song.genre
                    if (title.lowercase().contains(lowerQuery) ||
                        artist.lowercase().contains(lowerQuery) ||
                        album.lowercase().contains(lowerQuery) ||
                        genre.lowercase().contains(lowerQuery)
                    ) {
                        results.add(song)
                    }
                }
            }
        } finally {
            mSongsLock.readLock().unlock()
        }

        Log.d(TAG, "Search for '$query' returned ${results.size} results")
        return results
    }

    fun updateSongGenre(songPath: String, genre: String): Boolean {
        mSongsLock.writeLock().lock()
        try {
            for (song in mAllSongs) {
                if (song != null && songPath == song.path) {
                    song.setGenre(genre)
                    Log.d(TAG, "Updated in-memory genre for: " +
                        "${song.title} -> $genre")
                    return true
                }
            }
        } finally {
            mSongsLock.writeLock().unlock()
        }

        synchronized(mLooseSongs) {
            for (song in mLooseSongs) {
                if (song != null && songPath == song.path) {
                    song.setGenre(genre)
                    Log.d(TAG, "Updated loose song genre for: " +
                        "${song.title} -> $genre")
                    return true
                }
            }
        }

        Log.w(TAG, "Song not found for genre update: $songPath")
        return false
    }

    // ========================================================================
    // Public API — Asynchronous loading
    // ========================================================================

    fun loadAllSongsAsync(listener: OnSongsLoadedListener?) {
        if (mIsShutdown.get()) return

        if (mIsLoaded && songCount > 0) {
            if (listener != null) {
                Handler(Looper.getMainLooper()).post {
                    if (!mIsShutdown.get()) {
                        listener.onSongsLoaded(getAllSongs())
                    }
                }
            }
            return
        }

        if (mIsLoading.get()) {
            mPendingListener.set(listener)
            return
        }

        mIsLoading.set(true)
        mPendingListener.set(listener)

        val capturedListener = listener
        mExecutor.execute {
            try {
                loadAllSongsInternal()
                mIsLoaded = true

                if (capturedListener != null) {
                    val finalSongs = getAllSongs()
                    Handler(Looper.getMainLooper()).post {
                        if (!mIsShutdown.get()) {
                            capturedListener.onSongsLoaded(finalSongs)
                        }
                    }
                }
            } catch (exception: Exception) {
                Log.e(TAG, "Error loading songs", exception)
                if (capturedListener != null) {
                    Handler(Looper.getMainLooper()).post {
                        if (mIsShutdown.get()) return@post
                        capturedListener.onLoadingError(
                            exception.message ?: "Unknown error"
                        )
                    }
                }
            } finally {
                mIsLoading.set(false)
                if (mPendingListener.get() === capturedListener) {
                    mPendingListener.set(null)
                }
            }
        }
    }

    fun loadAllSongsWithProgress(listener: LoadProgressListener?) {
        if (mIsShutdown.get()) return

        if (mIsLoaded && songCount > 0) {
            if (listener != null) {
                Handler(Looper.getMainLooper()).post {
                    if (!mIsShutdown.get()) {
                        listener.onLoadComplete(getAllSongs())
                    }
                }
            }
            return
        }

        if (mIsLoading.get()) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!mIsShutdown.get()) {
                    loadAllSongsWithProgress(listener)
                }
            }, 200)
            return
        }

        mIsLoading.set(true)

        mExecutor.execute {
            try {
                val newSongList = ArrayList<Song>()

                if (mSelectedFolderUris.isEmpty()) {
                    loadLooseSongs()
                    synchronized(mLooseSongs) {
                        newSongList.addAll(mLooseSongs)
                    }

                    Handler(Looper.getMainLooper()).post {
                        if (mIsShutdown.get()) {
                            mIsLoading.set(false)
                            return@post
                        }
                        mSongsLock.writeLock().lock()
                        try {
                            mAllSongs.clear()
                            mAllSongs.addAll(newSongList)
                            mergeLooseSongs()
                        } finally {
                            mSongsLock.writeLock().unlock()
                        }
                        mIsLoaded = true
                        listener?.onLoadComplete(newSongList)
                        mIsLoading.set(false)
                    }
                    return@execute
                }

                val currentCount = AtomicInteger(0)
                for (folderUriString in mSelectedFolderUris) {
                    scanFolderWithUriProgress(
                        Uri.parse(folderUriString),
                        newSongList,
                        currentCount,
                        listener
                    )
                }

                if (newSongList.isNotEmpty()) {
                    Collections.sort(newSongList, Comparator<Song> { a, b ->
                        val firstTitle = a.title
                        val secondTitle = b.title
                        firstTitle.compareTo(secondTitle, ignoreCase = true)
                    })
                }

                Handler(Looper.getMainLooper()).post {
                    if (mIsShutdown.get()) {
                        mIsLoading.set(false)
                        return@post
                    }
                    mSongsLock.writeLock().lock()
                    try {
                        mAllSongs.clear()
                        mAllSongs.addAll(newSongList)
                        mergeLooseSongs()
                    } finally {
                        mSongsLock.writeLock().unlock()
                    }
                    mIsLoaded = true
                    listener?.onLoadComplete(newSongList)
                    mIsLoading.set(false)
                }
            } catch (exception: Exception) {
                Log.e(TAG, "Error loading songs with progress", exception)
                Handler(Looper.getMainLooper()).post {
                    if (mIsShutdown.get()) {
                        mIsLoading.set(false)
                        return@post
                    }
                    listener?.onLoadError(exception.message ?: "Unknown error")
                    mIsLoading.set(false)
                }
            }
        }
    }

    // ========================================================================
    // Internal loading
    // ========================================================================

    private fun loadAllSongsInternal() {
        mSongsLock.writeLock().lock()
        try {
            mAllSongs.clear()
        } finally {
            mSongsLock.writeLock().unlock()
        }

        if (mSelectedFolderUris.isEmpty()) {
            loadLooseSongs()
            synchronized(mLooseSongs) {
                mSongsLock.writeLock().lock()
                try {
                    mAllSongs.addAll(mLooseSongs)
                } finally {
                    mSongsLock.writeLock().unlock()
                }
            }
            return
        }

        for (folderUriString in mSelectedFolderUris) {
            scanFolderWithUriOptimized(Uri.parse(folderUriString))
        }

        mSongsLock.writeLock().lock()
        try {
            if (mAllSongs.isNotEmpty()) {
                Collections.sort(mAllSongs, Comparator<Song> { a, b ->
                    a.title.compareTo(b.title, ignoreCase = true)
                })
            }
        } finally {
            mSongsLock.writeLock().unlock()
        }

        mergeLooseSongs()
        Log.d(TAG, "Internal load complete: $songCount songs")
    }

    private fun scanFolderWithUriOptimized(folderUri: Uri) {
        try {
            val folderPath = getFolderPathFromUri(folderUri)
            if (folderPath != null) {
                queryMediaStoreWithCache(folderPath)
            } else {
                val folderName = getFolderNameFromUri(folderUri)
                if (folderName != null) {
                    queryMediaStoreByNameWithCache(folderName)
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "scan optimized error", exception)
        }
    }

    private fun queryMediaStoreWithCache(folderPath: String) {
        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val normalizedPath =
            if (folderPath.endsWith("/")) folderPath else "$folderPath/"
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        val newSongs = ArrayList<Song>()

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("$normalizedPath%"),
                null
            )

            if (cursor != null && cursor.moveToFirst()) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                if (pathColumn == -1) return

                do {
                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    try {
                        val retriever = android.media.MediaMetadataRetriever()
                        retriever.setDataSource(filePath)
                        retriever.release()
                    } catch (exception: Exception) {
                        continue
                    }

                    val duration: Long =
                        if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L
                    val cachedSong = mSongDatabase.getSong(filePath)

                    mSongsLock.writeLock().lock()
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong)
                        } else {
                            val newSong = Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath,
                                duration,
                                null
                            )
                            mAllSongs.add(newSong)
                            newSongs.add(newSong)
                        }
                    } finally {
                        mSongsLock.writeLock().unlock()
                    }
                } while (cursor.moveToNext())

                if (newSongs.isNotEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs)
                    Log.d(TAG, "Cached ${newSongs.size} new songs from $folderPath")
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "queryWithCache error", exception)
        } finally {
            cursor?.close()
        }
    }

    private fun queryMediaStoreByNameWithCache(folderName: String) {
        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        val newSongs = ArrayList<Song>()

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("%/$folderName/%"),
                null
            )

            if (cursor != null && cursor.moveToFirst()) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                if (pathColumn == -1) return

                do {
                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    try {
                        val retriever = android.media.MediaMetadataRetriever()
                        retriever.setDataSource(filePath)
                        retriever.release()
                    } catch (exception: Exception) {
                        continue
                    }

                    val duration: Long =
                        if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L
                    val cachedSong = mSongDatabase.getSong(filePath)

                    mSongsLock.writeLock().lock()
                    try {
                        if (cachedSong != null) {
                            mAllSongs.add(cachedSong)
                        } else {
                            val newSong = Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath,
                                duration,
                                null
                            )
                            mAllSongs.add(newSong)
                            newSongs.add(newSong)
                        }
                    } finally {
                        mSongsLock.writeLock().unlock()
                    }
                } while (cursor.moveToNext())

                if (newSongs.isNotEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs)
                    Log.d(TAG, "Cached ${newSongs.size} new songs from folder $folderName")
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "queryByNameWithCache error", exception)
        } finally {
            cursor?.close()
        }
    }

    private fun scanFolderWithUriProgress(
        folderUri: Uri,
        targetList: ArrayList<Song>,
        currentCount: AtomicInteger,
        listener: LoadProgressListener?
    ) {
        try {
            val folderPath = getFolderPathFromUri(folderUri)
            if (folderPath != null) {
                queryMediaStoreWithProgress(folderPath, targetList, currentCount, listener)
            } else {
                val folderName = getFolderNameFromUri(folderUri)
                if (folderName != null) {
                    queryMediaStoreByNameWithProgress(
                        folderName, targetList, currentCount, listener
                    )
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "scan progress error", exception)
        }
    }

    private fun queryMediaStoreWithProgress(
        folderPath: String,
        targetList: ArrayList<Song>,
        currentCount: AtomicInteger,
        listener: LoadProgressListener?
    ) {
        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val normalizedPath =
            if (folderPath.endsWith("/")) folderPath else "$folderPath/"
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        val mainHandler = Handler(Looper.getMainLooper())
        val lastReportedCount = intArrayOf(0)
        val lastReportedTime = longArrayOf(0L)

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("$normalizedPath%"),
                null
            )

            if (cursor != null && cursor.moveToFirst()) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                if (pathColumn == -1) return

                do {
                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    try {
                        val retriever = android.media.MediaMetadataRetriever()
                        retriever.setDataSource(filePath)
                        retriever.release()
                    } catch (exception: Exception) {
                        continue
                    }

                    val duration: Long =
                        if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L
                    val cachedSong = mSongDatabase.getSong(filePath)
                    val finalSong: Song

                    if (cachedSong != null) {
                        finalSong = cachedSong
                    } else {
                        finalSong = Song(
                            CharacterMapper.getTitle(filePath),
                            CharacterMapper.getArtist(filePath),
                            CharacterMapper.getAlbum(filePath),
                            CharacterMapper.getGenre(filePath),
                            filePath,
                            duration,
                            null
                        )
                    }

                    targetList.add(finalSong)
                    val currentValue = currentCount.incrementAndGet()

                    val currentTime = SystemClock.elapsedRealtime()
                    if (listener != null &&
                        (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD ||
                            currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)
                    ) {
                        lastReportedCount[0] = currentValue
                        lastReportedTime[0] = currentTime
                        mainHandler.post {
                            if (!mIsShutdown.get()) {
                                listener.onLoadProgress(currentValue)
                            }
                        }
                        if (!mIsShutdown.get()) {
                            postSongAdded(finalSong, currentValue)
                        }
                    }
                } while (cursor.moveToNext())

                val finalCount = currentCount.get()
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post {
                        if (!mIsShutdown.get()) {
                            listener.onLoadProgress(finalCount)
                        }
                    }
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "queryWithProgress error", exception)
        } finally {
            cursor?.close()
        }
    }

    private fun queryMediaStoreByNameWithProgress(
        folderName: String,
        targetList: ArrayList<Song>,
        currentCount: AtomicInteger,
        listener: LoadProgressListener?
    ) {
        val resolver = mContext.contentResolver
        val mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = "${MediaStore.Audio.Media.DATA} LIKE ? AND " +
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        val mainHandler = Handler(Looper.getMainLooper())
        val lastReportedCount = intArrayOf(0)
        val lastReportedTime = longArrayOf(0L)

        try {
            cursor = resolver.query(
                mediaUri,
                arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION
                ),
                selection,
                arrayOf("%/$folderName/%"),
                null
            )

            if (cursor != null && cursor.moveToFirst()) {
                val pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                if (pathColumn == -1) return

                do {
                    val filePath = cursor.getString(pathColumn)
                    if (filePath.isNullOrEmpty()) continue

                    try {
                        val retriever = android.media.MediaMetadataRetriever()
                        retriever.setDataSource(filePath)
                        retriever.release()
                    } catch (exception: Exception) {
                        continue
                    }

                    val duration: Long =
                        if (durationColumn != -1L) cursor.getLong(durationColumn) else 0L
                    val cachedSong = mSongDatabase.getSong(filePath)
                    val finalSong: Song

                    if (cachedSong != null) {
                        finalSong = cachedSong
                    } else {
                        finalSong = Song(
                            CharacterMapper.getTitle(filePath),
                            CharacterMapper.getArtist(filePath),
                            CharacterMapper.getAlbum(filePath),
                            CharacterMapper.getGenre(filePath),
                            filePath,
                            duration,
                            null
                        )
                    }

                    targetList.add(finalSong)
                    val currentValue = currentCount.incrementAndGet()

                    val currentTime = SystemClock.elapsedRealtime()
                    if (listener != null &&
                        (currentValue - lastReportedCount[0] >= UI_UPDATE_THRESHOLD ||
                            currentTime - lastReportedTime[0] >= UI_UPDATE_TIME_MS)
                    ) {
                        lastReportedCount[0] = currentValue
                        lastReportedTime[0] = currentTime
                        mainHandler.post {
                            if (!mIsShutdown.get()) {
                                listener.onLoadProgress(currentValue)
                            }
                        }
                        if (!mIsShutdown.get()) {
                            postSongAdded(finalSong, currentValue)
                        }
                    }
                } while (cursor.moveToNext())

                val finalCount = currentCount.get()
                if (listener != null && finalCount > lastReportedCount[0]) {
                    mainHandler.post {
                        if (!mIsShutdown.get()) {
                            listener.onLoadProgress(finalCount)
                        }
                    }
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "queryByNameWithProgress error", exception)
        } finally {
            cursor?.close()
        }
    }

    private fun postSongAdded(song: Song?, currentCount: Int) {
        if (song == null) return
        Bus.post(
            PlaylistEvent.SongAdded(
                song.path,
                song.title,
                song.artist,
                song.album,
                song.genre,
                song.duration,
                currentCount
            )
        )
    }

    fun shutdown() {
        if (mIsShutdown.compareAndSet(false, true) &&
            !mExecutor.isShutdown
        ) {
            mPendingListener.set(null)
            mExecutor.shutdown()
            Log.d(TAG, "Executor shutdown requested")
        }
    }

    // ========================================================================
    // URI helpers
    // ========================================================================

    private fun getFolderPathFromUri(uri: Uri): String? {
        val uriString = uri.toString()
        if (uriString.contains("primary:")) {
            try {
                val startIndex = uriString.indexOf("primary:") + 8
                var subPath = uriString.substring(startIndex)
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/")
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6)
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10)
                }
                var path = "/storage/emulated/0/$subPath"
                path = Uri.decode(path)
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length - 1)
                }
                return path
            } catch (exception: Exception) {
                Log.e(TAG, "Failed to get folder path from URI", exception)
                return null
            }
        }
        return null
    }

    private fun getFolderNameFromUri(uri: Uri): String? {
        var folderName: String? = null
        var cursor: Cursor? = null
        try {
            cursor = mContext.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val nameColumn = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameColumn != -1) {
                    folderName = cursor.getString(nameColumn)
                }
            }
        } catch (exception: Exception) {
            Log.e(TAG, "getFolderName error", exception)
        } finally {
            cursor?.close()
        }

        if (folderName == null) {
            var segment = uri.lastPathSegment
            if (segment != null && segment.contains(":")) {
                segment = segment.substring(segment.indexOf(":") + 1)
            }
            folderName = segment
        }

        return folderName?.let { CharacterMapper.cleanString(it) }
    }

    // ========================================================================
    // Companion
    // ========================================================================

    companion object {
        private const val TAG = "MusicLibrary"
        private const val PREFS_NAME = "LlamaPrefs"
        private const val KEY_FOLDERS = "selected_folders_uris"

        private const val UI_UPDATE_THRESHOLD = 10
        private const val UI_UPDATE_TIME_MS = 500L
    }
}