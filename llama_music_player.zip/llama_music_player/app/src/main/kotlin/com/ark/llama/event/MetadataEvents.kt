// MetadataEvents.kt
package com.ark.llama.event

/**
 * Metadata-surface events posted on the process EventBus.
 *
 * <p>Producer: [com.ark.llama.MetadataEditor] posts [Updated] after
 * every successful write; [com.ark.llama.PlaylistManager] posts
 * [GenreUpdated] on every genre-load lifecycle tick.</p>
 *
 * <p>Both events are plain data carriers with no behaviour. The
 * sealed interface lets a subscriber name a handler for
 * "any metadata event" without enumerating concrete types, and
 * reserves the namespace for future metadata events.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.5.0
 */
sealed interface MetadataEvent {

    /**
     * A song's metadata has been successfully written.
     *
     * <p>Carries what the writer was asked to write, not what a
     * subsequent re-read happens to return. A re-read is
     * verification only; when it fails, the submitted values are
     * still the ones the event carries.</p>
     *
     * <p>Consumers that receive this event refresh their local copy
     * of the song. The player activity refreshes the metadata cache,
     * the playlist activity replaces the row, and the service
     * updates its in-memory playlist entry.</p>
     *
     * @property songPath Path of the edited song, or null when the
     *        editor only resolved a URI
     * @property songUri Document URI of the edited song, or null
     * @property title New title, or null when unchanged
     * @property artist New artist, or null when unchanged
     * @property album New album, or null when unchanged
     * @property genre New genre, or null when unchanged
     * @property hasAlbumArt True when the announcement carries art
     * @property albumArtRemoved True when the edit removed the art
     * @property albumArtBytes New album art bytes, or null
     */
    data class Updated(
        val songPath: String?,
        val songUri: String?,
        val title: String?,
        val artist: String?,
        val album: String?,
        val genre: String?,
        val hasAlbumArt: Boolean,
        val albumArtRemoved: Boolean,
        val albumArtBytes: ByteArray?
    ) : MetadataEvent {

        /**
         * Equality is defined over every field.
         *
         * <p>Manual override is required because [albumArtBytes] is
         * an array and the compiler-generated equals uses reference
         * comparison for arrays. Without this override, two events
         * with identical byte content compare unequal and diffing
         * consumers mis-fire.</p>
         */
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Updated) return false
            return songPath == other.songPath &&
                songUri == other.songUri &&
                title == other.title &&
                artist == other.artist &&
                album == other.album &&
                genre == other.genre &&
                hasAlbumArt == other.hasAlbumArt &&
                albumArtRemoved == other.albumArtRemoved &&
                albumArtBytes.contentEquals(other.albumArtBytes)
        }

        /**
         * Hash code consistent with [equals]. Uses
         * [ByteArray.contentHashCode] for the album art bytes so
         * equal arrays produce equal hashes.
         */
        override fun hashCode(): Int {
            var result = songPath?.hashCode() ?: 0
            result = 31 * result + (songUri?.hashCode() ?: 0)
            result = 31 * result + (title?.hashCode() ?: 0)
            result = 31 * result + (artist?.hashCode() ?: 0)
            result = 31 * result + (album?.hashCode() ?: 0)
            result = 31 * result + (genre?.hashCode() ?: 0)
            result = 31 * result + hasAlbumArt.hashCode()
            result = 31 * result + albumArtRemoved.hashCode()
            result = 31 * result + (albumArtBytes?.contentHashCode() ?: 0)
            return result
        }
    }

    /**
     * A genre-loading lifecycle tick.
     *
     * <p>Three statuses are emitted, in order:</p>
     * <ul>
     *   <li>{@code "START"} — the pass is beginning. Carries
     *       {@code total} and zero {@code current}.</li>
     *   <li>{@code "UPDATE"} — a single song's genre was resolved.
     *       Carries {@code songPath}, the new {@code genre}, and the
     *       running count.</li>
     *   <li>{@code "COMPLETE"} — the pass is finished. Carries the
     *       final counts; consumers clear their loading flag.</li>
     * </ul>
     *
     * @property status One of "START", "UPDATE", or "COMPLETE"
     * @property songPath Path of the song whose genre changed, or null
     * @property genre New genre value, or null
     * @property current Number of songs processed so far
     * @property total Total number of songs to process
     */
    data class GenreUpdated(
        val status: String,
        val songPath: String?,
        val genre: String?,
        val current: Int,
        val total: Int
    ) : MetadataEvent
}