// PlaybackScopeDialog.kt
package com.ark.llama

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList
import java.util.HashSet
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Presents the seven scope modes as a single flat list and reports
 * the user's selection through [OnScopeAppliedListener].
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.4.0
 */
class PlaybackScopeDialog(
    private val mContext: Context,
    private val mInitialScope: PlaybackScope,
    private val mFolderItems: List<FolderAdapter.FolderItem>,
    private val mListener: OnScopeAppliedListener?
) : Dialog(mContext, android.R.style.Theme_Black_NoTitleBar) {

    // ========================================================================
    // Constants
    // ========================================================================

    private val BACKGROUND_COLOR = "#121212"
    private val HEADER_BACKGROUND_COLOR = "#1A1A1A"
    private val SELECTED_BACKGROUND_COLOR = "#1E1E1E"
    private val TOUCH_HIGHLIGHT_COLOR = "#2A2A2A"
    private val TEXT_COLOR_LIGHT = "#C0C0C0"
    private val CLICK_DEBOUNCE_DELAY_MS = 500L
    private val DISMISS_DELAY_MS = 500L
    private val TOP_BAR_HEIGHT_DP = 64
    private val HEADER_BAR_HEIGHT_DP = 40
    private val BUTTON_HEIGHT_DP = 36
    private val PADDING_STANDARD_DP = 16
    private val HEADER_PADDING_HORIZONTAL_DP = 16
    private val HEADER_PADDING_VERTICAL_DP = 4
    private val HEADER_COUNT_MARGIN_START_DP = 8
    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f

    // ========================================================================
    // Row model
    // ========================================================================

    private class Row(
        @JvmField val type: Int,
        @JvmField val kind: PlaybackScope.Kind,
        @JvmField val value: String?,
        @JvmField val label: String
    ) {
        companion object {
            const val TYPE_MODE = 0
            const val TYPE_FILTER = 1

            fun mode(kind: PlaybackScope.Kind, label: String) = Row(TYPE_MODE, kind, null, label)
            fun filter(kind: PlaybackScope.Kind, value: String, label: String) =
                Row(TYPE_FILTER, kind, value, label)
        }
    }

    private class FolderEntry(@JvmField val path: String, @JvmField val displayName: String)

    interface OnScopeAppliedListener {
        fun onScopeApplied(scope: PlaybackScope)
    }

    // ========================================================================
    // Instance state
    // ========================================================================

    private val mLoader: ExecutorService = Executors.newSingleThreadExecutor()
    private val mMain = Handler(Looper.getMainLooper())
    private lateinit var mThemeManager: ThemeManager
    private lateinit var mThemeHelper: ThemeHelper

    private var mRecyclerView: RecyclerView? = null
    private var mHeaderText: TextView? = null
    private var mCountText: TextView? = null
    private var mAdapter: ScopeAdapter? = null

    private val mRows = ArrayList<Row>()
    private val mFolderEntries = ArrayList<FolderEntry>()
    private val mGenreValues = ArrayList<String>()
    private val mArtistValues = ArrayList<String>()
    private val mAlbumValues = ArrayList<String>()

    private val mSelectedPaths = HashSet<String>()
    private val mSelectedGenres = HashSet<String>()
    private val mSelectedArtists = HashSet<String>()
    private val mSelectedAlbums = HashSet<String>()

    @Volatile private var mAllSongs: ArrayList<Song>? = null
    @Volatile private var mLooseTrackPaths: Set<String>? = null

    private var mSelectedKind: PlaybackScope.Kind
    private var mFilterExpanded: Boolean
    private var mLastApplyTime = 0L
    private var mLastCancelTime = 0L
    private var mApplyButton: Button? = null
    private var mApplyInProgress = false
    private var mPendingCommit: Runnable? = null

    init {
        mThemeManager = ThemeManager.getInstance(mContext)
        mThemeHelper = ThemeHelper.getInstance(mContext)
        mSelectedKind = mInitialScope.kind
        mFilterExpanded = supportsFilters(mSelectedKind)
        mSelectedPaths.addAll(mInitialScope.paths)
        mSelectedGenres.addAll(mInitialScope.genres)
        mSelectedArtists.addAll(mInitialScope.artists)
        mSelectedAlbums.addAll(mInitialScope.albums)
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(buildContentView())
        window?.let { configureWindow(it) }
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor())
        populateFolderEntries()
        rebuildRows()
        loadDynamicFilterLists()
        updateApplyEnabled()
        forceRedraw()
    }

    override fun dismiss() {
        super.dismiss()
        mMain.removeCallbacksAndMessages(null)
        mPendingCommit = null
        mApplyInProgress = false
        if (!mLoader.isShutdown) mLoader.shutdownNow()
    }

    private fun getLocaleContext(): Context = try {
        LanguageManager.getInstance(mContext).getLocalizedContext()
    } catch (e: Exception) {
        Log.w(TAG, "Failed to obtain localized context", e); mContext
    }

    private fun configureWindow(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = Color.parseColor(BACKGROUND_COLOR)
            window.navigationBarColor = Color.parseColor(BACKGROUND_COLOR)
        }
        val params = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.MATCH_PARENT
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.setWindowAnimations(R.style.PlaybackScopeDialogAnimation)
    }

    // ========================================================================
    // Content construction
    // ========================================================================

    private fun buildContentView(): View {
        val root = LinearLayout(mContext).apply {
            orientation = LinearLayout.VERTICAL
        }
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(BACKGROUND_COLOR))
            cornerRadii = floatArrayOf(
                dpToPx(20).toFloat(), dpToPx(20).toFloat(),
                dpToPx(20).toFloat(), dpToPx(20).toFloat(),
                0f, 0f, 0f, 0f
            )
        }
        root.background = bg
        root.addView(buildTopBar())
        root.addView(buildHeader())

        val recycler = RecyclerView(mContext).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            layoutManager = LinearLayoutManager(mContext)
        }
        val divider = DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL)
        ContextCompat.getDrawable(mContext, R.drawable.divider_custom)?.let {
            divider.setDrawable(it)
        }
        recycler.addItemDecoration(divider)
        val adapter = ScopeAdapter()
        recycler.adapter = adapter
        EdgeScrollHelper.attach(recycler)
        mAdapter = adapter
        mRecyclerView = recycler
        root.addView(recycler)
        return root
    }

    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(TOP_BAR_HEIGHT_DP))
            setPadding(dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP),
                dpToPx(PADDING_STANDARD_DP), dpToPx(PADDING_STANDARD_DP))
            setBackgroundColor(Color.parseColor(BACKGROUND_COLOR))
        }

        val cancel = Button(mContext).apply {
            text = getLocaleContext().getString(R.string.action_cancel)
            textSize = 14f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            minHeight = 0; minWidth = 0; includeFontPadding = false; isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        }
        cancel.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - mLastCancelTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastCancelTime = now; dismiss()
            }
        }
        mThemeHelper.updateButton(cancel, true); animateButton(cancel)

        val title = TextView(mContext).apply {
            text = getLocaleContext().getString(R.string.scope_dialog_title)
            textSize = 14f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            gravity = Gravity.CENTER
            includeFontPadding = false; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                0, dpToPx(BUTTON_HEIGHT_DP), 1f).apply {
                marginStart = dpToPx(8); marginEnd = dpToPx(8)
            }
        }

        val apply = Button(mContext).apply {
            text = getLocaleContext().getString(R.string.action_apply)
            textSize = 14f; letterSpacing = 0.1f
            setBackgroundResource(R.drawable.button_border_selector)
            minHeight = 0; minWidth = 0; includeFontPadding = false; isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(BUTTON_HEIGHT_DP))
        }
        apply.setOnClickListener {
            if (mApplyInProgress) return@setOnClickListener
            if (!apply.isEnabled) return@setOnClickListener
            val now = SystemClock.elapsedRealtime()
            if (now - mLastApplyTime >= CLICK_DEBOUNCE_DELAY_MS) {
                mLastApplyTime = now
                commitAndDismiss()
            }
        }
        mApplyButton = apply
        mThemeHelper.updateButton(apply, true)
        animateButton(apply)

        bar.addView(cancel); bar.addView(title); bar.addView(apply)
        return bar
    }

    private fun animateButton(button: Button) {
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(ANIMATION_SCALE_DOWN)
                    .scaleY(ANIMATION_SCALE_DOWN)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                    .setDuration(ANIMATION_DURATION_MS.toLong()).start()
            }
            false
        }
    }

    private fun buildHeader(): LinearLayout {
        val header = LinearLayout(mContext).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(HEADER_BAR_HEIGHT_DP))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP),
                dpToPx(HEADER_PADDING_HORIZONTAL_DP), dpToPx(HEADER_PADDING_VERTICAL_DP))
            setBackgroundColor(Color.parseColor(HEADER_BACKGROUND_COLOR))
        }
        mHeaderText = TextView(mContext).apply {
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(mHeaderText)
        mCountText = TextView(mContext).apply {
            textSize = 12f; letterSpacing = 0.1f
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dpToPx(HEADER_COUNT_MARGIN_START_DP)
            }
        }
        header.addView(mCountText)
        return header
    }

    // ========================================================================
    // Rows
    // ========================================================================

    private fun rebuildRows() {
        mRows.clear()
        appendMode(PlaybackScope.Kind.ALL_SONGS, R.string.scope_dialog_option_all_songs)
        appendMode(PlaybackScope.Kind.FAVORITES, R.string.scope_dialog_option_favorites)
        appendMode(PlaybackScope.Kind.LOOSE_TRACKS, R.string.scope_dialog_option_loose_tracks)
        appendMode(PlaybackScope.Kind.SPECIFIC_FOLDERS, R.string.scope_dialog_option_specific_folders)
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_FOLDERS)
        appendMode(PlaybackScope.Kind.SPECIFIC_GENRES, R.string.scope_dialog_option_specific_genres)
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_GENRES)
        appendMode(PlaybackScope.Kind.SPECIFIC_ARTISTS, R.string.scope_dialog_option_specific_artists)
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_ARTISTS)
        appendMode(PlaybackScope.Kind.SPECIFIC_ALBUMS, R.string.scope_dialog_option_specific_albums)
        appendFiltersIf(PlaybackScope.Kind.SPECIFIC_ALBUMS)
        mAdapter?.notifyDataSetChanged()
        updateHeader()
    }

    private fun appendMode(kind: PlaybackScope.Kind, @StringRes stringRes: Int) {
        mRows.add(Row.mode(kind, getLocaleContext().getString(stringRes)))
    }

    private fun appendFiltersIf(kind: PlaybackScope.Kind) {
        if (mSelectedKind != kind || !mFilterExpanded) return
        when (kind) {
            PlaybackScope.Kind.SPECIFIC_FOLDERS ->
                for (entry in mFolderEntries)
                    mRows.add(Row.filter(kind, entry.path, entry.displayName))
            PlaybackScope.Kind.SPECIFIC_GENRES ->
                for (g in mGenreValues) mRows.add(Row.filter(kind, g, g))
            PlaybackScope.Kind.SPECIFIC_ARTISTS ->
                for (a in mArtistValues) mRows.add(Row.filter(kind, a, a))
            PlaybackScope.Kind.SPECIFIC_ALBUMS ->
                for (a in mAlbumValues) mRows.add(Row.filter(kind, a, a))
            else -> { }
        }
    }

    private fun updateHeader() {
        val header = mHeaderText ?: return
        val countText = mCountText ?: return
        val modeLabel = getLocaleContext().getString(modeLabelResource(mSelectedKind))
        header.text = "${getLocaleContext().getString(R.string.scope_dialog_mode_prefix)} $modeLabel"
        val count = computeScopeCount()
        if (count >= 0) {
            countText.text = getLocaleContext().resources.getQuantityString(
                R.plurals.song_count, count, count)
            countText.visibility = View.VISIBLE
        } else countText.visibility = View.GONE
    }

    private fun computeScopeCount(): Int {
        val songs = mAllSongs ?: return -1
        val loose = mLooseTrackPaths ?: return -1
        val scope = buildScope()
        var count = 0
        for (s in songs) if (scope.matches(s, loose)) count++
        return count
    }

    private fun modeLabelResource(kind: PlaybackScope.Kind): Int = when (kind) {
        PlaybackScope.Kind.ALL_SONGS -> R.string.scope_dialog_option_all_songs
        PlaybackScope.Kind.FAVORITES -> R.string.scope_dialog_option_favorites
        PlaybackScope.Kind.LOOSE_TRACKS -> R.string.scope_dialog_option_loose_tracks
        PlaybackScope.Kind.SPECIFIC_FOLDERS -> R.string.scope_dialog_option_specific_folders
        PlaybackScope.Kind.SPECIFIC_GENRES -> R.string.scope_dialog_option_specific_genres
        PlaybackScope.Kind.SPECIFIC_ARTISTS -> R.string.scope_dialog_option_specific_artists
        PlaybackScope.Kind.SPECIFIC_ALBUMS -> R.string.scope_dialog_option_specific_albums
    }

    private fun supportsFilters(kind: PlaybackScope.Kind): Boolean =
        kind == PlaybackScope.Kind.SPECIFIC_FOLDERS ||
            kind == PlaybackScope.Kind.SPECIFIC_GENRES ||
            kind == PlaybackScope.Kind.SPECIFIC_ARTISTS ||
            kind == PlaybackScope.Kind.SPECIFIC_ALBUMS

    // ========================================================================
    // Filter data
    // ========================================================================

    private fun populateFolderEntries() {
        mFolderEntries.clear()
        for (item in mFolderItems) {
            if (item == null || item.isLooseTracks) continue
            val path = try {
                StorageAccessHelper.getInstance(mContext)
                    .getFolderPathFromUri(Uri.parse(item.uriString))
            } catch (e: Exception) {
                Log.w(TAG, "resolveFolderPath failed for ${item.uriString}", e); null
            }
            if (!path.isNullOrEmpty()) mFolderEntries.add(FolderEntry(path, item.displayName))
        }
        mFolderEntries.sortWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.displayName })
    }

    private fun loadDynamicFilterLists() {
        mLoader.execute {
            val genres = HashSet<String>()
            val artists = HashSet<String>()
            val albums = HashSet<String>()
            val loosePaths = HashSet<String>()
            var songs: ArrayList<Song>? = null
            var failed = false
            try {
                songs = SongDatabase.getInstance(mContext).getAllSongs()
                for (song in songs) {
                    if (song == null) continue
                    val genre = song.genre
                    if (genre.isNotEmpty() && !CharacterMapper.isUnknownGenre(genre))
                        genres.add(genre)
                    val artist = song.artist
                    if (artist.isNotEmpty() && !CharacterMapper.isUnknownArtist(artist))
                        artists.add(artist)
                    val album = song.album
                    if (album.isNotEmpty() && !CharacterMapper.isUnknownAlbum(album))
                        albums.add(album)
                }
                for (loose in SongDatabase.getInstance(mContext).getLooseSongs()) {
                    if (loose.path.isNotEmpty()) loosePaths.add(loose.path)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to enumerate filter values", e); failed = true
            }
            val finalSongs = songs
            val finalLoose = loosePaths
            mMain.post {
                if (!isShowing) return@post
                if (failed) {
                    val content = findViewById<ViewGroup>(android.R.id.content)
                    if (content != null) {
                        ToastManager.showToastInView(
                            content,
                            getLocaleContext().getString(R.string.scope_dialog_load_error),
                            ToastManager.LENGTH_NORMAL
                        )
                    }
                    return@post
                }
                mAllSongs = finalSongs
                mLooseTrackPaths = finalLoose
                mGenreValues.clear(); mGenreValues.addAll(genres)
                mGenreValues.sortWith(String.CASE_INSENSITIVE_ORDER)
                mArtistValues.clear(); mArtistValues.addAll(artists)
                mArtistValues.sortWith(String.CASE_INSENSITIVE_ORDER)
                mAlbumValues.clear(); mAlbumValues.addAll(albums)
                mAlbumValues.sortWith(String.CASE_INSENSITIVE_ORDER)
                rebuildRows()
            }
        }
    }

    // ========================================================================
    // Selection
    // ========================================================================

    private fun onModeTapped(kind: PlaybackScope.Kind) {
        cancelPendingCommit()
        if (mSelectedKind == kind) {
            if (supportsFilters(kind)) mFilterExpanded = !mFilterExpanded
        } else {
            mSelectedKind = kind
            clearAllFilters()
            mFilterExpanded = supportsFilters(kind)
        }
        rebuildRows()
        updateApplyEnabled()
    }

    private fun onFilterToggled(kind: PlaybackScope.Kind, value: String) {
        cancelPendingCommit()
        val set = setFor(kind)
        if (set.contains(value)) set.remove(value) else set.add(value)
        mAdapter?.notifyDataSetChanged()
        updateHeader()
        updateApplyEnabled()
    }

    private fun cancelPendingCommit() {
        if (!mApplyInProgress) return
        mApplyInProgress = false
        mPendingCommit?.let { mMain.removeCallbacks(it); mPendingCommit = null }
        updateApplyEnabled()
    }

    private fun updateApplyEnabled() {
        val button = mApplyButton ?: return
        val changed = buildScope() != mInitialScope
        button.isEnabled = changed
        mThemeHelper.updateButton(button, changed)
    }

    private fun setFor(kind: PlaybackScope.Kind): MutableSet<String> = when (kind) {
        PlaybackScope.Kind.SPECIFIC_FOLDERS -> mSelectedPaths
        PlaybackScope.Kind.SPECIFIC_GENRES -> mSelectedGenres
        PlaybackScope.Kind.SPECIFIC_ARTISTS -> mSelectedArtists
        PlaybackScope.Kind.SPECIFIC_ALBUMS -> mSelectedAlbums
        else -> HashSet()
    }

    private fun clearAllFilters() {
        mSelectedPaths.clear(); mSelectedGenres.clear()
        mSelectedArtists.clear(); mSelectedAlbums.clear()
    }

    // ========================================================================
    // Commit
    // ========================================================================

    private fun commitAndDismiss() {
        mApplyInProgress = true
        mApplyButton?.isEnabled = false
        mApplyButton?.let { mThemeHelper.updateButton(it, false) }
        val scope = buildScope()
        val scopeLabel = getLocaleContext().getString(modeLabelResource(scope.kind))
        mPendingCommit = Runnable {
            mPendingCommit = null
            try {
                mListener?.onScopeApplied(scope)
                if (mContext is Activity) {
                    ToastManager.showToast(
                        mContext as Activity,
                        getLocaleContext().getString(
                            R.string.scope_toast_applied, scopeLabel),
                        ToastManager.LENGTH_NORMAL
                    )
                }
            } finally {
                dismiss()
            }
        }
        mMain.postDelayed(mPendingCommit!!, DISMISS_DELAY_MS)
    }

    private fun buildScope(): PlaybackScope = when (mSelectedKind) {
        PlaybackScope.Kind.FAVORITES -> PlaybackScope.favorites()
        PlaybackScope.Kind.LOOSE_TRACKS -> PlaybackScope.looseTracks()
        PlaybackScope.Kind.SPECIFIC_FOLDERS -> PlaybackScope.folders(mSelectedPaths)
        PlaybackScope.Kind.SPECIFIC_GENRES -> PlaybackScope.genres(mSelectedGenres)
        PlaybackScope.Kind.SPECIFIC_ARTISTS -> PlaybackScope.artists(mSelectedArtists)
        PlaybackScope.Kind.SPECIFIC_ALBUMS -> PlaybackScope.albums(mSelectedAlbums)
        else -> PlaybackScope.ALL_SONGS
    }

    // ========================================================================
    // Adapter
    // ========================================================================

    private inner class ScopeAdapter : RecyclerView.Adapter<ScopeHolder>() {

        override fun getItemViewType(position: Int): Int = mRows[position].type

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScopeHolder {
            val view = LayoutInflater.from(mContext).inflate(R.layout.item_scope_row, parent, false)
            return ScopeHolder(view)
        }

        override fun onBindViewHolder(holder: ScopeHolder, position: Int) {
            val row = mRows[position]
            holder.mLabel.text = row.label
            if (row.type == Row.TYPE_MODE) {
                val selected = row.kind == mSelectedKind
                mThemeHelper.updateRadio(holder.mIndicator, selected, true)
                holder.itemView.setBackgroundColor(if (selected)
                    Color.parseColor(SELECTED_BACKGROUND_COLOR) else Color.TRANSPARENT)
                holder.itemView.setOnClickListener { onModeTapped(row.kind) }
                attachPressHighlight(holder.itemView, selected)
            } else {
                val selectedSet = setFor(row.kind)
                val checked = row.value != null && selectedSet.contains(row.value)
                mThemeHelper.updateCheckbox(holder.mIndicator, checked, true)
                holder.itemView.setBackgroundColor(Color.TRANSPARENT)
                holder.itemView.setOnClickListener {
                    row.value?.let { onFilterToggled(row.kind, it) }
                }
                attachPressHighlight(holder.itemView, false)
            }
        }

        override fun getItemCount(): Int = mRows.size
    }

    private class ScopeHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mLabel: TextView = itemView.findViewById(R.id.scopeRowLabel)
        val mIndicator: TextView = itemView.findViewById(R.id.scopeRowIndicator)
    }

    private fun attachPressHighlight(view: View, staySelected: Boolean) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> v.setBackgroundColor(
                    Color.parseColor(TOUCH_HIGHLIGHT_COLOR))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.setBackgroundColor(
                    if (staySelected) Color.parseColor(SELECTED_BACKGROUND_COLOR)
                    else Color.TRANSPARENT)
            }
            false
        }
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    private fun forceRedraw() {
        val window = window ?: return
        val root = window.decorView.findViewById<View>(android.R.id.content) ?: return
        root.requestLayout(); root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * mContext.resources.displayMetrics.density)

    companion object {
        private const val TAG = "PlaybackScopeDialog"
    }
}