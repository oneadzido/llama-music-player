// EqualizerActivity.kt
package com.ark.llama

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.ark.llama.event.LlamaEventBus
import com.ark.llama.event.SessionEvent
import com.ark.llama.event.SettingsEvent
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Provides the UI for adjusting audio effects: a multi-band
 * equalizer, bass boost, surround effect, pitch, and playback speed.
 *
 * @author Richard Korbla Adzido
 * @version 1.5.0
 * @since 1.0.0
 */
class EqualizerActivity : Activity() {

    // ========================================================================
    // Constants
    // ========================================================================

    private val ANIMATION_DURATION_MS = 80
    private val ANIMATION_SCALE_DOWN = 0.97f
    private val ANIMATION_SCALE_NORMAL = 1.0f

    private val SEEKBAR_MAX_BOOST = 1000
    private val SEEKBAR_MAX = 2000
    private val PITCH_DEFAULT = 1000
    private val SPEED_DEFAULT = 1000

    private val BOOST_UNITS_PER_PERCENT = 10
    private val EQ_BAND_UNITS_PER_STEP = 10
    private val PITCH_UNITS_PER_STEP = 17
    private val SPEED_UNITS_PER_STEP = 20

    private val TEXT_COLOR_LIGHT = "#C0C0C0"
    private val COLOR_DISABLED = "#5A5A5A"

    private val PRESET_DEBOUNCE_DELAY_MS = 500L
    private val STATUS_MESSAGE_DURATION_MS = 1500L
    private val UI_REFRESH_DELAY_MS = 200L
    private val SPLIT_SCREEN_MIN_HEIGHT_DP = 400

    private val PREFS_NAME = "LlamaPrefs"
    private val KEY_BASS_BOOST = "bass_boost_level"
    private val KEY_SURROUND = "surround_level"
    private val KEY_PITCH = "pitch_level"
    private val KEY_SPEED = "speed_level"
    private val KEY_BAND_PREFIX = "eq_band_"

    // ========================================================================
    // UI components
    // ========================================================================

    private var bandsContainer: LinearLayout? = null
    private var bandsWrapper: LinearLayout? = null
    private var presetButton: Button? = null
    private var bassBoostSeekBar: SeekBar? = null
    private var surroundSeekBar: SeekBar? = null
    private var pitchSeekBar: SeekBar? = null
    private var speedSeekBar: SeekBar? = null
    private var bassBoostValueText: TextView? = null
    private var surroundValueText: TextView? = null
    private var pitchValueText: TextView? = null
    private var speedValueText: TextView? = null
    private var resetButton: Button? = null
    private var cancelButton: Button? = null
    private var enableButton: Button? = null
    private var statusText: TextView? = null
    private var bandSeekBars: Array<SeekBar?>? = null
    private var bandValueTexts: Array<TextView?>? = null

    // ========================================================================
    // State
    // ========================================================================

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isEqualizerReady = false
    private var areBandsCreated = false
    private var revertToRestingRunnable: Runnable? = null
    private var lastPresetClickTime = 0L
    private var isPresetDialogShowing = false
    private val isClosing = AtomicBoolean(false)
    private val isUpdatingUI = AtomicBoolean(false)

    private var isBassRounding = false
    private var isSurroundRounding = false
    private var isEqRounding = false
    private var isPitchRounding = false
    private var isSpeedRounding = false

    // ========================================================================
    // Managers
    // ========================================================================

    private lateinit var equalizerManager: EqualizerManager
    private lateinit var themeManager: ThemeManager
    private lateinit var themeHelper: ThemeHelper

    private var musicService: MusicService? = null
    private var serviceConnection: ServiceConnection? = null
    private var isServiceBound = false
    private var isBindingComplete = false

    // ========================================================================
    // Equalizer listener
    // ========================================================================

    private val equalizerListener = object : EqualizerManager.EqualizerListener {
        override fun onBandLevelsChanged(levels: IntArray) {
            if (isClosing.get()) return
            runOnUiThreadSafely {
                if (bandSeekBars != null) updateBandControlsFromLevels()
            }
        }

        override fun onPresetChanged(preset: Int, presetName: String) {
            if (isClosing.get()) return
            runOnUiThreadSafely {
                presetButton?.text = presetName
                if (statusText != null && equalizerManager.isEnabled && hasAudioSession()) {
                    showTemporaryMessage(getString(R.string.equalizer_status_preset, presetName))
                }
            }
        }

        override fun onEqualizerReady(ready: Boolean) {
            if (isClosing.get()) return
            runOnUiThreadSafely {
                isEqualizerReady = ready
                val hasAudio = hasAudioSession()
                resetButton?.let {
                    it.isEnabled = hasAudio
                    themeHelper.updateButton(it, hasAudio)
                }
                if (ready) handleEqualizerReady(hasAudio)
                else handleEqualizerNotReady()
            }
        }
    }

    // ========================================================================
    // attachBaseContext
    // ========================================================================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(
            LanguageManager.getInstance(newBase).wrap(newBase)
        )
    }

    // ========================================================================
    // Thread safety
    // ========================================================================

    private fun runOnUiThreadSafely(action: Runnable) {
        if (isFinishing || isDestroyed || isClosing.get()) return
        if (!isUpdatingUI.compareAndSet(false, true)) return
        runOnUiThread {
            try {
                if (!isFinishing && !isDestroyed && !isClosing.get()) {
                    action.run()
                }
            } finally {
                isUpdatingUI.set(false)
            }
        }
    }

    // ========================================================================
    // Lifecycle
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFullScreen()
        setContentView(R.layout.activity_equalizer)

        LlamaEventBus.register(this)

        initializeManagers()
        initializeViews()
        setupListeners()
        bindMusicService()

        applyEqualizerSplitLayout(resources.configuration.screenHeightDp)

        val sessionId = MusicService.getAudioSessionId()
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId)
        } else {
            handleNoAudioSession()
        }

        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
        applyThemeToUI()
        themeAllHeaders()
    }

    override fun onResume() {
        super.onResume()
        if (isClosing.get()) return

        updateUI(false)
        updateAllEffectValues()

        val hasAudio = hasAudioSession()
        updateResetButtonState(hasAudio)

        if (!hasAudio) handleNoAudioSession()

        updateBandControlsState()

        val sessionId = MusicService.getAudioSessionId()
        if (sessionId > 0) {
            equalizerManager.attachToAudioSession(sessionId)
            mainHandler.postDelayed({
                if (!isClosing.get() && equalizerManager.isAttached()) {
                    refreshAllUIControls()
                }
            }, UI_REFRESH_DELAY_MS)
        } else {
            handleNoAudioSession()
        }

        applyThemeToUI()
        themeAllHeaders()
        ToastManager.refreshThemeColor()
    }

    override fun onDestroy() {
        isClosing.set(true)
        super.onDestroy()

        LlamaEventBus.unregister(this)

        unbindServiceSafely()

        revertToRestingRunnable?.let {
            mainHandler.removeCallbacks(it)
            revertToRestingRunnable = null
        }
        mainHandler.removeCallbacksAndMessages(null)
        equalizerManager.setListener(null)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT &&
            !isClosing.get()
        ) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyEqualizerSplitLayout(newConfig.screenHeightDp)
        forceRedraw()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    // ========================================================================
    // Split layout
    // ========================================================================

    private fun applyEqualizerSplitLayout(screenHeightDp: Int) {
        val wrapper = bandsWrapper ?: return
        val isSplit = screenHeightDp < SPLIT_SCREEN_MIN_HEIGHT_DP
        val params = wrapper.layoutParams as LinearLayout.LayoutParams
        val newWeight = if (isSplit) 0f else 1f
        if (params.weight != newWeight) {
            params.weight = newWeight
            wrapper.layoutParams = params
        }
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    private fun initializeManagers() {
        equalizerManager = EqualizerManager.getInstance(this)
        equalizerManager.setListener(equalizerListener)
        themeManager = ThemeManager.getInstance(this)
        themeHelper = ThemeHelper.getInstance(this)
    }

    private fun bindMusicService() {
        val bindIntent = Intent(this, MusicService::class.java)
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                val binder = service as MusicService.LocalBinder
                musicService = binder.service
                isServiceBound = true
                isBindingComplete = true
                updateUI(false)
                updateAllEffectValues()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                musicService = null
                isServiceBound = false
            }
        }
        serviceConnection = connection
        bindService(bindIntent, connection, BIND_AUTO_CREATE)
    }

    private fun unbindServiceSafely() {
        if (isServiceBound) {
            try {
                serviceConnection?.let { unbindService(it) }
            } catch (exception: Exception) {
                // The service was already unbound.
            }
            isServiceBound = false
        }
    }

    // ========================================================================
    // Session events
    // ========================================================================

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onAudioSessionChanged(event: SessionEvent.AudioSessionChanged) {
        if (isClosing.get()) return
        if (event.sessionId > 0) {
            mainHandler.post {
                if (!isClosing.get()) {
                    equalizerManager.attachToAudioSession(event.sessionId)
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onPlaybackParamsRefresh(event: SessionEvent.PlaybackParamsRefresh) {
        if (isClosing.get()) return
        runOnUiThreadSafely { updateAllEffectValues() }
    }

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onThemeColorChanged(event: SettingsEvent.ThemeColorChanged) {
        if (isFinishing || isDestroyed || isClosing.get()) return
        recreateWithConfiguration()
    }

    @Subscribe(threadMode = ThreadMode.STICKY, sticky = true)
    fun onLanguageChanged(event: SettingsEvent.LanguageChanged) {
        if (isFinishing || isDestroyed || isClosing.get()) return
        recreateWithConfiguration()
    }

    // ========================================================================
    // State queries
    // ========================================================================

    private fun hasAudioSession(): Boolean = MusicService.getAudioSessionId() > 0

    private fun isEqualizerOperational(): Boolean =
        equalizerManager.isEnabled &&
            hasAudioSession() &&
            equalizerManager.isAttached() &&
            equalizerManager.getNumberOfBands() > 0

    // ========================================================================
    // Refresh all UI controls
    // ========================================================================

    private fun refreshAllUIControls() {
        val isEnabled = equalizerManager.isEnabled
        val hasAudio = hasAudioSession()
        val themeColor = themeHelper.themeColorInt

        bassBoostSeekBar?.let { bar ->
            if (equalizerManager.isBassBoostSupported()) {
                val level = equalizerManager.getBassBoost()
                bar.progress = level
                updateBassBoostValue(level)
                bar.isEnabled = isEnabled && hasAudio
            } else {
                bar.isEnabled = false
                bassBoostValueText?.text = getString(R.string.equalizer_off)
            }
        }
        bassBoostValueText?.setTextColor(
            if (isEnabled && hasAudio && equalizerManager.isBassBoostSupported())
                themeColor else Color.parseColor(COLOR_DISABLED)
        )

        surroundSeekBar?.let { bar ->
            if (equalizerManager.isSurroundSupported()) {
                val level = equalizerManager.getSurround()
                bar.progress = level
                updateSurroundValue(level)
                bar.isEnabled = isEnabled && hasAudio
            } else {
                bar.isEnabled = false
                surroundValueText?.text = getString(R.string.equalizer_off)
            }
        }
        surroundValueText?.setTextColor(
            if (isEnabled && hasAudio && equalizerManager.isSurroundSupported())
                themeColor else Color.parseColor(COLOR_DISABLED)
        )

        pitchSeekBar?.let { bar ->
            val level = equalizerManager.getPitch()
            bar.progress = level
            updatePitchValue(level)
            bar.isEnabled = hasAudio
        }
        pitchValueText?.setTextColor(
            if (hasAudio) themeColor else Color.parseColor(COLOR_DISABLED)
        )

        speedSeekBar?.let { bar ->
            val level = equalizerManager.getSpeed()
            bar.progress = level
            updateSpeedValue(level)
            bar.isEnabled = hasAudio
        }
        speedValueText?.setTextColor(
            if (hasAudio) themeColor else Color.parseColor(COLOR_DISABLED)
        )

        updateBandControlsFromLevels()

        presetButton?.let {
            val currentPreset = equalizerManager.getCurrentPreset()
            it.text = equalizerManager.getPresetName(currentPreset)
            it.isEnabled = isEnabled && hasAudio
            themeHelper.updateButton(it, isEnabled && hasAudio)
        }

        enableButton?.let {
            it.isEnabled = hasAudio
            it.text = if (isEnabled) getString(R.string.action_disable)
            else getString(R.string.action_enable)
            themeHelper.updateButton(it, hasAudio)
        }

        resetButton?.let {
            it.isEnabled = isEnabled && hasAudio
            themeHelper.updateButton(it, isEnabled && hasAudio)
        }

        statusText?.let {
            it.text = if (isEnabled && hasAudio)
                getString(R.string.equalizer_status_waves)
            else getString(R.string.equalizer_status_disabled)
            it.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }
        forceRedraw()
    }

    private fun handleEqualizerReady(hasAudio: Boolean) {
        if (equalizerManager.getNumberOfBands() > 0 && !areBandsCreated) {
            createBandControls()
            areBandsCreated = true
        }

        refreshAllUIControls()

        if (hasAudio) {
            presetButton?.text = equalizerManager.getPresetName(
                equalizerManager.getCurrentPreset()
            )
        } else {
            presetButton?.text = getString(R.string.equalizer_preset_disabled)
            enableButton?.let {
                it.isEnabled = false
                themeHelper.updateButton(it, false)
                it.text = getString(R.string.action_enable)
            }
        }

        val isEnabled = equalizerManager.isEnabled
        updateUIState(isEnabled)

        statusText?.let {
            it.text = if (isEnabled && hasAudio)
                getString(R.string.equalizer_status_waves)
            else getString(R.string.equalizer_status_disabled)
            it.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }

        if (hasAudio) {
            enableButton?.let { themeHelper.updateButton(it, it.isEnabled) }
            resetButton?.let { themeHelper.updateButton(it, it.isEnabled) }
        }
    }

    private fun handleEqualizerNotReady() {
        statusText?.let {
            it.text = getString(R.string.equalizer_status_disabled)
            it.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }

        updateUIState(false)

        enableButton?.let {
            it.isEnabled = false
            themeHelper.updateButton(it, false)
            it.text = getString(R.string.action_enable)
        }

        presetButton?.text = getString(R.string.equalizer_preset_disabled)

        refreshAllUIControls()
    }

    private fun handleNoAudioSession() {
        statusText?.let {
            it.text = getString(R.string.equalizer_status_disabled)
            it.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }
        presetButton?.text = getString(R.string.equalizer_preset_disabled)
        enableButton?.let {
            it.isEnabled = false
            themeHelper.updateButton(it, false)
            it.text = getString(R.string.action_enable)
        }
        resetButton?.let {
            it.isEnabled = false
            themeHelper.updateButton(it, false)
        }

        val preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        bassBoostSeekBar?.let { bar ->
            val savedBass = preferences.getInt(KEY_BASS_BOOST, 0)
            bar.progress = savedBass
            updateBassBoostValue(savedBass)
            bar.isEnabled = false
            themeHelper.updateSeekBar(bar, false)
        }
        bassBoostValueText?.setTextColor(Color.parseColor(COLOR_DISABLED))

        surroundSeekBar?.let { bar ->
            val savedSurround = preferences.getInt(KEY_SURROUND, 0)
            bar.progress = savedSurround
            updateSurroundValue(savedSurround)
            bar.isEnabled = false
            themeHelper.updateSeekBar(bar, false)
        }
        surroundValueText?.setTextColor(Color.parseColor(COLOR_DISABLED))

        pitchSeekBar?.let { bar ->
            val savedPitch = preferences.getInt(KEY_PITCH, PITCH_DEFAULT)
            bar.progress = savedPitch
            updatePitchValue(savedPitch)
            bar.isEnabled = false
            themeHelper.updateSeekBar(bar, false)
        }
        pitchValueText?.setTextColor(Color.parseColor(COLOR_DISABLED))

        speedSeekBar?.let { bar ->
            val savedSpeed = preferences.getInt(KEY_SPEED, SPEED_DEFAULT)
            bar.progress = savedSpeed
            updateSpeedValue(savedSpeed)
            bar.isEnabled = false
            themeHelper.updateSeekBar(bar, false)
        }
        speedValueText?.setTextColor(Color.parseColor(COLOR_DISABLED))

        bandSeekBars?.let { bars ->
            val minLevel = equalizerManager.getMinBandLevel().toInt()
            for (index in bars.indices) {
                val bar = bars[index] ?: continue
                val savedLevel = preferences.getInt(KEY_BAND_PREFIX + index, 0)
                val progress = savedLevel - minLevel
                bar.progress = Math.max(0, Math.min(bar.max, progress))
                bar.isEnabled = false
                themeHelper.updateSeekBar(bar, false)
            }
        }
        bandValueTexts?.forEach { it?.setTextColor(Color.parseColor(COLOR_DISABLED)) }
    }

    private fun updateBandControlsState() {
        bandSeekBars?.let { bars ->
            updateBandControlsFromLevels()
            val isEnabled = equalizerManager.isEnabled
            val hasAudio = hasAudioSession()
            bars.forEach { it?.isEnabled = isEnabled && hasAudio }
        }
    }

    // ========================================================================
    // Status messages
    // ========================================================================

    private fun showTemporaryMessage(message: String) {
        val status = statusText ?: return
        if (isClosing.get()) return

        revertToRestingRunnable?.let { mainHandler.removeCallbacks(it) }

        status.text = message
        status.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))

        revertToRestingRunnable = Runnable {
            if (isClosing.get()) return@Runnable
            status.text = if (equalizerManager.isEnabled && hasAudioSession())
                getString(R.string.equalizer_status_waves)
            else if (hasAudioSession())
                getString(R.string.equalizer_status_disabled)
            else null
            status.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }
        mainHandler.postDelayed(revertToRestingRunnable!!, STATUS_MESSAGE_DURATION_MS)
    }

    private fun showPersistentDisabledMessage() {
        val status = statusText ?: return
        if (isClosing.get()) return
        revertToRestingRunnable?.let { mainHandler.removeCallbacks(it) }
        status.text = getString(R.string.equalizer_status_disabled)
        status.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
    }

    // ========================================================================
    // Full-screen
    // ========================================================================

    @Suppress("DEPRECATION")
    private fun setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.statusBarColor = resources.getColor(R.color.backgroundDark, null)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark, null)
            } else {
                window.statusBarColor = resources.getColor(R.color.backgroundDark)
                window.navigationBarColor = resources.getColor(R.color.backgroundDark)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    // ========================================================================
    // View init
    // ========================================================================

    private fun initializeViews() {
        bandsContainer = findViewById(R.id.bandsContainer)
        bandsWrapper = findViewById(R.id.bandsWrapper)
        presetButton = findViewById(R.id.presetButton)
        bassBoostSeekBar = findViewById(R.id.bassBoostSeekBar)
        surroundSeekBar = findViewById(R.id.surroundSeekBar)
        pitchSeekBar = findViewById(R.id.pitchSeekBar)
        speedSeekBar = findViewById(R.id.speedSeekBar)
        bassBoostValueText = findViewById(R.id.bassBoostValueText)
        surroundValueText = findViewById(R.id.surroundValueText)
        pitchValueText = findViewById(R.id.pitchValueText)
        speedValueText = findViewById(R.id.speedValueText)
        resetButton = findViewById(R.id.resetButton)
        cancelButton = findViewById(R.id.cancelButton)
        enableButton = findViewById(R.id.enableButton)
        statusText = findViewById(R.id.statusText)

        animateButton(presetButton)
        animateButton(resetButton)
        animateButton(cancelButton)
        animateButton(enableButton)

        initializePresetButtonText()
        initializeResetButtonState()
        initializeEffectControls()

        updateUIState(false)
    }

    private fun initializePresetButtonText() {
        if (hasAudioSession()) {
            presetButton?.text = equalizerManager.getPresetName(
                equalizerManager.getCurrentPreset()
            )
        } else {
            presetButton?.text = getString(R.string.equalizer_preset_disabled)
        }
    }

    private fun initializeResetButtonState() {
        resetButton?.let {
            val hasAudio = hasAudioSession()
            it.isEnabled = hasAudio
            themeHelper.updateButton(it, hasAudio)
        }
    }

    private fun initializeEffectControls() {
        if (equalizerManager.isBassBoostSupported()) {
            bassBoostSeekBar?.let {
                it.max = SEEKBAR_MAX_BOOST
                it.progress = equalizerManager.getBassBoost()
            }
            updateBassBoostValue(equalizerManager.getBassBoost())
        } else {
            bassBoostSeekBar?.isEnabled = false
            bassBoostValueText?.text = getString(R.string.equalizer_off)
        }

        if (equalizerManager.isSurroundSupported()) {
            surroundSeekBar?.let {
                it.max = SEEKBAR_MAX_BOOST
                it.progress = equalizerManager.getSurround()
            }
            updateSurroundValue(equalizerManager.getSurround())
        } else {
            surroundSeekBar?.isEnabled = false
            surroundValueText?.text = getString(R.string.equalizer_off)
        }

        pitchSeekBar?.let {
            it.max = SEEKBAR_MAX
            it.progress = equalizerManager.getPitch()
        }
        updatePitchValue(equalizerManager.getPitch())

        speedSeekBar?.let {
            it.max = SEEKBAR_MAX
            it.progress = equalizerManager.getSpeed()
        }
        updateSpeedValue(equalizerManager.getSpeed())
    }

    // ========================================================================
    // Theme
    // ========================================================================

    private fun themeAllHeaders() {
        if (isClosing.get()) return
        val root = findViewById<View>(android.R.id.content)
        if (root is android.view.ViewGroup) {
            themeHeadersRecursive(root)
        }
    }

    private fun themeHeadersRecursive(group: android.view.ViewGroup) {
        for (index in 0 until group.childCount) {
            val child = group.getChildAt(index)
            if (child is TextView && child !is Button) {
                val text = child.text.toString()
                if (text == getString(R.string.equalizer_title) ||
                    text == getString(R.string.equalizer_band_bass_boost) ||
                    text == getString(R.string.equalizer_band_surround) ||
                    text == getString(R.string.equalizer_band_pitch) ||
                    text == getString(R.string.equalizer_band_speed) ||
                    text == getString(R.string.equalizer_status_waves)
                ) {
                    child.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
                }
            } else if (child is android.view.ViewGroup) {
                themeHeadersRecursive(child)
            }
        }
    }

    private fun applyThemeToUI() {
        if (isClosing.get()) return

        themeHelper.setThemeColor(themeManager.getCurrentColor())

        presetButton?.let { themeHelper.updateButton(it, it.isEnabled) }
        resetButton?.let { themeHelper.updateButton(it, it.isEnabled) }
        cancelButton?.let { themeHelper.updateButton(it, it.isEnabled) }
        enableButton?.let { themeHelper.updateButton(it, it.isEnabled) }

        bassBoostSeekBar?.let { themeHelper.updateSeekBar(it, it.isEnabled) }
        surroundSeekBar?.let { themeHelper.updateSeekBar(it, it.isEnabled) }
        pitchSeekBar?.let { themeHelper.updateSeekBar(it, it.isEnabled) }
        speedSeekBar?.let { themeHelper.updateSeekBar(it, it.isEnabled) }

        bandSeekBars?.forEach { it?.let { bar ->
            themeHelper.updateSeekBar(bar, bar.isEnabled)
        } }

        updateValueTextWithSeekBar(bassBoostValueText, bassBoostSeekBar)
        updateValueTextWithSeekBar(surroundValueText, surroundSeekBar)
        updateValueTextWithSeekBar(pitchValueText, pitchSeekBar)
        updateValueTextWithSeekBar(speedValueText, speedSeekBar)

        statusText?.let {
            it.text = if (equalizerManager.isEnabled && hasAudioSession())
                getString(R.string.equalizer_status_waves)
            else getString(R.string.equalizer_status_disabled)
            it.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
        }

        bandValueTexts?.forEach { text ->
            if (text != null && equalizerManager.isEnabled && hasAudioSession()) {
                themeHelper.updateTextView(text, true)
            }
        }
        forceRedraw()
    }

    private fun updateValueTextWithSeekBar(valueText: TextView?, seekBar: SeekBar?) {
        if (valueText != null && seekBar != null) {
            val enabled = seekBar.isEnabled
            themeHelper.updateTextView(valueText, enabled)
            if (!enabled) valueText.setTextColor(Color.parseColor(COLOR_DISABLED))
        }
    }

    private fun animateButton(button: Button?) {
        if (button == null) return
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(ANIMATION_SCALE_DOWN)
                        .scaleY(ANIMATION_SCALE_DOWN)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(ANIMATION_SCALE_NORMAL)
                        .scaleY(ANIMATION_SCALE_NORMAL)
                        .setDuration(ANIMATION_DURATION_MS.toLong())
                        .start()
                }
            }
            false
        }
    }

    // ========================================================================
    // UI state
    // ========================================================================

    private fun updateUIState(enabled: Boolean) {
        if (isClosing.get()) return

        val hasAudio = hasAudioSession()
        val canEnable = isEqualizerReady && hasAudio
        val themeColor = themeHelper.themeColorInt

        updatePresetButtonState(enabled, canEnable, hasAudio)
        updateResetButtonState(canEnable)
        updateBassBoostControlState(enabled, canEnable, themeColor)
        updateSurroundControlState(enabled, canEnable, themeColor)
        updatePitchControlState(canEnable, themeColor)
        updateSpeedControlState(canEnable, themeColor)
        updateBandControlState(enabled, canEnable, themeColor)
        updateEnableButtonState(canEnable, enabled)
    }

    private fun updatePresetButtonState(enabled: Boolean, canEnable: Boolean, hasAudio: Boolean) {
        presetButton?.let { button ->
            val shouldEnable = enabled && canEnable
            button.isEnabled = shouldEnable
            themeHelper.updateButton(button, shouldEnable)
            if (!hasAudio) button.text = getString(R.string.equalizer_preset_disabled)
            else button.text = equalizerManager.getPresetName(equalizerManager.getCurrentPreset())
        }
    }

    private fun updateResetButtonState(canEnable: Boolean) {
        resetButton?.let {
            it.isEnabled = canEnable
            themeHelper.updateButton(it, canEnable)
        }
    }

    private fun updateBassBoostControlState(enabled: Boolean, canEnable: Boolean, themeColor: Int) {
        bassBoostSeekBar?.let { bar ->
            val boosterEnabled = enabled && canEnable && equalizerManager.isBassBoostSupported()
            bar.isEnabled = boosterEnabled
            themeHelper.updateSeekBar(bar, boosterEnabled)
            bassBoostValueText?.setTextColor(
                if (boosterEnabled) themeColor else Color.parseColor(COLOR_DISABLED)
            )
        }
    }

    private fun updateSurroundControlState(enabled: Boolean, canEnable: Boolean, themeColor: Int) {
        surroundSeekBar?.let { bar ->
            val boosterEnabled = enabled && canEnable && equalizerManager.isSurroundSupported()
            bar.isEnabled = boosterEnabled
            themeHelper.updateSeekBar(bar, boosterEnabled)
            surroundValueText?.setTextColor(
                if (boosterEnabled) themeColor else Color.parseColor(COLOR_DISABLED)
            )
        }
    }

    private fun updatePitchControlState(canEnable: Boolean, themeColor: Int) {
        pitchSeekBar?.let { bar ->
            bar.isEnabled = canEnable
            themeHelper.updateSeekBar(bar, canEnable)
            pitchValueText?.setTextColor(
                if (canEnable) themeColor else Color.parseColor(COLOR_DISABLED)
            )
        }
    }

    private fun updateSpeedControlState(canEnable: Boolean, themeColor: Int) {
        speedSeekBar?.let { bar ->
            bar.isEnabled = canEnable
            themeHelper.updateSeekBar(bar, canEnable)
            speedValueText?.setTextColor(
                if (canEnable) themeColor else Color.parseColor(COLOR_DISABLED)
            )
        }
    }

    private fun updateBandControlState(enabled: Boolean, canEnable: Boolean, themeColor: Int) {
        bandSeekBars?.forEach { bar ->
            bar?.let {
                it.isEnabled = enabled && canEnable
                themeHelper.updateSeekBar(it, enabled && canEnable)
            }
        }
        bandValueTexts?.forEach { text ->
            text?.setTextColor(
                if (enabled && canEnable) themeColor else Color.parseColor(COLOR_DISABLED)
            )
        }
    }

    private fun updateEnableButtonState(canEnable: Boolean, enabled: Boolean) {
        enableButton?.let { button ->
            button.isEnabled = canEnable
            button.text = if (canEnable && enabled) getString(R.string.action_disable)
            else getString(R.string.action_enable)
            themeHelper.updateButton(button, canEnable)
        }
    }

    // ========================================================================
    // Band controls
    // ========================================================================

    private fun createBandControls() {
        val container = bandsContainer ?: return
        if (isClosing.get()) return
        container.removeAllViews()
        val numberOfBands = equalizerManager.getNumberOfBands()
        if (numberOfBands.toInt() == 0) return

        val bars = arrayOfNulls<SeekBar>(numberOfBands.toInt())
        val texts = arrayOfNulls<TextView>(numberOfBands.toInt())
        bandSeekBars = bars
        bandValueTexts = texts

        val minLevel = equalizerManager.getMinBandLevel().toInt()
        val maxLevel = equalizerManager.getMaxBandLevel().toInt()
        val seekBarWidth = maxLevel - minLevel
        val themeColor = themeHelper.themeColorInt

        for (bandIndex in 0 until numberOfBands.toInt()) {
            createSingleBandControl(bandIndex, minLevel, maxLevel, seekBarWidth, themeColor)
        }
    }

    private fun createSingleBandControl(
        bandIndex: Int,
        minLevel: Int,
        maxLevel: Int,
        seekBarWidth: Int,
        themeColor: Int
    ) {
        val frequency = equalizerManager.getCenterFrequency(bandIndex)
        val frequencyText = equalizerManager.getFrequencyLabel(frequency)
        val currentLevel = equalizerManager.getBandLevel(bandIndex)

        val bandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 4)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val frequencyLabel = TextView(this).apply {
            text = frequencyText
            setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
            textSize = 12f
            setPadding(0, 8, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        val levelText = TextView(this).apply {
            text = formatLevel(currentLevel)
            setTextColor(themeColor)
            textSize = 12f
            setPadding(0, 8, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dpToPx(8) }
        }

        topRow.addView(frequencyLabel)
        topRow.addView(levelText)

        val seekBar = SeekBar(this).apply {
            max = seekBarWidth
            var initialProgress = currentLevel - minLevel
            var roundedInitial = Math.round(
                initialProgress / EQ_BAND_UNITS_PER_STEP.toFloat()
            ) * EQ_BAND_UNITS_PER_STEP
            roundedInitial = Math.max(0, Math.min(seekBarWidth, roundedInitial))
            progress = roundedInitial
            thumb = null
            isEnabled = equalizerManager.isEnabled && hasAudioSession()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                progressDrawable = resources.getDrawable(R.drawable.seekbar_progress, null)
            } else {
                progressDrawable = ContextCompat.getDrawable(this@EqualizerActivity, R.drawable.seekbar_progress)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 8
                bottomMargin = 8
            }
        }

        themeHelper.updateSeekBar(seekBar, seekBar.isEnabled)

        bandContainer.addView(topRow)
        bandContainer.addView(seekBar)
        bandsContainer?.addView(bandContainer)

        bandSeekBars?.set(bandIndex, seekBar)
        bandValueTexts?.set(bandIndex, levelText)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isClosing.get() || !fromUser || !isEqualizerOperational()) return
                if (isEqRounding) return

                var rounded = Math.round(
                    progress / EQ_BAND_UNITS_PER_STEP.toFloat()
                ) * EQ_BAND_UNITS_PER_STEP
                rounded = Math.max(0, Math.min(seekBarWidth, rounded))

                if (rounded != progress) {
                    isEqRounding = true
                    bar?.progress = rounded
                    val level = minLevel + rounded
                    equalizerManager.setBandLevel(bandIndex, level)
                    levelText.text = formatLevel(level)
                    isEqRounding = false
                } else {
                    val level = minLevel + progress
                    equalizerManager.setBandLevel(bandIndex, level)
                    levelText.text = formatLevel(level)
                }
            }

            override fun onStartTrackingTouch(bar: SeekBar?) { isEqRounding = false }
            override fun onStopTrackingTouch(bar: SeekBar?) { }
        })
    }

    private fun updateBandControlsFromLevels() {
        val bars = bandSeekBars ?: return
        if (isClosing.get() || !equalizerManager.isAttached()) return

        val minLevel = equalizerManager.getMinBandLevel().toInt()
        val themeColor = themeHelper.themeColorInt

        val bands = Math.min(bars.size, equalizerManager.getNumberOfBands().toInt())
        for (bandIndex in 0 until bands) {
            val level = equalizerManager.getBandLevel(bandIndex)
            bars[bandIndex]?.let { bar ->
                var progress = level - minLevel
                var rounded = Math.round(progress / EQ_BAND_UNITS_PER_STEP.toFloat()) *
                    EQ_BAND_UNITS_PER_STEP
                rounded = Math.max(0, Math.min(bar.max, rounded))
                bar.progress = rounded
            }
            bandValueTexts?.get(bandIndex)?.let { text ->
                text.text = formatLevel(level)
                if (equalizerManager.isEnabled && hasAudioSession()) {
                    text.setTextColor(themeColor)
                }
            }
        }
    }

    private fun formatLevel(level: Int): String {
        var rounded = Math.round(level / EQ_BAND_UNITS_PER_STEP.toFloat()) *
            EQ_BAND_UNITS_PER_STEP
        val decibels = rounded / 100.0f
        return when {
            decibels > 0 -> getString(R.string.equalizer_db_positive, decibels)
            decibels < 0 -> getString(R.string.equalizer_db_negative, decibels)
            else -> getString(R.string.equalizer_db_zero, decibels)
        }
    }

    // ========================================================================
    // Effect value labels
    // ========================================================================

    private fun updateBassBoostValue(value: Int) {
        if (!isClosing.get()) {
            bassBoostValueText?.text = getString(
                R.string.equalizer_percent,
                (value * 100) / SEEKBAR_MAX_BOOST
            )
        }
    }

    private fun updateSurroundValue(value: Int) {
        if (!isClosing.get()) {
            surroundValueText?.text = getString(
                R.string.equalizer_percent,
                (value * 100) / SEEKBAR_MAX_BOOST
            )
        }
    }

    private fun updatePitchValue(value: Int) {
        if (!isClosing.get()) {
            val semitones = (value - PITCH_DEFAULT) / (1000.0f / 6.0f)
            pitchValueText?.text = when {
                Math.abs(semitones) < 0.05f ->
                    getString(R.string.equalizer_semitones_zero, 0f)
                semitones > 0 ->
                    getString(R.string.equalizer_semitones_positive, semitones)
                else ->
                    getString(R.string.equalizer_semitones_negative, semitones)
            }
        }
    }

    private fun updateSpeedValue(value: Int) {
        if (!isClosing.get()) {
            val speed = 0.5f + (value / 2000.0f)
            speedValueText?.text = getString(R.string.equalizer_speed_value, speed)
        }
    }

    private fun updateAllEffectValues() {
        if (isClosing.get()) return
        updateBassBoostValue(equalizerManager.getBassBoost())
        updateSurroundValue(equalizerManager.getSurround())
        updatePitchValue(equalizerManager.getPitch())
        updateSpeedValue(equalizerManager.getSpeed())
    }

    // ========================================================================
    // UI refresh
    // ========================================================================

    private fun updateUI() = updateUI(true)

    private fun updateUI(showTransitionMessage: Boolean) {
        if (isClosing.get()) return
        val enabled = equalizerManager.isEnabled
        enableButton?.text = if (enabled) getString(R.string.action_disable)
        else getString(R.string.action_enable)
        updateUIState(enabled)
        updateAllEffectValues()
        applyThemeToUI()
        if (isEqualizerReady && hasAudioSession()) {
            if (enabled) {
                revertToRestingRunnable?.let { mainHandler.removeCallbacks(it) }
                if (showTransitionMessage) {
                    showTemporaryMessage(getString(R.string.equalizer_status_enabled))
                } else {
                    statusText?.text = getString(R.string.equalizer_status_waves)
                    statusText?.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT))
                }
            } else {
                showPersistentDisabledMessage()
            }
        }
    }

    // ========================================================================
    // Listeners
    // ========================================================================

    private fun setupListeners() {
        setupPresetButtonListener()
        setupBassBoostListener()
        setupSurroundListener()
        setupPitchListener()
        setupSpeedListener()
        setupResetButtonListener()
        setupEnableButtonListener()
        setupCancelButtonListener()
    }

    private fun setupPresetButtonListener() {
        presetButton?.setOnClickListener {
            if (isClosing.get() || isPresetDialogShowing) return@setOnClickListener
            val now = SystemClock.elapsedRealtime()
            if (now - lastPresetClickTime < PRESET_DEBOUNCE_DELAY_MS) return@setOnClickListener
            lastPresetClickTime = now
            isPresetDialogShowing = true
            showPresetDialog()
        }
    }

    private fun setupBassBoostListener() {
        bassBoostSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isClosing.get() || !fromUser || !isEqualizerOperational()) return
                if (isBassRounding) return
                var rounded = Math.round(progress / BOOST_UNITS_PER_PERCENT.toFloat()) *
                    BOOST_UNITS_PER_PERCENT
                rounded = Math.max(0, Math.min(SEEKBAR_MAX_BOOST, rounded))
                if (rounded != progress) {
                    isBassRounding = true
                    bar?.progress = rounded
                    equalizerManager.setBassBoost(rounded)
                    updateBassBoostValue(rounded)
                    isBassRounding = false
                } else {
                    equalizerManager.setBassBoost(progress)
                    updateBassBoostValue(progress)
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) { isBassRounding = false }
            override fun onStopTrackingTouch(bar: SeekBar?) { }
        })
    }

    private fun setupSurroundListener() {
        surroundSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isClosing.get() || !fromUser || !isEqualizerOperational()) return
                if (isSurroundRounding) return
                var rounded = Math.round(progress / BOOST_UNITS_PER_PERCENT.toFloat()) *
                    BOOST_UNITS_PER_PERCENT
                rounded = Math.max(0, Math.min(SEEKBAR_MAX_BOOST, rounded))
                if (rounded != progress) {
                    isSurroundRounding = true
                    bar?.progress = rounded
                    equalizerManager.setSurround(rounded)
                    updateSurroundValue(rounded)
                    isSurroundRounding = false
                } else {
                    equalizerManager.setSurround(progress)
                    updateSurroundValue(progress)
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) { isSurroundRounding = false }
            override fun onStopTrackingTouch(bar: SeekBar?) { }
        })
    }

    private fun setupPitchListener() {
        pitchSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isClosing.get() || !fromUser) return
                if (isPitchRounding) return
                var rounded = Math.round(progress / PITCH_UNITS_PER_STEP.toFloat()) *
                    PITCH_UNITS_PER_STEP
                rounded = Math.max(0, Math.min(SEEKBAR_MAX, rounded))
                if (rounded != progress) {
                    isPitchRounding = true
                    bar?.progress = rounded
                    equalizerManager.setPitch(rounded)
                    updatePitchValue(rounded)
                    isPitchRounding = false
                    if (isBindingComplete && musicService?.isPlaying == true) {
                        notifyPlaybackParamsChanged()
                    }
                } else {
                    equalizerManager.setPitch(progress)
                    updatePitchValue(progress)
                    if (isBindingComplete && musicService?.isPlaying == true) {
                        notifyPlaybackParamsChanged()
                    }
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) { isPitchRounding = false }
            override fun onStopTrackingTouch(bar: SeekBar?) { }
        })
    }

    private fun setupSpeedListener() {
        speedSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isClosing.get() || !fromUser) return
                if (isSpeedRounding) return
                var rounded = Math.round(progress / SPEED_UNITS_PER_STEP.toFloat()) *
                    SPEED_UNITS_PER_STEP
                rounded = Math.max(0, Math.min(SEEKBAR_MAX, rounded))
                if (rounded != progress) {
                    isSpeedRounding = true
                    bar?.progress = rounded
                    equalizerManager.setSpeed(rounded)
                    updateSpeedValue(rounded)
                    isSpeedRounding = false
                    if (isBindingComplete && musicService?.isPlaying == true) {
                        notifyPlaybackParamsChanged()
                    }
                } else {
                    equalizerManager.setSpeed(progress)
                    updateSpeedValue(progress)
                    if (isBindingComplete && musicService?.isPlaying == true) {
                        notifyPlaybackParamsChanged()
                    }
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) { isSpeedRounding = false }
            override fun onStopTrackingTouch(bar: SeekBar?) { }
        })
    }

    private fun setupResetButtonListener() {
        resetButton?.setOnClickListener {
            if (isClosing.get()) return@setOnClickListener

            val operational = isEqualizerOperational()
            var anythingChanged = false

            if (operational) {
                val numberOfBands = equalizerManager.getNumberOfBands()
                for (bandIndex in 0 until numberOfBands) {
                    if (equalizerManager.getBandLevel(bandIndex.toInt()) != 0) {
                        equalizerManager.setBandLevel(bandIndex.toInt(), 0)
                        anythingChanged = true
                    }
                }
                if (anythingChanged) equalizerManager.clearCustomBandLevels()
            }

            if (operational && equalizerManager.isBassBoostSupported()) {
                if (equalizerManager.getBassBoost() != 0) {
                    equalizerManager.setBassBoost(0)
                    bassBoostSeekBar?.progress = 0
                    updateBassBoostValue(0)
                    anythingChanged = true
                }
            }

            if (operational && equalizerManager.isSurroundSupported()) {
                if (equalizerManager.getSurround() != 0) {
                    equalizerManager.setSurround(0)
                    surroundSeekBar?.progress = 0
                    updateSurroundValue(0)
                    anythingChanged = true
                }
            }

            if (equalizerManager.getPitch() != PITCH_DEFAULT) {
                equalizerManager.setPitch(PITCH_DEFAULT)
                pitchSeekBar?.progress = PITCH_DEFAULT
                updatePitchValue(PITCH_DEFAULT)
                anythingChanged = true
            }

            if (equalizerManager.getSpeed() != SPEED_DEFAULT) {
                equalizerManager.setSpeed(SPEED_DEFAULT)
                speedSeekBar?.progress = SPEED_DEFAULT
                updateSpeedValue(SPEED_DEFAULT)
                anythingChanged = true
            }

            if (operational && anythingChanged) {
                equalizerManager.applyPreset(0)
            }

            updateBandControlsFromLevels()

            if (anythingChanged) {
                if (isBindingComplete && musicService?.isPlaying == true) {
                    notifyPlaybackParamsChanged()
                }
                ToastManager.showToast(
                    this@EqualizerActivity,
                    getString(R.string.equalizer_toast_reset),
                    ToastManager.LENGTH_SHORT
                )
            } else {
                ToastManager.showToast(
                    this@EqualizerActivity,
                    getString(R.string.equalizer_toast_already_default),
                    ToastManager.LENGTH_SHORT
                )
            }
        }
    }

    private fun setupEnableButtonListener() {
        enableButton?.setOnClickListener {
            if (isClosing.get() || !hasAudioSession()) return@setOnClickListener
            val newState = !equalizerManager.isEnabled
            equalizerManager.setEnabled(newState)
            updateUI()
        }
    }

    private fun setupCancelButtonListener() {
        cancelButton?.setOnClickListener {
            if (!isClosing.get()) {
                window.setFlags(
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                )
                finish()
            }
        }
    }

    private fun showPresetDialog() {
        if (isClosing.get() || !isEqualizerOperational()) return
        val presetNames = equalizerManager.getPresetNames()
        val currentPreset = equalizerManager.getCurrentPreset()

        val dialog = PresetDialog(this, presetNames, currentPreset,
            object : PresetDialog.OnPresetSelectedListener {
                override fun onPresetSelected(presetIndex: Int, presetName: String) {
                    if (!isClosing.get() && isEqualizerOperational()) {
                        equalizerManager.applyPreset(presetIndex)
                    }
                }
            })
        dialog.setOnDismissListener(DialogInterface.OnDismissListener {
            isPresetDialogShowing = false
        })
        dialog.show()
    }

    private fun notifyPlaybackParamsChanged() {
        if (isClosing.get()) return
        LlamaEventBus.post(SessionEvent.PlaybackParamsRefresh)
    }

    private fun forceRedraw() {
        val root = findViewById<View>(android.R.id.content) ?: return
        root.requestLayout()
        root.invalidate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            root.postInvalidateOnAnimation()
        }
    }

    private fun recreateWithConfiguration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.updateConfiguration(
                resources.configuration,
                resources.displayMetrics
            )
        }
        recreate()
        overridePendingTransition(0, 0)
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * resources.displayMetrics.density)
}