# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app. The configuration follows a
# balanced approach focused on performance while maintaining debuggability.
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keep readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to MediaPlayer (native playback)
# - YES to PlaybackController (state management)
# - YES to NotificationService (notification actions)
# - YES to Widget support (AppWidgetProvider)
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# IMPORTANT: Disable Obfuscation (keep readable stack traces)
# ============================================================================
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Keep all app classes (full package)
# ============================================================================
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }

# ============================================================================
# PlaybackController - Centralized playback state manager
# ============================================================================
-keep class com.ark.llama.PlaybackController { *; }
-keep class com.ark.llama.PlaybackController$* { *; }
-keep interface com.ark.llama.PlaybackController$PlaybackControllerListener { *; }

# ============================================================================
# LlamaMediaPlayer - Primary audio player (MediaPlayer wrapper)
# ============================================================================
-keep class com.ark.llama.LlamaMediaPlayer { *; }
-keep class com.ark.llama.LlamaMediaPlayer$* { *; }
-keep interface com.ark.llama.LlamaMediaPlayer$NativePlayerListener { *; }
-keep class com.ark.llama.LlamaMediaPlayer$State { *; }

# ============================================================================
# MusicService - Core service
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

# ============================================================================
# NotificationService - Notification management
# ============================================================================
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.NotificationService$* { *; }

# ============================================================================
# PlaylistService - Playlist update service
# ============================================================================
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.PlaylistService$* { *; }
-keep interface com.ark.llama.PlaylistService$UpdateCallback { *; }

# ============================================================================
# StorageAccessHelper - SAF operations
# ============================================================================
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageAccessHelper$* { *; }

# ============================================================================
# StorageObserver - Storage monitoring
# ============================================================================
-keep class com.ark.llama.StorageObserver { *; }

# ============================================================================
# ToastManager - Custom toast notifications
# ============================================================================
-keep class com.ark.llama.ToastManager { *; }

# ============================================================================
# NavigationController - Centralized button state management
# ============================================================================
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep class com.ark.llama.NavigationController$ButtonGroup { *; }
-keep class com.ark.llama.NavigationController$Operation { *; }

# ============================================================================
# MusicLibrary - Music library management
# ============================================================================
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.MusicLibrary$* { *; }
-keep interface com.ark.llama.MusicLibrary$OnSongsLoadedListener { *; }
-keep interface com.ark.llama.MusicLibrary$UpdateProgressListener { *; }
-keep interface com.ark.llama.MusicLibrary$LoadProgressListener { *; }

# ============================================================================
# SongDatabase - Database helper
# ============================================================================
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# CharacterMapper - Metadata cleaning utility
# ============================================================================
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$SongInfo { *; }

# ============================================================================
# MetadataReader / MetadataWriter - ID3 tag operations
# ============================================================================
-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$MetadataBundle { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$WriteResult { *; }
-keep class com.ark.llama.MetadataWriter$UpdateBundle { *; }

# ============================================================================
# EqualizerManager - Audio effects
# ============================================================================
-keep class com.ark.llama.EqualizerManager { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

# ============================================================================
# ThemeManager / ThemeHelper - Theme management
# ============================================================================
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# DisplayManager - UI display management
# ============================================================================
-keep class com.ark.llama.DisplayManager { *; }
-keep interface com.ark.llama.DisplayManager$OnAlbumArtUpdateListener { *; }

# ============================================================================
# FolderManager - Folder management activity
# ============================================================================
-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderManager$* { *; }

# ============================================================================
# FolderAdapter - Folder list adapter
# ============================================================================
-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }
-keep class com.ark.llama.FolderAdapter$FolderItem { *; }
-keep class com.ark.llama.FolderAdapter$FolderViewHolder { *; }

# ============================================================================
# PlaylistActivity - Playlist display activity
# ============================================================================
-keep class com.ark.llama.PlaylistActivity { *; }

# ============================================================================
# PlaylistAdapter - Playlist RecyclerView adapter
# ============================================================================
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }
-keep class com.ark.llama.PlaylistAdapter$ViewHolder { *; }

# ============================================================================
# EqualizerActivity - Equalizer UI activity
# ============================================================================
-keep class com.ark.llama.EqualizerActivity { *; }

# ============================================================================
# MetadataEditor - Metadata editing activity
# ============================================================================
-keep class com.ark.llama.MetadataEditor { *; }

# ============================================================================
# MusicPlayer - Main activity
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# CreditsDialog - About dialog
# ============================================================================
-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.CreditsDialog$* { *; }
-keep interface com.ark.llama.CreditsDialog$OnThemeSelectedListener { *; }

# ============================================================================
# PresetDialog - Equalizer preset dialog
# ============================================================================
-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

# ============================================================================
# ThemeDialog - Theme selection dialog
# ============================================================================
-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }

# ============================================================================
# FontAwesome - Icon font utility
# ============================================================================
-keep class com.ark.llama.FontAwesome { *; }

# ============================================================================
# BluetoothReceiver - Bluetooth and media button receiver
# ============================================================================
-keep class com.ark.llama.BluetoothReceiver { *; }

# ============================================================================
# Song - Data model (Serializable)
# ============================================================================
-keep class com.ark.llama.Song { *; }
-keepclassmembers class com.ark.llama.Song {
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Android Components
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.view.ViewGroup
-keep public class * extends android.widget.RemoteViews
-keep public class * extends android.appwidget.AppWidgetProvider

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Enums
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep atomic classes (used for thread safety)
# ============================================================================
-keep class java.util.concurrent.atomic.** { *; }

# ============================================================================
# Keep Handler and Looper (used for threading)
# ============================================================================
-keep class android.os.Handler { *; }
-keep class android.os.Looper { *; }

# ============================================================================
# Keep SystemClock (used for all timing)
# ============================================================================
-keep class android.os.SystemClock { *; }

# ============================================================================
# Keep Resource IDs
# ============================================================================
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Third-party Libraries (jaudiotagger, AndroidX, Android framework)
# ============================================================================
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class android.media.** { *; }
-dontwarn android.media.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Keep AudioTrack (used by LlamaMediaPlayer)
# ============================================================================
-keep class android.media.AudioTrack { *; }
-keep class android.media.AudioAttributes { *; }
-keep class android.media.AudioFormat { *; }

# ============================================================================
# Keep MediaSession (lock screen controls)
# ============================================================================
-keep class android.media.session.MediaSession { *; }
-keep class android.media.session.PlaybackState { *; }
-keep class android.media.MediaMetadata { *; }

# ============================================================================
# Keep AudioFocus classes
# ============================================================================
-keep class android.media.AudioManager { *; }
-keep class android.media.AudioFocusRequest { *; }

# ============================================================================
# Keep MediaPlayer (fallback)
# ============================================================================
-keep class android.media.MediaPlayer { *; }
-keep class android.media.MediaPlayer$* { *; }

# ============================================================================
# Keep MediaMetadataRetriever (album art extraction)
# ============================================================================
-keep class android.media.MediaMetadataRetriever { *; }

# ============================================================================
# Keep MediaStore classes
# ============================================================================
-keep class android.provider.MediaStore { *; }
-keep class android.provider.MediaStore$Audio$Media { *; }
-keep class android.provider.MediaStore$Files { *; }

# ============================================================================
# Keep DocumentFile (used for SAF)
# ============================================================================
-keep class androidx.documentfile.provider.DocumentFile { *; }

# ============================================================================
# Keep ContentResolver and Cursor
# ============================================================================
-keep class android.content.ContentResolver { *; }
-keep class android.database.Cursor { *; }
-keep class android.database.ContentObserver { *; }

# ============================================================================
# Keep all SharedPreferences operations
# ============================================================================
-keep class android.content.SharedPreferences { *; }
-keep class android.content.SharedPreferences$Editor { *; }

# ============================================================================
# Keep all Intent operations
# ============================================================================
-keep class android.content.Intent { *; }
-keep class android.content.IntentFilter { *; }

# ============================================================================
# Keep KeyEvent (for media buttons)
# ============================================================================
-keep class android.view.KeyEvent { *; }

# ============================================================================
# Keep PowerManager (for wake lock)
# ============================================================================
-keep class android.os.PowerManager { *; }
-keep class android.os.PowerManager$WakeLock { *; }

# ============================================================================
# Keep Notification classes
# ============================================================================
-keep class android.app.Notification { *; }
-keep class android.app.Notification$Builder { *; }
-keep class android.app.NotificationChannel { *; }
-keep class android.app.NotificationManager { *; }

# ============================================================================
# Keep PendingIntent
# ============================================================================
-keep class android.app.PendingIntent { *; }

# ============================================================================
# Keep Uri
# ============================================================================
-keep class android.net.Uri { *; }

# ============================================================================
# Keep Paint and Canvas (placeholder generation)
# ============================================================================
-keep class android.graphics.Paint { *; }
-keep class android.graphics.Canvas { *; }
-keep class android.graphics.Bitmap { *; }
-keep class android.graphics.BitmapFactory { *; }
-keep class android.graphics.drawable.Drawable { *; }
-keep class android.graphics.drawable.GradientDrawable { *; }
-keep class android.graphics.drawable.InsetDrawable { *; }
-keep class android.graphics.drawable.StateListDrawable { *; }
-keep class android.graphics.PorterDuff { *; }
-keep class android.graphics.PorterDuffColorFilter { *; }
-keep class android.graphics.Typeface { *; }

# ============================================================================
# Keep Animation classes
# ============================================================================
-keep class android.view.animation.Animation { *; }
-keep class android.view.animation.AnimationUtils { *; }
-keep class android.view.animation.AlphaAnimation { *; }

# ============================================================================
# Keep InputMethodManager
# ============================================================================
-keep class android.view.inputmethod.InputMethodManager { *; }

# ============================================================================
# Performance: Remove verbose logging in release
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# ============================================================================
# Final safety net - keep everything (since dontobfuscate is on, this is safe)
# ============================================================================
-keep class com.ark.llama.** {
    *;
}