# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app. The configuration follows a
# balanced approach focused on performance while maintaining debuggability.
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keeps readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to MediaPlayer (native playback)
# - YES to MediaSessionCompat and MediaButtonReceiver (media button routing)
# - YES to NotificationService (notification actions)
# - YES to Widget support (AppWidgetProvider)
#
# Section header convention:
# - "Keep <Subject>" for rules that preserve classes, methods, or fields
# - Descriptive headers (Performance, Obfuscation, Logging) for build behavior
#
# @author Richard Korbla Adzido
# @version 1.1.8
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# Disable Obfuscation (keeps readable stack traces)
# ============================================================================
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Logging Removal in Release
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# ============================================================================
# Keep All Application Classes
# ============================================================================
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }

# ============================================================================
# Keep MusicService - Core Playback Service
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

# ============================================================================
# Keep NotificationService - Notification Management
# ============================================================================
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.NotificationService$* { *; }

# ============================================================================
# Keep PlaylistService - Playlist Update Service
# ============================================================================
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.PlaylistService$* { *; }
-keep interface com.ark.llama.PlaylistService$UpdateCallback { *; }

# ============================================================================
# Keep StorageAccessHelper - SAF Operations
# ============================================================================
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageAccessHelper$* { *; }

# ============================================================================
# Keep StorageObserver - Storage Monitoring
# ============================================================================
-keep class com.ark.llama.StorageObserver { *; }

# ============================================================================
# Keep ToastManager - Custom Toast Notifications
# ============================================================================
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.ToastManager$* { *; }

# ============================================================================
# Keep NavigationController - Centralized Button State Management
# ============================================================================
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep class com.ark.llama.NavigationController$ButtonGroup { *; }
-keep class com.ark.llama.NavigationController$Operation { *; }

# ============================================================================
# Keep MusicLibrary - Music Library Management
# ============================================================================
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.MusicLibrary$* { *; }
-keep interface com.ark.llama.MusicLibrary$OnSongsLoadedListener { *; }
-keep interface com.ark.llama.MusicLibrary$UpdateProgressListener { *; }
-keep interface com.ark.llama.MusicLibrary$LoadProgressListener { *; }

# ============================================================================
# Keep SongDatabase - Database Helper
# ============================================================================
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep CharacterMapper - Metadata Cleaning Utility
# ============================================================================
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$SongInfo { *; }

# ============================================================================
# Keep MetadataReader and MetadataWriter - ID3 Tag Operations
# ============================================================================
-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$MetadataBundle { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$WriteResult { *; }
-keep class com.ark.llama.MetadataWriter$UpdateBundle { *; }

# ============================================================================
# Keep EqualizerManager - Audio Effects
# ============================================================================
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.EqualizerManager$* { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

# ============================================================================
# Keep ThemeManager and ThemeHelper - Theme Management
# ============================================================================
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep FolderManager - Folder Management Activity
# ============================================================================
-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderManager$* { *; }

# ============================================================================
# Keep FolderAdapter - Folder List Adapter
# ============================================================================
-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }
-keep class com.ark.llama.FolderAdapter$FolderItem { *; }
-keep class com.ark.llama.FolderAdapter$FolderViewHolder { *; }

# ============================================================================
# Keep PlaylistActivity - Playlist Display Activity
# ============================================================================
-keep class com.ark.llama.PlaylistActivity { *; }

# ============================================================================
# Keep PlaylistAdapter - Playlist RecyclerView Adapter
# ============================================================================
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }
-keep class com.ark.llama.PlaylistAdapter$ViewHolder { *; }

# ============================================================================
# Keep EqualizerActivity - Equalizer UI Activity
# ============================================================================
-keep class com.ark.llama.EqualizerActivity { *; }

# ============================================================================
# Keep MetadataEditor - Metadata Editing Activity
# ============================================================================
-keep class com.ark.llama.MetadataEditor { *; }

# ============================================================================
# Keep MusicPlayer - Main Activity
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Keep CreditsDialog - About Dialog
# ============================================================================
-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.CreditsDialog$* { *; }

# ============================================================================
# Keep PresetDialog - Equalizer Preset Dialog
# ============================================================================
-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

# ============================================================================
# Keep ThemeDialog - Theme Selection Dialog
# ============================================================================
-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }

# ============================================================================
# Keep FontAwesome - Icon Font Utility
# ============================================================================
-keep class com.ark.llama.FontAwesome { *; }

# ============================================================================
# Keep BluetoothReceiver - Bluetooth Connection-State Handler
# ============================================================================
-keep class com.ark.llama.BluetoothReceiver { *; }

# ============================================================================
# Keep Song - Data Model (Serializable)
# ============================================================================
-keep class com.ark.llama.Song { *; }
-keepclassmembers class com.ark.llama.Song {
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Android Components
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.view.ViewGroup
-keep public class * extends android.widget.RemoteViews
-keep public class * extends android.appwidget.AppWidgetProvider

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Enums
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Atomic Classes
# ============================================================================
-keep class java.util.concurrent.atomic.** { *; }

# ============================================================================
# Keep Handler and Looper
# ============================================================================
-keep class android.os.Handler { *; }
-keep class android.os.Looper { *; }

# ============================================================================
# Keep SystemClock
# ============================================================================
-keep class android.os.SystemClock { *; }

# ============================================================================
# Keep ExecutorService and Future
# ============================================================================
-keep class java.util.concurrent.ExecutorService { *; }
-keep class java.util.concurrent.Future { *; }
-keep class java.util.concurrent.Executors { *; }

# ============================================================================
# Keep Resource IDs
# ============================================================================
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Keep Third-Party Libraries - jaudiotagger, AndroidX, Android Framework
# ============================================================================
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class android.media.** { *; }
-dontwarn android.media.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Keep androidx.media Compat Classes
# ============================================================================
# The androidx.media artifact preserves the android.support.v4.media package
# namespace for its runtime classes to maintain binary compatibility from the
# pre-AndroidX era. Only the MediaButtonReceiver was moved to androidx.media.
# R8 must keep both namespaces explicitly or the session classes will be
# stripped and the notification MediaStyle will fail to bind.
-keep class android.support.v4.media.** { *; }
-keep interface android.support.v4.media.** { *; }
-dontwarn android.support.v4.media.**

-keep class androidx.media.** { *; }
-keep interface androidx.media.** { *; }
-dontwarn androidx.media.**

# ============================================================================
# Keep MediaSessionCompat and Token Types
# ============================================================================
# MediaSessionCompat.Token.getToken() returns the framework
# MediaSession.Token on API 21+. The compat/framework boundary is crossed by
# reflection when Notification.MediaStyle.setMediaSession(...) is called.
# Both ends must be kept explicitly.
-keep class android.support.v4.media.session.MediaSessionCompat { *; }
-keep class android.support.v4.media.session.MediaSessionCompat$Token { *; }
-keep class android.support.v4.media.session.PlaybackStateCompat { *; }
-keep class android.support.v4.media.MediaMetadataCompat { *; }

-keep class android.media.session.MediaSession { *; }
-keep class android.media.session.MediaSession$Token { *; }
-keep class android.media.session.PlaybackState { *; }
-keep class android.media.MediaMetadata { *; }

# ============================================================================
# Keep AudioTrack
# ============================================================================
-keep class android.media.AudioTrack { *; }
-keep class android.media.AudioAttributes { *; }
-keep class android.media.AudioFormat { *; }

# ============================================================================
# Keep AudioFocus Classes
# ============================================================================
-keep class android.media.AudioManager { *; }
-keep class android.media.AudioFocusRequest { *; }

# ============================================================================
# Keep MediaPlayer - Native Playback
# ============================================================================
-keep class android.media.MediaPlayer { *; }
-keep class android.media.MediaPlayer$* { *; }

# ============================================================================
# Keep MediaMetadataRetriever - Album Art Extraction
# ============================================================================
-keep class android.media.MediaMetadataRetriever { *; }

# ============================================================================
# Keep MediaStore Classes
# ============================================================================
-keep class android.provider.MediaStore { *; }
-keep class android.provider.MediaStore$Audio$Media { *; }
-keep class android.provider.MediaStore$Files { *; }

# ============================================================================
# Keep DocumentFile - SAF
# ============================================================================
-keep class androidx.documentfile.provider.DocumentFile { *; }

# ============================================================================
# Keep ContentResolver and Cursor
# ============================================================================
-keep class android.content.ContentResolver { *; }
-keep class android.database.Cursor { *; }
-keep class android.database.ContentObserver { *; }

# ============================================================================
# Keep SharedPreferences
# ============================================================================
-keep class android.content.SharedPreferences { *; }
-keep class android.content.SharedPreferences$Editor { *; }

# ============================================================================
# Keep Intent
# ============================================================================
-keep class android.content.Intent { *; }
-keep class android.content.IntentFilter { *; }

# ============================================================================
# Keep KeyEvent - Media Buttons
# ============================================================================
-keep class android.view.KeyEvent { *; }

# ============================================================================
# Keep PowerManager - Wake Lock and Battery Optimization
# ============================================================================
-keep class android.os.PowerManager { *; }
-keep class android.os.PowerManager$WakeLock { *; }

# ============================================================================
# Keep Notification Classes
# ============================================================================
-keep class android.app.Notification { *; }
-keep class android.app.Notification$Builder { *; }
-keep class android.app.Notification$MediaStyle { *; }
-keep class android.app.Notification$Action { *; }
-keep class android.app.NotificationChannel { *; }
-keep class android.app.NotificationManager { *; }

# ============================================================================
# Keep PendingIntent
# ============================================================================
-keep class android.app.PendingIntent { *; }

# ============================================================================
# Keep Uri
# ============================================================================
-keep class android.net.Uri { *; }

# ============================================================================
# Keep Paint and Canvas - Placeholder Generation
# ============================================================================
-keep class android.graphics.Paint { *; }
-keep class android.graphics.Canvas { *; }
-keep class android.graphics.Bitmap { *; }
-keep class android.graphics.BitmapFactory { *; }
-keep class android.graphics.drawable.Drawable { *; }
-keep class android.graphics.drawable.GradientDrawable { *; }
-keep class android.graphics.drawable.InsetDrawable { *; }
-keep class android.graphics.drawable.StateListDrawable { *; }
-keep class android.graphics.PorterDuff { *; }
-keep class android.graphics.PorterDuffColorFilter { *; }
-keep class android.graphics.Typeface { *; }

# ============================================================================
# Keep Animation Classes
# ============================================================================
-keep class android.view.animation.Animation { *; }
-keep class android.view.animation.AnimationUtils { *; }
-keep class android.view.animation.AlphaAnimation { *; }

# ============================================================================
# Keep InputMethodManager
# ============================================================================
-keep class android.view.inputmethod.InputMethodManager { *; }

# ============================================================================
# Final Safety Net - Keep Entire App Package
# ============================================================================
-keep class com.ark.llama.** {
    *;
}